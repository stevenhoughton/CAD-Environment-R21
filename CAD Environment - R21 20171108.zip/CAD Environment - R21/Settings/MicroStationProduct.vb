﻿
'Partial Public Class Manager

'    ''' <summary>
'    ''' Base configuration for all Microstation products
'    ''' </summary>
'    ''' <remarks></remarks>
'    Public Class MicrostationProduct
'        Inherits Product

'        ''' <summary>
'        ''' Microstation Specific keys property - inherits product which contains Name, Version, Path, RegKey
'        ''' </summary>
'        ''' <value></value>
'        ''' <returns></returns>
'        ''' <remarks></remarks>

'        Public Property LoadType As String = "Program"

'        Public Property RegString As String = "PathName"

'        Private _RegionDir As String = "[MSTNSCEROOT]\Region"
'        Public Property RegionDir As String
'            Get
'                Return Manager.EvaluateExpression(_RegionDir)
'            End Get
'            Set(ByVal value As String)
'                _RegionDir = value
'            End Set
'        End Property

'        Private _MSTNRegionDir As String = "[MSTNSCEROOT]\Region"
'        Public Property MSTNRegionDir As String
'            Get
'                Return Manager.EvaluateExpression(_MSTNRegionDir)
'            End Get
'            Set(ByVal value As String)
'                _MSTNRegionDir = value
'            End Set
'        End Property

'        Public Property CheckKeyForProductExist As String = "PathName"

'        Private _WorkingFolder As String = "[MSTNSCEROOT]\Working"
'        Public Property WorkingFolder As String
'            Get
'                Return Manager.EvaluateExpression(_WorkingFolder)
'            End Get
'            Set(ByVal value As String)
'                _WorkingFolder = value
'            End Set
'        End Property

'        Public Property WorkingRegKey As String = "Software\JacobsCAD\MSTN"

'    End Class

'End Class