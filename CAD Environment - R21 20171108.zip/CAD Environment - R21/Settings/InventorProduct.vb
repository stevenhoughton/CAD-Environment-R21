﻿'Partial Public Class Manager

'    '' <summary>
'    '' Base object for all AutoCAD products
'    '' </summary>
'    '' <remarks></remarks>
'    Public Class InventorProduct
'        Inherits Manager.Product

'         Example of generic properties
'         Name = "Inventor"
'         Version "RegistryVersion16.0\ws"409"
'         Path As String = "C:\Program Files\Autodesk\Autodesk Inventor 2012"
'         RegKey As String = "Software\Autodesk\Inventor"

'        Public Property RegKeys As New List(Of Manager.RegistryKey)

'    End Class

'End Class

