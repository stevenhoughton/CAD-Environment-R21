﻿
Partial Public Class Manager

    ''' <summary>
    ''' Base product configuration object for all Jacobs object
    ''' </summary>
    ''' <remarks></remarks>
    Public Class Product

        'Public Sub New()

        '    Me.Name = Jacobs.Config.EvaluateExpression(Me.Name)
        '    Me.Version = Jacobs.Config.EvaluateExpression(Me.Version)
        '    Me.Path = Jacobs.Config.EvaluateExpression(Me.Path)
        '    Me.RegKey = Jacobs.Config.EvaluateExpression(Me.RegKey)
        '    Me.RegKeyname = Jacobs.Config.EvaluateExpression(Me.RegKeyname)

        'End Sub

        Private _Name As String = "[PRODUCTNAME]"
        Public Property Name As String
            Get
                Return Manager.EvaluateExpression(_Name)
            End Get
            Set(ByVal value As String)
                _Name = value
            End Set
        End Property

        Private _Version As String = "[PRODUCTVERSION]"
        Public Property Version As String
            Get
                Return Manager.EvaluateExpression(_Version)
            End Get
            Set(ByVal value As String)
                _Version = value
            End Set
        End Property

        Private _Path As String = "[PRODUCTINSTALLPATH]"
        Public Property Path As String
            Get
                Return Manager.EvaluateExpression(_Path)
            End Get
            Set(ByVal value As String)
                _Path = value
            End Set
        End Property

        Private _RegKey As String = "[PRODUCTREGISTRYKEYHIVE]"
        Public Property RegKey As String
            Get
                Return Manager.EvaluateExpression(_RegKey)
            End Get
            Set(ByVal value As String)
                _RegKey = value
            End Set
        End Property

        Private _RegKeyName As String = "[PRODUCTREGISTRYKEY]"
        Public Property RegKeyname As String
            Get
                Return Manager.EvaluateExpression(_RegKeyName)
            End Get
            Set(ByVal value As String)
                _RegKeyName = value
            End Set
        End Property

    End Class


End Class