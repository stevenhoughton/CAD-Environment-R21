﻿
'Partial Public Class Manager

'''' <summary>
'''' A Revit product configuration
'''' </summary>
'''' <remarks></remarks>
'Public Class RevitProduct
' Inherits Product

'Public Sub New()


'End Sub

'Private _ShortName As String = "[PRODUCTSHORTNAME]"
'Public Property ShortName As String
'Get
'Return Manager.EvaluateExpression(_ShortName)
'End Get
'Set(ByVal value As String)
'           _ShortName = value
'End Set
'End Property

'Private _RegKeyHive As String = "Software\Autodesk\Revit\[PRODUCTNAME]\Components"
'Public Property RegKeyHive As String
'Get
'Return Manager.EvaluateExpression(_RegKeyHive)
'End Get
'Set(ByVal value As String)
'           _RegKeyHive = value
'End Set
'End Property
'
'Public Property RegHiveLocation As String = "HKEY_LOCAL_MACHINE"
'Public Property RegKeyRead As String = "ProductName"
'Public Property RegKeyHiveFamily As String = "Software\Classes\Revit.Family\Shell\Open\Command"
'Public Property RegKeyHiveProject As String = "Software\Classes\Revit.Project\Shell\Open\Command"
'Public Property RegKeyHiveFamilyTemplate As String = "Software\Classes\Revit.FamilyTemplate\Shell\Open\Command"
'Public Property RegKeyHiveTemplate As String = "Software\Classes\Revit.Template\Shell\Open\Command"
'Public Property Parameters As String = "Program\Revit.exe /dde"
'Public Property RegKeyOpen As String = ""
'Public Property RegType As String = "REG_SZ"
'
'Public Property RegKeys As New List(Of Manager.RegistryKey)

'End Class

'End Class


'<Configurations>
'  <Products>
'  <product>
'<Name>Autodesk Revit Architecture 2010</Name>
'<ShortName>Revit Architecture 2010</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Architecture 2010</Path>
'<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Architecture 2010\Components</RegKeyHive>
'<RegKeyRead>ProductName</RegKeyRead>
'<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'<Parameters>\Program\Revit.exe /dde</Parameters>
'<RegKey></RegKey>
'<RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit MEP 2010</Name>
'	<ShortName>Revit MEP 2010</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit MEP 2010</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit MEP 2010\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Structure 2010</Name>
'	<ShortName>Revit Structure 2010</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Structure 2010</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Structure 2010\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\ShellOpen\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Architecture 2011</Name>
'	<ShortName>Revit Architecture 2011</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Architecture 2011</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Architecture 2011\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit MEP 2011</Name>
'	<ShortName>Revit MEP 2011</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit MEP 2011</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit MEP 2011\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Structure 2011</Name>
'	<ShortName>Revit Structure 2011</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Structure 2011</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Structure 2011\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Architecture 2012</Name>
'	<ShortName>Revit Architecture 2012</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Architecture 2012</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Architecture 2012\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit MEP 2012</Name>
'	<ShortName>Revit MEP 2012</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit MEP 2012</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit MEP 2012\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Structure 2012</Name>
'	<ShortName>Revit Structure 2012</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Structure 2012</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Structure 2012\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Architecture 2013</Name>
'	<ShortName>Revit Architecture 2013</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Architecture 2013</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Architecture 2013\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit MEP 2013</Name>
'	<ShortName>Revit MEP 2013</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit MEP 2013</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit MEP 2013\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>
'</product>
'<product>
'	<Name>Autodesk Revit Structure 2013</Name>
'	<ShortName>Revit Structure 2013</ShortName>
'	<Path>C:\Program Files\Autodesk\Revit Structure 2013</Path>
'	<RegHiveLocation>HKEY_LOCAL_MACHINE</RegHiveLocation>
'	<RegKeyHive>\Software\AutoDesk\Revit\AutoDesk Revit Structure 2013\Components</RegKeyHive>
'	<RegKeyRead>ProductName</RegKeyRead>
'	<RegKeyHiveFamily>\Software\Classes\Revit.Family\Shell\Open\Command</RegKeyHiveFamily>
'	<RegKeyHiveProject>\Software\Classes\Revit.Project\Shell\Open\Command</RegKeyHiveProject>
'	<RegKeyHiveFamilyTemplate>\Software\Classes\Revit.FamilyTemplate\Shell\Open\Command</RegKeyHiveFamilyTemplate>
'	<RegKeyHiveTemplate>\Software\Classes\Revit.Template\Shell\Open\Command</RegKeyHiveTemplate>
'	<Parameters>\Program\Revit.exe /dde</Parameters>
'  <RegKey></RegKey>
'  <RegType>REG_SZ</RegType>