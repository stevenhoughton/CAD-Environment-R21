﻿
Imports System.Text.RegularExpressions
Imports System.Xml.Serialization
Imports System.IO
Imports System.Windows.Forms
Imports Jacobs.Common.Core

Partial Public Class Manager

    ''' <summary>
    ''' All our variables
    ''' </summary>
    ''' <remarks></remarks>
    Protected Shared _Variables As New Dictionary(Of String, Variable)

    ''' <summary>
    ''' Evaluate all expression if true
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Property Evaluate As Boolean = True

    ''' <summary>
    ''' Square bracket search pattern
    ''' </summary>
    ''' <remarks></remarks>
    Protected Shared ReadOnly _Pattern As String = "\[(.*?)\]"

    ''' <summary>
    ''' Evaluate all variable in the expression string
    ''' </summary>
    ''' <param name="expression"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function EvaluateExpression(ByVal expression As String) As String

        Try
            '' check if empty expression
            If String.IsNullOrEmpty(expression) Then
                Return Nothing
            End If

            '' do it
            Return Regex.Replace(expression, _Pattern, _Evaluator)

        Catch ex As System.Exception

            GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)

            '' return null string
            Return Nothing

        End Try

    End Function

    ''' <summary>
    ''' Our pointer to the field lookup function
    ''' </summary>
    ''' <remarks></remarks>
    Protected Shared _Evaluator As MatchEvaluator = New MatchEvaluator(AddressOf Evaluator)

    ''' <summary>
    ''' Do the look up and replace with rela string
    ''' </summary>
    ''' <param name="match"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Shared Function Evaluator(ByVal match As Match) As String

        '' check if no evaluation required
        If Not Evaluate Then
            Return match.Value
        End If

        '' get the key without brackets
        Dim key As String = match.Value.Trim({"["c, "]"c})

        '' exists?
        Dim variable As Variable = Nothing
        If Not _Variables.TryGetValue(key, variable) Then

            '' bugger
            Return ""

        End If

        '' test if we need to drill down?
        If Regex.IsMatch(variable.Value, _Pattern) Then
            Return EvaluateExpression(variable.Value)
        End If

        '' get the variable to evaluate
        Return variable.Value

    End Function

    ''' <summary>
    ''' Save a configuration object to disk as an XML file
    ''' </summary>
    ''' <param name="filename"></param>
    ''' <param name="eval"></param>
    ''' <param name="config"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Save(ByVal filename As String, ByVal eval As Boolean, ByVal config As Object) As Boolean

        '' check input, bail if rubbish
        If config Is Nothing Then Return False

        '' assign evaluated flag
        Evaluate = eval

        '' this is a safe function
        Try
            '' remove existing?
            If System.IO.File.Exists(filename) Then

                '' remove
                System.IO.File.Delete(filename)

            End If

            '' open the xml serialiser 3
            Dim serializer As XmlSerializer = New XmlSerializer(config.GetType())

            If System.IO.Directory.Exists(Path.GetDirectoryName(filename)) = False Then
                Try
                    System.IO.Directory.CreateDirectory(Path.GetDirectoryName(filename))
                Catch ex As Exception
                    GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
                    Return False
                End Try
            End If

            '' stream out with writer
            Using writer As IO.TextWriter = New StreamWriter(filename)

                '' do it
                serializer.Serialize(writer, config)

            End Using

            '' Ok?
            If System.IO.File.Exists(filename) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try

        '' bugger
        Return False

    End Function

    ''' <summary>
    ''' Read in an XML file
    ''' </summary>
    ''' <param name="filename"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Read(Of T)(ByVal filename As String) As T

        '' no good if file does not exist
        If Not System.IO.File.Exists(filename) Then Return Nothing

        '' this is a safe function
        Try

            '' construct a reader 4
            Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(T))

            '' try getting the reader stream
            Using file As New System.IO.StreamReader(filename)

                '' do it
                Return CType(reader.Deserialize(file), T)

            End Using


        Catch ex As Exception

        End Try

        '' bugger
        Return Nothing

    End Function

    ''' <summary>
    ''' Register a simple key/value pair variable
    ''' </summary>
    ''' <param name="key"></param>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Register(ByVal key As String, ByVal value As String) As Variable

        '' exists?
        Dim variable As Variable = Nothing
        If Not _Variables.TryGetValue(key, variable) Then

            '' create
            variable = New Variable()

            '' save
            _Variables(key) = variable

        End If

        '' assign
        variable.Dynamic = False
        variable.EvaluateOnce = True
        variable.Expression = Nothing
        variable.Key = key
        variable.Value = value
        variable.Evaluated = False

        '' return variable
        Return variable

    End Function

    ''' <summary>
    ''' Register a simple key/value pair variable
    ''' </summary>
    ''' <param name="key"></param>
    ''' <param name="expression"></param>
    ''' <param name="once"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Register(ByVal key As String, ByVal expression As Variable.EvaluateExpressionDelegate, ByVal once As Boolean) As Variable

        '' exists?
        Dim variable As Variable = Nothing
        If Not _Variables.TryGetValue(key, variable) Then

            '' create
            variable = New Variable()

            '' save
            _Variables(key) = variable

        End If

        '' assign
        variable.Dynamic = True
        variable.EvaluateOnce = once
        variable.Expression = expression
        variable.Key = key
        variable.Value = Nothing
        variable.Evaluated = False

        '' return variable
        Return variable

    End Function

End Class