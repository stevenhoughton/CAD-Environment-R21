﻿Imports System.Data
Imports Jacobs.Common.Core
Imports System.IO
Imports System.Windows.Forms
Imports Jacobs.Common.Settings

Public Class SaveToolSettings

    Private mMySettings As System.Data.DataTable
    Private mSaveFilePath As String = ""
    Private mSettingsName As String = ""

    ''' <summary>
    ''' Class Constructor to use at time of initalise of the class on FormLoad
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New(ByVal TempXMLFileSavePath As String, ByVal SettingsName As String)

        'Dialog Name / Data you are storing
        mSettingsName = SettingsName

        '  MsgBox(TempXMLFileSavePath)

        '' Store Path
        '' If reflection was used it's possible that the DLL or EXE extension may have come through
        '' This should capture thme both
        mSaveFilePath = TempXMLFileSavePath.Replace(".DLL", ".xml")
        mSaveFilePath = TempXMLFileSavePath.Replace(".EXE", ".xml")

        If Not mSaveFilePath.ToUpper.EndsWith(".XML") Then
            mSaveFilePath = mSaveFilePath & ".xml"
        End If

        mSaveFilePath = System.IO.Path.GetDirectoryName(mSaveFilePath).CombinePath(System.IO.Path.GetFileName(mSaveFilePath))

        '' Check that the directory nominated exists
        If Not System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(mSaveFilePath)) Then
            System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(mSaveFilePath))
        End If

        '' Redefine Table
        mMySettings = New System.Data.DataTable(mSettingsName)

        '' Create Columns in Table
        mMySettings.Columns.Add("SettingName", GetType(System.String))

        mMySettings.Columns.Add("SettingValue", GetType(System.String))

        mMySettings.PrimaryKey = New System.Data.DataColumn() {mMySettings.Columns("SettingName")}

        '' Commits data
        mMySettings.AcceptChanges()

    End Sub

    Public Sub SaveDialogSettings()
        SaveXML(mMySettings, mSaveFilePath, mSettingsName)
    End Sub

    Public Sub ReadDialogSettings() 'As Boolean
        mMySettings = SettingsReadXMLFile(mSaveFilePath)
    End Sub

    Public Sub Reset()
        mMySettings.Rows.Clear()
    End Sub

    ''' <summary>
    ''' Set and Get Functions to get setting
    ''' </summary>
    ''' <param name="ControlName"></param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DialogSettings(ByVal ControlName As String) As String
        Get
            Return ReadSetting(ControlName)
        End Get
        Set(ByVal value As String)
            SaveSetting(ControlName, value)
        End Set
    End Property

#Region "Private Functions to save and write etc"

    Private Function ReadSetting(ByVal ControlFieldName As String) As String

        '' Checks to see if the Settings is inside the Datatable
        Dim DatRow As DataRow = mMySettings.Rows.Find(ControlFieldName)
        Dim Ret As String = String.Empty
        If Not DatRow Is Nothing Then
            Ret = DatRow.Item("SettingValue").ToString
        End If
        Return Ret

    End Function

    Private Sub SaveSetting(ByVal ControlName As String, ByVal SaveValue As String)

        Dim NewAddRow As DataRow

        NewAddRow = mMySettings.NewRow()
        NewAddRow.Item("SettingName") = ControlName
        NewAddRow.Item("SettingValue") = SaveValue
        mMySettings.Rows.Add(NewAddRow)

        NewAddRow = Nothing

    End Sub

    Private Sub SaveXML(ByVal DT As System.Data.DataTable, FilePath As String, ByVal SaveMessage As String)

        If DT.Rows.Count > 0 Then

            Dim LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) & Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension)

            Dim TempDS As New DataSet

            '' Add Datatable to a Temp DataSet
            TempDS.Tables.Add(DT.Copy)
            TempDS.AcceptChanges()

            If System.IO.File.Exists(FilePath) Then
                System.IO.File.Delete(FilePath)
                WriteToLog(System.IO.Path.GetFileNameWithoutExtension(FilePath) & " Settings have been deleted" & vbCrLf, LogName)
                TempDS.WriteXml(FilePath)
                WriteToLog(System.IO.Path.GetFileNameWithoutExtension(FilePath) & " Settings have been ReWritten!" & vbCrLf, LogName)
            Else

                '' Check that the directory nominated exists
                If Not System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(FilePath)) Then
                    System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(FilePath))
                End If

                TempDS.WriteXml(FilePath)
            End If

        End If

    End Sub

    Private Function SettingsReadXMLFile(ByVal SaveSettingsFile As String) As System.Data.DataTable

        Dim ReturnDT As System.Data.DataTable = mMySettings.Clone

        If System.IO.File.Exists(SaveSettingsFile) = False Then Return ReturnDT

        Dim FStream As System.IO.FileStream
        Dim TempDS As New DataSet

        Try

            FStream = New FileStream(SaveSettingsFile, FileMode.Open) ' ListEnt, FileMode.Open)

            TempDS.ReadXml(FStream)

            FStream.Close()

            If TempDS.Tables.Count > 0 Then

                TempDS.Tables(0).PrimaryKey = New System.Data.DataColumn() {TempDS.Tables(0).Columns("SettingName")}
                TempDS.Tables(0).AcceptChanges()

                ReturnDT = TempDS.Tables(0).Copy

            End If

        Catch ex As Exception

            '' Only logs the error
            GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , True, True)

        Finally
            TempDS = Nothing
            FStream = Nothing
        End Try

        Return ReturnDT

    End Function

#End Region

End Class
