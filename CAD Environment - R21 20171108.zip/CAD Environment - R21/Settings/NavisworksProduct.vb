﻿
'Partial Public Class Manager

'    ''' <summary>
'    ''' Base object for all AutoCAD products
'    ''' </summary>
'    ''' <remarks></remarks>
'    Public Class NavisworkProduct
'        Inherits Manager.Product

'        ' Example of generic properties
'        ' Name = "Freedom"
'        ' Version "1.0.0"
'        ' Path As String = "C:\Program Files\Autodesk\Navisworks\Freedom"
'        ' RegKey As String = "Software\Autodesk\Freedom"

'        Public Property RegKeys As New List(Of Manager.RegistryKey)

'    End Class

'End Class