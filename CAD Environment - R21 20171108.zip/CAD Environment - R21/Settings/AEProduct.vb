﻿
Imports Jacobs.Common.Core

Partial Public Class Manager

    ''' <summary>
    ''' AE application Settings object
    ''' </summary>
    ''' <remarks></remarks>
    Public Class AEProduct
        Inherits Product

        Public Sub New()

        End Sub

        ''' AutoCAD
        Public Property AutoCADHasBeenCustomised As Boolean = False

        Private _UserSettingsFolder As String
        Public Property UserSettingsFolder As String
            Get
                Return Manager.EvaluateExpression(_UserSettingsFolder)
            End Get
            Set(ByVal value As String)
                _UserSettingsFolder = value
            End Set
        End Property

        Private _UserSettingsFileName As String
        Public Property UserSettingsFileName As String
            Get
                Return Manager.EvaluateExpression(_UserSettingsFileName)
            End Get
            Set(ByVal value As String)
                _UserSettingsFileName = value
            End Set
        End Property

        '' Only kept because the old Jacobs_Settings.DLL still requires these.
        '' The Jacobs_Settings.DLL is used in Products like Navisworks, Inventor, Revit and Project Wise.
        '' The new Jacobs.AutoCAD.Settings.dll file uses the same Configuration.xml file as the legacy files
        '' CAD Environment Bundle Content Folder

        Public Property AELogFile As String

        Private _LogFileExtension As String
        Public Property LogFileExtension As String
            Get
                Return Manager.EvaluateExpression(_LogFileExtension)
            End Get
            Set(ByVal value As String)
                _LogFileExtension = value
            End Set
        End Property

        Public Property ExtractionFinishedFileName As String
        Public Property ConfigurationBuildersFileName As String
        Public Property SystemAdministratorsFileName As String
        Public Property ConfigurationTestersFileName As String
        Public Property MustBeConfiguredFileName As String
        Public Property ConfigMappingFileName As String
        Public Property RegionsFileName As String
        Public Property DisciplinesFileName As String
        Public Property UserPGPFileName As String
        Public Property UserCUIXFileName As String
        Public Property UserMNLFileName As String
        Public Property ConfigurationSettingsFileName As String
        Public Property ConfigUAT As String
        Public Property ConfigAE As String
        Public Property ConfigProduction As String
        Public Property ConfigDevelopment As String
        Public Property ConfigTesting As String

        Private _ConfigurationExtractionPathPrefix As String
        Public Property ConfigurationExtractionPathPrefix As String
            Get
                Return Manager.EvaluateExpression(_ConfigurationExtractionPathPrefix)
            End Get
            Set(ByVal value As String)
                _ConfigurationExtractionPathPrefix = value
            End Set
        End Property

        Public Property DefaultConfigurationFileName As String

        Private _DefaultSettingsPath As String
        Public Property DefaultSettingsPath As String
            Get
                Return Manager.EvaluateExpression(_DefaultSettingsPath)
            End Get
            Set(ByVal value As String)
                _DefaultSettingsPath = value
            End Set
        End Property

        Private _DefaultConfigurationFilePathed As String
        Public Property DefaultConfigurationFilePathed As String
            Get
                Return Manager.EvaluateExpression(Me.DefaultSettingsPath.CombinePath(Me.DefaultConfigurationFileName))
            End Get
            Set(ByVal value As String)
                _DefaultConfigurationFilePathed = value
            End Set
        End Property

        Private _LibraryFolder As String
        Public Property LibraryFolder As String
            Get
                Return Manager.EvaluateExpression(_LibraryFolder)
            End Get
            Set(ByVal value As String)
                _LibraryFolder = value
            End Set
        End Property

        Private _BlockLibraryFolder As String
        Public Property BlockLibraryFolder As String
            Get
                Return Manager.EvaluateExpression(_BlockLibraryFolder)
            End Get
            Set(ByVal value As String)
                _BlockLibraryFolder = value
            End Set
        End Property

        Private _OfficeConfigurationPath As String
        Public Property OfficeConfigurationPath As String
            Get
                Return Manager.EvaluateExpression(_OfficeConfigurationPath)
            End Get
            Set(ByVal value As String)
                _OfficeConfigurationPath = value
            End Set
        End Property

        Private _ClientConfigurationPath As String
        Public Property ClientConfigurationPath As String
            Get
                Return Manager.EvaluateExpression(_ClientConfigurationPath)
            End Get
            Set(ByVal value As String)
                _ClientConfigurationPath = value
            End Set
        End Property

        Private _ClientsConfigurationPath As String
        Public Property ClientsConfigurationPath As String
            Get
                Return Manager.EvaluateExpression(_ClientsConfigurationPath)
            End Get
            Set(ByVal value As String)
                _ClientsConfigurationPath = value
            End Set
        End Property
        Public Property DrawingSheetSetupINIFileName As String ' = "DrawingSheetSetup.INI"
        Public Property DrawingSheetsFileName As String ' = "DrawingSheets.dwg"
        '                        C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Lib\General\Drawing Sheets
        Private _DrawingSheetsPath As String ' = "[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Lib\General\Drawing Sheets"
        Public Property DrawingSheetsPath As String
            Get
                Return Manager.EvaluateExpression(_DrawingSheetsPath)
            End Get
            Set(ByVal value As String)
                _DrawingSheetsPath = value
            End Set
        End Property
        'C:\Users\
        Private _GeneralPath As String ' = "[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Lib\General"
        Public Property GeneralPath As String
            Get
                Return Manager.EvaluateExpression(_GeneralPath)
            End Get
            Set(ByVal value As String)
                _GeneralPath = value
            End Set
        End Property

        Private _AEWorkingRegKey As String ' = "Software\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]"
        Public Property AEWorkingRegKey As String
            Get
                Return Manager.EvaluateExpression(_AEWorkingRegKey)
            End Get
            Set(ByVal value As String)
                _AEWorkingRegKey = value
            End Set
        End Property

        Public Property LastUsedProductName As String

        Public Property LastUsedProductInClientselector As String ' = "LastUsedProductInClientselector"

        Public Property LastSelectedWorkspace As String ' = "LastSelectedWorkspace"

        Public Property CurrentWorkspace As String ' = "CurrentWorkspace"

        Private _FirstTimeUsePage As String = ""
        Public Property FirstTimeUsePage As String
            Get
                Return Manager.EvaluateExpression(_FirstTimeUsePage)
            End Get
            Set(ByVal value As String)
                _FirstTimeUsePage = value
            End Set
        End Property

        Public Property Database As String ' = "AE"

        Private _NetworkConfiguration As String ' = "[NETWORKCADCFG]"
        Public Property NetworkConfiguration As String
            Get
                Return Manager.EvaluateExpression(_NetworkConfiguration)
            End Get
            Set(ByVal value As String)
                _NetworkConfiguration = value
            End Set
        End Property

        Public Property ClientselectorFileName As String ' = "Clientselector.exe"

        Public ReadOnly Property ClientselectorFilePath As String
            Get
                Return Manager.EvaluateExpression(Me.Path)
            End Get
        End Property

        Public ReadOnly Property ClientseletorFilePathed As String
            Get
                Return Me.ClientselectorFilePath.CombinePath(Me.ClientselectorFileName)
            End Get
        End Property

        Public Property ProjectDrive As String ' = "I"

        Public Property ProjectStandardsFolder As String ' = "\Deliverables\Drawings\standards"

        Public Property ProjectAEConfigurationsListFile As String ' = "AEConfigurations.XML"

        Public Property ProjectCEConfigurationsListFile As String ' = "CEConfigurations.XML"
        Public Property DatabaseServer As String ' = "AU-GLB-SQL05\MISC"

        '' Only kept because the old Settings.DLL still requires these.
        '' The Settings.DLL is used in Products like Navisworks, Inventor, Revit and Project Wise.
        '' The new AutoCAD.Settings.dll file uses the same Configuration.xml file as the legacy files
        '' CAD Environment Bundle Content Folder
        Private _ApplicationPlugIns As String ' = "[APPLICATIONPLUGINS]"
        Public Property ApplicationPlugIns As String
            Get
                Return Manager.EvaluateExpression(_ApplicationPlugIns)
            End Get
            Set(ByVal value As String)
                _ApplicationPlugIns = value
            End Set
        End Property

        Private _AEContents As String
        Public Property AEContents As String
            Get
                Return Manager.EvaluateExpression(_AEContents)
            End Get
            Set(ByVal value As String)
                _AEContents = value
            End Set
        End Property

        '' CAD Environment Bundle Content Folder
        Private _AEBundleContents As String ' = "[BUNDLECONTENTS]"
        Public Property AEBundleContents As String
            Get
                Return Manager.EvaluateExpression(_AEBundleContents)
            End Get
            Set(ByVal value As String)
                _AEBundleContents = value
            End Set
        End Property

        Private _AECacheSupport As String
        Public Property AECacheSupport As String
            Get
                Return Manager.EvaluateExpression(_AECacheSupport)
            End Get
            Set(ByVal value As String)
                _AECacheSupport = value
            End Set
        End Property

        Private _ADSiteName As String ' = "[AD-SITE]"
        Public Property ADSiteName As String
            Get
                Return Manager.EvaluateExpression(_ADSiteName)
            End Get
            Set(ByVal value As String)
                _ADSiteName = value
            End Set
        End Property

        Private _DFSDownloadSettingsPath As String ' = "[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[ProductName]" & "\Settings"
        Public Property DFSDownloadSettingsPath As String
            Get
                Return Manager.EvaluateExpression(_DFSDownloadSettingsPath)
            End Get
            Set(ByVal value As String)
                _DFSDownloadSettingsPath = value
            End Set
        End Property

        Public Property DFSDownloadBypassKey As String ' = "StartUp"

        Public ReadOnly Property DFSDownloadBypassHive As String
            Get
                Return Manager.EvaluateExpression(Me.AEWorkingRegKey & "\" & Me.Name)
            End Get
        End Property

        Public ReadOnly Property BlockLibraryClientPath As String
            Get
                Return Manager.EvaluateExpression(Me.LibraryFolder.CombinePath("Client"))
            End Get
        End Property

        Public Property ConfigsToHideFileName As String ' = "ConfigsToHide.CSV"

        Public ReadOnly Property ConfigsToHideFileNamePathed As String
            Get
                Return Manager.EvaluateExpression(Me.BlockLibraryClientsPath.CombinePath(Me.ConfigsToHideFileName))
            End Get
        End Property

        Public ReadOnly Property BlockLibraryClientsPath As String
            Get
                Return Manager.EvaluateExpression(Me.LibraryFolder.CombinePath("Clients"))
            End Get
        End Property

        Public Property TemplatesToHideFileName As String

        Public ReadOnly Property TemplatesToHideFileNamePathed As String
            Get
                Return Manager.EvaluateExpression(Me.BlockLibraryClientsPath.CombinePath(Me.TemplatesToHideFileName))
            End Get
        End Property

        Public Property DFSFileDelimeter As String ' = ";"

        Public Property LastUsedProductInContentWizard As String ' = "LastUsedProductInContentWizard"

        Public Property TitleBlockInserterDATFileName As String ' = "TitleBlockInserter.dat"

        Public Property AddressDATFileName As String ' = "Address.dat"

        Public Property UserBlockFinderSettingsFileName As String

    End Class

End Class
