﻿
Partial Public Class Manager

    ''' <summary>
    ''' Base object for all AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class JPIProduct
        Inherits Manager.Product

        Public Sub New()


        End Sub

        ' Example of generic properties
        ' Name = "Freedom"
        ' Version "1.0.0"
        ' Path As String = "C:\Program Files\Autodesk\Navisworks\Freedom"
        ' RegKey As String = "Software\Autodesk\Freedom"

        Public Property LotusShortCutName As String = "Lotus Notes 8.lnk"

        Private _LotusShortCutTarget As String = "[PROGRAMFILES]" & "\" & "[MANUFACTURER]" & "\JPI Customisation for Lotus Notes Client 8.0.2\JPI Interceptor.exe"
        Public Property LotusShortCutTarget As String
            Get
                Return Manager.EvaluateExpression(_LotusShortCutTarget)
            End Get
            Set(ByVal value As String)
                _LotusShortCutTarget = value
            End Set
        End Property

        Private _LotusShortCutStartInFolder As String = "[PROGRAMFILESX86]" & "\IBM\Lotus\Notes\framework/.."
        Public Property LotusShortCutStartInFolder As String
            Get
                Return Manager.EvaluateExpression(_LotusShortCutStartInFolder)
            End Get
            Set(ByVal value As String)
                _LotusShortCutStartInFolder = value
            End Set
        End Property

        Private _LotusShortCutIconLocation As String = "[PROGRAMFILESX86]" & "\IBM\Lotus\Notes\framework\shared\eclipse\features\com.ibm.notes.links.feature_8.0.2.20080809-0430\icons\notes.ico"
        Public Property LotusShortCutIconLocation As String
            Get
                Return Manager.EvaluateExpression(_LotusShortCutIconLocation)
            End Get
            Set(ByVal value As String)
                _LotusShortCutIconLocation = value
            End Set
        End Property

        Private _LotusShortCutCommonProgramFolder As String = "[COMMONPROGRAMS]" & "\Lotus Applications"
        Public Property LotusShortCutCommonProgramFolder As String
            Get
                Return Manager.EvaluateExpression(_LotusShortCutCommonProgramFolder)
            End Get
            Set(ByVal value As String)
                _LotusShortCutCommonProgramFolder = value
            End Set
        End Property

        Public Property RegKeys As New List(Of Manager.RegistryKey)

        Public Property IniFile As String = "Notes.ini"

        Public Property ClientSetupFile As String = "LotusNotesClientSetup.txt"

        Public Property BookmarkNSF As String = "Bookmark.NSF"

        Public Property DesktopNDK As String = "Desktop6.ndk"

        Public Property KeyFileNameKEY As String = "KeyfileName="
        Public Property LotusUserName As String = "UserName="

        Private _NotesPath As String = "[PROGRAMFILESX86]" & "\IBM\lotus\notes"
        Public Property NotesPath As String
            Get
                Return Manager.EvaluateExpression(_NotesPath)
            End Get
            Set(ByVal value As String)
                _NotesPath = value
            End Set
        End Property

        Private _DataPath As String = "[PROGRAMFILESX86]" & "\IBM\lotus\notes\data"
        Public Property DataPath As String
            Get
                Return Manager.EvaluateExpression(_DataPath)
            End Get
            Set(ByVal value As String)
                _DataPath = value
            End Set
        End Property

        Private _JPIExecutionLine As String = "[PROGRAMFILESX86]" & "\IBM\Lotus\Notes\notes.exe"
        Public Property JPIExecutionLine As String
            Get
                Return Manager.EvaluateExpression(_JPIExecutionLine)
            End Get
            Set(ByVal value As String)
                _JPIExecutionLine = value
            End Set
        End Property

        Public Property FoldersToElevate As New List(Of String)

        Public Property FoldersToCreate As New List(Of String)

        Public Property ProcessesToKill As New List(Of String)

        Public Property CriticalFiles As New List(Of String)

    End Class

End Class