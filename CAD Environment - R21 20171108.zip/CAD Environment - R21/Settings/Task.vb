﻿
Partial Public Class Manager

    ''' <summary>
    ''' A system variable configuration object for AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class Task

        ''' <summary>
        ''' Default construction
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()

        End Sub

        ''' <summary>
        ''' Initialise Parameters
        ''' </summary>
        ''' <param name="Destination"></param>
        ''' <param name="Source"></param>
        ''' <param name="recursesubfolders"></param>
        ''' <param name="FolderFilter"></param>
        ''' <param name="FileFilter"></param>
        ''' <param name="CheckDFSChangeLog"></param>
        ''' <param name="ByPassKey"></param>
        ''' <param name="callingapp"></param>
        ''' <param name="DFSChangesFile"></param>
        ''' <param name="Bypasskeyhive"></param>
        ''' <remarks></remarks>
        Public Sub New(Source As String, FolderFilter As String, FileFilter As String, Destination As String, Bypasskeyhive As String, ByPassKey As String, CheckDFSChangeLog As Boolean, DFSChangesFile As String, recursesubfolders As Boolean, callingapp As String, DeleteIfNotOnDFS As Boolean, ProductInstalledKey As String)

            '' save to me

            Me.Source = Source
            Me.FolderFilter = FolderFilter
            Me.FileFilter = FileFilter
            Me.Destination = Destination
            Me.ByPassKeyHive = Bypasskeyhive
            Me.ByPassKey = ByPassKey
            Me.CheckDFSChangeLog = CheckDFSChangeLog
            Me.DFSChangesFile = DFSChangesFile
            Me.RecurseSubFolders = recursesubfolders
            Me.CallingApp = callingapp
            Me.DeleteIfNotOnDFS = DeleteIfNotOnDFS
            Me.ProductInstalledKey = ProductInstalledKey

        End Sub


        ''' <summary>
        ''' Location on distributed file share (DFS) where you wish to copy files from.
        ''' Due to a bug in windows ensure you use URLs and not mapped drive letters to DFS shares
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Source As String

        ''' <summary>
        ''' The location on the PC where the files need to end up
        ''' Example... C:\Users\Public\Jacobs\Jacobs AutoCAD Enviroment R21\Lib
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Destination As String

        ''' <summary>
        ''' When set to true it will copy all files and sub folders - the directory tree is replicated below the Destination path
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RecurseSubFolders As Boolean

        ''' <summary>
        ''' The Search pattern is the name of the file you wish to download - it can use the normal wild card characters
        ''' Example Test.DWG or Test.* or even *.*
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' 
        Public Property FolderFilter As String
        ''' <summary>
        ''' The Search pattern is the name of the file you wish to download - it can use the normal wild card characters
        ''' Example Test.DWG or Test.* or even *.*
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>

        Public Property FileFilter As String

        ''' <summary>
        ''' Does a file check to see if the DFS change log file is the same on the PC and the DFS if they are then nothing gets copies.
        ''' Set to False to ignore checking the file and copy regardless
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CheckDFSChangeLog As Boolean

        ''' <summary>
        ''' This is an auditing field used on error messages as well to work out which program was used to call the downloaded.
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CallingApp As String

        ''' <summary>
        ''' Any changes made to the DFS need to be recorded in a DFSChanges.TXT file which should contain information such as...
        ''' Who Made the change, Who requested the change, what was changed, data and time of change
        ''' This file is used to see if a download is required when CheckDFSChangeLog is set to False
        ''' This file is to be stored in the root folder of the DFS share
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DFSChangesFile As String

        ''' <summary>
        ''' Download key to check - as boolean string
        ''' Example: DFSDownload
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ByPassKey As String

        ''' Each product can have a registry key set to stop the automatic downloads, this is done for testing purposes and on special cases...
        ''' The download key registry location and name are set here- but user or CAD Support team memeber would need to manually set the key to TRUE
        ''' for this to stop downloading. If the key is not present or it is set to false then the download continues regardless
        ''' Example... Software\Jacobs\BlockLibrary
        Public Property ByPassKeyHive As String

        ''' <summary>
        ''' If set to false it will not delete files on the PC hence the DFS and PC would not be in sync
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DeleteIfNotOnDFS As Boolean

        ''' <summary>
        ''' Use to see if a product is installed
        ''' If this hive\key is not empty and the hive\key is not present then the download for this task will not take place
        ''' If the hive\key is empty then it will execute the download
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProductInstalledKey As String


    End Class

End Class
