﻿
Partial Public Class Manager

    ''' <summary>
    ''' Variable information for expressions to be evaluated
    ''' </summary>
    ''' <remarks></remarks>
    Public Class Variable

        ''' <summary>
        ''' Evaluate expression signature
        ''' </summary>
        ''' <param name="key"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Delegate Function EvaluateExpressionDelegate(ByVal key As String) As String

        ''' <summary>
        ''' The variable key
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Key As String

        ''' <summary>
        ''' Our simple value
        ''' </summary>
        ''' <remarks></remarks>
        Protected _Value As String

        ''' <summary>
        ''' The final variable value either assigned of evaluated
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Value As String
            Get
                '' eval?
                If Dynamic Then

                    '' once off, already evaluated
                    If EvaluateOnce And _Evaluated Then

                        '' return previously evaluated 
                        Return _Value

                    ElseIf EvaluateOnce And Not _Evaluated Then

                        '' evaluate
                        _Value = Expression.Invoke(Key)

                        '' save state
                        _Evaluated = True

                        '' return value
                        Return _Value

                    Else

                        '' always dyanamic
                        Return Expression.Invoke(Key)

                    End If
                Else

                    '' simple valued returned
                    Return _Value

                End If
            End Get
            Set(ByVal value As String)

                '' blindly set this static or dynamic variable
                _Value = value

            End Set
        End Property

        ''' <summary>
        ''' Dynamically evaluate with the expression function
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Dynamic As Boolean = False

        ''' <summary>
        ''' A once off flag to determine if its been evaluated
        ''' </summary>
        ''' <remarks></remarks>
        Protected _Evaluated As Boolean = False

        ''' <summary>
        ''' A once off flag to determine if its been evaluated
        ''' </summary>
        ''' <remarks></remarks>
        Public Property Evaluated As Boolean
            Get
                Return _Evaluated
            End Get
            Set(value As Boolean)
                _Evaluated = value
            End Set
        End Property

        ''' <summary>
        ''' Evaluate only once
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property EvaluateOnce As Boolean = True

        ''' <summary>
        ''' The expression function
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Expression As EvaluateExpressionDelegate

    End Class

End Class