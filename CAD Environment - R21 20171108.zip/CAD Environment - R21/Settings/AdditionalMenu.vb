﻿
Partial Public Class Manager

    ''' <summary>
    ''' A system variable configuration object for AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class AdditionalMenu

        ''' <summary>
        ''' Default construction
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()

        End Sub

        Public Sub New(CUIName As String, MenuName As String, PopUps As String, VisibleToolBars As String, SupportSearchPaths As String, ToolPalettePath As String, profilespecific As String)

            '' save to me
            Me.CUIName = CUIName
            Me.MenuName = MenuName
            Me.PopUps = PopUps
            Me.VisibleToolBars = VisibleToolBars
            Me.SupportSearchPaths = SupportSearchPaths
            Me.ToolPalettePath = ToolPalettePath
            Me.ProfileSpecific = ProfileSpecific

        End Sub

        ''' <summary>
        '''  The path and name of the CUI we wish to load
        ''' Example: [ROAMABLEROOTFOLDER]Support\Jacobs.CUI
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property CUIName As String

        ''' <summary>
        ''' The name of the menu group you wish to load
        ''' Example: Jacobs
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property MenuName As String

        ''' <summary>
        ''' The name and location of the pop down menus PopUp name and location is comma separated but multiple pop ups are semicolon separated
        ''' Example: Jacobs,9
        ''' or: Jacobs,9;MyMenu,10
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property PopUps As String

        ''' <summary>
        ''' The names of the tool bars that you wish to turn on semicolon separated
        ''' Example: Jacobs
        ''' or Jacobs;JacobsTEXT;JacobsSCALE;JacobsDIMS
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property VisibleToolBars As String

        ''' <summary>
        ''' Any Support search paths to be added 
        ''' Example: [BUNDLECONTENTS];[ProgramFiles]\Autodesk\Object Enablers
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property SupportSearchPaths As String

        'Private _SupportSearchPaths As String
        'Public Property SupportSearchPaths As String
        '    Get
        '        Return Jacobs.Config.EvaluateExpression(_SupportSearchPaths)
        '    End Get
        '    Set(value As String)
        '        _SupportSearchPaths = value
        '    End Set
        'End Property

        ''' <summary>
        ''' Tool pallet location
        ''' Example: C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Tool Palettes
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ToolPalettePath As String

        'Private _ToolPalettePath As String
        'Public Property ToolPalettePath As String
        '    Get
        '        Return Jacobs.Config.EvaluateExpression(_ToolPalettePath)
        '    End Get
        '    Set(value As String)
        '        _ToolPalettePath = value
        '    End Set
        'End Property

        ''' <summary>
        ''' The name of the profile to load these on - if no profile name is specified it will load on all profiles
        ''' Multiple profiles can be specified semicolon delimited
        ''' Example: UnnamedProfile
        ''' or: UnnamedProfile;ProStructures;MechQ
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property ProfileSpecific As String

    End Class


    '       <AdditionalMenu>
    '         <CUIName>[ROAMABLEROOTFOLDER]Support\Jacobs.CUI</CUIName>
    '         <MenuName>Jacobs</MenuName>
    '         <PopUps>Jacobs,9</PopUps>
    '         <VisibleToolBars>Jacobs</VisibleToolBars>
    '         <SupportSearchPaths>[BUNDLECONTENTS];[ProgramFiles]\Autodesk\Object Enablers</SupportSearchPaths>
    '         <ToolPalettePath>C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Tool Palettes</ToolPalettePath>
    '         <ProfileSpecific><ProfileSpecific>
    '       </AdditionalMenu>

End Class
