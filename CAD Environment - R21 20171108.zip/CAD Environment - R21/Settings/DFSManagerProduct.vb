﻿
Imports Jacobs.Common.Core

Partial Public Class Manager


    ''' <summary>
    ''' Base object for all AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class DFSManagerProduct
        Inherits Manager.Product

        Public Sub New()


        End Sub

        ' Example of generic properties
        ' Name = "DFSDownloader"
        ' Version "1.0.0"
        ' Path As String = "C:\Program Files\Jacobs\DFS Manager R20"
        ' RegKey As String = "Software\Jacobs\DFS Manager R20"

        Public Property Tasks As New List(Of Manager.Task)

        Public Property DFSDownloaderConsoleFileName As String = "ConsoleDownloader.exe"

        Public ReadOnly Property DFSDownloaderConsole As String
            Get
                Return Manager.EvaluateExpression(Me.Path.CombinePath(Me.DFSDownloaderConsoleFileName))
            End Get
        End Property

        Public Property DFSDownloaderWindowsFileName As String = "WindowsDownloader.exe"

        Public ReadOnly Property DFSDownloaderWindow As String
            Get
                Return Manager.EvaluateExpression(Me.Path.CombinePath(Me.DFSDownloaderWindowsFileName))
            End Get
        End Property

        Private _DFSShareLocation As String = "[DFSSHARE]"
        Public Property DFSShareLocation As String
            Get
                Return Manager.EvaluateExpression(_DFSShareLocation)
            End Get
            Set(ByVal value As String)
                _DFSShareLocation = value
            End Set
        End Property

    End Class

End Class