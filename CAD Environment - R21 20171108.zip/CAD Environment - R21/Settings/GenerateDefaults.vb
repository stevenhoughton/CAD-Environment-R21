﻿Module GenerateDefaults

    'Dim filename As String = "C:\Public\Users\Temp\Configuration.XML"

    Public Function WriteXML(filename As String) As Boolean

        '' all data goes here
        Dim cfg As New Settings()

        Manager.Register("ASSETNUMBER", My.Computer.Name)
        Manager.Register("USERNAME", System.Environment.UserName)
        Manager.Register("JPILOGINNAME", Jacobs.Common.Core.WorkOutJPILoginName())
        Manager.Register("REGION", Jacobs.Common.Core.WorkOutRegion())

        cfg.AssetNumber = Manager.EvaluateExpression("[ASSETNUMBER]")
        cfg.UserName = Manager.EvaluateExpression("[USERNAME]")
        cfg.Region = Manager.EvaluateExpression("[REGION]")
        cfg.JPILoginName = Manager.EvaluateExpression("[JPILOGINNAME]")

        cfg.AEs.Add(GenerateAE("Jacobs AutoCAD Environment R21", "21.0.0", "Software\Jacobs\Jacobs AutoCAD Environment R21", "ProductCode", Manager.EvaluateExpression("[BUNDLECONTENTS]")))

        ' add to config object so we can write the xml file
        cfg.AutoCADs.Add(GenerateAutoCAD("AutoCAD 2017", "R21.0", "Software\Autodesk\AutoCAD\R21.0\Acad-0001:409", "ProductName", "C:\Program Files\Autodesk\AutoCAD 2017", "Acad-0001:409", "Acad", "Jacobs_Acad_Custom", "Acad 2017"))
        'cfg.AutoCADs.Add(GenerateAutoCAD("AutoCAD Map 3D 2017", "R21.0", "Software\Autodesk\AutoCAD\R21.0\Acad-0002:409", "ProductName", "C:\Program Files\Autodesk\AutoCAD Map 3D 2017", "Acad-0002:409", "MAP", "Jacobs_MAP_Custom", "MAP3D 2017"))
        cfg.AutoCADs.Add(GenerateAutoCAD("AutoCAD Civil 3D 2017", "R21.0", "Software\Autodesk\AutoCAD\R21.0\Acad-0000:409", "ProductName", "C:\Program Files\Autodesk\AutoCAD 2017", "Acad-0000:409", "C3D_Metric", "Jacobs_Civil_Custom", "C3D 2017"))

        cfg.DFSManager = GenerateDFS()

        cfg.JPI = GenerateJPI("JPI Customisation for Lotus Notes Client 8.0.2", "1.0.0", "C:\Program Files\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2", "Jacobs\JPI Customisation for Lotus Notes Client 8.0.2")

        '' write to disk
        Return Manager.Save(filename, False, cfg)

    End Function

    Private Function GenerateAE(ByVal prodname As String, ByVal version As String, ByVal regkey As String, ByVal regkeyname As String, ByVal path As String) As Manager.AEProduct

        ' In App Registration requirements
        ' AEPRODUCTNAME 

        ' AE Product Section
        Dim AE As New Manager.AEProduct

        AE.Name = prodname
        AE.Path = path
        AE.RegKey = regkey
        AE.Version = version
        AE.RegKeyname = "ProductCode"

        If version.Contains("21.") Then
            AE.LibraryFolder = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Clients")
            AE.BlockLibraryFolder = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Lib")
            AE.DrawingSheetsPath = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Lib\General\Drawing Sheets")
            AE.AEContents = Manager.EvaluateExpression("[BUNDLECONTENTS]")
            AE.OfficeConfigurationPath = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Office")
            AE.ClientConfigurationPath = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Client")
            AE.ClientsConfigurationPath = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Clients")
            AE.GeneralPath = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Lib\General")
            AE.DFSDownloadSettingsPath = Manager.EvaluateExpression("[DFSSHARE]" & "\Jacobs\Production\CAD Environment\Autodesk\AutoCAD 2017 Settings")
        End If

        Return AE

    End Function

    Private Function GenerateAutoCAD(ByVal prodname As String, ByVal version As String, ByVal regkey As String, ByVal regkeyname As String, ByVal path As String, ByVal prodno As String, ByVal EntCUIFileNameNoExt As String, ByVal MainCUIFileNameNoExt As String, ByVal prodshortname As String) As Manager.AutoCADProduct

        Manager.Register("PRODUCTREGISTRYKEY", regkeyname)
        Manager.Register("PRODUCTREGISTRYHIVE", regkey)
        Manager.Register("PRODUCTINSTALLPATH", path)
        Manager.Register("PRODUCTVERSION", version)
        Manager.Register("PRODUCTNAME", prodname)
        Manager.Register("PRODUCTNUMBER", prodno)
        Manager.Register("SHORTNAME", prodshortname)

        If prodname.Contains("2017") Then
            Common.Settings.Manager.Register("SHAREDACADNAME", Jacobs.Common.Core.WorkOutSharedAcadName("R21"))
        End If

        ' Populate AutoCAD product details
        Dim AutoCAD As New Manager.AutoCADProduct

        AutoCAD.RegKey = regkey
        AutoCAD.ShortName = prodshortname
        AutoCAD.RegKeyname = "ProductName"
        AutoCAD.Version = version
        AutoCAD.Name = prodname
        AutoCAD.Path = path
        AutoCAD.EntCUIFileNameNoExt = EntCUIFileNameNoExt
        AutoCAD.MainCUIFileNameNoExt = MainCUIFileNameNoExt

        If version.Contains("21.") Then
            AutoCAD.ToolPalettePath = Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPPRODUCTNAME]" & "\" & "Tool Palettes")
            AutoCAD.RestoreAcadCUI = False
        End If

        'AutoCAD.UserSettingsFileName = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData) & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\" & "[PRODUCTNAME]" & ".XML")
        AutoCAD.RegistryKeysToAdd.Add(New Manager.RegistryKey("HKCU", regkey & "\Profiles\" & "[CurrentProfile]" & "\Variables", "WBHELPONLINE", "0", "REG_SZ", ""))
        AutoCAD.RegistryKeysToAdd.Add(New Manager.RegistryKey("HKCU", regkey & "\Profiles\" & "[CurrentProfile]" & "\Variables", "NFWState", "1", "REG_DWORD", ""))
        AutoCAD.RegistryKeysToAdd.Add(New Manager.RegistryKey("HKCU", regkey & "\Profiles\" & "[CurrentProfile]" & "\General", "UseStartUpDialog", "0", "REG_DWORD", ""))
        AutoCAD.RegistryKeysToAdd.Add(New Manager.RegistryKey("HKCU", regkey & "\Profiles\" & "[CurrentProfile]" & "\Variables", "NEWTABMODE", "0", "REG_SZ", ""))
        AutoCAD.RegistryKeysToAdd.Add(New Manager.RegistryKey("HKCU", regkey, "LaunchNFW", "3", "REG_DWORD", path & "\Acad.exe"))
        ' NOTE System variables - these are mandatory (persistent = true)
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("HPMAXLINES", "10000000", True, "Int"))
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("MEASUREINIT", "1", True, "Int"))
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("MEASUREMENT", "1", False, "Int"))
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("PUBLISHCOLLATE", "0", False, "Int"))       ' Jacobs.AE.Config.AutoCAD.
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("BACKGROUNDPLOT", "0", False, "Int"))       ' Jacobs.AE.Config.AutoCAD.
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("REMEMBERFOLDERS", "1", True, "Int"))       ' Jacobs.AE.Config.AutoCAD.RememberFolders
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("ACADLSPASDOC", "0", True, "Int"))
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("CMDECHO", "1", True, "Int"))               ' ,"CMDECHO or Command line echoing has been turned on.")               ' Jacobs.AE.Config.AutoCAD.CMDECHO
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("NOMUTT", "0", True, "Int"))                ' ,"Command line muttering or NOMUTT has been turned off.")                ' Jacobs.AE.Config.AutoCAD.NOMUTT
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("OLESTARTUP", "1", True, "Int"))            ' Jacobs.AE.Config.AutoCAD.OLESTARTUP
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("FILEDIA", "1", True, "Int"))               ' Jacobs.AE.Config.AutoCAD.FILEDIA
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("CMDDIA", "1", True, "Int"))              ' Jacobs.AE.Config.AutoCAD.CMDDIA
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("MAXSORT", "1000", False, "Int"))            ' Jacobs.AE.Config.AutoCAD.MAXSORT
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("FONTALT", "ISOCP.shX", True, "Str"))       ' Jacobs.AE.Config.AutoCAD.FONTALT
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("ATTREQ", "1", True, "Int"))                ' Jacobs.AE.Config.AutoCAD.ATTREQ
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("MAXACTVP", "64", True, "Int"))             ' Jacobs.AE.Config.AutoCAD.MAXACTVP
        ' NOTE System variables - these are optional (persistent = false)
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("SAVEFIDELITY", "0", False, "Int"))          ' ,"Save fidelity has been turned off Annotation objects may not be visible in previous AutoCAD versions.")          ' Jacobs.AE.Config.AutoCAD.SetSaveFidelity
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("DCTMAIN", "Eng", False, "Str"))             ' ,"The main AutoCAD spelling checker dictionary has been set to UK English - eg. ise not ize.")             ' Jacobs.AE.Config.AutoCAD.DCTMAIN
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("DYNMODE", "0", False, "Int"))               ' ,"Dynamic mode has been turned off due to known lagging issues.")               ' Jacobs.AE.Config.AutoCAD.DYNMODE
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("INPUTHISTORYMODE", "7", False, "Int"))      ' ," Input history mode has been set to 7.")      ' Jacobs.AE.Config.AutoCAD.INPUTHISTORYMODE
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("CURSORSIZE", "5", False, "Int"))            ' Jacobs.AE.Config.AutoCAD.CursorSize
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("SELECTIONAREA", "0", True, "Int"))            ' Jacobs.AE.Config.AutoCAD.CursorSize
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("PREVIEWFILTER", "23", True, "Int"))        ' Jacobs.AE.Config.AutoCAD.PREVIEWFILTER
        AutoCAD.SystemVariables.Add(New Manager.SystemVariable("MENUBAR", "1", True, "Int"))       ' Jacobs.AE.Config.AutoCAD.RememberFold
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("ShowTabs", "1", True, "Str"))                ' Jacobs.AE.Config.AutoCAD.DisplayLayoutTabs
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("MaxHatch", "1000000.0", True, "Str"))        ' Jacobs.AE.Config.AutoCAD.MAXHATCH
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("Scrollbars", "0", True, "Str"))              ' Jacobs.AE.Config.AutoCAD.DisplayScrollBars
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("ShowPaperMargins", "0", False, "Str"))        ' Jacobs.AE.Config.AutoCAD.LayoutDisplayMargins
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("ShowPrintBorder", "0", False, "Str"))         ' Jacobs.AE.Config.AutoCAD.LayoutDisplayPaper
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("ShowPaperBackground", "0", False, "Str"))     ' Jacobs.AE.Config.AutoCAD.LayoutDisplayPaperShadow
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("LayoutXhairPickboxEtc", "0", False, "Str"))   ' Jacobs.AE.Config.AutoCAD.LayoutCrosshairColor
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("ACADHELP", "C:\Program Files\Autodesk\" & prodname & "\Help\index.html", False, "Str"))
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("NFWState", "0", False, "Str"))
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("ModelSpaceBackground", "0", False, "Str"))              ' Jacobs.AE.Config.AutoCAD.GraphicsWinModelBackgrndColor
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("XhairPickboxEtc", "16777215", False, "Str"))  ' Jacobs.AE.Config.AutoCAD.ModelCrosshairColor
        ' AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("LayoutXhairPickboxEtc", "10", False, "Str"))  ' Jacobs.AE.Config.AutoCAD.LayoutCrosshairColor
        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("Layout background", "0", False, "Str"))       ' Jacobs.AE.Config.AutoCAD.GraphicsWinLayoutBackgrndColor

        If prodname.Contains("2017") Then
            AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("DefaultConfig", "%USERPROFILE%\appdata\roaming\autodesk\" & prodname & "\R21.0\enu\plotters\dwg to pdf.pc3", False, "Str"))  ' Jacobs.AE.Config.AutoCAD.DefaultOutputDevice
        End If

        AutoCAD.EnvironmentVariables.Add(New Manager.SystemVariable("BEditBackground", "8421504", False, "Str"))
        '                                        C:\Users\[USERNAME]\AppData\Roaming\Autodesk\AutoCAD 2017\R21.0\enu\Support\JacobsOffice.cuix
        AutoCAD.AdditionalMenus.Add(New Manager.AdditionalMenu(Manager.EvaluateExpression("[ROAMABLEROOTPREFIX]" & "\Support\JacobsOffice.CUIX"), "SKMOffice", "SKMOffice,11", "SKMOffice", "", "", ""))

        Return AutoCAD

    End Function

    Private Function GenerateDFS() As Manager.DFSManagerProduct

        Dim DFSProduct As New Manager.DFSManagerProduct

        DFSProduct.Name = "DFS Manager R20"
        DFSProduct.Path = Manager.EvaluateExpression("[PROGRAMFILES]" & "\" & "[MANUFACTURER]" & "\DFS Manager R20")
        DFSProduct.RegKey = Manager.EvaluateExpression("Software\" & "[MANUFACTURER]" & "\DFS Manager R20")
        DFSProduct.Version = "21.0.0"
        DFSProduct.RegKeyname = "ProductCode"
        ' DFSProduct.DFSShareLocation = Manager.EvaluateExpression("\\Jacobs\\cc")

        ' Replaces these parameters when application is called with the UseConfigurationFile=True

        '' Me.Source = Source
        '' Me.FolderFilter = FolderFilter
        '' Me.FileFilter = FileFilter
        '' Me.Destination = Destination
        '' Me.ByPassKeyHive = Bypass key hive
        '' Me.ByPassKey = ByPassKey
        '' Me.CheckDFSChangeLog = CheckDFSChangeLog
        '' Me.DFSChangesFile = DFSChangesFile
        '' Me.RecurseSubFolders = recurse sub folders
        '' Me.CallingApp = calling application
        '' Me.DeleteIfNotOnDFS = DeleteIfNotOnDFS
        '' Me.ProductInstalledKey = ProductInstalledKey


        ' 2017 AutoCAD 

        ''----[ AutoCAD Environment Settings ]------------------------------------------------------------------------------------------------------------------------------
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 Settings"),
        "Jacobs*",
        "*.*",
        Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Settings"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 Settings\DFSDownloadBypass"),
        "DFSDownload",
        False,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\DFS Manager R21\ProductCode")))

        ''----[ AutoCAD Environment ]--------------------------------------------------------------------------------------------------------------------------------------
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 Bundle"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("[BUNDLE]"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 Bundle\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\Jacobs AutoCAD Environment R21\ProductCode")))

        ''----[ AutoCAD Environment BlockLibrary ]------------------------------------------------------------------------------------------------------------------------											
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 BlockLibrary"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Lib"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 BlockLibrary\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\Jacobs AutoCAD Environment R21\ProductCode")))

        ''----[ AutoCAD Environment Tool Palettes ]------------------------------------------------------------------------------------------------------------------------
        ' BlockLibrary.MSI
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 Tool Palettes"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\AutoCAD 2017\Tool Palettes"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 Tool Palettes\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\Jacobs AutoCAD Environment R21\ProductCode")))

        ' Task to Fix Express Tools
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 Express Tools Fix"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\Program Files\Autodesk\AutoCAD 2017\Express"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 Express Tools Fix"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\Jacobs AutoCAD Environment R21\ProductCode")))

        ' Task to Missing MAP 3D Fonts 
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\Civil 3D 2017 Missing Fonts"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\Program Files\Autodesk\AutoCAD Civil 3D 2017\Fonts"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 Civil 3D Missing Fonts"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        "Software\Autodesk\AutoCAD\R21.0\Acad-0000:409\ProductName"))

        ' Task to Missing MAP 3D Fonts 
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 Missing Fonts"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\Program Files\Autodesk\AutoCAD 2017\Fonts"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 AutoCAD Missing Fonts"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\Jacobs AutoCAD Environment R21\ProductCode")))

        ''----[ AutoCAD Environment Templates AKA Configurations ]----------------------------------------------------------------------------------------------------------
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\AutoCAD 2017 Configurations"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\Cleints"),
        Manager.EvaluateExpression("Software\Jacobs\Jacobs AutoCAD Environment R21 Configurations\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\Jacobs AutoCAD Environment R21\ProductCode")))

        ''----[ Lotus Notes And JPI - Marcus Powrie Special ]-------------------------------------------------------------------------------------------------------------
        '' Lotus Notes Task
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\" & "[AD-SITE]" & "\JPI\Lotus Notes (x86)\Notes"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("[PROGRAMFILESX86]" & "\IBM\lotus\notes"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        '' Lotus Notes Task User ID Files
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\" & "[AD-SITE]" & "\JPI\User ID"),
        "*.*",
        "[JPILOGINNAME]",
        Manager.EvaluateExpression("[USERAPPDATAROAMING]" & "\IBM\lotus\notes\data"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        False,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        ' Lotus Notes User Project Files 
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\" & "[AD-SITE]" & "\JPI\User ID\" & "[USERNAME]" & "\Projects"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\ProgramData\JPI\Projects"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        ' Lotus Notes Office Project Files
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\" & "[AD-SITE]" & "\JPI\Projects"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\ProgramData\JPI\Projects"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        ' Lotus Notes Region Project Files
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\JPI\Projects"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\ProgramData\JPI\Projects"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))


        ' Applications.EXE Regional Applications.INI Files 
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\JPI\Apps\ApplicationLauncher"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\ProgramData\JPI\Apps\ApplicationLauncher"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        '' Applications.EXE Regional Applications.INI Files 
        'DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]\[MANUFACTURER]\Production\[REGION]\skmw\Templates"), _
        '                                            "*.*", _
        '                                             Manager.EvaluateExpression("C:\Program Files (x86)\skmw\Templates"), _
        '                                            Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"), _
        '                                            "DFSDownload", _
        '                                            True, _
        '                                            "DFSChange.log", _
        '                                            True, _
        '                                            "Windows Startup Process", _
        '                                             False,
        '                                            Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        ' Application.exe Office Applications.INI Files
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\" & "[REGION]" & "\" & "[AD-SITE]" & "\JPI\Apps\ApplicationLauncher"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\ProgramData\JPI\Apps\ApplicationLauncher"),
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("Software\Jacobs\JPI Customisation for Lotus Notes Client 8.0.2\ProductCode")))

        ' Task to Download the Project Wise Manager files 1.0.0 (i.e. Updates)
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\SKM CAD\Autodesk\SCE\Project Wise Manager.Bundle"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\Program Files\Autodesk\ApplicationPlugins\Project Wise Manager.Bundle"),
        Manager.EvaluateExpression("Software\SKMCAD\Project Wise Manager\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        True,
        Manager.EvaluateExpression("SOFTWARE\SKMCAD\SKMCAD ProjectWise SS4 Customisation\1.0.0\GUID ProductCode")))

        ' Task to Download the Project Wise Manager files 1.1.1 (i.e. Updates)
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\SKM CAD\Autodesk\SCE\Project Wise Manager.Bundle"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\Program Files\Autodesk\ApplicationPlugins\Project Wise Manager.Bundle"),
        Manager.EvaluateExpression("Software\SKMCAD\Project Wise Manager\DFSDownloadBypass"),
        "DFSDownload",
        True,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        True,
        Manager.EvaluateExpression("SOFTWARE\SKMCAD\SKMCAD ProjectWise SS4 Customisation\1.1.1\GUID ProductCode")))

        ' Task to Download the AutoPLANT SS3 Object Enabler Fix
        DFSProduct.Tasks.Add(New Manager.Task(Manager.EvaluateExpression("[DFSSHARE]" & "\" & "[MANUFACTURER]" & "\Production\CAD Environment\Autodesk\Bentley AutoPLANT SS3 Object Enabler"),
        "*.*",
        "*.*",
        Manager.EvaluateExpression("C:\Program Files (x86)\Bentley\Plant V8i\Bin\R18"),
        Manager.EvaluateExpression("Software\Jacobs\AutoCAD Environment Bentley AutoPLANT SS3 OE"),
        "DFSDownload",
        False,
        "DFSChange.log",
        True,
        "Windows Startup Process",
        False,
        Manager.EvaluateExpression("SOFTWARE\Jacobs\AutoCAD Environment\ProductCode")))

        Return DFSProduct

    End Function
    Private Function GenerateJPI(ByVal productname As String, ByVal version As String, ByVal path As String, ByVal regkey As String) As Manager.JPIProduct

        Dim JPIProduct As New Manager.JPIProduct

        JPIProduct.Name = productname
        JPIProduct.Path = path
        JPIProduct.RegKey = regkey
        JPIProduct.Version = version

        JPIProduct.LotusShortCutName = "Lotus Notes 8.lnk"
        JPIProduct.LotusShortCutTarget = Manager.EvaluateExpression("[PROGRAMFILES]" & "\" & "[MANUFACTURER]" & "\JPI Customisation for Lotus Notes Client 8.0.2\JPI Interceptor.exe")
        JPIProduct.LotusShortCutStartInFolder = Manager.EvaluateExpression("[PROGRAMFILESX86]" & "\IBM\Lotus\Notes\framework/..")
        JPIProduct.LotusShortCutIconLocation = Manager.EvaluateExpression("[PROGRAMFILESX86]" & "\IBM\Lotus\Notes\framework\shared\eclipse\features\com.ibm.notes.links.feature_8.0.2.20080809-0430\icons\notes.ico")
        JPIProduct.LotusShortCutCommonProgramFolder = Manager.EvaluateExpression("[COMMONPROGRAMSX86]" & "\Lotus Applications")

        JPIProduct.IniFile = "Notes.ini"
        JPIProduct.ClientSetupFile = "LotusNotesClientSetup.txt"
        JPIProduct.BookmarkNSF = "Bookmark.NSF"
        JPIProduct.DesktopNDK = "Desktop6.ndk"

        JPIProduct.KeyFileNameKEY = "KeyfileName="
        JPIProduct.NotesPath = Manager.EvaluateExpression("[PROGRAMFILESX86]" & "\IBM\lotus\notes")
        JPIProduct.DataPath = Manager.EvaluateExpression("[PROGRAMFILESX86]" & "\IBM\lotus\notes\data")
        JPIProduct.JPIExecutionLine = Manager.EvaluateExpression("[PROGRAMFILESX86]" & "\IBM\Lotus\Notes\notes.exe")

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
             "Software\Microsoft\Office\10.0\Word\Security",
             "Level",
             "1",
             "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\10.0\Excel\Security",
        "Level",
        "1",
        "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\11.0\Word\Security",
        "Level",
        "1",
        "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\11.0\Excel\Security",
        "Level",
        "1",
        "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\12.0\Word\Security",
        "VBAWarnings",
        "1",
        "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\12.0\Excel\Security",
        "VBAWarnings",
        "1",
        "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\14.0\Word\Security",
        "VBAWarnings",
        "1",
        "REG_DWORD"))

        JPIProduct.RegKeys.Add(New Manager.RegistryKey("HKEY_CURRENT_USER",
        "Software\Microsoft\Office\14.0\Excel\Security",
        "VBAWarnings",
        "1",
        "REG_DWORD"))

        JPIProduct.FoldersToElevate.Add("C:\Program Files (x86)\IBM\lotus\notes")
        JPIProduct.FoldersToElevate.Add("C:\ProgramData\JPI\Projects")
        ''  JPIProduct.FoldersToElevate.Add("C:\Program Files\Bentley")
        '   JPIProduct.FoldersToElevate.Add("c:\JPI")
        '   JPIProduct.FoldersToElevate.Add("c:\back")
        '   JPIProduct.FoldersToElevate.Add("c:\tempo")
        '   JPIProduct.FoldersToElevate.Add("c:\tempo\ustation")
        ''  JPIProduct.FoldersToElevate.Add("C:\Program Files\Autodesk\AutoCAD 2012 – English")

        JPIProduct.FoldersToCreate.Add("C:\JPI")
        ' JPIProduct.FoldersToCreate.Add("C:\Back")
        JPIProduct.FoldersToCreate.Add("C:\Tempo")
        JPIProduct.FoldersToCreate.Add("C:\Tempo\ustation")
        JPIProduct.FoldersToCreate.Add("C:\ProgramData\JPI\Projects")

        JPIProduct.ProcessesToKill.Add("admin.exe")
        JPIProduct.ProcessesToKill.Add("designer.exe")
        JPIProduct.ProcessesToKill.Add("eclipse.exe")
        JPIProduct.ProcessesToKill.Add("nevent.exe")
        JPIProduct.ProcessesToKill.Add("notes.exe")
        JPIProduct.ProcessesToKill.Add("nlnotes.exe")
        JPIProduct.ProcessesToKill.Add("notes2.exe")
        JPIProduct.ProcessesToKill.Add("notes2w.exe")
        JPIProduct.ProcessesToKill.Add("nnotesmm.exe")
        JPIProduct.ProcessesToKill.Add("ntaskldr.exe")
        JPIProduct.ProcessesToKill.Add("nsd.exe")
        JPIProduct.ProcessesToKill.Add("nsenddiag.exe")
        JPIProduct.ProcessesToKill.Add("nxpcdmn.exe")

        JPIProduct.CriticalFiles.Add("C:\ProgramData\JPI\Apps\ApplicationLauncher\Applications.ini")
        JPIProduct.CriticalFiles.Add("C:\Program Files (x86)\IBM\lotus\notes\Notes.ini")
        JPIProduct.CriticalFiles.Add("C:\Program Files (x86)\IBM\lotus\notes\Data\LotusNotesClientSetup.txt")
        JPIProduct.CriticalFiles.Add("C:\Program Files (x86)\IBM\lotus\notes\Data\Bookmark.NSF")
        JPIProduct.CriticalFiles.Add("C:\Program Files (x86)\IBM\lotus\notes\Data\Desktop6.ndk")

        Return JPIProduct

    End Function

End Module
