﻿
Partial Public Class Manager

    ''' <summary>
    ''' A system variable configuration object for AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class RegistryKey

        ''' <summary>
        ''' Default construction
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()

        End Sub

        Public Sub New(ByVal RegArea As String, ByVal RegHive As String, ByVal RegKeyName As String, ByVal Regvalue As String, ByVal RegType As String, Optional ByVal IfFIleExists As String = "")

            '' save to me
            Me.RegArea = RegArea
            Me.RegHive = RegHive
            Me.RegKeyName = RegKeyName
            Me.Regvalue = Regvalue
            Me.RegType = RegType
            Me.IfFileExists = IfFIleExists

        End Sub

        ''' <summary>
        ''' Registry area to start 
        ''' Example: HKLM
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RegArea As String

        ''' <summary>
        ''' Registry hive location without the key
        ''' Example: Software\Jacobs\BlockFinder
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RegHive As String

        ''' <summary>
        ''' Key to use
        ''' Example: ProductName
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RegKeyName As String

        ''' <summary>
        ''' The value to set the key to as a string
        ''' Example: 213
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Regvalue As String

        ''' <summary>
        ''' The Registry type
        ''' Example: REG_DWORD
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property RegType As String

        Public Property IfFileExists As String

    End Class

End Class
