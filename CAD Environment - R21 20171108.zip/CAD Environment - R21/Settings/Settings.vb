﻿Imports Jacobs.Common.Core
Imports System.Windows.Forms
Imports Jacobs.Common.Settings

''' <summary>
''' Core configurations object
''' </summary>
''' <remarks></remarks>
Public Class Settings

    ''' <summary>
    ''' Default construction
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New()

        ' Replaces with C:\Users\[USERNAME]\AppData\Roaming
        ' Good location for user specific data which is not PC dependent but you would like to replicate when using roaming profiles – if data is too big it may be better to use the USERAPPDATALOCAL area
        Common.Settings.Manager.Register("USERAPPDATAROAMING", System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData))

        ' Replaces with C:\Users\[USERNAME]\AppData\Local
        ' Good location for user specific data which is PC dependent but will not be replicated
        Common.Settings.Manager.Register("USERAPPDATALOCAL", System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData))

        ' Returns C:\ProgramData\Microsoft\Windows\Start Menu\Programs
        Common.Settings.Manager.Register("COMMONPROGRAMS", System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonPrograms))

        'C:\ProgramData
        ' Good location for application data that needs to be protected from the use and accessed by all in a read only fashion… Blocks content etc
        Common.Settings.Manager.Register("COMMONAPPDATAFOLDER", My.Computer.FileSystem.GetDirectoryInfo(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonApplicationData)).FullName)

        ' Replaces with C:\Users\{USERNAME}\AppData\Local\Temp
        ' Good location for Log files – and temporary files that may be required and discarded
        Common.Settings.Manager.Register("TEMP", System.Environment.GetEnvironmentVariable("TMP"))

        'C:\Program Files
        ' Location for 64 bit application program files, user protected
        Common.Settings.Manager.Register("PROGRAMFILES", System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles))

        'C:\Program Files (x86)
        ' Location for old 32 bit application program files, user protected – sometimes we need to interact with older 32 bit apps
        Common.Settings.Manager.Register("PROGRAMFILESX86", System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFilesX86))

        'C:\Users
        ' Users area equivalent to the old D:\Documents and Settings folder – don’t really know why I have this one here… I think we may have a process to reset AutoCAD for all users on the PC…
        Common.Settings.Manager.Register("DOCUMENTSANDSETTINGS", System.IO.Directory.GetParent(System.IO.Directory.GetParent(My.Computer.FileSystem.SpecialDirectories.Desktop).FullName).FullName)

        'C:\Users\[USERNAME]\My Documents
        Common.Settings.Manager.Register("MYDOCUMENTS", System.IO.Directory.GetParent(My.Computer.FileSystem.SpecialDirectories.MyDocuments).FullName)

        'C:\Users\[USERNAME]\My Documents
        Common.Settings.Manager.Register("USERNAME", System.Environment.UserName)

        ' Computer Asset Number - from system variable - AU-N03631
        Common.Settings.Manager.Register("ASSETNUMBER", My.Computer.Name)

        'Region
        Common.Settings.Manager.Register("REGION", WorkOutRegion)

        'JPILoginName
        Common.Settings.Manager.Register("JPILOGINNAME", WorkOutJPILoginName)

        'DFSSHARE Replaces with the UNC name of the DFS Share
        Common.Settings.Manager.Register("DFSSHARE", WorkOutDFSShare)

        'C:\Users\Public
        ' Good place for users to share documents on a PC – probably not an area we would use unless we were doing some kind of etransmit or export or something like that… 
        Common.Settings.Manager.Register("COMMON", My.Computer.FileSystem.GetDirectoryInfo(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments)).Parent.FullName)

        'Jacobs 
        Common.Settings.Manager.Register("MANUFACTURER", "Jacobs")

        'Jacobs AutoCAD Environmnet R21
        Common.Settings.Manager.Register("AEPRODUCTNAME", "Jacobs AutoCAD Environment R21")

        'AutoCAD 2017
        Common.Settings.Manager.Register("SHAREDACADNAME", WorkOutSharedAcadName("R20.0"))

        'Autodesk\ApplicationPlugins
        Common.Settings.Manager.Register("APPLICATIONPLUGINS", "Autodesk\ApplicationPlugins")

        'C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle
        Common.Settings.Manager.Register("BUNDLE", "C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle")

        'C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle\Contents
        Common.Settings.Manager.Register("BUNDLECONTENTS", "C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle\Contents")

        'C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle\Contents\Userdatacache
        Common.Settings.Manager.Register("USERDATACACHE", "C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle\Contents\UserDataCache")

        Common.Settings.Manager.Register("AD-SITE", Environment.GetADSite)

        Common.Settings.Manager.Register("NETWORKCADCFG", WorkOutNetworkCADCFG("R20.0"))

    End Sub

    Public Sub MergeProductSettings(ByVal filename As String)

        '' Override with use Settings if the user has changed anything
        Try
            If System.IO.File.Exists(filename) Then
                XML.Merge(Me, filename)
            End If
        Catch ex As Exception
            '            Jacobs.Common.Settings.Settings.Manager.AE.Name
            GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , logName)

        End Try

    End Sub

    ''' <summary>
    ''' Our single reference to a configuration
    ''' </summary>
    ''' <remarks></remarks>
    Protected Shared _Core As Settings

    ''' <summary>
    ''' Get access to central/core configuration
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared ReadOnly Property Manager As Settings

        Get

            Dim GlobalSettingsFile As String = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\Configuration.xml"
            Dim UserSettingFileName As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData).CombinePath("Jacobs\Jacobs AutoCAD Environmnet R21\Settings\Configuration.xml")

            '' The master configuration XML object now moved to C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings, If not present create a fresh one
            If System.IO.File.Exists(GlobalSettingsFile) = False Then

                ' First time run create with defaults if not present
                Common.Settings.Manager.Evaluate = False
                WriteXML(GlobalSettingsFile)
                Common.Settings.Manager.Evaluate = True

            End If

            '' pick up the most important configuration base on company business rules
            If _Core Is Nothing Then

                ' Get default system values - first time use etc
                _Core = Common.Settings.Manager.Read(Of Settings)(GlobalSettingsFile)

            End If

            '' must evaluate from now on
            Common.Settings.Manager.Evaluate = True

            Return _Core

        End Get

    End Property

    ''' <summary>
    ''' A list of DFS products
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DFSManager As New Manager.DFSManagerProduct


    ''' <summary>
    ''' Our main AE application Settings
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property AEs As New List(Of Common.Settings.Manager.AEProduct)

    ''' <summary>
    ''' A list of AutoCAD products
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property AutoCADs As New List(Of Common.Settings.Manager.AutoCADProduct)

    '''' <summary>
    '''' A list of micro station products
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Property Microstations As New List(Of Common.Settings.Manager.MicrostationProduct)

    '''' <summary>
    '''' A list of Revit products
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    '   Public Property Revits As New List(Of Common.Settings.Manager.RevitProduct)

    '''' <summary>
    '''' A list of Navisworks products
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Property Navisworks As New List(Of Common.Settings.Manager.NavisworkProduct)

    '''' <summary>
    '''' A list of Inventor products
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Property Inventors As New List(Of Common.Settings.Manager.InventorProduct)


    ''' <summary>
    ''' Our current AE (Jacobs AutoCAD Environment R21) running
    ''' </summary>
    ''' <remarks></remarks>
    Private _CurrentAE As Common.Settings.Manager.AEProduct

    ''' <summary>
    ''' Current JPI product determined at runtime
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property JPI As Common.Settings.Manager.JPIProduct


    ''' <summary>
    ''' Current AutoCAD determined at runtime
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property AE As Common.Settings.Manager.AEProduct
        Get
            Return _CurrentAE
        End Get
        Set(ByVal value As Common.Settings.Manager.AEProduct)
            '' save new current CE
            _CurrentAE = value
        End Set
    End Property

    ''' <summary>
    ''' Our current AutoCAD
    ''' </summary>
    ''' <remarks></remarks>
    Private _CurrentAutoCAD As Common.Settings.Manager.AutoCADProduct

    ''' <summary>
    ''' Current AutoCAD determined at runtime
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property AutoCAD As Common.Settings.Manager.AutoCADProduct
        Get
            Return _CurrentAutoCAD
        End Get
        Set(ByVal value As Common.Settings.Manager.AutoCADProduct)

            '' save current
            _CurrentAutoCAD = value
            If _CurrentAutoCAD IsNot Nothing Then
                '' register 
                Common.Settings.Manager.Register("PRODUCTNAME", _CurrentAutoCAD.Name)
                Common.Settings.Manager.Register("PRODUCTVERSION", _CurrentAutoCAD.Version)
                Common.Settings.Manager.Register("PRODUCTINSTALLPATH", _CurrentAutoCAD.Path)
                Common.Settings.Manager.Register("PRODUCTREGISTRYKEY", _CurrentAutoCAD.RegKey)
                Common.Settings.Manager.Register("PRODUCTREGISTRYKEYNAME", _CurrentAutoCAD.RegKeyname)
            End If

        End Set
    End Property

    '''' <summary>
    '''' Current Navisworks product determined at runtime
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Property Naviswork As Common.Settings.Manager.NavisworkProduct

    Private _AssetNumber As String = "[ASSETNUMBER]"
    Public Property AssetNumber As String
        Get
            Return Common.Settings.Manager.EvaluateExpression(_AssetNumber)
        End Get
        Set(ByVal value As String)
            _AssetNumber = value
        End Set
    End Property

    'Public Property UserName As String
    Private _UserName As String = "[USERNAME]"
    Public Property UserName As String
        Get
            Return Common.Settings.Manager.EvaluateExpression(_UserName)
        End Get
        Set(ByVal value As String)
            _UserName = value
        End Set
    End Property

    Private _Region As String = "[REGION]"
    Public Property Region As String
        Get
            Return Common.Settings.Manager.EvaluateExpression(_Region)
        End Get
        Set(ByVal value As String)
            _Region = value
        End Set
    End Property

    Private _JPILoginName As String = "[JPILOGINNAME]"
    Public Property JPILoginName As String
        Get
            Return Common.Settings.Manager.EvaluateExpression(_JPILoginName)
        End Get
        Set(ByVal value As String)
            _JPILoginName = value
        End Set
    End Property

    '''' <summary>
    '''' Current Microstation determined at runtime
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Property Microstation As Common.Settings.Manager.MicrostationProduct

    '''' <summary>
    '''' Current Revit product determined at runtime
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Public Property Revit As Manager.RevitProduct

    Public Shared Sub PartialSettingsSaveAE(ByVal ae As Manager.AEProduct)

        '' main object to save
        Dim Settings As New Common.Settings.Settings()

        '' clean it out
        Properties.SetProperties(Settings, Nothing)

        '' add a one item list
        Settings.AEs = New List(Of Common.Settings.Manager.AEProduct)
        Settings.AEs.Add(ae)

        '' write startup.xml user area here
        'Disabled by Steven Houghton 21/09/17
        'Dim Ok As Boolean = Common.Settings.Manager.Save(Settings.Manager.AE.UserSettingsFileName, True, Settings)

        'If Ok = True Then
        '' merge our snippet into core
        '  Manager.MergeProductSettings(Settings.Manager.AutoCAD.UserSettingsFolder.ToString.CombinePath(Settings.Manager.AE.UserSettingsFileName))
        'Manager.MergeProductSettings(Settings.Manager.AE.UserSettingsFileName)
        'End If

    End Sub

    Public Shared Sub PartialSettingsSaveAcad(ByVal Acad As Manager.AutoCADProduct)

        '' main object to save
        Dim Settings As New Common.Settings.Settings

        '' clean it out
        Properties.SetProperties(Settings, Nothing)

        '' add a one item list
        Settings.AutoCADs = New List(Of Manager.AutoCADProduct)
        Settings.AutoCADs.Add(Acad)

        '' write startup.xml user area here for the User Options TAB Settings
        Dim Ok As Boolean = Common.Settings.Manager.Save(Settings.Manager.AutoCAD.UserSettingsFileName, True, Settings)

        If Ok = True Then
            '' merge our snippet into core
            Manager.MergeProductSettings(Settings.Manager.AutoCAD.UserSettingsFileName)
        End If

    End Sub
    ''' <summary>
    ''' Check to see if the logged in user is a nominated Template Builder - by reading the ConfigBuilder.txt file
    ''' And check if they have enough permissions to write to the Program Files folder allowing them to modify Administration Files
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Function IsUserValidSystemAdministrator() As Boolean

        Dim Result As Boolean = False

        Try

            If System.IO.File.Exists(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.SystemAdministratorsFileName)) Then

                Dim aFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.SystemAdministratorsFileName))

                For Each Str As String In aFileRead
                    '' Get logged in user name and check if they are allowed to create configs.
                    If Str.ToUpper = Common.Settings.Manager.EvaluateExpression(Manager.UserName).ToUpper Then
                        Result = True
                        Exit For
                    End If
                Next

            Else
                GeneralMessageBox("Error Missing File:" & Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.SystemAdministratorsFileName), System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , logName)
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", "")
        End Try

        Return Result

    End Function

End Class
