﻿
Partial Public Class Manager

    ''' <summary>
    ''' A system variable configuration object for AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class SystemVariable

        Private _p1 As String
        Private _p2 As String
        Private _p3 As Boolean
        Private _p4 As String

        ''' <summary>
        ''' Default construction
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()

        End Sub

        ''' <summary>
        ''' Initialise with name, value and persistence
        ''' </summary>
        ''' <param name="name"></param>
        ''' <param name="value"></param>
        ''' <param name="persistent"></param>
        ''' <remarks></remarks>
        Public Sub New(name As String, value As String, persistent As Boolean, type As String)

            '' save to me
            Me.Name = name
            Me.Value = value
            Me.Persistent = persistent
            Me.Type = type
        End Sub

        ''' <summary>
        ''' Name of the system variable
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Name As String

        ''' <summary>
        ''' The value of the system variable
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Value As String

        ''' <summary>
        ''' Should this variable persist
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Type As String

        ''' <summary>
        ''' Should this variable persist
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Persistent As Boolean

    End Class

End Class
