﻿Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings

Partial Public Class Manager

    ''' <summary>
    ''' Base object for all AutoCAD products
    ''' </summary>
    ''' <remarks></remarks>
    Public Class AutoCADProduct
        Inherits Manager.Product

        Public Sub New()

        End Sub

        ' Examples of core product values
        ' Name = "AutoCAD 2017"
        ' Version = "21.0"
        ' Path = "C:\Program Files\Autodesk\AutoCAD 2017"       ' Was InstallPath
        ' RegKey = "Software\Autodesk\AutoCAD\R21.0\Acad-0001:409"
        ' RegKeyName = "ProductName"

        Public ReadOnly Property AutoCADExeFileNamePathed As String
            Get
                Return Manager.EvaluateExpression(Me.Path.CombinePath(Me.Name, ".exe"))
            End Get
        End Property

        Public ReadOnly Property AutoCADLaunchString As String
            Get
                Return Manager.EvaluateExpression("""" & Me.Path & "\Acad.exe" & """")
            End Get
        End Property

        Public Property RegistryKeysToAdd As New List(Of Manager.RegistryKey)
        Public Property RegistryKeysToRemove As New List(Of Manager.RegistryKey)
        Public Property SystemVariables As New List(Of Manager.SystemVariable)
        Public Property EnvironmentVariables As New List(Of Manager.SystemVariable)
        Public Property AdditionalMenus As New List(Of Manager.AdditionalMenu)

        Public Property OfficeMenuName As String ' = "JacobsOffice"

        Public Property TopOfScript As String ' = "(princ)"
        Public Property BottomOfScript As String

        Private _FileDefaultTemplate As String
        Public Property FileDefaultTemplate As String
            Get
                Return Manager.EvaluateExpression(_FileDefaultTemplate)
            End Get
            Set(ByVal value As String)
                _FileDefaultTemplate = value
            End Set
        End Property

        Private _FirstTimeUse As String ' = "[PRODUCTREGISTRYHIVE]" & "\" & "[MANUFACTURER]" & "\" & "[PRODUCTNAME]"
        Public Property FirstTimeUse As String
            Get
                Return Manager.EvaluateExpression(_FirstTimeUse)
            End Get
            Set(ByVal value As String)
                _FirstTimeUse = value
            End Set
        End Property

        Public Property CheckKeyForProductExist As String ' = "ProductCode"

        Public Property CheckKeyForProductRun As String ' = "LocalRootFolder"

        Public Property Profilename As String ' = "<<Unnamed Profile>>"

        Public Property PartialMenuName As String ' = "<<None>>"

        Public Property AllowSaveSettings As String ' = "True"

        Private _ToolPalettePath As String ' = "[COMMON]" & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]" & "\ToolPalettes"
        Public Property ToolPalettePath As String
            Get
                Return Manager.EvaluateExpression(_ToolPalettePath)
            End Get
            Set(ByVal value As String)
                _ToolPalettePath = value
            End Set
        End Property

        Private _WorkingFolder As String
        Public Property WorkingFolder As String
            Get
                Return Manager.EvaluateExpression(_WorkingFolder)
            End Get
            Set(ByVal value As String)
                _WorkingFolder = value
            End Set
        End Property

        Private _WorkingSupportFolder As String
        Public Property WorkingSupportFolder As String
            Get
                Return Manager.EvaluateExpression(_WorkingFolder.CombinePath("Support"))
            End Get
            Set(ByVal value As String)
                _WorkingSupportFolder = value
            End Set
        End Property

        ' This used to be \Fonts but in 2017 the Fonts folder is not present may want to use Support folder TO INVESTIGATE
        Private _WorkingFontsFolder As String
        Public Property WorkingFontsFolder As String
            Get
                Return Manager.EvaluateExpression(_WorkingFontsFolder)
            End Get
            Set(ByVal value As String)
                _WorkingFontsFolder = value
            End Set
        End Property

        Private _WorkingPlotStylesFolder As String
        Public Property WorkingPlotStylesFolder As String
            Get
                Return Manager.EvaluateExpression(_WorkingFolder.CombinePath("Plot Styles"))
            End Get
            Set(ByVal value As String)
                _WorkingPlotStylesFolder = value
            End Set
        End Property

        Private _ContentWizardLaunchSwitch As String = "/b ""[WORKDIRECTORY]\CFG.SCR"""
        Public Property ContentWizardLaunchSwitch As String
            Get
                Return Manager.EvaluateExpression(_ContentWizardLaunchSwitch)
            End Get
            Set(ByVal value As String)
                _ContentWizardLaunchSwitch = value
            End Set
        End Property

        Private _ObjectEnablerFolder As String ' = "[PROGRAMFILES]" & "\Autodesk\Object Enablers"
        Public Property ObjectEnablerFolder As String
            Get
                Return Manager.EvaluateExpression(_ObjectEnablerFolder)
            End Get
            Set(ByVal value As String)
                _ObjectEnablerFolder = value
            End Set
        End Property

        Private _StartUpLogFile As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments) & Manager.EvaluateExpression("\" & "[MANUFACTURER]" & "\" & "[PRODUCTNAME]" & "\" & "[MANUFACTURER]" & ".AutoCAD.StartUp-" & "[USERNAME]" & "-" & "[ASSETNUMBER]" & ".log")
        Public Property StartUpLogFile As String
            Get
                Return Manager.EvaluateExpression(_StartUpLogFile)
            End Get
            Set(ByVal value As String)
                _StartUpLogFile = value
            End Set
        End Property

        '' Only kept because the old Settings.DLL still requires these.
        '' The Settings.DLL is used in Products like Navisworks, Inventor, Revit and Project Wise.
        '' The new AutoCAD.Settings.dll file uses the same Configuration.xml file as the legacy files
        Private _JacobsStartUpLogFile As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments) & Manager.EvaluateExpression("\" & "[MANUFACTURER]" & "\" & "[PRODUCTNAME]" & "\" & "[MANUFACTURER]" & ".AutoCAD.StartUp.log")
        Public Property JacobsStartUpLogFile As String
            Get
                Return Manager.EvaluateExpression(_JacobsStartUpLogFile)
            End Get
            Set(ByVal value As String)
                _JacobsStartUpLogFile = value
            End Set
        End Property

        Private _CachedFontsFolder As String
        Public Property CachedFontsFolder As String
            Get
                Return Manager.EvaluateExpression(_CachedFontsFolder)
            End Get
            Set(ByVal value As String)
                _CachedFontsFolder = value
            End Set
        End Property

        Private _CachedSettingsFolder As String
        Public Property CachedSettingsFolder As String
            Get
                Return Manager.EvaluateExpression(_CachedSettingsFolder)
            End Get
            Set(ByVal value As String)
                _CachedSettingsFolder = value
            End Set
        End Property

        Private _CachedJacobsCADCUIFiles As String
        Public Property CachedJacobsCADCUIFiles As String
            Get
                Return Manager.EvaluateExpression(_CachedJacobsCADCUIFiles)
            End Get
            Set(ByVal value As String)
                _CachedJacobsCADCUIFiles = value
            End Set
        End Property

        Private _CachedJacobsCUIFiles As String
        Public Property CachedJacobsCUIFiles As String
            Get
                Return Manager.EvaluateExpression(_CachedJacobsCUIFiles)
            End Get
            Set(ByVal value As String)
                _CachedJacobsCUIFiles = value
            End Set
        End Property
        Public Property IncompatibleApps As String

        Public Property ThirdPartyAppProfileExclusion As String

        Private _RegistryLocationProf As String
        Public Property RegistryLocationProf As String
            Get
                Return Manager.EvaluateExpression(_RegistryLocationProf)
            End Get
            Set(ByVal value As String)
                _RegistryLocationProf = value
            End Set
        End Property

        Public UseOfficeNetworkFonts As Boolean = True

        Public Property UseOfficeNetworkMenu As Boolean = True

        Private _NetworkFontsFolder As String
        Public Property NetworkFontsFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkFontsFolder)
            End Get
            Set(ByVal value As String)
                _NetworkFontsFolder = value
            End Set
        End Property

        Public Property NetworkSupportShortcutName As String

        Public Property NetworkPMPShortcutName As String

        Public Property NetworkPlotStylesShortcutName As String

        Public Property NetworkPC3ShortcutName As String

        Public Property NetworkTemplateShortcutName As String

        Public Property NetworkBlockFinderShortcutName As String

        Public Property CreateSupportShortCut As Boolean = True

        Public Property CreateTemplateShortCut As Boolean = True

        Public Property CreatePlotStyleShortCut As Boolean = True

        Public Property CreatePC3ShortCut As Boolean = True

        Public Property CreatePMPShortCut As Boolean = True

        Public Property CreateBlockFinderShortCut As Boolean = True

        Private _NetworkSupportFolder As String
        Public Property NetworkSupportFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkSupportFolder)
            End Get
            Set(ByVal value As String)
                _NetworkSupportFolder = value
            End Set
        End Property

        Private _NetworkMenuFolder As String
        Public Property NetworkMenuFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkMenuFolder)
            End Get
            Set(ByVal value As String)
                _NetworkMenuFolder = value
            End Set
        End Property

        Private _NetworkTemplateFolder As String
        Public Property NetworkTemplateFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkTemplateFolder)
            End Get
            Set(ByVal value As String)
                _NetworkTemplateFolder = value
            End Set
        End Property

        Private _NetworkPlotStyleFolder As String
        Public Property NetworkPlotStyleFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkPlotStyleFolder)
            End Get
            Set(ByVal value As String)
                _NetworkPlotStyleFolder = value
            End Set
        End Property

        Private _UserSettingsFolder As String
        Public Property UserSettingsFolder As String
            Get
                'Return Manager.EvaluateExpression(Me.UserSettingsFolder.CombinePath(Me.Name & ".XML"))
                Return Manager.EvaluateExpression(_UserSettingsFolder) '(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData) & "\" & "[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]\" & Me.Name & ".XML")
            End Get
            Set(ByVal value As String)
                _UserSettingsFolder = value
            End Set
        End Property

        Private _UserSettingsFileName As String
        Public Property UserSettingsFileName As String
            Get
                Return Manager.EvaluateExpression(_UserSettingsFileName)
            End Get
            Set(ByVal value As String)
                _UserSettingsFileName = value
            End Set
        End Property

        Private _NetworkPC3Folder As String
        Public Property NetworkPC3Folder As String
            Get
                Return Manager.EvaluateExpression(_NetworkPC3Folder)
            End Get
            Set(ByVal value As String)
                _NetworkPC3Folder = value
            End Set
        End Property

        Private _NetworkPMPFolder As String
        Public Property NetworkPMPFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkPMPFolder)
            End Get
            Set(ByVal value As String)
                _NetworkPMPFolder = value
            End Set
        End Property

        Private _NetworkBlockFinderFolder As String
        Public Property NetworkBlockFinderFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkBlockFinderFolder)
            End Get
            Set(ByVal value As String)
                _NetworkBlockFinderFolder = value
            End Set
        End Property

        Private _CustomDictionary As String
        Public Property CustomDictionary As String
            Get
                Return Manager.EvaluateExpression(_CustomDictionary)
            End Get
            Set(ByVal value As String)
                _CustomDictionary = value
            End Set
        End Property

        Public Property UseOfficeCustomDictionary As Boolean = True

        Public Property RestoreAcadCUI As Boolean = False

        Public Property ManageCUIs As Boolean = True

        Public Property MillimetresOnly As Boolean = False

        Public Property MillimetresAndMetres As Boolean = True

        Private _NetworkDictionaryFolder As String
        Public Property NetworkDictionaryFolder As String
            Get
                Return Manager.EvaluateExpression(_NetworkDictionaryFolder)
            End Get
            Set(ByVal value As String)
                _NetworkDictionaryFolder = value
            End Set
        End Property

        Public Property ResetScaleListOnDrawingActivate As Boolean = True

        Private Property _OnCompletionPrompt As String
        Public Property OnCompletionPrompt As String
            Get
                Return Manager.EvaluateExpression(_OnCompletionPrompt)
            End Get
            Set(ByVal value As String)
                _OnCompletionPrompt = value
            End Set
        End Property

        Private _ShortName As String = "[SHORTNAME]"
        Public Property ShortName As String
            Get
                Return Manager.EvaluateExpression(_ShortName)
            End Get
            Set(ByVal value As String)
                _ShortName = value
            End Set
        End Property

        Private _SharedAcadName As String ' = "[SHAREDACADNAME]"
        Public Property SharedAcadName As String
            Get
                Return Manager.EvaluateExpression(_SharedAcadName)
            End Get
            Set(ByVal value As String)
                _SharedAcadName = value
            End Set
        End Property

        Private _UserLocalTemplateFolder As String
        Public Property UserLocalTemplateFolder As String
            Get
                Return Manager.EvaluateExpression(_UserLocalTemplateFolder)
            End Get
            Set(ByVal value As String)
                _UserLocalTemplateFolder = value
            End Set
        End Property

        Private _UserLocalSupportFolder As String
        Public Property UserLocalSupportFolder As String
            Get
                Return Manager.EvaluateExpression(_UserLocalSupportFolder)
            End Get
            Set(ByVal value As String)
                _UserLocalSupportFolder = value
            End Set
        End Property

        Private _UserRoamingPlottersFolder As String
        Public Property UserRoamingPlottersFolder As String
            Get
                Return Manager.EvaluateExpression(_UserRoamingPlottersFolder)
            End Get
            Set(ByVal value As String)
                _UserRoamingPlottersFolder = value
            End Set
        End Property

        Private _UserRoamingPlotStylesFolder As String
        Public Property UserRoamingPlotStylesFolder As String
            Get
                Return Manager.EvaluateExpression(_UserRoamingPlotStylesFolder)
            End Get
            Set(ByVal value As String)
                _UserRoamingPlotStylesFolder = value
            End Set
        End Property

        Private _UserRoamingPMPFilesFolder As String
        Public Property UserRoamingPMPFilesFolder As String
            Get
                Return Manager.EvaluateExpression(_UserRoamingPMPFilesFolder)
            End Get
            Set(ByVal value As String)
                _UserRoamingPMPFilesFolder = value
            End Set
        End Property

        Private _UserRoamingSupportFolder As String
        Public Property UserRoamingSupportFolder As String
            Get
                Return Manager.EvaluateExpression(_UserRoamingSupportFolder)
            End Get
            Set(ByVal value As String)
                _UserRoamingSupportFolder = value
            End Set
        End Property

        Public Property ExpressToolsMenuBase As String = "acetmain"

        Public Property EntCUIFileNameNoExt As String = "Acad"

        Public Property MainCUIFileNameNoExt As String = "Jacobs_Acad_Custom"

        Private _MainMenuFileNamePathed As String
        Public Property MainMenuFileNamePathed As String
            Get
                Return Manager.EvaluateExpression(Settings.Manager.AE.UserSettingsFolder.CombinePath(Me.MainCUIFileNameNoExt & ".CUIX"))
            End Get
            Set(ByVal value As String)
                _MainMenuFileNamePathed = value
            End Set
        End Property

        Private _EnterpriseMenuFileNamePathed As String
        Public Property EnterpriseMenuFileNamePathed As String
            Get
                Return Manager.EvaluateExpression(Settings.Manager.AE.UserSettingsFolder.CombinePath(Me.EntCUIFileNameNoExt & ".CUIX"))
            End Get
            Set(ByVal value As String)
                _EnterpriseMenuFileNamePathed = value
            End Set
        End Property

        Private _AEAcadWorkingRegKey As String = "Software\" & "[MANUFACTURER]" & "\" & "[PRODUCTNAME]"
        Public Property AEAcadWorkingRegKey As String
            Get
                Return Manager.EvaluateExpression(_AEAcadWorkingRegKey)
            End Get
            Set(ByVal value As String)
                _AEAcadWorkingRegKey = value
            End Set
        End Property

        Private _CEAcadWorkingRegKey As String = "Software\" & "[MANUFACTURER]" & "\" & "[PRODUCTNAME]"
        Public Property CEAcadWorkingRegKey As String
            Get
                Return Manager.EvaluateExpression(_CEAcadWorkingRegKey)
            End Get
            Set(ByVal value As String)
                _CEAcadWorkingRegKey = value
            End Set
        End Property
    End Class

End Class



