var msiOpenDatabaseModeTransact = 1;
var msiViewModifyInsert         = 1;
var msiViewModifyUpdate         = 2;
var msiViewModifyAssign         = 3;
var msiViewModifyReplace        = 4;
var msiViewModifyDelete         = 6;

if (WScript.Arguments.Length != 1)
{
	//WScript.StdErr.WriteLine("Usage: " + WScript.ScriptName + " <Product.msi>");
	WScript.echo("Usage: " + WScript.ScriptName + " <Product.msi>");
	WScript.Quit(2);
}

var filespec = WScript.Arguments(0);
var installer
var database

try
{
	installer = WScript.CreateObject("WindowsInstaller.Installer");
	database = installer.OpenDatabase(filespec, msiOpenDatabaseModeTransact);
}
catch(exception)
{
	WScript.echo("Error: Can't find file " + WScript.Arguments(0));
	WScript.Quit(6);
}

var sql;
var view;
var record;

if( database == null )
{
	WScript.echo("Null");
	WScript.Quit(5);
}

// Get the Component out of the File table
// WHERE `FileName`='COPYUS~1.VBS|CopyUserFiles.vbs'
sql = "SELECT * FROM `File`";                                    // Get the File Table
view = database.OpenView(sql);
view.Execute();

while (record = view.Fetch())
{
	var FileName = record.StringData(3);                         // The 3rd column in the File table is the file name

	var t = FileName.search("CopyUserFiles.vbs");                // Look for file named "CopyUserFiles.vbs"
	if( t > 0 )
	{
		var Component = record.StringData(2);                    // The 2nd Column of the File table has the Component we want

//        WScript.echo("Found: " +Component);

		sql = "SELECT * FROM `Feature`";                         // Get the Feature table
        var view2 = database.OpenView(sql);
		view2.Execute();
		record = view2.Fetch();
//        WScript.echo("About to add record to Feature Table");
        record.StringData(1) = "UserData";                       // Set the 1st Column (Feature) to be "UserData"
        record.IntegerData(6) = 1;                               // Set the 6th column (Level) to be 1
        record.StringData(5) = "";                            // Set the 5th column (Display) to be 1
        record.StringData(7) = "";                            // Set the 7th column (Directory) to be 1
        record.IntegerData(8) = 0;                               // Set the 8th column (Attribues) to be 0
        view2.Modify(msiViewModifyInsert, record);
//        WScript.echo("Added record to Feature Table");
        view2.Close();

		sql = "SELECT * FROM `FeatureComponents`";               // Get the FeatureComponets Table
        var view3 = database.OpenView(sql);
		view3.Execute();
		record = view3.Fetch();
//        WScript.echo("About to add record to FeatureComponents Table");
        record.StringData(1) = "UserData";                      // Set the 1st Column (Feature) to be "UserData"
        record.StringData(2) = Component;                       // Set the 2nd column (Component) to be the componet value for CopyUserFiles.vbs we got from the file table
        view3.Modify(msiViewModifyInsert, record);
//        WScript.echo("Added record to FeatureComponents Table");
        view3.Close();
        
//		if (record == null)
//		{
//			WScript.echo("Unable to find " +FileName+ " entry in File table");
//		}
//		else
//		{
//		var Feature = record.StringData(1);
//		
//		WScript.echo("Feature found in Feature table named: " +Feature);
//		
//			// Add the msidbLocatorType64bit
//			if (record.IntegerData(5) < 16)
//			{
//				record.IntegerData(5) = record.IntegerData(5) + 16;
//				view2.Modify(msiViewModifyReplace, record);
//			}		
//		}
//		//WScript.echo(record.IntegerData(5));
//		view2.Close();
	}
}

WScript.echo("Finished post build event to complete Secondary Stage Installer requirements");

view.Close();
database.Commit();