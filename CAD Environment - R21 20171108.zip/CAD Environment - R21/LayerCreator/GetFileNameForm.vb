Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities

Friend Class GetFileNameForm
    Inherits System.Windows.Forms.Form

    ' ' Dim RuleAccessors As New RuleAccessors
    Public IsInitialising As Boolean = True

    Private Sub Cancel_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub Delimeter_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Delimeter.TextChanged
        Try
            If IsInitialising Then Exit Sub
            If Delimeter.Text Like "*[<>/\"":;?*|,=']*" Then

                Acad_MessageBox("Invalid character in delimiter name" & vbCr & "The following characters are not valid in as delimeter names" & vbCr & "<>/\"":;?*|,='", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                Delimeter.Text = ""
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub OK_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OK_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub GetFileName_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            IsInitialising = True
            If ThisDrawingIsConfigured() = True Then
                WorkSpaceName.Text = RuleAccessors.GetruleValue("FULLCONFIGNAME", "Client", True) & ".XML"
                FileName.Text = RuleAccessors.GetruleValue("CONFIGLEVEL", "Client", True) & ".XML"
                FileName.Enabled = False
            End If
            IsInitialising = False
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

End Class