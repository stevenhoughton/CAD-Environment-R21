Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Friend Class LayerCreatorForm
    Inherits System.Windows.Forms.Form

#Region "Dims"


    Dim xmlDoc As MSXML2.DOMDocument
    Dim Element As MSXML2.IXMLDOMNode
    Dim NodeList As MSXML2.IXMLDOMNodeList
    Dim root As MSXML2.IXMLDOMNode
    Dim elementcode As String
    Dim subelementcode As String
    Dim subsubelementcode As String
    Dim subsubsubelementcode As String
    Public IsInitialising As Boolean = True

#End Region

    Private Sub Cancel_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub Convert_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Me.Hide()
            ThisDrawingUtilities.SendCommand("._CONVERTPSTYLES" & vbCr)
            Me.Show()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub GetFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles GetFile.Click

        If IsThisAnOldConfigName() = True Then
            GetFileOld()
        Else
            GetFileNew()
        End If

    End Sub

    Sub GetFileOld()

        Try

            Dim sSelectedFile As String
            Dim strCFGPath As String
            Dim sConfigName As String

            If ThisDrawingIsConfigured() = True Then
                If RuleAccessors.GetruleValue("TESTCONFIG").IsTrue Then
                    sConfigName = "T@" & RuleAccessors.GetruleValue("FULLCONFIGNAME")
                Else
                    sConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME")
                End If
                strCFGPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sConfigName, "Settings")
            Else
                sConfigName = ""
                strCFGPath = Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Layer Definitions")
            End If

            sSelectedFile = DocumentOpenSingleSelect(strCFGPath, "Select Layer Definition File", "Select XML File (*.xml)|*.xml", "Select File")

            strCFGPath = System.IO.Path.GetDirectoryName(sSelectedFile)

            If String.IsNullOrEmpty(sSelectedFile) = False Then
                sSelectedFile = System.IO.Path.GetFileName(sSelectedFile)
                GetXMLFile(sSelectedFile, strCFGPath)
                AlternativeFileName.Text = sSelectedFile
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub GetFileNew()
        Try

            Dim sSelectedFile As String
            Dim strCFGPath As String
            Dim sConfigName As String

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then
                sConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME")
                strCFGPath = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName, "Settings")
            Else
                sConfigName = ""
                strCFGPath = Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Layer Definitions")
            End If

            sSelectedFile = DocumentOpenSingleSelect(strCFGPath, "Select Layer Definition File", "Select XML File (*.xml)|*.xml", "Select File")

            strCFGPath = System.IO.Path.GetDirectoryName(sSelectedFile)

            If String.IsNullOrEmpty(sSelectedFile) = False Then
                sSelectedFile = System.IO.Path.GetFileName(sSelectedFile)
                GetXMLFile(sSelectedFile, strCFGPath)
                AlternativeFileName.Text = sSelectedFile
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub


    Private Sub Help_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Function MultipleItemsSelected(ByRef cBoxName As System.Windows.Forms.ListBox) As String
        Try
            Dim sEelementListBoxValue As String = ""
            Dim ctr As Integer
            Dim i As Integer

            ctr = 0
            For i = 0 To cBoxName.Items.Count - 1
                If cBoxName.GetSelected(i) = True Then
                    ctr = ctr + 1
                    sEelementListBoxValue = UserInterface.GetListBoxText(cBoxName, i)
                End If
            Next i

            If ctr = 1 Then
                MultipleItemsSelected = sEelementListBoxValue
            Else
                If ctr = 0 Then
                    MultipleItemsSelected = "Nothing Selected"
                Else
                    MultipleItemsSelected = "Multiple Selections"
                End If
            End If
        Catch ex As Exception
            MultipleItemsSelected = "Multiple Selections"
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Function


    Private Sub LayerManagerBtn_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Me.Hide()
            ThisDrawingUtilities.SendCommand("_.LAYER" & vbCr)
            Me.Show()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub


    'Private Sub LayerName_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles LayerName.TextChanged
    '    Try
    '        If IsInitialising Then Exit Sub
    '        Dim item As Object

    '        'ExistingLayersLstBox.Value = System.DBNull.Value
    '        ExistingLayersLstBox.Text = ""

    '        For Each item In ExistingLayersLstBox.Items
    '            If item.ToString Like "*" & LayerName.Text & "*" Then
    '                ExistingLayersLstBox.Text = item.ToString
    '            End If
    '        Next item

    '        If LayerName.Text = "" Then
    '            ClearValues()
    '        Else
    '            '        SetDefaultValues
    '        End If
    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try
    'End Sub


    Private Sub ElementListBoxProcess(ByRef ElementListBoxValue As String)
        Try
            SubElementListBox.Items.Clear()
            SubSubElementListBox.Items.Clear()
            SubSubSubElementListBox.Items.Clear()
            SubSubSubSubElementListBox.Items.Clear()

            root = xmlDoc.documentElement

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT")

            For Each Element In NodeList
                If Element.attributes.getNamedItem("NAME").nodeValue.ToString = ElementListBoxValue Then
                    LayerName.Text = ""
                    LayerName.Text = Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    elementcode = Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    Colour.Text = Element.attributes.getNamedItem("COLOUR").nodeValue.ToString
                    CheckLinetype((Element.attributes.getNamedItem("LINETYPE").nodeValue).ToString, Element.attributes.getNamedItem("CODE").nodeValue.ToString)
                    LineWeight.Text = FixLineWeight((Element.attributes.getNamedItem("LINEWEIGHT").nodeValue).ToString, False).ToString
                    PlotStyle.Text = Element.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString
                    Description.Text = Element.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString
                End If
            Next Element

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & ElementListBoxValue & "']/ELEMENT")

            For Each Element In NodeList
                SubElementListBox.Items.Add(Element.attributes.getNamedItem("NAME").nodeValue)
            Next Element
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LWEIGHT_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Me.Hide()
            ThisDrawingUtilities.SendCommand("._LWEIGHT" & vbCr)
            Me.Show()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub OK_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub PlotStyle_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Dim sPlotStyle As String

            sPlotStyle = GetPlotStyle()

            If sPlotStyle <> "" Then
                PlotStyle.Text = sPlotStyle
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SubElementListBoxProcess(ByRef sElementListBox As String)
        Try
            SubSubElementListBox.Items.Clear()
            SubSubSubElementListBox.Items.Clear()
            SubSubSubSubElementListBox.Items.Clear()

            root = xmlDoc.documentElement

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & MultipleItemsSelected(ElementListBox) & "']/ELEMENT")
            For Each Element In NodeList
                If Element.attributes.getNamedItem("NAME").nodeValue.ToString = sElementListBox Then
                    LayerName.Text = ""
                    LayerName.Text = elementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    subelementcode = Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    Colour.Text = Element.attributes.getNamedItem("COLOUR").nodeValue.ToString
                    CheckLinetype((Element.attributes.getNamedItem("LINETYPE").nodeValue).ToString, elementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString)
                    LineWeight.Text = CType(FixLineWeight((Element.attributes.getNamedItem("LINEWEIGHT").nodeValue).ToString, False), String)
                    PlotStyle.Text = Element.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString
                    Description.Text = Element.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString
                End If
            Next Element

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & MultipleItemsSelected(ElementListBox) & "']/ELEMENT[@NAME='" & sElementListBox & "']/ELEMENT")

            For Each Element In NodeList
                SubSubElementListBox.Items.Add(Element.attributes.getNamedItem("NAME").nodeValue)
            Next Element
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SubSubElementListBoxProcess(ByRef sElementListBox As String)
        Try
            SubSubSubElementListBox.Items.Clear()
            SubSubSubSubElementListBox.Items.Clear()

            Dim a As Object
            Dim b As String

            a = MultipleItemsSelected(ElementListBox)
            b = MultipleItemsSelected(SubElementListBox)

            root = xmlDoc.documentElement

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & a.ToString & "']/ELEMENT[@NAME='" & b & "']/ELEMENT")

            For Each Element In NodeList

                If Element.attributes.getNamedItem("NAME").nodeValue.ToString = sElementListBox Then
                    LayerName.Text = ""
                    LayerName.Text = elementcode & Delimeter.Text & subelementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    subsubelementcode = Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    Colour.Text = Element.attributes.getNamedItem("COLOUR").nodeValue.ToString
                    CheckLinetype((Element.attributes.getNamedItem("LINETYPE").nodeValue).ToString, elementcode & Delimeter.Text & subelementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString)
                    PlotStyle.Text = Element.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString
                    LineWeight.Text = FixLineWeight((Element.attributes.getNamedItem("LINEWEIGHT").nodeValue).ToString, False).ToString
                    Description.Text = Element.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString
                End If

            Next Element

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & MultipleItemsSelected(ElementListBox) & "']/ELEMENT[@NAME='" & MultipleItemsSelected(SubElementListBox) & "']/ELEMENT[@NAME='" & sElementListBox & "']/ELEMENT")

            For Each Element In NodeList
                SubSubSubElementListBox.Items.Add(Element.attributes.getNamedItem("NAME").nodeValue)
            Next Element
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub SubSubSubElementListBoxProcess(ByRef sElementListBox As String)
        Try
            SubSubSubSubElementListBox.Items.Clear()

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & MultipleItemsSelected(ElementListBox) & "']/ELEMENT[@NAME='" & MultipleItemsSelected(SubElementListBox) & "']/ELEMENT[@NAME='" & MultipleItemsSelected(SubSubElementListBox) & "']/ELEMENT")

            For Each Element In NodeList

                If sElementListBox = Element.attributes.getNamedItem("NAME").nodeValue.ToString Then

                    LayerName.Text = ""
                    LayerName.Text = elementcode & Delimeter.Text & subelementcode & Delimeter.Text & subsubelementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    subsubsubelementcode = Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    Colour.Text = Element.attributes.getNamedItem("COLOUR").nodeValue.ToString
                    CheckLinetype((Element.attributes.getNamedItem("LINETYPE").nodeValue).ToString, elementcode & Delimeter.Text & subelementcode & Delimeter.Text & subsubelementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString)
                    PlotStyle.Text = Element.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString
                    LineWeight.Text = FixLineWeight((Element.attributes.getNamedItem("LINEWEIGHT").nodeValue).ToString, False).ToString
                    Description.Text = Element.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString
                End If

            Next Element

            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & MultipleItemsSelected(ElementListBox) & "']/ELEMENT[@NAME='" & MultipleItemsSelected(SubElementListBox) & "']/ELEMENT[@NAME='" & MultipleItemsSelected(SubSubElementListBox) & "']/ELEMENT[@NAME='" & sElementListBox & "']/ELEMENT")

            For Each Element In NodeList
                SubSubSubSubElementListBox.Items.Add(Element.attributes.getNamedItem("NAME").nodeValue)
            Next Element
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SubSubSubSubElementListBoxProcess(ByRef sElementListBox As String)
        Try
            NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT[@NAME='" & sElementListBox & "']/ELEMENT[@NAME='" & SubElementListBox.Text & "']/ELEMENT[@NAME='" & SubSubElementListBox.Text & "']/ELEMENT[@NAME='" & SubSubSubElementListBox.Text & "']/ELEMENT")

            For Each Element In NodeList

                If SubSubSubSubElementListBox.Text = Element.attributes.getNamedItem("NAME").nodeValue.ToString Then
                    LayerName.Text = ""
                    LayerName.Text = elementcode & Delimeter.Text & subelementcode & Delimeter.Text & subsubelementcode & Delimeter.Text & subsubsubelementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString
                    Colour.Text = Element.attributes.getNamedItem("COLOUR").nodeValue.ToString
                    CheckLinetype((Element.attributes.getNamedItem("LINETYPE").nodeValue).ToString, elementcode & Delimeter.Text & subelementcode & Delimeter.Text & subsubelementcode & Delimeter.Text & subsubsubelementcode & Delimeter.Text & Element.attributes.getNamedItem("CODE").nodeValue.ToString)
                    PlotStyle.Text = Element.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString
                    LineWeight.Text = FixLineWeight((Element.attributes.getNamedItem("LINEWEIGHT").nodeValue).ToString, False).ToString
                    Description.Text = Element.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString
                End If
            Next Element
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LayerCreatorFrm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            IsInitialising = True

            If CInt(ThisDrawingUtilities.GetVariable("LWUNITS")) = 0 Then
                LineWeight_Label.Text = "Lineweight in Inches: "
            Else
                LineWeight_Label.Text = "Lineweight in MM: "
            End If

            If Colour.Text <> "" Then
                If ThisDrawingUtilities.GetVariable("CPLOTSTYLE").ToString = "ByColor" Then
                    PlotStyle.Text = "Color_" & FixColour(Colour.Text)
                    PlotStyle.Enabled = False
                    'PlotStyle_Button.Enabled = False
                    PlotStyle_label.Enabled = True
                    PlotStyle_label.Text = "Colour PlotStyle: "
                Else
                    PlotStyle_label.Text = "Named PlotStyle: "
                    PlotStyle.Text = "Normal"
                    PlotStyle.Enabled = True
                    'PlotStyle_Button.Enabled = True
                    PlotStyle_label.Enabled = True
                End If
            Else
                PlotStyle.Text = ""
                PlotStyle.Enabled = False
                'PlotStyle_Button.Enabled = False
                PlotStyle_label.Enabled = True
                PlotStyle_label.Text = "PlotStyle: "
            End If

            CurrentLayer.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString

            If IsThisAnOldConfigName() = True Then
                ImportAllTextStyles()
            Else
                ImportAllTextStylesNew()
            End If


            reload_existinglayerlist()

            Dim strCFGPath As String

            Me.Text = "Layer Creator - " & Settings.Manager.AE.Version

            reload_existinglayerlist()

            Dim sConfigName As String

            If ThisDrawingIsConfigured() = True Then

                If RuleAccessors.GetruleValue("TESTCONFIG").IsTrue Then
                    sConfigName = "T@" & RuleAccessors.GetruleValue("FULLCONFIGNAME")
                Else
                    sConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME")
                End If
                strCFGPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sConfigName, "Settings")
            Else
                sConfigName = ""
                strCFGPath = Settings.Manager.AE.LibraryFolder.CombinePath("General", "Layer Definitions")
            End If

            For Each sFile As String In GetFiles(strCFGPath, "*.XML")
                Level.Items.Add(System.IO.Path.GetFileNameWithoutExtension(sFile))
            Next


            Level.SelectedIndex = Level.Items.Count - 1

            ClearValues()

            '    LineWeightDefault.Caption = val(ThisDrawing.GetVariable("LWDEFAULT")) / 100#
            IsInitialising = False
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub CreateLayers(ByRef ChildNode As MSXML2.IXMLDOMNode, ByRef sparent As String, ByRef sSearchAttribute As String, ByRef search2 As String)
        Try
            Dim NodeList As MSXML2.IXMLDOMNodeList
            Dim sRelative As String
            Dim sKey As String
            Dim sText As String
            Dim vHoldParentName() As String
            Dim i As Integer
            Dim lNewLayer As Autodesk.AutoCAD.Interop.Common.AcadLayer = Nothing
            Dim item As Object
            Dim sLayerName As String = ""
            Dim oldceltype As String = String.Empty

            If ChildNode.nodeType = MSXML2.tagDOMNodeType.NODE_ELEMENT Then
                NodeList = ChildNode.childNodes
                For Each ChildNode In NodeList
                    If ChildNode.baseName = "DELIMETER" Then
                    Else
                        If ChildNode.baseName <> "" Then
                            sRelative = sparent
                            sText = ChildNode.attributes.getNamedItem("NAME").nodeValue.ToString
                            sKey = sRelative & Delimeter.Text & ChildNode.attributes.getNamedItem("NAME").nodeValue.ToString

                            If UCase(sKey) Like UCase(sSearchAttribute) & "*" Or UCase(sKey) = UCase(search2) Then

                                If ChildNode.attributes.getNamedItem("COLOUR").nodeValue.ToString <> "" Then ' Check to see if we are allowed to create this layer
                                    For Each item In Split(sKey, Delimeter.Text) ' If we are then remove the ROOT prefix from the layer name
                                        If item.ToString.ToUpper <> "ROOT" Then
                                            If sLayerName = "" Then
                                                sLayerName = item.ToString
                                            Else
                                                sLayerName = sLayerName & Delimeter.Text & item.ToString
                                            End If
                                        End If
                                    Next item

                                    Try
                                        lNewLayer = ThisDrawingUtilities.Layers.Add(sLayerName) ' Make the layer and continue to set it's properties
                                    Catch ex As Exception
                                        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
                                    End Try


                                    If ChildNode.attributes.getNamedItem("LINETYPE").nodeValue.ToString <> "" Then
                                        CheckLinetype((ChildNode.attributes.getNamedItem("LINETYPE").nodeValue).ToString, sLayerName)
                                        lNewLayer.Linetype = ChildNode.attributes.getNamedItem("LINETYPE").nodeValue.ToString
                                    End If
                                    If ChildNode.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString <> "" Then
                                        lNewLayer.Description = ChildNode.attributes.getNamedItem("DESCRIPTION").nodeValue.ToString
                                    End If

                                    If ChildNode.attributes.getNamedItem("LINEWEIGHT").nodeValue.ToString <> "" Then

                                        lNewLayer.Lineweight = FixLineWeight(ChildNode.attributes.getNamedItem("LINEWEIGHT").nodeValue.ToString, False)

                                    End If

                                    If ChildNode.attributes.getNamedItem("COLOUR").nodeValue.ToString <> "" Then
                                        lNewLayer.color = FixColour((ChildNode.attributes.getNamedItem("COLOUR").nodeValue).ToString)
                                    End If



                                    If CInt(ThisDrawingUtilities.GetVariable("PSTYLEMODE")) = 0 Then


                                        If ChildNode.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString <> "" Then
                                            Try

                                                oldceltype = ThisDrawingUtilities.GetVariable("CPLOTSTYLE").ToString
                                                ThisDrawingUtilities.SetVariable("CPLOTSTYLE", ChildNode.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString)
                                                lNewLayer.PlotStyleName = ChildNode.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString
                                                ThisDrawingUtilities.SetVariable("CPLOTSTYLE", oldceltype)

                                            Catch ex As System.Exception
                                                ' need to load it from stb
                                                ThisDrawingUtilities.SetVariable("CPLOTSTYLE", oldceltype)

                                                Acad_MessageBox("There was an issue setting the layer plot style: " & sLayerName & " could not find plot style " & ChildNode.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString & " in the current plot style." &
                                                                "Ensure that the PlotStyle Name: " & ChildNode.attributes.getNamedItem("PLOTSTYLE").nodeValue.ToString & " exists in the plot style." &
                                                                "The layer has been created but with a default plot style of normal. To rectify the problem purge all the problem layers ensure the plot style table has the named plot stye and recreate them",
                                                                 System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                                            End Try
                                        End If
                                    End If
                                End If
                            End If
                            sLayerName = ""
                            sparent = sKey
                            '                    sSearchAttribute =

                        End If
                    End If
                    CreateLayers(ChildNode, sparent, sSearchAttribute, search2)
                Next ChildNode
                vHoldParentName = Split(sparent, Delimeter.Text)
                sparent = "ROOT"

                For i = 1 To UBound(vHoldParentName) - 1
                    sparent = sparent & Delimeter.Text & vHoldParentName(i)
                Next
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub MakeLayer_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MakeLayer.Click
        Try

            Me.StatusLabel.Text = "Please wait creating layers...."
            Me.MakeLayer.Enabled = False
            Me.Refresh()

            Dim lNewLayer As Autodesk.AutoCAD.Interop.Common.AcadLayer
            Dim i As Integer
            Dim sparent As String

            If MultipleItemsSelected(SubSubSubSubElementListBox) <> "Nothing Selected" Then
                For i = 0 To SubSubSubSubElementListBox.Items.Count - 1
                    If SubSubSubSubElementListBox.GetSelected(i) = True Then
                        root = xmlDoc.documentElement
                        sparent = "ROOT" & Delimeter.Text & MultipleItemsSelected(ElementListBox) & Delimeter.Text & MultipleItemsSelected(SubElementListBox) & Delimeter.Text & MultipleItemsSelected(SubSubElementListBox) & Delimeter.Text & MultipleItemsSelected(SubSubSubElementListBox)

                        CreateLayers(root, "ROOT", sparent & Delimeter.Text & UserInterface.GetListBoxText(SubSubSubSubElementListBox, i), sparent)

                    End If
                Next
            Else
                If MultipleItemsSelected(SubSubSubElementListBox) <> "Nothing Selected" Then
                    For i = 0 To SubSubSubElementListBox.Items.Count - 1
                        If SubSubSubElementListBox.GetSelected(i) = True Then
                            root = xmlDoc.documentElement
                            sparent = "ROOT" & Delimeter.Text & MultipleItemsSelected(ElementListBox) & Delimeter.Text & MultipleItemsSelected(SubElementListBox) & Delimeter.Text & MultipleItemsSelected(SubSubElementListBox)

                            CreateLayers(root, "ROOT", sparent & Delimeter.Text & UserInterface.GetListBoxText(SubSubSubElementListBox, i), sparent)
                        End If
                    Next
                Else
                    If MultipleItemsSelected(SubSubElementListBox) <> "Nothing Selected" Then
                        For i = 0 To SubSubElementListBox.Items.Count - 1
                            If SubSubElementListBox.GetSelected(i) = True Then
                                root = xmlDoc.documentElement
                                sparent = "ROOT" & Delimeter.Text & MultipleItemsSelected(ElementListBox) & Delimeter.Text & MultipleItemsSelected(SubElementListBox)

                                CreateLayers(root, "ROOT", sparent & Delimeter.Text & UserInterface.GetListBoxText(SubSubElementListBox, i), sparent)
                            End If
                        Next
                    Else
                        If MultipleItemsSelected(SubElementListBox) <> "Nothing Selected" Then
                            For i = 0 To SubElementListBox.Items.Count - 1

                                If SubElementListBox.GetSelected(i) = True Then
                                    root = xmlDoc.documentElement

                                    sparent = "ROOT" & Delimeter.Text & MultipleItemsSelected(ElementListBox)

                                    CreateLayers(root, "ROOT", sparent & Delimeter.Text & UserInterface.GetListBoxText(SubElementListBox, i), sparent)
                                End If
                            Next
                        Else
                            If MultipleItemsSelected(ElementListBox) <> "Nothing Selected" Then
                                For i = 0 To ElementListBox.Items.Count - 1
                                    If ElementListBox.GetSelected(i) = True Then
                                        root = xmlDoc.documentElement

                                        sparent = "ROOT"

                                        CreateLayers(root, "ROOT", sparent & Delimeter.Text & UserInterface.GetListBoxText(ElementListBox, i), sparent)
                                    End If
                                Next
                            Else
                                If Colour.Text <> "" And LayerName.Text <> "" Then ' Make sure we are allowed to create this layer
                                    lNewLayer = ThisDrawingUtilities.Layers.Add(LayerName.Text)
                                    If LineType.Text <> "" Then
                                        lNewLayer.Linetype = CheckLinetype(LineType.Text, LayerName.Text)
                                    End If
                                    If Description.Text <> "" Then
                                        lNewLayer.Description = Description.Text
                                    End If
                                    If LineWeight.Text <> "" Then
                                        lNewLayer.Lineweight = CType(CShort(FixLineWeight(LineWeight.Text)), ACAD_LWEIGHT)
                                    End If
                                    lNewLayer.color = FixColour(Colour.Text)
                                End If
                            End If
                        End If
                    End If
                End If
            End If

            reload_existinglayerlist()

            Acad_MessageBox("Process complete check command line for errors and manually fix any line types created by default.", , MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.StatusLabel.Text = ""
            Me.MakeLayer.Enabled = True

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub Colour_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Dim sCol As String

            sCol = getcolor()

            If sCol <> "" Then
                Colour.Text = sCol
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LineTypes_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Dim sSelectedLineType As String

            sSelectedLineType = GetLineType()

            If sSelectedLineType <> "" Then
                LineType.Text = sSelectedLineType
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LineWeight_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Try
            Dim sSelectedLineWeight As String

            sSelectedLineWeight = GetLineWeight()

            If sSelectedLineWeight <> "" Then ' And sSelectedLineWeight <> "0" Then
                LineWeight.Text = FixLineWeight(sSelectedLineWeight, True).ToString
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SetCurrentBtn_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SetCurrentBtn.Click
        Try
            Dim i As Integer

            For i = 0 To ExistingLayersLstBox.Items.Count - 1
                If ExistingLayersLstBox.GetSelected(i) = True Then
                    ThisDrawingUtilities.SetVariable("CLAYER", UserInterface.GetListBoxText(ExistingLayersLstBox, i))
                End If
            Next i

            CurrentLayer.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub GetXMLFile(ByRef sFileName As String, Optional ByRef strCFGPath As String = "")
        Try
            Dim xmlNode As Object

            xmlDoc = New MSXML2.DOMDocument

            xmlDoc.validateOnParse = False
            xmlDoc.setProperty("SelectionLanguage", "XPath")

            ' This should be windows xp compatible
            Dim sConfigName As String
            If strCFGPath = "" Then

                If ThisDrawingIsConfigured() = True Then
                    If RuleAccessors.GetruleValue("TESTCONFIG").IsTrue Then
                        sConfigName = "T@" & RuleAccessors.GetruleValue("FULLCONFIGNAME")
                    Else
                        sConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME")
                    End If
                    strCFGPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sConfigName, "Settings")
                Else
                    sConfigName = ""
                    strCFGPath = ""
                End If
            End If

            If System.IO.File.Exists(strCFGPath.CombinePath(sFileName)) Then

                xmlDoc.load(strCFGPath.CombinePath(sFileName))

                If xmlDoc.parseError.errorCode <> 0 Then
                    Acad_MessageBox(xmlDoc.parseError.reason, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                End If

                root = xmlDoc.documentElement
                xmlNode = xmlDoc.documentElement
                NodeList = root.selectNodes("//LAYERELEMENTS/ELEMENT")

                ElementListBox.Items.Clear()
                SubElementListBox.Items.Clear()
                SubSubElementListBox.Items.Clear()
                SubSubSubElementListBox.Items.Clear()
                SubSubSubSubElementListBox.Items.Clear()

                For Each Element In NodeList
                    ElementListBox.Items.Add(Element.attributes.getNamedItem("NAME").nodeValue)
                Next Element

                LineType.Text = ThisDrawingUtilities.GetVariable("CELTYPE").ToString
                Colour.Text = ThisDrawingUtilities.GetVariable("CECOLOR").ToString
                CurrentLayer.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                LineWeight.Text = FixLineWeight(ThisDrawingUtilities.GetVariable("CELWEIGHT").ToString, True).ToString

                PlotStyle.Text = ThisDrawingUtilities.GetVariable("CPLOTSTYLE").ToString

                LayerName.Text = ""

                NodeList = root.selectNodes("//LAYERELEMENTS/DELIMETER")

                Delimeter.Text = NodeList.item(0).nodeTypedValue.ToString
            Else
                Delimeter.Text = ""
                ElementListBox.Items.Clear()
                SubElementListBox.Items.Clear()
                SubSubElementListBox.Items.Clear()
                SubSubSubElementListBox.Items.Clear()
                SubSubSubSubElementListBox.Items.Clear()
                ClearValues()
                LayerName.Text = ""

            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try


    End Sub

    Sub reload_existinglayerlist()
        Try
            Dim item As AcadLayer

            ExistingLayersLstBox.Items.Clear()

            For Each item In ThisDrawingUtilities.Layers
                ExistingLayersLstBox.Items.Add(item.Name)
            Next item

            SetCurrentBtn.Enabled = False

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Function CheckLinetype(ByRef sLineType As String, ByVal LayerName As String) As String

        Dim sReturn As String = ThisDrawingUtilities.GetVariable("CELTYPE").ToString

        Try

            If sLineType = "" Then ' "" Is valid as some levels may not be allowed to be created
                sLineType = ThisDrawingUtilities.GetVariable("CELTYPE").ToString
            Else
                If LineTypeExist(sLineType) = False Then

                    ' Check for the line type in the AcadISO.LIN file
                    Try
                        ThisDrawingUtilities.Linetypes.Load(sLineType, "Acadiso.lin")
                    Catch ex As Exception

                        If ex.Message = "Duplicate record name" Then
                            ' Already exists don't need to do any more
                            ' Skip duplicate definitions 
                            Return sReturn
                        End If

                        If ex.Message = "Invalid linetype name" Then
                            Acad_MessageBox("Invalid linetype name: " & sLineType & " in " & "Acadiso.lin", , , , , , , True, logName)
                        End If

                    End Try

                    If LineTypeExist(sLineType) = False Then
                        '' Try all of the LIN files in the Config Support path in case we find it there
                        For Each SFile As String In GetFiles(Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(RuleAccessors.GetruleValue("FULLCONFIGNAME"), "Settings"), "*.LIN")
                            Try
                                If SFile.Contains("Acadiso.lin") Then
                                    'skip already checked that one
                                Else
                                    ThisDrawingUtilities.Linetypes.Load(sLineType, SFile)
                                End If
                            Catch ex As Exception
                                If ex.Message = "Duplicate record name" Then
                                    ' Already exists don't need to do any more
                                    ' Skip duplicate definitions 
                                    Return sReturn
                                End If

                                If ex.Message = "Invalid linetype name" Then
                                    Acad_MessageBox("Invalid linetype name: " & sLineType & " in " & SFile, , , , , , , True, logName)
                                End If

                            End Try
                        Next
                    End If

                    If LineTypeExist(sLineType) = False Then
                        '' If all else failed then try the DWT files in the hierarchy
                        Try
                            Importer(sLineType, WZ_LINETYPE_TABLE.ToString, False, , "Continuous")
                        Catch ex As Exception
                            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
                        End Try
                    End If

                    If LineTypeExist(sLineType) = False Then
                        Acad_MessageBox("The CAD Environment has tried to load the " & sLineType & " definintion " & LayerName & " from the following places and was unsuccessful - the Continuous line type will be used instead" &
                            "Checked the: AcadISO.LIN and all of the LIN files in this configuration as well as all the configuration templates starting from client.", , MessageBoxButtons.OK)
                    End If

                End If
            End If

        Catch ex As Exception

            'ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

            If ex.Message = "Duplicate record name" Then
                ' Skip duplicate definitions 
            Else

                Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            End If

        End Try

        Return sReturn

    End Function

    Sub FillWithLineTypes(ByRef cBoxName As System.Windows.Forms.ComboBox, ByRef sDefault As String)
        Try
            Dim i As Integer
            cBoxName.Items.Clear()
            cBoxName.ForeColor = System.Drawing.Color.Black
            For i = 0 To (ThisDrawingUtilities.Linetypes.Count - 1)
                cBoxName.Items.Add(ThisDrawingUtilities.Linetypes.Item(i).Name)
            Next

            cBoxName.Text = sDefault
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Function FixLineWeight(ByRef sLineWeight As String, Optional ByRef bAdjust As Boolean = True) As ACAD_LWEIGHT

        Try
            Dim dDivideby As Double

            '' All units should be caterd for future feature
            If CInt(ThisDrawingUtilities.GetVariable("LWUNITS")) = 1 Then
                dDivideby = 1.0# ' Millimeters
            Else
                dDivideby = 25.0# ' Inches
            End If

            If String.IsNullOrEmpty(sLineWeight) = False Then
                If sLineWeight = "-3" Or UCase(sLineWeight) = "Default".ToUpper Or
                   sLineWeight = "-1" Or UCase(sLineWeight) = "ByLayer".ToUpper Or
                   sLineWeight = "-2" Or UCase(sLineWeight) = "ByBlock".ToUpper Then

                    If bAdjust = True Then
                        sLineWeight = ThisDrawingUtilities.GetVariable("LWDEFAULT").ToString
                        Return CType(Val(sLineWeight) / dDivideby / 100.0#, ACAD_LWEIGHT) ' For some reason the default value is always stored in decimeters
                    Else
                        If sLineWeight = "-3" Or UCase(sLineWeight) = "Default".ToUpper Then
                            Return CType("-3", ACAD_LWEIGHT)
                        End If
                        If sLineWeight = "-1" Or UCase(sLineWeight) = "ByLayer".ToUpper Then
                            Return CType("-1", ACAD_LWEIGHT)
                        End If
                        If sLineWeight = "-2" Or UCase(sLineWeight) = "ByBlock".ToUpper Then
                            Return CType("-2", ACAD_LWEIGHT)
                        End If
                    End If
                Else
                    If bAdjust = True Then
                        Return CType(Val(sLineWeight) / dDivideby, ACAD_LWEIGHT)
                    End If
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return CType(ThisDrawingUtilities.GetVariable("LWDEFAULT").ToString, ACAD_LWEIGHT)

    End Function

    Function FixColour(ByRef sCol As String) As Autodesk.AutoCAD.Interop.Common.AcColor
        Try
            Select Case UCase(sCol)

                Case "RED"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acRed
                Case "YELLOW"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acYellow
                Case "GREEN"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acGreen
                Case "CYAN"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acCyan
                Case "BLUE"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acBlue
                Case "MAGENTA"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acMagenta
                Case "WHITE"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acWhite
                Case "GREY"
                    FixColour = CType(8, AcColor)
                Case "GRAY"
                    FixColour = CType(8, AcColor)
                Case "BYBLOCK"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acByBlock
                Case "BYLAYER"
                    FixColour = Autodesk.AutoCAD.Interop.Common.AcColor.acByLayer
                Case ""
                    FixColour = FixColour(ThisDrawingUtilities.GetVariable("CECOLOR").ToString)
                Case Else
                    FixColour = CType(CShort(sCol), AcColor)
            End Select
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try
    End Function

    Sub ClearValues()
        Try
            LineType.Text = String.Empty
            Colour.Text = String.Empty
            CurrentLayer.Text = String.Empty
            LineWeight.Text = String.Empty
            Description.Text = String.Empty
            PlotStyle.Text = String.Empty
            '            GetFile.Enabled = False
            AlternativeFileName.Text = String.Empty

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    'Sub SetDefaultValues()
    '    Try
    '        LineType.Text = ThisDrawing.GetVariable("CELTYPE").ToString
    '        Colour.Text = ThisDrawing.GetVariable("CELTYPE").ToString
    '        CurrentLayer.Text = ThisDrawing.GetVariable("CLAYER").ToString
    '        LineWeight.Text = FixLineWeight(ThisDrawing.GetVariable("CELWEIGHT").ToString, True)
    '        PlotStyle.Text = ThisDrawing.GetVariable("CPLOTSTYLE").ToString
    '        Description.Enabled = True
    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try
    'End Sub

    Private Sub Level_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Level.SelectedIndexChanged

        Try
            '   If IsInitialising Then Exit Sub
            GetXMLFile(Level.Text & ".xml")
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    'UPGRADE_WARNING: ComboBox event Level.Change was upgraded to Level.TextChanged which has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
    'Private Sub Level_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Level.TextChanged
    '    Try
    '        If IsInitialising Then Exit Sub
    '        GetXMLFile(Level.Text & ".xml")
    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try
    'End Sub

    Private Sub ExistingLayersLstBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingLayersLstBox.SelectedIndexChanged
        Try
            Dim i As Integer
            Dim bSomethingSelected As Boolean

            bSomethingSelected = False
            For i = 0 To ExistingLayersLstBox.Items.Count - 1
                If ExistingLayersLstBox.GetSelected(i) = True Then
                    bSomethingSelected = True
                    Exit For
                End If
            Next

            If bSomethingSelected = True Then
                '       MakeLayer.Enabled = False
                SetCurrentBtn.Enabled = True
            Else
                SetCurrentBtn.Enabled = False
                '        MakeLayer.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    'Private Sub ClientRules_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClientRules.CheckedChanged
    '    Try
    '        If IsInitialising Then Exit Sub

    '        If ClientRules.CheckState = CheckState.Checked Then
    '            WorkingVariableAccessors.AddWorkVar("LayerCREATORClientConfig", True)
    '        Else
    '            WorkingVariableAccessors.AddWorkVar("LayerCREATORClientConfig", False)
    '        End If

    '        If bInitialize = True Then
    '            bInitialize = False
    '        Else
    '            If ClientRules.CheckState = CheckState.Checked Then
    '                CheckRules(True)
    '            Else
    '                CheckRules(False)
    '            End If
    '        End If
    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try

    'End Sub


    Private Sub ElementListBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ElementListBox.SelectedIndexChanged
        Try
            Dim sEelementListBoxValue As String

            sEelementListBoxValue = MultipleItemsSelected(ElementListBox)

            If sEelementListBoxValue = "Multiple Selections" Then
                SubElementListBox.Items.Clear()
                ClearValues()

            Else
                If sEelementListBoxValue <> "Nothing Selected" Then
                    ElementListBoxProcess(sEelementListBoxValue)
                Else
                    ' Something is selected
                End If
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub


    Private Sub SubElementListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubElementListBox.SelectedIndexChanged
        Try
            Dim sEelementListBoxValue As String

            sEelementListBoxValue = MultipleItemsSelected(SubElementListBox)

            If sEelementListBoxValue = "Multiple Selections" Then
                SubSubElementListBox.Items.Clear()
                ClearValues()
                '        layername.text = ""
                '        Description.text = ""
                '        LayerName.Enabled = False
                '        Description.Enabled = False
            Else
                If sEelementListBoxValue <> "Nothing Selected" Then
                    SubElementListBoxProcess(sEelementListBoxValue)
                End If
                '        LayerName.Enabled = True
                '        Description.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SubSubElementListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubSubElementListBox.SelectedIndexChanged
        Try
            Dim sEelementListBoxValue As String

            sEelementListBoxValue = MultipleItemsSelected(SubSubElementListBox)

            If sEelementListBoxValue = "Multiple Selections" Then
                SubSubSubElementListBox.Items.Clear()
                ClearValues()
                '        layername.text = ""
                '        Description.text = ""
                '        LayerName.Enabled = False
                '        Description.Enabled = False
            Else
                If sEelementListBoxValue <> "Nothing Selected" Then
                    SubSubElementListBoxProcess(sEelementListBoxValue)
                End If
                '        LayerName.Enabled = True
                '        Description.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SubSubSubElementListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubSubSubElementListBox.SelectedIndexChanged
        Try
            Dim sEelementListBoxValue As String

            sEelementListBoxValue = MultipleItemsSelected(SubSubSubElementListBox)

            If sEelementListBoxValue = "Multiple Selections" Then
                SubSubSubSubElementListBox.Items.Clear()
                ClearValues()
                '        layername.text = ""
                '        Description.text = ""
                '        LayerName.Enabled = False
                '        Description.Enabled = False
            Else
                If sEelementListBoxValue <> "Nothing Selected" Then
                    SubSubSubElementListBoxProcess(sEelementListBoxValue)
                End If
                '        LayerName.Enabled = True
                '        Description.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SubSubSubSubElementListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubSubSubSubElementListBox.SelectedIndexChanged
        Try
            Dim sEelementListBoxValue As String

            sEelementListBoxValue = MultipleItemsSelected(SubSubSubSubElementListBox)

            If sEelementListBoxValue = "Multiple Selections" Then
                ClearValues()
                '        layername.text = ""
                '        Description.text = ""
                '        LayerName.Enabled = False
                '        Description.Enabled = False
            Else
                If sEelementListBoxValue <> "Nothing Selected" Then
                    SubSubSubSubElementListBoxProcess(sEelementListBoxValue)
                End If
                '        LayerName.Enabled = True
                '        Description.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub ImportAllTextStyles()

        Dim sConfigname As String
        Dim strCFGPath As String

        If ThisDrawingIsConfigured() = True Then
            If RuleAccessors.GetruleValue("TESTCONFIG").IsTrue Then
                sConfigname = "T@" & RuleAccessors.GetruleValue("FULLCONFIGNAME")
            Else
                sConfigname = RuleAccessors.GetruleValue("FULLCONFIGNAME")
            End If

            Dim fname As String = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sConfigname, "Settings", sConfigname.Split("-"c)(sConfigname.Split("-"c).Length - 1)) & ".dwt"

            Acad_MessageBox("Importing all text styles from configuration template in case they are required for line type definitions", , , , , , , True, logName)
            Importer("*", WZ_TEXTSTYLE_TABLE.ToString, False, fname, "Standard")

        Else
            sConfigname = ""
            strCFGPath = ""
        End If

    End Sub

    Sub ImportAllTextStylesNew()

        If IsMasterFile() = True Then Exit Sub

        Dim sConfigname As String = RuleAccessors.GetruleValue("FULLCONFIGNAME")

        Dim fname As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigname, "Settings", sConfigname & ".dwg")

        Acad_MessageBox("Importing all text styles from configuration template in case they are required for line type definitions", , , , , , , True, logName)

        ImporterNew("*", WZ_TEXTSTYLE_TABLE.ToString, False, fname, "Standard")

    End Sub


End Class