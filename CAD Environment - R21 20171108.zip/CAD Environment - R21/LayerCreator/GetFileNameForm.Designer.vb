<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class GetFileNameForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents FileName As System.Windows.Forms.TextBox
    Public WithEvents FileNameLabel As System.Windows.Forms.Label
    Public WithEvents DelimeterLabel As System.Windows.Forms.Label
    Public WithEvents Help_Button As System.Windows.Forms.Button
    Public WithEvents OK_Button As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents Delimeter As System.Windows.Forms.TextBox
    Public WithEvents WorkSpaceName As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GetFileNameForm))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.FileName = New System.Windows.Forms.TextBox()
        Me.FileNameLabel = New System.Windows.Forms.Label()
        Me.DelimeterLabel = New System.Windows.Forms.Label()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Delimeter = New System.Windows.Forms.TextBox()
        Me.WorkSpaceName = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Label21 = New System.Windows.Forms.Label()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FileName
        '
        Me.FileName.AcceptsReturn = True
        Me.FileName.BackColor = System.Drawing.SystemColors.Control
        Me.FileName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.FileName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.FileName.Location = New System.Drawing.Point(157, 142)
        Me.FileName.MaxLength = 0
        Me.FileName.Name = "FileName"
        Me.FileName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FileName.Size = New System.Drawing.Size(300, 24)
        Me.FileName.TabIndex = 0
        '
        'FileNameLabel
        '
        Me.FileNameLabel.AutoSize = True
        Me.FileNameLabel.BackColor = System.Drawing.SystemColors.Control
        Me.FileNameLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.FileNameLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FileNameLabel.Location = New System.Drawing.Point(72, 142)
        Me.FileNameLabel.Name = "FileNameLabel"
        Me.FileNameLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FileNameLabel.Size = New System.Drawing.Size(70, 17)
        Me.FileNameLabel.TabIndex = 1
        Me.FileNameLabel.Text = "File Name:"
        Me.FileNameLabel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'DelimeterLabel
        '
        Me.DelimeterLabel.AutoSize = True
        Me.DelimeterLabel.BackColor = System.Drawing.SystemColors.Control
        Me.DelimeterLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.DelimeterLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DelimeterLabel.Location = New System.Drawing.Point(75, 181)
        Me.DelimeterLabel.Name = "DelimeterLabel"
        Me.DelimeterLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DelimeterLabel.Size = New System.Drawing.Size(70, 17)
        Me.DelimeterLabel.TabIndex = 2
        Me.DelimeterLabel.Text = "Delimeter:"
        Me.DelimeterLabel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Help_Button
        '
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(312, 231)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(80, 27)
        Me.Help_Button.TabIndex = 4
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'OK_Button
        '
        Me.OK_Button.BackColor = System.Drawing.SystemColors.Control
        Me.OK_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.OK_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OK_Button.Location = New System.Drawing.Point(141, 231)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OK_Button.Size = New System.Drawing.Size(80, 27)
        Me.OK_Button.TabIndex = 5
        Me.OK_Button.Text = "OK"
        Me.OK_Button.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(228, 231)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(80, 27)
        Me.Cancel_Button.TabIndex = 6
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'Delimeter
        '
        Me.Delimeter.AcceptsReturn = True
        Me.Delimeter.BackColor = System.Drawing.SystemColors.Window
        Me.Delimeter.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Delimeter.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Delimeter.Location = New System.Drawing.Point(157, 174)
        Me.Delimeter.MaxLength = 0
        Me.Delimeter.Name = "Delimeter"
        Me.Delimeter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Delimeter.Size = New System.Drawing.Size(75, 24)
        Me.Delimeter.TabIndex = 7
        '
        'WorkSpaceName
        '
        Me.WorkSpaceName.BackColor = System.Drawing.SystemColors.Control
        Me.WorkSpaceName.Cursor = System.Windows.Forms.Cursors.Default
        Me.WorkSpaceName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.WorkSpaceName.Location = New System.Drawing.Point(66, 105)
        Me.WorkSpaceName.Name = "WorkSpaceName"
        Me.WorkSpaceName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.WorkSpaceName.Size = New System.Drawing.Size(408, 21)
        Me.WorkSpaceName.TabIndex = 8
        Me.WorkSpaceName.Text = "Label1"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 48
        Me.LogoPictureBox.TabStop = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.Window
        Me.Label21.Location = New System.Drawing.Point(143, 12)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(205, 35)
        Me.Label21.TabIndex = 49
        Me.Label21.Text = "Get File Name"
        '
        'GetFileName
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(507, 284)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.FileName)
        Me.Controls.Add(Me.FileNameLabel)
        Me.Controls.Add(Me.DelimeterLabel)
        Me.Controls.Add(Me.Help_Button)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.Delimeter)
        Me.Controls.Add(Me.WorkSpaceName)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 19)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "GetFileName"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents Label21 As System.Windows.Forms.Label
#End Region
End Class