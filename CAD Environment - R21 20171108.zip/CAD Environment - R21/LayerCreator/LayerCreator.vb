Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.LayerCreator.LayerCreator))> 

Public Class LayerCreator

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_LayerCreator", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub LayerCreator()

        Try
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                Dim SelectConfig As New SelectTemplate.TemplateSelector
                SelectConfig.DisplayWarning()

                If ThisDrawingIsConfigured() Then
                    DisplayDialog()
                End If
            Else
                DisplayDialog()
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub DisplayDialog()
        Try
            Dim LayerCreatorFrm As New LayerCreatorForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(LayerCreatorFrm)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

End Class
