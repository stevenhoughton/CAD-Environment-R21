<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class LayerCreatorForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents SubSubElementListBox As System.Windows.Forms.ListBox
    Public WithEvents ExistingLayersLstBox As System.Windows.Forms.ListBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents SetCurrentBtn As System.Windows.Forms.Button
    Public WithEvents LayerName As System.Windows.Forms.TextBox
    Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents CurrentLayer As System.Windows.Forms.TextBox
    Public WithEvents MakeLayer As System.Windows.Forms.Button
    Public WithEvents SubSubSubElementListBox As System.Windows.Forms.ListBox
    Public WithEvents ElementListBox As System.Windows.Forms.ListBox
    Public WithEvents SubSubSubSubElementListBox As System.Windows.Forms.ListBox
    Public WithEvents Level As System.Windows.Forms.ComboBox
    Public WithEvents Label12 As System.Windows.Forms.Label
    Public WithEvents Delimeter As System.Windows.Forms.Label
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents Help_Button As System.Windows.Forms.Button
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents LineWeightDefault As System.Windows.Forms.Label
    Public WithEvents Label14 As System.Windows.Forms.Label
    Public WithEvents Label15 As System.Windows.Forms.Label
    Public WithEvents LineWeight_Label As System.Windows.Forms.Label
    Public WithEvents PlotStyle_label As System.Windows.Forms.Label
    Public WithEvents PlotStyle As System.Windows.Forms.TextBox
    Public WithEvents Colour As System.Windows.Forms.TextBox
    Public WithEvents LineWeight As System.Windows.Forms.TextBox
    Public WithEvents LineType As System.Windows.Forms.TextBox
    Public WithEvents SubElementListBox As System.Windows.Forms.ListBox
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label16 As System.Windows.Forms.Label
    Public WithEvents Description As System.Windows.Forms.TextBox
    Public WithEvents Label20 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents GetFile As System.Windows.Forms.Button
    Public WithEvents AlternativeFileName As System.Windows.Forms.Label
    Public WithEvents TextBox1 As System.Windows.Forms.TextBox
    Public WithEvents TipFrame As System.Windows.Forms.GroupBox
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents Label21 As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LayerCreatorForm))
        Me.SubSubElementListBox = New System.Windows.Forms.ListBox()
        Me.ExistingLayersLstBox = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SetCurrentBtn = New System.Windows.Forms.Button()
        Me.LayerName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CurrentLayer = New System.Windows.Forms.TextBox()
        Me.MakeLayer = New System.Windows.Forms.Button()
        Me.SubSubSubElementListBox = New System.Windows.Forms.ListBox()
        Me.ElementListBox = New System.Windows.Forms.ListBox()
        Me.SubSubSubSubElementListBox = New System.Windows.Forms.ListBox()
        Me.Level = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Delimeter = New System.Windows.Forms.Label()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.LineWeightDefault = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.LineWeight_Label = New System.Windows.Forms.Label()
        Me.PlotStyle_label = New System.Windows.Forms.Label()
        Me.PlotStyle = New System.Windows.Forms.TextBox()
        Me.Colour = New System.Windows.Forms.TextBox()
        Me.LineWeight = New System.Windows.Forms.TextBox()
        Me.LineType = New System.Windows.Forms.TextBox()
        Me.SubElementListBox = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Description = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GetFile = New System.Windows.Forms.Button()
        Me.AlternativeFileName = New System.Windows.Forms.Label()
        Me.TipFrame = New System.Windows.Forms.GroupBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.StatusLabel = New System.Windows.Forms.Label()
        Me.TipFrame.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SubSubElementListBox
        '
        Me.SubSubElementListBox.BackColor = System.Drawing.SystemColors.Window
        Me.SubSubElementListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.SubSubElementListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SubSubElementListBox.ItemHeight = 17
        Me.SubSubElementListBox.Location = New System.Drawing.Point(315, 317)
        Me.SubSubElementListBox.Name = "SubSubElementListBox"
        Me.SubSubElementListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SubSubElementListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.SubSubElementListBox.Size = New System.Drawing.Size(147, 276)
        Me.SubSubElementListBox.Sorted = True
        Me.SubSubElementListBox.TabIndex = 0
        '
        'ExistingLayersLstBox
        '
        Me.ExistingLayersLstBox.BackColor = System.Drawing.SystemColors.Window
        Me.ExistingLayersLstBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.ExistingLayersLstBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ExistingLayersLstBox.ItemHeight = 17
        Me.ExistingLayersLstBox.Location = New System.Drawing.Point(157, 98)
        Me.ExistingLayersLstBox.Name = "ExistingLayersLstBox"
        Me.ExistingLayersLstBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ExistingLayersLstBox.Size = New System.Drawing.Size(609, 123)
        Me.ExistingLayersLstBox.Sorted = True
        Me.ExistingLayersLstBox.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(160, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(99, 17)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Existing Layers"
        '
        'SetCurrentBtn
        '
        Me.SetCurrentBtn.BackColor = System.Drawing.SystemColors.Control
        Me.SetCurrentBtn.Cursor = System.Windows.Forms.Cursors.Default
        Me.SetCurrentBtn.Enabled = False
        Me.SetCurrentBtn.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SetCurrentBtn.Location = New System.Drawing.Point(533, 236)
        Me.SetCurrentBtn.Name = "SetCurrentBtn"
        Me.SetCurrentBtn.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SetCurrentBtn.Size = New System.Drawing.Size(99, 26)
        Me.SetCurrentBtn.TabIndex = 3
        Me.SetCurrentBtn.Text = "Set Current"
        Me.SetCurrentBtn.UseVisualStyleBackColor = False
        '
        'LayerName
        '
        Me.LayerName.AcceptsReturn = True
        Me.LayerName.BackColor = System.Drawing.SystemColors.Window
        Me.LayerName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LayerName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LayerName.Location = New System.Drawing.Point(912, 92)
        Me.LayerName.MaxLength = 0
        Me.LayerName.Name = "LayerName"
        Me.LayerName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LayerName.Size = New System.Drawing.Size(222, 24)
        Me.LayerName.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(806, 98)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(131, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Actual Layer  Name:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(190, 242)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(98, 17)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Current Layer:"
        '
        'CurrentLayer
        '
        Me.CurrentLayer.AcceptsReturn = True
        Me.CurrentLayer.BackColor = System.Drawing.SystemColors.Window
        Me.CurrentLayer.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.CurrentLayer.Enabled = False
        Me.CurrentLayer.ForeColor = System.Drawing.SystemColors.WindowText
        Me.CurrentLayer.Location = New System.Drawing.Point(305, 239)
        Me.CurrentLayer.MaxLength = 0
        Me.CurrentLayer.Name = "CurrentLayer"
        Me.CurrentLayer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CurrentLayer.Size = New System.Drawing.Size(221, 24)
        Me.CurrentLayer.TabIndex = 7
        '
        'MakeLayer
        '
        Me.MakeLayer.BackColor = System.Drawing.SystemColors.Control
        Me.MakeLayer.Cursor = System.Windows.Forms.Cursors.Default
        Me.MakeLayer.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MakeLayer.Location = New System.Drawing.Point(565, 600)
        Me.MakeLayer.Name = "MakeLayer"
        Me.MakeLayer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.MakeLayer.Size = New System.Drawing.Size(99, 26)
        Me.MakeLayer.TabIndex = 8
        Me.MakeLayer.Text = "Create"
        Me.MakeLayer.UseVisualStyleBackColor = False
        '
        'SubSubSubElementListBox
        '
        Me.SubSubSubElementListBox.BackColor = System.Drawing.SystemColors.Window
        Me.SubSubSubElementListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.SubSubSubElementListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SubSubSubElementListBox.ItemHeight = 17
        Me.SubSubSubElementListBox.Location = New System.Drawing.Point(467, 317)
        Me.SubSubSubElementListBox.Name = "SubSubSubElementListBox"
        Me.SubSubSubElementListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SubSubSubElementListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.SubSubSubElementListBox.Size = New System.Drawing.Size(147, 276)
        Me.SubSubSubElementListBox.Sorted = True
        Me.SubSubSubElementListBox.TabIndex = 9
        '
        'ElementListBox
        '
        Me.ElementListBox.BackColor = System.Drawing.SystemColors.Window
        Me.ElementListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.ElementListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ElementListBox.ItemHeight = 17
        Me.ElementListBox.Location = New System.Drawing.Point(12, 317)
        Me.ElementListBox.Name = "ElementListBox"
        Me.ElementListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ElementListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ElementListBox.Size = New System.Drawing.Size(147, 276)
        Me.ElementListBox.Sorted = True
        Me.ElementListBox.TabIndex = 10
        '
        'SubSubSubSubElementListBox
        '
        Me.SubSubSubSubElementListBox.BackColor = System.Drawing.SystemColors.Window
        Me.SubSubSubSubElementListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.SubSubSubSubElementListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SubSubSubSubElementListBox.ItemHeight = 17
        Me.SubSubSubSubElementListBox.Location = New System.Drawing.Point(619, 317)
        Me.SubSubSubSubElementListBox.Name = "SubSubSubSubElementListBox"
        Me.SubSubSubSubElementListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SubSubSubSubElementListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.SubSubSubSubElementListBox.Size = New System.Drawing.Size(147, 276)
        Me.SubSubSubSubElementListBox.Sorted = True
        Me.SubSubSubSubElementListBox.TabIndex = 11
        '
        'Level
        '
        Me.Level.BackColor = System.Drawing.SystemColors.Window
        Me.Level.Cursor = System.Windows.Forms.Cursors.Default
        Me.Level.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Level.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Level.Location = New System.Drawing.Point(305, 264)
        Me.Level.Name = "Level"
        Me.Level.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Level.Size = New System.Drawing.Size(221, 25)
        Me.Level.Sorted = True
        Me.Level.TabIndex = 13
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(160, 266)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(139, 17)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Configuration Layers:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Delimeter
        '
        Me.Delimeter.BackColor = System.Drawing.SystemColors.Control
        Me.Delimeter.Cursor = System.Windows.Forms.Cursors.Default
        Me.Delimeter.Enabled = False
        Me.Delimeter.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Delimeter.Location = New System.Drawing.Point(909, 278)
        Me.Delimeter.Name = "Delimeter"
        Me.Delimeter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Delimeter.Size = New System.Drawing.Size(27, 18)
        Me.Delimeter.TabIndex = 15
        Me.Delimeter.Text = "_"
        Me.Delimeter.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Cancel_Button
        '
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(670, 600)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(99, 26)
        Me.Cancel_Button.TabIndex = 17
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'Help_Button
        '
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(8, 600)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(99, 26)
        Me.Help_Button.TabIndex = 18
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(959, 758)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(145, 17)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Default Line Weight = "
        Me.Label13.Visible = False
        '
        'LineWeightDefault
        '
        Me.LineWeightDefault.BackColor = System.Drawing.SystemColors.Control
        Me.LineWeightDefault.Cursor = System.Windows.Forms.Cursors.Default
        Me.LineWeightDefault.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LineWeightDefault.Location = New System.Drawing.Point(1073, 758)
        Me.LineWeightDefault.Name = "LineWeightDefault"
        Me.LineWeightDefault.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LineWeightDefault.Size = New System.Drawing.Size(45, 13)
        Me.LineWeightDefault.TabIndex = 21
        Me.LineWeightDefault.Text = "Label14"
        Me.LineWeightDefault.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(867, 125)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(57, 17)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "Colour: "
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(857, 155)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(69, 17)
        Me.Label15.TabIndex = 24
        Me.Label15.Text = "Linetype: "
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LineWeight_Label
        '
        Me.LineWeight_Label.BackColor = System.Drawing.SystemColors.Control
        Me.LineWeight_Label.Cursor = System.Windows.Forms.Cursors.Default
        Me.LineWeight_Label.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LineWeight_Label.Location = New System.Drawing.Point(797, 181)
        Me.LineWeight_Label.Name = "LineWeight_Label"
        Me.LineWeight_Label.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LineWeight_Label.Size = New System.Drawing.Size(106, 13)
        Me.LineWeight_Label.TabIndex = 25
        Me.LineWeight_Label.Text = "LineWeight: "
        Me.LineWeight_Label.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PlotStyle_label
        '
        Me.PlotStyle_label.BackColor = System.Drawing.SystemColors.Control
        Me.PlotStyle_label.Cursor = System.Windows.Forms.Cursors.Default
        Me.PlotStyle_label.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PlotStyle_label.Location = New System.Drawing.Point(794, 210)
        Me.PlotStyle_label.Name = "PlotStyle_label"
        Me.PlotStyle_label.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.PlotStyle_label.Size = New System.Drawing.Size(109, 13)
        Me.PlotStyle_label.TabIndex = 26
        Me.PlotStyle_label.Text = "PlotStyle: "
        Me.PlotStyle_label.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PlotStyle
        '
        Me.PlotStyle.AcceptsReturn = True
        Me.PlotStyle.BackColor = System.Drawing.SystemColors.Window
        Me.PlotStyle.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.PlotStyle.Enabled = False
        Me.PlotStyle.ForeColor = System.Drawing.SystemColors.WindowText
        Me.PlotStyle.Location = New System.Drawing.Point(911, 203)
        Me.PlotStyle.MaxLength = 0
        Me.PlotStyle.Name = "PlotStyle"
        Me.PlotStyle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.PlotStyle.Size = New System.Drawing.Size(138, 24)
        Me.PlotStyle.TabIndex = 27
        '
        'Colour
        '
        Me.Colour.AcceptsReturn = True
        Me.Colour.BackColor = System.Drawing.SystemColors.Window
        Me.Colour.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Colour.Enabled = False
        Me.Colour.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Colour.Location = New System.Drawing.Point(912, 119)
        Me.Colour.MaxLength = 0
        Me.Colour.Name = "Colour"
        Me.Colour.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Colour.Size = New System.Drawing.Size(138, 24)
        Me.Colour.TabIndex = 29
        '
        'LineWeight
        '
        Me.LineWeight.AcceptsReturn = True
        Me.LineWeight.BackColor = System.Drawing.SystemColors.Window
        Me.LineWeight.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LineWeight.Enabled = False
        Me.LineWeight.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LineWeight.Location = New System.Drawing.Point(912, 176)
        Me.LineWeight.MaxLength = 0
        Me.LineWeight.Name = "LineWeight"
        Me.LineWeight.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LineWeight.Size = New System.Drawing.Size(138, 24)
        Me.LineWeight.TabIndex = 31
        '
        'LineType
        '
        Me.LineType.AcceptsReturn = True
        Me.LineType.BackColor = System.Drawing.SystemColors.Window
        Me.LineType.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LineType.Enabled = False
        Me.LineType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LineType.Location = New System.Drawing.Point(912, 149)
        Me.LineType.MaxLength = 0
        Me.LineType.Name = "LineType"
        Me.LineType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LineType.Size = New System.Drawing.Size(138, 24)
        Me.LineType.TabIndex = 32
        '
        'SubElementListBox
        '
        Me.SubElementListBox.BackColor = System.Drawing.SystemColors.Window
        Me.SubElementListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.SubElementListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SubElementListBox.ItemHeight = 17
        Me.SubElementListBox.Location = New System.Drawing.Point(163, 317)
        Me.SubElementListBox.Name = "SubElementListBox"
        Me.SubElementListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SubElementListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.SubElementListBox.Size = New System.Drawing.Size(147, 276)
        Me.SubElementListBox.Sorted = True
        Me.SubElementListBox.TabIndex = 36
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(164, 301)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(53, 17)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Topic 2"
        Me.Label2.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.SystemColors.Control
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(844, 238)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(85, 17)
        Me.Label16.TabIndex = 38
        Me.Label16.Text = "Description: "
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Description
        '
        Me.Description.AcceptsReturn = True
        Me.Description.BackColor = System.Drawing.SystemColors.Window
        Me.Description.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Description.Enabled = False
        Me.Description.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Description.Location = New System.Drawing.Point(911, 232)
        Me.Description.MaxLength = 0
        Me.Description.Name = "Description"
        Me.Description.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Description.Size = New System.Drawing.Size(221, 24)
        Me.Description.TabIndex = 39
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.SystemColors.Control
        Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label20.Location = New System.Drawing.Point(16, 301)
        Me.Label20.Name = "Label20"
        Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label20.Size = New System.Drawing.Size(53, 17)
        Me.Label20.TabIndex = 40
        Me.Label20.Text = "Topic 1"
        Me.Label20.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(316, 301)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(53, 17)
        Me.Label3.TabIndex = 41
        Me.Label3.Text = "Topic 3"
        Me.Label3.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(471, 301)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(53, 17)
        Me.Label10.TabIndex = 42
        Me.Label10.Text = "Topic 4"
        Me.Label10.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(620, 301)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(53, 17)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Topic 5"
        Me.Label11.Visible = False
        '
        'GetFile
        '
        Me.GetFile.BackColor = System.Drawing.SystemColors.Control
        Me.GetFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.GetFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GetFile.Location = New System.Drawing.Point(736, 261)
        Me.GetFile.Name = "GetFile"
        Me.GetFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GetFile.Size = New System.Drawing.Size(30, 24)
        Me.GetFile.TabIndex = 44
        Me.GetFile.Text = "..."
        Me.GetFile.UseVisualStyleBackColor = False
        '
        'AlternativeFileName
        '
        Me.AlternativeFileName.BackColor = System.Drawing.SystemColors.Control
        Me.AlternativeFileName.Cursor = System.Windows.Forms.Cursors.Default
        Me.AlternativeFileName.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AlternativeFileName.Location = New System.Drawing.Point(533, 263)
        Me.AlternativeFileName.Name = "AlternativeFileName"
        Me.AlternativeFileName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AlternativeFileName.Size = New System.Drawing.Size(197, 21)
        Me.AlternativeFileName.TabIndex = 45
        Me.AlternativeFileName.Text = "Alternative File Name"
        Me.AlternativeFileName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TipFrame
        '
        Me.TipFrame.BackColor = System.Drawing.SystemColors.Control
        Me.TipFrame.Controls.Add(Me.TextBox1)
        Me.TipFrame.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TipFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TipFrame.Location = New System.Drawing.Point(8, 64)
        Me.TipFrame.Name = "TipFrame"
        Me.TipFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TipFrame.Size = New System.Drawing.Size(144, 232)
        Me.TipFrame.TabIndex = 46
        Me.TipFrame.TabStop = False
        Me.TipFrame.Text = "Tip"
        '
        'TextBox1
        '
        Me.TextBox1.AcceptsReturn = True
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Control
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextBox1.Location = New System.Drawing.Point(6, 12)
        Me.TextBox1.MaxLength = 0
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(132, 214)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 47
        Me.LogoPictureBox.TabStop = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label21.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.Window
        Me.Label21.Location = New System.Drawing.Point(143, 12)
        Me.Label21.Name = "Label21"
        Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label21.Size = New System.Drawing.Size(395, 35)
        Me.Label21.TabIndex = 47
        Me.Label21.Text = "Layer Creator - Discontinued"
        '
        'StatusLabel
        '
        Me.StatusLabel.AutoSize = True
        Me.StatusLabel.Location = New System.Drawing.Point(289, 608)
        Me.StatusLabel.Name = "StatusLabel"
        Me.StatusLabel.Size = New System.Drawing.Size(0, 17)
        Me.StatusLabel.TabIndex = 48
        '
        'LayerCreatorFrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(781, 632)
        Me.Controls.Add(Me.StatusLabel)
        Me.Controls.Add(Me.SubSubElementListBox)
        Me.Controls.Add(Me.ExistingLayersLstBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.SetCurrentBtn)
        Me.Controls.Add(Me.LayerName)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.CurrentLayer)
        Me.Controls.Add(Me.MakeLayer)
        Me.Controls.Add(Me.SubSubSubElementListBox)
        Me.Controls.Add(Me.ElementListBox)
        Me.Controls.Add(Me.SubSubSubSubElementListBox)
        Me.Controls.Add(Me.Level)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Delimeter)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.Help_Button)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.LineWeightDefault)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.LineWeight_Label)
        Me.Controls.Add(Me.PlotStyle_label)
        Me.Controls.Add(Me.PlotStyle)
        Me.Controls.Add(Me.Colour)
        Me.Controls.Add(Me.LineWeight)
        Me.Controls.Add(Me.LineType)
        Me.Controls.Add(Me.SubElementListBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Description)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.GetFile)
        Me.Controls.Add(Me.AlternativeFileName)
        Me.Controls.Add(Me.TipFrame)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.Label21)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 12)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "LayerCreatorFrm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.TipFrame.ResumeLayout(False)
        Me.TipFrame.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusLabel As System.Windows.Forms.Label
#End Region
End Class