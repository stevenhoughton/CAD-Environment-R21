﻿Imports Jacobs.Common.Core
Imports System.IO
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports Autodesk.AutoCAD.ApplicationServices
Imports Jacobs.AutoCAD.Utilities
Imports System.Reflection
Imports System.Windows.Forms
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.Common.Settings
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources

Public Class LayoutExportForm

    Private mInitalising As Boolean = False

    Private mDisableUpdate As Boolean = False
    Private TableIsFiltered As Boolean = False

    Private FileToProcess_DS As New System.Data.DataSet

    Private mBlockDataSet As New DataSet
    Private mDefColor As Color

    Public Class FileToExport
        Public Sub New(ByVal LayoutName As String, ByVal NewFileName As String)
            mExportFile = NewFileName
            mLayoutName = LayoutName
        End Sub

        Private mExportFile As String = ""
        Private mLayoutName As String = ""

        Public ReadOnly Property LayoutName() As String
            Get
                Return mLayoutName
            End Get
        End Property

        Public ReadOnly Property ExportName() As String
            Get
                Return mExportFile
            End Get
        End Property
    End Class

    Private mExportFiles As List(Of FileToExport) = New List(Of FileToExport)

    Public Sub New()

        mInitalising = True

        ' This call is required by the designer.
        InitializeComponent()

        System.Windows.Forms.Application.EnableVisualStyles()

        ' Add any initialization after the InitializeComponent() call.

        Dim DT As New System.Data.DataTable("BlockDetails")

        DT.Columns.Add("BlockName", GetType(System.String))
        DT.Columns.Add("AttributeName", GetType(System.String))
        DT.Columns.Add("AttributeValue", GetType(System.String))
        DT.Columns.Add("LayoutID", GetType(System.String))

        If mBlockDataSet.Tables.Contains("BlockDetails") Then
            mBlockDataSet.Tables.Remove("BlockDetails")
            mBlockDataSet.AcceptChanges()
        End If
        mBlockDataSet.Tables.Add(DT)

        Dim DTL As New System.Data.DataTable("LayoutDetails")

        DTL.Columns.Add("LayoutName", GetType(System.String))
        DTL.Columns.Add("LayoutID", GetType(System.String))

        If mBlockDataSet.Tables.Contains("LayoutDetails") Then
            mBlockDataSet.Tables.Remove("LayoutDetails")
            mBlockDataSet.AcceptChanges()
        End If
        mBlockDataSet.Tables.Add(DTL)

        mBlockDataSet.AcceptChanges()

        mDefColor = cboBlockNames.BackColor

        SetIgnoreData()

    End Sub

    Private Sub frmLayoutTools_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        mInitalising = True

        '' Workout out the Dialog Box Title 
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        ' Now that we have things like the AEVersion number and Title display it on the dialog name 
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

        RepositionTitle(Me.lblTitle, Me)

        '' Assign Global Generic dialog tool tips. Not to be hard coded. Use Global Reference file in Utilities
        ToolTip1.SetToolTip(cmdHelp, UtilitiesMyResources.ToolTipHelp)
        ToolTip1.SetToolTip(Cancel_Button, UtilitiesMyResources.ToolTipCancel)

        '' Assign local unique tool tips. Not to be hard coded. Use local reference file
        ToolTip1.SetToolTip(cmdRunFiles, My.Resources.ToolTipOK)
        ToolTip1.SetToolTip(lblTitle, My.Resources.ToolSummary)

        XEnabled(pnlTools, False)

        ClearExportFiles()
        lstNewFiles.DataSource = Nothing
        lstNewFiles.Items.Clear()

        lstNewFiles.DataSource = mExportFiles
        lstNewFiles.DisplayMember = "ExportName"

        chkLstLayouts.Items.Clear()

        mInitalising = False

    End Sub

    Private Sub frmLayoutTools_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        lblTitle.Left = Me.Width \ 2 - Me.lblTitle.Width \ 2
    End Sub

    Private Sub SetIgnoreData()
        'This will set Unresolved Settings etc
        'Hidden Message dialog Settings
    End Sub

    Private WriteOnly Property AddExportFile() As FileToExport
        Set(ByVal value As FileToExport)
            mExportFiles.Add(value)
            If mExportFiles.Count > 0 Then
                cmdRunFiles.Enabled = True
            Else
                cmdRunFiles.Enabled = False
            End If
        End Set
    End Property

    Private Sub ClearExportFiles()
        mExportFiles.Clear()
        cmdRunFiles.Enabled = False
    End Sub

    Private Sub SaveXML(ByVal DT As System.Data.DataTable, ByVal PDesc As String, ByVal FilePath As String)

        If DT.Rows.Count > 0 Then
            Dim TempDS As New DataSet
            TempDS.Tables.Add(DT.Copy)
            TempDS.AcceptChanges()

            If File.Exists(FilePath) Then
                File.Delete(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Processes have been deleted" & vbCrLf)
                TempDS.WriteXml(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Processes have been ReWritten!" & vbCrLf)
            Else
                TempDS.WriteXml(FilePath)
            End If
        End If

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub SaveDataRow(ByRef SettingDataTable As System.Data.DataTable, ByVal ControlName As String, ByVal SaveValue As String)

        Dim NewAddRow As DataRow

        NewAddRow = SettingDataTable.NewRow()
        NewAddRow.Item("SettingName") = ControlName
        NewAddRow.Item("SettingValue") = SaveValue
        SettingDataTable.Rows.Add(NewAddRow)

        NewAddRow = Nothing

    End Sub

    Private Function RestoreSettingValue(ByVal Settings As System.Data.DataTable, ByVal ControlFieldName As String) As String

        Dim DatRow As DataRow = Settings.Rows.Find(ControlFieldName)
        Dim Ret As String = ""

        If Not DatRow Is Nothing Then
            Ret = DatRow.Item("SettingValue").ToString
        End If

        Return Ret

    End Function

    Private Sub cmdRunFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRunFiles.Click

        For Each ExpFile As FileToExport In mExportFiles
            Dim ExportDrg As New clsExportImportLayout(0)
            ExportDrg.LayoutName = ExpFile.LayoutName
            ExportDrg.ExportName = ExpFile.ExportName
            ExportDrg.PreformExportImport()
            ExportDrg = Nothing
        Next
        tsslMessage.Text = "Export Complete!"

        Me.Hide()
        Me.Close()

    End Sub

    Private Sub CheckAndSetFolders(ByVal Path As String)

        If Directory.Exists(Path) = False Then
            Directory.CreateDirectory(Path)
        End If

    End Sub

    Private Sub cmdBrowsePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowsePath.Click

        'Dim NewPath As New FolderBrowserDialog
        'If NewPath.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    txtSavePath.Text = NewPath.SelectedPath
        'End If

        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                txtSavePath.Text = ReturnedFolder

                GetLayoutsToListBox()

                XEnabled(pnlTools, True)

                cboBlockNames.Enabled = False
                cboDrgNoAtt.Enabled = False
                cboDrgRevAtt.Enabled = False
            Else
                Acad_MessageBox("Invalid Selection folder does not exist - please try again")
            End If
        End If

    End Sub

    Private Sub GetLayoutsToListBox()

        chkLstLayouts.Items.Clear()
        mBlockDataSet.Tables("LayoutDetails").Rows.Clear()

        Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim db As Database = doc.Database
        Dim ed As Editor = doc.Editor

        Try
            Using DokLock As DocumentLock = doc.LockDocument
                Using tr As Transaction = db.TransactionManager.StartTransaction()
                    Dim layoutDict As DBDictionary = TryCast(tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead, False), DBDictionary)
                    For Each dictEnt As DBDictionaryEntry In layoutDict
                        ' ''Layout layout = tr.GetObject(dictEnt.Value, OpenMode.ForRead, false) as Layout;
                        ' ''ed.WriteMessage("{0}Layout name: {1}", Environment.NewLine, layout.LayoutName);
                        ''ed.WriteMessage("{0}Layout name: {1}", Environment.NewLine, dictEnt.Key)
                        If dictEnt.Key.ToLower <> "model" Then chkLstLayouts.Items.Add(dictEnt.Key)

                        Dim NR As DataRow = mBlockDataSet.Tables("LayoutDetails").NewRow
                        NR.Item("LayoutName") = dictEnt.Key
                        NR.Item("LayoutID") = dictEnt.Value.ToString

                        mBlockDataSet.Tables("LayoutDetails").Rows.Add(NR)

                        'dictEnt.Value
                    Next
                End Using
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        For Each DatRow As DataRow In mBlockDataSet.Tables("LayoutDetails").Rows
            If chkLstLayouts.Items.Contains(DatRow.Item("LayoutName")) = False AndAlso _
                DatRow.Item("LayoutName").ToString.ToLower.Contains("model") = False Then
                chkLstLayouts.Items.Add(DatRow.Item("LayoutName"))
            End If
        Next

    End Sub

    Private Sub cmdRefreshList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefreshList.Click
        GetLayoutsToListBox()
        lstNewFiles.Items.Clear()
    End Sub

    Private Sub RefereshNewFileList()

        ClearExportFiles()

        For Each ItemChecked As Object In chkLstLayouts.CheckedItems

            Dim LayoutName As String = chkLstLayouts.GetItemText(ItemChecked)

            Dim Prefix As String = txtExportPrefix.Text
            Dim Middle As String = LayoutName

            If chkNameByBlockAndAtt.Checked Then

                Dim SelItem As DataRowView = CType(cboBlockNames.SelectedItem, DataRowView)

                If SelItem IsNot Nothing Then

                    Dim BlkName As String = SelItem.Item("BlockName").ToString

                    If chkNameByBlockAndAtt.Checked AndAlso BlkName <> "" AndAlso BlkName <> "No Blocks Found" Then
                        Middle = GetAttributeNameDets(LayoutName, 0)
                        Dim X As String = GetAttributeNameDets(LayoutName, 1)
                        Middle += If(X.Length > 0, "-", "") & X
                    End If

                End If

            End If

            Dim Suffix As String = txtExportSuffix.Text

            AddExportFile = New FileToExport(LayoutName, txtSavePath.Text.CombinePath("\" & Prefix & Middle & Suffix & ".dwg"))
        Next

        lstNewFiles.DataSource = Nothing
        lstNewFiles.Items.Clear()
        lstNewFiles.DataSource = mExportFiles
        lstNewFiles.DisplayMember = "ExportName"

    End Sub

    Private Function GetAttributeNameDets(ByVal LayName As String, ByVal DrgNoOrRev As Integer) As String

        Dim ReturnFilePart As String = ""

        If cboBlockNames.SelectedItem Is Nothing Then Return "Error_Blk"
        If cboDrgNoAtt.SelectedItem Is Nothing Then Return "Error_DrgNoAtt"
        If cboDrgRevAtt.SelectedItem Is Nothing Then Return "Error_RevNoAtt"

        'Get Records filtered By LayoutName Passed to the function
        Dim LayoutFiltered_DT As System.Data.DataTable = (From P In mBlockDataSet.Tables("LayoutDetails").AsEnumerable() _
                          .Where(Function(P) P.Field(Of String)("LayoutName") = LayName)).Distinct.CopyToDataTable

        'if Record Count = 1 Continue else return Zero Length String
        If LayoutFiltered_DT.Rows.Count = 1 Then

            'Get Object ID of the layout
            Dim LayoutID As String = LayoutFiltered_DT.Rows(0).Item("LayoutID").ToString

            'get Block Details Filtered by Layout Object ID
            Dim BlockFiltered_By_LID_DT As System.Data.DataTable = (From P In mBlockDataSet.Tables("BlockDetails").AsEnumerable() _
                  .Where(Function(P) P.Field(Of String)("LayoutID") = LayoutID)).CopyToDataTable

            Dim BlkName As String = CType(cboBlockNames.SelectedItem, DataRowView).Item("BlockName").ToString
            Dim DrgNoAtt As String = CType(cboDrgNoAtt.SelectedItem, DataRowView).Item("AttributeName").ToString
            Dim DrgRevAtt As String = CType(cboDrgRevAtt.SelectedItem, DataRowView).Item("AttributeName").ToString

            Dim TestValue As String = ""

            Select Case DrgNoOrRev
                Case 0 'Drawing Number Attribute
                    TestValue = DrgNoAtt
                Case 1 'Drawing Rev Attribute
                    TestValue = DrgRevAtt
            End Select

            If TestValue <> "" Then

                Dim BlockFiltered_By_BlockName_DT As System.Data.DataTable = (From P In BlockFiltered_By_LID_DT.AsEnumerable() _
                                                                    .Where(Function(P) P.Field(Of String)("BlockName") = BlkName)).CopyToDataTable

                'check to make sure rows have been returned
                If BlockFiltered_By_BlockName_DT.Rows.Count > 0 Then

                    Dim BlockFiltered_By_Attribute_DT As System.Data.DataTable = (From P In BlockFiltered_By_LID_DT.AsEnumerable() _
                            .Where(Function(P) P.Field(Of String)("AttributeName") = TestValue)).CopyToDataTable

                    If BlockFiltered_By_Attribute_DT.Rows.Count = 1 Then
                        ReturnFilePart = BlockFiltered_By_Attribute_DT.Rows(0).Item("AttributeValue").ToString
                    Else
                        ReturnFilePart = "Error"
                    End If

                End If

            End If


        Else
            ReturnFilePart = "Error"
        End If

        Return ReturnFilePart

    End Function

    Private Sub chkLstLayouts_ItemCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemCheckEventArgs) Handles chkLstLayouts.ItemCheck

        If mDisableUpdate Then Exit Sub

        mDisableUpdate = True

        Dim clb As CheckedListBox = DirectCast(sender, CheckedListBox)
        ' Switch off event handler

        chkLstLayouts.SetItemCheckState(e.Index, e.NewValue)
        ' Switch on event handler

        mDisableUpdate = False

        RefereshNewFileList()
    End Sub

    Private Sub txtExportPrefix_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtExportPrefix.TextChanged
        RefereshNewFileList()
    End Sub

    Private Sub txtExportSuffix_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtExportSuffix.TextChanged
        RefereshNewFileList()
    End Sub

    Private Sub GetBlockNamesFromFile()

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim Ed As Editor = Doc.Editor

        ' create a new database
        Dim CurrentDatabase As Database = Doc.Database
        Dim ThisDrawingBlockCount As Integer = 0

        Try

            Using Doc.LockDocument

                Using trans As Transaction = CurrentDatabase.TransactionManager.StartTransaction

                    Dim bt As BlockTable = CType(trans.GetObject(CurrentDatabase.BlockTableId, OpenMode.ForRead, False), BlockTable)
                    Dim LayMan As LayoutManager = LayoutManager.Current

                    For Each OID As ObjectId In bt

                        Dim btr As BlockTableRecord = CType(trans.GetObject(OID, OpenMode.ForRead, False), BlockTableRecord)

                        If btr.IsErased = False AndAlso btr.IsAnonymous = False Then

                            If Not btr.Name.ToString.StartsWith("*") Then

                                If btr.HasAttributeDefinitions Then

                                    Dim Col As ObjectIdCollection = btr.GetBlockReferenceIds(True, False)

                                    For Each OIDx As ObjectId In Col

                                        Dim Bref As BlockReference = TryCast(trans.GetObject(OIDx, OpenMode.ForRead), BlockReference)

                                        Dim AttCol As AttributeCollection = Bref.AttributeCollection

                                        For Each AttOID As ObjectId In AttCol

                                            Dim AttDef As AttributeReference = DirectCast(trans.GetObject(AttOID, OpenMode.ForRead), AttributeReference)

                                            Dim NR As DataRow = mBlockDataSet.Tables("BlockDetails").NewRow
                                            NR.Item("BlockName") = Bref.Name.ToUpper
                                            NR.Item("AttributeName") = AttDef.Tag.ToUpper
                                            NR.Item("AttributeValue") = AttDef.TextString
                                            NR.Item("LayoutID") = btr.LayoutId.ToString

                                            mBlockDataSet.Tables("BlockDetails").Rows.Add(NR)

                                        Next

                                        ThisDrawingBlockCount += 1

                                    Next

                                End If

                            End If

                        End If

                    Next

                    trans.Commit()

                End Using

            End Using

        Catch ex As Exception
            Ed.WriteMessage("Error Reading Current DB " & vbCrLf & ex.Message.ToString & vbCrLf)
        Finally
            CurrentDatabase.Dispose()

            If ThisDrawingBlockCount = 0 Then

                Dim NR As DataRow = mBlockDataSet.Tables("BlockDetails").NewRow
                NR.Item("BlockName") = "---"
                NR.Item("AttributeName") = "---"
                mBlockDataSet.Tables("BlockDetails").Rows.Add(NR)
            End If
        End Try

        CurrentDatabase = Nothing

    End Sub

    Private Function GetBlocksToExport() As Boolean

        Dim Ret As Boolean = False

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim Ed As Editor = Doc.Editor
        Dim CurrentDatabase As Database = Doc.Database

        Dim ThisDrawingBlockCount As Integer = 0

        mBlockDataSet.Tables("BlockDetails").Rows.Clear()

        Try

            Using Doc.LockDocument

                Using CurrentDatabase

                    Using trans As Transaction = CurrentDatabase.TransactionManager.StartTransaction

                        Dim bt As BlockTable = DirectCast(trans.GetObject(CurrentDatabase.BlockTableId, OpenMode.ForRead), BlockTable)
                        For Each btrId As ObjectId In bt

                            Dim btr As BlockTableRecord = DirectCast(trans.GetObject(btrId, OpenMode.ForRead), BlockTableRecord)
                            If btr.IsLayout Then

                                Dim lo As Layout = DirectCast(trans.GetObject(btr.LayoutId, OpenMode.ForRead), Layout)
                                Dim LayoutSpace As BlockTableRecord = DirectCast(trans.GetObject(lo.BlockTableRecordId, OpenMode.ForRead), BlockTableRecord)
                                For Each objId As ObjectId In LayoutSpace
                                    Dim ent As Entity = DirectCast(trans.GetObject(objId, OpenMode.ForRead), Entity)
                                    If Not ent.[GetType]().ToString().Contains("BlockReference") Then
                                        Continue For
                                    End If
                                    Dim Bref As BlockReference = DirectCast(ent, BlockReference)
                                    Dim Effn As String = EffectiveName(Bref)

                                    Dim AttCol As AttributeCollection = Bref.AttributeCollection

                                    For Each AttOID As ObjectId In AttCol

                                        Dim AttDef As AttributeReference = DirectCast(trans.GetObject(AttOID, OpenMode.ForRead), AttributeReference)

                                        Dim NR As DataRow = mBlockDataSet.Tables("BlockDetails").NewRow
                                        NR.Item("BlockName") = Bref.Name.ToUpper
                                        NR.Item("AttributeName") = AttDef.Tag.ToUpper
                                        NR.Item("AttributeValue") = AttDef.TextString
                                        NR.Item("LayoutID") = lo.ObjectId.ToString

                                        mBlockDataSet.Tables("BlockDetails").Rows.Add(NR)

                                    Next

                                    ThisDrawingBlockCount += 1

                                    Ret = True

                                Next

                            End If

                        Next

                    End Using

                End Using

            End Using

        Catch ex As Exception
            Ed.WriteMessage("Error Reading Current DB " & vbCrLf & ex.Message.ToString & vbCrLf)
        Finally
            CurrentDatabase.Dispose()

            If ThisDrawingBlockCount = 0 Then

                Dim NR As DataRow = mBlockDataSet.Tables("BlockDetails").NewRow
                NR.Item("BlockName") = "No Blocks Found"
                NR.Item("AttributeName") = "---"
                mBlockDataSet.Tables("BlockDetails").Rows.Add(NR)
            End If
        End Try

        CurrentDatabase = Nothing

        Return Ret

    End Function

    Private Shared Function EffectiveName(ByVal blkref As BlockReference) As String
        If blkref.IsDynamicBlock Then
            Using obj As BlockTableRecord = DirectCast(blkref.DynamicBlockTableRecord.GetObject(OpenMode.ForRead), BlockTableRecord)
                Return obj.Name
            End Using
        End If
        Return blkref.Name
    End Function

    Private Sub chkNameByBlockAndAtt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkNameByBlockAndAtt.CheckedChanged

        If chkNameByBlockAndAtt.CheckState = CheckState.Checked Then

            'GetBlockNamesFromFile()

            If GetBlocksToExport() Then

                cboDrgRevAtt.Enabled = True
                cboBlockNames.Enabled = True
                cboBlockNames.BackColor = Color.Coral

            End If

            cboBlockNames.DataSource = Nothing

            cboBlockNames.DataSource = mBlockDataSet.Tables("BlockDetails").DefaultView.ToTable(True, "BlockName")
            cboBlockNames.DisplayMember = "BlockName"

        Else

            cboDrgRevAtt.Enabled = False
            cboBlockNames.Enabled = False
            cboDrgNoAtt.Enabled = False

        End If

        RefereshNewFileList()

    End Sub

    Private Sub cboBlockNames_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboBlockNames.SelectedValueChanged

        If cboBlockNames.SelectedItem IsNot Nothing Then

            Dim SelI As DataRowView = CType(cboBlockNames.SelectedItem, DataRowView)

            If SelI.Item("BlockName").ToString <> "No Blocks Found" Then

                cboDrgNoAtt.DataSource = Nothing
                cboDrgNoAtt.Items.Clear()

                cboBlockNames.BackColor = mDefColor
                cboDrgNoAtt.Enabled = True
                cboDrgRevAtt.Enabled = True
                cboDrgNoAtt.BackColor = Color.Coral

                If mBlockDataSet.Tables.Contains("SearchData") Then
                    mBlockDataSet.Tables.Remove("SearchData")
                    mBlockDataSet.AcceptChanges()
                End If

                Dim Dt_Temp As System.Data.DataTable = mBlockDataSet.Tables("BlockDetails").Clone
                Dt_Temp = mBlockDataSet.Tables("BlockDetails").Copy
                Dt_Temp.TableName = "SearchData"
                Dt_Temp.Columns.Remove("LayoutID")
                Dt_Temp.Columns.Remove("AttributeValue")
                mBlockDataSet.Tables.Add(Dt_Temp)
                mBlockDataSet.AcceptChanges()

                Dim FiltertedDT_Drg_NO As System.Data.DataTable = (From P In mBlockDataSet.Tables("SearchData").AsEnumerable() _
                                          .Where(Function(P) P.Field(Of String)("BlockName") = SelI.Item("BlockName").ToString)).CopyToDataTable().DefaultView.ToTable(True, "AttributeName")

                Dim FiltertedDT_Rev_NO As System.Data.DataTable = FiltertedDT_Drg_NO.Copy
                Dim DtRow As DataRow = FiltertedDT_Rev_NO.NewRow
                DtRow.Item("AttributeName") = ""
                FiltertedDT_Rev_NO.Rows.InsertAt(DtRow, 0)
                FiltertedDT_Rev_NO.AcceptChanges()
                'Dim FiltertedDTX As System.Data.DataTable = FiltertedDT.DefaultView.ToTable(True, "AttributeName")

                'Dim names = (From dr As DataRow In mBlockDataSet.Tables("BlockDetails").Rows Where dr("BlockName") = SelI.Item("BlockName")
                '             Select ).Distinct()

                cboDrgNoAtt.DataSource = FiltertedDT_Drg_NO
                cboDrgNoAtt.DisplayMember = "AttributeName"

                cboDrgRevAtt.DataSource = FiltertedDT_Rev_NO
                cboDrgRevAtt.DisplayMember = "AttributeName"


            Else


                cboDrgRevAtt.Enabled = False
                cboDrgNoAtt.Enabled = False
                cboDrgNoAtt.BackColor = mDefColor

            End If


        Else
            cboDrgRevAtt.Enabled = False
            cboDrgNoAtt.Enabled = False
            cboDrgNoAtt.BackColor = mDefColor
        End If

        RefereshNewFileList()

    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub cboDrgRevAtt_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDrgRevAtt.SelectedValueChanged
        RefereshNewFileList()
    End Sub

    Private Sub LayoutExportForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

End Class