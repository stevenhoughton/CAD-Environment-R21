﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LayoutExportForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LayoutExportForm))
        Me.pnlBanner = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.pnlButtonBtm = New System.Windows.Forms.Panel()
        Me.cmdRunFiles = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.tsslMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsslProgBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.pnlMainArea = New System.Windows.Forms.Panel()
        Me.pnlTools = New System.Windows.Forms.Panel()
        Me.gbxNamingOptions = New System.Windows.Forms.GroupBox()
        Me.lblDrgRevAtt = New System.Windows.Forms.Label()
        Me.cboDrgRevAtt = New System.Windows.Forms.ComboBox()
        Me.lblDrgNoAtt = New System.Windows.Forms.Label()
        Me.cboDrgNoAtt = New System.Windows.Forms.ComboBox()
        Me.cboBlockNames = New System.Windows.Forms.ComboBox()
        Me.chkNameByBlockAndAtt = New System.Windows.Forms.CheckBox()
        Me.txtExportSuffix = New System.Windows.Forms.TextBox()
        Me.lblExportSuffix = New System.Windows.Forms.Label()
        Me.txtExportPrefix = New System.Windows.Forms.TextBox()
        Me.lblExportPrefix = New System.Windows.Forms.Label()
        Me.cmdRefreshList = New System.Windows.Forms.Button()
        Me.lblNewFiles = New System.Windows.Forms.Label()
        Me.lstNewFiles = New System.Windows.Forms.ListBox()
        Me.chkLstLayouts = New System.Windows.Forms.CheckedListBox()
        Me.lblLayouts = New System.Windows.Forms.Label()
        Me.cmdBrowsePath = New System.Windows.Forms.Button()
        Me.txtSavePath = New System.Windows.Forms.TextBox()
        Me.lblSavePath = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.imlScripts = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pnlBanner.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlButtonBtm.SuspendLayout()
        Me.pnlMainArea.SuspendLayout()
        Me.pnlTools.SuspendLayout()
        Me.gbxNamingOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBanner
        '
        Me.pnlBanner.BackgroundImage = CType(resources.GetObject("pnlBanner.BackgroundImage"), System.Drawing.Image)
        Me.pnlBanner.Controls.Add(Me.lblTitle)
        Me.pnlBanner.Controls.Add(Me.LogoPictureBox)
        Me.pnlBanner.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBanner.Location = New System.Drawing.Point(0, 0)
        Me.pnlBanner.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlBanner.Name = "pnlBanner"
        Me.pnlBanner.Size = New System.Drawing.Size(997, 64)
        Me.pnlBanner.TabIndex = 38
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(197, 35)
        Me.lblTitle.TabIndex = 29
        Me.lblTitle.Text = "Layout Export"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 28
        Me.LogoPictureBox.TabStop = False
        '
        'pnlButtonBtm
        '
        Me.pnlButtonBtm.Controls.Add(Me.cmdRunFiles)
        Me.pnlButtonBtm.Controls.Add(Me.Cancel_Button)
        Me.pnlButtonBtm.Controls.Add(Me.cmdHelp)
        Me.pnlButtonBtm.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtonBtm.Location = New System.Drawing.Point(0, 483)
        Me.pnlButtonBtm.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlButtonBtm.MaximumSize = New System.Drawing.Size(0, 46)
        Me.pnlButtonBtm.MinimumSize = New System.Drawing.Size(0, 46)
        Me.pnlButtonBtm.Name = "pnlButtonBtm"
        Me.pnlButtonBtm.Padding = New System.Windows.Forms.Padding(16, 7, 16, 7)
        Me.pnlButtonBtm.Size = New System.Drawing.Size(997, 46)
        Me.pnlButtonBtm.TabIndex = 44
        '
        'cmdRunFiles
        '
        Me.cmdRunFiles.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRunFiles.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRunFiles.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmdRunFiles.Enabled = False
        Me.cmdRunFiles.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRunFiles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRunFiles.Location = New System.Drawing.Point(690, 7)
        Me.cmdRunFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdRunFiles.Name = "cmdRunFiles"
        Me.cmdRunFiles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRunFiles.Size = New System.Drawing.Size(159, 32)
        Me.cmdRunFiles.TabIndex = 34
        Me.cmdRunFiles.Text = "OK"
        Me.cmdRunFiles.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.Dock = System.Windows.Forms.DockStyle.Right
        Me.Cancel_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(849, 7)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(132, 32)
        Me.Cancel_Button.TabIndex = 35
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'cmdHelp
        '
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.Dock = System.Windows.Forms.DockStyle.Left
        Me.cmdHelp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(16, 7)
        Me.cmdHelp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(132, 32)
        Me.cmdHelp.TabIndex = 36
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 529)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(997, 22)
        Me.StatusStrip1.TabIndex = 43
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'tsslMessage
        '
        Me.tsslMessage.Name = "tsslMessage"
        Me.tsslMessage.Size = New System.Drawing.Size(12, 21)
        Me.tsslMessage.Text = "."
        '
        'tsslProgBar
        '
        Me.tsslProgBar.Name = "tsslProgBar"
        Me.tsslProgBar.Size = New System.Drawing.Size(133, 20)
        '
        'pnlMainArea
        '
        Me.pnlMainArea.Controls.Add(Me.pnlTools)
        Me.pnlMainArea.Controls.Add(Me.cmdBrowsePath)
        Me.pnlMainArea.Controls.Add(Me.txtSavePath)
        Me.pnlMainArea.Controls.Add(Me.lblSavePath)
        Me.pnlMainArea.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMainArea.Location = New System.Drawing.Point(0, 64)
        Me.pnlMainArea.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlMainArea.Name = "pnlMainArea"
        Me.pnlMainArea.Padding = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.pnlMainArea.Size = New System.Drawing.Size(997, 419)
        Me.pnlMainArea.TabIndex = 45
        '
        'pnlTools
        '
        Me.pnlTools.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlTools.Controls.Add(Me.gbxNamingOptions)
        Me.pnlTools.Controls.Add(Me.cmdRefreshList)
        Me.pnlTools.Controls.Add(Me.lblNewFiles)
        Me.pnlTools.Controls.Add(Me.lstNewFiles)
        Me.pnlTools.Controls.Add(Me.chkLstLayouts)
        Me.pnlTools.Controls.Add(Me.lblLayouts)
        Me.pnlTools.Location = New System.Drawing.Point(21, 65)
        Me.pnlTools.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlTools.Name = "pnlTools"
        Me.pnlTools.Size = New System.Drawing.Size(955, 342)
        Me.pnlTools.TabIndex = 12
        '
        'gbxNamingOptions
        '
        Me.gbxNamingOptions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxNamingOptions.Controls.Add(Me.lblDrgRevAtt)
        Me.gbxNamingOptions.Controls.Add(Me.cboDrgRevAtt)
        Me.gbxNamingOptions.Controls.Add(Me.lblDrgNoAtt)
        Me.gbxNamingOptions.Controls.Add(Me.cboDrgNoAtt)
        Me.gbxNamingOptions.Controls.Add(Me.cboBlockNames)
        Me.gbxNamingOptions.Controls.Add(Me.chkNameByBlockAndAtt)
        Me.gbxNamingOptions.Controls.Add(Me.txtExportSuffix)
        Me.gbxNamingOptions.Controls.Add(Me.lblExportSuffix)
        Me.gbxNamingOptions.Controls.Add(Me.txtExportPrefix)
        Me.gbxNamingOptions.Controls.Add(Me.lblExportPrefix)
        Me.gbxNamingOptions.Location = New System.Drawing.Point(13, 11)
        Me.gbxNamingOptions.Margin = New System.Windows.Forms.Padding(4)
        Me.gbxNamingOptions.Name = "gbxNamingOptions"
        Me.gbxNamingOptions.Padding = New System.Windows.Forms.Padding(4)
        Me.gbxNamingOptions.Size = New System.Drawing.Size(925, 85)
        Me.gbxNamingOptions.TabIndex = 53
        Me.gbxNamingOptions.TabStop = False
        Me.gbxNamingOptions.Text = "File Naming Options"
        '
        'lblDrgRevAtt
        '
        Me.lblDrgRevAtt.AutoSize = True
        Me.lblDrgRevAtt.Location = New System.Drawing.Point(584, 17)
        Me.lblDrgRevAtt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDrgRevAtt.Name = "lblDrgRevAtt"
        Me.lblDrgRevAtt.Size = New System.Drawing.Size(145, 17)
        Me.lblDrgRevAtt.TabIndex = 67
        Me.lblDrgRevAtt.Text = "Drawing Rev Attribute"
        '
        'cboDrgRevAtt
        '
        Me.cboDrgRevAtt.Enabled = False
        Me.cboDrgRevAtt.FormattingEnabled = True
        Me.cboDrgRevAtt.Location = New System.Drawing.Point(588, 41)
        Me.cboDrgRevAtt.Margin = New System.Windows.Forms.Padding(4)
        Me.cboDrgRevAtt.Name = "cboDrgRevAtt"
        Me.cboDrgRevAtt.Size = New System.Drawing.Size(168, 24)
        Me.cboDrgRevAtt.TabIndex = 66
        '
        'lblDrgNoAtt
        '
        Me.lblDrgNoAtt.AutoSize = True
        Me.lblDrgNoAtt.Location = New System.Drawing.Point(401, 18)
        Me.lblDrgNoAtt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDrgNoAtt.Name = "lblDrgNoAtt"
        Me.lblDrgNoAtt.Size = New System.Drawing.Size(170, 17)
        Me.lblDrgNoAtt.TabIndex = 65
        Me.lblDrgNoAtt.Text = "Drawing Number Attribute"
        '
        'cboDrgNoAtt
        '
        Me.cboDrgNoAtt.Enabled = False
        Me.cboDrgNoAtt.FormattingEnabled = True
        Me.cboDrgNoAtt.Location = New System.Drawing.Point(405, 42)
        Me.cboDrgNoAtt.Margin = New System.Windows.Forms.Padding(4)
        Me.cboDrgNoAtt.Name = "cboDrgNoAtt"
        Me.cboDrgNoAtt.Size = New System.Drawing.Size(173, 24)
        Me.cboDrgNoAtt.TabIndex = 64
        '
        'cboBlockNames
        '
        Me.cboBlockNames.Enabled = False
        Me.cboBlockNames.FormattingEnabled = True
        Me.cboBlockNames.Location = New System.Drawing.Point(160, 43)
        Me.cboBlockNames.Margin = New System.Windows.Forms.Padding(4)
        Me.cboBlockNames.Name = "cboBlockNames"
        Me.cboBlockNames.Size = New System.Drawing.Size(236, 24)
        Me.cboBlockNames.TabIndex = 63
        '
        'chkNameByBlockAndAtt
        '
        Me.chkNameByBlockAndAtt.AutoSize = True
        Me.chkNameByBlockAndAtt.Location = New System.Drawing.Point(164, 18)
        Me.chkNameByBlockAndAtt.Margin = New System.Windows.Forms.Padding(4)
        Me.chkNameByBlockAndAtt.Name = "chkNameByBlockAndAtt"
        Me.chkNameByBlockAndAtt.Size = New System.Drawing.Size(192, 21)
        Me.chkNameByBlockAndAtt.TabIndex = 62
        Me.chkNameByBlockAndAtt.Text = "Filename From Title Block"
        Me.chkNameByBlockAndAtt.UseVisualStyleBackColor = True
        '
        'txtExportSuffix
        '
        Me.txtExportSuffix.Location = New System.Drawing.Point(765, 42)
        Me.txtExportSuffix.Margin = New System.Windows.Forms.Padding(4)
        Me.txtExportSuffix.Name = "txtExportSuffix"
        Me.txtExportSuffix.Size = New System.Drawing.Size(151, 22)
        Me.txtExportSuffix.TabIndex = 61
        '
        'lblExportSuffix
        '
        Me.lblExportSuffix.AutoSize = True
        Me.lblExportSuffix.Location = New System.Drawing.Point(779, 20)
        Me.lblExportSuffix.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblExportSuffix.Name = "lblExportSuffix"
        Me.lblExportSuffix.Size = New System.Drawing.Size(112, 17)
        Me.lblExportSuffix.TabIndex = 60
        Me.lblExportSuffix.Text = "File Export Suffix"
        '
        'txtExportPrefix
        '
        Me.txtExportPrefix.Location = New System.Drawing.Point(8, 43)
        Me.txtExportPrefix.Margin = New System.Windows.Forms.Padding(4)
        Me.txtExportPrefix.Name = "txtExportPrefix"
        Me.txtExportPrefix.Size = New System.Drawing.Size(143, 22)
        Me.txtExportPrefix.TabIndex = 59
        '
        'lblExportPrefix
        '
        Me.lblExportPrefix.AutoSize = True
        Me.lblExportPrefix.Location = New System.Drawing.Point(20, 20)
        Me.lblExportPrefix.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblExportPrefix.Name = "lblExportPrefix"
        Me.lblExportPrefix.Size = New System.Drawing.Size(113, 17)
        Me.lblExportPrefix.TabIndex = 58
        Me.lblExportPrefix.Text = "File Export Prefix"
        '
        'cmdRefreshList
        '
        Me.cmdRefreshList.Enabled = False
        Me.cmdRefreshList.Font = New System.Drawing.Font("Wingdings 3", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdRefreshList.Location = New System.Drawing.Point(216, 103)
        Me.cmdRefreshList.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdRefreshList.Name = "cmdRefreshList"
        Me.cmdRefreshList.Size = New System.Drawing.Size(40, 40)
        Me.cmdRefreshList.TabIndex = 52
        Me.cmdRefreshList.Tag = "Clears Boths List and ReLoad all Layout Names from Current Drawing"
        Me.cmdRefreshList.Text = "Q"
        Me.cmdRefreshList.UseVisualStyleBackColor = True
        Me.cmdRefreshList.Visible = False
        '
        'lblNewFiles
        '
        Me.lblNewFiles.AutoSize = True
        Me.lblNewFiles.Enabled = False
        Me.lblNewFiles.Location = New System.Drawing.Point(265, 123)
        Me.lblNewFiles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNewFiles.Name = "lblNewFiles"
        Me.lblNewFiles.Size = New System.Drawing.Size(164, 17)
        Me.lblNewFiles.TabIndex = 51
        Me.lblNewFiles.Text = "New Files To Be Created"
        '
        'lstNewFiles
        '
        Me.lstNewFiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstNewFiles.FormattingEnabled = True
        Me.lstNewFiles.ItemHeight = 16
        Me.lstNewFiles.Location = New System.Drawing.Point(265, 146)
        Me.lstNewFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.lstNewFiles.Name = "lstNewFiles"
        Me.lstNewFiles.Size = New System.Drawing.Size(673, 164)
        Me.lstNewFiles.TabIndex = 50
        '
        'chkLstLayouts
        '
        Me.chkLstLayouts.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chkLstLayouts.CheckOnClick = True
        Me.chkLstLayouts.FormattingEnabled = True
        Me.chkLstLayouts.Location = New System.Drawing.Point(13, 146)
        Me.chkLstLayouts.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLstLayouts.Name = "chkLstLayouts"
        Me.chkLstLayouts.Size = New System.Drawing.Size(240, 157)
        Me.chkLstLayouts.TabIndex = 49
        '
        'lblLayouts
        '
        Me.lblLayouts.AutoSize = True
        Me.lblLayouts.Enabled = False
        Me.lblLayouts.Location = New System.Drawing.Point(13, 123)
        Me.lblLayouts.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLayouts.Name = "lblLayouts"
        Me.lblLayouts.Size = New System.Drawing.Size(123, 17)
        Me.lblLayouts.TabIndex = 48
        Me.lblLayouts.Text = "Layouts To Export"
        '
        'cmdBrowsePath
        '
        Me.cmdBrowsePath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdBrowsePath.Location = New System.Drawing.Point(832, 30)
        Me.cmdBrowsePath.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdBrowsePath.Name = "cmdBrowsePath"
        Me.cmdBrowsePath.Size = New System.Drawing.Size(144, 28)
        Me.cmdBrowsePath.TabIndex = 11
        Me.cmdBrowsePath.Text = "Browse"
        Me.cmdBrowsePath.UseVisualStyleBackColor = True
        '
        'txtSavePath
        '
        Me.txtSavePath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSavePath.Enabled = False
        Me.txtSavePath.Location = New System.Drawing.Point(21, 33)
        Me.txtSavePath.Margin = New System.Windows.Forms.Padding(4)
        Me.txtSavePath.Name = "txtSavePath"
        Me.txtSavePath.Size = New System.Drawing.Size(801, 22)
        Me.txtSavePath.TabIndex = 10
        '
        'lblSavePath
        '
        Me.lblSavePath.AutoSize = True
        Me.lblSavePath.Enabled = False
        Me.lblSavePath.Location = New System.Drawing.Point(27, 12)
        Me.lblSavePath.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSavePath.Name = "lblSavePath"
        Me.lblSavePath.Size = New System.Drawing.Size(132, 17)
        Me.lblSavePath.TabIndex = 9
        Me.lblSavePath.Text = "File Export Location"
        '
        'imlScripts
        '
        Me.imlScripts.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlScripts.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlScripts.TransparentColor = System.Drawing.Color.Transparent
        '
        'LayoutExportForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(997, 551)
        Me.Controls.Add(Me.pnlMainArea)
        Me.Controls.Add(Me.pnlButtonBtm)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.pnlBanner)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(1013, 588)
        Me.Name = "LayoutExportForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.pnlBanner.ResumeLayout(False)
        Me.pnlBanner.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlButtonBtm.ResumeLayout(False)
        Me.pnlMainArea.ResumeLayout(False)
        Me.pnlMainArea.PerformLayout()
        Me.pnlTools.ResumeLayout(False)
        Me.pnlTools.PerformLayout()
        Me.gbxNamingOptions.ResumeLayout(False)
        Me.gbxNamingOptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlBanner As System.Windows.Forms.Panel
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents pnlButtonBtm As System.Windows.Forms.Panel
    Public WithEvents cmdRunFiles As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents tsslMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsslProgBar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents pnlMainArea As System.Windows.Forms.Panel
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents imlScripts As System.Windows.Forms.ImageList
    Public WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents pnlTools As System.Windows.Forms.Panel
    Friend WithEvents gbxNamingOptions As System.Windows.Forms.GroupBox
    Friend WithEvents lblDrgRevAtt As System.Windows.Forms.Label
    Friend WithEvents cboDrgRevAtt As System.Windows.Forms.ComboBox
    Friend WithEvents lblDrgNoAtt As System.Windows.Forms.Label
    Friend WithEvents cboDrgNoAtt As System.Windows.Forms.ComboBox
    Friend WithEvents cboBlockNames As System.Windows.Forms.ComboBox
    Friend WithEvents chkNameByBlockAndAtt As System.Windows.Forms.CheckBox
    Friend WithEvents txtExportSuffix As System.Windows.Forms.TextBox
    Friend WithEvents lblExportSuffix As System.Windows.Forms.Label
    Friend WithEvents txtExportPrefix As System.Windows.Forms.TextBox
    Friend WithEvents lblExportPrefix As System.Windows.Forms.Label
    Friend WithEvents cmdRefreshList As System.Windows.Forms.Button
    Friend WithEvents lblNewFiles As System.Windows.Forms.Label
    Friend WithEvents lstNewFiles As System.Windows.Forms.ListBox
    Friend WithEvents chkLstLayouts As System.Windows.Forms.CheckedListBox
    Friend WithEvents lblLayouts As System.Windows.Forms.Label
    Friend WithEvents cmdBrowsePath As System.Windows.Forms.Button
    Friend WithEvents txtSavePath As System.Windows.Forms.TextBox
    Friend WithEvents lblSavePath As System.Windows.Forms.Label
End Class
