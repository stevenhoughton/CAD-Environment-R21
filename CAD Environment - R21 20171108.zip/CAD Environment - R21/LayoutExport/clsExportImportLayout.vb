﻿Imports Autodesk.AutoCAD.Colors
Imports Autodesk.AutoCAD.GraphicsInterface
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.AutoCAD.Utilities
Imports System.IO
Imports Jacobs.Common.Settings

Public Class clsExportImportLayout

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Private mCopyMethod As Integer = 0 '0 = Copy Out, 1 = Import
    Private mExportName As String = ""
    Private mLayoutName As String = ""

    Public Sub New(ByVal ToOutOrIn As Integer)
        mCopyMethod = ToOutOrIn
    End Sub

    Public Property LayoutName() As String
        Get
            Return mLayoutName
        End Get
        Set(ByVal value As String)
            mLayoutName = value
        End Set
    End Property

    Public Property ExportName() As String
        Get
            Return mExportName
        End Get
        Set(ByVal value As String)
            mExportName = value
        End Set
    End Property

    Public Sub PreformExportImport()

        Select Case mCopyMethod
            Case 0
                copyLayoutToNewDwg()
            Case 1
                'Do nothing just yet
        End Select
    End Sub

    Private Sub copyLayoutToNewDwg()

        Dim CurrentDoc As Document = Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = CurrentDoc.Editor()

        Dim layout As New Layout
        Dim layoutNameInCurDwg As String = LayoutName
        Dim lytMgr As LayoutManager

        Dim layoutId As ObjectId

        'Get orignal drawing
        Dim SourceDB As Database = Application.DocumentManager.MdiActiveDocument.Database
        Dim MyLayers As List(Of clsLayerDetails) = GetAllLayersPropertiesFromCurrentFile()

        Try

            Using DokLock As DocumentLock = CurrentDoc.LockDocument

                'create a new drawing
                Dim newDb As Database = New Database(True, False)
                Using tr As Transaction = newDb.TransactionManager.StartTransaction()

                    'Make the working database the new database
                    HostApplicationServices.WorkingDatabase = newDb
                    Dim lytDict_Dest As DBDictionary = CType(tr.GetObject(newDb.LayoutDictionaryId, OpenMode.ForRead), DBDictionary)
                    Dim NewDBBlockTable As BlockTable = CType(tr.GetObject(newDb.BlockTableId, OpenMode.ForWrite), BlockTable)

                    ' Create a new Layout
                    Dim newLytMgr As LayoutManager = LayoutManager.Current()

                    'rename Default layouts
                    newLytMgr.RenameLayout("Layout1", "Layout1ABC")
                    newLytMgr.RenameLayout("Layout2", "Layout2ABC")

                    'check to see if new wanted layout exists
                    If lytDict_Dest.Contains(LayoutName) Then
                        'Delete id exist.  IN princiapl should never exist
                        newLytMgr.DeleteLayout(LayoutName)
                    End If

                    'Create New layout
                    Dim newLayoutId As ObjectId = newLytMgr.CreateLayout(LayoutName)

                    'Delete Renamed Layouts
                    newLytMgr.DeleteLayout("Layout1ABC")
                    newLytMgr.DeleteLayout("Layout2ABC")

                    newLytMgr.CurrentLayout = (LayoutName)

                    Dim newLayout As Layout = CType(tr.GetObject(newLayoutId, OpenMode.ForWrite), Autodesk.AutoCAD.DatabaseServices.Layout)
                    Dim VPTable As ViewportTable = CType(tr.GetObject(newDb.ViewportTableId, OpenMode.ForWrite), ViewportTable)

                    ''Make the original database the working database
                    HostApplicationServices.WorkingDatabase = SourceDB
                    Using tr2 As Transaction = SourceDB.TransactionManager.StartTransaction()

                        ' Get the dictionary of the original database
                        Dim lytDict_Source As DBDictionary = CType(tr2.GetObject(SourceDB.LayoutDictionaryId, OpenMode.ForRead), DBDictionary)
                        'Make sure the layout existed in the original database
                        If Not lytDict_Source.Contains(layoutNameInCurDwg) Then
                            ed.WriteMessage("Layout named ""Layout1"" does not exist in current dwg")
                            Return
                        End If

                        'Get the layout in the original database
                        lytMgr = LayoutManager.Current()
                        layoutId = lytMgr.GetLayoutId(layoutNameInCurDwg)
                        layout = CType(tr2.GetObject(layoutId, OpenMode.ForRead), Autodesk.AutoCAD.DatabaseServices.Layout)

                        newLayout.CopyFrom(layout)

                        'Get the block table record of the existing layout
                        Dim blkTableRec As BlockTableRecord
                        blkTableRec = CType(tr2.GetObject(layout.BlockTableRecordId, OpenMode.ForRead), BlockTableRecord)

                        'Get the object ids of the objects in the existing block table record
                        Dim objIdCol As New ObjectIdCollection()
                        For Each objId As ObjectId In blkTableRec
                            objIdCol.Add(objId)
                        Next

                        ' Clone the objects to the new layout
                        Dim idMap As IdMapping = New IdMapping()
                        newDb.WblockCloneObjects(objIdCol,
                                                 newLayout.BlockTableRecordId,
                                                 idMap,
                                                 DuplicateRecordCloning.Replace,
                                                 False)
                        tr2.Commit()

                    End Using


                    Dim NewDBExtensionDictionary As New DBDictionary
                    Dim Dict1 As DBDictionary = New DBDictionary()
                    Dim Dict2 As DBDictionary = New DBDictionary()

                    Try
                        NewDBExtensionDictionary = CType(tr.GetObject(NewDBBlockTable.ExtensionDictionary, OpenMode.ForWrite), DBDictionary)
                    Catch ex As Exception
                        NewDBBlockTable.CreateExtensionDictionary()
                        NewDBExtensionDictionary = CType(tr.GetObject(NewDBBlockTable.ExtensionDictionary, OpenMode.ForWrite), DBDictionary)
                    End Try

                    Try
                        NewDBExtensionDictionary.SetAt("SKM_RULES", Dict1)
                        tr.AddNewlyCreatedDBObject(Dict1, True)

                        NewDBExtensionDictionary.SetAt("SKM_WORKING_VARIABLES", Dict2)
                        tr.AddNewlyCreatedDBObject(Dict2, True)

                    Catch ex As Exception
                        MsgBox("Error Producing New Dictionary")
                    End Try

                    HostApplicationServices.WorkingDatabase = SourceDB
                    Using tr3 As Transaction = SourceDB.TransactionManager.StartTransaction()

                        'Get Extension Dictionary
                        Dim blkTable As BlockTable
                        blkTable = CType(tr3.GetObject(SourceDB.BlockTableId, OpenMode.ForRead), BlockTable)

                        Dim ExistExtensionDictionary As DBDictionary
                        ExistExtensionDictionary = CType(tr3.GetObject(blkTable.ExtensionDictionary(), OpenMode.ForRead, False), DBDictionary)

                        ''Get the object ids of the objects in the existing block table record
                        Dim objIdCol As New ObjectIdCollection()

                        Dim DataDic As DBDictionary = CType(tr3.GetObject(ExistExtensionDictionary.GetAt("SKM_RULES"), OpenMode.ForRead), DBDictionary)

                        Dim DicKeys As IDictionary = DataDic

                        For Each X As String In DicKeys.Keys
                            'ed.WriteMessage(X & vbCrLf)
                            objIdCol.Add(DataDic.GetAt(X))

                            Dim ExistingRec As Xrecord = CType(tr3.GetObject(CType(DataDic(X), ObjectId), OpenMode.ForRead), Xrecord)
                            Dim ExData As ResultBuffer = ExistingRec.Data

                            Dim mgrXRec As Xrecord = New Xrecord()
                            mgrXRec.Data = ExData
                            Dict1.SetAt(X, mgrXRec)
                            tr.AddNewlyCreatedDBObject(mgrXRec, True)

                        Next

                        tr3.Commit()

                    End Using

                    HostApplicationServices.WorkingDatabase = SourceDB
                    Using tr4 As Transaction = SourceDB.TransactionManager.StartTransaction()

                        Dim blkTable As BlockTable
                        blkTable = CType(tr4.GetObject(SourceDB.BlockTableId, OpenMode.ForRead), BlockTable)

                        Dim ExistExtensionDictionary As DBDictionary
                        ExistExtensionDictionary = CType(tr4.GetObject(blkTable.ExtensionDictionary(), OpenMode.ForRead, False), DBDictionary)

                        Dim objIdCol As New ObjectIdCollection()

                        Dim DataDic As DBDictionary = CType(tr4.GetObject(ExistExtensionDictionary.GetAt("SKM_WORKING_VARIABLES"), OpenMode.ForRead), DBDictionary)
                        Dim DicKeys As IDictionary = DataDic

                        For Each X As String In DicKeys.Keys
                            objIdCol.Add(DataDic.GetAt(X))

                            Dim ExistingRec As Xrecord = CType(tr4.GetObject(CType(DataDic(X), ObjectId), OpenMode.ForRead), Xrecord)
                            Dim ExData As ResultBuffer = ExistingRec.Data

                            Dim mgrXRec As Xrecord = New Xrecord()
                            mgrXRec.Data = ExData
                            Dict2.SetAt(X, mgrXRec)
                            tr.AddNewlyCreatedDBObject(mgrXRec, True)

                        Next

                        tr4.Commit()

                    End Using


                    ' get the model space object ids for both dbs
                    Dim sourceMsId As ObjectId = SymbolUtilityServices.GetBlockModelSpaceId(SourceDB)
                    Dim destDbMsId As ObjectId = SymbolUtilityServices.GetBlockModelSpaceId(newDb)

                    ' now create an array of object ids to hold the source objects to copy
                    Dim sourceIds As New ObjectIdCollection()

                    ' open the sourceDb ModelSpace (current autocad dwg)
                    Using ms As BlockTableRecord = CType(tr.GetObject(sourceMsId, OpenMode.ForRead), BlockTableRecord)
                        ' loop all the entities and record their ids
                        For Each id As ObjectId In ms
                            sourceIds.Add(id)
                        Next
                    End Using

                    ' next prepare to deepclone the recorded ids to the destdb
                    Dim mapping As New IdMapping()
                    ' now clone the objects into the destdb
                    SourceDB.WblockCloneObjects(sourceIds, destDbMsId, mapping, DuplicateRecordCloning.Replace, False)
                    'destDb.SaveAs("c:\temp\dwgs\CopyTest.dwg", DwgVersion.Current)

                    'End Using
                    tr.Commit()

                    'Save File
                    newDb.SaveAs(ExportName, DwgVersion.Current)

                End Using

                Dim TempFile As String = ExportName.Replace(".dwg", "x.dwg")
                Dim Changed As Boolean = ExecuteExistingLayerMapping(newDb, MyLayers, TempFile, True) '<-- Change to false once we go to production

                If Changed Then
                    If File.Exists(TempFile) Then
                        File.Delete(ExportName)
                        File.Move(TempFile, ExportName)
                    End If
                End If


            End Using

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub
End Class
