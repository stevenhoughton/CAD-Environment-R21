#Region "Imports"

Imports System.IO
Imports AcadAppStartUp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Autodesk.AutoCAD.ApplicationServices    'Access to the AutoCAD application
Imports Autodesk.AutoCAD.Runtime                'Command registration copy
Imports Autodesk.AutoCAD.DatabaseServices       'DataBase
'Imports Autodesk.AutoCAD.Customization
Imports System.Windows.Forms
Imports Autodesk.AutoCAD.Interop
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Settings
'Imports Jacobs.AutoCAD.StartUpTab
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension
Imports Autodesk.AutoCAD.EditorInput

#End Region

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.StartUp.StartUp))>

Public Class StartUp
    Implements Autodesk.AutoCAD.Runtime.IExtensionApplication

#Region "Variables"

    Public WithEvents ThisDrawingStartUp As AcadDocument = CType(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)
    Public WithEvents docs As DocumentCollection = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager

    Public sConfigurationPath As String
    Public sDrawingConfigName As String
    Public CurrPlotStylePath As String ' Stores the Plot Style search path before changing it
    Public currQNEWTemplate As String

    Public Shared oLayerMan As New LayerEvent(True)
    Dim LogName As String = ""

#End Region

#Region "Events"

    Private Sub CommandEndedEvent(ByVal senderObj As Object, ByVal e As CommandEventArgs)

        Try
            ' If this is not a configured drawing stop now
            If ThisDrawingIsConfigured() = False Then Exit Sub

            Dim dScaleFactor As Double

            ' If the command that just ended contains the words DROPGEOM or INSERT then this was a block insertion or a drag and drop command.
            If e.GlobalCommandName.Contains("DROPGEOM") Or e.GlobalCommandName.Contains("INSERT") Then

                ' Since this is after the event the last entity inserted in the drawing must have been the block that we wish to scale 
                Dim myobject As Autodesk.AutoCAD.Interop.Common.AcadObject = entlast()
                If myobject IsNot Nothing Then
                    ' If we did find an entity check if that entity was a block
                    If myobject.ObjectName = "AcDbBlockReference" Then
                        ' Type convert the entity to an AutoCAD block reference..
                        Dim blk As AcadBlockReference = CType(myobject, AcadBlockReference)
                        ' If it has then check that the block we have just inserted is not UNITLESS as this would mean that we can't scale the block at all
                        If blk.InsUnits.ToUpper = "UNITLESS" Then
                            Acad_MessageBox("The inserted block was unit-less AE cannot work out scale to use.", , , , , , , True, LogName)
                            ' No point going any further here we don't know what units the block was draw in hence we can't scale
                            Exit Sub
                        End If

                        ' Check the scale tool rule to see if the Template has been set to scale blocks using dimscale... (don't ignore tool overrides if present)
                        If RuleAccessors.GetruleValue("SCALE7", "False", False, True).ToString.IsTrue Then

                            If CDbl(ThisDrawingUtilities.GetVariable("DIMSCALE")) = 0.0# Then
                                If WhichSpace() = "FloatingModelSpace" Then
                                    dScaleFactor = 1.0# / System.Math.Round(ThisDrawingUtilities.ActivePViewport.CustomScale, 6)
                                Else
                                    dScaleFactor = 1.0#
                                End If
                            Else
                                dScaleFactor = CDbl(ThisDrawingUtilities.GetVariable("DIMSCALE"))
                            End If

                            ' This convoluted workaround was introduced in AutoCAD 2017 when the DROPGEOM end command started firing off twice
                            ' the code attempts to stop the block from being scaled twice.
                            Dim res As Long = 0
                            If WorkingVariableAccessors.GetWorkVarValue("LASTSCALEDBLOCKID") = "" Then
                                res = 0
                            Else
                                res = CLng(CDbl(WorkingVariableAccessors.GetWorkVarValue("LASTSCALEDBLOCKID")))
                            End If

                            If blk.ObjectID = res Then
                                ' Same block already scaled
                            Else
                                Acad_MessageBox("The inserted block set to: " & blk.InsUnits.ToUpper & " current drawing is set to: " & InsunitsToStr(CInt(ThisDrawingUtilities.GetVariable("INSUNITS"))) & " Scale factor = " & dScaleFactor, , , , , , , True, LogName)
                                blk.ScaleEntity(blk.InsertionPoint, dScaleFactor)
                                WorkingVariableAccessors.AddWorkVar("LASTSCALEDBLOCKID", blk.ObjectID)
                            End If

                        End If
                        ' Scale, Layer block as per the blocks.csv file
                        'ProcessBlock(blk)
                    End If
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub LayoutSwitchedEvent(ByVal senderObj As Object, ByVal e As LayoutSwitchedEventArgs)

        ' If this is not a configured drawing stop now
        If ThisDrawingIsConfigured() = False Then Exit Sub

        ' Check if UCFOLLOW is set to 1
        If CInt(ThisDrawingStartUp.GetVariable("UCSFOLLOW")) = 1 Then
            If WhichSpace() = "FloatingModelSpace" Then
                If ThisDrawingStartUp.ActivePViewport.DisplayLocked = False Then
                    ' Scale Tool Section
                    Acad_MessageBox("Since UCSFOLLOW is set to 1 - AE Switch Scale Tool System Variable Functionality has been disabled until the view port is unlocked or change UCSFollow to 0", , , , , , , True, LogName)
                    ' Dimensions Tool Section
                    Acad_MessageBox("Since UCSFOLLOW is set to 1 - AE Switch Dimensions Tool System Variable Functionality has been disabled until the view port is unlocked or change UCSFollow to 0", , , , , , , True, LogName)
                    ' Text Tool Section
                    Acad_MessageBox("Since UCSFOLLOW is set to 1 - AE Switch Text Tool System Variable Functionality has been disabled until the view port is unlocked or change UCSFollow to 0", , , , , , , True, LogName)
                    Exit Sub
                End If
            End If
        End If

        If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

            Dim bIgnoreOverrides As Boolean

            ' Scale Tool Section
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "False").ToString.IsTrue

            ' Is the tick box selected to say that we want to change sysvars when switching layouts
            If RuleAccessors.GetruleValue("SCALE3", "True", bIgnoreOverrides, True).ToString.IsTrue Then
                ChangeScaleSysVars()
            End If

            ' Dimensions Tool Section
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("DIMENSIONSClientConfig", "False").IsTrue
            ' Is the tick box selected to say that we want to change sysvars when switching layouts
            If RuleAccessors.GetruleValue("DIM6", "True", bIgnoreOverrides, True).ToString.IsTrue Then ' Is the tick box selected to say that we want to change sysvars when switching layouts
                ChangeDimensionSysVars()
            End If

            ' Text Tool Section
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue
            ' Is the tick box selected to say that we want to change sysvars when switching layouts
            If RuleAccessors.GetruleValue("TEXT23", "True", bIgnoreOverrides, True).ToString.IsTrue Then
                ChangeTextSysVars()
            End If

        End If

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="senderObj"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub CommandWillStartEvent(ByVal senderObj As Object, ByVal e As CommandEventArgs)
        Try
            If UCase("AI_EDITCUSTFILE") = UCase(e.GlobalCommandName) Then
                Acad_MessageBox("Ensure that you change your aliases in the " & vbCrLf & Replace(ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString, "\\", "\") & "Support\USER.PGP file for the changes to be permanent." &
                                vbCrLf & "Changes made to the Acad.PGP file will only apply for this drawing session", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' </summary>
    ''' <param name="senderObj"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub LispWillStartEvent(ByVal senderObj As Object, ByVal e As LispWillStartEventArgs)
        Try
            If UCase(e.FirstLine) = UCase("(C:ALIASEDIT)") Then
                Acad_MessageBox("Ensure that you change your aliases in the " & vbCrLf _
                                & Replace(ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString, "\\", "\") & "Support\USER.PGP file for the changes to be permanent." & vbCrLf _
                                & "Changes made to the Acad.PGP file will only apply for this drawing session", "",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' Event to call the clean up of Template Settings
    ''' </summary>
    ''' <param name="senderObj"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Public Sub BeginDocumentCloseEvent(ByVal senderObj As Object, ByVal e As DocumentBeginCloseEventArgs)
        Try

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                UnconfigureSession()

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Public Sub Terminate() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Terminate

    End Sub

#End Region

#Region "StartHere"

    ''' <summary>
    ''' This is the primary startup routine of the AE - it runs once per autocad session and is responsible for cleaning up last run and 
    ''' configuring autocad. Once it has been configured it records that it was done for this user so that it does not execute next time.
    ''' irrespective weather a drawing is configured or not.
    ''' </summary>
    ''' <remarks></remarks>

    Public Sub Initialize() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Initialize

        '' Work out log name
        LogName = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        ' Jacobs.AutoCAD.StartUp

        '' Place-mark the AutoCAD drawing database.. DBMOD
        AcadAppStartUp.DocumentManager.MdiActiveDocument.PushDbmod()
        Try
            '' Subscribe to the DocumentActivated event and the Configured event"
            AddHandler docs.DocumentActivated, AddressOf DocumentActivatedEvent
            AddHandler ConfigurationEvents.Configured, AddressOf Me.OnConfigured
            AddHandler AcadAppStartUp.SystemVariableChanged, AddressOf SysVarChangedEvent

            ' Place mark the AutoCAD drawing database.. DBMOD 
            '            AcadAppStartUp.DocumentManager.MdiActiveDocument.PushDbmod()

            '  MsgBox("' 1")
            ' If a user had overridden the original Settings then they will be honored.
            GetConfigSettings()

            ' MsgBox("' 2")
            CleanPreviousRun()

            ' End If

            ' Setup AutoCAD environment variables, system variables, shortcuts and paths
            CustomiseAutoCAD()

            ' Since the document activated event does not always fire off every time a document is activated. 
            ' For example launching Autocad from a shortcut versus launching autocad from a dwg file which uses the applauncher.
            ' This does cause the every time event to fire off unnecessarily in some cases but if it was not called then there would be scenarios when it does not fire off.
            ConfigureSessionIfRequired()

            '' Advise User that AutoCAD has been configured
            Acad_MessageBox(Settings.Manager.AutoCAD.Name & " has been customised by Support team.", , , , , , , True, LogName)

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                ChangeScaleSysVars()
                ChangeDimensionSysVars()
                ChangeTextSysVars()
                ConfigurationSettings()

            Else

                StripScaleFromModeMacro()

            End If

            'Enabled during testing
            ConfigurationSettings()

            ' '' Check to see if we are in a Template DWG file and if we are in the middle of creating a new one, modifying existing or create using
            CheckIfBuildingTemplateInProgress()

            AcadAppStartUp.DocumentManager.MdiActiveDocument.PopDbmod()

        Catch ex As Exception

            AcadAppStartUp.DocumentManager.MdiActiveDocument.PopDbmod()
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

        End Try

    End Sub

#End Region

#Region "Helpers"

    Private Sub SysVarChangedEvent(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.SystemVariableChangedEventArgs)

        Dim SysVarname As String = e.Name

        ' This only needs to run when there is a change of view port
        If SysVarname = "CVPORT" Then

            If ThisDrawingIsConfigured() = False Then Exit Sub

            ' Check if UCFOLLOW is set to 1
            If CInt(ThisDrawingStartUp.GetVariable("UCSFOLLOW")) = 1 Then
                If WhichSpace() = "FloatingModelSpace" Then
                    If ThisDrawingStartUp.ActivePViewport.DisplayLocked = False Then
                        ' Scale Tool Section
                        Acad_MessageBox("Since UCSFOLLOW is set to 1 - AE Switch Scale Tool System Variable Functionality has been disabled until the the viewport is unlocked or change UCSFollow to 0", , , , , , , True, LogName)
                        ' Dimensions Tool Section
                        Acad_MessageBox("Since UCSFOLLOW is set to 1 - AE Switch Dimensions Tool System Variable Functionality has been disabled until the the viewport is unlocked or change UCSFollow to 0", , , , , , , True, LogName)
                        ' Text Tool Section
                        Acad_MessageBox("Since UCSFOLLOW is set to 1 - AE Switch Text Tool System Variable Functionality has been disabled until the the viewport is unlocked or change UCSFollow to 0", , , , , , , True, LogName)
                        Exit Sub
                    End If
                End If
            End If

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then
                Dim bIgnoreOverrides As Boolean

                ' Scale Tool Section
                bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "False").ToString.IsTrue
                ' Is the tick box selected to say that we want to change sysvars when switching vieports
                If RuleAccessors.GetruleValue("SCALE14", "True", bIgnoreOverrides, True).ToString.IsTrue Then
                    ChangeScaleSysVars()
                End If

                ' Dimensions Tool Section
                bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("DIMENSIONSClientConfig", "False").IsTrue
                ' Is the tick box selected to say that we want to change sysvars when switching vieports
                If RuleAccessors.GetruleValue("DIM8", "True", bIgnoreOverrides, True).ToString.IsTrue Then ' Is the tickbox selected to say that we want to change sysvars when switching layouts
                    ChangeDimensionSysVars()
                End If

                ' Text Tool Section
                bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue
                ' Is the tick box selected to say that we want to change sysvars when switching vieports
                If RuleAccessors.GetruleValue("TEXT27", "True", bIgnoreOverrides, True).ToString.IsTrue Then
                    ChangeTextSysVars()
                End If
            End If

        End If

    End Sub

    ''' <summary>
    ''' The on configured event ensures that every time a drawing is configured while autocad is in session the Template gets 
    ''' cleaned out and the new one is set up
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub OnConfigured()

        ConfigureSessionIfRequired()

        If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then
            ChangeScaleSysVars()
            ChangeDimensionSysVars()
            ChangeTextSysVars()
        End If

    End Sub

    Private Sub DocumentActivatedEvent(ByVal senderObj As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.DocumentCollectionEventArgs)

        Try
            '' Get the current document
            Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
            'Checks if the current document is available
            If acDoc IsNot Nothing Then

                '' Add the events we wish to listen for
                AddHandler acDoc.BeginDocumentClose, AddressOf BeginDocumentCloseEvent
                AddHandler acDoc.LayoutSwitched, AddressOf LayoutSwitchedEvent
                AddHandler acDoc.CommandEnded, AddressOf CommandEndedEvent
                AddHandler acDoc.LispWillStart, AddressOf LispWillStartEvent
                AddHandler acDoc.CommandWillStart, AddressOf CommandWillStartEvent

                '' Ensure we always have the current drawing in ThisDrawing variable - as we are relying on a few of it's events
                ThisDrawingStartUp = CType(e.Document.GetAcadDocument, AcadDocument)

                ' Since the document activated event does not always fire off every time a document is activated. 
                ' For example launching autocad from a shortcut versus launching autocad from a dwg file which uses the applauncher.
                ' This does cause the every time event to fire off necessarily in some cases but if it was not called then there would be scenarions when it does not fire off.
                ConfigureSessionIfRequired()

                If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                    ChangeScaleSysVars()
                    ChangeDimensionSysVars()
                    ChangeTextSysVars()

                End If
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' This is more for cleaning Content Wizard runs than Template Settings
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CleanPreviousRun()

        Try

            ' Delete any left over keys from ContentWizard run or crashes runs
            RemoveRegKeysFromPreviousRun()

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                UnconfigureSession()

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Check to see if this DWG file had a FULLCONFIGNAME and CONFIGLEVEL rule present and if so prep the session for a configured drawing
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ConfigureSessionIfRequired()

        Try

            UnconfigureSession()

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                If GetruleValue("FULLCONFIGNAME").Contains("fullconfigname") Then
                    '' Invert Description and rule value
                    Dim x As New Rule
                    x = GetRule("FULLCONFIGNAME")
                    '                    MsgBox("Fixing Config Error: " & x.value & " and " & x.Description)
                    AddRule("FULLCONFIGNAME", x.Description, x.value, x.DlgCode.ToString, x.TableCode.ToString)
                End If

                CheckForConfigUpdates()
                setconfigpath()
                DestroyNDrivePlotStyleShortCut()
                ConfigureAutoCADSession()
                ReInitFonts()

            End If

            Setup_Display()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' This is the Template stripping sub - it will remove all Template elements but will keep the rules
    ''' As this can be called to reset a configuration
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub UnconfigureSession()

        Try
            '' Remove Configuration Related Paths by removing any path that contains 3 hyphens
            DestroySearchPath()

            '' Remove Configuration Related Plot Style Paths by removing any path that contains 3 hyphens
            DestroyPlotStyleSearchPath()

            '' Remove Configuration Related Palette Paths by removing any path that contains 3 hyphens
            DestroyPalettePath()

            ' Remove QNEW Template File if it contains 3 hyphens - revert back to a presaved one if present - else set to none
            SetQNEWPathNone()

            ' Don't delete this because it causes config plot style shortcuts not to get generated
            DeleteOldConfigurationFiles()

            StripScaleFromModeMacro()


            '' Configuration Plot Style Paths, Plotters, PMP and PC3 Paths have now been removed - so we now need to revert to office paths if present
            '' These are honored by AutoCAD any files in these paths will be found
            ' This happens every time autocad starts up
            CreateShortCuts(Settings.Manager.AutoCAD.NetworkSupportShortcutName, Settings.Manager.AutoCAD.UserSettingsFolder, Settings.Manager.AutoCAD.NetworkSupportFolder, Settings.Manager.AutoCAD.CreateSupportShortCut)

            CreateShortCuts(Settings.Manager.AutoCAD.NetworkPMPShortcutName, Settings.Manager.AutoCAD.UserRoamingPMPFilesFolder, Settings.Manager.AutoCAD.NetworkPMPFolder, Settings.Manager.AutoCAD.CreatePMPShortCut)

            CreateShortCuts(Settings.Manager.AutoCAD.NetworkPlotStylesShortcutName, Settings.Manager.AutoCAD.UserRoamingPlotStylesFolder, Settings.Manager.AutoCAD.NetworkPlotStyleFolder, Settings.Manager.AutoCAD.CreatePlotStyleShortCut)

            CreateShortCuts(Settings.Manager.AutoCAD.NetworkPC3ShortcutName, Settings.Manager.AutoCAD.UserRoamingPlottersFolder, Settings.Manager.AutoCAD.NetworkPC3Folder, Settings.Manager.AutoCAD.CreatePC3ShortCut)

            CreateShortCuts(Settings.Manager.AutoCAD.NetworkTemplateShortcutName, Settings.Manager.AutoCAD.UserLocalTemplateFolder, Settings.Manager.AutoCAD.NetworkTemplateFolder, Settings.Manager.AutoCAD.CreateTemplateShortCut, False)

            CreateShortCuts(Settings.Manager.AutoCAD.NetworkBlockFinderShortcutName, Settings.Manager.AutoCAD.UserSettingsFolder, Settings.Manager.AutoCAD.NetworkBlockFinderFolder, Settings.Manager.AutoCAD.CreateBlockFinderShortCut)

            ' Recreate Pallet Paths
            SetPalettePath(Settings.Manager.AutoCAD.ToolPalettePath, True)

            ' QNEW is recreated when we set path to none
            SetQNEWPathNone()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub CustomDictionary()
        Try
            If Settings.Manager.AE.AutoCADHasBeenCustomised.ToString.IsTrue = False Then

                If Settings.Manager.AutoCAD.UseOfficeCustomDictionary = True Then
                    If File.Exists(Settings.Manager.AutoCAD.NetworkDictionaryFolder.CombinePath(Settings.Manager.AutoCAD.CustomDictionary)) = True Then
                        ThisDrawingStartUp.SetVariable("DCTCUST", Settings.Manager.AutoCAD.NetworkDictionaryFolder.CombinePath(Settings.Manager.AutoCAD.CustomDictionary))
                        Acad_MessageBox("Using office custom dictionary located here: " & Settings.Manager.AutoCAD.NetworkDictionaryFolder.CombinePath(Settings.Manager.AutoCAD.CustomDictionary), , , , , , , True, LogName)
                    Else
                        If File.Exists(ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString & "Support\Sample.cus") Then
                            ThisDrawingStartUp.SetVariable("DCTCUST", ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString & "Support\Sample.cus")
                            Acad_MessageBox("Using local custom dictionary located here: " & ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString & "Support\Sample.cus", , , , , , , True, LogName)
                        End If
                    End If
                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub RestoreOriginalAutoCADFontsQuiet()
        Try
            Dim sFiles() As String
            Dim vFile() As String
            Dim sFile As String

            sFiles = Directory.GetFiles(Settings.Manager.AutoCAD.UserRoamingSupportFolder)
            For Each sFile In sFiles
                If UCase(sFile) Like UCase("*.sh*") = True Then
                    vFile = Split(sFile, "\")
                    sFile = vFile(UBound(vFile))
                    Try
                        File.SetAttributes(Settings.Manager.AutoCAD.UserRoamingSupportFolder & "\" & sFile, FileAttributes.Normal)
                        File.Delete(Settings.Manager.AutoCAD.UserRoamingSupportFolder & "\" & sFile)
                    Catch
                    End Try
                End If
            Next

            Acad_MessageBox("All Fonts in the " & Settings.Manager.AutoCAD.UserRoamingSupportFolder & " folder have been deleted.", , , , , , , True, LogName)

            sFiles = Directory.GetFiles(Settings.Manager.AutoCAD.CachedFontsFolder)
            For Each sFile In sFiles
                If UCase(sFile) Like UCase("*.sh*") = True Then
                    vFile = Split(sFile, "\")
                    sFile = vFile(UBound(vFile))
                    File.Copy(Settings.Manager.AutoCAD.CachedFontsFolder.CombinePath(sFile), Settings.Manager.AutoCAD.UserRoamingSupportFolder.CombinePath(sFile), True)
                End If
            Next
            Acad_MessageBox("Original AutoCAD cached Fonts have been restored.", , , , , , , True, LogName)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub CreateShortCuts(ByVal sShortCutName As String, ByVal sFolder As String, ByVal stargetPath As String, ByVal DoIt As Boolean, Optional ByVal Roamable As Boolean = True)
        Try

            If Roamable = False Then
                sFolder = sFolder.Replace("\Roaming\", "\Local\")
            End If

            If File.Exists(sFolder.CombinePath(sShortCutName)) Then
                File.Delete(sFolder.CombinePath(sShortCutName))
            End If

            If DoIt = True Then
                If Directory.Exists(stargetPath) = True Then
                    If Directory.Exists(sFolder) = True Then
                        If Environment.CreateShortCut(sShortCutName, sFolder, stargetPath, sFolder, "moricons.dll", 14) = True Then
                            Acad_MessageBox("ShortCut to office " & sFolder & " to " & stargetPath & " Created Successfully.", , , , , , , True, LogName)
                        Else
                            Acad_MessageBox("There was an error in setting up the Common office " & sFolder & " shortcut." & vbCrLf &
                                              "Target: " & stargetPath &
                                              "Destination: " & sFolder &
                                              "Please notify CADSupport@globalcom", , , , , , , True, LogName)
                        End If
                    Else
                        Acad_MessageBox("ERROR: " & sFolder & " Short Cut to " & stargetPath & " COULD NOT BE created.", , , , , , , True, LogName)
                        Acad_MessageBox("ERROR: Because the local shortcut location: " & sFolder & " could not be found.", , , , , , , True, LogName)
                    End If
                Else
                    If Settings.Manager.AE.ADSiteName <> "" Then
                        Acad_MessageBox("Common office " & sFolder & " folder has not been setup here or network drives have not been mapped: " &
                                            stargetPath & vbCrLf &
                                            "Talk to your CAD Co-ordinator if they are required.", , , , , , , True, LogName)
                    Else
                        Acad_MessageBox("AD Site Name could not be determined: " & vbCrLf &
                                            "If working from home you may need to VPN into the Jacobs Domain.", , , , , , , True, LogName)
                    End If
                End If
            Else
                Acad_MessageBox("If " & sFolder & " short cut existed it has been removed.", , , , , , , True, LogName)
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub


    Private Sub SortCollection(ByVal col As Collection, ByVal psSortPropertyName As String, ByVal pbAscending As Boolean, Optional ByVal psKeyPropertyName As String = "")

        Try

            Dim obj As Object
            Dim i As Integer
            Dim j As Integer
            Dim iMinMaxIndex As Integer
            Dim vMinMax As Integer
            Dim vValue As Integer
            Dim bSortCondition As Boolean
            Dim bUseKey As Boolean
            Dim sKey As String

            bUseKey = (psKeyPropertyName <> "")

            For i = 1 To col.Count - 1
                obj = col(i)
                ' the vbGet can be replaced with a 
                'CallType.Get if you
                ' want. See VB Language reference for CallByName

                vMinMax = CInt(CallByName(obj, psSortPropertyName, vbGet))
                iMinMaxIndex = i

                For j = i + 1 To col.Count
                    obj = col(j)
                    vValue = CInt(CallByName(obj, psSortPropertyName, vbGet))

                    If (pbAscending) Then
                        bSortCondition = (vValue < vMinMax)
                    Else
                        bSortCondition = (vValue > vMinMax)
                    End If

                    If (bSortCondition) Then
                        vMinMax = vValue
                        iMinMaxIndex = j
                    End If

                    obj = Nothing
                Next j

                If (iMinMaxIndex <> i) Then
                    obj = col(iMinMaxIndex)

                    col.Remove(iMinMaxIndex)
                    If (bUseKey) Then
                        sKey = CStr(CallByName(obj,
                           psKeyPropertyName, vbGet))
                        col.Add(obj, sKey, i)
                    Else
                        col.Add(obj, , i)
                    End If

                    obj = Nothing
                End If

                obj = Nothing
            Next i
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try


    End Sub

    Private Function CompareFiles(ByVal filePathOne As String, ByVal filePathTwo As String) As Boolean
        Try

            Dim fileOneByte As Integer
            Dim fileTwoByte As Integer
            Dim fileOneStream As FileStream
            Dim fileTwoStream As FileStream

            If (filePathOne = filePathTwo) Then
                Return True
            End If

            fileOneStream = New FileStream(filePathOne, FileMode.Open, FileAccess.Read)
            fileTwoStream = New FileStream(filePathTwo, FileMode.Open, FileAccess.Read)

            ' If the files are not the same length...
            If (fileOneStream.Length <> fileTwoStream.Length) Then

                fileOneStream.Close()
                fileTwoStream.Close()

                Return False

            End If

            Dim areFilesEqual As Boolean = True
            Do
                fileOneByte = fileOneStream.ReadByte()
                fileTwoByte = fileTwoStream.ReadByte()
                If fileOneByte <> fileTwoByte Then
                    areFilesEqual = False
                    Exit Do
                End If
            Loop While (fileOneByte <> -1)

            fileOneStream.Close()
            fileTwoStream.Close()
            Return areFilesEqual

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return False
        End Try

    End Function

    Private Function addScale(ByVal ScaleName As String, ByVal PaperUnits As Double, ByVal DrawingUnits As Double) As Boolean
        Dim db As Database = HostApplicationServices.WorkingDatabase
        ' next get the objectContextManager
        Try



            Dim contextManager As ObjectContextManager = db.ObjectContextManager
            ' if ok
            If Not contextManager Is Nothing Then
                ' now get the Annotation Scaling context collection (named ACDB_ANNOTATIONSCALES_COLLECTION)
                Dim contextCollection As ObjectContextCollection = contextManager.GetContextCollection("ACDB_ANNOTATIONSCALES")
                ' if ok
                If Not contextCollection Is Nothing Then
                    ' create a brand new scale context
                    Dim annotationScale As AnnotationScale = New AnnotationScale()
                    annotationScale.Name = ScaleName.ToString
                    annotationScale.PaperUnits = PaperUnits
                    annotationScale.DrawingUnits = DrawingUnits
                    ' now add to the drawing's context collection
                    If Not contextCollection.HasContext(ScaleName) Then
                        contextCollection.AddContext(annotationScale)
                    End If
                End If
            End If
            Return True
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Works out from the Configuration.XML file for the current AutoCAD whether an incompatible application file is present on the PC
    ''' In the location specified in the incompatible apps section of the Confoguration.XML file.
    ''' Returns True if there is one and False if not
    ''' Machines with incompatible applications installed cannot not have AE managed CUI files like having Acad as Enterprise and AutoCAD_Custom as MAIN
    ''' This is a way of excluding the AE CUI management via the presence of a file (there is also a profile exclusion method as well as a user tick box method)
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckForConflictingApps() As Boolean

        Try

            Acad_MessageBox("Searching " & Settings.Manager.AutoCAD.Name & " for Incompatible Apps", , , , , , , True, LogName)

            If Not String.IsNullOrEmpty(Settings.Manager.AutoCAD.IncompatibleApps) Then

                Dim vFiles() As String
                Dim sFile As String

                vFiles = Settings.Manager.AutoCAD.IncompatibleApps.Split(";"c)

                For Each sFile In vFiles
                    If File.Exists(sFile) Then
                        Return True
                    End If
                Next
            Else
                ' this allows us to have no files in the string to search for
                Return False
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return False
        End Try

        Return False

    End Function

    ''' <summary>
    ''' Works out from the Configuration.XML file for the current AutoCAD wether the current AutoCAD profile is one of the ones in the exclusion list
    ''' In the location specified in the ThirdPartyAppProfileExclusion section of the Confoguration.XML file.
    ''' Returns True if there is one and False if not
    ''' Machines with ThirdPartyAppProfileExclusions cannot not have AE managed CUI files like having Acad as Enterprise and AutoCAD_Custom as MAIN
    ''' This is a way of excluding the AE CUI management via the profile (there is also a file exclusion method as well as a user tick box method)
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckForThirdPartyAppProfiles() As Boolean

        Try

            If Not String.IsNullOrEmpty(Settings.Manager.AutoCAD.ThirdPartyAppProfileExclusion) Then
                Dim vProfiles() As String
                Dim sProfile As String
                Dim sCProfile As String

                sCProfile = ThisDrawingStartUp.GetVariable("CPROFILE").ToString

                vProfiles = Settings.Manager.AutoCAD.ThirdPartyAppProfileExclusion.Split(";"c)

                For Each sProfile In vProfiles

                    If sProfile.ToUpper Like sCProfile.ToUpper Then
                        Return True
                    End If
                Next

            Else
                ' this allows us to have no files in the string to search for
                Return False
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return True
        End Try

        Return False

    End Function

    ''' <summary>
    ''' This was added to get rid of subsequent font errors for missing Fonts
    ''' Once a config opens once on the Pc the font get's copied to the autocad Fonts area supressing the error in future 
    ''' In the new AE we copy the config Fonts to the ROAMABLEROOTPREFIX Sopport folder..
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyCfgFontsToAcadFonts()

        Dim parentfolder As System.IO.DirectoryInfo
        Dim sFile As System.IO.FileInfo

        Try
            If ThisDrawingIsConfigured() = True Then
                If IsThisAnOldConfigName() = True Then
                    Dim sAcadFontPath As String = String.Empty
                    sAcadFontPath = ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Support")
                    If System.IO.Directory.Exists(sConfigurationPath.CombinePath("Support")) = True Then
                        If System.IO.Directory.Exists(sAcadFontPath) = True Then
                            parentfolder = My.Computer.FileSystem.GetDirectoryInfo(sConfigurationPath.CombinePath("Support"))
                            For Each sFile In parentfolder.GetFiles("*.sh*")
                                'sFile.Attributes = IO.FileAttributes.Normal
                                sFile.CopyTo(sAcadFontPath.CombinePath(sFile.Name), True)
                            Next sFile
                        End If
                    End If
                Else
                    Dim sAcadFontPath As String = String.Empty
                    sAcadFontPath = ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Support")
                    If System.IO.Directory.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(GetruleValue("FullConfigName").CombinePath("Support"))) = True Then
                        If System.IO.Directory.Exists(sAcadFontPath) = True Then
                            parentfolder = My.Computer.FileSystem.GetDirectoryInfo(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(GetruleValue("FullConfigName").CombinePath("Support")))
                            For Each sFile In parentfolder.GetFiles("*.sh*")
                                'sFile.Attributes = IO.FileAttributes.Normal
                                sFile.CopyTo(sAcadFontPath.CombinePath(sFile.Name), True)
                            Next sFile
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub RemoveConfig()
        Try
            RuleAccessors.RemoveRule("FULLCONFIGNAME")
            RuleAccessors.RemoveRule("CONFIGLEVEL")
            RuleAccessors.RemoveRule("MENU")
            RuleAccessors.RemoveRule("DONTASKSWITCHCFG")
            RuleAccessors.RemoveRule("TESTCONFIG")
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Removes a single rule by its name
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_DELETERULE", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub Jacobs_X()

        Dim name As String = InputBox("Enter Rule Name: ", "Remove Rule", "DIM5")

        If Not String.IsNullOrEmpty(name) Then
            RuleAccessors.RemoveRule(name)
        End If

    End Sub

    ''' <summary>
    ''' Displays the Extracted Configuration Settings Path Regardless of old or new config 
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ShowExtractionSupportPath", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub Jacobs_ShowExtractionSupportPath()

        Dim ConfigExtractionSupportPath As String = String.Empty

        If IsThisAnOldConfigName() = True Then
            ConfigExtractionSupportPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(GetruleValue("FullConfigName"), "Settings")
        Else
            ConfigExtractionSupportPath = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(GetruleValue("FullConfigName").CombinePath("Settings"))
        End If

    End Sub

    ''' <summary>
    ''' Adds a rule by its name, value, description, table code and group code - comma separated string
    ''' Emaple: "DIM5,ISO-25,Default DimStyle: ,1,11"
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ADDRULE", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub Jacobs_A()

        Dim name As String = InputBox("Enter Rule Name,Value,Description,TableCode,GroupCode: ", "Add Rule", "DIM5,ISO-25,Default DimStyle: ,1,11")
        Dim rl As String() = name.Split(","c)

        If rl.Length = 5 Then
            RuleAccessors.AddRule(rl(0), rl(1), rl(2), rl(3), rl(4))
        End If

    End Sub

    Private Sub AskSwitchConfig()
        Try
            RuleAccessors.RemoveRule("DONTASKSWITCHCFG")
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub SetPalettePath(ByRef sSearchPath As String, ByRef bTopOfList As Boolean)

        Try

            If System.IO.Directory.Exists(sSearchPath) Then

                Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

                If InStr(preferences.Files.ToolPalettePath, sSearchPath) = 0 Then
                    If bTopOfList = True Then
                        preferences.Files.ToolPalettePath = sSearchPath & ";" & preferences.Files.ToolPalettePath
                    Else
                        preferences.Files.ToolPalettePath = preferences.Files.ToolPalettePath & ";" & sSearchPath
                    End If
                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub


    'Private Sub SetSearchPath(ByRef sSearchPath As String, ByRef bTopOfList As Boolean)

    '    Try
    '        If System.IO.Directory.Exists(sSearchPath) = True Then

    '            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingUtilities.Application.Preferences

    '            If InStr(preferences.Files.SupportPath, sSearchPath) = 0 Then
    '                If bTopOfList = True Then
    '                    preferences.Files.SupportPath = sSearchPath & ";" & preferences.Files.SupportPath
    '                Else
    '                    preferences.Files.SupportPath = preferences.Files.SupportPath & ";" & sSearchPath
    '                End If
    '            End If

    '        End If

    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name,,,logname)
    '    End Try
    'End Sub

    ''' <summary>
    ''' Adds the path to the bottom of the Support search path - used for testing if paths get removed by the sce check
    ''' *-*-*-*
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_XXPATH", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub XXPath()

        Dim btopoflist As Boolean = False
        Dim sSearchPath As String = "\\au-glb-lic01\StrucPlus;\\DC2LIC07\mech-q\A2013"
        Dim sSearchPathStrs() As String

        sSearchPath = InputBox("Enter Path: ", "Adds a Support Search Path", sSearchPath)
        sSearchPathStrs = Split(sSearchPath, ";")

        Try

            For Each sSearchPath In sSearchPathStrs

                If System.IO.Directory.Exists(sSearchPath) = True Then

                    Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

                    If InStr(preferences.Files.SupportPath, sSearchPath) = 0 Then
                        If btopoflist = True Then
                            preferences.Files.SupportPath = sSearchPath & ";" & preferences.Files.SupportPath
                        Else
                            preferences.Files.SupportPath = preferences.Files.SupportPath & ";" & sSearchPath
                        End If
                    End If

                End If

            Next

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub


    Private Sub JacobsCreateDirectory(ByRef sPath As String)

        Try

            If System.IO.Directory.Exists(sPath) = False Then

                If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                    Directory.CreateDirectory(sPath)
                    Acad_MessageBox("Directory Created: " & sPath, , , , , , , True, LogName)

                Else

                    Directory.CreateDirectory(sPath)
                    Acad_MessageBox("Directory Created: " & sPath, , , , , , , True, LogName)

                End If

            End If

        Catch ex As Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

        End Try

    End Sub

    Private Sub DeleteProfile(ByRef sProfileName As String)
        Dim pPreferences As Autodesk.AutoCAD.Interop.AcadPreferences

        Try



            If (sProfileName Like "*[-]*[-]*[-]*[-]*") Then
                pPreferences = ThisDrawingStartUp.Application.Preferences
                pPreferences.Profiles.DeleteProfile(sProfileName)
                pPreferences = Nothing
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    'Private Sub ExtractConfiguration(ByRef sConfigurationName As String)
    '    '   GetConfigSettings()
    '    Try


    '        ' Unzip the selected configuration

    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name,,,logname  )
    '    End Try
    'End Sub

    ''' <summary>
    ''' Get the drawing configname from the registry - this will only be present if the ContentWizard has called AutoCAD
    ''' The Content wizard is responsible for creating and deleting the key
    ''' Key Should be deleted on exit by the start up program in case the content wizard crashes (as a precaution)
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDrawingConfigName() As String

        Dim rConfigRule As Rule

        Try



            If Not (RuleAccessors.GetRule("FULLCONFIGNAME") Is Nothing) Then
                rConfigRule = RuleAccessors.GetRule("FULLCONFIGNAME")
                sDrawingConfigName = rConfigRule.value
                rConfigRule = Nothing
            End If

            GetDrawingConfigName = sDrawingConfigName

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return sDrawingConfigName

    End Function

    ''' <summary>
    ''' Get the selected configuration name from the registry - this will only be present if the ContentWizard has called AutoCAD
    ''' The Content wizard is responsible for creating and deleting the key
    ''' Key Should be deleted on exit by the start up program in case the content wizard crashes (as a precaution)
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSelectedConfigurationName() As String

        Dim sSelectedConfiguration As String = ""
        Dim sKeyPath As String
        Dim sKey As String

        Try

            '   GetConfigSettings()

            sKeyPath = Settings.Manager.AutoCAD.AEAcadWorkingRegKey '& "\" & AE.Config.AutoCAD.Name & "\"
            sKey = "CurrentWorkspace"

            sSelectedConfiguration = Jacobs.Common.Core.Registry.RegistryRead("HKCU", sKeyPath, sKey)
            Jacobs.Common.Core.Registry.RegistryWrite("HKCU", sKeyPath, sKey, "", "REG_SZ")

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return sSelectedConfiguration

    End Function

    Private Function SetTest() As String

        Dim sIsTestConfig As String = ""
        Dim sKeyPath As String
        Dim sKey As String

        Try


            '     GetConfigSettings()

            sKeyPath = Settings.Manager.AutoCAD.AEAcadWorkingRegKey '& "\" & AE.Config.AutoCAD.Name & "\"
            sKey = "TestConfig"

            Jacobs.Common.Core.Registry.RegistryWrite("HKCU", sKeyPath, sKey, "False", "REG_SZ")
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return sIsTestConfig

    End Function

    ''' <summary>
    ''' Sets the configuration required paths - if they exist
    ''' </summary>
    ''' <param name="sConfigurationName"></param>
    ''' <param name="sConfigurationPath"></param>
    ''' <param name="sDrawingConfigurationName"></param>
    ''' <remarks></remarks>
    Private Sub SetPathsForConfiguration(ByRef sConfigurationName As String, ByRef sConfigurationPath As String, ByRef sDrawingConfigurationName As String)

        Try

            'SetSearchPath(sConfigurationPath.CombinePath("Fonts"), True)
            SetSearchPath(sConfigurationPath.CombinePath("Support"), True)

            If IsThisAnOldConfigName() = False Then
                SetSearchPath(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("Support"), True)
            End If

            SetSearchPath(Settings.Manager.AE.Path, False)
            SetPalettePath(sConfigurationPath.CombinePath("Support\Tool Palettes"), False)
            SetPrinterSupportPath(sConfigurationPath.CombinePath("Plotters\Plot Styles"))
            SetPrinterSupportPath(sConfigurationPath.CombinePath("Plot Styles"))

        Catch ex As Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

        End Try

    End Sub

    Public Sub SetPrinterSupportPath(ByRef sSearchPath As String)

        Try
            If System.IO.Directory.Exists(sSearchPath) = True Then

                Dim sConfigName As String = RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False) & ".lnk"
                Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

                Dim oWsh As New IWshRuntimeLibrary.WshShell
                Dim oShortcut As IWshRuntimeLibrary.IWshShortcut
                Dim szShortcut As String

                ' Retrieve the current SupportPath value
                CurrPlotStylePath = preferences.Files.PrinterStyleSheetPath

                ' Get the path where the shortcut will be located
                szShortcut = CurrPlotStylePath.CombinePath(sConfigName)

                ' Make it happen
                oShortcut = CType(oWsh.CreateShortcut(szShortcut), IWshRuntimeLibrary.IWshShortcut)

                ' Link it to this file
                With oShortcut
                    .TargetPath = sSearchPath
                    .Save()
                End With

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub


    ' ''' <summary>
    ' ''' Get the config level from the registry - this will only be present if the ContentWizard has called AutoCAD
    ' ''' The Content wizard is responsible for creating and deleting the key
    ' ''' Key Should be deleted on exit by the start up program in case the content wizard crashes (as a precaution)
    ' ''' </summary>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function GetConfigLevel() As String

    '    Dim sConfigLevel As String = ""
    '    Dim sKeyPath As String
    '    Dim sKey As String

    '    Try



    '        '  GetConfigSettings()

    '        sKey = "ConfigType"

    '        sConfigLevel = Core.Registry.RegistryRead("HKCU", sKeyPath, sKey)

    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name,,,logname  )
    '    End Try

    '    Return sConfigLevel

    'End Function

    Private Sub CreateProfile(ByRef sConfigurationName As String, ByRef sConfigurationPath As String, ByRef sDrawingConfigurationName As String)

        Dim pPreferences As Autodesk.AutoCAD.Interop.AcadPreferences

        Try

            pPreferences = ThisDrawingStartUp.Application.Preferences

            'If System.IO.Directory.Exists(sConfigurationPath.CombinePath("Fonts")) = True Then
            'SetSearchPath(sConfigurationPath.CombinePath("Fonts"), True)
            ' End If

            'If System.IO.Directory.Exists(sConfigurationPath.CombinePath("Settings")) = True Then
            SetSearchPath(sConfigurationPath.CombinePath("Support"), True)
            'End If

            '            If System.IO.Directory.Exists(sConfigurationPath.CombinePath("Plotters\Plot Styles")) = True Then
            SetPrinterSupportPath(sConfigurationPath.CombinePath("Plotters\Plot Styles"))
            'End If

            ' If System.IO.Directory.Exists(sConfigurationPath.CombinePath("Plot Styles")) = True Then
            SetPrinterSupportPath(sConfigurationPath.CombinePath("Plot Styles"))
            'End If

            ' If System.IO.Directory.Exists(AllSettings.Manager.AE.Path) = True Then
            SetSearchPath(Settings.Manager.AE.Path, False)
            'End If

            ' Code to Support Client level tool palettes
            ' If System.IO.Directory.Exists(sConfigurationPath.CombinePath("Settings\Tool Palettes")) = True Then
            SetPalettePath(sConfigurationPath.CombinePath("Support\Tool Palettes"), False)
            'End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Function GetIfTest() As String

        Dim sIsTestConfig As String = ""
        Dim sKeyPath As String
        Dim sKey As String

        Try

            sKeyPath = Settings.Manager.AutoCAD.AEAcadWorkingRegKey '& "\" & AE.Config.AutoCAD.Name & "\"
            sKey = "TestConfig"
            sIsTestConfig = Jacobs.Common.Core.Registry.RegistryRead("HKCU", sKeyPath, sKey)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return sIsTestConfig

    End Function

    Private Sub DestroySearchPath()

        Try

            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

            ' Retrieve the current SupportPath value
            Dim currSupportPath As String = preferences.Files.SupportPath

            If UBound(Split(currSupportPath, ";")) > 0 Then
                For Each sPathItem As String In Split(currSupportPath, ";")
                    If (sPathItem Like "*[-]*[-]*[-]*") And
                        Not (sPathItem Like "\\*") Or
                        sPathItem Like Settings.Manager.AutoCAD.WorkingFolder.CombinePath("Support") Then 'Assume its one of ours and remove it from the list

                        If InStr(currSupportPath, ";" & sPathItem) <> 0 Then
                            preferences.Files.SupportPath = Replace(currSupportPath, ";" & sPathItem, "")
                        End If
                        If InStr(currSupportPath, sPathItem.ToString & ";") <> 0 Then
                            preferences.Files.SupportPath = Replace(currSupportPath, sPathItem.ToString & ";", "")
                        End If
                        currSupportPath = preferences.Files.SupportPath
                    End If
                Next sPathItem
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub DestroyPlotStyleSearchPath()

        Try

            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences
            CurrPlotStylePath = preferences.Files.PrinterStyleSheetPath

            If System.IO.Directory.Exists(CurrPlotStylePath) = True Then
                Dim ParentFolder As System.IO.DirectoryInfo = My.Computer.FileSystem.GetDirectoryInfo(CurrPlotStylePath)
                If Not Err.Number = 0 Then
                    Information.Err.Clear()
                Else
                    For Each sFile As System.IO.FileInfo In ParentFolder.GetFiles()
                        If (sFile.Name Like "*[-]*[-]*[-]*.lnk") Then ' Remove it if it's one of ours.
                            sFile.Attributes = IO.FileAttributes.Normal
                            sFile.Delete()
                        End If
                    Next sFile
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub DestroyPalettePath()

        Try

            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

            ' Retrieve the current SupportPath value
            Dim currSupportPath As String = preferences.Files.ToolPalettePath

            If UBound(Split(currSupportPath, ";")) > 0 Then

                For Each sPathItem As String In Split(currSupportPath, ";")

                    If (sPathItem Like "*[-]*[-]*[-]*") Then 'Assume its one of ours and remove it from the list

                        If InStr(currSupportPath, ";" & sPathItem) <> 0 Then
                            preferences.Files.ToolPalettePath = Replace(currSupportPath, ";" & sPathItem, "")
                        End If

                        If InStr(currSupportPath, sPathItem.ToString & ";") <> 0 Then
                            preferences.Files.ToolPalettePath = Replace(currSupportPath, sPathItem.ToString & ";", "")
                        End If
                        currSupportPath = preferences.Files.ToolPalettePath

                    End If

                Next sPathItem

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub SetQNEWPathNone()

        Try
            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

            If IsThisAnOldConfigName() = True Then

                ' If it ends with a single or double digit and then a .DWT Assume its one of ours
                ' And therefore it needs removing
                If (UCase(preferences.Files.QNewTemplateFile) Like "*_#.DWT") Or (UCase(preferences.Files.QNewTemplateFile) Like "*_##.DWT") Then

                    If currQNEWTemplate <> "" Then
                        ' If the saved on is not one of our use it
                        If Not (UCase(currQNEWTemplate) Like "*_#.DWT") And Not (UCase(currQNEWTemplate) Like "*_##.DWT") Then
                            If System.IO.File.Exists(currQNEWTemplate) = True Then
                                preferences.Files.QNewTemplateFile = currQNEWTemplate ' Resets the old QNEW before it was changed to what it was if recorded
                            Else
                                preferences.Files.QNewTemplateFile = "None"
                            End If
                        Else
                            preferences.Files.QNewTemplateFile = "None"
                        End If
                    Else
                        preferences.Files.QNewTemplateFile = "None"
                    End If

                End If

            Else

                preferences = ThisDrawingStartUp.Application.Preferences
                ' If it had 3 hyphens and ends in .DWT Assume its one of ours and it needs removing
                If (UCase(preferences.Files.QNewTemplateFile) Like "*[-]*[-]*[-]*.DWT") Then
                    If currQNEWTemplate <> "" Then
                        ' If the saved one is not one of our use it
                        If Not (UCase(currQNEWTemplate) Like "*[-]*[-]*[-]*.DWT") Then
                            If System.IO.File.Exists(currQNEWTemplate) = True Then
                                preferences.Files.QNewTemplateFile = currQNEWTemplate ' Resets the old QNEW before it was changed to what it was if recorded
                            Else
                                preferences.Files.QNewTemplateFile = "None"
                            End If
                        Else
                            preferences.Files.QNewTemplateFile = "None"
                        End If
                    Else
                        preferences.Files.QNewTemplateFile = "None"
                    End If
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub DeleteOldConfigurationFiles()

        Dim sCurrentConfig As String
        Dim sCurrentConfigPath As String
        Dim FileCol As New Collection
        Dim MyFile As System.IO.FileInfo

        Try

            ' Check to see if we are running the content wizard or not
            ' sCurrentConfig = GetFullConfigName
            sCurrentConfig = ""

            If sCurrentConfig = "" Then ' Not Running in the content wizard
                sCurrentConfig = RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False)
                If sCurrentConfig <> "NotFound" Then
                    If RuleAccessors.GetruleValue("TESTCONFIG").IsTrue Then
                        sCurrentConfig = "T@" & sCurrentConfig
                    End If
                    '   GetConfigSettings()
                    sCurrentConfigPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sCurrentConfig, "Support")

                    If File.Exists(Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sCurrentConfig, Settings.Manager.AE.ExtractionFinishedFileName)) Then
                        File.Delete(Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sCurrentConfig, Settings.Manager.AE.ExtractionFinishedFileName))
                    End If

                    'varFileArray = GetAllFilesInDir(sCurrentConfigPath)
                    GetDirectoryFiles(sCurrentConfigPath, FileCol)
                    If Not FileCol Is Nothing Then
                        For Each sFile As String In FileCol
                            If Not String.IsNullOrEmpty(Path.GetFileName(sFile)) Then

                                If Path.GetFileName(sFile).ToLower.Contains("profile.arg") = False And
                                    Path.GetFileName(sFile).ToLower.Contains(".dwl") = False Then
                                    MyFile = My.Computer.FileSystem.GetFileInfo(sCurrentConfigPath.CombinePath(Path.GetFileName(sFile)))

                                    Try

                                        If FileInUse(MyFile.FullName) = False Then
                                            MyFile.Delete()
                                        End If

                                    Catch ex As Exception

                                        ' Do nothing

                                        'Catch ex As System.Security.SecurityException
                                        '    ' Do nothing as it's ok to leave the file if it can't be deleted....
                                        '    'If Err.Number = 70 Then
                                        '    '    ' This is a permission denied error and should be ignored as other DWG files may be looking as this image
                                        '    '    Information.Err.Clear()
                                        '    'End If
                                        'Catch ex As Exception
                                        '    ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
                                    End Try
                                End If
                            End If
                        Next
                    End If

                End If
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Public Function FileInUse(ByVal sFile As String) As Boolean
        Dim thisFileInUse As Boolean = False
        If System.IO.File.Exists(sFile) Then
            Try
                Using f As New IO.FileStream(sFile, FileMode.Open, FileAccess.ReadWrite, FileShare.None)
                    ' thisFileInUse = False
                End Using
            Catch
                thisFileInUse = True
            End Try
        End If
        Return thisFileInUse
    End Function


    'Private Sub AddToSupportPath(ByVal sPath As String, ByVal front As Boolean)
    '    Try

    '        If Directory.Exists(sPath) Then

    '            '' get AutoCAD preferences object
    '            Dim AcadPref As AcadPreferences = CType(Autodesk.AutoCAD.ApplicationServices.Application.Preferences, AcadPreferences)

    '            If front = True Then
    '                If AcadPref.Files.SupportPath.ToString.Contains(sPath) = False Then
    '                    AcadPref.Files.SupportPath = sPath & ";" & AcadPref.Files.SupportPath
    '                End If
    '            Else
    '                If AcadPref.Files.SupportPath.ToString.Contains(sPath) = False Then
    '                    AcadPref.Files.SupportPath = AcadPref.Files.SupportPath & ";" & sPath
    '                End If
    '            End If
    '        End If
    '    Catch ex As System.Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try
    'End Sub

    Private Sub DestroyNDrivePlotStyleShortCut()

        Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
        Dim CurrPlotStylePath As String
        Dim parentfolder As System.IO.DirectoryInfo
        Dim sFile As System.IO.FileInfo

        Try


            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                preferences = ThisDrawingStartUp.Application.Preferences
                CurrPlotStylePath = preferences.Files.PrinterStyleSheetPath

                If System.IO.Directory.Exists(CurrPlotStylePath) = True Then
                    parentfolder = My.Computer.FileSystem.GetDirectoryInfo(CurrPlotStylePath)
                    If Not Err.Number = 0 Then
                        Information.Err.Clear()
                    Else
                        For Each sFile In parentfolder.GetFiles
                            If sFile.Name.ToString.ToUpper = Settings.Manager.AutoCAD.NetworkPlotStylesShortcutName.ToUpper Then ' Remove it if it's one of ours.
                                sFile.Attributes = IO.FileAttributes.Normal
                                sFile.Delete()
                            End If
                        Next sFile
                    End If
                End If

            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub ConfigureAutoCADSession()

        '      Dim sSelectedConfigurationName As String
        '       Dim sCurrentProfile As String
        Dim sFullConfigName As String
        '        Dim sConfigLevel As String

        Try

            If IsThisAnOldConfigName() = True Then

                MsgBox("old configurations not Supported")

            Else

                sFullConfigName = GetruleValue("FULLCONFIGNAME")

                'If sFullConfigName.ToUpper.Contains("T@") Then

                '    RuleAccessors.AddRule("TESTCONFIG", "TRUE", "Is this drawing using a test configuration", CStr(0), CStr(0))

                'Else
                '    '' Probably should be part of the Template Builder..
                '    RuleAccessors.RemoveRule("TESTCONFIG")

                'End If

                RUNTIMEConfigPath = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sFullConfigName)
                CopyCfgFontsToAcadFonts()
                MergeCFGFiles(False) ' This means we are not building a config so do merge
                SetPathsForConfiguration(sDrawingConfigName, RUNTIMEConfigPath, sDrawingConfigName)

            End If


            If IsThisAnOldConfigName() = True Then
                SetQNEWPath(GetCurrentProfile.ToString)
            Else
                SetQNEWPathNew(GetCurrentProfile.ToString)
            End If

            ' Initialize Tool Rules

            'InitializeRules("[Text]", True, True, False)
            'InitializeRules("[Scale]", True, True, False)
            'InitializeRules("[Dimensions]", True, True, False)
            'InitializeRules("[Title Block Inserter]", True, True, False)

            ThisDrawingStartUp.SetVariable("RE-INIT", 16)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Unfortunately AutoCAD checks for Fonts before it has finished loading and before VBA code can execute.
    ''' This means we cannot avoid the Missing Fonts dialog box - but we can fix the font references afterwards
    ''' Withe the function below which automatically runs.
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_UpdateMissingFonts", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub ReInitFonts()

        Dim sOldFONTALT As String

        Try

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                Acad_MessageBox("Updating missing Fonts.", , , , , , , True, LogName)
                sOldFONTALT = ThisDrawingStartUp.GetVariable("FONTALT").ToString

                If UCase(sOldFONTALT) = "SIMPLEX8.shX" Then
                    ThisDrawingStartUp.SetVariable("FONTALT", "ISOCP.shX")
                Else
                    ThisDrawingStartUp.SetVariable("FONTALT", "SIMPLEX8.shX")
                End If

                If CInt(ThisDrawingStartUp.GetVariable("REGENMODE")) = 1 Then
                    ThisDrawingStartUp.Regen(Autodesk.AutoCAD.Interop.Common.AcRegenType.acAllViewports)
                End If
                ThisDrawingStartUp.SetVariable("FONTALT", sOldFONTALT)

            End If

            Acad_MessageBox("", , , , , , , True, LogName)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub SetPrinterSupportPathNDrive()

        Try

            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingStartUp.Application.Preferences

            Dim oWsh As New IWshRuntimeLibrary.WshShell
            Dim oShortcut As IWshRuntimeLibrary.WshShortcut
            Dim szShortcut As String

            ' Retrieve the current SupportPath value
            CurrPlotStylePath = preferences.Files.PrinterStyleSheetPath

            ' Get the path where the shortcut will be located
            szShortcut = CurrPlotStylePath.CombinePath(Settings.Manager.AutoCAD.NetworkPlotStylesShortcutName)

            Dim sSearchPath As String = Settings.Manager.AutoCAD.NetworkPlotStyleFolder

            If System.IO.Directory.Exists(sSearchPath) = True Then

                ' Make it happen
                oShortcut = CType(oWsh.CreateShortcut(szShortcut), IWshRuntimeLibrary.WshShortcut)

                ' Link it to this file
                With oShortcut
                    .TargetPath = sSearchPath
                    .Save()
                End With

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub CheckForConfigUpdates()

        Try
            Dim sConfigName As String = GetruleValue("FULLCONFIGNAME")
            Dim sNewConfigName As String = GetMappedConfigName()

            '' Check to see if old config name
            If IsThisAnOldConfigName() = True Then

                '' Catch any non mapped old configs
                If sNewConfigName = String.Empty Then

                    '' Work out how to notify user based on wether they are config builders or not
                    If CheckConfigBuilders() = True Then
                        Acad_MessageBox("Old configuration detected witout a mapped template name. Add " & sConfigName & " to the mapping file: " & vbCrLf &
                                        "Old Configuration is still in use", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        ThisDrawingUtilities.Utility.Prompt("Old configuration detected witout a mapped template name. Contact CAD Support to add " & sConfigName & " to the mapping file: " & vbCrLf &
                                                                            "Old Configuration is still in use" & vbCrLf)
                    End If

                    'OldConfigProcess()

                    Exit Sub

                End If

            End If

            '' Now check if this is an old config and the template in the mapping file has been created or not.
            If IsThisAnOldConfigName() = True Then
                '' Check if a new one has been created
                If DoesNewOneExist() = False Then
                    '' There is no new config but there is a mapped name - check to see if this is a config bulder and hence can create the mew config.
                    If CheckConfigBuilders() = True Then
                        If Acad_MessageBox("Old Config Name Detected but a new Template has not yet been created." & vbCrLf &
                                                        "As a nominated Template Builder you have the ability to Migrate this Configuration to a Template." & vbCrLf &
                                                        "Old Name: " & sConfigName & vbCrLf &
                                                        "New Name: " & sNewConfigName & vbCrLf &
                                                        "Would you like to Migrate this to a new template now ? " & vbCrLf & vbCrLf &
                                                        "Answering no will continue using the old config.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then


                            WriteLineToTextFile(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt"), sNewConfigName)
                            '' Yes new config migration process required
                            MigrateConfig()
                        Else
                            Acad_MessageBox("Remember to create the new template." & vbCrLf &
                                                         "Old config is still in use." & vbCrLf &
                                                         Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName),
                                                          System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                            '' No new one exists and template 
                            'OldConfigProcess()
                        End If
                    Else
                        '' If no new config exists then normal user has no option but to use the old config
                        Acad_MessageBox("Please - Contact CAD Support to create a new Template for: " & vbCrLf &
                                        sConfigName & vbCrLf &
                                        "You may continue to work using the old template while CAD Support migrates it.", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        'OldConfigProcess()
                    End If
                Else
                    '' Automatically migrating DWG file to use new existing config - no questions asked
                    NewConfigProcess()
                End If
            Else
                '' This is a new config no old config names detected use new code no migrating required
                NewConfigProcess()
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub MigrateConfig()

        If IsThisAnOldConfigName() = True Then

            Dim sConfigName As String = GetruleValue("FULLCONFIGNAME")
            Dim sNewConfigName As String = GetMappedConfigName()

            'Dim Dest As String = AllSettings.Manager.AE.ClientsConfigurationPath.CombinePath(sNewConfigName)

            Dim Dest As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", sNewConfigName)

            Dim Source As String = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sConfigName)

            '' Copy Folders
            If System.IO.Directory.Exists(Dest) Then
                System.IO.Directory.Delete(Dest, True)
            End If
            If Not System.IO.Directory.Exists(Dest) Then
                System.IO.Directory.CreateDirectory(Dest)
            End If
            CopyDirectory(Source, Dest)


            '' Save the DWG file
            ThisDrawingStartUp.SaveAs(Dest.CombinePath("Support", sNewConfigName & ".DWG"))

            '' Delete MNU and MNL files
            For Each file As String In System.IO.Directory.GetFiles(Dest.CombinePath("Support"))

                If file.ToUpper.Contains(".MNU") Or
                    file.ToUpper.Contains(".MNL") Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", sConfigName.Split("-"c)(0) & ".DWT").ToUpper) Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", sConfigName.Split("-"c)(1) & ".DWT").ToUpper) Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", sConfigName.Split("-"c)(2) & ".DWT").ToUpper) Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", sConfigName.Split("-"c)(3) & ".DWT").ToUpper) Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", sConfigName.Split("-"c)(4) & ".DWT").ToUpper) Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", ".DWL").ToUpper) Or
                    file.ToUpper.Contains(Dest.CombinePath("Support", ".BAK").ToUpper) Then

                    System.IO.File.Delete(file)

                End If

            Next

            If System.IO.File.Exists(Dest.CombinePath("Support", "Acad.pgp")) Then
                System.IO.File.Delete(Dest.CombinePath("Support", "Acad.pgp"))
            End If

            If System.IO.File.Exists(Dest.CombinePath("Support", "Acadiso.lin")) Then
                System.IO.File.Delete(Dest.CombinePath("Support", "Acadiso.lin"))
            End If

            If System.IO.File.Exists(Dest.CombinePath("Support", "Acadiso.pat")) Then
                System.IO.File.Delete(Dest.CombinePath("Support", "Acadiso.pat"))
            End If

            If System.IO.File.Exists(Dest.CombinePath("Support", "Acad.lin")) Then
                System.IO.File.Delete(Dest.CombinePath("Support", "Acad.lin"))
            End If

            If System.IO.File.Exists(Dest.CombinePath("Support", "Acad.pat")) Then
                System.IO.File.Delete(Dest.CombinePath("Support", "Acad.pat"))
            End If

            If System.IO.File.Exists(Dest.CombinePath("ExtractionFinished.txt")) Then
                System.IO.File.Delete(Dest.CombinePath("ExtractionFinished.txt"))
            End If

            If System.IO.Directory.Exists(Dest.CombinePath("Fonts")) Then
                CopyDirectory(Dest.CombinePath("Fonts"), Dest.CombinePath("Support"))
            End If

            If System.IO.Directory.Exists(Dest.CombinePath("Plot Styles")) Then
                CopyDirectory(Dest.CombinePath("Plot Styles"), Dest.CombinePath("Plot Styles").Replace("\Plot Styles", "\Plotters\Plot Styles"))
            End If

            If System.IO.Directory.Exists(Dest.CombinePath("Fonts")) Then
                For Each File As String In System.IO.Directory.GetFiles(Dest.CombinePath("Fonts"))
                    System.IO.File.Delete(File)
                Next
                System.IO.Directory.Delete(Dest.CombinePath("Fonts"))
            End If

            If System.IO.Directory.Exists(Dest.CombinePath("Plot Styles")) Then
                For Each File As String In System.IO.Directory.GetFiles(Dest.CombinePath("Plot Styles"))
                    System.IO.File.Delete(File)
                Next
                System.IO.Directory.Delete(Dest.CombinePath((Dest.CombinePath("Plot Styles"))))
            End If

            '' Create All XML file Layers

            'For Each File As String In System.IO.Directory.GetFiles(Dest.CombinePath("Support"))
            '    If File.ToUpper.Contains(".XML") Then
            '        CreateLayersFromXML(File)
            '    End If
            'Next

            '' Stamp file with new template rule
            AddRule("FULLCONFIGNAME", sNewConfigName, "Full Configuration Name", "0", "0")

        Else

            ThisDrawingStartUp.Save()

            '' Launches Template Builder if trigger text file exists
            ' CheckIfBuildingTemplateInProgress()

        End If

    End Sub

    Private Function DoesNewOneExist() As Boolean

        Dim Result As Boolean = False

        Try
            Dim sConfigName As String = GetruleValue("FULLCONFIGNAME")
            Dim sFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigMappingFileName))

            For Each ConfigRow As String In sFileRead
                If ConfigRow.ToUpper.Contains(sConfigName.ToUpper) Then
                    sConfigName = ConfigRow.Split(","c)(1)

                    ' Check that the config exists ?
                    If Directory.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName)) Then
                        If File.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName, "Support", sConfigName & ".dwt")) Then
                            Result = True
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, , LogName)
        End Try

        Return Result

    End Function

    Private Function GetMappedConfigName() As String

        Dim Result As String = String.Empty

        Try
            Dim sConfigName As String = GetruleValue("FULLCONFIGNAME")
            Dim sFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigMappingFileName))
            For Each ConfigRow As String In sFileRead
                If ConfigRow.ToUpper.Contains(sConfigName.ToUpper) Then
                    Result = ConfigRow.Split(","c)(1)
                    Exit For
                End If
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, , LogName)
        End Try

        Return Result

    End Function

    Public Sub NewConfigProcess()

        Dim bDontSwitchCfg As Boolean = False
        Dim sConfigName As String = GetruleValue("FULLCONFIGNAME")

        ' Check to see if this is a new config.
        If IsThisAnOldConfigName() = True Then

            Dim sFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigMappingFileName))
            Dim MappingFound As Boolean = False

            For Each ConfigRow As String In sFileRead

                If ConfigRow.ToUpper.Contains(sConfigName.ToUpper) Then
                    sConfigName = ConfigRow.Split(","c)(1)

                    MappingFound = True

                    ' Check that the config exists ?
                    If Directory.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName)) Then

                        If File.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName, "Support", sConfigName & ".dwt")) Then

                            AddRule("FULLCONFIGNAME", sConfigName, "Full Configuration Name", "0", "0")
                            Acad_MessageBox("This drawing has been upgraded to the new Template named: " & sConfigName, , , , , , , True, LogName)

                        Else

                            Acad_MessageBox("New Template folder is present but template has not been created yet." & vbCrLf & "Old config still in use" & vbCrLf &
                                        Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName, "Support", sConfigName & ".dwt"), "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        End If
                    Else

                        '        AllSettings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigName), "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    End If



                    Exit For


                End If

            Next

            If MappingFound = False Then

                Acad_MessageBox("The old configuration: " & sConfigName & " was not found in the mapping file" & vbCrLf & "Old config still in use", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

            End If

        End If

    End Sub

    'Public Sub OldConfigProcess()

    '    Dim NewConfig As New StartUpNewConfigForm
    '    Dim rSwitchConfigRule As Rule
    '    Dim bDontSwitchCfg As Boolean

    '    Dim intFileNumber As Integer
    '    Dim strLogPath As String
    '    Dim cfg As String

    '        If Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing") <> "True" Then
    '        ' Check to see if this is the latest configuration or if there is a newer one
    '        If Not IsNothing(GetConfigurationUpdates) Then
    '            bDontSwitchCfg = False
    '            If Not (RuleAccessors.GetRule("DONTASKSWITCHCFG") Is Nothing) Then
    '                rSwitchConfigRule = RuleAccessors.GetRule("DONTASKSWITCHCFG")
    '                bDontSwitchCfg = rSwitchConfigRule.value.ToString.IsTrue
    '            End If
    '            If Not bDontSwitchCfg Then
    '                'NewConfig.show()
    '                Autodesk.AutoCAD.ApplicationServices.Application.showModalDialog(NewConfig)
    '            End If
    '        End If
    '    Else

    '        If ThisDrawingStartUp.FullName <> "" Then ' Drawing name is empty if the file has not been saved.

    '            ' Log to batchprocessor file that this file has an out of date config
    '            ' The log is created here and deleted in the Batch Processor tool

    '            intFileNumber = FreeFile()
    '            strLogPath = My.Computer.FileSystem.SpecialDirectories.Temp

    '            If System.IO.File.Exists(strLogPath & "\" & "ActivitiesAE" & Settings.Manager.AE.LogFileExtension) = True Then
    '                FileOpen(intFileNumber, strLogPath & "\" & "ActivitiesAE" & Settings.Manager.AE.LogFileExtension, Microsoft.VisualBasic.OpenMode.Append)
    '            Else
    '                FileOpen(intFileNumber, strLogPath & "\" & "ActivitiesAE" & Settings.Manager.AE.LogFileExtension, Microsoft.VisualBasic.OpenMode.Output)
    '            End If

    '            If Not IsNothing(GetConfigurationUpdates) Then
    '                ' write the error log data
    '                WriteLine(intFileNumber, "------------[ Template in this drawing is out of date ]------------")
    '                WriteLine(intFileNumber, "DrawingName: " & ThisDrawingStartUp.FullName)
    '                WriteLine(intFileNumber, "Current Template is: " & RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False))

    '                WriteLine(intFileNumber, "")
    '                WriteLine(intFileNumber, "Additional Possible configurations include")
    '                For Each cfg In GetConfigurationUpdates()
    '                    WriteLine(intFileNumber, cfg)
    '                Next cfg
    '                WriteLine(intFileNumber, "")

    '            Else
    '                WriteLine(intFileNumber, "------------[ This drawing is using the latest Template of it's type ]------------")
    '                WriteLine(intFileNumber, "DrawingName: " & ThisDrawingStartUp.FullName)
    '                WriteLine(intFileNumber, "Current Template is: " & RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False))
    '                WriteLine(intFileNumber, "")

    '            End If

    '            ' close the file
    '            FileClose(intFileNumber)
    '        End If

    '    End If


    'End Sub

    Private Sub MergeFilesNonConfiguredrawings()

        Try
            '' New location for PGP file makes sense to be language specific
            Dim Source As String = Settings.Manager.AutoCAD.Path & "\UserDataCache\en-us\Support"
            Dim destination As String = Settings.Manager.AutoCAD.UserSettingsFolder

            FileMerger(Source.CombinePath("Acad.pgp"), destination.CombinePath("Acad.pgp"), destination.CombinePath(Settings.Manager.AE.UserPGPFileName))

            If CInt(ThisDrawingStartUp.GetVariable("MEASUREMENT")) = 1 Then
                FileMerger(Source.CombinePath("Acadiso.lin"), destination.CombinePath("Acadiso.lin"), destination.CombinePath("USER.LIN"))
            Else
                ' Could be an issue here as we don't have a UserIso.lin file
                FileMerger(Source.CombinePath("Acad.lin"), destination.CombinePath("Acad.lin"), destination.CombinePath("USER.LIN"))
            End If

            FileMerger(Source.CombinePath("Acadiso.pat"), destination.CombinePath("Acadiso.pat"), destination.CombinePath("USER.PAT"))

            ThisDrawingStartUp.SetVariable("RE-INIT", 16)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub Setup_Display()

        Try
            If Jacobs.Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.FirstTimeUse, "FirstTimeRun", True).IsTrue = False Then
                'If Not String.IsNullOrEmpty(AllSettings.Manager.AE.ADSiteName) Then
                If Jacobs.Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.FirstTimeUse, "FirstTimeRun", True).IsTrue = False Then
                    'If Not String.IsNullOrEmpty(AllSettings.Manager.AE.FirstTimeUsePage) Then
                    '    Shell(AllSettings.Manager.AE.FirstTimeUsePage)
                    'End If
                End If
                RestoreOriginalAutoCADFontsQuiet()
                Acad_MessageBox(Settings.Manager.AutoCAD.OnCompletionPrompt, , , , , , , True, LogName)
                'End If

                Jacobs.Common.Core.Registry.RegistryWrite("HKCU", Settings.Manager.AutoCAD.FirstTimeUse, "FirstTimeRun", "True", "REG_SZ")

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Sets all AutoCAD system varible from an array of variables defined in the Configuration.XML file
    ''' CAD Support team can conrol if a variable is persistent or not.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetEnvironmentVariables()

        Try

            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
            preferences = ThisDrawingStartUp.Application.Preferences

            Dim Result As String = String.Empty

            For Each EnvironmentVariable As Manager.SystemVariable In Settings.Manager.AutoCAD.EnvironmentVariables
                If EnvironmentVariable.Persistent.ToString.IsTrue = True Then

                    If EnvironmentVariable.Name = "ShowTabs" Then
                        preferences.Display.DisplayLayoutTabs = EnvironmentVariable.Value.IsTrue
                        Continue For
                    End If

                    ''  <SystemVariable>
                    ''    <Name>MaxHatch</Name>
                    ''    <Value>1000000.0</Value>
                    ''    <Type>Str</Type>
                    ''    <Persistent>true</Persistent>
                    ''  </SystemVariable>


                    If EnvironmentVariable.Name = "Scrollbars" Then
                            preferences.Display.DisplayScrollBars = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "DefaultFormatForSave" Then
                            preferences.OpenSave.SaveAsType = CType(CInt(EnvironmentVariable.Value), AcSaveAsType)
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "ShowPaperMargins" Then
                            preferences.Display.LayoutDisplayMargins = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        ''  <SystemVariable>
                        ''    <Name>ShowPrintBorder</Name>
                        ''    <Value>0</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>false</Persistent>
                        ''  </SystemVariable>
                        ''  <SystemVariable>


                        If EnvironmentVariable.Name = "ShowPaperBackground" Then
                            preferences.Display.LayoutDisplayPaper = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "LayoutXhairPickboxEtc" Then
                            preferences.Display.LayoutCrosshairColor = CType(EnvironmentVariable.Value, UInteger)
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "AcadHELP" Then
                            preferences.Files.HelpFilePath = EnvironmentVariable.Value
                            Continue For
                        End If

                        ''  <SystemVariable>
                        ''    <Name>NFWState</Name>
                        ''    <Value>0</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>false</Persistent>
                        ''  </SystemVariable>


                        If EnvironmentVariable.Name = "ModelSpaceBackground" Then
                            preferences.Display.GraphicsWinModelBackgrndColor = CUInt(CInt(EnvironmentVariable.Value))
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "XhairPickboxEtc" Then
                            preferences.Display.ModelCrosshairColor = CUInt(CInt(EnvironmentVariable.Value))
                            Continue For
                        End If


                        If EnvironmentVariable.Name = "Layout background" Then
                            preferences.Display.GraphicsWinLayoutBackgrndColor = CUInt(CInt(EnvironmentVariable.Value))
                            Continue For
                        End If

                        'If EnvironmentVariable.Name = "DefaultConfig" Then
                        '    preferences.Output.DefaultOutputDevice = EnvironmentVariable.Value
                        '    Continue For
                        'End If



                        ''  <SystemVariable>
                        ''    <Name>BEditBackground</Name>
                        ''    <Value>8421504</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>false</Persistent>
                        ''  </SystemVariable>
                        ''</EnvironmentVariables>



                        Result = vbvlClass.SetEnvironment(EnvironmentVariable.Name, EnvironmentVariable.Value)
                        Acad_MessageBox("ENV " & EnvironmentVariable.Name & " has been set to " & EnvironmentVariable.Value & " Result: " & Result, , , , , , , True, LogName)

                    Else

                        ' If its not a persisten variable we want to do it once per profile
                        If Jacobs.Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.FirstTimeUse & "\" & ThisDrawingStartUp.GetVariable("CPROFILE").ToString, "FirstTimeRunEnvSet", True).IsTrue = False Then

                        If EnvironmentVariable.Name = "ShowTabs" Then
                            preferences.Display.DisplayLayoutTabs = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        ''  <SystemVariable>
                        ''    <Name>MaxHatch</Name>
                        ''    <Value>1000000.0</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>true</Persistent>
                        ''  </SystemVariable>


                        If EnvironmentVariable.Name = "Scrollbars" Then
                            preferences.Display.DisplayScrollBars = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "DefaultFormatForSave" Then
                            preferences.OpenSave.SaveAsType = CType(CInt(EnvironmentVariable.Value), AcSaveAsType)
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "ShowPaperMargins" Then
                            preferences.Display.LayoutDisplayMargins = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        ''  <SystemVariable>
                        ''    <Name>ShowPrintBorder</Name>
                        ''    <Value>0</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>false</Persistent>
                        ''  </SystemVariable>
                        ''  <SystemVariable>


                        If EnvironmentVariable.Name = "ShowPaperBackground" Then
                            preferences.Display.LayoutDisplayPaper = EnvironmentVariable.Value.IsTrue
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "LayoutXhairPickboxEtc" Then
                            preferences.Display.LayoutCrosshairColor = CType(EnvironmentVariable.Value, UInteger)
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "AcadHELP" Then
                            preferences.Files.HelpFilePath = EnvironmentVariable.Value
                            Continue For
                        End If

                        ''  <SystemVariable>
                        ''    <Name>NFWState</Name>
                        ''    <Value>0</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>false</Persistent>
                        ''  </SystemVariable>


                        If EnvironmentVariable.Name = "ModelSpaceBackground" Then
                            preferences.Display.GraphicsWinModelBackgrndColor = CUInt(CInt(EnvironmentVariable.Value))
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "XhairPickboxEtc" Then
                            preferences.Display.ModelCrosshairColor = CUInt(CInt(EnvironmentVariable.Value))
                            Continue For
                        End If

                        If EnvironmentVariable.Name = "Layout background" Then
                            preferences.Display.GraphicsWinLayoutBackgrndColor = CUInt(CInt(EnvironmentVariable.Value))
                            Continue For
                        End If

                        'If EnvironmentVariable.Name = "DefaultConfig" Then
                        '    preferences.Output.DefaultOutputDevice = EnvironmentVariable.Value
                        '    Continue For
                        'End If

                        ''  <SystemVariable>
                        ''    <Name>BEditBackground</Name>
                        ''    <Value>8421504</Value>
                        ''    <Type>Str</Type>
                        ''    <Persistent>false</Persistent>
                        ''  </SystemVariable>
                        ''</EnvironmentVariables>


                        Result = vbvlClass.SetEnvironment(EnvironmentVariable.Name, EnvironmentVariable.Value)
                        Acad_MessageBox("ENV " & EnvironmentVariable.Name & " setting to " & EnvironmentVariable.Value & " Result: " & Result, , , , , , , True, LogName)
                    Else
                        Acad_MessageBox("ENV " & EnvironmentVariable.Name & " is not persistent and does not need to be set again since AutoCAD has already been customised.", , , , , , , True, LogName)
                    End If
                End If
            Next

            ' Flag that the non persistent EnvVariables have been set for this profile                        
            Jacobs.Common.Core.Registry.RegistryWrite("HKCU", Settings.Manager.AutoCAD.FirstTimeUse & "\" & ThisDrawingStartUp.GetVariable("CPROFILE").ToString, "FirstTimeRunEnvSet", "True", "REG_SZ")


            '            preferences.System.EnableStartupDialog = True

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Sets all AutoCAD system variable from an array of variables defined in the Configuration.XML file
    ''' CAD Support team can conrol if a variable is persistent or not.
    ''' Currentlt only caters for int and str types
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetSystemVariables()

        Try

            For Each SystemVariable As Manager.SystemVariable In Settings.Manager.AutoCAD.SystemVariables

                Dim Result As String = "OK"

                If SystemVariable.Persistent = True Then
                    Try

                        If SystemVariable.Type = "Int" Then
                            ThisDrawingStartUp.SetVariable(SystemVariable.Name, CInt(SystemVariable.Value))
                        End If

                        If SystemVariable.Type = "Str" Then
                            ThisDrawingStartUp.SetVariable(SystemVariable.Name, SystemVariable.Value)
                        End If

                        Acad_MessageBox("SYS " & SystemVariable.Name & " has been set to " & SystemVariable.Value & " Result: " & Result, , , , , , , True, LogName)

                    Catch ex As Exception
                        Acad_MessageBox("SYS " & SystemVariable.Name & " could not be set " & SystemVariable.Value & " Result: " & ex.Message, , , , , , , True, LogName)
                    End Try

                Else

                    If Jacobs.Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.FirstTimeUse & "\" & ThisDrawingStartUp.GetVariable("CPROFILE").ToString, "FirstTimeRunSysVarsSet", True).IsTrue = False Then

                        Try
                            If SystemVariable.Type = "Int" Then
                                ThisDrawingStartUp.SetVariable(SystemVariable.Name, CInt(SystemVariable.Value))
                            End If

                            If SystemVariable.Type = "Str" Then
                                ThisDrawingStartUp.SetVariable(SystemVariable.Name, SystemVariable.Value)
                            End If

                            Acad_MessageBox("SYS " & SystemVariable.Name & " has been set to " & SystemVariable.Value & " Result: " & Result, , , , , , , True, LogName)

                        Catch ex As Exception
                            Acad_MessageBox("SYS " & SystemVariable.Name & " could not be set " & SystemVariable.Value & " Result: " & ex.Message, , , , , , , True, LogName)
                        End Try
                    Else
                        Acad_MessageBox("SYS " & SystemVariable.Name & " is not persistent and does not need to be set again since AutoCAD has already been customised.", , , , , , , True, LogName)
                    End If


                End If
            Next

            ' Flag that the non persistent SystemVariables have been set for this profile                        
            Jacobs.Common.Core.Registry.RegistryWrite("HKCU", Settings.Manager.AutoCAD.FirstTimeUse & "\" & ThisDrawingStartUp.GetVariable("CPROFILE").ToString, "FirstTimeRunSysVarsSet", "True", "REG_SZ")

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub CopyFontsFromNetwork()
        Try

            Dim sToExecute As String
            ' <NetworkFontsFolder>[NETWORKCADCFG]\[SHAREDAcadNAME]\[AD-SITE]\Fonts</NetworkFontsFolder> <UserRoamingSupportFolder>[USERAPPDATAROAMING]\Autodesk\AutoCAD 2017\R21.0\enu\Support</UserRoamingSupportFolder>
            sToExecute = "XCOPY """ & Settings.Manager.AutoCAD.NetworkFontsFolder & "\*.sh*"" """ & Settings.Manager.AutoCAD.UserRoamingSupportFolder & """ /V /Y /I /C /Q"
            Shell(sToExecute, AppWinStyle.Hide, False)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    '' Called from outside must be public
    'Public Function GetConfigurationUpdates() As String()

    '    Dim varFilesForList() As String = Nothing
    '    Dim iCorpVer As Integer
    '    Dim iBUVer As Integer
    '    Dim iDiscVer As Integer
    '    Dim iOfficeVer As Integer
    '    Dim iClientVer As Integer
    '    Dim sFileConfigurationName As String
    '    Dim lngFileCount As Integer
    '    Dim sConfigNameFromRule As String
    '    Dim sConfigNameWithoutVer As String
    '    Dim bAddToList As Boolean

    '    Try



    '        ' Set drawing configuration if different from selected if we have a configname selected and we are running the content wizard
    '        'Then show a  new prompt with check box and add a rule depending on check box selected. If they say yes then set
    '        'sSelectedConfigurationName to the new version.

    '        sConfigNameFromRule = RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False)
    '        sConfigNameWithoutVer = sConfigNameFromRule

    '        iCorpVer = GetVersion(sConfigNameFromRule, "CORP")
    '        iBUVer = GetVersion(sConfigNameFromRule, "BU")
    '        iDiscVer = GetVersion(sConfigNameFromRule, "DISC")
    '        iOfficeVer = GetVersion(sConfigNameFromRule, "OFFICE")
    '        iClientVer = GetVersion(sConfigNameFromRule, "CLIENT")

    '        sConfigNameWithoutVer = RemoveVerNo(sConfigNameWithoutVer)

    '        Dim FileCol As New Collection
    '        GetDirectoryFiles(Settings.Manager.AE.ClientsConfigurationPath, FileCol)
    '        If Not FileCol Is Nothing Then
    '            For Each sFile As String In FileCol

    '                If sFile.ToUpper.Contains(".ZIP") Then

    '                    sFileConfigurationName = sFile.ToUpper.Replace(".ZIP", "")

    '                    If RemoveVerNo(sFileConfigurationName).Contains(sConfigNameWithoutVer) Then

    '                        If GetVersion(sFileConfigurationName, "CORP") > iCorpVer Then
    '                            bAddToList = True
    '                        End If

    '                        If GetVersion(sFileConfigurationName, "BU") > iBUVer Then
    '                            bAddToList = True
    '                        End If

    '                        If GetVersion(sFileConfigurationName, "DISC") > iDiscVer Then
    '                            bAddToList = True
    '                        End If

    '                        If GetVersion(sFileConfigurationName, "OFFICE") > iOfficeVer Then
    '                            bAddToList = True
    '                        End If

    '                        If GetVersion(sFileConfigurationName, "CLIENT") > iClientVer Then
    '                            bAddToList = True
    '                        End If

    '                        If bAddToList Then

    '                            ReDim Preserve varFilesForList(lngFileCount)

    '                            varFilesForList(lngFileCount) = sFile

    '                            lngFileCount = lngFileCount + 1

    '                        End If

    '                    End If

    '                End If

    '            Next
    '        End If

    '    Catch ex As Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try

    '    If lngFileCount > 0 Then
    '        Return Array.Copy(varFilesForList)
    '    Else
    '        Return Nothing
    '    End If

    'End Function

    'Private Function GetVersion(ByVal sConfigName As String, ByVal sCateg As String) As Integer

    '    Dim iCorpVer As Integer
    '    Dim iBUVer As Integer
    '    Dim iDiscVer As Integer
    '    Dim iOfficeVer As Integer
    '    Dim iClientVer As Integer
    '    Dim iHyphenLocation As Integer
    '    Dim iCounter As Integer
    '    Dim ReturnVersion As Integer = 0

    '    Try


    '        If sConfigName.Contains("NotFound") Then
    '            Return 0
    '            Exit Function
    '        End If

    '        For iCounter = 1 To Len(sConfigName)
    '            If IsNumeric(Mid(sConfigName, iCounter, 1)) Then
    '                iHyphenLocation = InStr(1, sConfigName, "-", CType(1, CompareMethod))
    '                If iHyphenLocation > iCounter Then
    '                    iCorpVer = CInt(Mid(sConfigName, iCounter, iHyphenLocation - iCounter))
    '                End If
    '                Exit For
    '            End If
    '        Next

    '        ' Check that it's not at the Corporate level only....
    '        Dim counter As Integer
    '        If iHyphenLocation <> 0 Then
    '            counter = CShort(iHyphenLocation)
    '            For iCounter = counter To Len(sConfigName)
    '                If IsNumeric(Mid(sConfigName, iCounter, 1)) Then
    '                    iHyphenLocation = InStr(iHyphenLocation + 1, sConfigName, "-")
    '                    If iHyphenLocation > iCounter Then
    '                        iBUVer = CShort(Mid(sConfigName, iCounter, iHyphenLocation - iCounter))
    '                    End If
    '                    Exit For
    '                End If
    '            Next
    '            If iHyphenLocation <> 0 Then
    '                counter = CShort(iHyphenLocation)
    '                For iCounter = counter To Len(sConfigName)
    '                    If IsNumeric(Mid(sConfigName, iCounter, 1)) Then
    '                        iHyphenLocation = InStr(iHyphenLocation + 1, sConfigName, "-")
    '                        If iHyphenLocation > iCounter Then
    '                            iDiscVer = CShort(Mid(sConfigName, iCounter, iHyphenLocation - iCounter))
    '                        End If
    '                        Exit For
    '                    End If
    '                Next
    '                If iHyphenLocation <> 0 Then
    '                    counter = CShort(iHyphenLocation)
    '                    For iCounter = counter To Len(sConfigName)
    '                        If IsNumeric(Mid(sConfigName, iCounter, 1)) Then
    '                            iHyphenLocation = InStr(iHyphenLocation + 1, sConfigName, "-")
    '                            If iHyphenLocation > iCounter Then
    '                                iOfficeVer = CShort(Mid(sConfigName, iCounter, iHyphenLocation - iCounter))
    '                            End If
    '                            Exit For
    '                        End If
    '                    Next
    '                End If
    '            End If
    '        End If

    '        If sConfigName = "" Then
    '            Return 0
    '            Exit Function
    '        End If

    '        iClientVer = Convert.ToInt32(Mid(sConfigName, InStr(1, sConfigName, "_") + 1, Len(sConfigName) - InStr(1, sConfigName, "_")))

    '        If sCateg = "CORP" Then
    '            ReturnVersion = iCorpVer
    '        End If

    '        If sCateg = "BU" Then
    '            ReturnVersion = iBUVer
    '        End If

    '        If sCateg = "DISC" Then
    '            ReturnVersion = iDiscVer
    '        End If

    '        If sCateg = "OFFICE" Then
    '            ReturnVersion = iOfficeVer
    '        End If

    '        If sCateg = "CLIENT" Then
    '            ReturnVersion = iClientVer
    '        End If

    '    Catch ex As Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try

    '    Return CShort(ReturnVersion)

    'End Function

    'Private Function RemoveVerNo(ByVal sConfigName As String) As String

    '    Dim sConfigNameWithoutVer As String
    '    Dim iCounter As Integer
    '    Dim Result As String = ""

    '    Try



    '        sConfigNameWithoutVer = sConfigName

    '        For iCounter = 1 To CShort((InStr(1, sConfigNameWithoutVer, "_") - 3)) 'Len(sConfigName)
    '            If IsNumeric(Mid(sConfigName, iCounter, 1)) Then
    '                sConfigNameWithoutVer = Replace(sConfigNameWithoutVer, Mid(sConfigName, iCounter, 1), "")
    '            End If
    '        Next
    '        sConfigNameWithoutVer = Mid(sConfigNameWithoutVer, 1, InStr(1, sConfigNameWithoutVer, "_"))

    '        Result = LCase(sConfigNameWithoutVer)

    '    Catch ex As Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try

    '    Return Result

    'End Function

    ''' <summary>
    ''' We used to do this in a secondary installer - perhaps we should put that functionality back in
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CopyJacobsCachedFiles()

        Try

            ' This file gets copied every time to ensure changes we make in AE are properly added to the menus

            Dim sToExecute As String

            sToExecute = "XCOPY """ & Settings.Manager.AutoCAD.CachedJacobsCUIFiles & """ """ & Settings.Manager.AutoCAD.UserSettingsFolder & """ /V /Y /I /C /Q"
            Shell(sToExecute, AppWinStyle.Hide, False)

            sToExecute = "XCOPY """ & Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath("BatchProcessorRoutines", "*.*") & """ """ & Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath("BatchProcessorRoutines") & """ /D /V /Y /I /C /Q /S"
            Shell(sToExecute, AppWinStyle.Hide, False)

            ' Only copy the very first time AutoCAD is run - the rest of the time these files are managed via the ManageCUIS_Select
            If Settings.Manager.AE.AutoCADHasBeenCustomised.ToString.IsTrue = False Then
                If Settings.Manager.AutoCAD.RestoreAcadCUI = True Then

                    ' Get the MAIN CUI FILE from the cached location
                    If System.IO.File.Exists(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.MainCUIFileNameNoExt & ".CUIX")) Then
                        System.IO.File.Copy(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.MainCUIFileNameNoExt & ".CUIX"),
                                                  Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AutoCAD.MainCUIFileNameNoExt & ".CUIX"), True)
                    End If
                    ' Get the ENTERPRISE CUI FILE from the cached location
                    If System.IO.File.Exists(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX")) Then
                        System.IO.File.Copy(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX"),
                                            Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX"), True)
                    End If
                    'If System.IO.File.Exists(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX")) Then
                    '    System.IO.File.Copy(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX"), _
                    '                        Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX"), True)
                    'End If
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ' ''' <summary>
    ' ''' Chek if the menu that was passed is one of the partial menus to be loaded.
    ' ''' </summary>
    ' ''' <param name="MenuName"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Private Function IsAdditionalMenu(ByVal MenuName As String) As Boolean

    '    ' If the CUIX's is profile specific and this is one of the excluded profiles return false
    '    Dim ProfileMatch As Boolean = False

    '    For Each addmenu As Common.Settings.Manager.AdditionalMenu In Settings.Manager.AutoCAD.AdditionalMenus

    '        Dim MnuNameArray() As String = Common.Settings.Manager.EvaluateExpression(addmenu.CUIName).Split("\"c)

    '        If String.IsNullOrEmpty(addmenu.ProfileSpecific) = True Then
    '            ProfileMatch = False
    '        Else
    '            ' If it's not empty then it must apply to some profiles.
    '            ' Check to see if this Additional Menus Profile is one of the excluded profiles.
    '            Dim sValidProfiles() As String = Split(addmenu.ProfileSpecific, ";")
    '            For Each sProfile As String In sValidProfiles
    '                For Each sThirdPartyExcludedProfile As String In Settings.Manager.AutoCAD.ThirdPartyAppProfileExclusion.Split(";"c)
    '                    If sProfile.ToString.ToUpper Like sThirdPartyExcludedProfile.ToUpper Then
    '                        ' Yes this Additional Menu has is an excluded profile so it can be a MAIN cui.
    '                        ProfileMatch = True
    '                    End If
    '                Next
    '            Next
    '        End If

    '        ' Check if this additional menu CUI name is one of the Partial Menus - but don't worry if this profile is an excluded profile.
    '        ' As excluded profiles can have the Adittional Menu's CUIX as the main CUIX
    '        If Path.GetFileNameWithoutExtension(MenuName).ToUpper.Contains(Path.GetFileNameWithoutExtension(MnuNameArray(MnuNameArray.Length - 1)).ToUpper) And _
    '            ProfileMatch = False Then

    '            Return True

    '        End If
    '    Next

    '    Return False

    'End Function

    ' ''' <summary>
    ' ''' For the current AutoCAD product it does all the logistics for seting the CUIX file as follows
    ' ''' </summary>
    ' ''' <remarks></remarks>
    'Private Sub SetEnterpriseUIFile()

    '    Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
    '    Dim MainMenu As String
    '    Dim EnterpriseMenu As String

    '    Try

    '        preferences = ThisDrawingStartUp.Application.Preferences
    '        MainMenu = preferences.Files.MenuFile
    '        EnterpriseMenu = preferences.Files.EnterpriseMenuFile

    '        ' See if Enterprise menu is correct

    '        If Path.GetFileNameWithoutExtension(EnterpriseMenu).ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper) Then

    '            ' Enterprise menu is good no need to do anything


    '            '' This is a bit counter productive... As the unmanaged partial menu and the excluded profile clash
    '            '' Check that the Main UI file is not the Enterprise UI file or that it's not one of the Partial menus which we would need to load later or that it's not "." or ""
    '            If Path.GetFileNameWithoutExtension(MainMenu).ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper) Or _
    '               MainMenu = "." Or _
    '               MainMenu = "" Or _
    '               IsAdditionalMenu(MainMenu) = True Then

    '                ' We need a CUIX so that Partial CUIxs can be loaded on to it defaulted to Custom
    '                preferences.Files.MenuFile = "Custom.CUIX"

    '            End If

    '        Else

    '            ' Ent is not correct

    '            ' Test to see if the main has the ENT loaded
    '            If Path.GetFileNameWithoutExtension(MainMenu).ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper) Then

    '                ' Main menu has the enterprise menu loaded on it - so get whatever is on Ent and hang on to it so we can use it as the main swap them over
    '                Dim temp As String = preferences.Files.EnterpriseMenuFile

    '                '' This is a bit counter productive... As the unmanaged partial menu and the excluded profile clash
    '                ' Check that the Enterprise UI file which we are about to set as Main is not the Enterprise UI file or 
    '                ' that its not one of the Partial menus which we would need to load later or 
    '                ' that its not "." or ""
    '                If Path.GetFileNameWithoutExtension(temp).ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper) Or _
    '                   MainMenu = "." Or _
    '                   MainMenu = "" Or _
    '                   IsAdditionalMenu(MainMenu) = True Then

    '                    ' We need a CUIX so that Partial CUIxs can be loaded on to it defaulted to Custom
    '                    preferences.Files.MenuFile = "Custom.CUIX"

    '                Else
    '                    preferences.Files.MenuFile = temp
    '                End If

    '                preferences.Files.EnterpriseMenuFile = Settings.Manager.AutoCAD.EnterpriseMenuFileNamePathed

    '            Else

    '                ' Ent is not correct and ent is not loaded on main
    '                preferences.Files.EnterpriseMenuFile = Settings.Manager.AutoCAD.EnterpriseMenuFileNamePathed


    '                '' This is a bit counter productive... As the unmanaged partial menu and the excluded profile clash
    '                ' Check that the Main UI file is not of the Partial menus which we would need to load later or that it's not "." or ""
    '                If MainMenu = "." Or _
    '                   MainMenu = "" Or _
    '                   IsAdditionalMenu(MainMenu) = True Then

    '                    ' We need a CUIX so that Partial CUIxs can be loaded on to it defaulted to Custom
    '                    preferences.Files.MenuFile = "Custom.CUIX"

    '                End If

    '            End If

    '        End If

    '    Catch ex As System.Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try

    'End Sub

    ' ''' <summary>
    ' ''' Fucntion to manage third party application supporr search paths, palette paths, menus, toolbars and ribbon tabs (this could be profile dependent)
    ' ''' </summary>
    ' ''' <param name="Product"></param>
    ' ''' <remarks></remarks>
    ' '''     
    'Private Sub Manage3rdPartyApps(ByVal Product As String, Optional ByVal SetWorkspace As Boolean = True)

    '    ' Check the current workspace to see if it's empty ""
    '    If String.IsNullOrEmpty(CStr(ThisDrawingStartUp.GetVariable("WSCURRENT"))) Then

    '        Dim cprofile As String = RegistryRead("HKCU", Settings.Manager.AutoCAD.RegKey & "\Profiles", "")
    '        Dim LastWorkSpaceOnSave As String = RegistryRead("HKCU", Settings.Manager.AutoCAD.RegKey & "\Profiles\" & cprofile, "WorkspaceNameAtProfileSave")

    '        ' If no workspace is selected then check to see if there was a previous workspace saved for this current user
    '        If String.IsNullOrEmpty(LastWorkSpaceOnSave) Then
    '            If Settings.Manager.AutoCAD.Name.ToUpper.Contains("Civil 3D".ToUpper) Then

    '                Acad_MessageBox("Workspace not set. Please switch the current workspace to: " & Settings.Manager.AutoCAD.MainCUIFileNameNoExt & vbCrLf & vbCrLf & _
    '                                    "Due to a sequencing limitation in Civil 3d the AE cannot automatically switch workspaces the first time a profile is started." & vbCrLf & _
    '                                    "In order to see all the ribbons and pull-down menus available to you, please switch to the above mentioned workspace." & vbCrLf & _
    '                                    "You can achieve this by using the WORKSPACE command.", _
    '                                    "", MessageBoxButtons.OK, MessageBoxIcon.Information)

    '            Else

    '                If SetWorkspace = True Then
    '                    ThisDrawingStartUp.SetVariable("WSCURRENT", Settings.Manager.AutoCAD.MainCUIFileNameNoExt)
    '                End If

    '            End If
    '        Else
    '            ' If there was one set it to be current
    '            ThisDrawingStartUp.SetVariable("WSCURRENT", LastWorkSpaceOnSave)
    '        End If
    '    End If

    '    ' Check the Configuration.xml file for any additional menus that should be loaded
    '    For Each MenuItem As Common.Settings.Manager.AdditionalMenu In Settings.Manager.AutoCAD.AdditionalMenus

    '        Dim ToBeManagedOnThisProfile As Boolean = False

    '        ' Is this additiona menu ProfileSpecific field for this additiona menu empty? 
    '        ' In other words applies to all profiles and not just some..

    '        If String.IsNullOrEmpty(MenuItem.ProfileSpecific) = True Then

    '            ' If thats so then we must manage it for every profile
    '            ToBeManagedOnThisProfile = True

    '        Else

    '            ' If it's not empty then it must apply to some profiles.
    '            ' Check to see if the current profile is one of the profiles that this menu applies to

    '            Dim sValidProfiles() As String = Split(MenuItem.ProfileSpecific, ";")

    '            For Each sProfile As String In sValidProfiles

    '                If sProfile.ToString.ToUpper = ThisDrawingStartUp.GetVariable("CPROFILE").ToString.ToUpper Then

    '                    ToBeManagedOnThisProfile = True

    '                End If

    '            Next

    '            ' ADDED BACK?
    '            If ToBeManagedOnThisProfile = False Then
    '                '    ' We have just iterated through all the allowed profiles and none of them matched the current profile 
    '                '    ' See if it's loaded and unload it 
    '                Try
    '                    Dim mg As AcadMenuGroup
    '                    For Each mg In ThisDrawingStartUp.Application.MenuGroups
    '                        If LCase(mg.Name) = LCase(MenuItem.MenuName) Then
    '                            mg.Unload()
    '                            Exit For
    '                        End If
    '                    Next
    '                Catch ex As Exception

    '                End Try
    '            End If

    '        End If

    '        ' Check if this is an office menu 
    '        If MenuItem.MenuName.ToUpper = "Office".ToUpper Then

    '            ' Does the user wish to manage the office menu or not
    '            If Settings.Manager.AutoCAD.UseOfficeNetworkMenu = False Then
    '                ToBeManagedOnThisProfile = False
    '            End If

    '        End If

    '        '' If we are supposed to manage it on this profile then
    '        '' The first thing we need to do is unload it in case it was loaded before
    '        '' Remove the menu if it's loaded
    '        '' Check to see if this is an excluded profile and don't unload if it is...

    '        'If LCase(mg.Name) = LCase(MenuItem.MenuName) Or _

    '        If CheckForThirdPartyAppProfiles() = True Then

    '            Dim mg As AcadMenuGroup
    '            For Each mg In ThisDrawingStartUp.Application.MenuGroups
    '                If UCase(mg.Name) = "MODELDOC" Or _
    '                    UCase(mg.Name) = "AUTOCADWS" Or _
    '                    UCase(mg.Name) = "CONTENTEXPLORER" Then
    '                    mg.Unload()
    '                    Exit For
    '                End If
    '            Next

    '        End If


    '        ' Else if the menu cui file is not present and there are Support search paths to manage remove them
    '        If String.IsNullOrEmpty(MenuItem.SupportSearchPaths) = False Then
    '            RemoveSupportPaths(Common.Settings.Manager.EvaluateExpression(MenuItem.SupportSearchPaths))
    '        End If

    '        ' Else if the menu cui file is not present and there are palette search paths to manage remove them
    '        If String.IsNullOrEmpty(MenuItem.ToolPalettePath) = False Then
    '            RemoveToolPalettePaths(Common.Settings.Manager.EvaluateExpression(MenuItem.ToolPalettePath))
    '        End If

    '        If ToBeManagedOnThisProfile = True Then

    '            ' Check to see if the CUI file exists and if it does then load it back up so 
    '            ' That all workspaces get the toolbars ribbons and menus

    '            If File.Exists(Common.Settings.Manager.EvaluateExpression(MenuItem.CUIName)) Then

    '                ' If there are Support paths set to manage add them
    '                If String.IsNullOrEmpty(MenuItem.SupportSearchPaths) = False Then
    '                    AddToSupportPath(Common.Settings.Manager.EvaluateExpression(MenuItem.SupportSearchPaths))
    '                End If

    '                ' If there are palette paths set to manage add them
    '                If String.IsNullOrEmpty(MenuItem.ToolPalettePath) = False Then
    '                    AddToToolPalettePath(Common.Settings.Manager.EvaluateExpression(MenuItem.ToolPalettePath))
    '                End If

    '                '' Check to see if there is a valud menu name to use.
    '                If String.IsNullOrEmpty(MenuItem.MenuName) = False Then
    '                    LoadPartialCui(Common.Settings.Manager.EvaluateExpression(MenuItem.CUIName), MenuItem.MenuName, MenuItem.PopUps, MenuItem.VisibleToolBars)
    '                End If

    '            End If

    '        End If

    '    Next

    'End Sub

    ' ''' <summary>
    ' ''' Loads a partial CUI so that the ribbons get incorporated into every workspace.
    ' ''' Toolbars and menus are displayed according to Configuration.xml AdditionalMenu instructions
    ' ''' </summary>
    ' ''' <param name="CUIName"></param>
    ' ''' <param name="MenuName"></param>
    ' ''' <param name="sPopUps"></param>
    ' ''' <param name="ToolBars"></param>
    ' ''' <remarks></remarks>
    'Private Sub LoadPartialCui(ByVal CUIName As String, ByVal MenuName As String, ByVal sPopUps As String, ByVal ToolBars As String)

    '    Dim mg As AcadMenuGroup = Nothing
    '    Dim menuwasloaded As Boolean = False
    '    Dim intcnt As Integer

    '    Try

    '        For intcnt = 0 To ThisDrawingStartUp.Application.MenuGroups.Count - 1
    '            If ThisDrawingStartUp.Application.MenuGroups.Item(intcnt).Name.ToUpper = MenuName.ToUpper Then
    '                mg = ThisDrawingStartUp.Application.MenuGroups.Item(intcnt)
    '                menuwasloaded = True
    '                Exit For
    '            End If
    '        Next

    '        If menuwasloaded = False Then
    '            ' Load it first
    '            ThisDrawingStartUp.Application.MenuGroups.Load(CUIName)
    '            Acad_MessageBox("Customization file loaded successfully. Customization Group: " & MenuName.ToUpper, , , , , , , True, LogName)
    '            AcadAppStartUp.UpdateScreen()
    '            For intcnt = 0 To ThisDrawingStartUp.Application.MenuGroups.Count - 1
    '                If ThisDrawingStartUp.Application.MenuGroups.Item(intcnt).Name.ToUpper = MenuName.ToUpper Then
    '                    mg = ThisDrawingStartUp.Application.MenuGroups.Item(intcnt)
    '                    menuwasloaded = True
    '                    Exit For
    '                End If
    '            Next

    '        End If

    '    Catch ex As Exception

    '        mg = Nothing

    '    End Try


    '    '   Autodesk.AutoCAD.Customization.CustomizationSection.addToolbarsMenusAndPanelsToWorkspace()
    '    '   AddPartial(CUIName)

    '    If mg IsNot Nothing Then


    '        '    AddPartial(CUIName)

    '        ' Cycle through the toobars, setting them to visible if required
    '        Dim i As Integer
    '        Dim ToolBarsToShow() As String = Split(ToolBars, ";")
    '        For i = 0 To mg.Toolbars.Count - 1
    '            For Each tb As String In ToolBarsToShow
    '                If mg.Toolbars.Item(i).Name.ToUpper = tb.ToUpper Then
    '                    mg.Toolbars.Item(i).Visible = True
    '                End If
    '            Next
    '        Next

    '        ' Manage Pop Up Menus
    '        Dim sPopMenu As String
    '        Dim sPopMenus() As String
    '        Dim sPopMenuName As String
    '        Dim sPopMenuPosition As Integer

    '        sPopMenus = sPopUps.Split(":"c)

    '        ' Cycle throug the pop menus make them visible if required
    '        For Each sPopMenu In sPopMenus

    '            sPopMenuName = sPopMenu.Split(","c)(0)
    '            sPopMenuPosition = CInt(sPopMenu.Split(","c)(1))

    '            If String.IsNullOrEmpty(sPopMenu) = False Then

    '                Try

    '                    Dim menupoped As Boolean = False
    '                    Dim acMenuGroup As AcadMenuGroup

    '                    For Each acMenuGroup In ThisDrawingStartUp.Application.MenuGroups
    '                        If acMenuGroup.Name.ToString.ToUpper.Contains(MenuName.ToUpper) Then
    '                            ' Check for pop ups
    '                            For i = 0 To acMenuGroup.Menus.Count

    '                                If acMenuGroup.Menus.Item(i).Name.ToUpper = sPopMenuName.ToUpper Then
    '                                    ' Already popped
    '                                    Exit For
    '                                Else
    '                                    ' Pop up the menu
    '                                    mg.Menus.InsertMenuInMenuBar(sPopMenuName, "")
    '                                    Exit For
    '                                End If

    '                                i = i + 1

    '                            Next
    '                        End If
    '                    Next acMenuGroup

    '                    'If menupoped = False Then
    '                    '    'mg.Menus.InsertMenuInMenuBar(sPopMenuName, sPopMenuPosition)

    '                    mg.Menus.InsertMenuInMenuBar(sPopMenuName, "")

    '                    'End If

    '                Catch ex As System.Exception

    '                End Try

    '            End If

    '        Next
    '    Else
    '        Acad_MessageBox("Could not obtain menu group: " & MenuName, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , LogName)
    '    End If

    'End Sub

    Private Sub AddToSupportPath(ByVal sPath As String)

        Dim sTestPaths() As String
        Dim sTestPath As String
        Dim PathsOK As Boolean = True
        'Dim sDocumentsAndSettings As String

        Try




            sPath = Common.Settings.Manager.EvaluateExpression(sPath)
            '    GetConfigSettings()
            'sDocumentsAndSettings = sDocumentsAndSettingsFolder

            'sPath = Replace(sPath, "[ROAMABLEROOTPREFIX]", ThisDrawing.GetVariable("ROAMABLEROOTPREFIX"))
            'sPath = Replace(sPath, "[ProgramFiles]", My.Computer.FileSystem.SpecialDirectories.ProgramFiles)
            'sPath = Replace(sPath, "[DocumentsAndSettings]", sDocumentsAndSettings)
            'sPath = Replace(sPath, "[LOCALROOTPREFIX]", ThisDrawing.GetVariable("LOCALROOTPREFIX"))
            'sPath = Replace(sPath, "[AD-SITE]", Core.Environment.GetADSite)


            sTestPaths = sPath.Split(";"c)

            ' if any one of the paths is missing don't add any
            For Each sTestPath In sTestPaths
                If sTestPath <> "[PATH]" Then
                    If Not Directory.Exists(sTestPath) Then
                        PathsOK = False
                    End If
                End If
            Next

            Dim prefs As AcadPreferences = CType(AcadAppStartUp.Preferences, AcadPreferences)

            If PathsOK = True Then

                If sPath.Contains("[PATH]") Then
                    sPath = Replace(sPath, "[PATH]", prefs.Files.SupportPath)
                Else
                    sPath = prefs.Files.SupportPath & ";" & sPath
                End If
                prefs.Files.SupportPath = sPath

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub AddToToolPalettePath(ByVal sPath As String)

        Dim sTestPaths() As String
        Dim sTestPath As String

        Dim sExistingPaths() As String
        Dim sExistingPath As String

        Dim PathsOK As Boolean = True
        Dim sCleanPath As String = ""
        ' Dim sDocumentsAndSettings As String

        Try



            sPath = Common.Settings.Manager.EvaluateExpression(sPath)
            'GetConfigSettings()
            'sDocumentsAndSettings = sDocumentsAndSettingsFolder

            'sPath = Replace(sPath, "[ROAMABLEROOTPREFIX]", ThisDrawing.GetVariable("ROAMABLEROOTPREFIX"))
            'sPath = Replace(sPath, "[ProgramFiles]", My.Computer.FileSystem.SpecialDirectories.ProgramFiles)
            'sPath = Replace(sPath, "[DocumentsAndSettings]", sDocumentsAndSettings)
            'sPath = Replace(sPath, "[LOCALROOTPREFIX]", ThisDrawing.GetVariable("LOCALROOTPREFIX"))
            'sPath = Replace(sPath, "[AD-SITE]", Core.Environment.GetADSite)

            sTestPaths = sPath.Split(";"c)

            ' if any one of the paths is missing don't add any
            For Each sTestPath In sTestPaths
                If sTestPath <> "[PATH]" Then
                    If Not Directory.Exists(sTestPath) Then
                        PathsOK = False
                    End If
                End If
            Next

            '' get AutoCAD preferences
            Dim prefs As AcadPreferences = CType(AcadAppStartUp.Preferences, AcadPreferences)

            ' if any one of the paths are present don't add any assume they have been added
            sExistingPaths = prefs.Files.ToolPalettePath.ToString.Split(";"c)
            For Each sTestPath In sTestPaths
                If sTestPath <> "[PATH]" Then
                    For Each sExistingPath In sExistingPaths
                        If sTestPath.ToUpper = sExistingPath.ToUpper Then
                            PathsOK = False
                        End If
                    Next
                End If
            Next

            sCleanPath = sPath.Replace("[PATH]", "")

            If prefs.Files.ToolPalettePath.ToString.Contains(sCleanPath) Then
                PathsOK = False
            End If

            If PathsOK = True Then
                If sPath.Contains("[PATH]") Then
                    sPath = Replace(sPath, "[PATH]", prefs.Files.ToolPalettePath)
                Else
                    sPath = prefs.Files.ToolPalettePath & ";" & sPath
                End If
                prefs.Files.ToolPalettePath = sPath
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub RemoveSupportPaths(ByVal sPath As String)

        Dim sPathNew As String
        ' Dim sDocumentsAndSettings As String

        Try

            sPath = Common.Settings.Manager.EvaluateExpression(sPath)
            'GetConfigSettings()
            'sDocumentsAndSettings = sDocumentsAndSettingsFolder

            'sPath = Replace(sPath, "[ROAMABLEROOTPREFIX]", ThisDrawing.GetVariable("ROAMABLEROOTPREFIX"))
            'sPath = Replace(sPath, "[ProgramFiles]", My.Computer.FileSystem.SpecialDirectories.ProgramFiles)
            'sPath = Replace(sPath, "[DocumentsAndSettings]", sDocumentsAndSettings)
            'sPath = Replace(sPath, "[LOCALROOTPREFIX]", ThisDrawing.GetVariable("LOCALROOTPREFIX"))
            'sPath = Replace(sPath, "[AD-SITE]", Core.Environment.GetADSite)
            'sPath = Replace(sPath, "[PATH]", "")

            '' get AutoCAD preferences
            Dim AcadPrefs As AcadPreferences = CType(AcadAppStartUp.Preferences, AcadPreferences)

            ' Remove it if its at the end of the path
            sPathNew = AcadPrefs.Files.SupportPath.ToString.Replace(";" & sPath, "")

            AcadPrefs.Files.SupportPath = sPathNew

            ' Remove it if its at the front of the path
            sPathNew = AcadPrefs.Files.SupportPath.ToString.Replace(sPath & ";", "")

            AcadPrefs.Files.SupportPath = sPathNew

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub RemoveToolPalettePaths(ByVal sPath As String)

        Dim sPathNew As String
        ' Dim sDocumentsAndSettings As String

        Try



            sPath = Common.Settings.Manager.EvaluateExpression(sPath)

            'GetConfigSettings()
            'sDocumentsAndSettings = sDocumentsAndSettingsFolder

            'sPath = Replace(sPath, "[ROAMABLEROOTPREFIX]", ThisDrawing.GetVariable("ROAMABLEROOTPREFIX"))
            'sPath = Replace(sPath, "[ProgramFiles]", My.Computer.FileSystem.SpecialDirectories.ProgramFiles)
            'sPath = Replace(sPath, "[DocumentsAndSettings]", sDocumentsAndSettings)
            'sPath = Replace(sPath, "[LOCALROOTPREFIX]", ThisDrawing.GetVariable("LOCALROOTPREFIX"))
            'sPath = Replace(sPath, "[AD-SITE]", Core.Environment.GetADSite)
            'sPath = Replace(sPath, "[PATH]", "")

            '' get AutoCAD preferences
            Dim AcadPrefs As AcadPreferences = CType(AcadAppStartUp.Preferences, AcadPreferences)

            ' Remove it if its at the end of the path
            sPathNew = AcadPrefs.Files.ToolPalettePath.ToString.Replace(";" & sPath, "")

            AcadPrefs.Files.ToolPalettePath = sPathNew

            ' Remove it if its at the front of the path
            sPathNew = AcadPrefs.Files.ToolPalettePath.ToString.Replace(sPath & ";", "")

            AcadPrefs.Files.ToolPalettePath = sPathNew

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub RestoreCUIByName(ByVal CUIName As String)



        Dim BackupDateTime As String

        If Not CUIName.Contains("CUIX") Then
            CUIName = CUIName & ".CUIX"
        End If

        'PrevWorkspace = AcadApp.GetSystemVariable("WSCURRENT")
        Dim PrevWorkspace As String = ThisDrawingStartUp.GetVariable("WSCURRENT").ToString

        Dim LocalFolder As String = ThisDrawingStartUp.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Support")
        Dim LocalFile As String = LocalFolder.CombinePath(CUIName)
        Dim AcadCachedFile As String = Settings.Manager.AutoCAD.Path.CombinePath("UserDataCache\Settings", CUIName)
        Dim CustomisationCachedFile As String = Settings.Manager.AE.Path.CombinePath("UserDataCache\Settings", CUIName)

        ' Check if the AutoCAD version of the file matches the Customisation version copy if required 
        ' In Case user modified AutoCAD's User Data Cache location
        If File.Exists(AcadCachedFile) Then
            If File.Exists(CustomisationCachedFile) Then
                If CompareFiles(CustomisationCachedFile, AcadCachedFile) = False Then
                    File.Copy(CustomisationCachedFile, AcadCachedFile, True)
                End If
            End If
        End If

        ' Check if the Local version of the file matches the Customisation version backup and copy if required 
        If File.Exists(LocalFile) Then
            If File.Exists(CustomisationCachedFile) Then
                If CompareFiles(CustomisationCachedFile, LocalFile) = False Then
                    BackupDateTime = Now.ToString("yyyy-mm-dd HH-mm-ss")
                    'BackupDateTime = Now().ToString.Replace(":", "-")
                    'BackupDateTime = BackupDateTime.Replace("/", "-")
                    File.Copy(LocalFile, LocalFile & "-" & BackupDateTime, True)
                    File.Copy(CustomisationCachedFile, LocalFile, True)
                    Acad_MessageBox("Cached file was different to local - " & CUIName & " file has been restored.", , , , , , , True, LogName)
                    Acad_MessageBox("The old " & CUIName & " file has been backed up here: " & LocalFile & "-" & BackupDateTime, , , , , , , True, LogName)
                End If
            End If
        End If

        ' Delete all but last 10 Acad.CUI backup files
        ' Iterate the folder look for Acad.CUI-* and only keep the last 10
        ' Make sure we don't delete Acad.CUI or Acad.CUI-Original.

        '  On Error Resume Next
        Dim sFiles() As String
        Dim sFile As String
        Dim PossibleFilesToDeleteCollection As New Collection
        sFiles = Directory.GetFiles(LocalFolder)
        For Each sFile In sFiles
            If UCase(sFile) Like UCase("*" & CUIName & ".CUIX-*") = True Then
                If Not UCase(sFile) Like "*" & CUIName & ".CUIX" And
                   Not UCase(sFile) Like "*" & CUIName & ".CUIX-ORIGINAL" Then
                    PossibleFilesToDeleteCollection.Add(sFile, sFile)
                    If Err.Number <> 0 Then
                        Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , LogName)
                        Err.Clear()
                    Else

                    End If
                End If
            End If
        Next

        If PossibleFilesToDeleteCollection.Count > 0 Then
            ' Get rid of previous SP2 backups
            For Each sFile In PossibleFilesToDeleteCollection
                If UCase(sFile) Like "*PM" Or UCase(sFile) Like "*AM" Then
                    File.Delete(sFile)
                    PossibleFilesToDeleteCollection.Remove(sFile)
                End If
            Next

            ' Sort Collection
            SortCollection(PossibleFilesToDeleteCollection, "Value", True)

            ' Only keep the last 10 files
            Dim i As Integer

            If PossibleFilesToDeleteCollection.Count > 10 Then
                For i = 1 To PossibleFilesToDeleteCollection.Count - 10
                    File.Delete(CStr(PossibleFilesToDeleteCollection(i)))
                Next
            End If

        End If
    End Sub

    ''' <summary>
    ''' Iterate the nominated registry keys and delete them
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub RemoveRegKeysFromPreviousRun()



        Try

            For Each RegKey As Common.Settings.Manager.RegistryKey In Settings.Manager.AutoCAD.RegistryKeysToRemove

                RegistryDelete(RegKey.RegArea, RegKey.RegHive, RegKey.RegKeyName)

            Next

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Iterate the nominated registry keys and delete them
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub AddRegKeys()

        Try

            For Each RegKey As Common.Settings.Manager.RegistryKey In Settings.Manager.AutoCAD.RegistryKeysToAdd

                If String.IsNullOrEmpty(RegKey.IfFileExists) Then
                    RegistryWrite(RegKey.RegArea, RegKey.RegHive.Replace("[CurrentProfile]", ThisDrawingUtilities.GetVariable("CPROFILE").ToString), RegKey.RegKeyName, RegKey.Regvalue, RegKey.RegType)
                Else
                    If System.IO.File.Exists(Common.Settings.Manager.EvaluateExpression(RegKey.IfFileExists)) Then
                        RegistryWrite(RegKey.RegArea, RegKey.RegHive.Replace("[CurrentProfile]", ThisDrawingUtilities.GetVariable("CPROFILE").ToString), RegKey.RegKeyName, RegKey.Regvalue, RegKey.RegType)
                    End If
                End If
            Next

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

#End Region

#Region "Commands"

    ''' <summary>
    ''' Call the help file associated with the assembly - help file name = assembly name .chm
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_PatchHelp", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub ShowContents()

        Try
            CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ViewLog", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub ShowLog()
        Try

            'Dim LogFolder As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData).CombinePath("Jacobs")
            Dim LogFolder As String = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]"))

            Shell("explorer.exe " & LogFolder, AppWinStyle.NormalFocus, False)


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_UserFiles", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub JacobsUserFiles()
        Try
            Shell("Explorer.exe " & Settings.Manager.AutoCAD.UserSettingsFolder, AppWinStyle.NormalFocus, False)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    <CommandMethod("Jacobs_ViewUserConfigXML")>
    Public Sub ShowXML()

        If File.Exists(Settings.Manager.AE.UserSettingsFileName) Then
            Shell("Notepad.exe " & Settings.Manager.AE.UserSettingsFileName, AppWinStyle.NormalFocus, False)
        Else
            Acad_MessageBox(Settings.Manager.AE.UserSettingsFileName & vbCr & vbCr & "File not found perhaps no Settings have been changed by the user at this time.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        If File.Exists(Settings.Manager.AutoCAD.UserSettingsFileName) Then
            Shell("Notepad.exe " & Settings.Manager.AutoCAD.UserSettingsFileName, AppWinStyle.NormalFocus, False)
        Else
            Acad_MessageBox(Settings.Manager.AutoCAD.UserSettingsFileName & vbCr & vbCr & "File not found perhaps no Settings have been changed by the user at this time.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , LogName)
        End If

    End Sub

    <CommandMethod("Jacobs_ViewMasterConfigXML")>
    Public Sub ShowConfigXML()
        Try

            If File.Exists(Settings.Manager.AE.DefaultConfigurationFilePathed) Then
                Shell("Notepad.exe " & Settings.Manager.AE.DefaultConfigurationFilePathed, AppWinStyle.NormalFocus, False)
            Else

                Acad_MessageBox(Settings.Manager.AE.DefaultConfigurationFilePathed & " File not found.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , LogName)

            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ResetBatchProcessor", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub ResetBatchProcessor()
        Jacobs.Common.Core.RegistryDelete("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing")
    End Sub


    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ShowADSiteName", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub ShowADSiteName()
        Try

            Acad_MessageBox("Your AD SITE name is: " & Settings.Manager.AE.ADSiteName, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    '<Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_CopyUserFiles", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    'Public Sub CopyJacobsUserFiles()

    '    Try

    '        Dim sFiles() As String
    '        Dim sFile As String
    '        'Dim vFile() As String

    '        sFiles = Directory.GetFiles(Settings.Manager.AutoCAD.CachedSettingsFolder)

    '        For Each sFile In sFiles

    '            If UCase(Path.GetFileName(sFile)) Like UCase("*User*.*") = True Then

    '                'MsgBox(UCase(sFile) & " is Like" & UCase("*User*.*"))

    '                'vFile = Split(sFile, "\")
    '                'sFile = vFile(UBound(vFile))

    '                'Dim source As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\User Files\Settings", sFile)
    '                Dim destination As String = Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(sFile)

    '                If File.Exists(destination) Then
    '                    If Acad_MessageBox("A file named " & destination & vbCrLf & "Already exists on this machine, would you like to overwrite it?", _
    '                                        System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, _
    '                                       MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then

    '                        File.Copy(sFile, destination, True)
    '                    End If
    '                Else
    '                    File.Copy(sFile, destination, True)
    '                End If

    '            End If

    '        Next

    '        JacobsUserFiles()

    '    Catch ex As Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try

    'End Sub

    <CommandMethod("Jacobs_MakeNDrivePaths")>
    Public Sub MakeNDrivePaths()

        Try

            JacobsCreateDirectory(Settings.Manager.AutoCAD.NetworkFontsFolder)

            JacobsCreateDirectory(Settings.Manager.AutoCAD.NetworkSupportFolder)

            JacobsCreateDirectory(Settings.Manager.AutoCAD.NetworkTemplateFolder)

            JacobsCreateDirectory(Settings.Manager.AutoCAD.NetworkPlotStyleFolder)

            JacobsCreateDirectory(Settings.Manager.AutoCAD.NetworkPMPFolder)

            JacobsCreateDirectory(Settings.Manager.AutoCAD.NetworkDictionaryFolder)

        Catch ex As System.Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

        End Try

    End Sub

    ''' <summary>
    ''' Called by menu
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_AboutAE", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub AE_About()
        Try
            Dim AboutAE As New StartUpAboutForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(AboutAE)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Public Sub SetQNEWPath(ByRef sQNewTemplate As String)

        Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
        Dim MyTemplate As Autodesk.AutoCAD.Interop.IAcadPreferencesFiles
        Dim sTemplateName As String
        Dim sConfigNameFromRule As String

        Try

            preferences = ThisDrawingStartUp.Application.Preferences
            MyTemplate = ThisDrawingStartUp.Application.Preferences.Files

            currQNEWTemplate = preferences.Files.QNewTemplateFile

            sConfigNameFromRule = RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False)

            If Not sConfigNameFromRule Like "T@*" Then
                If (sConfigNameFromRule Like "*[-]*[-]*[-]*[-]*") Then ' If it's one of ours.
                    sTemplateName = Split(sConfigNameFromRule, "-")(4) & ".DWT"

                    '  MsgBox(RUNTIMEConfigPath.CombinePath("Settings", sTemplateName))

                    If System.IO.File.Exists(RUNTIMEConfigPath.CombinePath("Support", sTemplateName)) = True Then
                        If System.IO.File.Exists(preferences.Files.TemplateDwgPath.CombinePath(sTemplateName)) = True Then
                            My.Computer.FileSystem.DeleteFile(preferences.Files.TemplateDwgPath.CombinePath(sTemplateName))
                        End If
                        My.Computer.FileSystem.CopyFile(RUNTIMEConfigPath.CombinePath("Support", sTemplateName), preferences.Files.TemplateDwgPath.CombinePath(sTemplateName))
                        MyTemplate.QNewTemplateFile = preferences.Files.TemplateDwgPath.CombinePath(sTemplateName)
                    End If
                End If
            Else
                Acad_MessageBox("This is a test Template - QNEW and New template file copying has been omitted.", , , , , , , True, LogName)
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Public Sub SetQNEWPathNew(ByRef sQNewTemplate As String)

        Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
        Dim MyTemplate As Autodesk.AutoCAD.Interop.IAcadPreferencesFiles
        Dim sTemplateName As String
        Dim sConfigNameFromRule As String

        Try

            preferences = ThisDrawingUtilities.Application.Preferences
            MyTemplate = ThisDrawingUtilities.Application.Preferences.Files

            currQNEWTemplate = preferences.Files.QNewTemplateFile

            sConfigNameFromRule = RuleAccessors.GetruleValue("FULLCONFIGNAME", "NotFound", , False)

            If (sConfigNameFromRule Like "*[-]*[-]*[-]*") Then ' If it's one of ours.
                sTemplateName = sConfigNameFromRule & ".DWT"

                If System.IO.File.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigNameFromRule, "Support", sTemplateName)) = True Then
                    If System.IO.File.Exists(preferences.Files.TemplateDwgPath.CombinePath(sTemplateName)) = True Then

                        My.Computer.FileSystem.DeleteFile(preferences.Files.TemplateDwgPath.CombinePath(sTemplateName))

                    End If
                    My.Computer.FileSystem.CopyFile(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(sConfigNameFromRule, "Support", sTemplateName), preferences.Files.TemplateDwgPath.CombinePath(sTemplateName))
                    MyTemplate.QNewTemplateFile = preferences.Files.TemplateDwgPath.CombinePath(sTemplateName)
                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    <CommandMethod("Jacobs_CopyFonts")>
    Public Sub CopyFonts()

        Try

            If Settings.Manager.AutoCAD.UseOfficeNetworkFonts = True Then '<UseOfficeNetworkFonts>true</UseOfficeNetworkFonts>
                If Directory.Exists(Settings.Manager.AutoCAD.NetworkFontsFolder) = True Then '<NetworkFontsFolder>[NETWORKCADCFG]\[SHAREDAcadNAME]\[AD-SITE]\Fonts</NetworkFontsFolder>
                    If Directory.Exists(Settings.Manager.AutoCAD.UserRoamingSupportFolder) = True Then '<UserRoamingSupportFolder>[USERAPPDATAROAMING]\Autodesk\AutoCAD 2017\R21.0\enu\Support</UserRoamingSupportFolder>
                        CopyFontsFromNetwork()
                        Acad_MessageBox("Common office Fonts are now up to date.", , , , , , , True, LogName)
                    Else
                        Acad_MessageBox("ERROR: Office SHX and SHP files on " & Settings.Manager.AutoCAD.NetworkFontsFolder & " COULD NOT BE copied.", , , , , , , True, LogName)
                        Acad_MessageBox("ERROR: Because local font path: " & Settings.Manager.AutoCAD.UserRoamingSupportFolder & " could not be found.", , , , , , , True, LogName)
                    End If
                Else
                    If Settings.Manager.AE.ADSiteName <> "" Then
                        Acad_MessageBox("Common office Font folder has not been setup here or network drives have not been mapped: " & Settings.Manager.AutoCAD.NetworkFontsFolder & vbCrLf &
                                          "Talk to your CAD Co-ordinator if they are required.", , , , , , , True, LogName)
                    Else
                        Acad_MessageBox("AD Site Name could not be determined: " & vbCrLf &
                                           "I working from home you may need to VPN into the Jacobs Domain.", , , , , , , True, LogName)
                    End If
                End If
            Else
                Acad_MessageBox("Fonts have not been copied from network location" & vbCrLf &
                                    "If you have previously being using network Fonts" & vbCrLf &
                                    "You may wish to run the RestoreOriginalAutoCADFonts command.", , , , , , , True, LogName)
            End If

            '  End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    <CommandMethod("Jacobs_CopyOfficeMenu")>
    Public Sub CopyOfficeMenuFromNetwork()
        Try

            If Settings.Manager.AutoCAD.UseOfficeNetworkMenu = True Then

                Dim sToExecute As String
                Dim sMenuWildCard As String

                For Each Menu As Common.Settings.Manager.AdditionalMenu In Settings.Manager.AutoCAD.AdditionalMenus
                    sMenuWildCard = Settings.Manager.AutoCAD.NetworkMenuFolder.CombinePath(Path.GetFileNameWithoutExtension(Menu.CUIName) & ".*")
                    If System.IO.File.Exists(sMenuWildCard.Replace(".*", ".CUIX")) Then
                        sMenuWildCard = Settings.Manager.AutoCAD.NetworkMenuFolder.CombinePath(Path.GetFileNameWithoutExtension(Menu.CUIName) & ".*")

                        'Dim destination As String = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]\[AEPRODUCTNAME]"))
                        Dim destination As String = Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents

                        sToExecute = "XCOPY """ & sMenuWildCard & """ """ & destination & """ /D /V /Y /I /C /Q"
                        Shell(sToExecute, AppWinStyle.Hide, False)
                    End If
                Next
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Check to see if the user has elected to let the AE manage their CUI files and if so manage them
    ''' By: Making the Acad.cuix the Enteprise CUIX and the Acad Custom.CUIX the Main CUIX
    ''' This check happens every time
    ''' </summary>
    ''' <remarks></remarks>
    <CommandMethod("Jacobs_ManageCUIS_Select")>
    Public Sub Jacobs_ManageCUIS_Select()

        Try

            '' Check to see if user wishes to Manage CUIs or not
            If Settings.Manager.AutoCAD.ManageCUIs = True Then

                Acad_MessageBox("User has the Manage UI files option enabled in the Options Tab Jacobs Customisation: ", , , , , , , True, LogName)

                '' The presence of certain files on a PC can be used to prevent AE UI file management. (example if a file "C:\Temp\X.txt" exists don't manage cuixs at all)
                If CheckForConflictingApps() = False Then

                    'Disabled S.Houghton 15/08/17
                    'Acad_MessageBox("    No conflicting application definitions exist in the " & My.Settings.ConfigurationXML & " file.", , , , , , , True, LogName)

                    If CheckForThirdPartyAppProfiles() = False Then

                        'Disabled S.Houghton 15/08/17
                        'Acad_MessageBox("    The current profile does not match any of the excluded profiles in the " & My.Settings.ConfigurationXML & " file.", , , , , , , True, LogName)

                        ' The user Can have managed CUIs but choose not to restore the original Enterprise CUI file from the cached locaton
                        If Settings.Manager.AutoCAD.RestoreAcadCUI = True Then

                            Acad_MessageBox("The AutoCAD Environment is Restoring Enterprise CUI from cached location", , , , , , , True, LogName)

                            System.IO.File.Copy(Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX"),
                                                Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AutoCAD.EntCUIFileNameNoExt & ".CUIX"), True)

                        End If

                        Acad_MessageBox("The AutoCAD Environment Is MANAGING UI files", , , , , , , True, LogName)

                        SetMainAndEnterpriseUIFiles()
                        'Manage3rdPartyApps(Settings.Manager.AutoCAD.Name)

                    Else
                        'Disbaled S.Houghton 15/08/17
                        'Acad_MessageBox("    The current profile matches one of the excluded profiles in the " & My.Settings.ConfigurationXML & " file", , , , , , , True, LogName)
                        Acad_MessageBox("** THE AE WILL NOT BE MANAGING the MAIN UI file but will continue to manage the Enterprise UI file and load partial menus **", , , , , , , True, LogName)

                        'SetEnterpriseUIFile()
                        'Manage3rdPartyApps(Settings.Manager.AutoCAD.Name, False)

                    End If
                Else
                    'Disabled S.Houghton 15/08/17
                    'Acad_MessageBox("    Conflicting application files exist on this PC as specified in the " & My.Settings.ConfigurationXML & " file.", , , , , , , True, LogName)
                    Acad_MessageBox("** THE AE Jacobs WILL NOT BE MANAGING CUIs **", , , , , , , True, LogName)

                End If
            Else

                Acad_MessageBox("User has the UI File Management option disabled in the Options Tab Jacobs Customisation", , , , , , , True, LogName)
                Acad_MessageBox("** Jacobs WILL NOT BE MANAGING CUIs **", , , , , , , True, LogName)

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' For the current AutoCAD product it does all the logistics for seting the CUIX files as follows
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ManageCUIs", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub SetMainAndEnterpriseUIFiles()

        Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
        Dim MainMenu As String
        Dim EnterpriseMenu As String

        Try

            preferences = ThisDrawingUtilities.Application.Preferences
            MainMenu = preferences.Files.MenuFile
            EnterpriseMenu = preferences.Files.EnterpriseMenuFile

            ' See if Enterprise menu is correct
            If EnterpriseMenu.ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper & ".CU") Or
                EnterpriseMenu.ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper) Then

                ' Leave it alone
                ' Now check if main is correct
                If MainMenu.ToUpper.Contains(Settings.Manager.AutoCAD.MainCUIFileNameNoExt.ToUpper & ".CU") Or
                    MainMenu.ToUpper.Contains(Settings.Manager.AutoCAD.MainCUIFileNameNoExt.ToUpper) Then
                    ' Leave it it's fine
                    ' Bail both good
                Else
                    ' Ok Main needs to be changed since we know ent is already correct simply change main
                    ' Set it to AE Main
                    preferences.Files.MenuFile = Settings.Manager.AutoCAD.MainMenuFileNamePathed
                    ' Bail 
                End If
            Else

                ' Ent is not correct
                ' Test to see if the main has the ENT loaded
                If MainMenu.ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper & ".CU") Or
                    MainMenu.ToUpper.Contains(Settings.Manager.AutoCAD.EntCUIFileNameNoExt.ToUpper) Then

                    ' Main menu has the enterprise menu loaded on it

                    ' does the Ent have the main menu ?
                    If EnterpriseMenu.ToUpper.Contains(Settings.Manager.AutoCAD.MainCUIFileNameNoExt.ToUpper & ".CU") Or
                       EnterpriseMenu.ToUpper.Contains(Settings.Manager.AutoCAD.MainCUIFileNameNoExt.ToUpper) Then

                        ' Yes so we have to set main to . first Big swap over main to . first
                        preferences.Files.MenuFile = "."
                        preferences.Files.EnterpriseMenuFile = Settings.Manager.AutoCAD.EnterpriseMenuFileNamePathed
                        preferences.Files.MenuFile = Settings.Manager.AutoCAD.MainMenuFileNamePathed

                    Else

                        ' Yes ok to do simple load both ent and main stuffed
                        preferences.Files.MenuFile = Settings.Manager.AutoCAD.MainMenuFileNamePathed
                        preferences.Files.EnterpriseMenuFile = Settings.Manager.AutoCAD.EnterpriseMenuFileNamePathed

                    End If

                Else

                    ' Ent is not correct and ent is not loaded on main fix ent
                    preferences.Files.EnterpriseMenuFile = Settings.Manager.AutoCAD.EnterpriseMenuFileNamePathed

                    ' Check if main is correct?
                    ' Leave it alone
                    ' Now check if main is correct
                    If MainMenu.ToUpper.Contains(Settings.Manager.AutoCAD.MainCUIFileNameNoExt.ToUpper & ".CU") Or
                        MainMenu.ToUpper.Contains(Settings.Manager.AutoCAD.MainCUIFileNameNoExt.ToUpper) Then
                        ' Leave it it's fine
                        ' Bail both good
                    Else

                        ' Ok Main needs to be changed since we know ent is already correct simply change main
                        ' Set it to AE Main
                        preferences.Files.MenuFile = Settings.Manager.AutoCAD.MainMenuFileNamePathed
                        ' Bail 
                    End If

                End If

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    <CommandMethod("Jacobs_CopyRasterMenu")>
    Public Sub CopyRasterDesignMenu()

        ' Check if the AutoCAD version of the file matches the Jacobs Customisation version copy if required 
        ' In Case user modified AutoCAD's User Data Cache location

        Dim CachedRasterDesignFile As String = "C:\Program Files\Autodesk\AutoCAD Raster Design 2017\UserDataCache\Settings\AecCo.CUIX"
        Dim UserRasterCUIX As String = Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath("AecCo.CUIX")

        If File.Exists(CachedRasterDesignFile) Then
            If File.Exists(UserRasterCUIX) Then
                If CompareFiles(CachedRasterDesignFile, UserRasterCUIX) = False Then
                    File.Copy(CachedRasterDesignFile, UserRasterCUIX, True)
                End If
            Else
                File.Copy(CachedRasterDesignFile, UserRasterCUIX, True)
            End If
        End If

    End Sub

    ''' <summary>
    ''' This function is in charge of customising autocad as per the Settings in the Template xml file
    ''' Some Settings will be reset every time autocad fires off and other will vary
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_CustomiseAutoCAD", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Private Sub CustomiseAutoCAD()

        ' In case it was called from lisp Error redefinition
        ' Once per dll at the very beginning we should call this to ensure that the Settings object is available
        ' If a user had overridden the original Settings then they will be honored.
        GetConfigSettings()



        '' Add any required registry keys for this AutoCAD product
        AddRegKeys()


        ' Set the environment variables as per the configuration.XML file
        ' Environment variables can be set to be persistent - if they are persistent they get set every time
        SetEnvironmentVariables()


        ' Set the system variables as per the configuration.XML file
        ' System variables can be set to be persistent - if they are persistent they get set every time
        SetSystemVariables()

        ' Create Shortcuts to network drives if the locations are present - shortcuts are first deleted and if their paths exist they get recreated
        ' This happens every time autocad starts up
        CreateShortCuts(Settings.Manager.AutoCAD.NetworkSupportShortcutName, Settings.Manager.AutoCAD.UserSettingsFolder, Settings.Manager.AutoCAD.NetworkSupportFolder, Settings.Manager.AutoCAD.CreateSupportShortCut)
        CreateShortCuts(Settings.Manager.AutoCAD.NetworkPMPShortcutName, Settings.Manager.AutoCAD.UserRoamingPMPFilesFolder, Settings.Manager.AutoCAD.NetworkPMPFolder, Settings.Manager.AutoCAD.CreatePMPShortCut)
        CreateShortCuts(Settings.Manager.AutoCAD.NetworkPlotStylesShortcutName, Settings.Manager.AutoCAD.UserRoamingPlotStylesFolder, Settings.Manager.AutoCAD.NetworkPlotStyleFolder, Settings.Manager.AutoCAD.CreatePlotStyleShortCut)
        CreateShortCuts(Settings.Manager.AutoCAD.NetworkPC3ShortcutName, Settings.Manager.AutoCAD.UserRoamingPlottersFolder, Settings.Manager.AutoCAD.NetworkPC3Folder, Settings.Manager.AutoCAD.CreatePC3ShortCut)
        CreateShortCuts(Settings.Manager.AutoCAD.NetworkTemplateShortcutName, Settings.Manager.AutoCAD.UserLocalTemplateFolder, Settings.Manager.AutoCAD.NetworkTemplateFolder, Settings.Manager.AutoCAD.CreateTemplateShortCut, False)
        CreateShortCuts(Settings.Manager.AutoCAD.NetworkBlockFinderShortcutName, Settings.Manager.AutoCAD.UserSettingsFolder, Settings.Manager.AutoCAD.NetworkBlockFinderFolder, Settings.Manager.AutoCAD.CreateBlockFinderShortCut)

        ' Custom dictionary is a special case system variable - it can be set by the user to point to an office location to cater for country specific
        ' spelling - such as the UK - this only occurs once per user
        CustomDictionary()


        ' If UsenetWorkFonts flag is set to true the system will copy all the Fonts in the network location to the 
        ' PC location - this only occurs once per user
        CopyFonts()


        '' Copy any office controlled menus from the local office menu location on N:
        '' To User Settings folder
        'CopyOfficeMenuFromNetwork()

        '' If Autocad is reset via Autodesk's Reset AutoCAD command the AecCo.cuix with the Raster Design Menu would not get copied across.
        '' This next bit of code checks to see if Raster is installed and copies the menu file if required.
        'CopyRasterDesignMenu()

        ' This copies the cached files to the User Area
        'Disabled Steven Houghton 28/09/2017
        'CopyJacobsCachedFiles()

        'Jacobs_StartUpTab.DoIt()

        '' Check to see if the user has elected to let the AE manage their CUI files and if so manage them
        '' By: Making the Acad.cuix the Enteprise CUIX and the Acad Custom.CUIX the Main CUIX
        '' This check happens every time
        '  Jacobs_ManageCUIS_Select()

        '' Settings in the Configuration.xml file determine which Additional menus need to be loaded if present
        '' This routine will load the menus and show toolbars and menus as well as add in Settings search paths
        '' In 2017 products the AutoLoader is not Profile Aware - this routine will load based on profile if
        '' they are provided - else it will load every time
        '' Checks every time and is independent of ManagedCUIs

        '' Record that this AutoCAD has been setup for this user - so we don't do things again
        Dim Ae As New Common.Settings.Manager.AEProduct()
        Properties.SetProperties(Ae, Nothing)

        Ae.Name = Settings.Manager.AE.Name
        Ae.AutoCADHasBeenCustomised = True

        '' write out user snippet
        Settings.PartialSettingsSaveAE(Ae)

        '' Merge User PGP User LIN User PAT
        MergeFilesNonConfiguredrawings()


        '' Notify user via the log file.
        Acad_MessageBox("Populated Jacobs Customisation Options Tab", , , , , , , True, LogName)

        Acad_MessageBox("-[ Jacobs Customisation Message ]-----------------------------------------", , , , , , , True, LogName)
        Acad_MessageBox("Type in Jacobs_ViewLog to see the StartUp.log file.", , , , , , , True, LogName)
        Acad_MessageBox("For additional information on this patch type Jacobs_PatchHelp.", , , , , , , True, LogName)
        Acad_MessageBox("-----------------------------------------------------------------------", , , , , , , True, LogName)

        ' Revert the AutoCAD drawing database.. DBMOD (so that DBMOD  0) hence we don't get asked to save drawing on exit
        AcadAppStartUp.DocumentManager.MdiActiveDocument.PopDbmod()

    End Sub


    'Public Shared Function ExtractConfiguration(ByVal sConfigurationName As String, ByVal sSelectedProduct As String) As Boolean

    '    'GAD Added "As Boolean to line below
    '    Dim bSuccess As Boolean = True
    '    'Dim regVersion As RegistryKey
    '    Dim sExtractionPath As String = ""
    '    Dim sFileToExtract As String = ""
    '    Dim sItems() As String
    '    'Dim fso As New FileSystemObject

    '    'GAD Removed the line below and added the following one
    '    'Dim oFile As System.IO.File
    '    Dim oFile As System.IO.File = Nothing

    '    Dim oSystemWriter As System.IO.StreamWriter

    '    sExtractionPath = AllSettings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(sConfigurationName)

    '    If Not Directory.Exists(sExtractionPath) Then
    '        Directory.CreateDirectory(sExtractionPath)
    '    End If

    '    If (bSuccess) Then

    '        ' Remove configuration directory (if it exists)
    '        'If fso.FolderExists(sExtractionPath) Then
    '        '    fso.DeleteFolder(sExtractionPath, True)
    '        'End If

    '        ' Create new configuration directory
    '        If Not Directory.Exists(sExtractionPath) Then
    '            Directory.CreateDirectory(sExtractionPath)
    '        End If

    '        ' Separate configuration categories
    '        sItems = sConfigurationName.Split("-"c)

    '        ' Extract each of the five parts making up the configuration
    '        For nCurrentCategory As Integer = sItems.Length - 1 To 0 Step -1

    '            If (nCurrentCategory + 1 = CATEGORY_CLIENT) Then
    '                sFileToExtract = AllSettings.Manager.AE.LibraryFolder & "\" & GetCategoryDirectory(nCurrentCategory + 1) & "\" & sConfigurationName & ".zip"
    '            Else
    '                If (sItems(nCurrentCategory).Replace("T@", "") <> "None") Then
    '                    sFileToExtract = AllSettings.Manager.AE.LibraryFolder & "\" & GetCategoryDirectory(nCurrentCategory + 1) & "\" & FormatVersion(sItems(nCurrentCategory)) & ".zip"
    '                    If sFileToExtract.IndexOf("T@") > -1 Then
    '                        sFileToExtract = sFileToExtract.Replace("T@", "")
    '                    End If
    '                End If
    '            End If

    '            ' Ensure file exists
    '            If File.Exists(sFileToExtract) Then
    '                UnzipConfigurationFile(sFileToExtract, sExtractionPath, False, nCurrentCategory + 1)
    '            End If

    '        Next

    '        Dim sDestination As String = sExtractionPath.CombinePath(AllSettings.Manager.AE.ExtractionFinishedFileName)  'AppSettings.Item("DummyFile")

    '        oSystemWriter = IO.File.CreateText(sDestination)
    '        oSystemWriter.WriteLine("Date: " & DateTime.Now.Day.ToString() & "/" & DateTime.Now.Month.ToString() & "/" & DateTime.Now.Year.ToString())
    '        oSystemWriter.Close()

    '    End If

    '    Return bSuccess
    'End Function

    'Public Shared Sub UnzipConfigurationFile(ByVal sFileToExtract As String, ByVal sExtractionPath As String, ByVal bTemplateOnly As Boolean, ByVal nCategory As Integer)

    '    Dim strmZipInputStream As ICSharpCode.sharpZipLib.Zip.ZipInputStream
    '    Dim bUnzipFile As Boolean = False
    '    'Dim fso As New FileSystemObject

    '    strmZipInputStream = New ICSharpCode.sharpZipLib.Zip.ZipInputStream(System.IO.File.OpenRead(sFileToExtract))

    '    Dim objZipEntry As ICSharpCode.sharpZipLib.Zip.ZipEntry

    '    objZipEntry = strmZipInputStream.GetNextEntry
    '    While Not (objZipEntry Is Nothing)

    '        ' Determine directory and filename
    '        Dim sDirectoryName As String = Path.GetDirectoryName(objZipEntry.Name)
    '        Dim sFileName As String = Path.GetFileName(objZipEntry.Name)

    '        bUnzipFile = False
    '        If (bTemplateOnly And sFileName.EndsWith(".dwt")) Then
    '            bUnzipFile = True
    '        ElseIf (Not bTemplateOnly) Then
    '            bUnzipFile = True
    '        End If

    '        If (bUnzipFile) Then

    '            ' Create directories required for this file
    '            Directory.CreateDirectory(sExtractionPath & "\" & sDirectoryName)

    '            If (sFileName <> String.Empty) Then

    '                If Not File.Exists(sExtractionPath & "\" & objZipEntry.Name) Then

    '                    Dim strmWriter As FileStream = System.IO.File.Create(sExtractionPath & "\" & objZipEntry.Name)

    '                    Dim nSize As Integer = 2048
    '                    Dim bData(nSize) As Byte

    '                    While (True)
    '                        nSize = strmZipInputStream.Read(bData, 0, bData.Length)
    '                        If (nSize > 0) Then
    '                            strmWriter.Write(bData, 0, nSize)
    '                        Else
    '                            Exit While
    '                        End If
    '                    End While

    '                    strmWriter.Close()

    '                End If

    '            End If
    '        End If

    '        objZipEntry = strmZipInputStream.GetNextEntry
    '    End While

    '    strmZipInputStream.Close()
    'End Sub '

    'Public Shared Function GetCategoryDirectory(ByVal nCategory As Integer) As String
    '    ' GAD Added the following line
    '    Dim sReturnValue As String = ""

    '    If (nCategory = CATEGORY_CORPORATE) Then
    '        ' GAD Removed the line below and added the next one
    '        'Return CATEGORY_CORPORATE_DIR
    '        sReturnValue = CATEGORY_CORPORATE_DIR
    '    ElseIf (nCategory = CATEGORY_BUSINESS_UNIT) Then
    '        ' GAD Removed the line below and added the next one
    '        'Return CATEGORY_BUSINESS_UNIT_DIR
    '        sReturnValue = CATEGORY_BUSINESS_UNIT_DIR
    '    ElseIf (nCategory = CATEGORY_DISCIPLINE) Then
    '        ' GAD Removed the line below and added the next one
    '        'Return CATEGORY_DISCIPLINE_DIR
    '        sReturnValue = CATEGORY_DISCIPLINE_DIR
    '    ElseIf (nCategory = CATEGORY_OFFICE) Then
    '        ' GAD Removed the line below and added the next one
    '        'Return CATEGORY_OFFICE_DIR
    '        sReturnValue = CATEGORY_OFFICE_DIR
    '    ElseIf (nCategory = CATEGORY_CLIENT) Then
    '        ' GAD Removed the line below and added the next one
    '        'Return CATEGORY_CLIENT_DIR
    '        sReturnValue = CATEGORY_CLIENT_DIR
    '    End If

    '    ' GAD Added the following line
    '    Return sReturnValue

    'End Function

    Public Shared Function FormatVersion(ByVal sItem As String) As String
        Dim sFinalStr As String = ""

        'GAD removed the line below and added the following one
        'Dim nVersionIndex = sItem.Length
        Dim nVersionIndex As Integer = sItem.Length

        Dim cDummy As Char = New Char

        If (sItem.IndexOf("_") >= 0) Then
            sFinalStr = sItem
        Else
            For nIndex As Integer = (sItem.Length - 1) To 0 Step -1
                If (Char.IsDigit(sItem.Chars(nIndex))) Then
                    nVersionIndex = nIndex
                Else
                    Exit For
                End If
            Next

            sFinalStr = sItem.Substring(0, nVersionIndex) & "_" & sItem.Substring(nVersionIndex)
        End If

        Return sFinalStr
    End Function


#End Region

End Class





