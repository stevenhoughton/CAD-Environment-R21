Imports System.Windows.Forms
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Friend Class StartUpAboutForm
    Inherits System.Windows.Forms.Form

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
    ' Dim RuleAccessors As New RuleAccessors

    Private Sub AboutAE_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            Me.Text = "About AutoCAD Environment R21 - " & Settings.Manager.AE.Version
            FullConfigurationName = RuleAccessors.GetruleValue("FULLCONFIGNAME")
            If FullConfigurationName = "" Then
                Me.ConfigName.Text = "This drawing is not configured"
            Else
                Me.ConfigName.Text = FullConfigurationName
            End If
            Me.AEVersion.Text = Settings.Manager.AE.Version
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

End Class