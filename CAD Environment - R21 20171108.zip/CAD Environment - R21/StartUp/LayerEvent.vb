﻿
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Internal
Imports Autodesk.AutoCAD.Runtime
Imports acApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Jacobs.AutoCAD.Utilities
Imports System
'Imports System.Data

Public Class LayerEvent
    'Implements IExtensionApplication

    Private Shared mAllowMessaging As Boolean = False

#Region "Properties"

    Public Shared Property ObjectType() As ObjectId
        Get
            Return m_ObjectType
        End Get
        Friend Set(value As ObjectId)
            m_ObjectType = value
        End Set
    End Property
    Private Shared m_ObjectType As ObjectId

    Public Property TxtAnnoScales() As List(Of AnnotationScale)
        Get
            Return m_TxtAnnoScales
        End Get
        Set(value As List(Of AnnotationScale))
            m_TxtAnnoScales = value
        End Set
    End Property
    Private Shared m_TxtAnnoScales As New List(Of AnnotationScale)

    Public Property DimAnnoScales() As List(Of AnnotationScale)
        Get
            Return m_DimAnnoScales
        End Get
        Set(value As List(Of AnnotationScale))
            m_DimAnnoScales = value
        End Set
    End Property
    Private Shared m_DimAnnoScales As New List(Of AnnotationScale)

    Public Property TxtLayerName() As String
        Get
            Return m_TxtLayerName
        End Get
        Set(value As String)
            m_TxtLayerName = value
        End Set
    End Property
    Private Shared m_TxtLayerName As String = ""

    Public Property TxtStyleName() As String
        Get
            Return m_TxtStyleName
        End Get
        Set(value As String)
            m_TxtStyleName = value
        End Set
    End Property
    Private Shared m_TxtStyleName As String = ""

    Public Shared Property DimLayerName() As String
        Get
            Return m_DimLayerName
        End Get
        Friend Set(value As String)
            m_DimLayerName = value
        End Set
    End Property
    Private Shared m_DimLayerName As String = ""

    Public Property DimStyleName() As String
        Get
            Return m_DimStyleName
        End Get
        Friend Set(value As String)
            m_DimStyleName = value
        End Set
    End Property
    Private Shared m_DimStyleName As String = ""

    Public Property UseAESettings() As Boolean
        Set(value As Boolean)
            m_UseAESettings = value
        End Set
        Get
            Return m_UseAESettings
        End Get
    End Property
    Private Shared m_UseAESettings As Boolean = False

    Public Sub ClearDimAnnotationList()
        m_DimAnnoScales.Clear()
    End Sub

    Public Sub ClearTxtAnnotationList()
        m_TxtAnnoScales.Clear()
    End Sub

#End Region

#Region "Initialization"

    Public Sub New(ByVal ShowEventMessages As Boolean)

        mAllowMessaging = ShowEventMessages

        Dim acDocs As DocumentCollection = acApp.DocumentManager
        Dim doc As Document = acDocs.MdiActiveDocument
        Dim ed As Editor = doc.Editor

        AddHandler acDocs.DocumentActivated, AddressOf OnDocumentActivated
        AddHandler doc.CommandWillStart, AddressOf OnCommandWillStart
    End Sub

    'Public Sub Initialize() 'Implements IExtensionApplication.Initialize
    '    Dim acDocs As DocumentCollection = acApp.DocumentManager
    '    Dim doc As Document = acDocs.MdiActiveDocument
    '    Dim ed As Editor = doc.Editor

    '    AddHandler acDocs.DocumentCreated, AddressOf OnDocumentCreated
    '    AddHandler doc.CommandWillStart, AddressOf OnCommandWillStart

    '    ed.WriteMessage(vbLf & "** " + Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location) + " loaded ** " & vbLf)
    'End Sub

    'Private Sub IExtensionApplication_Terminate() Implements IExtensionApplication.Terminate
    'End Sub

#End Region

#Region "Methods"

    Public Shared Sub OnCommandEnded(sender As Object, e As CommandEventArgs)
        Dim doc As Document = acApp.DocumentManager.MdiActiveDocument
        Dim ed As Editor = doc.Editor

        UnRegisterEvents(doc)

        If m_UseAESettings = False Then Exit Sub

        Try

            Using docLock As DocumentLock = doc.LockDocument()

                Using tr As Transaction = doc.Database.TransactionManager.StartOpenCloseTransaction()

                    If ObjectType <> Nothing Then

                        Dim ent As Entity = TryCast(DirectCast(tr.GetObject(ObjectType, OpenMode.ForWrite), Entity), Entity)

                        If ent Is Nothing Then
                            Return
                        End If

                        If TypeOf ent Is DBText Then

                            Dim txttxt As DBText = TryCast(DirectCast(ent, DBText), DBText)

                            'Todo - Should change to get Currently Selected Style Name
                            'Need to Add Rules TEXT29 Layer, TEXT30 - Text Style
                            If m_TxtLayerName <> "" Then
                                txttxt.Layer = m_TxtLayerName
                            Else
                                If mAllowMessaging Then ed.WriteMessage("** Text Entity layer not changed ** " & vbLf)
                            End If

                            'TODO Add TextStyle to NewCreated Object (TO DICUSS)
                            'm_TxtStyleName 

                            If m_TxtAnnoScales.Count > 0 Then
                                txttxt.Annotative = AnnotativeStates.True
                                For Each A As AnnotationScale In m_TxtAnnoScales
                                    txttxt.AddContext(A)
                                    If mAllowMessaging Then ed.WriteMessage("Scale: " & A.Name & " Added to Dimension Object!" & vbCrLf)
                                Next
                            End If

                        End If

                        If TypeOf ent Is MText Then

                            Dim mt As MText = TryCast(DirectCast(ent, MText), MText)

                            'Todo - Should change to get Currently Selected Style Name
                            'Need to Add Rules TEXT29 Layer, TEXT30 - Text Style, 31 - Auto Lyer, 32 - Auto Style
                            If m_TxtLayerName <> "" Then
                                mt.Layer = m_TxtLayerName
                            Else
                                If mAllowMessaging Then ed.WriteMessage("** MText Entity layer not changed ** " & vbLf)
                            End If

                            'TODO Add TextStyle to NewCreated Object (TO DICUSS)
                            'm_TxtStyleName 

                            If m_TxtAnnoScales.Count > 0 Then
                                mt.Annotative = AnnotativeStates.True
                                For Each A As AnnotationScale In m_TxtAnnoScales
                                    mt.AddContext(A)
                                    If mAllowMessaging Then ed.WriteMessage("Scale: " & A.Name & " Added to Dimension Object!" & vbCrLf)
                                Next
                            End If

                        End If

                        If TypeOf ent Is Dimension Then

                            Dim dm As Dimension = TryCast(DirectCast(ent, Dimension), Dimension)

                            m_DimLayerName = RuleAccessors.GetruleValue("DIM1", "0")

                            If m_DimLayerName <> "" Then
                                'Use Rule Value else Layer 0
                                dm.Layer = m_DimLayerName
                            Else
                                If mAllowMessaging Then ed.WriteMessage("** Dimension Entity layer not changed ** " & vbLf)
                            End If

                            'TODO Add DimStyle to NewCreated Object (TO DICUSS)
                            'm_DimStyleName 

                            If m_DimAnnoScales.Count > 0 Then
                                dm.Annotative = AnnotativeStates.True
                                For Each A As AnnotationScale In m_DimAnnoScales
                                    dm.AddContext(A)
                                    If mAllowMessaging Then ed.WriteMessage("Scale: " & A.Name & " Added to Dimension Object!" & vbCrLf)
                                Next
                            End If

                        End If

                    End If

                    tr.Commit()
                End Using
            End Using

        Catch ex As System.Exception
            ed.WriteMessage(vbLf & "System.Exception error: " + ex.Message)
        End Try
    End Sub

    Public Shared Sub OnCommandWillStart(sender As Object, e As CommandEventArgs)
        Dim cmd As String = e.GlobalCommandName.ToString().ToUpper()

        'Disabled Steven Houghton 20170707
        'If cmd IsNot Nothing AndAlso Utils.WcMatch(cmd, "*DIM*,DTEXT,MTEXT,TEXT") And m_UseAESettings Then
        'RegisterEvents(acApp.DocumentManager.MdiActiveDocument)
        'End If
    End Sub

    Public Shared Sub OnDocumentActivated(sender As [Object], e As DocumentCollectionEventArgs)
        Dim doc As Document = e.Document

        If doc IsNot Nothing Then
            AddHandler doc.CommandWillStart, AddressOf OnCommandWillStart
        End If
    End Sub

    Public Shared Sub OnObjectAppended(sender As Object, e As ObjectEventArgs)
        Dim id As ObjectId = e.DBObject.ObjectId

        If id <> Nothing Then
            ObjectType = id
        End If
    End Sub

    Public Shared Sub RegisterEvents(doc As Document)
        If doc IsNot Nothing Then
            Dim ed As Editor = doc.Editor

            ' command events
            AddHandler doc.CommandCancelled, AddressOf OnCommandEnded
            AddHandler doc.CommandEnded, AddressOf OnCommandEnded
            AddHandler doc.CommandFailed, AddressOf OnCommandEnded

            ' database events
            AddHandler doc.Database.ObjectAppended, AddressOf OnObjectAppended

            If mAllowMessaging Then ed.WriteMessage(vbLf & "** ObjectType events registered ** " & vbLf)
        End If
    End Sub

    Public Shared Sub UnRegisterEvents(doc As Document)
        If doc IsNot Nothing Then
            Dim ed As Editor = doc.Editor

            ' command events
            RemoveHandler doc.CommandCancelled, AddressOf OnCommandEnded
            RemoveHandler doc.CommandEnded, AddressOf OnCommandEnded
            RemoveHandler doc.CommandFailed, AddressOf OnCommandEnded

            ' database events
            RemoveHandler doc.Database.ObjectAppended, AddressOf OnObjectAppended

            If mAllowMessaging Then ed.WriteMessage(vbLf & "** ObjectType events unregistered ** " & vbLf)
        End If
    End Sub

#End Region



End Class


'Description = This is a set of text that will allow the placement of text
'Rule = TEXT0,Allow users to change default Settings nominated here:,1,3,42
'Rule = TEXT1,Select what type of text to use in this drawing [MTEXT or DTEXT]:,MTEXT,2,41
'Rule = TEXT2,Select the default text height for this drawing:,3.5,2,40
'Rule = TEXT3,Select which layer you wish to use for 1.8 high text:,TEXT_18,1,6
'Rule = TEXT4,Select which style to use for 1.8 high text:,Standard,1,8
'Rule = TEXT5,Select which colour to use for 1.8 high text:,256,1,16
'Rule = TEXT6,Select which justification to use for 1.8 high text:,BL,1,15
'Rule = TEXT7,Select which layer you wish to use for 2.5 high text:,TEXT_25,1,6
'Rule = TEXT8,Select which style to use for 2.5 high text:,Standard,1,8
'Rule = TEXT9,Select which colour to use for 2.5 high text:,256,1,16
'Rule = TEXT10,Select which justification to use for 2.5 high text:,BL,1,15
'Rule = TEXT11,Select which layer you wish to use for 3.5 high text:,TEXT_35,1,6
'Rule = TEXT12,Select which style to use for 3.5 high text:,Standard,1,8
'Rule = TEXT13,Select which colour to use for 3.5 high text:,256,1,16
'Rule = TEXT14,Select which justification to use for 3.5 high text:,BL,1,15
'Rule = TEXT15,Select which layer you wish to use for 5.0 high text:,TEXT_50,1,6
'Rule = TEXT16,Select which style to use for 5.0 high text:,Standard,1,8
'Rule = TEXT17,Select which colour to use for 5.0 high text:,256,1,16
'Rule = TEXT18,Select which justification to use for 5.0 high text:,BL,1,15
'Rule = TEXT19,Select which layer you wish to use for 7.0 high text:,TEXT_70,1,6
'Rule = TEXT20,Select which style to use for 7.0 high text:,Standard,1,8
'Rule = TEXT21,Select which colour to use for 7.0 high text:,256,1,16
'Rule = TEXT22,Select which justification to use for 7.0 high text:,BL,1,15
'Rule = TEXT23,Change system variables when switching layouts:,1,3,42
'Rule = TEXT24,Don't prompt for height and rotation:,1,3,42
'Rule = TEXT25,Don't show Text switch space message in this configuration: ,1,3,42
'Rule = TEXT26,Show Text Justifications Dialog Box: ,0,3,42
'Rule = TEXT27,Change system variables when switching viewports:,1,3,42
'Rule = TEXT28,Default text rotation angle:,0.0,2,40



''Description = This Will apply Jacobs Client Configurations for Placement of Dimensions
''Rule = DIM0,Allow users to change default Settings nominated here:,1,3,42

''Rule = DIM1,Default Layer for All Dimensions:,DIM,1,6
''Rule = DIM2,Default Colour for All Dimensions:,ByLayer,1,16


''Rule = DIM3,Use DIMSCALE variable to override dimension styles:,1,3,42
''Rule = DIM4,Use floating model space dimensions: ,0,3,42


''Rule = DIM5,Default DimStyle for Client:,Standard,1,11



''Rule = DIM6,Automatically change dimensions when switching layouts:,1,3,42
''Rule = DIM7,Don't show Dimension switch space message in this configuration: ,1,3,42
''Rule = DIM8,Automatically change dimensions when switching viewports:,1,3,42

'End Namespace
