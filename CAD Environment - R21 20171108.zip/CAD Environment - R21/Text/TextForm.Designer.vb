<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class TextForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents TxtLay18 As System.Windows.Forms.ComboBox
    Public WithEvents LayerTitle As System.Windows.Forms.Label
    Public WithEvents TxtSty18 As System.Windows.Forms.ComboBox
    Public WithEvents StyleTitle As System.Windows.Forms.Label
    Public WithEvents TextTitle As System.Windows.Forms.Label
    Public WithEvents TxtJust18 As System.Windows.Forms.ComboBox
    Public WithEvents JustificationTitle As System.Windows.Forms.Label
    Public WithEvents TxtStyElipsis18 As System.Windows.Forms.Button
    Public WithEvents TxtRot18 As System.Windows.Forms.TextBox
    Public WithEvents RotateTitle As System.Windows.Forms.Label
    Public WithEvents TxtCol18 As System.Windows.Forms.ComboBox
    Public WithEvents ColourTitle As System.Windows.Forms.Label
    Public WithEvents OK_Button As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents Help_Button As System.Windows.Forms.Button
    Public WithEvents Txt18Ask As System.Windows.Forms.CheckBox
    Public WithEvents TxtStyElipsis35 As System.Windows.Forms.Button
    Public WithEvents TxtLay35 As System.Windows.Forms.ComboBox
    Public WithEvents TxtSty35 As System.Windows.Forms.ComboBox
    Public WithEvents TxtJust35 As System.Windows.Forms.ComboBox
    Public WithEvents TxtRot35 As System.Windows.Forms.TextBox
    Public WithEvents TxtCol35 As System.Windows.Forms.ComboBox
    Public WithEvents Txt35Ask As System.Windows.Forms.CheckBox
    Public WithEvents TxtStyElipsis25 As System.Windows.Forms.Button
    Public WithEvents TxtLay25 As System.Windows.Forms.ComboBox
    Public WithEvents TxtSty25 As System.Windows.Forms.ComboBox
    Public WithEvents TxtJust25 As System.Windows.Forms.ComboBox
    Public WithEvents TxtRot25 As System.Windows.Forms.TextBox
    Public WithEvents TxtCol25 As System.Windows.Forms.ComboBox
    Public WithEvents Txt25Ask As System.Windows.Forms.CheckBox
    Public WithEvents TxtStyElipsis70 As System.Windows.Forms.Button
    Public WithEvents TxtLay70 As System.Windows.Forms.ComboBox
    Public WithEvents TxtSty70 As System.Windows.Forms.ComboBox
    Public WithEvents TxtJust70 As System.Windows.Forms.ComboBox
    Public WithEvents TxtRot70 As System.Windows.Forms.TextBox
    Public WithEvents TxtCol70 As System.Windows.Forms.ComboBox
    Public WithEvents Txt70Ask As System.Windows.Forms.CheckBox
    Public WithEvents TxtStyElipsis50 As System.Windows.Forms.Button
    Public WithEvents TxtLay50 As System.Windows.Forms.ComboBox
    Public WithEvents TxtSty50 As System.Windows.Forms.ComboBox
    Public WithEvents TxtJust50 As System.Windows.Forms.ComboBox
    Public WithEvents TxtRot50 As System.Windows.Forms.TextBox
    Public WithEvents TxtCol50 As System.Windows.Forms.ComboBox
    Public WithEvents Txt50Ask As System.Windows.Forms.CheckBox
    Public WithEvents Text25 As System.Windows.Forms.Label
    Public WithEvents Text35 As System.Windows.Forms.Label
    Public WithEvents Text50 As System.Windows.Forms.Label
    Public WithEvents Text70 As System.Windows.Forms.Label
    Public WithEvents Text18 As System.Windows.Forms.Label
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents ClientRules As System.Windows.Forms.CheckBox
    Public WithEvents col18 As System.Windows.Forms.Button
    Public WithEvents col25 As System.Windows.Forms.Button
    Public WithEvents col35 As System.Windows.Forms.Button
    Public WithEvents col50 As System.Windows.Forms.Button
    Public WithEvents col70 As System.Windows.Forms.Button
    Public WithEvents DontAskAgain As System.Windows.Forms.CheckBox
    Public WithEvents DontPrompt As System.Windows.Forms.CheckBox
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents TextHeight As System.Windows.Forms.TextBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents TextType As System.Windows.Forms.ComboBox
    Public WithEvents ChangeSysVars As System.Windows.Forms.CheckBox
    Public WithEvents Justifications As System.Windows.Forms.CheckBox
    Public WithEvents ChangeSysVarsVP As System.Windows.Forms.CheckBox
    Public WithEvents RotationAngle As System.Windows.Forms.TextBox
    Public WithEvents DegreesLabel As System.Windows.Forms.Label
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents ProposedTextSizeLabel As System.Windows.Forms.Label
    Public WithEvents NewTextSize As System.Windows.Forms.Label
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
    Public WithEvents ActualTextSizeLabel As System.Windows.Forms.Label
    Public WithEvents CurrentTEXTSIZE As System.Windows.Forms.Label
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents UserScale1 As System.Windows.Forms.Label
    Public WithEvents UserScale2 As System.Windows.Forms.Label
    Public WithEvents Label12 As System.Windows.Forms.Label
    Public WithEvents MetersNotice As System.Windows.Forms.Label
    Public WithEvents ScaleFrame As System.Windows.Forms.GroupBox
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TextForm))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.RotationAngle = New System.Windows.Forms.TextBox()
        Me.DontPrompt = New System.Windows.Forms.CheckBox()
        Me.ChangeSysVars = New System.Windows.Forms.CheckBox()
        Me.Justifications = New System.Windows.Forms.CheckBox()
        Me.ChangeSysVarsVP = New System.Windows.Forms.CheckBox()
        Me.TxtLay18 = New System.Windows.Forms.ComboBox()
        Me.LayerTitle = New System.Windows.Forms.Label()
        Me.TxtSty18 = New System.Windows.Forms.ComboBox()
        Me.StyleTitle = New System.Windows.Forms.Label()
        Me.TextTitle = New System.Windows.Forms.Label()
        Me.TxtJust18 = New System.Windows.Forms.ComboBox()
        Me.JustificationTitle = New System.Windows.Forms.Label()
        Me.TxtStyElipsis18 = New System.Windows.Forms.Button()
        Me.TxtRot18 = New System.Windows.Forms.TextBox()
        Me.RotateTitle = New System.Windows.Forms.Label()
        Me.TxtCol18 = New System.Windows.Forms.ComboBox()
        Me.ColourTitle = New System.Windows.Forms.Label()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.Txt18Ask = New System.Windows.Forms.CheckBox()
        Me.TxtStyElipsis35 = New System.Windows.Forms.Button()
        Me.TxtLay35 = New System.Windows.Forms.ComboBox()
        Me.TxtSty35 = New System.Windows.Forms.ComboBox()
        Me.TxtJust35 = New System.Windows.Forms.ComboBox()
        Me.TxtRot35 = New System.Windows.Forms.TextBox()
        Me.TxtCol35 = New System.Windows.Forms.ComboBox()
        Me.Txt35Ask = New System.Windows.Forms.CheckBox()
        Me.TxtStyElipsis25 = New System.Windows.Forms.Button()
        Me.TxtLay25 = New System.Windows.Forms.ComboBox()
        Me.TxtSty25 = New System.Windows.Forms.ComboBox()
        Me.TxtJust25 = New System.Windows.Forms.ComboBox()
        Me.TxtRot25 = New System.Windows.Forms.TextBox()
        Me.TxtCol25 = New System.Windows.Forms.ComboBox()
        Me.Txt25Ask = New System.Windows.Forms.CheckBox()
        Me.TxtStyElipsis70 = New System.Windows.Forms.Button()
        Me.TxtLay70 = New System.Windows.Forms.ComboBox()
        Me.TxtSty70 = New System.Windows.Forms.ComboBox()
        Me.TxtJust70 = New System.Windows.Forms.ComboBox()
        Me.TxtRot70 = New System.Windows.Forms.TextBox()
        Me.TxtCol70 = New System.Windows.Forms.ComboBox()
        Me.Txt70Ask = New System.Windows.Forms.CheckBox()
        Me.TxtStyElipsis50 = New System.Windows.Forms.Button()
        Me.TxtLay50 = New System.Windows.Forms.ComboBox()
        Me.TxtSty50 = New System.Windows.Forms.ComboBox()
        Me.TxtJust50 = New System.Windows.Forms.ComboBox()
        Me.TxtRot50 = New System.Windows.Forms.TextBox()
        Me.TxtCol50 = New System.Windows.Forms.ComboBox()
        Me.Txt50Ask = New System.Windows.Forms.CheckBox()
        Me.Text25 = New System.Windows.Forms.Label()
        Me.Text35 = New System.Windows.Forms.Label()
        Me.Text50 = New System.Windows.Forms.Label()
        Me.Text70 = New System.Windows.Forms.Label()
        Me.Text18 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ClientRules = New System.Windows.Forms.CheckBox()
        Me.col18 = New System.Windows.Forms.Button()
        Me.col25 = New System.Windows.Forms.Button()
        Me.col35 = New System.Windows.Forms.Button()
        Me.col50 = New System.Windows.Forms.Button()
        Me.col70 = New System.Windows.Forms.Button()
        Me.DontAskAgain = New System.Windows.Forms.CheckBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextHeight = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextType = New System.Windows.Forms.ComboBox()
        Me.DegreesLabel = New System.Windows.Forms.Label()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.ProposedTextSizeLabel = New System.Windows.Forms.Label()
        Me.NewTextSize = New System.Windows.Forms.Label()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.ActualTextSizeLabel = New System.Windows.Forms.Label()
        Me.CurrentTEXTSIZE = New System.Windows.Forms.Label()
        Me.ScaleFrame = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.UserScale1 = New System.Windows.Forms.Label()
        Me.UserScale2 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.MetersNotice = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextToolGroupBox = New System.Windows.Forms.GroupBox()
        Me.OverrideConfigSettingsRadioButton = New System.Windows.Forms.RadioButton()
        Me.UseSettingsInConfigRadioButton = New System.Windows.Forms.RadioButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.SettingsTabPage = New System.Windows.Forms.TabPage()
        Me.ToolDefaultsTabPage = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.ScaleFrame.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TextToolGroupBox.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SettingsTabPage.SuspendLayout()
        Me.ToolDefaultsTabPage.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'RotationAngle
        '
        Me.RotationAngle.AcceptsReturn = True
        Me.RotationAngle.BackColor = System.Drawing.SystemColors.Window
        Me.RotationAngle.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.RotationAngle.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RotationAngle.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RotationAngle.Location = New System.Drawing.Point(276, 68)
        Me.RotationAngle.MaxLength = 0
        Me.RotationAngle.Name = "RotationAngle"
        Me.RotationAngle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RotationAngle.Size = New System.Drawing.Size(40, 23)
        Me.RotationAngle.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.RotationAngle, "Specify DTEXT default rotation angle in decimal degrees")
        '
        'DontPrompt
        '
        Me.DontPrompt.AutoSize = True
        Me.DontPrompt.BackColor = System.Drawing.SystemColors.Control
        Me.DontPrompt.Cursor = System.Windows.Forms.Cursors.Default
        Me.DontPrompt.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DontPrompt.ForeColor = System.Drawing.Color.Black
        Me.DontPrompt.Location = New System.Drawing.Point(7, 70)
        Me.DontPrompt.Name = "DontPrompt"
        Me.DontPrompt.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DontPrompt.Size = New System.Drawing.Size(257, 20)
        Me.DontPrompt.TabIndex = 1
        Me.DontPrompt.Text = "Don't prompt for rotation always use"
        Me.ToolTip1.SetToolTip(Me.DontPrompt, "When using DTEXT supress the test rotation question and assume the nominated angl" & _
        "e")
        Me.DontPrompt.UseVisualStyleBackColor = False
        '
        'ChangeSysVars
        '
        Me.ChangeSysVars.AutoSize = True
        Me.ChangeSysVars.BackColor = System.Drawing.SystemColors.Control
        Me.ChangeSysVars.Cursor = System.Windows.Forms.Cursors.Default
        Me.ChangeSysVars.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChangeSysVars.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ChangeSysVars.Location = New System.Drawing.Point(7, 124)
        Me.ChangeSysVars.Name = "ChangeSysVars"
        Me.ChangeSysVars.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ChangeSysVars.Size = New System.Drawing.Size(343, 20)
        Me.ChangeSysVars.TabIndex = 5
        Me.ChangeSysVars.Text = "Change system variables when Switching Layouts"
        Me.ToolTip1.SetToolTip(Me.ChangeSysVars, resources.GetString("ChangeSysVars.ToolTip"))
        Me.ChangeSysVars.UseVisualStyleBackColor = False
        '
        'Justifications
        '
        Me.Justifications.AutoSize = True
        Me.Justifications.BackColor = System.Drawing.SystemColors.Control
        Me.Justifications.Cursor = System.Windows.Forms.Cursors.Default
        Me.Justifications.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Justifications.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Justifications.Location = New System.Drawing.Point(7, 97)
        Me.Justifications.Name = "Justifications"
        Me.Justifications.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Justifications.Size = New System.Drawing.Size(295, 20)
        Me.Justifications.TabIndex = 6
        Me.Justifications.Text = "Always show justification dialog for DTEXT"
        Me.ToolTip1.SetToolTip(Me.Justifications, "When Using DTEXT prompt the user for a text justification")
        Me.Justifications.UseVisualStyleBackColor = False
        '
        'ChangeSysVarsVP
        '
        Me.ChangeSysVarsVP.AutoSize = True
        Me.ChangeSysVarsVP.BackColor = System.Drawing.SystemColors.Control
        Me.ChangeSysVarsVP.Cursor = System.Windows.Forms.Cursors.Default
        Me.ChangeSysVarsVP.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChangeSysVarsVP.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ChangeSysVarsVP.Location = New System.Drawing.Point(7, 151)
        Me.ChangeSysVarsVP.Name = "ChangeSysVarsVP"
        Me.ChangeSysVarsVP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ChangeSysVarsVP.Size = New System.Drawing.Size(354, 20)
        Me.ChangeSysVarsVP.TabIndex = 7
        Me.ChangeSysVarsVP.Text = "Change system variables when Switching Viewports"
        Me.ToolTip1.SetToolTip(Me.ChangeSysVarsVP, resources.GetString("ChangeSysVarsVP.ToolTip"))
        Me.ChangeSysVarsVP.UseVisualStyleBackColor = False
        '
        'TxtLay18
        '
        Me.TxtLay18.BackColor = System.Drawing.SystemColors.Window
        Me.TxtLay18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtLay18.Enabled = False
        Me.TxtLay18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLay18.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtLay18.Location = New System.Drawing.Point(131, 49)
        Me.TxtLay18.Name = "TxtLay18"
        Me.TxtLay18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtLay18.Size = New System.Drawing.Size(246, 24)
        Me.TxtLay18.Sorted = True
        Me.TxtLay18.TabIndex = 0
        '
        'LayerTitle
        '
        Me.LayerTitle.AutoSize = True
        Me.LayerTitle.BackColor = System.Drawing.SystemColors.Control
        Me.LayerTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.LayerTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LayerTitle.Location = New System.Drawing.Point(219, 22)
        Me.LayerTitle.Name = "LayerTitle"
        Me.LayerTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LayerTitle.Size = New System.Drawing.Size(42, 17)
        Me.LayerTitle.TabIndex = 1
        Me.LayerTitle.Text = "Layer"
        Me.LayerTitle.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TxtSty18
        '
        Me.TxtSty18.BackColor = System.Drawing.SystemColors.Window
        Me.TxtSty18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtSty18.Enabled = False
        Me.TxtSty18.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtSty18.Location = New System.Drawing.Point(67, 51)
        Me.TxtSty18.Name = "TxtSty18"
        Me.TxtSty18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtSty18.Size = New System.Drawing.Size(132, 25)
        Me.TxtSty18.Sorted = True
        Me.TxtSty18.TabIndex = 2
        '
        'StyleTitle
        '
        Me.StyleTitle.AutoSize = True
        Me.StyleTitle.BackColor = System.Drawing.SystemColors.Control
        Me.StyleTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.StyleTitle.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StyleTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.StyleTitle.Location = New System.Drawing.Point(106, 25)
        Me.StyleTitle.Name = "StyleTitle"
        Me.StyleTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StyleTitle.Size = New System.Drawing.Size(68, 16)
        Me.StyleTitle.TabIndex = 3
        Me.StyleTitle.Text = "Text Style"
        Me.StyleTitle.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TextTitle
        '
        Me.TextTitle.AutoSize = True
        Me.TextTitle.BackColor = System.Drawing.SystemColors.Control
        Me.TextTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.TextTitle.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TextTitle.Location = New System.Drawing.Point(39, 21)
        Me.TextTitle.Name = "TextTitle"
        Me.TextTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextTitle.Size = New System.Drawing.Size(48, 16)
        Me.TextTitle.TabIndex = 4
        Me.TextTitle.Text = "Height"
        Me.TextTitle.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TxtJust18
        '
        Me.TxtJust18.BackColor = System.Drawing.SystemColors.Window
        Me.TxtJust18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtJust18.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtJust18.Location = New System.Drawing.Point(292, 612)
        Me.TxtJust18.Name = "TxtJust18"
        Me.TxtJust18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtJust18.Size = New System.Drawing.Size(105, 25)
        Me.TxtJust18.Sorted = True
        Me.TxtJust18.TabIndex = 5
        '
        'JustificationTitle
        '
        Me.JustificationTitle.AutoSize = True
        Me.JustificationTitle.BackColor = System.Drawing.SystemColors.Control
        Me.JustificationTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.JustificationTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.JustificationTitle.Location = New System.Drawing.Point(313, 586)
        Me.JustificationTitle.Name = "JustificationTitle"
        Me.JustificationTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.JustificationTitle.Size = New System.Drawing.Size(78, 17)
        Me.JustificationTitle.TabIndex = 6
        Me.JustificationTitle.Text = "Justification"
        Me.JustificationTitle.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TxtStyElipsis18
        '
        Me.TxtStyElipsis18.BackColor = System.Drawing.SystemColors.Control
        Me.TxtStyElipsis18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtStyElipsis18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TxtStyElipsis18.Location = New System.Drawing.Point(112, 613)
        Me.TxtStyElipsis18.Name = "TxtStyElipsis18"
        Me.TxtStyElipsis18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtStyElipsis18.Size = New System.Drawing.Size(24, 24)
        Me.TxtStyElipsis18.TabIndex = 7
        Me.TxtStyElipsis18.Text = "..."
        Me.TxtStyElipsis18.UseVisualStyleBackColor = False
        Me.TxtStyElipsis18.Visible = False
        '
        'TxtRot18
        '
        Me.TxtRot18.AcceptsReturn = True
        Me.TxtRot18.BackColor = System.Drawing.SystemColors.Window
        Me.TxtRot18.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtRot18.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtRot18.Location = New System.Drawing.Point(147, 612)
        Me.TxtRot18.MaxLength = 0
        Me.TxtRot18.Name = "TxtRot18"
        Me.TxtRot18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtRot18.Size = New System.Drawing.Size(69, 24)
        Me.TxtRot18.TabIndex = 8
        '
        'RotateTitle
        '
        Me.RotateTitle.AutoSize = True
        Me.RotateTitle.BackColor = System.Drawing.SystemColors.Control
        Me.RotateTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.RotateTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RotateTitle.Location = New System.Drawing.Point(142, 586)
        Me.RotateTitle.Name = "RotateTitle"
        Me.RotateTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RotateTitle.Size = New System.Drawing.Size(97, 17)
        Me.RotateTitle.TabIndex = 9
        Me.RotateTitle.Text = "Rotation Angle"
        Me.RotateTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TxtCol18
        '
        Me.TxtCol18.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCol18.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtCol18.Enabled = False
        Me.TxtCol18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCol18.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtCol18.Location = New System.Drawing.Point(401, 49)
        Me.TxtCol18.Name = "TxtCol18"
        Me.TxtCol18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtCol18.Size = New System.Drawing.Size(105, 24)
        Me.TxtCol18.Sorted = True
        Me.TxtCol18.TabIndex = 10
        '
        'ColourTitle
        '
        Me.ColourTitle.AutoSize = True
        Me.ColourTitle.BackColor = System.Drawing.SystemColors.Control
        Me.ColourTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.ColourTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ColourTitle.Location = New System.Drawing.Point(434, 21)
        Me.ColourTitle.Name = "ColourTitle"
        Me.ColourTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ColourTitle.Size = New System.Drawing.Size(48, 17)
        Me.ColourTitle.TabIndex = 11
        Me.ColourTitle.Text = "Colour"
        Me.ColourTitle.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.BackColor = System.Drawing.SystemColors.Control
        Me.OK_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.OK_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OK_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OK_Button.Location = New System.Drawing.Point(88, 5)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OK_Button.Size = New System.Drawing.Size(64, 26)
        Me.OK_Button.TabIndex = 12
        Me.OK_Button.Text = "OK"
        Me.OK_Button.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(168, 5)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(64, 26)
        Me.Cancel_Button.TabIndex = 13
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(8, 5)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(64, 26)
        Me.Help_Button.TabIndex = 14
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'Txt18Ask
        '
        Me.Txt18Ask.BackColor = System.Drawing.SystemColors.Control
        Me.Txt18Ask.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt18Ask.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Txt18Ask.Location = New System.Drawing.Point(219, 612)
        Me.Txt18Ask.Name = "Txt18Ask"
        Me.Txt18Ask.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Txt18Ask.Size = New System.Drawing.Size(59, 24)
        Me.Txt18Ask.TabIndex = 15
        Me.Txt18Ask.Text = "Ask"
        Me.Txt18Ask.UseVisualStyleBackColor = False
        '
        'TxtStyElipsis35
        '
        Me.TxtStyElipsis35.BackColor = System.Drawing.SystemColors.Control
        Me.TxtStyElipsis35.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtStyElipsis35.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TxtStyElipsis35.Location = New System.Drawing.Point(112, 693)
        Me.TxtStyElipsis35.Name = "TxtStyElipsis35"
        Me.TxtStyElipsis35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtStyElipsis35.Size = New System.Drawing.Size(24, 24)
        Me.TxtStyElipsis35.TabIndex = 16
        Me.TxtStyElipsis35.Text = "..."
        Me.TxtStyElipsis35.UseVisualStyleBackColor = False
        Me.TxtStyElipsis35.Visible = False
        '
        'TxtLay35
        '
        Me.TxtLay35.BackColor = System.Drawing.SystemColors.Window
        Me.TxtLay35.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtLay35.Enabled = False
        Me.TxtLay35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLay35.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtLay35.Location = New System.Drawing.Point(131, 129)
        Me.TxtLay35.Name = "TxtLay35"
        Me.TxtLay35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtLay35.Size = New System.Drawing.Size(246, 24)
        Me.TxtLay35.Sorted = True
        Me.TxtLay35.TabIndex = 17
        '
        'TxtSty35
        '
        Me.TxtSty35.BackColor = System.Drawing.SystemColors.Window
        Me.TxtSty35.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtSty35.Enabled = False
        Me.TxtSty35.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtSty35.Location = New System.Drawing.Point(67, 131)
        Me.TxtSty35.Name = "TxtSty35"
        Me.TxtSty35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtSty35.Size = New System.Drawing.Size(132, 25)
        Me.TxtSty35.Sorted = True
        Me.TxtSty35.TabIndex = 18
        '
        'TxtJust35
        '
        Me.TxtJust35.BackColor = System.Drawing.SystemColors.Window
        Me.TxtJust35.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtJust35.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtJust35.Location = New System.Drawing.Point(292, 692)
        Me.TxtJust35.Name = "TxtJust35"
        Me.TxtJust35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtJust35.Size = New System.Drawing.Size(105, 25)
        Me.TxtJust35.TabIndex = 19
        '
        'TxtRot35
        '
        Me.TxtRot35.AcceptsReturn = True
        Me.TxtRot35.BackColor = System.Drawing.SystemColors.Window
        Me.TxtRot35.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtRot35.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtRot35.Location = New System.Drawing.Point(147, 692)
        Me.TxtRot35.MaxLength = 0
        Me.TxtRot35.Name = "TxtRot35"
        Me.TxtRot35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtRot35.Size = New System.Drawing.Size(69, 24)
        Me.TxtRot35.TabIndex = 20
        '
        'TxtCol35
        '
        Me.TxtCol35.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCol35.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtCol35.Enabled = False
        Me.TxtCol35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCol35.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtCol35.Location = New System.Drawing.Point(401, 129)
        Me.TxtCol35.Name = "TxtCol35"
        Me.TxtCol35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtCol35.Size = New System.Drawing.Size(105, 24)
        Me.TxtCol35.Sorted = True
        Me.TxtCol35.TabIndex = 21
        '
        'Txt35Ask
        '
        Me.Txt35Ask.BackColor = System.Drawing.SystemColors.Control
        Me.Txt35Ask.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt35Ask.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Txt35Ask.Location = New System.Drawing.Point(219, 692)
        Me.Txt35Ask.Name = "Txt35Ask"
        Me.Txt35Ask.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Txt35Ask.Size = New System.Drawing.Size(59, 24)
        Me.Txt35Ask.TabIndex = 22
        Me.Txt35Ask.Text = "Ask"
        Me.Txt35Ask.UseVisualStyleBackColor = False
        '
        'TxtStyElipsis25
        '
        Me.TxtStyElipsis25.BackColor = System.Drawing.SystemColors.Control
        Me.TxtStyElipsis25.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtStyElipsis25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TxtStyElipsis25.Location = New System.Drawing.Point(112, 653)
        Me.TxtStyElipsis25.Name = "TxtStyElipsis25"
        Me.TxtStyElipsis25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtStyElipsis25.Size = New System.Drawing.Size(24, 24)
        Me.TxtStyElipsis25.TabIndex = 23
        Me.TxtStyElipsis25.Text = "..."
        Me.TxtStyElipsis25.UseVisualStyleBackColor = False
        Me.TxtStyElipsis25.Visible = False
        '
        'TxtLay25
        '
        Me.TxtLay25.BackColor = System.Drawing.SystemColors.Window
        Me.TxtLay25.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtLay25.Enabled = False
        Me.TxtLay25.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLay25.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtLay25.Location = New System.Drawing.Point(131, 89)
        Me.TxtLay25.Name = "TxtLay25"
        Me.TxtLay25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtLay25.Size = New System.Drawing.Size(246, 24)
        Me.TxtLay25.Sorted = True
        Me.TxtLay25.TabIndex = 24
        '
        'TxtSty25
        '
        Me.TxtSty25.BackColor = System.Drawing.SystemColors.Window
        Me.TxtSty25.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtSty25.Enabled = False
        Me.TxtSty25.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtSty25.Location = New System.Drawing.Point(67, 91)
        Me.TxtSty25.Name = "TxtSty25"
        Me.TxtSty25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtSty25.Size = New System.Drawing.Size(132, 25)
        Me.TxtSty25.Sorted = True
        Me.TxtSty25.TabIndex = 25
        '
        'TxtJust25
        '
        Me.TxtJust25.BackColor = System.Drawing.SystemColors.Window
        Me.TxtJust25.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtJust25.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtJust25.Location = New System.Drawing.Point(292, 652)
        Me.TxtJust25.Name = "TxtJust25"
        Me.TxtJust25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtJust25.Size = New System.Drawing.Size(105, 25)
        Me.TxtJust25.TabIndex = 26
        '
        'TxtRot25
        '
        Me.TxtRot25.AcceptsReturn = True
        Me.TxtRot25.BackColor = System.Drawing.SystemColors.Window
        Me.TxtRot25.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtRot25.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtRot25.Location = New System.Drawing.Point(147, 652)
        Me.TxtRot25.MaxLength = 0
        Me.TxtRot25.Name = "TxtRot25"
        Me.TxtRot25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtRot25.Size = New System.Drawing.Size(69, 24)
        Me.TxtRot25.TabIndex = 27
        '
        'TxtCol25
        '
        Me.TxtCol25.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCol25.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtCol25.Enabled = False
        Me.TxtCol25.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCol25.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtCol25.Location = New System.Drawing.Point(401, 89)
        Me.TxtCol25.Name = "TxtCol25"
        Me.TxtCol25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtCol25.Size = New System.Drawing.Size(105, 24)
        Me.TxtCol25.Sorted = True
        Me.TxtCol25.TabIndex = 28
        '
        'Txt25Ask
        '
        Me.Txt25Ask.BackColor = System.Drawing.SystemColors.Control
        Me.Txt25Ask.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt25Ask.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Txt25Ask.Location = New System.Drawing.Point(219, 652)
        Me.Txt25Ask.Name = "Txt25Ask"
        Me.Txt25Ask.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Txt25Ask.Size = New System.Drawing.Size(59, 24)
        Me.Txt25Ask.TabIndex = 29
        Me.Txt25Ask.Text = "Ask"
        Me.Txt25Ask.UseVisualStyleBackColor = False
        '
        'TxtStyElipsis70
        '
        Me.TxtStyElipsis70.BackColor = System.Drawing.SystemColors.Control
        Me.TxtStyElipsis70.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtStyElipsis70.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TxtStyElipsis70.Location = New System.Drawing.Point(112, 773)
        Me.TxtStyElipsis70.Name = "TxtStyElipsis70"
        Me.TxtStyElipsis70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtStyElipsis70.Size = New System.Drawing.Size(24, 24)
        Me.TxtStyElipsis70.TabIndex = 30
        Me.TxtStyElipsis70.Text = "..."
        Me.TxtStyElipsis70.UseVisualStyleBackColor = False
        Me.TxtStyElipsis70.Visible = False
        '
        'TxtLay70
        '
        Me.TxtLay70.BackColor = System.Drawing.SystemColors.Window
        Me.TxtLay70.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtLay70.Enabled = False
        Me.TxtLay70.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLay70.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtLay70.Location = New System.Drawing.Point(131, 209)
        Me.TxtLay70.Name = "TxtLay70"
        Me.TxtLay70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtLay70.Size = New System.Drawing.Size(246, 24)
        Me.TxtLay70.Sorted = True
        Me.TxtLay70.TabIndex = 31
        '
        'TxtSty70
        '
        Me.TxtSty70.BackColor = System.Drawing.SystemColors.Window
        Me.TxtSty70.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtSty70.Enabled = False
        Me.TxtSty70.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtSty70.Location = New System.Drawing.Point(67, 211)
        Me.TxtSty70.Name = "TxtSty70"
        Me.TxtSty70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtSty70.Size = New System.Drawing.Size(132, 25)
        Me.TxtSty70.Sorted = True
        Me.TxtSty70.TabIndex = 32
        '
        'TxtJust70
        '
        Me.TxtJust70.BackColor = System.Drawing.SystemColors.Window
        Me.TxtJust70.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtJust70.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtJust70.Location = New System.Drawing.Point(292, 772)
        Me.TxtJust70.Name = "TxtJust70"
        Me.TxtJust70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtJust70.Size = New System.Drawing.Size(105, 25)
        Me.TxtJust70.TabIndex = 33
        '
        'TxtRot70
        '
        Me.TxtRot70.AcceptsReturn = True
        Me.TxtRot70.BackColor = System.Drawing.SystemColors.Window
        Me.TxtRot70.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtRot70.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtRot70.Location = New System.Drawing.Point(147, 772)
        Me.TxtRot70.MaxLength = 0
        Me.TxtRot70.Name = "TxtRot70"
        Me.TxtRot70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtRot70.Size = New System.Drawing.Size(69, 24)
        Me.TxtRot70.TabIndex = 34
        '
        'TxtCol70
        '
        Me.TxtCol70.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCol70.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtCol70.Enabled = False
        Me.TxtCol70.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCol70.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtCol70.Location = New System.Drawing.Point(401, 209)
        Me.TxtCol70.Name = "TxtCol70"
        Me.TxtCol70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtCol70.Size = New System.Drawing.Size(105, 24)
        Me.TxtCol70.Sorted = True
        Me.TxtCol70.TabIndex = 35
        '
        'Txt70Ask
        '
        Me.Txt70Ask.BackColor = System.Drawing.SystemColors.Control
        Me.Txt70Ask.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt70Ask.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Txt70Ask.Location = New System.Drawing.Point(219, 772)
        Me.Txt70Ask.Name = "Txt70Ask"
        Me.Txt70Ask.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Txt70Ask.Size = New System.Drawing.Size(59, 24)
        Me.Txt70Ask.TabIndex = 36
        Me.Txt70Ask.Text = "Ask"
        Me.Txt70Ask.UseVisualStyleBackColor = False
        '
        'TxtStyElipsis50
        '
        Me.TxtStyElipsis50.BackColor = System.Drawing.SystemColors.Control
        Me.TxtStyElipsis50.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtStyElipsis50.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TxtStyElipsis50.Location = New System.Drawing.Point(112, 733)
        Me.TxtStyElipsis50.Name = "TxtStyElipsis50"
        Me.TxtStyElipsis50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtStyElipsis50.Size = New System.Drawing.Size(24, 24)
        Me.TxtStyElipsis50.TabIndex = 37
        Me.TxtStyElipsis50.Text = "..."
        Me.TxtStyElipsis50.UseVisualStyleBackColor = False
        Me.TxtStyElipsis50.Visible = False
        '
        'TxtLay50
        '
        Me.TxtLay50.BackColor = System.Drawing.SystemColors.Window
        Me.TxtLay50.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtLay50.Enabled = False
        Me.TxtLay50.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtLay50.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtLay50.Location = New System.Drawing.Point(131, 169)
        Me.TxtLay50.Name = "TxtLay50"
        Me.TxtLay50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtLay50.Size = New System.Drawing.Size(246, 24)
        Me.TxtLay50.Sorted = True
        Me.TxtLay50.TabIndex = 38
        '
        'TxtSty50
        '
        Me.TxtSty50.BackColor = System.Drawing.SystemColors.Window
        Me.TxtSty50.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtSty50.Enabled = False
        Me.TxtSty50.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtSty50.Location = New System.Drawing.Point(67, 171)
        Me.TxtSty50.Name = "TxtSty50"
        Me.TxtSty50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtSty50.Size = New System.Drawing.Size(132, 25)
        Me.TxtSty50.Sorted = True
        Me.TxtSty50.TabIndex = 39
        '
        'TxtJust50
        '
        Me.TxtJust50.BackColor = System.Drawing.SystemColors.Window
        Me.TxtJust50.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtJust50.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtJust50.Location = New System.Drawing.Point(292, 732)
        Me.TxtJust50.Name = "TxtJust50"
        Me.TxtJust50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtJust50.Size = New System.Drawing.Size(105, 25)
        Me.TxtJust50.TabIndex = 40
        '
        'TxtRot50
        '
        Me.TxtRot50.AcceptsReturn = True
        Me.TxtRot50.BackColor = System.Drawing.SystemColors.Window
        Me.TxtRot50.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtRot50.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtRot50.Location = New System.Drawing.Point(147, 732)
        Me.TxtRot50.MaxLength = 0
        Me.TxtRot50.Name = "TxtRot50"
        Me.TxtRot50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtRot50.Size = New System.Drawing.Size(69, 24)
        Me.TxtRot50.TabIndex = 41
        '
        'TxtCol50
        '
        Me.TxtCol50.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCol50.Cursor = System.Windows.Forms.Cursors.Default
        Me.TxtCol50.Enabled = False
        Me.TxtCol50.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtCol50.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TxtCol50.Location = New System.Drawing.Point(401, 169)
        Me.TxtCol50.Name = "TxtCol50"
        Me.TxtCol50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TxtCol50.Size = New System.Drawing.Size(105, 24)
        Me.TxtCol50.Sorted = True
        Me.TxtCol50.TabIndex = 42
        '
        'Txt50Ask
        '
        Me.Txt50Ask.BackColor = System.Drawing.SystemColors.Control
        Me.Txt50Ask.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt50Ask.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Txt50Ask.Location = New System.Drawing.Point(219, 732)
        Me.Txt50Ask.Name = "Txt50Ask"
        Me.Txt50Ask.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Txt50Ask.Size = New System.Drawing.Size(59, 24)
        Me.Txt50Ask.TabIndex = 43
        Me.Txt50Ask.Text = "Ask"
        Me.Txt50Ask.UseVisualStyleBackColor = False
        '
        'Text25
        '
        Me.Text25.AutoSize = True
        Me.Text25.BackColor = System.Drawing.SystemColors.Control
        Me.Text25.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text25.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Text25.Location = New System.Drawing.Point(47, 93)
        Me.Text25.Name = "Text25"
        Me.Text25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text25.Size = New System.Drawing.Size(28, 16)
        Me.Text25.TabIndex = 44
        Me.Text25.Text = "2.5"
        Me.Text25.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Text35
        '
        Me.Text35.AutoSize = True
        Me.Text35.BackColor = System.Drawing.SystemColors.Control
        Me.Text35.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text35.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Text35.Location = New System.Drawing.Point(47, 133)
        Me.Text35.Name = "Text35"
        Me.Text35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text35.Size = New System.Drawing.Size(28, 16)
        Me.Text35.TabIndex = 45
        Me.Text35.Text = "3.5"
        Me.Text35.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Text50
        '
        Me.Text50.AutoSize = True
        Me.Text50.BackColor = System.Drawing.SystemColors.Control
        Me.Text50.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text50.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text50.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Text50.Location = New System.Drawing.Point(47, 173)
        Me.Text50.Name = "Text50"
        Me.Text50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text50.Size = New System.Drawing.Size(28, 16)
        Me.Text50.TabIndex = 46
        Me.Text50.Text = "5.0"
        Me.Text50.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Text70
        '
        Me.Text70.AutoSize = True
        Me.Text70.BackColor = System.Drawing.SystemColors.Control
        Me.Text70.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text70.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text70.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Text70.Location = New System.Drawing.Point(47, 213)
        Me.Text70.Name = "Text70"
        Me.Text70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text70.Size = New System.Drawing.Size(28, 16)
        Me.Text70.TabIndex = 47
        Me.Text70.Text = "7.0"
        Me.Text70.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Text18
        '
        Me.Text18.AutoSize = True
        Me.Text18.BackColor = System.Drawing.SystemColors.Control
        Me.Text18.Cursor = System.Windows.Forms.Cursors.Default
        Me.Text18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Text18.Location = New System.Drawing.Point(47, 53)
        Me.Text18.Name = "Text18"
        Me.Text18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text18.Size = New System.Drawing.Size(28, 16)
        Me.Text18.TabIndex = 48
        Me.Text18.Text = "1.8"
        Me.Text18.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(145, 568)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(87, 17)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "TEXT/DTEXT"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(309, 568)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(87, 17)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "TEXT/DTEXT"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ClientRules
        '
        Me.ClientRules.BackColor = System.Drawing.SystemColors.Control
        Me.ClientRules.Checked = True
        Me.ClientRules.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ClientRules.Cursor = System.Windows.Forms.Cursors.Default
        Me.ClientRules.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClientRules.ForeColor = System.Drawing.Color.Black
        Me.ClientRules.Location = New System.Drawing.Point(18, 421)
        Me.ClientRules.Name = "ClientRules"
        Me.ClientRules.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ClientRules.Size = New System.Drawing.Size(270, 24)
        Me.ClientRules.TabIndex = 51
        Me.ClientRules.Text = "Client Config"
        Me.ClientRules.UseVisualStyleBackColor = False
        '
        'col18
        '
        Me.col18.BackColor = System.Drawing.SystemColors.Control
        Me.col18.Cursor = System.Windows.Forms.Cursors.Default
        Me.col18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.col18.Location = New System.Drawing.Point(509, 49)
        Me.col18.Name = "col18"
        Me.col18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.col18.Size = New System.Drawing.Size(24, 24)
        Me.col18.TabIndex = 52
        Me.col18.Text = "..."
        Me.col18.UseVisualStyleBackColor = False
        '
        'col25
        '
        Me.col25.BackColor = System.Drawing.SystemColors.Control
        Me.col25.Cursor = System.Windows.Forms.Cursors.Default
        Me.col25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.col25.Location = New System.Drawing.Point(509, 89)
        Me.col25.Name = "col25"
        Me.col25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.col25.Size = New System.Drawing.Size(24, 24)
        Me.col25.TabIndex = 53
        Me.col25.Text = "..."
        Me.col25.UseVisualStyleBackColor = False
        '
        'col35
        '
        Me.col35.BackColor = System.Drawing.SystemColors.Control
        Me.col35.Cursor = System.Windows.Forms.Cursors.Default
        Me.col35.ForeColor = System.Drawing.SystemColors.ControlText
        Me.col35.Location = New System.Drawing.Point(509, 129)
        Me.col35.Name = "col35"
        Me.col35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.col35.Size = New System.Drawing.Size(24, 24)
        Me.col35.TabIndex = 54
        Me.col35.Text = "..."
        Me.col35.UseVisualStyleBackColor = False
        '
        'col50
        '
        Me.col50.BackColor = System.Drawing.SystemColors.Control
        Me.col50.Cursor = System.Windows.Forms.Cursors.Default
        Me.col50.ForeColor = System.Drawing.SystemColors.ControlText
        Me.col50.Location = New System.Drawing.Point(509, 169)
        Me.col50.Name = "col50"
        Me.col50.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.col50.Size = New System.Drawing.Size(24, 24)
        Me.col50.TabIndex = 55
        Me.col50.Text = "..."
        Me.col50.UseVisualStyleBackColor = False
        '
        'col70
        '
        Me.col70.BackColor = System.Drawing.SystemColors.Control
        Me.col70.Cursor = System.Windows.Forms.Cursors.Default
        Me.col70.ForeColor = System.Drawing.SystemColors.ControlText
        Me.col70.Location = New System.Drawing.Point(509, 209)
        Me.col70.Name = "col70"
        Me.col70.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.col70.Size = New System.Drawing.Size(24, 24)
        Me.col70.TabIndex = 56
        Me.col70.Text = "..."
        Me.col70.UseVisualStyleBackColor = False
        '
        'DontAskAgain
        '
        Me.DontAskAgain.BackColor = System.Drawing.SystemColors.Control
        Me.DontAskAgain.Cursor = System.Windows.Forms.Cursors.Default
        Me.DontAskAgain.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DontAskAgain.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DontAskAgain.Location = New System.Drawing.Point(219, 279)
        Me.DontAskAgain.Name = "DontAskAgain"
        Me.DontAskAgain.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DontAskAgain.Size = New System.Drawing.Size(243, 24)
        Me.DontAskAgain.TabIndex = 64
        Me.DontAskAgain.Text = "Don't show this dialog when switching spaces"
        Me.DontAskAgain.UseVisualStyleBackColor = False
        Me.DontAskAgain.Visible = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me.DontPrompt)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.TextHeight)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Controls.Add(Me.TextType)
        Me.Frame1.Controls.Add(Me.ChangeSysVars)
        Me.Frame1.Controls.Add(Me.Justifications)
        Me.Frame1.Controls.Add(Me.ChangeSysVarsVP)
        Me.Frame1.Controls.Add(Me.RotationAngle)
        Me.Frame1.Controls.Add(Me.DegreesLabel)
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(202, 17)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(365, 179)
        Me.Frame1.TabIndex = 57
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Tool Defaults"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(7, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(68, 16)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Text Type"
        '
        'TextHeight
        '
        Me.TextHeight.AcceptsReturn = True
        Me.TextHeight.BackColor = System.Drawing.SystemColors.Window
        Me.TextHeight.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextHeight.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextHeight.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextHeight.Location = New System.Drawing.Point(104, 44)
        Me.TextHeight.MaxLength = 0
        Me.TextHeight.Name = "TextHeight"
        Me.TextHeight.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextHeight.Size = New System.Drawing.Size(93, 23)
        Me.TextHeight.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(7, 47)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(77, 16)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Text Height"
        '
        'TextType
        '
        Me.TextType.BackColor = System.Drawing.SystemColors.Window
        Me.TextType.Cursor = System.Windows.Forms.Cursors.Default
        Me.TextType.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextType.Location = New System.Drawing.Point(104, 17)
        Me.TextType.Name = "TextType"
        Me.TextType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextType.Size = New System.Drawing.Size(93, 24)
        Me.TextType.Sorted = True
        Me.TextType.TabIndex = 4
        '
        'DegreesLabel
        '
        Me.DegreesLabel.AutoSize = True
        Me.DegreesLabel.BackColor = System.Drawing.SystemColors.Control
        Me.DegreesLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.DegreesLabel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DegreesLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DegreesLabel.Location = New System.Drawing.Point(322, 71)
        Me.DegreesLabel.Name = "DegreesLabel"
        Me.DegreesLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DegreesLabel.Size = New System.Drawing.Size(32, 16)
        Me.DegreesLabel.TabIndex = 9
        Me.DegreesLabel.Text = "deg"
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.Controls.Add(Me.ProposedTextSizeLabel)
        Me.Frame2.Controls.Add(Me.NewTextSize)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(247, 246)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(178, 48)
        Me.Frame2.TabIndex = 58
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "Proposed New Value"
        '
        'ProposedTextSizeLabel
        '
        Me.ProposedTextSizeLabel.BackColor = System.Drawing.SystemColors.Control
        Me.ProposedTextSizeLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.ProposedTextSizeLabel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProposedTextSizeLabel.ForeColor = System.Drawing.Color.Black
        Me.ProposedTextSizeLabel.Location = New System.Drawing.Point(16, 23)
        Me.ProposedTextSizeLabel.Name = "ProposedTextSizeLabel"
        Me.ProposedTextSizeLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ProposedTextSizeLabel.Size = New System.Drawing.Size(67, 14)
        Me.ProposedTextSizeLabel.TabIndex = 0
        Me.ProposedTextSizeLabel.Text = "TEXTSIZE:"
        '
        'NewTextSize
        '
        Me.NewTextSize.BackColor = System.Drawing.SystemColors.Control
        Me.NewTextSize.Cursor = System.Windows.Forms.Cursors.Default
        Me.NewTextSize.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NewTextSize.Location = New System.Drawing.Point(89, 23)
        Me.NewTextSize.Name = "NewTextSize"
        Me.NewTextSize.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NewTextSize.Size = New System.Drawing.Size(69, 14)
        Me.NewTextSize.TabIndex = 1
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.Controls.Add(Me.ActualTextSizeLabel)
        Me.Frame3.Controls.Add(Me.CurrentTEXTSIZE)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(42, 246)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(178, 48)
        Me.Frame3.TabIndex = 59
        Me.Frame3.TabStop = False
        Me.Frame3.Text = "Current Value"
        '
        'ActualTextSizeLabel
        '
        Me.ActualTextSizeLabel.BackColor = System.Drawing.SystemColors.Control
        Me.ActualTextSizeLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.ActualTextSizeLabel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ActualTextSizeLabel.ForeColor = System.Drawing.Color.Black
        Me.ActualTextSizeLabel.Location = New System.Drawing.Point(8, 23)
        Me.ActualTextSizeLabel.Name = "ActualTextSizeLabel"
        Me.ActualTextSizeLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ActualTextSizeLabel.Size = New System.Drawing.Size(67, 14)
        Me.ActualTextSizeLabel.TabIndex = 0
        Me.ActualTextSizeLabel.Text = "TEXTSIZE:"
        '
        'CurrentTEXTSIZE
        '
        Me.CurrentTEXTSIZE.BackColor = System.Drawing.SystemColors.Control
        Me.CurrentTEXTSIZE.Cursor = System.Windows.Forms.Cursors.Default
        Me.CurrentTEXTSIZE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CurrentTEXTSIZE.Location = New System.Drawing.Point(83, 23)
        Me.CurrentTEXTSIZE.Name = "CurrentTEXTSIZE"
        Me.CurrentTEXTSIZE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CurrentTEXTSIZE.Size = New System.Drawing.Size(75, 14)
        Me.CurrentTEXTSIZE.TabIndex = 1
        '
        'ScaleFrame
        '
        Me.ScaleFrame.BackColor = System.Drawing.SystemColors.Control
        Me.ScaleFrame.Controls.Add(Me.Label10)
        Me.ScaleFrame.Controls.Add(Me.Label11)
        Me.ScaleFrame.Controls.Add(Me.UserScale1)
        Me.ScaleFrame.Controls.Add(Me.UserScale2)
        Me.ScaleFrame.Controls.Add(Me.Label12)
        Me.ScaleFrame.Controls.Add(Me.MetersNotice)
        Me.ScaleFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ScaleFrame.Location = New System.Drawing.Point(202, 201)
        Me.ScaleFrame.Name = "ScaleFrame"
        Me.ScaleFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ScaleFrame.Size = New System.Drawing.Size(298, 72)
        Me.ScaleFrame.TabIndex = 60
        Me.ScaleFrame.TabStop = False
        Me.ScaleFrame.Text = "Model Space Scale"
        Me.ScaleFrame.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(14, 21)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(47, 16)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Scale:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(83, 23)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(13, 17)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = ":"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'UserScale1
        '
        Me.UserScale1.BackColor = System.Drawing.SystemColors.Control
        Me.UserScale1.Cursor = System.Windows.Forms.Cursors.Default
        Me.UserScale1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.UserScale1.Location = New System.Drawing.Point(56, 23)
        Me.UserScale1.Name = "UserScale1"
        Me.UserScale1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UserScale1.Size = New System.Drawing.Size(18, 13)
        Me.UserScale1.TabIndex = 2
        '
        'UserScale2
        '
        Me.UserScale2.BackColor = System.Drawing.SystemColors.Control
        Me.UserScale2.Cursor = System.Windows.Forms.Cursors.Default
        Me.UserScale2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.UserScale2.Location = New System.Drawing.Point(101, 23)
        Me.UserScale2.Name = "UserScale2"
        Me.UserScale2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UserScale2.Size = New System.Drawing.Size(75, 13)
        Me.UserScale2.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label12.Location = New System.Drawing.Point(23, 50)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(225, 15)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "NOTE: Scale tool is configured for meters."
        '
        'MetersNotice
        '
        Me.MetersNotice.BackColor = System.Drawing.SystemColors.Control
        Me.MetersNotice.Cursor = System.Windows.Forms.Cursors.Default
        Me.MetersNotice.ForeColor = System.Drawing.SystemColors.WindowText
        Me.MetersNotice.Location = New System.Drawing.Point(23, 50)
        Me.MetersNotice.Name = "MetersNotice"
        Me.MetersNotice.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.MetersNotice.Size = New System.Drawing.Size(225, 15)
        Me.MetersNotice.TabIndex = 5
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(180, 35)
        Me.lblTitle.TabIndex = 61
        Me.lblTitle.Text = "Text Options"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 65
        Me.LogoPictureBox.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(9, 25)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(77, 16)
        Me.Label5.TabIndex = 66
        Me.Label5.Text = "Text Height"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(29, 96)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(28, 16)
        Me.Label6.TabIndex = 67
        Me.Label6.Text = "2.5"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(29, 136)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(28, 16)
        Me.Label9.TabIndex = 68
        Me.Label9.Text = "3.5"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label14.Location = New System.Drawing.Point(29, 176)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(28, 16)
        Me.Label14.TabIndex = 69
        Me.Label14.Text = "5.0"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(29, 216)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(28, 16)
        Me.Label15.TabIndex = 70
        Me.Label15.Text = "7.0"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.SystemColors.Control
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(29, 56)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label16.Size = New System.Drawing.Size(28, 16)
        Me.Label16.TabIndex = 71
        Me.Label16.Text = "1.8"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TextToolGroupBox
        '
        Me.TextToolGroupBox.Controls.Add(Me.OverrideConfigSettingsRadioButton)
        Me.TextToolGroupBox.Controls.Add(Me.UseSettingsInConfigRadioButton)
        Me.TextToolGroupBox.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextToolGroupBox.Location = New System.Drawing.Point(18, 494)
        Me.TextToolGroupBox.Name = "TextToolGroupBox"
        Me.TextToolGroupBox.Size = New System.Drawing.Size(498, 44)
        Me.TextToolGroupBox.TabIndex = 72
        Me.TextToolGroupBox.TabStop = False
        Me.TextToolGroupBox.Text = "Text Tool Settings"
        '
        'OverrideConfigSettingsRadioButton
        '
        Me.OverrideConfigSettingsRadioButton.AutoSize = True
        Me.OverrideConfigSettingsRadioButton.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OverrideConfigSettingsRadioButton.Location = New System.Drawing.Point(270, 18)
        Me.OverrideConfigSettingsRadioButton.Name = "OverrideConfigSettingsRadioButton"
        Me.OverrideConfigSettingsRadioButton.Size = New System.Drawing.Size(228, 20)
        Me.OverrideConfigSettingsRadioButton.TabIndex = 18
        Me.OverrideConfigSettingsRadioButton.Text = "Override Configuration Settings"
        Me.OverrideConfigSettingsRadioButton.UseVisualStyleBackColor = True
        '
        'UseSettingsInConfigRadioButton
        '
        Me.UseSettingsInConfigRadioButton.AutoSize = True
        Me.UseSettingsInConfigRadioButton.Checked = True
        Me.UseSettingsInConfigRadioButton.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UseSettingsInConfigRadioButton.Location = New System.Drawing.Point(20, 18)
        Me.UseSettingsInConfigRadioButton.Name = "UseSettingsInConfigRadioButton"
        Me.UseSettingsInConfigRadioButton.Size = New System.Drawing.Size(265, 20)
        Me.UseSettingsInConfigRadioButton.TabIndex = 17
        Me.UseSettingsInConfigRadioButton.TabStop = True
        Me.UseSettingsInConfigRadioButton.Text = "Use Settings Defined in Configuration"
        Me.UseSettingsInConfigRadioButton.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.SettingsTabPage)
        Me.TabControl1.Controls.Add(Me.ToolDefaultsTabPage)
        Me.TabControl1.Location = New System.Drawing.Point(7, 66)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(581, 342)
        Me.TabControl1.TabIndex = 73
        '
        'SettingsTabPage
        '
        Me.SettingsTabPage.Controls.Add(Me.TextTitle)
        Me.SettingsTabPage.Controls.Add(Me.Frame3)
        Me.SettingsTabPage.Controls.Add(Me.Frame2)
        Me.SettingsTabPage.Controls.Add(Me.col70)
        Me.SettingsTabPage.Controls.Add(Me.col50)
        Me.SettingsTabPage.Controls.Add(Me.col35)
        Me.SettingsTabPage.Controls.Add(Me.col25)
        Me.SettingsTabPage.Controls.Add(Me.col18)
        Me.SettingsTabPage.Controls.Add(Me.TxtLay18)
        Me.SettingsTabPage.Controls.Add(Me.Text18)
        Me.SettingsTabPage.Controls.Add(Me.LayerTitle)
        Me.SettingsTabPage.Controls.Add(Me.Text70)
        Me.SettingsTabPage.Controls.Add(Me.Text50)
        Me.SettingsTabPage.Controls.Add(Me.Text35)
        Me.SettingsTabPage.Controls.Add(Me.Text25)
        Me.SettingsTabPage.Controls.Add(Me.TxtCol50)
        Me.SettingsTabPage.Controls.Add(Me.TxtLay50)
        Me.SettingsTabPage.Controls.Add(Me.TxtCol70)
        Me.SettingsTabPage.Controls.Add(Me.TxtLay70)
        Me.SettingsTabPage.Controls.Add(Me.TxtCol25)
        Me.SettingsTabPage.Controls.Add(Me.TxtCol18)
        Me.SettingsTabPage.Controls.Add(Me.TxtLay25)
        Me.SettingsTabPage.Controls.Add(Me.ColourTitle)
        Me.SettingsTabPage.Controls.Add(Me.TxtCol35)
        Me.SettingsTabPage.Controls.Add(Me.TxtLay35)
        Me.SettingsTabPage.Location = New System.Drawing.Point(4, 26)
        Me.SettingsTabPage.Name = "SettingsTabPage"
        Me.SettingsTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.SettingsTabPage.Size = New System.Drawing.Size(573, 312)
        Me.SettingsTabPage.TabIndex = 0
        Me.SettingsTabPage.Text = "Settings"
        Me.SettingsTabPage.UseVisualStyleBackColor = True
        '
        'ToolDefaultsTabPage
        '
        Me.ToolDefaultsTabPage.Controls.Add(Me.Frame1)
        Me.ToolDefaultsTabPage.Controls.Add(Me.ScaleFrame)
        Me.ToolDefaultsTabPage.Controls.Add(Me.Label5)
        Me.ToolDefaultsTabPage.Controls.Add(Me.DontAskAgain)
        Me.ToolDefaultsTabPage.Controls.Add(Me.Label6)
        Me.ToolDefaultsTabPage.Controls.Add(Me.TxtSty50)
        Me.ToolDefaultsTabPage.Controls.Add(Me.Label9)
        Me.ToolDefaultsTabPage.Controls.Add(Me.TxtSty70)
        Me.ToolDefaultsTabPage.Controls.Add(Me.Label14)
        Me.ToolDefaultsTabPage.Controls.Add(Me.TxtSty25)
        Me.ToolDefaultsTabPage.Controls.Add(Me.Label15)
        Me.ToolDefaultsTabPage.Controls.Add(Me.TxtSty35)
        Me.ToolDefaultsTabPage.Controls.Add(Me.Label16)
        Me.ToolDefaultsTabPage.Controls.Add(Me.StyleTitle)
        Me.ToolDefaultsTabPage.Controls.Add(Me.TxtSty18)
        Me.ToolDefaultsTabPage.Location = New System.Drawing.Point(4, 26)
        Me.ToolDefaultsTabPage.Name = "ToolDefaultsTabPage"
        Me.ToolDefaultsTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.ToolDefaultsTabPage.Size = New System.Drawing.Size(573, 312)
        Me.ToolDefaultsTabPage.TabIndex = 1
        Me.ToolDefaultsTabPage.Text = "Tool Defaults"
        Me.ToolDefaultsTabPage.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.OK_Button, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(341, 414)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(241, 36)
        Me.TableLayoutPanel2.TabIndex = 74
        '
        'Text
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(594, 457)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TextToolGroupBox)
        Me.Controls.Add(Me.TxtJust18)
        Me.Controls.Add(Me.JustificationTitle)
        Me.Controls.Add(Me.TxtStyElipsis18)
        Me.Controls.Add(Me.TxtRot18)
        Me.Controls.Add(Me.RotateTitle)
        Me.Controls.Add(Me.Txt18Ask)
        Me.Controls.Add(Me.TxtStyElipsis35)
        Me.Controls.Add(Me.TxtJust35)
        Me.Controls.Add(Me.TxtRot35)
        Me.Controls.Add(Me.Txt35Ask)
        Me.Controls.Add(Me.TxtStyElipsis25)
        Me.Controls.Add(Me.TxtJust25)
        Me.Controls.Add(Me.TxtRot25)
        Me.Controls.Add(Me.Txt25Ask)
        Me.Controls.Add(Me.TxtStyElipsis70)
        Me.Controls.Add(Me.TxtJust70)
        Me.Controls.Add(Me.TxtRot70)
        Me.Controls.Add(Me.Txt70Ask)
        Me.Controls.Add(Me.TxtStyElipsis50)
        Me.Controls.Add(Me.TxtJust50)
        Me.Controls.Add(Me.TxtRot50)
        Me.Controls.Add(Me.Txt50Ask)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ClientRules)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 19)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Text"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.Frame3.ResumeLayout(False)
        Me.ScaleFrame.ResumeLayout(False)
        Me.ScaleFrame.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TextToolGroupBox.ResumeLayout(False)
        Me.TextToolGroupBox.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.SettingsTabPage.ResumeLayout(False)
        Me.SettingsTabPage.PerformLayout()
        Me.ToolDefaultsTabPage.ResumeLayout(False)
        Me.ToolDefaultsTabPage.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents Label9 As System.Windows.Forms.Label
    Public WithEvents Label14 As System.Windows.Forms.Label
    Public WithEvents Label15 As System.Windows.Forms.Label
    Public WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextToolGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents OverrideConfigSettingsRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents UseSettingsInConfigRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents SettingsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents ToolDefaultsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
#End Region
End Class