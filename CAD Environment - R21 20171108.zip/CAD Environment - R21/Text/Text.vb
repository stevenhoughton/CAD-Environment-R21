#Region "Imports"

Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports AutoCADApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Interop
Imports System.Windows.Forms
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.AutoCAD.RulesAndWorkvars
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension

#End Region

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.Text.Text))> 

Public Class Text
    Implements Autodesk.AutoCAD.Runtime.IExtensionApplication

    Public WithEvents ThisDrawingText As AcadDocument = CType(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)
    Public WithEvents docs As DocumentCollection = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager

    '' Dim RuleAccessors As New RuleAccessors
    Dim SelectConfig As New SelectTemplate.TemplateSelector
    Dim TextOptionsFrm As New TextForm
    Dim JustificationsFrm As New Justifications
    Dim sToolPath As String

    Private Structure Rule
        Dim name As String
        Dim Desc As String
        Dim value As String
        Dim tblcode As Integer
        Dim dglcode As Integer
    End Structure

    Private Structure WorkVar
        Dim name As String
        Dim value As String
    End Structure

    Private sTextType As String
    Private sPreviousLayer As String
    Private sPreviousCEColour As String
    Private sPreviousTextStyle As String
    Private sPreviousTextSize As String

    ' Flag used to check whether it's our command that launched PLINE
    Private Shared myCommandStarted As Boolean = False
    '  Private Shared DocColl As Autodesk.AutoCAD.ApplicationServices.DocumentCollection = AutoCADApp.DocumentManager

#Region "Events"

    Public Sub Initialize() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Initialize
        Try

            'Dim Doc As Document
            'For Each Doc In DocColl
            '    'AddHandler Doc.CommandEnded, AddressOf MyCommandEnded
            '    'AddHandler Doc.CommandCancelled, AddressOf MyCancelCommand
            'Next
            AddHandler docs.DocumentActivated, AddressOf docs_ActivatedCreatedEvent
            'AddHandler docs.DocumentToBeDestroyed, AddressOf MyDocumentToBeDestroyed

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub docs_ActivatedCreatedEvent(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.DocumentCollectionEventArgs)

        '' Get the current document
        Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument

        AddHandler acDoc.CommandEnded, AddressOf CommandEndedEvent

        '' Ensure we always have the current drawing in ThisDrawing variable - as we are relying on a few of it's events
        Try
            ThisDrawingText = CType(e.Document.GetAcadDocument, AcadDocument)
        Catch ex As Exception

        End Try

        'AddHandler e.Document.CommandEnded, New CommandEventHandler(AddressOf MyCommandEnded)
        'AddHandler e.Document.CommandCancelled, New CommandEventHandler(AddressOf MyCancelCommand)
    End Sub

    Public Sub Terminate() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Terminate

    End Sub

    Private Sub CommandEndedEvent(ByVal senderObj As Object, ByVal e As CommandEventArgs)

        If ((myCommandStarted = True) And (UCase(e.GlobalCommandName) = UCase(sTextType))) Then
            AutoCADApp.SetSystemVariable("CECOLOR", sPreviousCEColour)
            AutoCADApp.SetSystemVariable("CLAYER", sPreviousLayer)
            AutoCADApp.SetSystemVariable("TEXTSTYLE", sPreviousTextStyle)
            AutoCADApp.SetSystemVariable("TEXTSIZE", CDbl(sPreviousTextSize))
            myCommandStarted = False
        End If

    End Sub

#End Region

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_TextOptions", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub TextOptions()
        Try
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() Then
                    DisplayDialog()
                End If
            Else
                DisplayDialog()
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub DisplayDialog()
        Try
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(TextOptionsFrm)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_T18", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub T18()
        Try
            Dim sTextLayer As String
            Dim sTextStyle As String
            Dim sTextColour As String
            Dim sTextHeight As String
            'Dim sTextType As String
            Dim sTextJustification As String = ""
            Dim sCallingString As String
            Dim vDontPrompt As String
            Dim vRotationAngle As Object
            'Dim dscale As Double
            Dim dTextSize As Double
            Dim TJust As String = ""

            Dim bIgnoreOverrides As Boolean

            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If

            'added by Dgrigg
            ThisDrawingText.StartUndoMark()

            ' Check to see if we need to look for Rules or workvar overrides
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue

            TextOptionsFrm.CheckRules()
            sTextStyle = RuleAccessors.GetruleValue("TEXT4", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextLayer = RuleAccessors.GetruleValue("TEXT3", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)

            'TextRule = RuleSearch("TEXT4", arrrulenf, j, ThisDrawing.GetVariable("TEXTSTYLE").tostring, True, False, bIgnoreOverrides, True, False)
            'sTextStyle = TextRule.value
            'TextRule = RuleSearch("TEXT3", arrrulenf, j, ThisDrawing.GetVariable("CLAYER").ToString, True, False, bIgnoreOverrides, True, False)
            'sTextLayer = TextRule.value
            dTextSize = 1.8
            ' TextOptionsFrm.CheckRules()

            ' These next 3 lines use the dialog overrides all the time - never the rule value unless it's not set
            sTextType = RuleAccessors.GetruleValue("TEXT1", "MTEXT", False, True)
            vDontPrompt = RuleAccessors.GetruleValue("TEXT24", "False", False, True)
            vRotationAngle = RuleAccessors.GetruleValue("TEXT28", "0.0", False, True)

            ' Sort out the true and false possibilities for
            ' If vDontPrompt = False Or vDontPrompt = 0 Or UCase(vDontPrompt) = "FALSE" Then
            If UCase(vDontPrompt) = "FALSE" Then
                vDontPrompt = "FALSE"
            Else
                vDontPrompt = "TRUE"
            End If

            sTextLayer = RuleAccessors.GetruleValue("TEXT3", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)
            sTextStyle = RuleAccessors.GetruleValue("TEXT4", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextColour = RuleAccessors.GetruleValue("TEXT5", ThisDrawingText.GetVariable("CECOLOR").ToString, False, True)

            'added by Dgrigg
            If TextOptionsFrm.Justifications.CheckState = CheckState.Checked And UCase(sTextType) = "DTEXT" Then

                'JustificationsFrm.Show()
                Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(JustificationsFrm)
                If JustificationsFrm.TL.CheckState = CheckState.Checked Then
                    TJust = "TL"
                End If
                If JustificationsFrm.TC.CheckState = CheckState.Checked Then
                    TJust = "TC"
                End If
                If JustificationsFrm.TR.CheckState = CheckState.Checked Then
                    TJust = "TR"
                End If
                If JustificationsFrm.ML.CheckState = CheckState.Checked Then
                    TJust = "ML"
                End If
                If JustificationsFrm.MC.CheckState = CheckState.Checked Then
                    TJust = "MC"
                End If
                If JustificationsFrm.MR.CheckState = CheckState.Checked Then
                    TJust = "MR"
                End If
                If JustificationsFrm.BL.CheckState = CheckState.Checked Then
                    TJust = "BL"
                End If
                If JustificationsFrm.BC.CheckState = CheckState.Checked Then
                    TJust = "BC"
                End If
                If JustificationsFrm.BR.CheckState = CheckState.Checked Then
                    TJust = "BR"
                End If

                sTextJustification = TJust
                JustificationsFrm.Hide()
            End If

            If sTextJustification = "" Then
                sTextJustification = RuleAccessors.GetruleValue("TEXT6", "BL", False, True)
            End If

            sTextHeight = CStr(CalculateNewTextSize(dTextSize))

            sCallingString = sTextType & ";" & sTextLayer & ";" & sTextStyle & ";" & sTextColour & ";" & sTextHeight & ";" & sTextJustification & ";" & vDontPrompt & ";" & vRotationAngle.ToString

            WorkingVariableAccessors.AddWorkVar("TEXTPARAMS", sCallingString)

            TXT()

            ThisDrawingText.EndUndoMark()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_T25", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub T25()
        Try


            Dim sTextLayer As String
            Dim sTextStyle As String
            Dim sTextColour As String
            Dim sTextHeight As String
            'Dim sTextType As String
            Dim sTextJustification As String = ""
            Dim sCallingString As String
            Dim vDontPrompt As String
            Dim vRotationAngle As Object
            'Dim dscale As Double
            Dim dTextSize As Double
            Dim TJust As String = ""

            Dim bIgnoreOverrides As Boolean


            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If
            'added by Dgrigg
            'added by Dgrigg

            ThisDrawingText.StartUndoMark()


            ' Check to see if we need to look for Rules or workvar overrides
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue
            ' TextRule = RuleSearch("TEXT8", arrrulenf, j, ThisDrawing.GetVariable("TEXTSTYLE").tostring, True, False, bIgnoreOverrides, True, False)
            ' sTextStyle = TextRule.value
            sTextStyle = RuleAccessors.GetruleValue("TEXT8", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextLayer = RuleAccessors.GetruleValue("TEXT7", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)
            'TextRule = RuleSearch("TEXT7", arrrulenf, j, ThisDrawing.GetVariable("CLAYER").ToString, True, False, bIgnoreOverrides, True, False)
            ' sTextLayer = TextRule.value

            dTextSize = 2.5

            TextOptionsFrm.CheckRules()

            sTextType = RuleAccessors.GetruleValue("TEXT1", "MTEXT", False, True)
            vDontPrompt = RuleAccessors.GetruleValue("TEXT24", "False", False, True)
            vRotationAngle = RuleAccessors.GetruleValue("TEXT28", "0.0", False, True)

            ' Sort out the true and false possibilities for
            If UCase(vDontPrompt) = "FALSE" Then
                vDontPrompt = "FALSE"
            Else
                vDontPrompt = "TRUE"
            End If

            sTextStyle = RuleAccessors.GetruleValue("TEXT8", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextColour = RuleAccessors.GetruleValue("TEXT9", ThisDrawingText.GetVariable("CECOLOR").ToString, False, True)

            'added by Dgrigg
            If TextOptionsFrm.Justifications.CheckState = CheckState.Checked And UCase(sTextType) = "DTEXT" Then

                JustificationsFrm.Show()

                If JustificationsFrm.TL.CheckState = CheckState.Checked Then
                    TJust = "TL"
                End If
                If JustificationsFrm.TC.CheckState = CheckState.Checked Then
                    TJust = "TC"
                End If
                If JustificationsFrm.TR.CheckState = CheckState.Checked Then
                    TJust = "TR"
                End If
                If JustificationsFrm.ML.CheckState = CheckState.Checked Then
                    TJust = "ML"
                End If
                If JustificationsFrm.MC.CheckState = CheckState.Checked Then
                    TJust = "MC"
                End If
                If JustificationsFrm.MR.CheckState = CheckState.Checked Then
                    TJust = "MR"
                End If
                If JustificationsFrm.BL.CheckState = CheckState.Checked Then
                    TJust = "BL"
                End If
                If JustificationsFrm.BC.CheckState = CheckState.Checked Then
                    TJust = "BC"
                End If
                If JustificationsFrm.BR.CheckState = CheckState.Checked Then
                    TJust = "BR"
                End If

                sTextJustification = TJust
                JustificationsFrm.Hide()
            End If

            If sTextJustification = "" Then
                sTextJustification = RuleAccessors.GetruleValue("TEXT10", "BL", False, True)
            End If


            sTextHeight = CStr(CalculateNewTextSize(dTextSize))

            sCallingString = sTextType & ";" & sTextLayer & ";" & sTextStyle & ";" & sTextColour & ";" & sTextHeight & ";" & sTextJustification & ";" & vDontPrompt & ";" & vRotationAngle.ToString

            WorkingVariableAccessors.AddWorkVar("TEXTPARAMS", sCallingString)

            TXT()
            ThisDrawingText.EndUndoMark()
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try


    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_T35", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub T35()

        Try
            Dim sTextLayer As String
            Dim sTextStyle As String
            Dim sTextColour As String
            Dim sTextHeight As String
            'Dim sTextType As String
            Dim sTextJustification As String = ""
            Dim sCallingString As String
            Dim vDontPrompt As String
            Dim vRotationAngle As Object
            'Dim dscale As Double
            Dim dTextSize As Double
            Dim TJust As String = ""

            Dim bIgnoreOverrides As Boolean

            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If
            'added by Dgrigg
            'added by Dgrigg

            ThisDrawingText.StartUndoMark()

            ' Check to see if we need to look for Rules or workvar overrides
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue

            ' TextRule = RuleSearch("TEXT12", arrrulenf, j, ThisDrawing.GetVariable("TEXTSTYLE").tostring, True, False, bIgnoreOverrides, True, False)
            'sTextStyle = TextRule.value
            sTextStyle = RuleAccessors.GetruleValue("TEXT12", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)

            ' TextRule = RuleSearch("TEXT11", arrrulenf, j, ThisDrawing.GetVariable("CLAYER").ToString, True, False, bIgnoreOverrides, True, False)
            'sTextLayer = TextRule.value
            sTextLayer = RuleAccessors.GetruleValue("TEXT11", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)
            dTextSize = 3.5

            TextOptionsFrm.CheckRules()

            sTextType = RuleAccessors.GetruleValue("TEXT1", "MTEXT", False, True)
            vDontPrompt = RuleAccessors.GetruleValue("TEXT24", "False", False, True)
            vRotationAngle = RuleAccessors.GetruleValue("TEXT28", "0.0", False, True)

            ' Sort out the true and false possibilities for
            If UCase(vDontPrompt) = "FALSE" Then
                vDontPrompt = "FALSE"
            Else
                vDontPrompt = "TRUE"
            End If

            sTextStyle = RuleAccessors.GetruleValue("TEXT12", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextColour = RuleAccessors.GetruleValue("TEXT13", ThisDrawingText.GetVariable("CECOLOR").ToString, False, True)

            'added by Dgrigg
            If TextOptionsFrm.Justifications.CheckState = CheckState.Checked And UCase(sTextType) = "DTEXT" Then

                JustificationsFrm.Show()

                If JustificationsFrm.TL.CheckState = CheckState.Checked Then
                    TJust = "TL"
                End If
                If JustificationsFrm.TC.CheckState = CheckState.Checked Then
                    TJust = "TC"
                End If
                If JustificationsFrm.TR.CheckState = CheckState.Checked Then
                    TJust = "TR"
                End If
                If JustificationsFrm.ML.CheckState = CheckState.Checked Then
                    TJust = "ML"
                End If
                If JustificationsFrm.MC.CheckState = CheckState.Checked Then
                    TJust = "MC"
                End If
                If JustificationsFrm.MR.CheckState = CheckState.Checked Then
                    TJust = "MR"
                End If
                If JustificationsFrm.BL.CheckState = CheckState.Checked Then
                    TJust = "BL"
                End If
                If JustificationsFrm.BC.CheckState = CheckState.Checked Then
                    TJust = "BC"
                End If
                If JustificationsFrm.BR.CheckState = CheckState.Checked Then
                    TJust = "BR"
                End If

                sTextJustification = TJust
                JustificationsFrm.Hide()

            End If

            If sTextJustification = "" Then
                sTextJustification = RuleAccessors.GetruleValue("TEXT14", "BL", False, True)
            End If

            sTextHeight = CalculateNewTextSize(dTextSize).ToString

            sCallingString = sTextType & ";" & sTextLayer & ";" & sTextStyle & ";" & sTextColour & ";" & sTextHeight & ";" & sTextJustification & ";" & vDontPrompt & ";" & vRotationAngle.ToString

            WorkingVariableAccessors.AddWorkVar("TEXTPARAMS", sCallingString)

            TXT()

            ThisDrawingText.EndUndoMark()
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_T50", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub T50()
        Try


            Dim sTextLayer As String
            Dim sTextStyle As String
            Dim sTextColour As String
            Dim sTextHeight As String
            'Dim sTextType As String
            Dim sTextJustification As String = ""
            Dim sCallingString As String
            Dim vDontPrompt As String
            Dim vRotationAngle As Object
            'Dim dscale As Double
            Dim dTextSize As Double
            Dim TJust As String = ""

            Dim bIgnoreOverrides As Boolean


            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If

            ThisDrawingText.StartUndoMark()


            ' Check to see if we need to look for Rules or workvar overrides
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue

            'TextRule = RuleSearch("TEXT16", arrrulenf, j, ThisDrawing.GetVariable("TEXTSTYLE").tostring, True, False, bIgnoreOverrides, True, False)
            'sTextStyle = TextRule.value
            sTextStyle = RuleAccessors.GetruleValue("TEXT16", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            ' TextRule = RuleSearch("TEXT15", arrrulenf, j, ThisDrawing.GetVariable("CLAYER").ToString, True, False, bIgnoreOverrides, True, False)
            ' sTextLayer = TextRule.value
            sTextLayer = RuleAccessors.GetruleValue("TEXT15", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)

            dTextSize = 5.0#

            TextOptionsFrm.CheckRules()

            sTextType = RuleAccessors.GetruleValue("TEXT1", "MTEXT", False, True)
            vDontPrompt = RuleAccessors.GetruleValue("TEXT24", "False", False, True)
            vRotationAngle = RuleAccessors.GetruleValue("TEXT28", "0.0", False, True)

            ' Sort out the true and false possibilities for
            If UCase(vDontPrompt) = "FALSE" Then
                vDontPrompt = "FALSE"
            Else
                vDontPrompt = "TRUE"
            End If

            sTextLayer = RuleAccessors.GetruleValue("TEXT15", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)
            sTextStyle = RuleAccessors.GetruleValue("TEXT16", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextColour = RuleAccessors.GetruleValue("TEXT17", ThisDrawingText.GetVariable("CECOLOR").ToString, False, True)

            'added by Dgrigg
            If TextOptionsFrm.Justifications.CheckState = CheckState.Checked And UCase(sTextType) = "DTEXT" Then

                JustificationsFrm.Show()

                If JustificationsFrm.TL.CheckState = CheckState.Checked Then
                    TJust = "TL"
                End If
                If JustificationsFrm.TC.CheckState = CheckState.Checked Then
                    TJust = "TC"
                End If
                If JustificationsFrm.TR.CheckState = CheckState.Checked Then
                    TJust = "TR"
                End If
                If JustificationsFrm.ML.CheckState = CheckState.Checked Then
                    TJust = "ML"
                End If
                If JustificationsFrm.MC.CheckState = CheckState.Checked Then
                    TJust = "MC"
                End If
                If JustificationsFrm.MR.CheckState = CheckState.Checked Then
                    TJust = "MR"
                End If
                If JustificationsFrm.BL.CheckState = CheckState.Checked Then
                    TJust = "BL"
                End If
                If JustificationsFrm.BC.CheckState = CheckState.Checked Then
                    TJust = "BC"
                End If
                If JustificationsFrm.BR.CheckState = CheckState.Checked Then
                    TJust = "BR"
                End If

                sTextJustification = TJust
                JustificationsFrm.Hide()

            End If

            If sTextJustification = "" Then
                sTextJustification = RuleAccessors.GetruleValue("TEXT18", "BL", False, True)
            End If


            sTextHeight = CalculateNewTextSize(dTextSize).ToString

            sCallingString = sTextType & ";" & sTextLayer & ";" & sTextStyle & ";" & sTextColour & ";" & sTextHeight & ";" & sTextJustification & ";" & vDontPrompt & ";" & vRotationAngle.ToString

            WorkingVariableAccessors.AddWorkVar("TEXTPARAMS", sCallingString)

            TXT()

            ThisDrawingText.EndUndoMark()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_T70", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub T70()
        Try

            Dim sTextLayer As String
            Dim sTextStyle As String
            Dim sTextColour As String
            Dim sTextHeight As String
            'Dim sTextType As String
            Dim sTextJustification As String = ""
            Dim sCallingString As String
            Dim vDontPrompt As String
            Dim vRotationAngle As Object
            'Dim dscale As Double
            Dim dTextSize As Double
            Dim TJust As String = ""

            Dim bIgnoreOverrides As Boolean

            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If

            ThisDrawingText.StartUndoMark()


            ' Check to see if we need to look for Rules or workvar overrides
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").IsTrue

            'TextRule = RuleSearch("TEXT20", arrrulenf, j, ThisDrawing.GetVariable("TEXTSTYLE").tostring, True, False, bIgnoreOverrides, True, False)
            'sTextStyle = TextRule.value
            'TextRule = RuleSearch("TEXT19", arrrulenf, j, ThisDrawing.GetVariable("CLAYER").ToString, True, False, bIgnoreOverrides, True, False)
            'sTextLayer = TextRule.value
            sTextLayer = RuleAccessors.GetruleValue("TEXT19", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)
            sTextStyle = RuleAccessors.GetruleValue("TEXT20", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            dTextSize = 7.0#

            TextOptionsFrm.CheckRules()

            sTextType = RuleAccessors.GetruleValue("TEXT1", "MTEXT", False, True)
            vDontPrompt = RuleAccessors.GetruleValue("TEXT24", "False", False, True)
            vRotationAngle = RuleAccessors.GetruleValue("TEXT28", "0.0", False, True)

            ' Sort out the true and false possibilities for
            If UCase(vDontPrompt) = "FALSE" Then
                vDontPrompt = "FALSE"
            Else
                vDontPrompt = "TRUE"
            End If
            sTextLayer = RuleAccessors.GetruleValue("TEXT19", ThisDrawingText.GetVariable("CLAYER").ToString, False, True)
            sTextStyle = RuleAccessors.GetruleValue("TEXT20", ThisDrawingText.GetVariable("TEXTSTYLE").ToString, False, True)
            sTextColour = RuleAccessors.GetruleValue("TEXT21", ThisDrawingText.GetVariable("CECOLOR").ToString, False, True)

            'added by Dgrigg
            If TextOptionsFrm.Justifications.CheckState = CheckState.Checked And UCase(sTextType) = "DTEXT" Then

                JustificationsFrm.Show()

                If JustificationsFrm.TL.CheckState = CheckState.Checked Then
                    TJust = "TL"
                End If
                If JustificationsFrm.TC.CheckState = CheckState.Checked Then
                    TJust = "TC"
                End If
                If JustificationsFrm.TR.CheckState = CheckState.Checked Then
                    TJust = "TR"
                End If
                If JustificationsFrm.ML.CheckState = CheckState.Checked Then
                    TJust = "ML"
                End If
                If JustificationsFrm.MC.CheckState = CheckState.Checked Then
                    TJust = "MC"
                End If
                If JustificationsFrm.MR.CheckState = CheckState.Checked Then
                    TJust = "MR"
                End If
                If JustificationsFrm.BL.CheckState = CheckState.Checked Then
                    TJust = "BL"
                End If
                If JustificationsFrm.BC.CheckState = CheckState.Checked Then
                    TJust = "BC"
                End If
                If JustificationsFrm.BR.CheckState = CheckState.Checked Then
                    TJust = "BR"
                End If

                sTextJustification = TJust
                JustificationsFrm.Hide()

            End If

            If sTextJustification = "" Then
                sTextJustification = RuleAccessors.GetruleValue("TEXT22", "BL", False, True)
            End If

            sTextHeight = CalculateNewTextSize(dTextSize).ToString

            sCallingString = sTextType & ";" & sTextLayer & ";" & sTextStyle & ";" & sTextColour & ";" & sTextHeight & ";" & sTextJustification & ";" & vDontPrompt & ";" & vRotationAngle.ToString

            WorkingVariableAccessors.AddWorkVar("TEXTPARAMS", sCallingString)

            TXT()

            ThisDrawingText.EndUndoMark()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_DTEXT", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Sub DTEXT()
        Try


            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If

            TextOptionsFrm.CheckRules()
            RuleAccessors.RecordDglRule("TEXT1", "DTEXT")
            Acad_MessageBox("The AE is now configured to place DTEXT." & vbCrLf & "Select the desired text height button from the CAD Environment toobar to begin DTEXT", , , , , , , True, logName)
            TextOptionsFrm.CheckRules()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_Text", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub Text()

        Try
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If

            TextOptionsFrm.CheckRules()
            RuleAccessors.RecordDglRule("TEXT1", "TEXT")
            Acad_MessageBox("The AutoCAD Environment R20 is now configured to place TEXT." & vbCrLf & "Select the desired text height button from the CAD Environment toobar to begin TEXT", , , , , , , True, logName)
            TextOptionsFrm.CheckRules()
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_MTEXT", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub MTEXT()
        Try



            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() = False Then Exit Sub
            End If
            TextOptionsFrm.CheckRules()
            RuleAccessors.RecordDglRule("TEXT1", "MTEXT")
            Acad_MessageBox("The AutoCAD Environment is now configured to place MTEXT." & vbCrLf & "Select the desired text height button from the CAD Environment toobar to begin MTEXT", , , , , , , True, logName)
            TextOptionsFrm.CheckRules()
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Public Sub TXT()

        Try

            '------------------------------------------------------------------------------------
            ' REMOVE - FOR TESTING ONLY
            'AddWorkvar("TEXTPARAMS", "TEXT;0;Standard;ByLayer;1.8;;FALSE")
            '------------------------------------------------------------------------------------

            Dim rWorkVar As RulesAndWorkvars.WorkVars.WorkVar
            Dim rules As New RulesAndWorkvars.RulesAndWorkVars
            Dim WorkVars As New RulesAndWorkvars.WorkVars

            rWorkVar = WorkVars.ReadWorkvar("TEXTPARAMS")

            If rWorkVar.name <> "" Then

                ' Record current settings
                sPreviousCEColour = AutoCADApp.GetSystemVariable("CECOLOR").ToString
                sPreviousTextStyle = AutoCADApp.GetSystemVariable("TEXTSTYLE").ToString
                sPreviousTextSize = AutoCADApp.GetSystemVariable("TEXTSIZE").ToString
                sPreviousLayer = AutoCADApp.GetSystemVariable("CLAYER").ToString

                ' Get values from rule
                sTextType = Split(rWorkVar.value, ";")(0)
                Dim sCommandToExecute As String

                Dim sTextStyle As String = Split(rWorkVar.value, ";")(2)

                Dim sTextColour As String = Split(rWorkVar.value, ";")(3)
                Dim sTextHeight As String = Split(rWorkVar.value, ";")(4)
                Dim sTextJustification As String = Split(rWorkVar.value, ";")(5)
                Dim sDontPrompt As String = Split(rWorkVar.value, ";")(6)
                Dim sRotationAngle As String = Split(rWorkVar.value, ";")(7)
                Dim sTextlayer As String

                Dim ed As Editor = AutoCADApp.DocumentManager.MdiActiveDocument.Editor

                sTextlayer = Split(rWorkVar.value, ";")(1)

                Dim objReturnInsPoint As PromptPointResult
                Dim sInsertion As String

                ' Important - if the layer is not present or the text style then there is an error here
                ' we are skipping the error because this should have been catered for by the Text.dvb file that calls this.
                ' On Error GoTo 0

                '                On Error Resume Next
                'Application.SetSystemVariable("DIMSTYLE", sTextStyle)
                ' Important - if the layer is not present or the text style then there is an error here
                ' we are skipping the error because this should have been catered for by the Text.dvb file that calls this.
                '                On Error Resume Next

                ''''''-----GAD 
                ' Should we call this here?
                ' ChangeTextSysVars()

                Try
                    AutoCADApp.SetSystemVariable("TEXTSTYLE", sTextStyle.ToString)
                    AutoCADApp.SetSystemVariable("TEXTSIZE", CDbl(sTextHeight))

                    ' ChangeTextSysVars()
                    ' Should we not chnage these?
                    AutoCADApp.SetSystemVariable("CLAYER", sTextlayer)
                    AutoCADApp.SetSystemVariable("CECOLOR", sTextColour)
                Catch ex As System.Exception
                    Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
                End Try

                If UCase(sTextType) = "MTEXT" Then
                    ' If it's MTEXT with no Prompting just run it
                    sCommandToExecute = "(initdia)(command ""._MTEXT"" pause pause)"
                    myCommandStarted = True
                    AutoCADApp.DocumentManager.MdiActiveDocument.SendStringToExecute(sCommandToExecute & vbCr, False, False, False)
                Else
                    ' Its DTEXT or TEXT
                    Dim prPtOpts As New PromptPointOptions(vbLf + "Specify start point of text: ")
                    prPtOpts.AllowNone = True 'Allow ENTER only
                    prPtOpts.AppendKeywordsToMessage = False
                    objReturnInsPoint = ed.GetPoint(prPtOpts)
                    sInsertion = objReturnInsPoint.Value.X & "," & objReturnInsPoint.Value.Y

                    myCommandStarted = True

                    If sTextJustification <> "" Then
                        ' If justfication needs to be nominated...
                        If sDontPrompt.IsTrue Then
                            ' User does not wish to be prompted for rotation
                            If GetCurrentTextStyleHeight() <> 0.0 Then
                                ' Textheight set in style then
                                If GetCurrentTextStyleHeight() <> CDbl(sTextHeight) Then
                                    ' If the text height in the style is different to the button that was pressed display warning message

                                    Acad_MessageBox("You are using a text style with a fixed height of: " & GetCurrentTextStyleHeight() & vbCrLf & _
                                                    "Text will not be inserted at the selected height of: " & sTextHeight & vbCrLf & _
                                                    "Text will be placed in the nominated layer for text of height " & sTextHeight, _
                                                     System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, _
                                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                                End If
                                ' Automatic mode catering for text style with height preset
                                sCommandToExecute = "(command ""._DTEXT"" ""J"" """ & sTextJustification & """ """ & sInsertion & """ """ & sRotationAngle & """ pause)"
                            Else
                                ' Automatic mode catering for text height of 0.0 in text style
                                sCommandToExecute = "(command ""._DTEXT"" ""J"" """ & sTextJustification & """ """ & sInsertion & """ """ & sTextHeight & """ """ & sRotationAngle & """ pause)"
                            End If
                        Else
                            ' If rotation needs to be nominated by user
                            If GetCurrentTextStyleHeight() <> 0.0 Then
                                ' Textheight set in style then
                                If GetCurrentTextStyleHeight() <> CDbl(sTextHeight) Then
                                    ' If the text height in the style is different to the button that was pressed display warning message

                                    Acad_MessageBox("You are using a text style with a fixed height of: " & GetCurrentTextStyleHeight() & vbCrLf & _
                                                    "Text will not be inserted at the selected height of: " & sTextHeight & vbCrLf & _
                                                    "Text will be placed in the nominated layer for text of height " & sTextHeight, _
                                                     System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, _
                                                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                                End If
                                ' User nominates rotation angle catering for text style with height preset
                                sCommandToExecute = "(command ""._DTEXT"" ""J"" """ & sTextJustification & """ """ & sInsertion & """ pause)"
                            Else
                                ' User nominates rotation angle catering for text height of 0.0 in text style
                                sCommandToExecute = "(command ""._DTEXT"" ""J"" """ & sTextJustification & """ """ & sInsertion & """ """ & sTextHeight & """ pause)"
                            End If
                        End If
                        AutoCADApp.DocumentManager.MdiActiveDocument.SendStringToExecute(sCommandToExecute & vbCr, False, False, False)
                    End If
                End If
            Else

                Acad_MessageBox("Error Occurred trying to retrieve workvar TEXTPARAMS from drawing database." & vbCrLf & _
                                "If you are still having issues contact you CAD Support Coordinator", _
                                 System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, _
                                MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

            End If

        Catch ex As System.Exception

            ' revert back to previous layer and color
            AutoCADApp.SetSystemVariable("CLAYER", sPreviousLayer)
            AutoCADApp.SetSystemVariable("CECOLOR", sPreviousCEColour)
            AutoCADApp.SetSystemVariable("TEXTSTYLE", sPreviousTextStyle)
            AutoCADApp.SetSystemVariable("TEXTSIZE", CDbl(sPreviousTextSize))

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Public Function GetCurrentTextStyleHeight() As Double
        Try


            '' Get the current document and database  
            Dim acDoc As Document = AutoCADApp.DocumentManager.MdiActiveDocument
            Dim acCurDb As Database = acDoc.Database
            '' Start a transaction  
            Using acTrans As Transaction = acCurDb.TransactionManager.StartTransaction()
                '' Open the current text style for write      
                Dim acTextStyleTblRec As TextStyleTableRecord
                acTextStyleTblRec = CType(acTrans.GetObject(acCurDb.Textstyle, OpenMode.ForRead), TextStyleTableRecord)
                '' Change the font files used for both Big and Regular fonts      
                GetCurrentTextStyleHeight = acTextStyleTblRec.TextSize
            End Using
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try
    End Function


End Class

