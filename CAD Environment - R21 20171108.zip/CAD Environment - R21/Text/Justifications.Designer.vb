<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class Justifications
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents BL As System.Windows.Forms.CheckBox
	Public WithEvents BC As System.Windows.Forms.CheckBox
	Public WithEvents BR As System.Windows.Forms.CheckBox
	Public WithEvents MC As System.Windows.Forms.CheckBox
	Public WithEvents OK As System.Windows.Forms.Button
	Public WithEvents Cancel As System.Windows.Forms.Button
	Public WithEvents MR As System.Windows.Forms.CheckBox
	Public WithEvents ML As System.Windows.Forms.CheckBox
	Public WithEvents TR As System.Windows.Forms.CheckBox
	Public WithEvents TC As System.Windows.Forms.CheckBox
	Public WithEvents TL As System.Windows.Forms.CheckBox
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents Help_Button As System.Windows.Forms.Button
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Justifications))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BL = New System.Windows.Forms.CheckBox()
        Me.BC = New System.Windows.Forms.CheckBox()
        Me.BR = New System.Windows.Forms.CheckBox()
        Me.MC = New System.Windows.Forms.CheckBox()
        Me.OK = New System.Windows.Forms.Button()
        Me.Cancel = New System.Windows.Forms.Button()
        Me.MR = New System.Windows.Forms.CheckBox()
        Me.ML = New System.Windows.Forms.CheckBox()
        Me.TR = New System.Windows.Forms.CheckBox()
        Me.TC = New System.Windows.Forms.CheckBox()
        Me.TL = New System.Windows.Forms.CheckBox()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'BL
        '
        Me.BL.BackColor = System.Drawing.SystemColors.Control
        Me.BL.Cursor = System.Windows.Forms.Cursors.Default
        Me.BL.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BL.Location = New System.Drawing.Point(96, 117)
        Me.BL.Name = "BL"
        Me.BL.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BL.Size = New System.Drawing.Size(96, 32)
        Me.BL.TabIndex = 0
        Me.BL.Text = "Bottom Left"
        Me.BL.UseVisualStyleBackColor = False
        '
        'BC
        '
        Me.BC.BackColor = System.Drawing.SystemColors.Control
        Me.BC.Cursor = System.Windows.Forms.Cursors.Default
        Me.BC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BC.Location = New System.Drawing.Point(192, 117)
        Me.BC.Name = "BC"
        Me.BC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BC.Size = New System.Drawing.Size(96, 32)
        Me.BC.TabIndex = 1
        Me.BC.Text = "Bottom Centre"
        Me.BC.UseVisualStyleBackColor = False
        '
        'BR
        '
        Me.BR.BackColor = System.Drawing.SystemColors.Control
        Me.BR.Cursor = System.Windows.Forms.Cursors.Default
        Me.BR.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BR.Location = New System.Drawing.Point(288, 117)
        Me.BR.Name = "BR"
        Me.BR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BR.Size = New System.Drawing.Size(96, 32)
        Me.BR.TabIndex = 2
        Me.BR.Text = "Bottom Right"
        Me.BR.UseVisualStyleBackColor = False
        '
        'MC
        '
        Me.MC.BackColor = System.Drawing.SystemColors.Control
        Me.MC.Cursor = System.Windows.Forms.Cursors.Default
        Me.MC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MC.Location = New System.Drawing.Point(192, 93)
        Me.MC.Name = "MC"
        Me.MC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.MC.Size = New System.Drawing.Size(96, 32)
        Me.MC.TabIndex = 3
        Me.MC.Text = "Middle Centre"
        Me.MC.UseVisualStyleBackColor = False
        '
        'OK
        '
        Me.OK.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK.BackColor = System.Drawing.SystemColors.Control
        Me.OK.Cursor = System.Windows.Forms.Cursors.Default
        Me.OK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OK.Location = New System.Drawing.Point(88, 5)
        Me.OK.Name = "OK"
        Me.OK.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OK.Size = New System.Drawing.Size(64, 26)
        Me.OK.TabIndex = 4
        Me.OK.Text = "OK"
        Me.OK.UseVisualStyleBackColor = False
        '
        'Cancel
        '
        Me.Cancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel.Location = New System.Drawing.Point(168, 5)
        Me.Cancel.Name = "Cancel"
        Me.Cancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel.Size = New System.Drawing.Size(64, 26)
        Me.Cancel.TabIndex = 5
        Me.Cancel.Text = "Cancel"
        Me.Cancel.UseVisualStyleBackColor = False
        '
        'MR
        '
        Me.MR.BackColor = System.Drawing.SystemColors.Control
        Me.MR.Cursor = System.Windows.Forms.Cursors.Default
        Me.MR.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MR.Location = New System.Drawing.Point(288, 93)
        Me.MR.Name = "MR"
        Me.MR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.MR.Size = New System.Drawing.Size(96, 32)
        Me.MR.TabIndex = 6
        Me.MR.Text = "Middle Right"
        Me.MR.UseVisualStyleBackColor = False
        '
        'ML
        '
        Me.ML.BackColor = System.Drawing.SystemColors.Control
        Me.ML.Cursor = System.Windows.Forms.Cursors.Default
        Me.ML.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ML.Location = New System.Drawing.Point(96, 93)
        Me.ML.Name = "ML"
        Me.ML.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ML.Size = New System.Drawing.Size(96, 32)
        Me.ML.TabIndex = 7
        Me.ML.Text = "Middle Left"
        Me.ML.UseVisualStyleBackColor = False
        '
        'TR
        '
        Me.TR.BackColor = System.Drawing.SystemColors.Control
        Me.TR.Cursor = System.Windows.Forms.Cursors.Default
        Me.TR.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TR.Location = New System.Drawing.Point(288, 69)
        Me.TR.Name = "TR"
        Me.TR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TR.Size = New System.Drawing.Size(96, 32)
        Me.TR.TabIndex = 8
        Me.TR.Text = "Top Right"
        Me.TR.UseVisualStyleBackColor = False
        '
        'TC
        '
        Me.TC.BackColor = System.Drawing.SystemColors.Control
        Me.TC.Cursor = System.Windows.Forms.Cursors.Default
        Me.TC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TC.Location = New System.Drawing.Point(192, 69)
        Me.TC.Name = "TC"
        Me.TC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TC.Size = New System.Drawing.Size(96, 32)
        Me.TC.TabIndex = 9
        Me.TC.Text = "Top Centre"
        Me.TC.UseVisualStyleBackColor = False
        '
        'TL
        '
        Me.TL.BackColor = System.Drawing.SystemColors.Control
        Me.TL.Cursor = System.Windows.Forms.Cursors.Default
        Me.TL.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TL.Location = New System.Drawing.Point(96, 69)
        Me.TL.Name = "TL"
        Me.TL.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TL.Size = New System.Drawing.Size(96, 32)
        Me.TL.TabIndex = 10
        Me.TL.Text = "Top Left"
        Me.TL.UseVisualStyleBackColor = False
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 11
        Me.LogoPictureBox.TabStop = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.Window
        Me.Label13.Location = New System.Drawing.Point(143, 12)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(233, 35)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Text Justification"
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(8, 5)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(64, 26)
        Me.Help_Button.TabIndex = 13
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.OK, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel, 2, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(213, 165)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(241, 36)
        Me.TableLayoutPanel2.TabIndex = 29
        '
        'Justifications
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(466, 208)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.BL)
        Me.Controls.Add(Me.BC)
        Me.Controls.Add(Me.BR)
        Me.Controls.Add(Me.MC)
        Me.Controls.Add(Me.MR)
        Me.Controls.Add(Me.ML)
        Me.Controls.Add(Me.TR)
        Me.Controls.Add(Me.TC)
        Me.Controls.Add(Me.TL)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.Label13)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(472, 241)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(472, 241)
        Me.Name = "Justifications"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
#End Region 
End Class