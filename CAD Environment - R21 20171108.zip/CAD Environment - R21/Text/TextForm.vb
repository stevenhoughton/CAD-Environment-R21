#Region "Imports"

Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports System.Windows.Forms
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

#End Region

Friend Class TextForm
    Inherits System.Windows.Forms.Form

#Region "Variables"

    Public IsInitialising As Boolean = True

    ' ' Dim RuleAccessors As New RuleAccessors
    Dim sToolPath As String
    ' Dim bInitialize As Boolean = True

#End Region

#Region "Events"

    Private Sub TextHeight_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextHeight.TextChanged

        NewTextSize.Text = CalculateNewTextSize(CDbl(TextHeight.Text)).ToString

    End Sub

    Private Sub TextType_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TextType.TextChanged
        If IsInitialising Then Exit Sub
        Try
            If TextType.Text = "MTEXT" Then
                Justifications.CheckState = CheckState.Unchecked
                Justifications.Enabled = False
                DontPrompt.Enabled = False
                DegreesLabel.Enabled = False
                RotationAngle.Enabled = False
            Else
                Justifications.Enabled = True
                Justifications.CheckState = RuleAccessors.GetruleValue("TEXT26", "False", False, True).ToString.GetCheckState
                DontPrompt.Enabled = True
                DegreesLabel.Enabled = True
                RotationAngle.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub ClientRules_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClientRules.CheckedChanged
        If IsInitialising = True Then Exit Sub
        Try
            'If bInitialize = True Then
            '    bInitialize = False
            'Else
            'MsgBox(ClientRules.ToString.IsTrue)

            WorkingVariableAccessors.AddWorkVar("TEXTClientConfig", ClientRules.CheckState.ToString.IsTrue)
            CheckRules(ClientRules.CheckState.ToString.IsTrue)

            If ClientRules.CheckState.ToString.IsTrue Then


                RemoveTextOverrides()

            End If
            '   End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Sub RemoveTextOverrides()

        Dim Tool As String = String.Empty
        Tool = "TEXT"
        For i As Integer = 0 To 100
            If RuleAccessors.HasRule(Tool) Then
                RuleAccessors.RemoveRule(Tool)
            End If
            If RuleAccessors.HasRule(Tool & i) Then
                RuleAccessors.RemoveRule(Tool & i)
            End If
            If RuleAccessors.HasRule(Tool & i & "-DlgBox") Then
                RuleAccessors.RemoveRule(Tool & i & "-DlgBox")
            End If
        Next

    End Sub
#End Region

#Region "StartHere"

    Private Sub TextOptions_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            IsInitialising = True

            '            Dim sScale As String

            sToolPath = Settings.Manager.AE.Path

            '  bInitialize = True

            ' Check rules Ignoring any overrides if use client config is checked
            CheckRules(WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "True").ToString.IsTrue)

            ' bInitialize = False

            ChangeSysvars_Change()
            ChangeSysvarsVP_Change()

            CurrentTEXTSIZE.Text = ThisDrawingUtilities.GetVariable("TEXTSIZE").ToString

            IsInitialising = False
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

#End Region

#Region "Helpers"

    Private Sub ChangeSysvars_Change()

        Try

            If ChangeSysVars.CheckState = CheckState.Checked And ChangeSysVarsVP.CheckState = CheckState.Unchecked Then
                DontAskAgain.Enabled = False
                DontAskAgain.CheckState = CheckState.Checked
            Else
                DontAskAgain.Enabled = True
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub ChangeSysvarsVP_Change()
        Try
            If ChangeSysVars.CheckState = CheckState.Checked And ChangeSysVarsVP.CheckState = CheckState.Unchecked Then
                DontAskAgain.Enabled = False
                DontAskAgain.CheckState = CheckState.Checked
            Else
                DontAskAgain.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Public Sub CheckRules(Optional ByRef bIgnoreOverrides As Boolean = False)
        Try

            Dim sWhatToUse As String
            Dim sWhatToShow As String

            If RuleAccessors.GetruleValue("TEXT0", "True").ToString.IsTrue Then
                ' Allow uses to select if they want to use rules or not - since they are present and set the tickbox to what it was if it has bee used before
                ClientRules.Enabled = True
                ' If this is the first time the tool is run in this drawing set it to use rules
                ClientRules.CheckState = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "True").ToString.GetCheckState
            Else
                ' Allow uses to select if they want to use rules or not - since they are present and set the tickbox to what it was if it has bee used before
                ClientRules.Enabled = False
                ' If this is the first time the tool is run in this drawing set it to use rules
                ClientRules.CheckState = CheckState.Checked
            End If

            If ClientRules.CheckState = CheckState.Checked Then

                ' Check to see if the rules are already recorded in this drawing - if so don't initialize.
                '          InitializeRules("[TEXT]", True, True, False)

                Dim SearchForContent As Boolean = True
                If IsMasterFile() = True Then
                    SearchForContent = False
                End If

                'If IsThisAnOldConfigName() = True Then
                '    InitializeRules("[TEXT]", True, SearchForContent, False)
                'Else
                InitializeRulesNew("[TEXT]", True, SearchForContent, False)
                'End If


                TxtLay18.Enabled = False
                TxtCol18.Enabled = False
                TxtSty18.Enabled = False
                TxtRot18.Enabled = False
                TxtJust18.Enabled = False
                Txt18Ask.Enabled = False
                TxtStyElipsis18.Enabled = False

                TxtLay25.Enabled = False
                TxtCol25.Enabled = False
                TxtSty25.Enabled = False
                TxtRot25.Enabled = False
                TxtJust25.Enabled = False
                Txt25Ask.Enabled = False
                TxtStyElipsis25.Enabled = False

                TxtLay35.Enabled = False
                TxtCol35.Enabled = False
                TxtSty35.Enabled = False
                TxtRot35.Enabled = False
                TxtJust35.Enabled = False
                Txt35Ask.Enabled = False
                TxtStyElipsis35.Enabled = False

                TxtLay50.Enabled = False
                TxtCol50.Enabled = False
                TxtSty50.Enabled = False
                TxtRot50.Enabled = False
                TxtJust50.Enabled = False
                Txt50Ask.Enabled = False
                TxtStyElipsis50.Enabled = False

                TxtLay70.Enabled = False
                TxtCol70.Enabled = False
                TxtSty70.Enabled = False
                TxtRot70.Enabled = False
                TxtJust70.Enabled = False
                Txt70Ask.Enabled = False
                TxtStyElipsis70.Enabled = False

                col18.Enabled = False
                col25.Enabled = False
                col35.Enabled = False
                col50.Enabled = False
                col70.Enabled = False

                '        DontPrompt.Enabled = False
                '        DegreesLabel.Enabled = False

                ChangeSysVars.Enabled = False
                ChangeSysVarsVP.Enabled = False

                sWhatToUse = "UseFirstRule"
                sWhatToShow = "AllAvailable"

            Else

                TxtLay18.Enabled = True
                TxtCol18.Enabled = True
                TxtSty18.Enabled = True
                TxtRot18.Enabled = True
                TxtJust18.Enabled = True
                Txt18Ask.Enabled = True
                TxtStyElipsis18.Enabled = True

                TxtLay25.Enabled = True
                TxtCol25.Enabled = True
                TxtSty25.Enabled = True
                TxtRot25.Enabled = True
                TxtJust25.Enabled = True
                Txt25Ask.Enabled = True
                TxtStyElipsis25.Enabled = True

                TxtLay35.Enabled = True
                TxtCol35.Enabled = True
                TxtSty35.Enabled = True
                TxtRot35.Enabled = True
                TxtJust35.Enabled = True
                Txt35Ask.Enabled = True
                TxtStyElipsis35.Enabled = True

                TxtLay50.Enabled = True
                TxtCol50.Enabled = True
                TxtSty50.Enabled = True
                TxtRot50.Enabled = True
                TxtJust50.Enabled = True
                Txt50Ask.Enabled = True
                TxtStyElipsis50.Enabled = True

                TxtLay70.Enabled = True
                TxtCol70.Enabled = True
                TxtSty70.Enabled = True
                TxtRot70.Enabled = True
                TxtJust70.Enabled = True
                Txt70Ask.Enabled = True
                TxtStyElipsis70.Enabled = True

                col18.Enabled = True
                col25.Enabled = True
                col35.Enabled = True
                col50.Enabled = True
                col70.Enabled = True

                '        DontPrompt.Enabled = True
                '        DegreesLabel.Enabled = True

                ChangeSysVars.Enabled = True
                ChangeSysVarsVP.Enabled = True

                sWhatToUse = "UsePrevious"
                sWhatToShow = "AllAvailable"

            End If

            '--------------------------------------------------------------------------------------------------------------------------------------------------
            ' The next two rules should be set initally by the tool rules in the DWT file but overwritten by user without changing ClientConfig check box
            ' These are special cases as users can override them at runtime - either via the DT or MT buttons or via the dialog box itself to set heights and
            ' Text justification
            '--------------------------------------------------------------------------------------------------------------------------------------------------

            ' TEXT1 Rule ' Select what type of text to insert by default DTEXT or TEXT or MTEXT
            PopulateComboBox(TextType, "TEXT1", sWhatToShow, sWhatToUse, "TEXTTYPES", RuleAccessors.GetruleValue("TEXT1", , False), False) 'bIgnoreOverrides
            TextType.Sorted = True

            ' TEXT2 Rule default Text Height
            PopulateTextBox(TextHeight, "TEXT2", RuleAccessors.GetruleValue("TEXT2", , False), , False, False) ' bIgnoreOverrides

            ' TEXT26 Rule ' ask user if they wish to set a justification
            PopulateCheckBox(Justifications, "TEXT26", RuleAccessors.GetruleValue("TEXT26", , False), , False, False) 'bIgnoreOverrides

            ' TEXT28 Rule ' Rotation angle
            PopulateTextBox(RotationAngle, "TEXT28", RuleAccessors.GetruleValue("TEXT28", , False), , False, False) 'bIgnoreOverrides

            ' TEXT24 Rule ' Don't prompt for text height and rotation
            PopulateCheckBox(DontPrompt, "TEXT24", RuleAccessors.GetruleValue("TEXT24", , False), , False, False) ' bIgnoreOverrides

            '--------------------------------------------------------------------------------------------------------------------------------------------------

            ' TEXT3 Rule ' Text layer for 18 unit high text
            PopulateComboBox(TxtLay18, "TEXT3", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            ' TEXT4 Rule ' Text style for 18 unit high text
            PopulateComboBox(TxtSty18, "TEXT4", sWhatToShow, sWhatToUse, "TEXTSTYLE", ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            ' TEXT5 Rule ' Text colour for 18 unit high text
            PopulateComboBox(TxtCol18, "TEXT5", sWhatToShow, sWhatToUse, "CECOLOR", ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            ' TEXT6 Rule
            PopulateComboBox(TxtJust18, "TEXT6", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)
            ' TEXT7 Rule ' Text layer for 25 unit high text
            PopulateComboBox(TxtLay25, "TEXT7", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            ' TEXT8 Rule ' Text style for 18 unit high text
            PopulateComboBox(TxtSty25, "TEXT8", sWhatToShow, sWhatToUse, "TEXTSTYLE", ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            ' TEXT9 Rule ' Text colour for 18 unit high text
            PopulateComboBox(TxtCol25, "TEXT9", sWhatToShow, sWhatToUse, "CECOLOR", ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            ' TEXT10 Rule
            PopulateComboBox(TxtJust25, "TEXT10", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)

            ' TEXT11 Rule ' Text layer for 35 unit high text
            PopulateComboBox(TxtLay35, "TEXT11", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            ' TEXT12 Rule ' Text style for 18 unit high text
            PopulateComboBox(TxtSty35, "TEXT12", sWhatToShow, sWhatToUse, "TEXTSTYLE", ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            ' TEXT13 Rule ' Text colour for 18 unit high text
            PopulateComboBox(TxtCol35, "TEXT13", sWhatToShow, sWhatToUse, "CECOLOR", ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            ' TEXT14 Rule
            PopulateComboBox(TxtJust35, "TEXT14", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)

            ' TEXT15 Rule ' Text layer for 50 unit high text
            PopulateComboBox(TxtLay50, "TEXT15", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            ' TEXT16 Rule ' Text style for 18 unit high text
            PopulateComboBox(TxtSty50, "TEXT16", sWhatToShow, sWhatToUse, "TEXTSTYLE", ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            ' TEXT17 Rule ' Text colour for 18 unit high text
            PopulateComboBox(TxtCol50, "TEXT17", sWhatToShow, sWhatToUse, "CECOLOR", ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            ' TEXT18 Rule
            PopulateComboBox(TxtJust50, "TEXT18", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)

            ' TEXT19 Rule ' Text layer for 70 unit high text
            PopulateComboBox(TxtLay70, "TEXT19", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            ' TEXT20 Rule ' Text style for 70 unit high text
            PopulateComboBox(TxtSty70, "TEXT20", sWhatToShow, sWhatToUse, "TEXTSTYLE", ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            ' TEXT21 Rule ' Text colour for 70 unit high text
            PopulateComboBox(TxtCol70, "TEXT21", sWhatToShow, sWhatToUse, "CECOLOR", ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            ' TEXT22 Rule ' Text colour for 70 unit high text
            PopulateComboBox(TxtJust70, "TEXT22", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)

            ' TEXT23 Rule ChangeSYSVars
            PopulateCheckBox(ChangeSysVars, "TEXT23", "True", , , bIgnoreOverrides)

            ' TEXT27 Rule ChangeSYSVarsVP
            PopulateCheckBox(ChangeSysVarsVP, "TEXT27", "False", , , bIgnoreOverrides)

            ' TEXT25 Rule Don't show this dialog again
            PopulateCheckBox(DontAskAgain, "TEXT25", "True", , , bIgnoreOverrides)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

#End Region

#Region "Buttons"

    Private Sub Help_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub OK_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OK_Button.Click
        Try
            ' These two rules are set as defaults by rules but not enforced all the time
            RuleAccessors.RecordDglRule("TEXT1", TextType.Text)
            RuleAccessors.RecordDglRule("TEXT2", Val(TextHeight.Text))

            If DontAskAgain.CheckState = CheckState.Checked Then
                RuleAccessors.RecordDglRule("TEXT25", True)
            Else
                RuleAccessors.RecordDglRule("TEXT25", False)
            End If

            If Justifications.CheckState = CheckState.Checked Then
                RuleAccessors.RecordDglRule("TEXT26", True)
            Else
                RuleAccessors.RecordDglRule("TEXT26", False)
            End If

            RuleAccessors.RecordDglRule("TEXT28", RotationAngle.Text)

            If DontPrompt.CheckState = CheckState.Checked Then
                RuleAccessors.RecordDglRule("TEXT24", True)
            Else
                RuleAccessors.RecordDglRule("TEXT24", False)
            End If

            If ClientRules.Checked = False Then

                RuleAccessors.RecordDglRule("TEXT3", TxtLay18.Text)
                RuleAccessors.RecordDglRule("TEXT4", TxtSty18.Text)
                RuleAccessors.RecordDglRule("TEXT5", TxtCol18.Text)
                RuleAccessors.RecordDglRule("TEXT6", TxtJust18.Text)

                RuleAccessors.RecordDglRule("TEXT7", TxtLay25.Text)
                RuleAccessors.RecordDglRule("TEXT8", TxtSty25.Text)
                RuleAccessors.RecordDglRule("TEXT9", TxtCol25.Text)
                RuleAccessors.RecordDglRule("TEXT10", TxtJust25.Text)

                RuleAccessors.RecordDglRule("TEXT11", TxtLay35.Text)
                RuleAccessors.RecordDglRule("TEXT12", TxtSty35.Text)
                RuleAccessors.RecordDglRule("TEXT13", TxtCol35.Text)
                RuleAccessors.RecordDglRule("TEXT14", TxtJust35.Text)

                RuleAccessors.RecordDglRule("TEXT15", TxtLay50.Text)
                RuleAccessors.RecordDglRule("TEXT16", TxtSty50.Text)
                RuleAccessors.RecordDglRule("TEXT17", TxtCol50.Text)
                RuleAccessors.RecordDglRule("TEXT18", TxtJust50.Text)

                RuleAccessors.RecordDglRule("TEXT19", TxtLay70.Text)
                RuleAccessors.RecordDglRule("TEXT20", TxtSty70.Text)
                RuleAccessors.RecordDglRule("TEXT21", TxtCol70.Text)
                RuleAccessors.RecordDglRule("TEXT22", TxtJust70.Text)

                RuleAccessors.RecordDglRule("TEXT23", ChangeSysVars.Checked)
                RuleAccessors.RecordDglRule("TEXT27", ChangeSysVarsVP.Checked)

                'If ChangeSysVars.CheckState = CheckState.Checked Then
                '    RuleAccessors.RecordDglRule("TEXT23", True)
                'Else
                '    RuleAccessors.RecordDglRule("TEXT23", False)
                'End If

                'If ChangeSysVarsVP.CheckState = CheckState.Checked Then
                '    RuleAccessors.RecordDglRule("TEXT27", True)
                'Else
                '    RuleAccessors.RecordDglRule("TEXT27", False)
                'End If
            End If

            ChangeTextSysVars()

            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub Cancel_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub col18_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles col18.Click
        Try
            Dim sCol As String
            sCol = getcolor()
            If sCol = "256" Then
                sCol = "ByLayer"
            Else
                If sCol = "0" Then
                    sCol = "ByBlock"
                End If
            End If
            TxtCol18.Text = sCol
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub col25_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles col25.Click
        Try
            Dim sCol As String
            sCol = getcolor()
            If sCol = "256" Then
                sCol = "ByLayer"
            Else
                If sCol = "0" Then
                    sCol = "ByBlock"
                End If
            End If
            TxtCol25.Text = sCol
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub col35_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles col35.Click
        Try
            Dim sCol As String
            sCol = getcolor()
            If sCol = "256" Then
                sCol = "ByLayer"
            Else
                If sCol = "0" Then
                    sCol = "ByBlock"
                End If
            End If
            TxtCol35.Text = sCol
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub col50_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles col50.Click
        Try
            Dim sCol As String
            sCol = getcolor()
            If sCol = "256" Then
                sCol = "ByLayer"
            Else
                If sCol = "0" Then
                    sCol = "ByBlock"
                End If
            End If
            TxtCol50.Text = sCol
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub col70_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles col70.Click
        Try
            Dim sCol As String
            sCol = getcolor()
            If sCol = "256" Then
                sCol = "ByLayer"
            Else
                If sCol = "0" Then
                    sCol = "ByBlock"
                End If
            End If
            TxtCol70.Text = sCol
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

#End Region

    Private Sub Text_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

End Class