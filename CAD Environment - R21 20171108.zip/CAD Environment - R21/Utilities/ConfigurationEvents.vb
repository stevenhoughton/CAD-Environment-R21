﻿
Public Module ConfigurationEvents

    ''' <summary>
    ''' Our system has been configured
    ''' </summary>
    ''' <remarks></remarks>
    Public Event Configured()

    ''' <summary>
    ''' Notify subscribers of the AE configured event
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub RaiseConfiguredEvent()

        '' notify
        RaiseEvent Configured()

    End Sub

End Module
