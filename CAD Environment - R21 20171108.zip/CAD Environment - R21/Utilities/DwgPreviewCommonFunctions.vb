﻿Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.Geometry
Imports Jacobs.AutoCAD.Utilities.DwgView

Public Module DwgPreviewCommonFunctions

    Public Sub InitaliseDwgViewControl(ByRef DwgViewControl As DwgPreviewControl, _
                                       ByVal DrawingFileName As String, ByVal AllowOrbit As Boolean, _
                                       ByVal AllowPanning As Boolean, Optional ByVal BlockToZoom As String = "")

        DwgViewControl.mbOrbiting = AllowOrbit
        DwgViewControl.mbPanning = AllowPanning

        If Not DwgViewControl.mpView Is Nothing Then
            ' clear the preview control
            DwgViewControl.mpView.EraseAll()
        End If

        ' create a new database
        Dim dwgs As Database = New Database(False, True)

        ' now read it in
        dwgs.ReadDwgFile(DrawingFileName, FileOpenMode.OpenForReadAndReadShare, True, "")

        If BlockToZoom = "" Then
            'Just Zooms to File Extents
            InitDrawingControl(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument, dwgs, DwgViewControl)
        Else
            'Just Zooms to block Extents
            InitDrawingControl(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument, dwgs, BlockToZoom, DwgViewControl)
        End If

        DwgViewControl.mpView.Zoom(0.9)

        dwgs = Nothing

    End Sub

    Private Sub InitDrawingControl(ByVal doc As Document, ByVal db As Database, _
                                   ByRef DwgViewControl As DwgPreviewControl, _
                                           Optional ByVal AllowOrbiting As Boolean = False)

        DwgViewControl.mbOrbiting = AllowOrbiting

        ' initialize the control
        DwgViewControl.Init(doc, db)

        ' now find out what the current view is and set the GsPreviewCtrl to the same
        SetViewTo(DwgViewControl.mpView, db, DwgViewControl)

        Using doc.LockDocument

            Using trans As Transaction = db.TransactionManager.StartTransaction

                Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead, False), BlockTable)
                'Dim Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)

                ' now add the current space to the GsView
                Using Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)
                    DwgViewControl.mpView.Add(Spacebtr, DwgViewControl.mpModel)
                    DwgViewControl.mpView.Zoom(0.9)
                End Using

            End Using

        End Using

        refreshView(DwgViewControl)

        '' set the view style to basic
        'ChangeViewStyleTo(VisualStyleType.Basic)

        '' set the render mode to basic
        'ChangeRenderModeTo(Autodesk.AutoCAD.GraphicsSystem.RenderMode.Wireframe)

    End Sub

    Private Sub InitDrawingControl(ByVal doc As Document, ByVal db As Database, _
                                           ByVal BlockName As String, ByRef DwgViewControl As DwgPreviewControl, _
                                           Optional ByVal AllowOrbiting As Boolean = False)

        DwgViewControl.mbOrbiting = AllowOrbiting

        ' initialize the control
        DwgViewControl.Init(doc, db)

        ' now find out what the current view is and set the GsPreviewCtrl to the same
        SetViewTo(DwgViewControl.mpView, BlockName, db, DwgViewControl)

        Using doc.LockDocument

            Using trans As Transaction = db.TransactionManager.StartTransaction

                Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead, False), BlockTable)
                'Dim Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)

                ' now add the current space to the GsView
                Using Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)
                    DwgViewControl.mpView.Add(Spacebtr, DwgViewControl.mpModel)
                End Using

            End Using

        End Using

        refreshView(DwgViewControl)

        '' set the view style to basic
        'ChangeViewStyleTo(VisualStyleType.Basic)

        '' set the render mode to basic
        'ChangeRenderModeTo(Autodesk.AutoCAD.GraphicsSystem.RenderMode.Wireframe)

    End Sub

    ' sets a GsView to the active viewport data held by the database
    Private Sub SetViewTo(ByVal view As Autodesk.AutoCAD.GraphicsSystem.View, ByVal Blockname As String, ByVal db As Database, _
                               ByRef DwgViewControl As DwgPreviewControl)

        '' just check we have valid extents
        'If db.Extmax.X < db.Extmin.X OrElse db.Extmax.Y < db.Extmin.Y OrElse db.Extmax.Z < db.Extmax.Z Then
        '    db.Extmin = New Point3d(0, 0, 0)
        '    db.Extmax = New Point3d(400, 400, 400)
        'End If

        Dim Trx As Transaction = db.TransactionManager.StartTransaction

        Dim myBT As BlockTable
        Dim myBTR As BlockTableRecord = Nothing
        Dim wcsExtents As New Extents3d

        myBT = CType(Trx.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

        If myBT.Has(Blockname) Then

            myBTR = TryCast(Trx.GetObject(myBT(Blockname), OpenMode.ForRead, False), BlockTableRecord)

            Dim Col As ObjectIdCollection = myBTR.GetBlockReferenceIds(True, False)
            If Col.Count > 0 Then
                Dim Bref As BlockReference = TryCast(Trx.GetObject(Col.Item(0), OpenMode.ForRead), BlockReference)
                wcsExtents = Bref.GeometricExtents
            End If

        End If

        Trx.Commit()

        ' get the dwg extents
        Dim extMax As Point3d = wcsExtents.MaxPoint
        Dim extMin As Point3d = wcsExtents.MinPoint

        ' now the active viewport info
        Dim height As Double = 0.0, width As Double = 0.0, viewTwist As Double = 0.0
        Dim targetView As New Point3d()
        Dim viewDir As New Vector3d()
        GSUtil.GetActiveViewPortInfo(height, width, targetView, viewDir, viewTwist, True)

        ' from the data returned let's work out the viewmatrix
        viewDir = viewDir.GetNormal()
        Dim viewXDir As Vector3d = viewDir.GetPerpendicularVector().GetNormal()
        viewXDir = viewXDir.RotateBy(viewTwist, -viewDir)
        Dim viewYDir As Vector3d = viewDir.CrossProduct(viewXDir)
        Dim boxCenter As Point3d = extMin + 0.5 * (extMax - extMin)
        Dim viewMat As Matrix3d
        viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis, boxCenter, viewXDir, _
         viewYDir, viewDir).Inverse()

        'Dim wcsExtents As New Extents3d(extMin, extMax)
        'Dim viewExtents As Extents3d = wcsExtents
        'viewExtents.TransformBy(viewMat)

        Dim viewExtents As Extents3d = wcsExtents
        viewExtents.TransformBy(viewMat)
        Dim xMax As Double = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X)
        Dim yMax As Double = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y)
        Dim eye As Point3d = boxCenter + viewDir
        ' finally set the Gs view to the dwg view
        view.SetView(eye, boxCenter, viewYDir, xMax, yMax)

        ' now update
        refreshView(DwgViewControl)

    End Sub

    ' sets a GsView to the active viewport data held by the database
    Private Sub SetViewTo(ByVal view As Autodesk.AutoCAD.GraphicsSystem.View, ByVal db As Database, _
                               ByRef DwgViewControl As DwgPreviewControl)

        ' just check we have valid extents
        ''If db.Extmax.X < db.Extmin.X OrElse db.Extmax.Y < db.Extmin.Y OrElse db.Extmax.Z < db.Extmax.Z Then
        ''    db.Extmin = New Point3d(0, 0, 0)
        ''    db.Extmax = New Point3d(400, 400, 400)
        ''End If

        ' get the dwg extents
        Dim extMax As Point3d = db.Extmax
        Dim extMin As Point3d = db.Extmin

        ' now the active viewport info
        Dim height As Double = 0.0, width As Double = 0.0, viewTwist As Double = 0.0
        Dim targetView As New Point3d()
        Dim viewDir As New Vector3d()

        GSUtil.GetActiveViewPortInfo(height, width, targetView, viewDir, viewTwist, True)

        ' from the data returned let's work out the viewmatrix
        viewDir = viewDir.GetNormal()
        Dim viewXDir As Vector3d = viewDir.GetPerpendicularVector().GetNormal()
        viewXDir = viewXDir.RotateBy(viewTwist, -viewDir)
        Dim viewYDir As Vector3d = viewDir.CrossProduct(viewXDir)
        Dim boxCenter As Point3d = extMin + 0.5 * (extMax - extMin)

        Dim viewMat As Matrix3d
        viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis, boxCenter, viewXDir, _
         viewYDir, viewDir).Inverse()

        'Dim wcsExtents As New Extents3d(extMin, extMax)

        Dim wcsExtents As Extents3d

        If (extMax.X < extMin.X) Or (extMax.Y < extMin.Y) Then
            wcsExtents = New Extents3d(extMax, extMin)
        Else
            wcsExtents = New Extents3d(extMin, extMax)
        End If

        Dim viewExtents As Extents3d = wcsExtents
        viewExtents.TransformBy(viewMat)

        Dim xMax As Double = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X)
        Dim yMax As Double = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y)
        Dim eye As Point3d = boxCenter + viewDir

        ' finally set the Gs view to the dwg view
        view.SetView(eye, boxCenter, viewYDir, xMax, yMax)

        ' now update
        refreshView(DwgViewControl)

    End Sub

    Private Sub refreshView(ByRef DwgViewControl As DwgPreviewControl)
        If Not IsDesignMode Then
            DwgViewControl.mpView.Invalidate()
            DwgViewControl.mpView.Update()
        End If
    End Sub

    Public ReadOnly Property IsDesignMode() As Boolean
        Get
            Return DwgPreviewControl.IsDesignMode
        End Get
    End Property

End Module
