﻿Imports Autodesk.AutoCAD.Colors
Imports Autodesk.AutoCAD.GraphicsInterface
Imports Autodesk.AutoCAD.DatabaseServices

Public Class clsLayerDetails

    Private mLayerName As String

    'Data Storage
    Private mIsPlotable As Boolean = False
    Private mIsFrozen As Boolean = False
    Private mIsOff As Boolean = False
    Private mIsLocked As Boolean = False
    Private mColor As Color
    Private mLineWeight As LineWeight
    Private mLineType As ObjectId
    Private mLineTypeName As String
    Private mLineTypeTableID As ObjectId

    'Trigger for the 2 Variables Below
    Private mLayerFound As Boolean = False
    Private mCreateIfMissing As Boolean = True
    Private mDeleteIfNotInCurrent As Boolean = True

    'Enabling the Layer Change
    Private mEnabledOnOff As Boolean = True
    Private mEnabledFrozen As Boolean = True
    Private mEnabledPlot As Boolean = True
    Private mEnabledLock As Boolean = True
    Private mEnabledColor As Boolean = False
    Private mEnabledLineType As Boolean = False
    Private mEnabledLineWeight As Boolean = False

    Public Sub New(ByVal LayerNameIni As String)
        LayerName = LayerNameIni
    End Sub

    Public Property LayerName() As String
        Get
            Return mLayerName
        End Get
        Set(ByVal value As String)
            mLayerName = value
        End Set
    End Property

    Public Property DeleteIfNotInCurrent() As Boolean
        Get
            Return mDeleteIfNotInCurrent
        End Get
        Set(ByVal value As Boolean)
            mDeleteIfNotInCurrent = value
        End Set
    End Property

    Public Property CreateIfMissing() As Boolean
        Get
            Return mCreateIfMissing
        End Get
        Set(ByVal value As Boolean)
            mCreateIfMissing = value
        End Set
    End Property

    Public Property LayerFound_Res() As Boolean
        Get
            Return mLayerFound
        End Get
        Set(ByVal value As Boolean)
            mLayerFound = value
        End Set
    End Property

    Public Property eOnOff() As Boolean
        Get
            Return mEnabledOnOff
        End Get
        Set(value As Boolean)
            mEnabledOnOff = value
        End Set
    End Property

    Public Property IsOff() As Boolean
        Get
            Return mIsOff
        End Get
        Set(ByVal value As Boolean)
            mIsOff = value
        End Set
    End Property

    Public Property eFreeze() As Boolean
        Get
            Return mEnabledFrozen
        End Get
        Set(value As Boolean)
            mEnabledFrozen = value
        End Set
    End Property

    Public Property IsFrozen() As Boolean
        Get
            Return mIsFrozen
        End Get
        Set(ByVal value As Boolean)
            mIsFrozen = value
        End Set
    End Property

    Public Property ePlot() As Boolean
        Get
            Return mEnabledPlot
        End Get
        Set(value As Boolean)
            mEnabledPlot = value
        End Set
    End Property

    Public Property IsPlotAble() As Boolean
        Get
            Return mIsPlotable
        End Get
        Set(ByVal value As Boolean)
            mIsPlotable = value
        End Set
    End Property

    Public Property eLock() As Boolean
        Get
            Return mEnabledLock
        End Get
        Set(value As Boolean)
            mEnabledLock = value
        End Set
    End Property

    Public Property IsLocked() As Boolean
        Get
            Return mIsLocked
        End Get
        Set(ByVal value As Boolean)
            mIsLocked = value
        End Set
    End Property

    Public Property eLColor() As Boolean
        Get
            Return mEnabledColor
        End Get
        Set(value As Boolean)
            mEnabledColor = value
        End Set
    End Property

    Public Property SetLColor() As Color
        Get
            Return mColor
        End Get
        Set(ByVal value As Color)
            mColor = value
        End Set
    End Property

    Public Property eLLineType() As Boolean
        Get
            Return mEnabledLineType
        End Get
        Set(value As Boolean)
            mEnabledLineType = value
        End Set
    End Property

    Public Property SetLLineType() As ObjectId
        Get
            Return mLineType
        End Get
        Set(ByVal value As ObjectId)
            mLineType = value
        End Set
    End Property

    Public Property SetLLineTypeName() As String
        Get
            Return mLineTypeName
        End Get
        Set(ByVal value As String)
            mLineTypeName = value
        End Set
    End Property
    Public Property SetLLineTypeTableID() As ObjectId
        Get
            Return mLineTypeTableID
        End Get
        Set(ByVal value As ObjectId)
            mLineTypeTableID = value
        End Set
    End Property

    Public Property eLLineWeight() As Boolean
        Get
            Return mEnabledLineWeight
        End Get
        Set(value As Boolean)
            mEnabledLineWeight = value
        End Set
    End Property

    Public Property SetLLineWeight() As LineWeight
        Get
            Return mLineWeight
        End Get
        Set(ByVal value As LineWeight)
            mLineWeight = value
        End Set
    End Property
End Class
