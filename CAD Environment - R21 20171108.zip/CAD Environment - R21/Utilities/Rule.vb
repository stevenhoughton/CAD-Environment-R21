Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension

Public Class Rule

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Public ReadOnly Property ThisDrawing() As AcadDocument
        Get
            Return CType(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)
        End Get
    End Property

    ' constant for dictionary name on the symbol tables
    Private Const RULES As String = "SKM_RULES"

    Private m_sRuleID As String
    Private m_sDescription As String
    Private m_sValue As String
    Private m_iTableCode As Integer
    Private m_iDlgCode As Integer

    ' property to set the ruleid...this can only be done
    ' once, then it is read only


    ' property to get the RuleID

    Public Property RuleID() As String
        Get

            RuleID = m_sRuleID

        End Get
        Set(ByVal Value As String)

            If m_sRuleID = "" Then
                m_sRuleID = Value
            End If

        End Set
    End Property

    ' property to set the description...as above, this
    ' can only be done once, then it is read only


    ' property to get the description of the this rule

    Public Property Description() As String
        Get

            Description = m_sDescription

        End Get
        Set(ByVal Value As String)

            If m_sDescription = "" Then
                m_sDescription = Value
            End If

        End Set
    End Property

    ' property to set the value for the rule...as above
    ' witable until set once, then read only


    ' property to get the value for this rule

    Public Property value() As String
        Get

            value = m_sValue

        End Get
        Set(ByVal Value As String)

            If m_sValue = "" Then
                m_sValue = Value
            End If

        End Set
    End Property

    ' property to set the DXF code integer used to identify
    ' the type of value used in this rule


    Public Property TableCode() As Integer
        Get

            TableCode = m_iTableCode

        End Get
        Set(ByVal Value As Integer)

            If m_iTableCode = -1 Then
                m_iTableCode = Value
            End If

        End Set
    End Property


    Public Property DlgCode() As Integer
        Get

            DlgCode = m_iDlgCode

        End Get
        Set(ByVal Value As Integer)

            If m_iDlgCode = -1 Then
                m_iDlgCode = Value
            End If

        End Set
    End Property

    Public Function Save() As Boolean

        Try

            Dim pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary = Nothing
            Dim pXDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
            Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
            Dim iXrecDataType(3) As Int16
            Dim vXrecDataValue(3) As Object

            ' get a pointer to the extension dictionary...
            pXDict = ThisDrawing.Blocks.GetExtensionDictionary

            Try

                pDict = CType(pXDict.GetObject(RULES), AcadDictionary)

            Catch ex As Exception
                If ex.Message.ToUpper.Contains("Key not found".ToUpper) Then
                    ' Ignore the error and continue
                Else
                    Return False
                    Exit Function
                End If
            End Try

            ' check if we got it...
            If pDict Is Nothing Then
                '...not there, so add it in...
                ' Try
                pDict = CType(pXDict.AddObject(RULES, "AcDbDictionary"), AcadDictionary)
                ' Issues about AcDbDictionary not registered when executing the line above in AutoCAD 2017 can be solved by adding 
                ' the following registry keys This worked for Map and Civil 3d 2017 versions

                ' Windows Registry Editor Version 5.00
                ' [HKEY_LOCAL_MACHINE\SOFTWARE\Autodesk\ObjectDBX\R17.1\ActiveXCLSID]
                ' "AcDbSortentsTable"="{048ED0E0-12CF-4C0F-9FFA-947C2FBE8C8E}"
                ' "AcDbDictionary"="{E70DE962-842A-4488-9481-1D0FD72A020F}"
                ' "AcDbTableStyle"="{72EFC580-D085-4B81-8C55-26A79E445338}"
                ' "AcDbMLeaderStyle"="{F3C3049A-AADC-4F4E-B35E-B15AA27DA2E7}"



                ' In windows 7 64bit they ended up under the WOW key and don't work in that folder 
                ' so I created them here - these work for AutoCAD 2012 but not Map 2012 (haven't tried civil 3d 2012 yet)

                ' Windows Registry Editor Version 5.00
                ' [HKEY_LOCAL_MACHINE\SOFTWARE\Autodesk\ObjectDBX\R18.2\ActiveXCLSID]
                ' "AcDbSortentsTable"="{A89FFC20-CAE1-4FFF-96A4-2422B305B57B}"
                ' "AcDbTableStyle"="{F4C9A261-DD69-45E5-BA9C-B70BD8B9E770}"
                ' "AcDbMLeaderStyle"="{99211C95-3862-4E7C-8770-35C68CA1944B}"
                ' "AcDbDictionary"="{3CC77F29-1CFD-4754-8408-F3E947391238}"

                ''---------------------------------------------------------------
                '' AcadDictionary
                ''---------------------------------------------------------------
                ' Windows Registry Editor Version 5.00

                '[HKEY_CLASSES_ROOT\CLSID\{3CC77F29-1CFD-4754-8408-F3E947391238}]
                '@="AcadDictionary"

                '[HKEY_CLASSES_ROOT\CLSID\{3CC77F29-1CFD-4754-8408-F3E947391238}\InProcServer32]
                '@="axdb.dll"
                '"ThreadingModel"="Apartment"

                ''---------------------------------------------------------------
                '' AcadTableStyle
                ''---------------------------------------------------------------
                ' Windows Registry Editor Version 5.00

                '[HKEY_CLASSES_ROOT\CLSID\{F4C9A261-DD69-45E5-BA9C-B70BD8B9E770}]
                '@="AcadTableStyle"

                '[HKEY_CLASSES_ROOT\CLSID\{F4C9A261-DD69-45E5-BA9C-B70BD8B9E770}\InProcServer32]
                '@="axdb.dll"
                '"ThreadingModel"="Apartment"
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadTableStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.2.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{F4C9A261-DD69-45E5-BA9C-B70BD8B9E770}\InProcServer32\18.0.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadTableStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.0.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{F4C9A261-DD69-45E5-BA9C-B70BD8B9E770}\InProcServer32\18.1.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadTableStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.1.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{F4C9A261-DD69-45E5-BA9C-B70BD8B9E770}\InProcServer32\18.2.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadTableStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.2.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"



                ''---------------------------------------------------------------
                '' AcadMLeaderStyle
                ''---------------------------------------------------------------
                ' Windows Registry Editor Version 5.00

                '[HKEY_CLASSES_ROOT\CLSID\{99211C95-3862-4E7C-8770-35C68CA1944B}]
                '@="AcadMLeaderStyle"

                '[HKEY_CLASSES_ROOT\CLSID\{99211C95-3862-4E7C-8770-35C68CA1944B}\InProcServer32]
                '@="axdb.dll"
                '"ThreadingModel"="Apartment"
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadMLeaderStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.2.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{99211C95-3862-4E7C-8770-35C68CA1944B}\InProcServer32\18.0.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadMLeaderStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.0.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{99211C95-3862-4E7C-8770-35C68CA1944B}\InProcServer32\18.1.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadMLeaderStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.1.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{99211C95-3862-4E7C-8770-35C68CA1944B}\InProcServer32\18.2.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadMLeaderStyleClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.2.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"



                ''---------------------------------------------------------------
                '' AcadSortentsTable
                ''---------------------------------------------------------------
                ' Windows Registry Editor Version 5.00

                '[HKEY_CLASSES_ROOT\CLSID\{A89FFC20-CAE1-4FFF-96A4-2422B305B57B}]
                '@="AcadSortentsTable"

                '[HKEY_CLASSES_ROOT\CLSID\{A89FFC20-CAE1-4FFF-96A4-2422B305B57B}\InProcServer32]
                '@="axdb.dll"
                '"ThreadingModel"="Apartment"
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadSortentsTableClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.2.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{A89FFC20-CAE1-4FFF-96A4-2422B305B57B}\InProcServer32\18.0.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadSortentsTableClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.0.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{A89FFC20-CAE1-4FFF-96A4-2422B305B57B}\InProcServer32\18.1.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadSortentsTableClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.1.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"

                '[HKEY_CLASSES_ROOT\CLSID\{A89FFC20-CAE1-4FFF-96A4-2422B305B57B}\InProcServer32\18.2.0.0]
                '"Class"="Autodesk.AutoCAD.Interop.Common.AcadSortentsTableClass"
                '"Assembly"="Autodesk.AutoCAD.Interop.Common, Version=18.2.0.0, Culture=neutral, PublicKeyToken=eed84259d7cbf30b"
                '"RuntimeVersion"="v2.0.50727"



                '' These are the 2017 - R21 Keys I found may need to conver CLSID to GIUDS ?
                'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Components\8E58BBCEFCB868EE6AC43C9188796051
                '8E0D6A6353402A94B82D2BCAA771FFAB
                '22:\Software\Autodesk\ObjectDBX\R21.0\ActiveXCLSID\AcDbDictionary
                'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Components\6D2214EE27CDFDB48D61E9081FC82BCD
                '8E0D6A6353402A94B82D2BCAA771FFAB
                '22:\Software\Autodesk\ObjectDBX\R21.0\ActiveXCLSID\AcDbMLeaderStyle
                'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Components\3CD3454E359E253AF526CB8FD879AAFF
                '8E0D6A6353402A94B82D2BCAA771FFAB
                '22:\Software\Autodesk\ObjectDBX\R21.0\ActiveXCLSID\AcDbTableStyle
                'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Components\B85EE1460C74CB32D7CE2CE1C4516058
                '8E0D6A6353402A94B82D2BCAA771FFAB
                '22:\Software\Autodesk\ObjectDBX\R21.0\ActiveXCLSID\AcDbSortentsTable
            End If

            ' add this xrecord in...
            pXrec = pDict.AddXRecord(Me.RuleID)

            '...set up our arrays of data...
            iXrecDataType(0) = 300
            vXrecDataValue(0) = Me.Description
            iXrecDataType(1) = 301
            vXrecDataValue(1) = Me.value
            iXrecDataType(2) = 281
            vXrecDataValue(2) = Me.TableCode
            iXrecDataType(3) = 282
            vXrecDataValue(3) = Me.DlgCode

            '...set the data on the xrecord...
            pXrec.SetXRecordData(iXrecDataType, vXrecDataValue)

            ' return true for ok...
            Save = True
            Return True


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return False

    End Function


    ' Will only delete rule in current drawing
    Public Function Delete() As Boolean

        Dim pXdict, pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
        Dim iXrecDataType(3) As Integer
        Dim vXrecDataValue(3) As Object

        On Error GoTo ErrorHandler

        ' get a pointer to the extension dictionary...
        pXdict = ThisDrawing.Blocks.GetExtensionDictionary
        ' see if our rule dictionary is present...
        pDict = CType(pXdict.GetObject(RULES), AcadDictionary)
        ' check if we got it...

        If pDict Is Nothing Then
            '...not there nothing to delete....
            Delete = False
        Else
            ' add this xrecord in...
            pDict.Remove(Me.RuleID)
            ' return true for ok...
            Delete = True
        End If

BailOut:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found - dictionary entry not found
                ' clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Information.Err.Clear()
                Delete = False
                Resume BailOut
        End Select

    End Function

    ' class constructor...
    Public Sub New()

        MyBase.New()

        ' explicitly initialise all our class variables to defualts...
        m_sRuleID = ""
        m_sDescription = ""
        m_sValue = ""
        m_iTableCode = -1
        m_iDlgCode = -1

    End Sub

    Protected Overrides Sub Finalize()

        MyBase.Finalize()

    End Sub

End Class