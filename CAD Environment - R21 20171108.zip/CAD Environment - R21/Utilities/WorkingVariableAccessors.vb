﻿Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core

Public Module WorkingVariableAccessors

    Private m_cWorkVars As Collection

    ' constant for dictionary name on the symbol tables
    Private Const WORKVARS As String = "SKM_WORKING_VARIABLES"

    '------------------------------------------------------------------------------
    ' Working Variables
    ' NOTE: All of the work vars are searched and stored in the current drawing
    '------------------------------------------------------------------------------

    Public Function WorkVarsInitialize() As Boolean

        Dim pExtDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord

        On Error GoTo ErrorHandler

        ' see if the extension dictionary is there off the text styles table...
        'UPGRADE_WARNING: Couldn't resolve default property of object ThisDrawing.Blocks. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        If Not ThisDrawingUtilities.Blocks.HasExtensionDictionary Then
            ' we haven't been here before (and neither has anything else for that matter)
            ' so just bail...nothing to do
            WorkVarsInitialize = False
            Exit Function
        Else
            ' it's got an ext. dict., so het it
            'UPGRADE_WARNING: Couldn't resolve default property of object ThisDrawing.Blocks. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            pExtDict = ThisDrawingUtilities.Blocks.GetExtensionDictionary
        End If

        If pExtDict.Count < 2 Then
            ' Normally we have 1 extension dictionary for RULES but if Two are Present then it should be the Workvars one.
            WorkVarsInitialize = False
            Exit Function
        End If

        ' got an extension dictionary, so see if our dictionary is present...
        pDict = CType(pExtDict.GetObject(WORKVARS), Autodesk.AutoCAD.Interop.Common.AcadDictionary)

        ' initialise our collection...
        m_cWorkVars = New Collection

        ' if we get here, the extension dictionary is present
        ' and our dictionary containing our "working variable" xrecords is there,
        ' so loop them all and add them to our collection
        Dim vXrecDataType As Object = Nothing
        Dim vXrecDataValue As Object = Nothing
        Dim i As Integer
        Dim pWorkVar As WorkVars

        For Each pXrec In pDict

            ' get the xrecord's data...
            pXrec.GetXRecordData(vXrecDataType, vXrecDataValue)

            '' cast to working types
            Dim types() As Int16 = DirectCast(vXrecDataType, Int16())
            Dim values() As Object = DirectCast(vXrecDataValue, Object())

            ' create a new instance of a rule object...
            pWorkVar = New WorkVars

            ' set the name
            pWorkVar.Name = pXrec.Name

            ' set the value...
            pWorkVar.value = values(1).ToString()

            ' add the workvar to the collection
            m_cWorkVars.Add(pWorkVar, pWorkVar.Name)
        Next pXrec

        WorkVarsInitialize = True

BailOutHere:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                WorkVarsInitialize = False
                Resume BailOutHere
            Case -2145386302
                ThisDrawingUtilities.SendCommand(Chr(27))
                ' Lock Change in Progress
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                WorkVarsInitialize = False
                Resume BailOutHere
                Acad_MessageBox("This lock error can be minimised by locking all your viewports", , , , , , , True, logName)
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                WorkVarsInitialize = False
                Resume BailOutHere
        End Select

    End Function

    Public Function WorkVarsPurge() As Boolean

        Dim pExtDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord

        On Error GoTo ErrorHandler

        ' see if the extension dictionary is there off the text styles table...
        If Not ThisDrawingUtilities.Blocks.HasExtensionDictionary Then
            ' we haven't been here before (and neither has anything else for that matter)
            ' so just bail...nothing to do
            WorkVarsPurge = False
            Exit Function
        Else
            ' it's got an ext. dict., so het it
            pExtDict = ThisDrawingUtilities.Blocks.GetExtensionDictionary
        End If

        ' got an extension dictionary, so see if our dictionary is present...
        pDict = CType(pExtDict.GetObject(WORKVARS), Autodesk.AutoCAD.Interop.Common.AcadDictionary)

        ' initialise our collection...
        m_cWorkVars = New Collection

        ' if we get here, the extension dictionary is present
        ' and our dictionary containing our "working variable" xrecords is there,
        ' so loop them all and add them to our collection
        Dim vXrecDataType As Object = Nothing
        Dim vXrecDataValue As Object = Nothing
        Dim i As Integer
        Dim pWorkVar As WorkVars
        For Each pXrec In pDict

            ' get the xrecord's data...
            pXrec.GetXRecordData(vXrecDataType, vXrecDataValue)

            pXrec.Delete()

        Next pXrec

        WorkVarsPurge = True

BailOutHere:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                WorkVarsPurge = False
                Resume BailOutHere
            Case -2145386302
                ThisDrawingUtilities.SendCommand(Chr(27))
                ' Lock Change in Progress
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                WorkVarsPurge = False
                Resume BailOutHere
                Acad_MessageBox("This lock error can be minimised by locking all your viewports", , , , , , , True, logName)
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                WorkVarsPurge = False
                Resume BailOutHere
        End Select

    End Function

    Public Function WorkVarCount() As Integer

        If m_cWorkVars Is Nothing Then
            WorkVarCount = -1
            Exit Function
        ElseIf m_cWorkVars.Count() = 0 Then
            WorkVarCount = -1
            Exit Function
        End If

        WorkVarCount = CShort(m_cWorkVars.Count())

    End Function

    Public Function GetWorkVar(ByVal sVarName As String) As WorkVars

        Dim pWorkVar As WorkVars

        ' Have to initialize every time just in case we changed drawings
        WorkVarsInitialize() ' Do an initialize to make sure something wasn't written sincle last time

        If m_cWorkVars Is Nothing Then
            If m_cWorkVars Is Nothing Then
                GetWorkVar = Nothing
                Exit Function
            ElseIf m_cWorkVars.Count() = 0 Then
                GetWorkVar = Nothing
                Exit Function
            End If
        End If

        For Each pWorkVar In m_cWorkVars
            If UCase(pWorkVar.Name) = UCase(sVarName) Then
                GetWorkVar = pWorkVar
                Exit Function
            End If
        Next pWorkVar
        ' we get here, then it doesn't exist so return nothing
        GetWorkVar = Nothing

    End Function

    Public Function GetWorkVarValue(ByVal sVarName As String, Optional ByRef sDefault As String = "") As String

        Dim pWorkVar As WorkVars
        If ThisDrawingIsConfigured() Then


            ' Have to initialize every time just in case we changed drawings
            WorkVarsInitialize() ' Do an initialize to make sure something wasn't written sincle last time

            If m_cWorkVars Is Nothing Then
                If m_cWorkVars Is Nothing Then
                    GetWorkVarValue = sDefault
                    Exit Function
                ElseIf m_cWorkVars.Count() = 0 Then
                    GetWorkVarValue = sDefault
                    Exit Function
                End If
            End If

            For Each pWorkVar In m_cWorkVars
                If UCase(pWorkVar.Name) = UCase(sVarName) Then
                    GetWorkVarValue = CStr(pWorkVar.value)
                    Exit Function
                End If
            Next pWorkVar
        End If

        ' we get here, then it doesn't exist so return empty string
        GetWorkVarValue = sDefault

    End Function

    Public Function GetAllWorkVars() As Collection

        If m_cWorkVars Is Nothing Then
            GetAllWorkVars = Nothing
        ElseIf m_cWorkVars.Count() = 0 Then
            GetAllWorkVars = Nothing
        Else
            GetAllWorkVars = m_cWorkVars
        End If

    End Function

    Public Function DeleteWorkVar(ByVal sName As String) As Boolean

        On Error GoTo ErrorHandler

        If m_cWorkVars Is Nothing Then
            DeleteWorkVar = False
            Exit Function
        ElseIf m_cWorkVars.Count() = 0 Then
            DeleteWorkVar = False
            Exit Function
        End If

        If HasWorkVar(sName) Then
            'delete it
            m_cWorkVars.Remove(sName)
            DeleteWorkVar = True
        Else
            ' no object of the name passed in, so return failure
            DeleteWorkVar = False
        End If


BailOutHere:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case Else
                Information.Err.Clear()
                DeleteWorkVar = False
                Resume BailOutHere
        End Select
    End Function

    Public Function AddWorkVar(ByVal sName As String, ByVal vValue As Object) As WorkVars

        Dim pWorkVar As WorkVars
        ' create a new instance of our workvar...
        pWorkVar = New WorkVars
        ' set the values for the object...
        pWorkVar.Name = sName
        pWorkVar.value = vValue

        pWorkVar.Save()

BailOutHere:
        AddWorkVar = pWorkVar
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found
                ' clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                AddWorkVar = Nothing
                Resume BailOutHere
        End Select

    End Function


    Public Function HasWorkVar(ByVal sVarName As String) As Boolean

        Dim pWorkVar As WorkVars

        If m_cWorkVars Is Nothing Then
            HasWorkVar = False
            Exit Function
        ElseIf m_cWorkVars.Count() = 0 Then
            HasWorkVar = False
            Exit Function
        End If

        For Each pWorkVar In m_cWorkVars
            If UCase(pWorkVar.Name) = UCase(sVarName) Then
                HasWorkVar = True
                Exit Function
            End If
        Next pWorkVar

        HasWorkVar = False

    End Function

    Sub RemoveWorkVar(ByRef sWorkVarID As String)

        Dim rWorkVarToDelete As WorkVars

        rWorkVarToDelete = GetWorkVar(sWorkVarID)

        If rWorkVarToDelete IsNot Nothing Then
            rWorkVarToDelete.Delete()
        End If

    End Sub

End Module



