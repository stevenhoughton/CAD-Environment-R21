﻿Imports System.IO
Imports System.Diagnostics
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms

Imports Autodesk.AutoCAD.ApplicationServices.Application
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Windows
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.GraphicsSystem
Imports Jacobs.AutoCAD.Utilities.DwgView


Public Class DwgPreviewControl
    Inherits Control

    Public Sub New()
    End Sub

    ' current dwg
    Public mCurrentDwg As Database = Nothing
    ' Gs specific
    Public mpManager As Autodesk.AutoCAD.GraphicsSystem.Manager = Nothing
    Public mpDevice As Autodesk.AutoCAD.GraphicsSystem.Device = Nothing
    Public mpModel As Autodesk.AutoCAD.GraphicsSystem.Model = Nothing
    Public mpView As Autodesk.AutoCAD.GraphicsSystem.View = Nothing
    ' flags
    Public mZooming As Boolean = False
    Public mMouseDown As Boolean = False
    Public mMouseMoving As Boolean = False
    Public mbPanning As Boolean = False
    Public mbOrbiting As Boolean = False
    Public mStartPoint As System.Drawing.Point
    Public mEndPoint As System.Drawing.Point

    Public Shared ReadOnly Property IsDesignMode() As Boolean
        Get
            Return Utils.IsDesignMode(Nothing)
        End Get
    End Property

    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            ' clear up the GS view gadgets
            If Not IsDesignMode Then
                ClearAll()
            End If
        End If
        MyBase.Dispose(disposing)

    End Sub

    ' called from InitDrawingControl, does GsPreviewCtrl specific initialization
    Public Sub Init(ByVal doc As Document, ByVal db As Database)
        mCurrentDwg = db
        ' check to see if the manager is already initalised
        If mpManager Is Nothing Then
            ' if not let's set it up
            mpManager = doc.GraphicsManager
            ' here's some test code to show the GS Events working
            'mpManager.ViewToBeDestroyed += New ViewToBeDestroyedEventHandler(AddressOf GSUtil.mpManager_ViewToBeDestroyed)
            AddHandler mpManager.ViewToBeDestroyed, AddressOf GSUtil.mpManager_ViewToBeDestroyed

            'mpManager.ViewWasCreated += New ViewWasCreatedEventHandler(AddressOf GSUtil.mpManager_ViewWasCreated)
            AddHandler mpManager.ViewWasCreated, AddressOf GSUtil.mpManager_ViewWasCreated

            'mpManager.GsToBeUnloaded += New GsToBeUnloadedEventHandler(AddressOf GSUtil.mpManager_GsToBeUnloaded)
            AddHandler mpManager.GsToBeUnloaded, AddressOf GSUtil.mpManager_GsToBeUnloaded

            'mpManager.ConfigWasModified += New ConfigWasModifiedEventHandler(AddressOf GSUtil.mpManager_ConfigWasModified)
            AddHandler mpManager.ConfigWasModified, AddressOf GSUtil.mpManager_ConfigWasModified

            '' OLD CODE 2012 START -------------------------------------------------------------------------------------------------------------
            '' Looks like CreateAutoCADDevice now requires an AutoCAD GraphicsKernel
            ''
            '' now create the Gs control, create the autocad device passing the handle to the Windows panel
            'mpDevice = mpManager.CreateAutoCADDevice(Me.Handle)
            '
            '' resize the device to the panel size
            'mpDevice.OnSize(Me.Size)
            '
            '' now create a new gs view
            'mpView = New Autodesk.AutoCAD.GraphicsSystem.View()
            '
            '' and create the model
            'mpModel = mpManager.CreateAutoCADModel()
            '' OLD CODE 2012 END -------------------------------------------------------------------------------------------------------------


            '' NEW CODE 2017 START -------------------------------------------------------------------------------------------------------------
            Dim descriptor As New KernelDescriptor()
            descriptor.addRequirement(Autodesk.AutoCAD.UniqueString.Intern("3D Drawing"))
            Dim kernal As GraphicsKernel = Manager.AcquireGraphicsKernel(descriptor)

            ' now create the Gs control, create the autocad device passing the handle to the Windows panel
            mpDevice = mpManager.CreateAutoCADDevice(kernal, Me.Handle)

            ' resize the device to the panel size
            mpDevice.OnSize(Me.Size)

            ' now create a new gs view
            mpView = New Autodesk.AutoCAD.GraphicsSystem.View()

            ' and create the model
            mpModel = mpManager.CreateAutoCADModel(kernal)
            '' NEW CODE 2017 END -------------------------------------------------------------------------------------------------------------


            ' add the view to the device
            mpDevice.Add(mpView)


        End If
    End Sub


    Public Sub ClearAll()
        If Not IsDesignMode Then
            If mpDevice IsNot Nothing Then
                Dim b As Boolean = mpDevice.[Erase](mpView)
            End If
            If mpView IsNot Nothing Then
                mpView.EraseAll()
                mpView.Dispose()
                mpView = Nothing
            End If
            If mpManager IsNot Nothing Then
                If mpModel IsNot Nothing Then
                    mpModel.Dispose()
                    mpModel = Nothing
                End If

                If mpDevice IsNot Nothing Then
                    mpDevice.Dispose()
                    mpDevice = Nothing
                End If
                mpManager = Nothing
            End If
        End If
    End Sub

    ' [TT]: Refactored to exclude AutoCAD types from methods that run in the designer:

    Public Sub ErasePreview()
        If Not IsDesignMode Then
            InternalErasePreview()
        End If
    End Sub

    Public Sub InternalErasePreview()
        If mpView IsNot Nothing Then
            mpView.EraseAll()
        End If
        If mpManager IsNot Nothing AndAlso mpModel IsNot Nothing Then
            mpModel.Dispose()
            mpModel = Nothing
        End If
    End Sub

    Private Sub RubberRectangle(ByVal p1 As Point, ByVal p2 As Point)
        Dim rc As New Rectangle()

        ' Convert the points to screen coordinates.
        p1 = PointToScreen(p1)
        p2 = PointToScreen(p2)
        ' Normalize the rectangle.
        If p1.X < p2.X Then
            rc.X = p1.X
            rc.Width = p2.X - p1.X
        Else
            rc.X = p2.X
            rc.Width = p1.X - p2.X
        End If
        If p1.Y < p2.Y Then
            rc.Y = p1.Y
            rc.Height = p2.Y - p1.Y
        Else
            rc.Y = p2.Y
            rc.Height = p1.Y - p2.Y
        End If
        ' Draw the reversible frame.
        ControlPaint.DrawReversibleFrame(rc, Color.White, FrameStyle.Dashed)
    End Sub

    Public Sub refreshView()
        If Not IsDesignMode Then
            InternalRefreshView()
        End If
    End Sub

    Private Sub InternalRefreshView()
        If mpView IsNot Nothing Then
            mpView.Invalidate()
            mpView.Update()
        End If
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        refreshView()
    End Sub

    Protected Overrides Sub OnMouseMove(ByVal e As System.Windows.Forms.MouseEventArgs)
        MyBase.OnMouseMove(e)
        If Not IsDesignMode Then
            InternalOnMouseMove(e)
        End If
    End Sub

    Private Sub InternalOnMouseMove(ByVal e As System.Windows.Forms.MouseEventArgs)
        If mpView IsNot Nothing Then
            If mZooming Then
                ' if left button is down
                If mMouseDown Then
                    If mMouseMoving Then
                        ' erase the old rectangle
                        RubberRectangle(mStartPoint, mEndPoint)
                    End If
                    ' draw the new rectangle
                    RubberRectangle(mStartPoint, e.Location)
                    mMouseMoving = True
                    ' save the new point for next time
                    mEndPoint = e.Location
                End If
            Else
                If mbPanning Then
                    'transform the point from device coordinates to
                    'world coordinates
                    Dim pan_vec As New Vector3d(-(e.Location.X - mStartPoint.X), e.Location.Y - mStartPoint.Y, 0)
                    pan_vec.TransformBy(mpView.ViewingMatrix * mpView.WorldToDeviceMatrix.Inverse())
                    mpView.Dolly(pan_vec)
                    refreshView()
                    mStartPoint = e.Location
                End If
                If mbOrbiting Then
                    Dim Half_Pi As Double = 1.570796326795

                    '' Old Code 2012 - Error	'Viewport' is not a member of 'Autodesk.AutoCAD.GraphicsSystem.View'
                    ' Dim view_rect As System.Drawing.Rectangle = mpView.Viewport
                    '' Old Code 2012

                    '' NEW CODE 2017
                    Dim view_rect As New System.Drawing.Rectangle(CInt(mpView.ViewportExtents.MinPoint.X), CInt(mpView.ViewportExtents.MinPoint.Y), CInt(mpView.ViewportExtents.MaxPoint.X - mpView.ViewportExtents.MinPoint.X), CInt(mpView.ViewportExtents.MaxPoint.Y - mpView.ViewportExtents.MinPoint.Y))
                    '' NEW CODE 2017

                    Dim nViewportX As Integer = (view_rect.Right - view_rect.Left) + 1
                    Dim nViewportY As Integer = (view_rect.Bottom - view_rect.Top) + 1

                    Dim centerX As Integer = CInt(Math.Truncate(nViewportX / 2.0F + view_rect.Left))
                    Dim centerY As Integer = CInt(Math.Truncate(nViewportY / 2.0F + view_rect.Top))

                    Dim radius As Double = System.Math.Min(nViewportX, nViewportY) * 0.4F

                    ' compute two vectors from last and new cursor positions:

                    Dim last_vector As New Vector3d((mStartPoint.X - centerX) / radius, -(mStartPoint.Y - centerY) / radius, 0.0)
                    If last_vector.LengthSqrd > 1.0 Then
                        ' outside the radius
                        Dim x As Double = last_vector.X / last_vector.Length
                        Dim y As Double = last_vector.Y / last_vector.Length
                        Dim z As Double = last_vector.Z / last_vector.Length

                        last_vector = New Vector3d(x, y, z)
                    Else
                        Dim x As Double = last_vector.X
                        Dim y As Double = last_vector.Y
                        Dim z As Double = System.Math.Sqrt(1.0 - last_vector.X * last_vector.X - last_vector.Y * last_vector.Y)
                        last_vector = New Vector3d(x, y, z)
                    End If

                    Dim new_vector As New Vector3d((e.Location.X - centerX) / radius, -(e.Location.Y - centerY) / radius, 0.0)

                    If new_vector.LengthSqrd > 1.0 Then
                        ' outside the radius
                        Dim x As Double = new_vector.X / new_vector.Length
                        Dim y As Double = new_vector.Y / new_vector.Length
                        Dim z As Double = new_vector.Z / new_vector.Length

                        new_vector = New Vector3d(x, y, z)
                    Else
                        Dim x As Double = new_vector.X
                        Dim y As Double = new_vector.Y
                        Dim z As Double = System.Math.Sqrt(1.0 - new_vector.X * new_vector.X - new_vector.Y * new_vector.Y)
                        new_vector = New Vector3d(x, y, z)
                    End If

                    ' determine angles for proper sequence of camera manipulations:

                    Dim rotation_vector As Vector3d = last_vector
                    rotation_vector = rotation_vector.CrossProduct(new_vector)
                    ' rotation_vector = last_vector x new_vector
                    Dim work_vector As Vector3d = rotation_vector
                    work_vector = New Vector3d(work_vector.X, work_vector.Y, 0.0F)
                    ' projection of rotation_vector onto xy plane
                    Dim roll_angle As Double = System.Math.Atan2(work_vector.X, work_vector.Y)
                    ' assuming that the camera's up vector is "up",
                    ' this computes the angle between the up vector 
                    ' and the work vector, which is the roll required
                    ' to make the up vector coincident with the rotation_vector
                    Dim length As Double = rotation_vector.Length
                    Dim orbit_y_angle As Double = If((length <> 0.0), System.Math.Acos(rotation_vector.Z / length) + Half_Pi, Half_Pi)
                    ' represents inverse cosine of the dot product of the
                    If length > 1.0F Then
                        ' rotation_vector and the up_vector divided by the
                        length = 1.0F
                    End If
                    ' magnitude of both vectors.  We add pi/2 because we 
                    ' are making the up-vector parallel to the the rotation
                    Dim rotation_angle As Double = System.Math.Asin(length)
                    ' vector ... up-vector is perpin. to the eye-vector.
                    ' perform view manipulations

                    mpView.Roll(roll_angle)
                    ' 1: roll camera to make up vector coincident with rotation vector
                    mpView.Orbit(0.0F, orbit_y_angle)
                    ' 2: orbit along y to make up vector parallel with rotation vector
                    mpView.Orbit(rotation_angle, 0.0F)
                    ' 3: orbit along x by rotation angle
                    mpView.Orbit(0.0F, -orbit_y_angle)
                    ' 4: orbit along y by the negation of 2
                    mpView.Roll(-roll_angle)
                    ' 5: roll camera by the negation of 1
                    refreshView()
                    mStartPoint = e.Location
                End If
            End If
        End If
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As System.Windows.Forms.MouseEventArgs)
        MyBase.OnMouseDown(e)
        If Not IsDesignMode Then
            InternalOnMouseDown(e)
        End If
    End Sub

    Private Sub InternalOnMouseDown(ByVal e As System.Windows.Forms.MouseEventArgs)
        If mpView IsNot Nothing Then
            If e.Button = System.Windows.Forms.MouseButtons.Left Then
                ' if zooming
                If mZooming Then
                    mMouseDown = True
                    mMouseMoving = False
                Else
                    If mbOrbiting Then
                        mbOrbiting = True
                        Me.Focus()
                    End If
                End If
            ElseIf e.Button = System.Windows.Forms.MouseButtons.Middle Then
                mbPanning = True
            End If
            mStartPoint = e.Location
        End If
    End Sub

    Protected Overrides Sub OnMouseUp(ByVal e As System.Windows.Forms.MouseEventArgs)
        MyBase.OnMouseUp(e)
        If Not IsDesignMode Then
            InternalOnMouseUp(e)
        End If
    End Sub

    Private Sub InternalOnMouseUp(ByVal e As System.Windows.Forms.MouseEventArgs)
        If mpView IsNot Nothing Then
            If e.Button = System.Windows.Forms.MouseButtons.Left Then
                If mZooming AndAlso mMouseDown Then
                    ' end zoom
                    mZooming = False
                    mMouseDown = False
                    mMouseMoving = False


                    mpView.ZoomWindow(New Point2d(mStartPoint.X, Me.Bottom - mStartPoint.Y), New Point2d(mEndPoint.X, Me.Bottom - mEndPoint.Y))

                    refreshView()
                Else
                    mbOrbiting = False
                End If
            ElseIf e.Button = System.Windows.Forms.MouseButtons.Middle Then
                mbPanning = False
            End If
        End If
    End Sub

    Protected Overrides Sub OnSizeChanged(ByVal e As EventArgs)
        MyBase.OnSizeChanged(e)

        If Not IsDesignMode Then
            InternalOnSizeChanged()
        End If
    End Sub

    ' This method will never be jit'ed in the designer
    Private Sub InternalOnSizeChanged()
        If mpDevice IsNot Nothing Then
            mpDevice.OnSize(Me.Size)
        End If
    End Sub
End Class

Public Class GSUtil
    Public Const strActive As [String] = "*Active"
    Public Const strActiveSettings As [String] = "ACAD_RENDER_ACTIVE_SETTINGS"
    Public Shared Sub CustomUpdate(ByVal parmeter As System.IntPtr, ByVal left As Integer, ByVal right As Integer, ByVal bottom As Integer, ByVal top As Integer)
        MessageBox.Show("Left:" & left & "Right" & right & "Bottom" & bottom & "Top" & top)
    End Sub
    '----- 0 - lets make it red for an example
    '{255, 255, 255, 255},//----- 0 - ByBlock - White
    '----- 1 - Red 
    '----- 2 - Yellow
    '----- 3 - Green
    '----- 4 - Cyan
    '----- 5 - Blue
    '----- 6 - Magenta
    '----- 7 - More red Red 
    '----- 8 - More red Red 
    '----- 9 - More red Red 
    'System.Drawing.Color.FromArgb(255, 255, 255, 255),//----- 7 - White
    '      System.Drawing.Color.FromArgb(255, 255, 255, 255),//----- 8
    '      System.Drawing.Color.FromArgb(255, 255, 255, 255),//----- 9
    '----- 10
    '----- 11
    '----- 12
    '----- 13
    '----- 14
    '----- 15
    '----- 16
    '----- 17
    '----- 18
    '----- 19
    '----- 20
    '----- 21
    '----- 22
    '----- 23
    '----- 24
    '----- 25
    '----- 26
    '----- 27
    '----- 28
    '----- 29
    '----- 30
    '----- 31
    '----- 32
    '----- 33
    '----- 34
    '----- 35
    '----- 36
    '----- 37
    '----- 38
    '----- 39
    '----- 40
    '----- 41
    '----- 42
    '----- 43
    '----- 44
    '----- 45
    '----- 46
    '----- 47
    '----- 48
    '----- 49
    '----- 50
    '----- 51
    '----- 52
    '----- 53
    '----- 54
    '----- 55
    '----- 56
    '----- 57
    '----- 58
    '----- 59
    '----- 60
    '----- 61
    '----- 62
    '----- 63
    '----- 64
    '----- 65
    '----- 66
    '----- 67
    '----- 68
    '----- 69
    '----- 70
    '----- 71
    '----- 72
    '----- 73
    '----- 74
    '----- 75
    '----- 76
    '----- 77
    '----- 78
    '----- 79
    '----- 80
    '----- 81
    '----- 82
    '----- 83
    '----- 84
    '----- 85
    '----- 86
    '----- 87
    '----- 88
    '----- 89
    '----- 90
    '----- 91
    '----- 92
    '----- 93
    '----- 94
    '----- 95
    '----- 96
    '----- 97
    '----- 98
    '----- 99
    '----- 100
    '----- 101
    '----- 102
    '----- 103
    '----- 104
    '----- 105
    '----- 106
    '----- 107
    '----- 108
    '----- 109
    '----- 110
    '----- 111
    '----- 112
    '----- 113
    '----- 114
    '----- 115
    '----- 116
    '----- 117
    '----- 118
    '----- 119
    '----- 120
    '----- 121
    '----- 122
    '----- 123
    '----- 124
    '----- 125
    '----- 126
    '----- 127
    '----- 128
    '----- 129
    '----- 130
    '----- 131
    '----- 132
    '----- 133
    '----- 134
    '----- 135
    '----- 136
    '----- 137
    '----- 138
    '----- 139
    '----- 140
    '----- 141
    '----- 142
    '----- 143
    '----- 144
    '----- 145
    '----- 146
    '----- 147
    '----- 148
    '----- 149
    '----- 150
    '----- 151
    '----- 152
    '----- 153
    '----- 154
    '----- 155
    '----- 156
    '----- 157
    '----- 158
    '----- 159
    '----- 160
    '----- 161
    '----- 162
    '----- 163
    '----- 164
    '----- 165
    '----- 166
    '----- 167
    '----- 168
    '----- 169
    '----- 170
    '----- 171
    '----- 172
    '----- 173
    '----- 174
    '----- 175
    '----- 176
    '----- 177
    '----- 178
    '----- 179
    '----- 180
    '----- 181
    '----- 182
    '----- 183
    '----- 184
    '----- 185
    '----- 186
    '----- 187
    '----- 188
    '----- 189
    '----- 190
    '----- 191
    '----- 192
    '----- 193
    '----- 194
    '----- 195
    '----- 196
    '----- 197
    '----- 198
    '----- 199
    '----- 200
    '----- 201
    '----- 202
    '----- 203
    '----- 204
    '----- 205
    '----- 206
    '----- 207
    '----- 208
    '----- 209
    '----- 210
    '----- 211
    '----- 212
    '----- 213
    '----- 214
    '----- 215
    '----- 216
    '----- 217
    '----- 218
    '----- 219
    '----- 220
    '----- 221
    '----- 222
    '----- 223
    '----- 224
    '----- 225
    '----- 226
    '----- 227
    '----- 228
    '----- 229
    '----- 230
    '----- 231
    '----- 232
    '----- 233
    '----- 234
    '----- 235
    '----- 236
    '----- 237
    '----- 238
    '----- 239
    '----- 240
    '----- 241
    '----- 242
    '----- 243
    '----- 244
    '----- 245
    '----- 246
    '----- 247
    '----- 248
    '----- 249
    '----- 250
    '----- 251
    '----- 252
    '----- 253
    '----- 254
    '----- 255
    Public Shared MyAcadColorPs As System.Drawing.Color() = {System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 255, 0, 255), System.Drawing.Color.FromArgb(0, 255, 0, 255), System.Drawing.Color.FromArgb(0, 255, 255, 255), System.Drawing.Color.FromArgb(0, 0, 255, 255),
     System.Drawing.Color.FromArgb(255, 0, 255, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 127, 127, 255),
     System.Drawing.Color.FromArgb(165, 0, 0, 255), System.Drawing.Color.FromArgb(165, 82, 82, 255), System.Drawing.Color.FromArgb(127, 0, 0, 255), System.Drawing.Color.FromArgb(127, 63, 63, 255), System.Drawing.Color.FromArgb(76, 0, 0, 255), System.Drawing.Color.FromArgb(76, 38, 38, 255),
     System.Drawing.Color.FromArgb(38, 0, 0, 255), System.Drawing.Color.FromArgb(38, 19, 19, 255), System.Drawing.Color.FromArgb(255, 63, 0, 255), System.Drawing.Color.FromArgb(255, 159, 127, 255), System.Drawing.Color.FromArgb(165, 41, 0, 255), System.Drawing.Color.FromArgb(165, 103, 82, 255),
     System.Drawing.Color.FromArgb(127, 31, 0, 255), System.Drawing.Color.FromArgb(127, 79, 63, 255), System.Drawing.Color.FromArgb(76, 19, 0, 255), System.Drawing.Color.FromArgb(76, 47, 38, 255), System.Drawing.Color.FromArgb(38, 9, 0, 255), System.Drawing.Color.FromArgb(38, 23, 19, 255),
     System.Drawing.Color.FromArgb(255, 127, 0, 255), System.Drawing.Color.FromArgb(255, 191, 127, 255), System.Drawing.Color.FromArgb(165, 82, 0, 255), System.Drawing.Color.FromArgb(165, 124, 82, 255), System.Drawing.Color.FromArgb(127, 63, 0, 255), System.Drawing.Color.FromArgb(127, 95, 63, 255),
     System.Drawing.Color.FromArgb(76, 38, 0, 255), System.Drawing.Color.FromArgb(76, 57, 38, 255), System.Drawing.Color.FromArgb(38, 19, 0, 255), System.Drawing.Color.FromArgb(38, 28, 19, 255), System.Drawing.Color.FromArgb(255, 191, 0, 255), System.Drawing.Color.FromArgb(255, 223, 127, 255),
     System.Drawing.Color.FromArgb(165, 124, 0, 255), System.Drawing.Color.FromArgb(165, 145, 82, 255), System.Drawing.Color.FromArgb(127, 95, 0, 255), System.Drawing.Color.FromArgb(127, 111, 63, 255), System.Drawing.Color.FromArgb(76, 57, 0, 255), System.Drawing.Color.FromArgb(76, 66, 38, 255),
     System.Drawing.Color.FromArgb(38, 28, 0, 255), System.Drawing.Color.FromArgb(38, 33, 19, 255), System.Drawing.Color.FromArgb(255, 255, 0, 255), System.Drawing.Color.FromArgb(255, 255, 127, 255), System.Drawing.Color.FromArgb(165, 165, 0, 255), System.Drawing.Color.FromArgb(165, 165, 82, 255),
     System.Drawing.Color.FromArgb(127, 127, 0, 255), System.Drawing.Color.FromArgb(127, 127, 63, 255), System.Drawing.Color.FromArgb(76, 76, 0, 255), System.Drawing.Color.FromArgb(76, 76, 38, 255), System.Drawing.Color.FromArgb(38, 38, 0, 255), System.Drawing.Color.FromArgb(38, 38, 19, 255),
     System.Drawing.Color.FromArgb(191, 255, 0, 255), System.Drawing.Color.FromArgb(223, 255, 127, 255), System.Drawing.Color.FromArgb(124, 165, 0, 255), System.Drawing.Color.FromArgb(145, 165, 82, 255), System.Drawing.Color.FromArgb(95, 127, 0, 255), System.Drawing.Color.FromArgb(111, 127, 63, 255),
     System.Drawing.Color.FromArgb(57, 76, 0, 255), System.Drawing.Color.FromArgb(66, 76, 38, 255), System.Drawing.Color.FromArgb(28, 38, 0, 255), System.Drawing.Color.FromArgb(33, 38, 19, 255), System.Drawing.Color.FromArgb(127, 255, 0, 255), System.Drawing.Color.FromArgb(191, 255, 127, 255),
     System.Drawing.Color.FromArgb(82, 165, 0, 255), System.Drawing.Color.FromArgb(124, 165, 82, 255), System.Drawing.Color.FromArgb(63, 127, 0, 255), System.Drawing.Color.FromArgb(95, 127, 63, 255), System.Drawing.Color.FromArgb(38, 76, 0, 255), System.Drawing.Color.FromArgb(57, 76, 38, 255),
     System.Drawing.Color.FromArgb(19, 38, 0, 255), System.Drawing.Color.FromArgb(28, 38, 19, 255), System.Drawing.Color.FromArgb(63, 255, 0, 255), System.Drawing.Color.FromArgb(159, 255, 127, 255), System.Drawing.Color.FromArgb(41, 165, 0, 255), System.Drawing.Color.FromArgb(103, 165, 82, 255),
     System.Drawing.Color.FromArgb(31, 127, 0, 255), System.Drawing.Color.FromArgb(79, 127, 63, 255), System.Drawing.Color.FromArgb(19, 76, 0, 255), System.Drawing.Color.FromArgb(47, 76, 38, 255), System.Drawing.Color.FromArgb(9, 38, 0, 255), System.Drawing.Color.FromArgb(23, 38, 19, 255),
     System.Drawing.Color.FromArgb(0, 255, 0, 255), System.Drawing.Color.FromArgb(127, 255, 127, 255), System.Drawing.Color.FromArgb(0, 165, 0, 255), System.Drawing.Color.FromArgb(82, 165, 82, 255), System.Drawing.Color.FromArgb(0, 127, 0, 255), System.Drawing.Color.FromArgb(63, 127, 63, 255),
     System.Drawing.Color.FromArgb(0, 76, 0, 255), System.Drawing.Color.FromArgb(38, 76, 38, 255), System.Drawing.Color.FromArgb(0, 38, 0, 255), System.Drawing.Color.FromArgb(19, 38, 19, 255), System.Drawing.Color.FromArgb(0, 255, 63, 255), System.Drawing.Color.FromArgb(127, 255, 159, 255),
     System.Drawing.Color.FromArgb(0, 165, 41, 255), System.Drawing.Color.FromArgb(82, 165, 103, 255), System.Drawing.Color.FromArgb(0, 127, 31, 255), System.Drawing.Color.FromArgb(63, 127, 79, 255), System.Drawing.Color.FromArgb(0, 76, 19, 255), System.Drawing.Color.FromArgb(38, 76, 47, 255),
     System.Drawing.Color.FromArgb(0, 38, 9, 255), System.Drawing.Color.FromArgb(19, 38, 23, 255), System.Drawing.Color.FromArgb(0, 255, 127, 255), System.Drawing.Color.FromArgb(127, 255, 191, 255), System.Drawing.Color.FromArgb(0, 165, 82, 255), System.Drawing.Color.FromArgb(82, 165, 124, 255),
     System.Drawing.Color.FromArgb(0, 127, 63, 255), System.Drawing.Color.FromArgb(63, 127, 95, 255), System.Drawing.Color.FromArgb(0, 76, 38, 255), System.Drawing.Color.FromArgb(38, 76, 57, 255), System.Drawing.Color.FromArgb(0, 38, 19, 255), System.Drawing.Color.FromArgb(19, 38, 28, 255),
     System.Drawing.Color.FromArgb(0, 255, 191, 255), System.Drawing.Color.FromArgb(127, 255, 223, 255), System.Drawing.Color.FromArgb(0, 165, 124, 255), System.Drawing.Color.FromArgb(82, 165, 145, 255), System.Drawing.Color.FromArgb(0, 127, 95, 255), System.Drawing.Color.FromArgb(63, 127, 111, 255),
     System.Drawing.Color.FromArgb(0, 76, 57, 255), System.Drawing.Color.FromArgb(38, 76, 66, 255), System.Drawing.Color.FromArgb(0, 38, 28, 255), System.Drawing.Color.FromArgb(19, 38, 33, 255), System.Drawing.Color.FromArgb(0, 255, 255, 255), System.Drawing.Color.FromArgb(127, 255, 255, 255),
     System.Drawing.Color.FromArgb(0, 165, 165, 255), System.Drawing.Color.FromArgb(82, 165, 165, 255), System.Drawing.Color.FromArgb(0, 127, 127, 255), System.Drawing.Color.FromArgb(63, 127, 127, 255), System.Drawing.Color.FromArgb(0, 76, 76, 255), System.Drawing.Color.FromArgb(38, 76, 76, 255),
     System.Drawing.Color.FromArgb(0, 38, 38, 255), System.Drawing.Color.FromArgb(19, 38, 38, 255), System.Drawing.Color.FromArgb(0, 191, 255, 255), System.Drawing.Color.FromArgb(127, 223, 255, 255), System.Drawing.Color.FromArgb(0, 124, 165, 255), System.Drawing.Color.FromArgb(82, 145, 165, 255),
     System.Drawing.Color.FromArgb(0, 95, 127, 255), System.Drawing.Color.FromArgb(63, 111, 127, 255), System.Drawing.Color.FromArgb(0, 57, 76, 255), System.Drawing.Color.FromArgb(38, 66, 76, 255), System.Drawing.Color.FromArgb(0, 28, 38, 255), System.Drawing.Color.FromArgb(19, 33, 38, 255),
     System.Drawing.Color.FromArgb(0, 127, 255, 255), System.Drawing.Color.FromArgb(127, 191, 255, 255), System.Drawing.Color.FromArgb(0, 82, 165, 255), System.Drawing.Color.FromArgb(82, 124, 165, 255), System.Drawing.Color.FromArgb(0, 63, 127, 255), System.Drawing.Color.FromArgb(63, 95, 127, 255),
     System.Drawing.Color.FromArgb(0, 38, 76, 255), System.Drawing.Color.FromArgb(38, 57, 76, 255), System.Drawing.Color.FromArgb(0, 19, 38, 255), System.Drawing.Color.FromArgb(19, 28, 38, 255), System.Drawing.Color.FromArgb(0, 63, 255, 255), System.Drawing.Color.FromArgb(127, 159, 255, 255),
     System.Drawing.Color.FromArgb(0, 41, 165, 255), System.Drawing.Color.FromArgb(82, 103, 165, 255), System.Drawing.Color.FromArgb(0, 31, 127, 255), System.Drawing.Color.FromArgb(63, 79, 127, 255), System.Drawing.Color.FromArgb(0, 19, 76, 255), System.Drawing.Color.FromArgb(38, 47, 76, 255),
     System.Drawing.Color.FromArgb(0, 9, 38, 255), System.Drawing.Color.FromArgb(19, 23, 38, 255), System.Drawing.Color.FromArgb(0, 0, 255, 255), System.Drawing.Color.FromArgb(127, 127, 255, 255), System.Drawing.Color.FromArgb(0, 0, 165, 255), System.Drawing.Color.FromArgb(82, 82, 165, 255),
     System.Drawing.Color.FromArgb(0, 0, 127, 255), System.Drawing.Color.FromArgb(63, 63, 127, 255), System.Drawing.Color.FromArgb(0, 0, 76, 255), System.Drawing.Color.FromArgb(38, 38, 76, 255), System.Drawing.Color.FromArgb(0, 0, 38, 255), System.Drawing.Color.FromArgb(19, 19, 38, 255),
     System.Drawing.Color.FromArgb(63, 0, 255, 255), System.Drawing.Color.FromArgb(159, 127, 255, 255), System.Drawing.Color.FromArgb(41, 0, 165, 255), System.Drawing.Color.FromArgb(103, 82, 165, 255), System.Drawing.Color.FromArgb(31, 0, 127, 255), System.Drawing.Color.FromArgb(79, 63, 127, 255),
     System.Drawing.Color.FromArgb(19, 0, 76, 255), System.Drawing.Color.FromArgb(47, 38, 76, 255), System.Drawing.Color.FromArgb(9, 0, 38, 255), System.Drawing.Color.FromArgb(23, 19, 38, 255), System.Drawing.Color.FromArgb(127, 0, 255, 255), System.Drawing.Color.FromArgb(191, 127, 255, 255),
     System.Drawing.Color.FromArgb(82, 0, 165, 255), System.Drawing.Color.FromArgb(124, 82, 165, 255), System.Drawing.Color.FromArgb(63, 0, 127, 255), System.Drawing.Color.FromArgb(95, 63, 127, 255), System.Drawing.Color.FromArgb(38, 0, 76, 255), System.Drawing.Color.FromArgb(57, 38, 76, 255),
     System.Drawing.Color.FromArgb(19, 0, 38, 255), System.Drawing.Color.FromArgb(28, 19, 38, 255), System.Drawing.Color.FromArgb(191, 0, 255, 255), System.Drawing.Color.FromArgb(223, 127, 255, 255), System.Drawing.Color.FromArgb(124, 0, 165, 255), System.Drawing.Color.FromArgb(145, 82, 165, 255),
     System.Drawing.Color.FromArgb(95, 0, 127, 255), System.Drawing.Color.FromArgb(111, 63, 127, 255), System.Drawing.Color.FromArgb(57, 0, 76, 255), System.Drawing.Color.FromArgb(66, 38, 76, 255), System.Drawing.Color.FromArgb(28, 0, 38, 255), System.Drawing.Color.FromArgb(33, 19, 38, 255),
     System.Drawing.Color.FromArgb(255, 0, 255, 255), System.Drawing.Color.FromArgb(255, 127, 255, 255), System.Drawing.Color.FromArgb(165, 0, 165, 255), System.Drawing.Color.FromArgb(165, 82, 165, 255), System.Drawing.Color.FromArgb(127, 0, 127, 255), System.Drawing.Color.FromArgb(127, 63, 127, 255),
     System.Drawing.Color.FromArgb(76, 0, 76, 255), System.Drawing.Color.FromArgb(76, 38, 76, 255), System.Drawing.Color.FromArgb(38, 0, 38, 255), System.Drawing.Color.FromArgb(38, 19, 38, 255), System.Drawing.Color.FromArgb(255, 0, 191, 255), System.Drawing.Color.FromArgb(255, 127, 223, 255),
     System.Drawing.Color.FromArgb(165, 0, 124, 255), System.Drawing.Color.FromArgb(165, 82, 145, 255), System.Drawing.Color.FromArgb(127, 0, 95, 255), System.Drawing.Color.FromArgb(127, 63, 111, 255), System.Drawing.Color.FromArgb(76, 0, 57, 255), System.Drawing.Color.FromArgb(76, 38, 66, 255),
     System.Drawing.Color.FromArgb(38, 0, 28, 255), System.Drawing.Color.FromArgb(38, 19, 33, 255), System.Drawing.Color.FromArgb(255, 0, 127, 255), System.Drawing.Color.FromArgb(255, 127, 191, 255), System.Drawing.Color.FromArgb(165, 0, 82, 255), System.Drawing.Color.FromArgb(165, 82, 124, 255),
     System.Drawing.Color.FromArgb(127, 0, 63, 255), System.Drawing.Color.FromArgb(127, 63, 95, 255), System.Drawing.Color.FromArgb(76, 0, 38, 255), System.Drawing.Color.FromArgb(76, 38, 57, 255), System.Drawing.Color.FromArgb(38, 0, 19, 255), System.Drawing.Color.FromArgb(38, 19, 28, 255),
     System.Drawing.Color.FromArgb(255, 0, 63, 255), System.Drawing.Color.FromArgb(255, 127, 159, 255), System.Drawing.Color.FromArgb(165, 0, 41, 255), System.Drawing.Color.FromArgb(165, 82, 103, 255), System.Drawing.Color.FromArgb(127, 0, 31, 255), System.Drawing.Color.FromArgb(127, 63, 79, 255),
     System.Drawing.Color.FromArgb(76, 0, 19, 255), System.Drawing.Color.FromArgb(76, 38, 47, 255), System.Drawing.Color.FromArgb(38, 0, 9, 255), System.Drawing.Color.FromArgb(38, 19, 23, 255), System.Drawing.Color.FromArgb(84, 84, 84, 255), System.Drawing.Color.FromArgb(118, 118, 118, 255),
     System.Drawing.Color.FromArgb(152, 152, 152, 255), System.Drawing.Color.FromArgb(186, 186, 186, 255), System.Drawing.Color.FromArgb(220, 220, 220, 255), System.Drawing.Color.FromArgb(255, 255, 255, 255)}

    ' standard autocad colours
    '----- 0 - ByBlock - White
    '----- 1 - Red 
    '----- 2 - Yellow
    '----- 3 - Green
    '----- 4 - Cyan
    '----- 5 - Blue
    '----- 6 - Magenta
    '----- 7 - White
    '----- 8
    '----- 9
    '----- 10
    '----- 11
    '----- 12
    '----- 13
    '----- 14
    '----- 15
    '----- 16
    '----- 17
    '----- 18
    '----- 19
    '----- 20
    '----- 21
    '----- 22
    '----- 23
    '----- 24
    '----- 25
    '----- 26
    '----- 27
    '----- 28
    '----- 29
    '----- 30
    '----- 31
    '----- 32
    '----- 33
    '----- 34
    '----- 35
    '----- 36
    '----- 37
    '----- 38
    '----- 39
    '----- 40
    '----- 41
    '----- 42
    '----- 43
    '----- 44
    '----- 45
    '----- 46
    '----- 47
    '----- 48
    '----- 49
    '----- 50
    '----- 51
    '----- 52
    '----- 53
    '----- 54
    '----- 55
    '----- 56
    '----- 57
    '----- 58
    '----- 59
    '----- 60
    '----- 61
    '----- 62
    '----- 63
    '----- 64
    '----- 65
    '----- 66
    '----- 67
    '----- 68
    '----- 69
    '----- 70
    '----- 71
    '----- 72
    '----- 73
    '----- 74
    '----- 75
    '----- 76
    '----- 77
    '----- 78
    '----- 79
    '----- 80
    '----- 81
    '----- 82
    '----- 83
    '----- 84
    '----- 85
    '----- 86
    '----- 87
    '----- 88
    '----- 89
    '----- 90
    '----- 91
    '----- 92
    '----- 93
    '----- 94
    '----- 95
    '----- 96
    '----- 97
    '----- 98
    '----- 99
    '----- 100
    '----- 101
    '----- 102
    '----- 103
    '----- 104
    '----- 105
    '----- 106
    '----- 107
    '----- 108
    '----- 109
    '----- 110
    '----- 111
    '----- 112
    '----- 113
    '----- 114
    '----- 115
    '----- 116
    '----- 117
    '----- 118
    '----- 119
    '----- 120
    '----- 121
    '----- 122
    '----- 123
    '----- 124
    '----- 125
    '----- 126
    '----- 127
    '----- 128
    '----- 129
    '----- 130
    '----- 131
    '----- 132
    '----- 133
    '----- 134
    '----- 135
    '----- 136
    '----- 137
    '----- 138
    '----- 139
    '----- 140
    '----- 141
    '----- 142
    '----- 143
    '----- 144
    '----- 145
    '----- 146
    '----- 147
    '----- 148
    '----- 149
    '----- 150
    '----- 151
    '----- 152
    '----- 153
    '----- 154
    '----- 155
    '----- 156
    '----- 157
    '----- 158
    '----- 159
    '----- 160
    '----- 161
    '----- 162
    '----- 163
    '----- 164
    '----- 165
    '----- 166
    '----- 167
    '----- 168
    '----- 169
    '----- 170
    '----- 171
    '----- 172
    '----- 173
    '----- 174
    '----- 175
    '----- 176
    '----- 177
    '----- 178
    '----- 179
    '----- 180
    '----- 181
    '----- 182
    '----- 183
    '----- 184
    '----- 185
    '----- 186
    '----- 187
    '----- 188
    '----- 189
    '----- 190
    '----- 191
    '----- 192
    '----- 193
    '----- 194
    '----- 195
    '----- 196
    '----- 197
    '----- 198
    '----- 199
    '----- 200
    '----- 201
    '----- 202
    '----- 203
    '----- 204
    '----- 205
    '----- 206
    '----- 207
    '----- 208
    '----- 209
    '----- 210
    '----- 211
    '----- 212
    '----- 213
    '----- 214
    '----- 215
    '----- 216
    '----- 217
    '----- 218
    '----- 219
    '----- 220
    '----- 221
    '----- 222
    '----- 223
    '----- 224
    '----- 225
    '----- 226
    '----- 227
    '----- 228
    '----- 229
    '----- 230
    '----- 231
    '----- 232
    '----- 233
    '----- 234
    '----- 235
    '----- 236
    '----- 237
    '----- 238
    '----- 239
    '----- 240
    '----- 241
    '----- 242
    '----- 243
    '----- 244
    '----- 245
    '----- 246
    '----- 247
    '----- 248
    '----- 249
    '----- 250
    '----- 251
    '----- 252
    '----- 253
    '----- 254
    '----- 255
    Public Shared MyAcadColorMs As System.Drawing.Color() = {System.Drawing.Color.FromArgb(255, 255, 255, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 255, 0, 255), System.Drawing.Color.FromArgb(0, 255, 0, 255), System.Drawing.Color.FromArgb(0, 255, 255, 255), System.Drawing.Color.FromArgb(0, 0, 255, 255),
     System.Drawing.Color.FromArgb(255, 0, 255, 255), System.Drawing.Color.FromArgb(255, 255, 255, 255), System.Drawing.Color.FromArgb(255, 255, 255, 255), System.Drawing.Color.FromArgb(255, 255, 255, 255), System.Drawing.Color.FromArgb(255, 0, 0, 255), System.Drawing.Color.FromArgb(255, 127, 127, 255),
     System.Drawing.Color.FromArgb(165, 0, 0, 255), System.Drawing.Color.FromArgb(165, 82, 82, 255), System.Drawing.Color.FromArgb(127, 0, 0, 255), System.Drawing.Color.FromArgb(127, 63, 63, 255), System.Drawing.Color.FromArgb(76, 0, 0, 255), System.Drawing.Color.FromArgb(76, 38, 38, 255),
     System.Drawing.Color.FromArgb(38, 0, 0, 255), System.Drawing.Color.FromArgb(38, 19, 19, 255), System.Drawing.Color.FromArgb(255, 63, 0, 255), System.Drawing.Color.FromArgb(255, 159, 127, 255), System.Drawing.Color.FromArgb(165, 41, 0, 255), System.Drawing.Color.FromArgb(165, 103, 82, 255),
     System.Drawing.Color.FromArgb(127, 31, 0, 255), System.Drawing.Color.FromArgb(127, 79, 63, 255), System.Drawing.Color.FromArgb(76, 19, 0, 255), System.Drawing.Color.FromArgb(76, 47, 38, 255), System.Drawing.Color.FromArgb(38, 9, 0, 255), System.Drawing.Color.FromArgb(38, 23, 19, 255),
     System.Drawing.Color.FromArgb(255, 127, 0, 255), System.Drawing.Color.FromArgb(255, 191, 127, 255), System.Drawing.Color.FromArgb(165, 82, 0, 255), System.Drawing.Color.FromArgb(165, 124, 82, 255), System.Drawing.Color.FromArgb(127, 63, 0, 255), System.Drawing.Color.FromArgb(127, 95, 63, 255),
     System.Drawing.Color.FromArgb(76, 38, 0, 255), System.Drawing.Color.FromArgb(76, 57, 38, 255), System.Drawing.Color.FromArgb(38, 19, 0, 255), System.Drawing.Color.FromArgb(38, 28, 19, 255), System.Drawing.Color.FromArgb(255, 191, 0, 255), System.Drawing.Color.FromArgb(255, 223, 127, 255),
     System.Drawing.Color.FromArgb(165, 124, 0, 255), System.Drawing.Color.FromArgb(165, 145, 82, 255), System.Drawing.Color.FromArgb(127, 95, 0, 255), System.Drawing.Color.FromArgb(127, 111, 63, 255), System.Drawing.Color.FromArgb(76, 57, 0, 255), System.Drawing.Color.FromArgb(76, 66, 38, 255),
     System.Drawing.Color.FromArgb(38, 28, 0, 255), System.Drawing.Color.FromArgb(38, 33, 19, 255), System.Drawing.Color.FromArgb(255, 255, 0, 255), System.Drawing.Color.FromArgb(255, 255, 127, 255), System.Drawing.Color.FromArgb(165, 165, 0, 255), System.Drawing.Color.FromArgb(165, 165, 82, 255),
     System.Drawing.Color.FromArgb(127, 127, 0, 255), System.Drawing.Color.FromArgb(127, 127, 63, 255), System.Drawing.Color.FromArgb(76, 76, 0, 255), System.Drawing.Color.FromArgb(76, 76, 38, 255), System.Drawing.Color.FromArgb(38, 38, 0, 255), System.Drawing.Color.FromArgb(38, 38, 19, 255),
     System.Drawing.Color.FromArgb(191, 255, 0, 255), System.Drawing.Color.FromArgb(223, 255, 127, 255), System.Drawing.Color.FromArgb(124, 165, 0, 255), System.Drawing.Color.FromArgb(145, 165, 82, 255), System.Drawing.Color.FromArgb(95, 127, 0, 255), System.Drawing.Color.FromArgb(111, 127, 63, 255),
     System.Drawing.Color.FromArgb(57, 76, 0, 255), System.Drawing.Color.FromArgb(66, 76, 38, 255), System.Drawing.Color.FromArgb(28, 38, 0, 255), System.Drawing.Color.FromArgb(33, 38, 19, 255), System.Drawing.Color.FromArgb(127, 255, 0, 255), System.Drawing.Color.FromArgb(191, 255, 127, 255),
     System.Drawing.Color.FromArgb(82, 165, 0, 255), System.Drawing.Color.FromArgb(124, 165, 82, 255), System.Drawing.Color.FromArgb(63, 127, 0, 255), System.Drawing.Color.FromArgb(95, 127, 63, 255), System.Drawing.Color.FromArgb(38, 76, 0, 255), System.Drawing.Color.FromArgb(57, 76, 38, 255),
     System.Drawing.Color.FromArgb(19, 38, 0, 255), System.Drawing.Color.FromArgb(28, 38, 19, 255), System.Drawing.Color.FromArgb(63, 255, 0, 255), System.Drawing.Color.FromArgb(159, 255, 127, 255), System.Drawing.Color.FromArgb(41, 165, 0, 255), System.Drawing.Color.FromArgb(103, 165, 82, 255),
     System.Drawing.Color.FromArgb(31, 127, 0, 255), System.Drawing.Color.FromArgb(79, 127, 63, 255), System.Drawing.Color.FromArgb(19, 76, 0, 255), System.Drawing.Color.FromArgb(47, 76, 38, 255), System.Drawing.Color.FromArgb(9, 38, 0, 255), System.Drawing.Color.FromArgb(23, 38, 19, 255),
     System.Drawing.Color.FromArgb(0, 255, 0, 255), System.Drawing.Color.FromArgb(127, 255, 127, 255), System.Drawing.Color.FromArgb(0, 165, 0, 255), System.Drawing.Color.FromArgb(82, 165, 82, 255), System.Drawing.Color.FromArgb(0, 127, 0, 255), System.Drawing.Color.FromArgb(63, 127, 63, 255),
     System.Drawing.Color.FromArgb(0, 76, 0, 255), System.Drawing.Color.FromArgb(38, 76, 38, 255), System.Drawing.Color.FromArgb(0, 38, 0, 255), System.Drawing.Color.FromArgb(19, 38, 19, 255), System.Drawing.Color.FromArgb(0, 255, 63, 255), System.Drawing.Color.FromArgb(127, 255, 159, 255),
     System.Drawing.Color.FromArgb(0, 165, 41, 255), System.Drawing.Color.FromArgb(82, 165, 103, 255), System.Drawing.Color.FromArgb(0, 127, 31, 255), System.Drawing.Color.FromArgb(63, 127, 79, 255), System.Drawing.Color.FromArgb(0, 76, 19, 255), System.Drawing.Color.FromArgb(38, 76, 47, 255),
     System.Drawing.Color.FromArgb(0, 38, 9, 255), System.Drawing.Color.FromArgb(19, 38, 23, 255), System.Drawing.Color.FromArgb(0, 255, 127, 255), System.Drawing.Color.FromArgb(127, 255, 191, 255), System.Drawing.Color.FromArgb(0, 165, 82, 255), System.Drawing.Color.FromArgb(82, 165, 124, 255),
     System.Drawing.Color.FromArgb(0, 127, 63, 255), System.Drawing.Color.FromArgb(63, 127, 95, 255), System.Drawing.Color.FromArgb(0, 76, 38, 255), System.Drawing.Color.FromArgb(38, 76, 57, 255), System.Drawing.Color.FromArgb(0, 38, 19, 255), System.Drawing.Color.FromArgb(19, 38, 28, 255),
     System.Drawing.Color.FromArgb(0, 255, 191, 255), System.Drawing.Color.FromArgb(127, 255, 223, 255), System.Drawing.Color.FromArgb(0, 165, 124, 255), System.Drawing.Color.FromArgb(82, 165, 145, 255), System.Drawing.Color.FromArgb(0, 127, 95, 255), System.Drawing.Color.FromArgb(63, 127, 111, 255),
     System.Drawing.Color.FromArgb(0, 76, 57, 255), System.Drawing.Color.FromArgb(38, 76, 66, 255), System.Drawing.Color.FromArgb(0, 38, 28, 255), System.Drawing.Color.FromArgb(19, 38, 33, 255), System.Drawing.Color.FromArgb(0, 255, 255, 255), System.Drawing.Color.FromArgb(127, 255, 255, 255),
     System.Drawing.Color.FromArgb(0, 165, 165, 255), System.Drawing.Color.FromArgb(82, 165, 165, 255), System.Drawing.Color.FromArgb(0, 127, 127, 255), System.Drawing.Color.FromArgb(63, 127, 127, 255), System.Drawing.Color.FromArgb(0, 76, 76, 255), System.Drawing.Color.FromArgb(38, 76, 76, 255),
     System.Drawing.Color.FromArgb(0, 38, 38, 255), System.Drawing.Color.FromArgb(19, 38, 38, 255), System.Drawing.Color.FromArgb(0, 191, 255, 255), System.Drawing.Color.FromArgb(127, 223, 255, 255), System.Drawing.Color.FromArgb(0, 124, 165, 255), System.Drawing.Color.FromArgb(82, 145, 165, 255),
     System.Drawing.Color.FromArgb(0, 95, 127, 255), System.Drawing.Color.FromArgb(63, 111, 127, 255), System.Drawing.Color.FromArgb(0, 57, 76, 255), System.Drawing.Color.FromArgb(38, 66, 76, 255), System.Drawing.Color.FromArgb(0, 28, 38, 255), System.Drawing.Color.FromArgb(19, 33, 38, 255),
     System.Drawing.Color.FromArgb(0, 127, 255, 255), System.Drawing.Color.FromArgb(127, 191, 255, 255), System.Drawing.Color.FromArgb(0, 82, 165, 255), System.Drawing.Color.FromArgb(82, 124, 165, 255), System.Drawing.Color.FromArgb(0, 63, 127, 255), System.Drawing.Color.FromArgb(63, 95, 127, 255),
     System.Drawing.Color.FromArgb(0, 38, 76, 255), System.Drawing.Color.FromArgb(38, 57, 76, 255), System.Drawing.Color.FromArgb(0, 19, 38, 255), System.Drawing.Color.FromArgb(19, 28, 38, 255), System.Drawing.Color.FromArgb(0, 63, 255, 255), System.Drawing.Color.FromArgb(127, 159, 255, 255),
     System.Drawing.Color.FromArgb(0, 41, 165, 255), System.Drawing.Color.FromArgb(82, 103, 165, 255), System.Drawing.Color.FromArgb(0, 31, 127, 255), System.Drawing.Color.FromArgb(63, 79, 127, 255), System.Drawing.Color.FromArgb(0, 19, 76, 255), System.Drawing.Color.FromArgb(38, 47, 76, 255),
     System.Drawing.Color.FromArgb(0, 9, 38, 255), System.Drawing.Color.FromArgb(19, 23, 38, 255), System.Drawing.Color.FromArgb(0, 0, 255, 255), System.Drawing.Color.FromArgb(127, 127, 255, 255), System.Drawing.Color.FromArgb(0, 0, 165, 255), System.Drawing.Color.FromArgb(82, 82, 165, 255),
     System.Drawing.Color.FromArgb(0, 0, 127, 255), System.Drawing.Color.FromArgb(63, 63, 127, 255), System.Drawing.Color.FromArgb(0, 0, 76, 255), System.Drawing.Color.FromArgb(38, 38, 76, 255), System.Drawing.Color.FromArgb(0, 0, 38, 255), System.Drawing.Color.FromArgb(19, 19, 38, 255),
     System.Drawing.Color.FromArgb(63, 0, 255, 255), System.Drawing.Color.FromArgb(159, 127, 255, 255), System.Drawing.Color.FromArgb(41, 0, 165, 255), System.Drawing.Color.FromArgb(103, 82, 165, 255), System.Drawing.Color.FromArgb(31, 0, 127, 255), System.Drawing.Color.FromArgb(79, 63, 127, 255),
     System.Drawing.Color.FromArgb(19, 0, 76, 255), System.Drawing.Color.FromArgb(47, 38, 76, 255), System.Drawing.Color.FromArgb(9, 0, 38, 255), System.Drawing.Color.FromArgb(23, 19, 38, 255), System.Drawing.Color.FromArgb(127, 0, 255, 255), System.Drawing.Color.FromArgb(191, 127, 255, 255),
     System.Drawing.Color.FromArgb(82, 0, 165, 255), System.Drawing.Color.FromArgb(124, 82, 165, 255), System.Drawing.Color.FromArgb(63, 0, 127, 255), System.Drawing.Color.FromArgb(95, 63, 127, 255), System.Drawing.Color.FromArgb(38, 0, 76, 255), System.Drawing.Color.FromArgb(57, 38, 76, 255),
     System.Drawing.Color.FromArgb(19, 0, 38, 255), System.Drawing.Color.FromArgb(28, 19, 38, 255), System.Drawing.Color.FromArgb(191, 0, 255, 255), System.Drawing.Color.FromArgb(223, 127, 255, 255), System.Drawing.Color.FromArgb(124, 0, 165, 255), System.Drawing.Color.FromArgb(145, 82, 165, 255),
     System.Drawing.Color.FromArgb(95, 0, 127, 255), System.Drawing.Color.FromArgb(111, 63, 127, 255), System.Drawing.Color.FromArgb(57, 0, 76, 255), System.Drawing.Color.FromArgb(66, 38, 76, 255), System.Drawing.Color.FromArgb(28, 0, 38, 255), System.Drawing.Color.FromArgb(33, 19, 38, 255),
     System.Drawing.Color.FromArgb(255, 0, 255, 255), System.Drawing.Color.FromArgb(255, 127, 255, 255), System.Drawing.Color.FromArgb(165, 0, 165, 255), System.Drawing.Color.FromArgb(165, 82, 165, 255), System.Drawing.Color.FromArgb(127, 0, 127, 255), System.Drawing.Color.FromArgb(127, 63, 127, 255),
     System.Drawing.Color.FromArgb(76, 0, 76, 255), System.Drawing.Color.FromArgb(76, 38, 76, 255), System.Drawing.Color.FromArgb(38, 0, 38, 255), System.Drawing.Color.FromArgb(38, 19, 38, 255), System.Drawing.Color.FromArgb(255, 0, 191, 255), System.Drawing.Color.FromArgb(255, 127, 223, 255),
     System.Drawing.Color.FromArgb(165, 0, 124, 255), System.Drawing.Color.FromArgb(165, 82, 145, 255), System.Drawing.Color.FromArgb(127, 0, 95, 255), System.Drawing.Color.FromArgb(127, 63, 111, 255), System.Drawing.Color.FromArgb(76, 0, 57, 255), System.Drawing.Color.FromArgb(76, 38, 66, 255),
     System.Drawing.Color.FromArgb(38, 0, 28, 255), System.Drawing.Color.FromArgb(38, 19, 33, 255), System.Drawing.Color.FromArgb(255, 0, 127, 255), System.Drawing.Color.FromArgb(255, 127, 191, 255), System.Drawing.Color.FromArgb(165, 0, 82, 255), System.Drawing.Color.FromArgb(165, 82, 124, 255),
     System.Drawing.Color.FromArgb(127, 0, 63, 255), System.Drawing.Color.FromArgb(127, 63, 95, 255), System.Drawing.Color.FromArgb(76, 0, 38, 255), System.Drawing.Color.FromArgb(76, 38, 57, 255), System.Drawing.Color.FromArgb(38, 0, 19, 255), System.Drawing.Color.FromArgb(38, 19, 28, 255),
     System.Drawing.Color.FromArgb(255, 0, 63, 255), System.Drawing.Color.FromArgb(255, 127, 159, 255), System.Drawing.Color.FromArgb(165, 0, 41, 255), System.Drawing.Color.FromArgb(165, 82, 103, 255), System.Drawing.Color.FromArgb(127, 0, 31, 255), System.Drawing.Color.FromArgb(127, 63, 79, 255),
     System.Drawing.Color.FromArgb(76, 0, 19, 255), System.Drawing.Color.FromArgb(76, 38, 47, 255), System.Drawing.Color.FromArgb(38, 0, 9, 255), System.Drawing.Color.FromArgb(38, 19, 23, 255), System.Drawing.Color.FromArgb(84, 84, 84, 255), System.Drawing.Color.FromArgb(118, 118, 118, 255),
     System.Drawing.Color.FromArgb(152, 152, 152, 255), System.Drawing.Color.FromArgb(186, 186, 186, 255), System.Drawing.Color.FromArgb(220, 220, 220, 255), System.Drawing.Color.FromArgb(255, 255, 255, 255)}

    Public Shared Function GetActiveViewPortInfo(ByRef height As Double, ByRef width As Double, ByRef target As Point3d, ByRef viewDir As Vector3d, ByRef viewTwist As Double, ByVal getViewCenter As Boolean) As Boolean
        ' get the editor object
        Dim ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
        'TOOK this out as it crashes in Paperspace
        'ed.UpdateTiledViewportsInDatabase()
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Using t As Transaction = db.TransactionManager.StartTransaction()
            Dim vt As ViewportTable = DirectCast(t.GetObject(db.ViewportTableId, OpenMode.ForRead), ViewportTable)
            Dim btr As ViewportTableRecord = DirectCast(t.GetObject(vt(GSUtil.strActive), OpenMode.ForRead), ViewportTableRecord)
            height = btr.Height
            width = btr.Width
            target = btr.Target
            viewDir = New Vector3d(0, 0, 1) '  btr.ViewDirection
            viewTwist = btr.ViewTwist
            t.Commit()
        End Using
        Return True
    End Function

    Public Shared Sub mpManager_ViewToBeDestroyed(ByVal sender As [Object], ByVal e As ViewEventArgs)
    End Sub

    Public Shared Sub mpManager_ViewWasCreated(ByVal sender As [Object], ByVal e As ViewEventArgs)
    End Sub

    Public Shared Sub mpManager_GsToBeUnloaded(ByVal sender As [Object], ByVal e As EventArgs)
    End Sub

    Public Shared Sub mpManager_ConfigWasModified(ByVal sender As [Object], ByVal e As EventArgs)
    End Sub

    Public Class RubberbandRectangle
        Public Enum PenStyles
            PS_SOLID = 0
            PS_DASH = 1
            PS_DOT = 2
            PS_DASHDOT = 3
            PS_DASHDOTDOT = 4
        End Enum
        Private NULL_BRUSH As Integer = 5
        Private R2_XORPEN As Integer = 7
        Private m_penStyle As PenStyles
        Private BLACK_PEN As Integer = 0

        ' Default contructor - sets member fields
        Public Sub New()
            m_penStyle = PenStyles.PS_DOT
        End Sub

        ' penStyles property get/set.
        Public Property PenStyle() As PenStyles
            Get
                Return m_penStyle
            End Get
            Set(ByVal value As PenStyles)
                m_penStyle = value
            End Set
        End Property

        Public Sub DrawXORRectangle(ByVal grp As Graphics, ByVal startPt As System.Drawing.Point, ByVal endPt As System.Drawing.Point)
            Dim X1 As Integer = startPt.X
            Dim Y1 As Integer = startPt.Y
            Dim X2 As Integer = endPt.X
            Dim Y2 As Integer = endPt.Y
            ' Extract the Win32 HDC from the Graphics object supplied.
            Dim hdc As IntPtr = grp.GetHdc()

            ' Create a pen with a dotted style to draw the border of the
            ' rectangle.
            Dim gdiPen As IntPtr = CreatePen(m_penStyle, 1, BLACK_PEN)

            ' Set the ROP cdrawint mode to XOR.
            SetROP2(hdc, R2_XORPEN)

            ' Select the pen into the device context.
            Dim oldPen As IntPtr = SelectObject(hdc, gdiPen)

            ' Create a stock NULL_BRUSH brush and select it into the device
            ' context so that the rectangle isn't filled.
            Dim oldBrush As IntPtr = SelectObject(hdc, GetStockObject(NULL_BRUSH))

            ' Now XOR the hollow rectangle on the Graphics object with
            ' a dotted outline.
            Rectangle(hdc, X1, Y1, X2, Y2)

            ' Put the old stuff back where it was.
            SelectObject(hdc, oldBrush)
            ' no need to delete a stock object
            SelectObject(hdc, oldPen)
            DeleteObject(gdiPen)
            ' but we do need to delete the pen
            ' Return the device context to Windows.
            grp.ReleaseHdc(hdc)
        End Sub

        ' Use Interop to call the corresponding Win32 GDI functions
        ' Handle to a Win32 device context
        <System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")> _
        Private Shared Function SetROP2(ByVal hdc As IntPtr, ByVal enDrawMode As Integer) As Integer
            ' Drawing mode
        End Function
        ' Pen style from enum PenStyles
        ' Width of pen
        <System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")> _
        Private Shared Function CreatePen(ByVal enPenStyle As PenStyles, ByVal nWidth As Integer, ByVal crColor As Integer) As IntPtr
            ' Color of pen
        End Function
        <System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")> _
        Private Shared Function DeleteObject(ByVal hObject As IntPtr) As Boolean
            ' Win32 GDI handle to object to delete
        End Function
        ' Win32 GDI device context
        <System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")> _
        Private Shared Function SelectObject(ByVal hdc As IntPtr, ByVal hObject As IntPtr) As IntPtr
            ' Win32 GDI handle to object to select
        End Function
        ' Handle to a Win32 device context
        ' x-coordinate of top left corner
        ' y-cordinate of top left corner
        ' x-coordinate of bottom right corner
        <System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")> _
        Private Shared Sub Rectangle(ByVal hdc As IntPtr, ByVal X1 As Integer, ByVal Y1 As Integer, ByVal X2 As Integer, ByVal Y2 As Integer)
            ' y-coordinate of bottm right corner
        End Sub
        <System.Runtime.InteropServices.DllImportAttribute("gdi32.dll")> _
        Private Shared Function GetStockObject(ByVal brStyle As Integer) As IntPtr
            ' Selected from the WinGDI.h BrushStyles enum
        End Function

        ' C# version of Win32 RGB macro
        Private Shared Function RGB(ByVal R As Integer, ByVal G As Integer, ByVal B As Integer) As Integer
            Return (R Or (G << 8) Or (B << 16))
        End Function
    End Class
End Class
'' http://through-the-interface.typepad.com/through_the_interface/2008/06/autocad-net-ver.html
