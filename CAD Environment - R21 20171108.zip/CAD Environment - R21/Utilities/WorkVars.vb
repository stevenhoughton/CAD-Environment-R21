Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.AutoCAD.Utilities

Public Class WorkVars

    Private m_sWorkVarName As String
    Private m_vValue As Object
    Private Const WORKVAR As String = "SKM_WORKING_VARIABLES"

    ' property to set the name...this can only be done
    ' once, then it is read only


    ' property to get the name

    Public Property Name() As String
        Get

            Name = m_sWorkVarName

        End Get
        Set(ByVal Value As String)

            If m_sWorkVarName = "" Then
                m_sWorkVarName = Value
            End If

        End Set
    End Property

    ' property to set the value for the rule...as above
    ' witable until set once, then read only


    ' property to get the value for this rule
    Public Property value() As Object
        Get
            value = m_vValue
        End Get
        Set(ByVal Value As Object)
            If m_vValue Is Nothing Then
                m_vValue = Value
            End If
        End Set
    End Property

    ' class constructor...
    'UPGRADE_NOTE: Class_Initialize was upgraded to Class_Initialize_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Private Sub Class_Initialize_Renamed()

        ' explicitly initialise all our class variables to defualts...
        m_sWorkVarName = ""
        m_vValue = Nothing

    End Sub
    Public Sub New()
        MyBase.New()
        Class_Initialize_Renamed()
    End Sub

    ' calss destructor...
    Protected Overrides Sub Finalize()
        ' don't really need to do anything...
        MyBase.Finalize()
    End Sub

    ' Save will only save a workvar in the current file

    Public Function Save() As Boolean

        Dim pXdict, pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
        Dim iXrecDataType(1) As Int16
        Dim vXrecDataValue(1) As Object
        On Error GoTo ErrorHandler
        ' get a pointer to the extension dictionary...
        'UPGRADE_WARNING: Couldn't resolve default property of object ThisDrawing.Blocks. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        pXdict = ThisDrawingUtilities.Blocks.GetExtensionDictionary
        ' see if our rule dictionary is present...
        pDict = CType(pXdict.GetObject(WORKVAR), AcadDictionary)
        ' check if we got it...
        If pDict Is Nothing Then
            '...not there, so add it in...
            pDict = CType(pXdict.AddObject(WORKVAR, "AcDbDictionary"), AcadDictionary)
        End If
        ' add this xrecord in...
        pXrec = pDict.AddXRecord(Me.Name)
        '...set up our arrays of data...

        iXrecDataType(0) = 300
        'UPGRADE_WARNING: Couldn't resolve default property of object vXrecDataValue(0). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        vXrecDataValue(0) = Me.Name
        iXrecDataType(1) = 301
        'UPGRADE_WARNING: Couldn't resolve default property of object Me.value. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        'UPGRADE_WARNING: Couldn't resolve default property of object vXrecDataValue(1). Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        vXrecDataValue(1) = Me.value

        '...set the data on the xrecord...
        pXrec.SetXRecordData(iXrecDataType, vXrecDataValue)
        ' return true for ok...
        Save = True

BailOut:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found - dictionary entry not found
                ' clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Information.Err.Clear()
                Save = False
                Resume BailOut
        End Select
    End Function

    ' Will only delete WorkVar in current drawing

    Public Function Delete() As Boolean

        Dim pXdict, pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
        Dim iXrecDataType(3) As Int16
        Dim vXrecDataValue(3) As Object
        On Error GoTo ErrorHandler
        ' get a pointer to the extension dictionary...
        'UPGRADE_WARNING: Couldn't resolve default property of object ThisDrawing.Blocks. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        pXdict = ThisDrawingUtilities.Blocks.GetExtensionDictionary
        ' see if our WorkVar dictionary is present...
        pDict = CType(pXdict.GetObject(WORKVAR), AcadDictionary)

        ' check if we got it...

        If pDict Is Nothing Then
            '...not there nothing to delete....
            Delete = False
        Else
            ' add this xrecord in...
            pDict.Remove(Me.Name)
            ' return true for ok...
            Delete = True
        End If

BailOut:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found - dictionary entry not found
                ' clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Information.Err.Clear()
                Delete = False
                Resume BailOut
        End Select
    End Function
End Class