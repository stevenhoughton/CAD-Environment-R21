﻿Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Runtime
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Public Class ScaleUtilities

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    <CommandMethod("Jacobs_SELECTOBJECTSCALEREMOVEOTHERS", (CommandFlags.Modal Or CommandFlags.UsePickSet))> _
    Public Sub RemoveAllButCurrentScale()

        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database = doc.Database
        Dim ed As Editor = doc.Editor

        ' Get the manager object and the list of scales
        Dim ocm As ObjectContextManager = db.ObjectContextManager
        Dim occ As ObjectContextCollection = ocm.GetContextCollection("ACDB_ANNOTATIONSCALES")

        ' Prompt the user for objects to process (or get them
        ' from the pickfirst set)
        Dim pso As New PromptSelectionOptions()
        pso.MessageForAdding = vbLf & "Select annotative objects"
        Dim psr As PromptSelectionResult = ed.GetSelection(pso)
        If psr.Status <> PromptStatus.OK Then
            Return
        End If

        ' Maintain counters of objects modified and scales removed
        Dim objCount As Integer = 0, scaCount As Integer = 0

        ' Use a flag to check when we first modify an object
        Dim scalesRemovedForObject As Boolean = False

        Dim tr As Transaction = doc.TransactionManager.StartTransaction()

        Using tr


            ' If we can't find the current annotation scale in our

            ' dictionary, we have a problem

            If Not occ.HasContext(db.Cannoscale.Name) Then
                Acad_MessageBox("Cannot find current annotation scale.", , , , , , , , LogName)
                Return
            End If

            ' Get the ObjectContext associated with the current
            ' annotation scale

            Dim curCtxt As ObjectContext = occ.GetContext(db.Cannoscale.Name)

            ' Check each selected object
            For Each so As SelectedObject In psr.Value
                ' Open it for read
                Dim id As ObjectId = so.ObjectId
                Dim obj As DBObject = tr.GetObject(id, OpenMode.ForRead)
                ' Check it's annotative and has the current scale
                If obj.Annotative = AnnotativeStates.[True] AndAlso obj.HasContext(curCtxt) Then
                    ' Now we get it for write
                    obj.UpgradeOpen()
                    ' Loop through the various annotation scales in
                    ' the drawing
                    For Each oc As ObjectContext In occ
                        ' If it's on the object but not current
                        ' (for some reason we have to check the name
                        ' rather than oc == curCtxt)
                        If obj.HasContext(oc) AndAlso oc.Name <> db.Cannoscale.Name Then
                            ' Remove it and increment our counter/set our
                            ' flag
                            obj.RemoveContext(oc)
                            scaCount += 1
                            scalesRemovedForObject = True
                        End If
                    Next

                    ' Increment our counter for objects once per pass
                    ' and then reset the flag
                    If scalesRemovedForObject Then
                        objCount += 1
                        scalesRemovedForObject = False
                    End If

                End If
            Next

            tr.Commit()
            ' Report the results

            Acad_MessageBox(scaCount.ToString & " scales removed from " & objCount.ToString & " objects.", , , , , , , True, LogName)

        End Using
    End Sub

    <CommandMethod("Jacobs_LAS")>
    Public Sub Las()

        Dim occ As ObjectContextCollection = ListAllScales()

        For Each oc As ObjectContext In occ
            Dim x As AnnotationScale = TryCast(oc, AnnotationScale)
            If x IsNot Nothing Then
                Acad_MessageBox(x.Name & " " & x.PaperUnits & " " & x.Scale, , , , , , , True, LogName)
            End If
        Next

    End Sub

    Public Function ListAllScales() As ObjectContextCollection

        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database = doc.Database
        Dim ed As Editor = doc.Editor
        Dim ocm As ObjectContextManager = db.ObjectContextManager
        Dim AnnotationScale As AnnotationScale = Nothing
        Dim result As ObjectContextCollection = Nothing

        If ocm IsNot Nothing Then
            ' Now get the Annotation Scaling context collection
            ' (named ACDB_ANNOTATIONSCALES_COLLECTION)
            Dim occ As ObjectContextCollection = ocm.GetContextCollection("ACDB_ANNOTATIONSCALES")
            If occ IsNot Nothing Then
                ' Create a collection to collect the IDs
                'Dim oic As New ObjectIdCollection()

                result = occ



            End If
        End If

        Return result

    End Function


End Class

'End Namespace

