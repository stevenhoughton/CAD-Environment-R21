﻿Imports System
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD
Imports Jacobs.AutoCAD.Utilities
Imports System.IO
Imports Jacobs.Common.Settings

Public Class clsDynamicBlockMod

    Private mDyanmicBlockID As ObjectId = ObjectId.Null

    Private mChangeFailed As Boolean = False

    Private mHasPropertyChangeToDo As Boolean = False
    Private mPropertyChangeName As New ArrayList
    Private mPropertyChangeValue As New ArrayList

    Private mHasAttChangeToDo As Boolean = False
    Private mAttChangeName As New ArrayList
    Private mAttChangeValue As New ArrayList

    Private mInsPt As Point3d = Nothing
    Private mInsPt2 As Point3d = Nothing

    Private mExplodeAfterInsert As Boolean = False

    Private mBlockFileName As String = ""

    Private mLayerInsert As String = "0"

    Private mLayerNameSolid As String = ""
    Private mLayerNameHidden As String = ""
    Private mBlockName As String = ""
    Private mModelSpace As Boolean = True

    Private mScaleX As Double = 1
    Private mScaleY As Double = 1
    Private mScaleZ As Double = 1

    Private mInsertMode As Integer = 0

    Private mRotation As Double = 0

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Public Sub New()
        'Do nothing ATM
        'Possible unesseary Constructor
    End Sub

    Public Sub New(ByVal _InsPt As Point3d, ByVal _BlockFileName As String, ByVal _BlockName As String, _
                                 ByVal _rotation As Double, ByVal _scale As Integer, ByVal _ModelSpace As Boolean, _
                                 ByVal _insertLayer As String, _
                                 Optional ByVal _LayerNameS As String = "", Optional ByVal _LayerNameH As String = "")

        InsPt = _InsPt
        BlockFileName = _BlockFileName
        BlockName = _BlockName
        Rotation = _rotation
        ScaleX = _scale
        ModelSpace = _ModelSpace

        LayerInsert = _insertLayer

        If _LayerNameS <> "" Then
            LayerNameSolid = _LayerNameS
        End If

        If _LayerNameH <> "" Then
            LayerNameHidden = _LayerNameH
        End If

    End Sub

    Public Sub New(ByVal _InsPt As Point3d, ByVal _BlockFileName As String, ByVal _BlockName As String, _
                             ByVal _rotation As Double, ByVal _scaleX As Double, ByVal _scaleY As Double, ByVal _scaleZ As Double, _
                             ByVal _ModelSpace As Boolean, _
                             ByVal _insertLayer As String, _
                             Optional ByVal _LayerNameS As String = "", Optional ByVal _LayerNameH As String = "")

        InsPt = _InsPt
        BlockFileName = _BlockFileName
        BlockName = _BlockName
        Rotation = _rotation
        ScaleX = _scaleX
        ScaleY = _scaleY
        ScaleZ = _scaleZ
        ModelSpace = _ModelSpace

        LayerInsert = _insertLayer

        If _LayerNameS <> "" Then
            LayerNameSolid = _LayerNameS
        End If

        If _LayerNameH <> "" Then
            LayerNameHidden = _LayerNameH
        End If

    End Sub

    Public Property DyanmicBlockID() As ObjectId
        Get
            Return mDyanmicBlockID
        End Get
        Set(ByVal value As ObjectId)
            mDyanmicBlockID = value
        End Set
    End Property

    Public Property InsPt() As Point3d
        Get
            Return mInsPt
        End Get
        Set(ByVal value As Point3d)
            mInsPt = value
        End Set
    End Property

    Public Property InsPt2() As Point3d
        Get
            Return mInsPt2
        End Get
        Set(ByVal value As Point3d)
            mInsPt2 = value
        End Set
    End Property
    Public Property BlockFileName() As String
        Get
            Return mBlockFileName
        End Get
        Set(ByVal value As String)
            mBlockFileName = value
        End Set
    End Property

    Public Property BlockName() As String
        Get
            Return mBlockName
        End Get
        Set(ByVal value As String)
            mBlockName = value
            If mBlockFileName = mBlockName Then
                mInsertMode = 1 'Inser File as block
            Else
                mInsertMode = 0 'Insert Block From With in File
            End If
        End Set
    End Property

    Public Property Rotation() As Double
        Get
            Return mRotation
        End Get
        Set(ByVal value As Double)
            mRotation = value
        End Set
    End Property

    Public Property ScaleX() As Double
        Get
            Return mScaleX
        End Get
        Set(ByVal value As Double)
            mScaleX = value
            mScaleY = value
            mScaleZ = value
        End Set
    End Property

    Public Property ScaleY() As Double
        Get
            Return mScaleY
        End Get
        Set(ByVal value As Double)
            mScaleY = value
        End Set
    End Property

    Public Property ScaleZ() As Double
        Get
            Return mScaleZ
        End Get
        Set(ByVal value As Double)
            mScaleZ = value
        End Set
    End Property

    Public Property ModelSpace() As Boolean
        Get
            Return mModelSpace
        End Get
        Set(ByVal value As Boolean)
            mModelSpace = value
        End Set
    End Property

    Public Property ExplodeAfterInsert() As Boolean
        Get
            Return mExplodeAfterInsert
        End Get
        Set(ByVal value As Boolean)
            mExplodeAfterInsert = value
        End Set
    End Property

    Public Property LayerNameSolid() As String
        Get
            Return mLayerNameSolid
        End Get
        Set(ByVal value As String)
            mLayerNameSolid = value
        End Set
    End Property

    Public Property LayerNameHidden() As String
        Get
            Return mLayerNameHidden
        End Get
        Set(ByVal value As String)
            mLayerNameHidden = value
        End Set
    End Property

    Public Property LayerInsert() As String
        Get
            Return mLayerInsert
        End Get
        Set(ByVal value As String)
            mLayerInsert = value
        End Set
    End Property

    Public Function InsertBlock() As ObjectId

        Dim RetOID As ObjectId = ObjectId.Null

        If mInsertMode = 0 Then
            RetOID = InsertBlockFromFile()
        Else
            RetOID = InsertFileAsBlock()
        End If

        Return RetOID

    End Function

    Private Function InsertFileAsBlock() As ObjectId

        Dim myTransMan As DatabaseServices.TransactionManager
        Dim myTrans As DatabaseServices.Transaction
        Dim myDwg As Document
        Dim myBT As BlockTable
        Dim myBTR As BlockTableRecord = Nothing

        Dim RetOID As ObjectId = ObjectId.Null

        myDwg = Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = myDwg.Editor
        myTransMan = myDwg.TransactionManager
        myTrans = myTransMan.StartTransaction
        myBT = CType(myDwg.Database.BlockTableId.GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), BlockTable)

        If myBT.Has(BlockName) Then

            Using myDwg.LockDocument
                Select Case ModelSpace
                    Case True
                        myBTR = CType(myBT(BlockTableRecord.ModelSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                    Case False
                        myBTR = CType(myBT(BlockTableRecord.PaperSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                End Select

                Dim myBlockRef As New DatabaseServices.BlockReference(InsPt, myBT(BlockName))
                Dim ucsRot As Double

                Dim ucs As Matrix3d = ed.CurrentUserCoordinateSystem
                myBlockRef.TransformBy(ucs)

                If InsPt2 = Nothing Then
                    Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                    Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                    Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                    ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)
                Else
                    Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                    Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                    Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                    ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)

                    Dim Xp1 As Point3d = InsPt.TransformBy(mat)
                    Dim Xp2 As Point3d = InsPt2.TransformBy(mat)
                    Dim ucsRot2 As Double = Vector3d.XAxis.GetAngleTo(Xp1.GetVectorTo(Xp2), Vector3d.ZAxis)

                    ucsRot = ucsRot + ucsRot2
                End If

                'myBlockRef.Layer = LayerInsert
                If LayerInsert <> String.Empty Then

                    Dim LayerTab As LayerTable = DirectCast(myTrans.GetObject(myDwg.Database.LayerTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), LayerTable)
                    If LayerTab.Has(LayerInsert) Then
                        myBlockRef.Layer = LayerInsert
                    Else
                        ed.WriteMessage("Current Drawing is missing Layer at BlockInsert: " & LayerInsert & ", Contact CAD Support" & vbCrLf)
                    End If

                End If


                myBlockRef.Rotation = ucsRot ' + Rotation
                myBlockRef.ScaleFactors = New Geometry.Scale3d(ScaleX, ScaleY, ScaleZ)
                myBTR.AppendEntity(myBlockRef)
                myTrans.AddNewlyCreatedDBObject(myBlockRef, True)

                RetOID = myBlockRef.ObjectId

                If mExplodeAfterInsert Then
                    myBlockRef.ExplodeToOwnerSpace()
                    myBlockRef.Erase()
                    myBlockRef.DisableUndoRecording(False)
                    myBlockRef.DowngradeOpen()
                End If
                myTrans.Commit()
            End Using

        Else

            If Not System.IO.File.Exists(BlockFileName) Then
                Acad_MessageBox(BlockFileName & " not found...", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Dim myDB As Database
                myDB = myDwg.Database
                Try
                    Using myDwg.LockDocument

                        Select Case ModelSpace
                            Case True
                                myBTR = CType(myBT(BlockTableRecord.ModelSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                            Case False
                                myBTR = CType(myBT(BlockTableRecord.PaperSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                        End Select

                        'Insert Block to current drawing
                        Using db As Database = New Database(False, True)

                            db.ReadDwgFile(BlockFileName, IO.FileShare.Read, True, "")

                            BlockName = Path.GetFileNameWithoutExtension(BlockName)

                            Dim id As ObjectId = myDB.Insert(BlockName, db, True)
                            Dim myBlockRef As BlockReference = New BlockReference(New Point3d(mInsPt.X, mInsPt.Y, mInsPt.Z), id)

                            Dim ucsRot As Double

                            Dim ucs As Matrix3d = ed.CurrentUserCoordinateSystem
                            myBlockRef.TransformBy(ucs)

                            If InsPt2 = Nothing Then
                                Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                                Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                                Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                                ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)
                            Else
                                Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                                Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                                Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                                ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)

                                Dim Xp1 As Point3d = InsPt.TransformBy(mat)
                                Dim Xp2 As Point3d = InsPt2.TransformBy(mat)
                                Dim ucsRot2 As Double = Vector3d.XAxis.GetAngleTo(Xp1.GetVectorTo(Xp2), Vector3d.ZAxis)

                                ucsRot = ucsRot + ucsRot2
                            End If

                            myBlockRef.SetDatabaseDefaults(myDB)
                            myBlockRef.ScaleFactors = New Geometry.Scale3d(ScaleX, ScaleY, ScaleZ)

                            'myBlockRef.Layer = LayerInsert
                            If LayerInsert <> String.Empty Then

                                Dim LayerTab As LayerTable = DirectCast(myTrans.GetObject(myDwg.Database.LayerTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), LayerTable)
                                If LayerTab.Has(LayerInsert) Then
                                    myBlockRef.Layer = LayerInsert
                                Else
                                    ed.WriteMessage("Current Drawing is missing Layer at BlockInsert: " & LayerInsert & ", Contact CAD Support" & vbCrLf)
                                End If

                            End If

                            myBlockRef.Rotation = ucsRot ' + Rotation

                            myBTR.AppendEntity(myBlockRef)
                            myTrans.AddNewlyCreatedDBObject(myBlockRef, True)

                            Dim BrBlockTab As BlockTableRecord = CType(myTrans.GetObject(myBlockRef.BlockTableRecord, OpenMode.ForRead), BlockTableRecord)

                            For Each OIDX As ObjectId In BrBlockTab
                                Dim obj As DBObject = OIDX.GetObject(OpenMode.ForRead)
                                If TypeOf obj Is AttributeDefinition Then
                                    Dim Ad As AttributeDefinition = CType(OIDX.GetObject(OpenMode.ForRead), AttributeDefinition)
                                    Dim AR As AttributeReference = New AttributeReference()
                                    AR.SetAttributeFromBlock(Ad, myBlockRef.BlockTransform)
                                    myBlockRef.AttributeCollection.AppendAttribute(AR)
                                    myTrans.AddNewlyCreatedDBObject(AR, True)
                                End If
                            Next
                            RetOID = myBlockRef.ObjectId

                            If mExplodeAfterInsert Then
                                myBlockRef.ExplodeToOwnerSpace()
                                myBlockRef.Erase()
                                myBlockRef.DisableUndoRecording(False)
                                myBlockRef.DowngradeOpen()
                            End If

                            myTrans.Commit()

                        End Using

                    End Using

                Catch ex As Autodesk.AutoCAD.Runtime.Exception
                    Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, , LogName)
                End Try
            End If
        End If
        myTrans.Dispose()
        myTransMan.Dispose()

        DyanmicBlockID = RetOID

        Return RetOID

    End Function

    Private Function InsertBlockFromFile() As ObjectId

        Dim myTransMan As DatabaseServices.TransactionManager
        Dim myTrans As DatabaseServices.Transaction
        Dim myDwg As Document
        Dim myBT As BlockTable
        Dim myBTR As BlockTableRecord = Nothing

        Dim RetOID As ObjectId = Nothing

        myDwg = Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = myDwg.Editor
        myTransMan = myDwg.TransactionManager
        myTrans = myTransMan.StartTransaction
        myBT = CType(myDwg.Database.BlockTableId.GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), BlockTable)

        'check to see if it has been inserted before
        If myBT.Has(BlockName) Then

            Using myDwg.LockDocument
                Select Case ModelSpace
                    Case True
                        myBTR = CType(myBT(BlockTableRecord.ModelSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                    Case False
                        myBTR = CType(myBT(BlockTableRecord.PaperSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                End Select

                Dim myBlockRef As New DatabaseServices.BlockReference(InsPt, myBT(BlockName))
                Dim ucsRot As Double

                Dim ucs As Matrix3d = ed.CurrentUserCoordinateSystem
                myBlockRef.TransformBy(ucs)

                If InsPt2 = Nothing Then
                    Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                    Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                    Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                    ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)
                Else
                    Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                    Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                    Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                    ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)

                    Dim Xp1 As Point3d = InsPt.TransformBy(mat)
                    Dim Xp2 As Point3d = InsPt2.TransformBy(mat)
                    Dim ucsRot2 As Double = Vector3d.XAxis.GetAngleTo(Xp1.GetVectorTo(Xp2), Vector3d.ZAxis)

                    ucsRot = ucsRot + ucsRot2
                End If

                'myBlockRef.Layer = LayerInsert
                If LayerInsert <> String.Empty Then

                    Dim LayerTab As LayerTable = DirectCast(myTrans.GetObject(myDwg.Database.LayerTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), LayerTable)
                    If LayerTab.Has(LayerInsert) Then
                        myBlockRef.Layer = LayerInsert
                    Else
                        ed.WriteMessage("Current Drawing is missing Layer at BlockInsert: " & LayerInsert & ", Contact CAD Support" & vbCrLf)
                    End If

                End If

                myBlockRef.Rotation = ucsRot ' + Rotation
                myBlockRef.ScaleFactors = New Geometry.Scale3d(ScaleX, ScaleY, ScaleZ)
                myBTR.AppendEntity(myBlockRef)
                myTrans.AddNewlyCreatedDBObject(myBlockRef, True)

                RetOID = myBlockRef.ObjectId

                If mExplodeAfterInsert Then
                    myBlockRef.ExplodeToOwnerSpace()
                    myBlockRef.Erase()
                    myBlockRef.DisableUndoRecording(False)
                    myBlockRef.DowngradeOpen()
                End If
                myTrans.Commit()
            End Using

        Else
            If Not System.IO.File.Exists(BlockFileName) Then
                Acad_MessageBox(BlockFileName & " not found...", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Dim myDB As Database
                myDB = myDwg.Database
                Try
                    Using myDwg.LockDocument

                        'Import Block to current drawing
                        Using db As Database = New Database(False, True)

                            db.ReadDwgFile(BlockFileName, IO.FileShare.Read, True, "")

                            Dim Oids As New ObjectIdCollection
                            Using xtr As Transaction = db.TransactionManager.StartTransaction
                                Dim DB_BT As BlockTable = CType(db.BlockTableId.GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), BlockTable)
                                If DB_BT.Has(BlockName) Then
                                    Oids.Add(DB_BT(BlockName))
                                End If
                                xtr.Commit()
                            End Using

                            If Oids.Count > 0 Then
                                Dim iMap As New IdMapping
                                myDB.WblockCloneObjects(Oids, myBT.ObjectId, iMap, DuplicateRecordCloning.Ignore, False)
                            End If

                        End Using

                        'Insert Block
                        If myBT.Has(BlockName) Then

                            Select Case ModelSpace
                                Case True
                                    myBTR = CType(myBT(BlockTableRecord.ModelSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                                Case False
                                    myBTR = CType(myBT(BlockTableRecord.PaperSpace).GetObject(Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTableRecord)
                            End Select

                            Dim myBlockRef As New DatabaseServices.BlockReference(InsPt, myBT(BlockName))
                            Dim ucsRot As Double

                            Dim ucs As Matrix3d = ed.CurrentUserCoordinateSystem
                            myBlockRef.TransformBy(ucs)

                            If InsPt2 = Nothing Then
                                Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                                Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                                Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                                ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)
                            Else
                                Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
                                Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
                                Dim ucsXDir As Point3d = DirectCast(Application.GetSystemVariable("UCSXDIR"), Point3d)
                                ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)

                                Dim Xp1 As Point3d = InsPt.TransformBy(mat)
                                Dim Xp2 As Point3d = InsPt2.TransformBy(mat)
                                Dim ucsRot2 As Double = Vector3d.XAxis.GetAngleTo(Xp1.GetVectorTo(Xp2), Vector3d.ZAxis)

                                ucsRot = ucsRot + ucsRot2
                            End If

                            'myBlockRef.Layer = LayerInsert
                            If LayerInsert <> String.Empty Then

                                Dim LayerTab As LayerTable = DirectCast(myTrans.GetObject(myDwg.Database.LayerTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), LayerTable)
                                If LayerTab.Has(LayerInsert) Then
                                    myBlockRef.Layer = LayerInsert
                                Else
                                    ed.WriteMessage("Current Drawing is missing Layer at BlockInsert: " & LayerInsert & ", Contact CAD Support" & vbCrLf)
                                End If

                            End If

                            myBlockRef.Rotation = ucsRot ' + Rotation
                            myBlockRef.ScaleFactors = New Geometry.Scale3d(ScaleX, ScaleY, ScaleZ)
                            myBTR.AppendEntity(myBlockRef)
                            myTrans.AddNewlyCreatedDBObject(myBlockRef, True)

                            Dim BrBlockTab As BlockTableRecord = CType(myTrans.GetObject(myBlockRef.BlockTableRecord, OpenMode.ForRead), BlockTableRecord)

                            For Each OIDX As ObjectId In BrBlockTab
                                Dim obj As DBObject = OIDX.GetObject(OpenMode.ForRead)
                                If TypeOf obj Is AttributeDefinition Then
                                    Dim Ad As AttributeDefinition = CType(OIDX.GetObject(OpenMode.ForRead), AttributeDefinition)
                                    Dim AR As AttributeReference = New AttributeReference()
                                    AR.SetAttributeFromBlock(Ad, myBlockRef.BlockTransform)
                                    myBlockRef.AttributeCollection.AppendAttribute(AR)
                                    myTrans.AddNewlyCreatedDBObject(AR, True)
                                End If
                            Next

                            RetOID = myBlockRef.ObjectId

                            If mExplodeAfterInsert Then
                                myBlockRef.ExplodeToOwnerSpace()
                                myBlockRef.Erase()
                                myBlockRef.DisableUndoRecording(False)
                                myBlockRef.DowngradeOpen()
                            End If

                            myTrans.Commit()
                        End If

                    End Using

                Catch ex As Autodesk.AutoCAD.Runtime.Exception
                    Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", "")
                End Try
            End If
        End If
        myTrans.Dispose()
        myTransMan.Dispose()

        DyanmicBlockID = RetOID

        Return RetOID

    End Function

    Public WriteOnly Property PropertyChangeName() As String
        Set(ByVal value As String)
            mPropertyChangeName.Add(value.ToUpper)
        End Set
    End Property

    Public WriteOnly Property PropertyChangeValue() As String
        Set(ByVal value As String)
            mPropertyChangeValue.Add(value.ToUpper)
            mHasPropertyChangeToDo = True
        End Set
    End Property

    Public Sub SetStdPropertyEdit(ByVal ProertyType As DynamicModifyStates, ByVal ChangeValue As String, Optional ByVal StateNameOverride As String = "")

        'TODO LATER - expand for other States (If required)
        Select Case ProertyType
            Case DynamicModifyStates.Company_Visibility
                PropertyChangeName = CStr(IIf(StateNameOverride.Length > 0, StateNameOverride, "Visibility"))
            Case DynamicModifyStates.Company_Flip_State
                PropertyChangeName = CStr(IIf(StateNameOverride.Length > 0, StateNameOverride, "Flip state")) '
        End Select

        PropertyChangeValue = ChangeValue

    End Sub

    Public WriteOnly Property AttChangeName() As String
        Set(ByVal value As String)
            mAttChangeName.Add(value.ToUpper)
        End Set
    End Property

    Public WriteOnly Property AttChangeValue() As String
        Set(ByVal value As String)
            mAttChangeValue.Add(value.ToUpper)
            mHasAttChangeToDo = True
        End Set
    End Property

    Public Sub UpdateDisplay()

        If mDyanmicBlockID = ObjectId.Null Then Exit Sub

        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database = doc.Database
        Dim ed As Editor = doc.Editor

        Using doc.LockDocument

            Using Tx As Transaction = db.TransactionManager.StartTransaction()

                Dim bref As BlockReference = TryCast(Tx.GetObject(mDyanmicBlockID, OpenMode.ForWrite), BlockReference)

                If bref.IsDynamicBlock Then

                    If mHasPropertyChangeToDo Then

                        Dim props As DynamicBlockReferencePropertyCollection = bref.DynamicBlockReferencePropertyCollection

                        For Each prop As DynamicBlockReferenceProperty In props

                            If mPropertyChangeName.Contains(prop.PropertyName.ToUpper) Then

                                Dim FoundIndex As Integer = mPropertyChangeName.IndexOf(prop.PropertyName.ToUpper)

                                If FoundIndex > -1 Then

                                    If IsNumeric(mPropertyChangeValue.Item(FoundIndex)) = True Then
                                        prop.Value = CType(mPropertyChangeValue.Item(FoundIndex), Double)
                                    Else
                                        prop.Value = mPropertyChangeValue.Item(FoundIndex)
                                    End If

                                End If

                            End If

                        Next

                    End If

                    If mHasAttChangeToDo Then

                        If bref.AttributeCollection.Count > 0 Then

                            For Each AttID As ObjectId In bref.AttributeCollection

                                Dim AttObj As Object = Tx.GetObject(AttID, OpenMode.ForRead)

                                Dim ar As AttributeReference = CType(AttObj, AttributeReference)

                                If mAttChangeName.Contains(ar.Tag.ToUpper) Then

                                    Dim FoundIndex As Integer = mAttChangeName.IndexOf(ar.Tag.ToUpper)

                                    If FoundIndex > -1 Then

                                        ar.UpgradeOpen()
                                        ar.TextString = mAttChangeValue(FoundIndex).ToString

                                        Dim WDB As Database = HostApplicationServices.WorkingDatabase
                                        HostApplicationServices.WorkingDatabase = db

                                        ar.AdjustAlignment(db)

                                        HostApplicationServices.WorkingDatabase = WDB

                                        ar.DowngradeOpen()

                                    End If

                                End If

                            Next

                        End If

                    End If

                End If

                Tx.Commit()

            End Using

        End Using

    End Sub


End Class
