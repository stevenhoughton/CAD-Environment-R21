Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings

Public Module RuleAccessors

    'Public Class RuleAccessors

    'Dim DebugMode As Boolean

    ' Private ??? or Public
    Public m_crules As Collection

    ' constant for dictionary name on the symbol tables
    Private Const RULES As String = "SKM_RULES"

    '------------------------------------------------------------------------------
    '
    ' Rules
    '
    ' NOTE: Rules can be retrieved from other files but they can only be saved
    '       and updated in the current file - by the content creation wizard
    '       or the configuration switcher. One rule can be retrieved from the
    '       current file and that is the CLIENT rule.
    '
    '------------------------------------------------------------------------------
    Public Function RulesInitialize(Optional ByRef sExternalDwgName As String = "") As Boolean

        Dim pExtDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pAxDoc As Autodesk.AutoCAD.Interop.Common.AxDbDocument
        Dim pXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
        Dim pObj As Autodesk.AutoCAD.Interop.Common.AcadObject

        On Error GoTo ErrorHandler

        If sExternalDwgName = "" Then

            ' see if the extension dictionary is there off the text styles table...
            If Not ThisDrawingUtilities.Blocks.HasExtensionDictionary Then
                ' we haven't been here before (and neither has anything else for that matter)
                ' so just bail...nothing to do
                RulesInitialize = False
                Exit Function
            Else
                ' it's got an ext. dict., so get it
                pExtDict = ThisDrawingUtilities.Blocks.GetExtensionDictionary
            End If

            ' got an extension dictionary, so see if our dictionary is present...

            pDict = CType(pExtDict.GetObject(RULES), AcadDictionary)

            On Error Resume Next

            If Err.Number = 5 Then
                Acad_MessageBox(Err.Description, "TitleBlockInserter Generated Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
            End If

            On Error GoTo ErrorHandler
        Else

            If IsMasterFile() = True Then

                Acad_MessageBox("Master File Detected in Rules Initialize...", , , , , , , True, logName)
                RulesInitialize = True
                Exit Function

            Else

                ' got the optional external drawing file name
                ' create a new pristine dbase...
                pAxDoc = New Autodesk.AutoCAD.Interop.Common.AxDbDocument

                ' try and read our drawing into the newly constructed dbase...
                pAxDoc.Open(sExternalDwgName)

                ' get a pointer to the extension dictionary...
                If Not pAxDoc.Blocks.HasExtensionDictionary Then
                    ' we haven't been here before (and neither has anything else for that matter)
                    ' so just bail...nothing to do
                    RulesInitialize = False
                    Exit Function
                End If
                ' extension dict. present so get a pointer to it...
                pDict = pAxDoc.Blocks.GetExtensionDictionary

            End If


        End If

        ' if we get here then the blocks table has AN extension dictionary
        ' initialise our collection...
        m_crules = New Collection
        ' if we get here, the extension dictionary is present
        ' and our dictionary containing our "rule" xrecords is there,
        ' so loop them all and add them to our collection
        '    For Each pXrec In pDict
        Dim i As Integer
        Dim pRule As Rule
        For Each pObj In pDict

            'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
            If TypeOf pObj Is Autodesk.AutoCAD.Interop.Common.AcadXRecord Then

                '    If pObj.GetType Is GetType(AcadXRecord) Then
                pXrec = CType(pObj, AcadXRecord)

                ' get the xrecord's data...
                Dim vXrecDataType As Object = Nothing
                Dim vXrecDataValue As Object = Nothing
                pXrec.GetXRecordData(vXrecDataType, vXrecDataValue)

                '' cast to working types
                Dim types() As Int16 = DirectCast(vXrecDataType, Int16())
                Dim values() As Object = DirectCast(vXrecDataValue, Object())

                ' create a new instance of a rule object...
                pRule = New Rule

                ' set the name
                pRule.RuleID = pXrec.Name

                If values IsNot Nothing Then
                    ' set the description...
                    pRule.Description = values(0).ToString
                    ' set the value...
                    pRule.value = values(1).ToString

                    ' set the table code
                    pRule.TableCode = CShort(values(2))

                    pRule.DlgCode = CShort(values(3))

                Else
                    pRule.Description = String.Empty
                    pRule.value = String.Empty
                    pRule.TableCode = 0
                    pRule.DlgCode = 0
                End If

                ' add the rule to the collection
                m_crules.Add(pRule, pRule.RuleID)

            End If

        Next pObj

        RulesInitialize = True

BailOutHere:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476
                ' Key not found
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                RulesInitialize = False
                Resume BailOutHere
            Case -2145386302
                ThisDrawingUtilities.SendCommand(Chr(27))
                ' Lock Change in Progress
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                RulesInitialize = False
                Acad_MessageBox("This lock error can be minimised by locking your viewports", , , , , , , True, logName)
                Resume BailOutHere
            Case -2145386390
                ' No Drawing database
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                RulesInitialize = False

                Acad_MessageBox("***********************************************************************", , , , , , , True, logName)
                Acad_MessageBox("This AutoCAD Install is corrupt. Contact your local IS Group.", , , , , , , True, logName)
                Acad_MessageBox("The AutoCAD Environment R21 will not work on this machine until AutoCAD is repaired.", , , , , , , True, logName)
                Acad_MessageBox("***********************************************************************", , , , , , , True, logName)

                Resume BailOutHere

            Case -2147467259
                ' WTF ? NFI ?
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                RulesInitialize = False
                Resume BailOutHere

            Case -2145386303
                ' Lock change in process - caused when ChangedSystemVariable "CvPORT" is called
                ' clear the error
                Information.Err.Clear()
                ' bail out as we haven't been here before
                RulesInitialize = False
                Resume BailOutHere

            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                RulesInitialize = False
                Resume BailOutHere
        End Select

    End Function

    Public Function RulesCount() As Integer

        RulesCount = CShort(m_crules.Count())

    End Function

    Public Function GetRule(ByVal sRuleID As String, Optional ByRef sExternalDwgName As String = "") As Rule
        '' Dim RuleAccessors As New RuleAccessors

        Dim pRule As Rule = Nothing

        Dim pAxDoc As Autodesk.AutoCAD.Interop.Common.AxDbDocument
        Dim pAxXdict, pAxDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pAxXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
        Dim vXrecDataType As Object = Nothing
        Dim vXrecDataValue As Object = Nothing
        Dim pObj As Autodesk.AutoCAD.Interop.Common.AcadObject

        On Error GoTo ErrorHandler

        ' The config Name must live in this drawing....
        ' If no other drawing is specified look in this one first

        If sExternalDwgName = "" Then

            If RulesInitialize() Then
                For Each pRule In m_crules
                    If UCase(pRule.RuleID) = UCase(sRuleID) Then
                        Return pRule
                        Exit Function
                    End If
                Next

            End If

        Else

            ' Else a drawing name has been specified...and it exists
            ' And it's not a Master File...

            If System.IO.File.Exists(sExternalDwgName) Or
                    IsMasterFile() = True Then

                If RulesInitialize(sExternalDwgName) Then ' Read/Initialize the rules in the ANOTHER file
                    For Each pRule In m_crules
                        If UCase(pRule.RuleID) = UCase(sRuleID) Then
                            Return pRule
                            Exit Function
                        End If
                    Next pRule
                End If

                ' got the optional external drawing file name
                ' create a new pristine dbase...
                pAxDoc = New Autodesk.AutoCAD.Interop.Common.AxDbDocument

                ' try and read our drawing into the newly constructed dbase...
                pAxDoc.Open(sExternalDwgName)

                ' get a pointer to the extension dictionary...
                If Not pAxDoc.Blocks.HasExtensionDictionary Then
                    ' no extension, so no rules present...
                    '' bail out
                    GetRule = Nothing
                    Return Nothing
                    Exit Function
                End If

                ' extension dict. present so get a pointer to it...
                pAxXdict = pAxDoc.Blocks.GetExtensionDictionary

                ' if we get here then the blocks table has AN extension dictionary
                ' hanging off it, so try and get our dictionary...
                pAxDict = CType(pAxXdict.GetObject(RULES), AcadDictionary)

                '...got the dictionary, so loop it looking for our entry
                For Each pObj In pAxDict

                    'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
                    If TypeOf pObj Is Autodesk.AutoCAD.Interop.Common.AcadXRecord Then

                        ' If pObj.GetType Is GetType(AcadXRecord) Then

                        pAxXrec = CType(pObj, AcadXRecord)
                        If UCase(pAxXrec.Name) = UCase(sRuleID) Then
                            ' got our xrecord we're looking for, so get it's data...
                            pAxXrec.GetXRecordData(vXrecDataType, vXrecDataValue)

                            '' cast to working types
                            Dim types() As Int16 = DirectCast(vXrecDataType, Int16())
                            Dim values() As Object = DirectCast(vXrecDataValue, Object())

                            ' construct a new rule object
                            pRule = New Rule
                            pRule.RuleID = pAxXrec.Name

                            pRule.Description = values(0).ToString()

                            pRule.value = values(1).ToString()

                            pRule.TableCode = CShort(values(2))

                            pRule.DlgCode = CShort(values(3))
                            ' return our new rule
                            GetRule = pRule
                            ' bail out
                            Return pRule
                            Exit Function
                        End If
                    End If
                Next pObj

            Else

                Acad_MessageBox("The name " & sExternalDwgName & " has been specified but does not exist.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                GetRule = Nothing
                ' bail out
                Return Nothing
                Exit Function

            End If

        End If

        '' if we get here, everything's failed, so return nothing to be safe
        GetRule = Nothing
        Return Nothing

BailOut:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found - dictionary entry not found
                ' clear the error
                Information.Err.Clear()
                GetRule = Nothing
                pAxDoc = Nothing
                Resume BailOut
            Case -2147467259 ' Error HRESULT E_FAIL has been returned from a call to a COM component.
                ' clear the error
                Information.Err.Clear()
                GetRule = Nothing
                pAxDoc = Nothing
                ThisDrawingUtilities.Utility.Prompt(vbCrLf & "Error HRESULT E_FAIL has been returned from a call to a COM component." & vbCrLf)
                ThisDrawingUtilities.Utility.Prompt(vbCrLf & "RuleID: " & sRuleID & vbCrLf)
                ThisDrawingUtilities.Utility.Prompt(vbCrLf & "DrawingName: " & sExternalDwgName & vbCrLf)
                Resume BailOut

            Case -2145386390 ' Database not found
                ' clear the error
                Information.Err.Clear()
                GetRule = Nothing
                pAxDoc = Nothing
                Acad_MessageBox("***********************************************************************")
                Acad_MessageBox("This AutoCAD Install is corrupt. Contact your local IS Group.")
                Acad_MessageBox("The AutoCAD Environment R21 will not work on this machine until AutoCAD is repaired.")
                Acad_MessageBox("***********************************************************************")
                Resume BailOut
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                GetRule = Nothing
                pAxDoc = Nothing
                Resume BailOut
        End Select
    End Function

    Public Function GetAllRules() As Collection

        If m_crules Is Nothing Then
            'UPGRADE_NOTE: Object GetAllRules may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
            GetAllRules = Nothing
        Else
            GetAllRules = m_crules
        End If

    End Function

    ' The delete rule function only deletes rules in the current drawing
    ' Just in case we need to delete the CLIENT rule
    Public Function DeleteRule(ByVal sName As String) As Boolean

        On Error GoTo ErrorHandler

        If m_crules Is Nothing Then
            DeleteRule = False
            Exit Function
        ElseIf m_crules.Count() = 0 Then
            DeleteRule = False
            Exit Function
        End If

        If HasRule(sName) Then
            'delete it
            m_crules.Remove(sName)
            DeleteRule = True
        Else
            ' no object of the name passed in, so return failure
            DeleteRule = False
        End If

BailOutHere:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case Else
                Information.Err.Clear()
                DeleteRule = False
                Resume BailOutHere
        End Select

    End Function

    Public Function AddRule(ByVal sName As String, ByVal vValue As Object, ByVal sDesc As String, ByVal sDglCode As String, ByVal sTblCode As String) As Rule

        Dim pRule As Rule

        On Error GoTo ErrorHandler
        ' create a new instance of our Rule...
        pRule = New Rule

        ' set the values for the object...

        pRule.RuleID = sName
        pRule.value = CStr(vValue)
        pRule.Description = sDesc
        pRule.TableCode = CInt(sTblCode)
        pRule.DlgCode = CInt(sDglCode)

        pRule.Save()

        '' let everyone know we are partially configured
        If String.Compare(sName, "FULLCONFIGNAME", True) = 0 Then
            ConfigurationEvents.RaiseConfiguredEvent()
        End If

BailOutHere:
        AddRule = pRule
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found
                ' clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                AddRule = Nothing
                Resume BailOutHere
        End Select
    End Function

    Public Function HasRule(ByVal sRuleID As String, Optional ByRef sExternalDwgName As String = "") As Boolean

        Dim pRule As Rule
        Dim pAxDoc As Autodesk.AutoCAD.Interop.Common.AxDbDocument
        Dim pAxXdict, pAxDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pAxXrec As Autodesk.AutoCAD.Interop.Common.AcadXRecord
        Dim pObj As Autodesk.AutoCAD.Interop.Common.AcadObject

        On Error GoTo Error_Handler

        If sExternalDwgName = "" Then
            If RulesInitialize() = True Then
                For Each pRule In m_crules
                    If UCase(pRule.RuleID) = UCase(sRuleID) Then
                        HasRule = True
                        Exit Function
                    End If
                Next pRule
            Else
                HasRule = False
            End If
        Else
            pAxDoc = New Autodesk.AutoCAD.Interop.Common.AxDbDocument
            pAxDoc.Open(sExternalDwgName)
            If Not pAxDoc.Blocks.HasExtensionDictionary Then
                HasRule = False
                Exit Function
            End If
            pAxXdict = pAxDoc.Blocks.GetExtensionDictionary
            pAxDict = CType(pAxXdict.GetObject(RULES), AcadDictionary)
            For Each pObj In pAxDict

                If TypeOf pObj Is Autodesk.AutoCAD.Interop.Common.AcadXRecord Then

                    pAxXrec = CType(pObj, AcadXRecord)
                    If UCase(pAxXrec.Name) = UCase(sRuleID) Then
                        HasRule = True
                        Exit Function
                    End If
                End If
            Next pObj
        End If

        HasRule = False

BailOut:
        Exit Function

Error_Handler:
        Select Case Err.Number
            Case -2145386476
                Information.Err.Clear()
                HasRule = False
                Resume BailOut
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                HasRule = False
                Resume BailOut
        End Select

    End Function

    Sub RemoveRule(ByRef sRuleID As String)
        Dim rRuleToDelete As Rule

        rRuleToDelete = GetRule(sRuleID)

        If Not rRuleToDelete Is Nothing Then
            rRuleToDelete.Delete()
        End If

    End Sub

    Public Function RecordDglRule(ByVal sName As String, ByVal vValue As Object) As Rule

        Dim pRule As Rule
        Dim rTempRule As Rule

        ' enable error handler...
        On Error GoTo ErrorHandler

        ' create a new instance of our Rule...

        rTempRule = GetRule(sName)

        If rTempRule IsNot Nothing Then

            pRule = GetRule(sName & "-DlgBox")
            If pRule IsNot Nothing Then
                RemoveRule((sName & "-DlgBox"))
            End If

            pRule = New Rule

            ' set the values for the object...
            pRule.RuleID = sName & "-DlgBox"

            pRule.value = CStr(vValue)
            pRule.Description = rTempRule.Description
            pRule.TableCode = rTempRule.TableCode
            pRule.DlgCode = rTempRule.DlgCode

            pRule.Save()

            RecordDglRule = pRule

        Else

            RecordDglRule = rTempRule
        End If

BailOutHere:
        Exit Function

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' Key not found
                ' clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                Return Nothing
                Resume BailOutHere
        End Select

    End Function

    Public Function GetruleValue(ByVal sRuleID As String, Optional ByRef sDefault As String = "", Optional ByRef bIgnoreOverride As Boolean = False, Optional ByRef bLookBack As Boolean = False) As String

        Dim pRule As Rule
        Dim iLevelCtr As Integer
        Dim iCurrentLevel As Integer
        Dim fName As String
        Dim sCfgLevel As String
        Dim sFullCfgName As String
        Dim bTestConfig As Boolean

        If ThisDrawingIsConfigured() Then
            If bLookBack = False Then
                If bIgnoreOverride = False Then
                    pRule = GetRule(sRuleID & "-DlgBox")
                    If pRule IsNot Nothing Then
                        GetruleValue = pRule.value
                        Exit Function
                    Else
                        pRule = GetRule(sRuleID)
                        If pRule IsNot Nothing Then
                            GetruleValue = pRule.value
                            Exit Function
                        Else
                            GetruleValue = sDefault
                        End If
                    End If
                Else
                    pRule = GetRule(sRuleID)
                    If pRule IsNot Nothing Then
                        GetruleValue = pRule.value
                        Exit Function
                    Else
                        GetruleValue = sDefault
                    End If
                End If

            Else
                If bIgnoreOverride = False Then
                    pRule = GetRule(sRuleID & "-DlgBox")
                    If pRule IsNot Nothing Then
                        GetruleValue = pRule.value
                        Exit Function
                    Else
                        pRule = GetRule(sRuleID)
                        If pRule IsNot Nothing Then
                            GetruleValue = pRule.value
                            Exit Function
                        End If
                    End If
                Else
                    pRule = GetRule(sRuleID)
                    If pRule IsNot Nothing Then
                        GetruleValue = pRule.value
                        Exit Function
                    End If
                End If

                ' Ok - Couldn't find it in this drawing so look back
                pRule = GetRule("FULLCONFIGNAME")

                If pRule IsNot Nothing Then
                    If IsMasterFile() = True Then

                        Acad_MessageBox("Special File Skip - looking back", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                    Else
                        If IsThisAnOldConfigName() = True Then

                            sFullCfgName = GetRule("FULLCONFIGNAME").value
                            sCfgLevel = GetRule("CONFIGLEVEL").value

                            If sFullCfgName Like "T@*" Then
                                bTestConfig = True
                            Else
                                bTestConfig = False
                            End If

                            Select Case UCase(sCfgLevel)
                                Case "CLIENT"
                                    iCurrentLevel = 4
                                Case "OFFICE"
                                    iCurrentLevel = 3
                                Case "DISCIPLINE"
                                    iCurrentLevel = 2
                                Case "BUSINESS UNIT"
                                    iCurrentLevel = 1
                                Case "CORPORATE"
                                    iCurrentLevel = 0
                            End Select

                            For iLevelCtr = iCurrentLevel To 0 Step -1
                                fName = ""
                                If UCase(Split(sFullCfgName, "-")(iLevelCtr)) <> "NONE" Then
                                    If bTestConfig = True And iLevelCtr = 0 Then
                                        fName = Settings.Manager.AE.ConfigurationExtractionPathPrefix & sFullCfgName & "\Settings\" & Right(Split(sFullCfgName, "-")(iLevelCtr), Len(Split(sFullCfgName, "-")(iLevelCtr)) - 2) & ".dwt"
                                    Else
                                        fName = Settings.Manager.AE.ConfigurationExtractionPathPrefix & sFullCfgName & "\Settings\" & Split(sFullCfgName, "-")(iLevelCtr) & ".dwt"
                                    End If
                                End If
                                If fName <> "" Then
                                    If System.IO.File.Exists(fName) Then
                                        pRule = GetRule(sRuleID, fName)
                                        If pRule IsNot Nothing Then
                                            GetruleValue = pRule.value
                                            Exit Function
                                        End If
                                    End If
                                End If
                            Next  ' Go and look at the next level template

                        Else
                            '' New Configs only look back to Client and Corporate levels

                            Acad_MessageBox("New Config Check Client then corp", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

                            '' Look in client level first

                            fName = Settings.Manager.AE.ClientsConfigurationPath.CombinePath("Settings", GetruleValue("FULLCONFIGNAME") & ".dwg")
                            If System.IO.File.Exists(fName) Then
                                pRule = GetRule(sRuleID, fName)
                                If pRule Is Nothing Then
                                    '' Check Corporate level
                                    fName = Settings.Manager.AE.AEBundleContents.CombinePath("Tools.dwg")
                                    If pRule IsNot Nothing Then
                                        GetruleValue = pRule.value
                                        Exit Function
                                    End If
                                Else
                                    GetruleValue = pRule.value
                                End If
                            End If


                        End If

                    End If

                End If
            End If

        End If

        GetruleValue = sDefault

    End Function
End Module


