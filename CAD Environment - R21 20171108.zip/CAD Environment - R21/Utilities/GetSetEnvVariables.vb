﻿Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Runtime
Imports System.Runtime.InteropServices 'for DllImport()
Imports System.Security
Imports System.Text.StringBuilder
Imports System.Reflection.Assembly

Public Class vbvlClass

    ''' <summary>
    ''' Use P/Invoke for acedGetEnv 
    ''' </summary>
    ''' <param name="strEnvironmentName"></param>
    ''' <param name="stbReturnValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <System.Security.SuppressUnmanagedCodeSecurity(), DllImport("acCore.dll", _
    CharSet:=CharSet.Auto, CallingConvention:=CallingConvention.Cdecl, EntryPoint:="acedGetEnv")> _
    Private Shared Function acedGetEnv(ByVal strEnvironmentName As String, ByVal stbReturnValue As System.Text.StringBuilder) As Integer
    End Function

    ''' <summary>
    ''' Use P/Invoke for acedSetEnv 
    ''' </summary>
    ''' <param name="strEnvironmentName"></param>
    ''' <param name="stbNewValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <System.Security.SuppressUnmanagedCodeSecurity(), DllImport("acCore.dll", _
    CharSet:=CharSet.Auto, CallingConvention:=CallingConvention.Cdecl, EntryPoint:="acedSetEnv")> _
    Private Shared Function acedSetEnv(ByVal strEnvironmentName As String, ByVal stbNewValue As System.Text.StringBuilder) As Integer
    End Function

    ''' <summary>
    ''' Get and Set environment variables using th P/Evoke
    ''' </summary>
    ''' <param name="rbfEnvironmentName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <LispFunction("GetEnvironment")> _
    Public Shared Function GetEnvironment(ByVal rbfEnvironmentName As ResultBuffer) As ResultBuffer
        Dim rbfReturn As New ResultBuffer
        Dim arrEnvironmentName As TypedValue() = rbfEnvironmentName.AsArray
        Dim strEnvironmentName As String = arrEnvironmentName(0).Value.ToString
        Dim stbReturn As New System.Text.StringBuilder(1024)
        Try
            acedGetEnv(strEnvironmentName, stbReturn)
            rbfReturn.Add(New TypedValue(&H138D, stbReturn.ToString))
        Catch Ex As Exception
            rbfReturn.Add(New TypedValue(&H138D, "Error " & Ex.Message))
        End Try
        Return rbfReturn
    End Function

    ''' <summary>
    ''' Overload GetEnvironment function to accept and return strings 
    ''' </summary>
    ''' <param name="strEnvironmentName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetEnvironment(ByVal strEnvironmentName As String) As String
        Dim stbReturn As New System.Text.StringBuilder(2048)
        Try
            acedGetEnv(strEnvironmentName, stbReturn)
            Return stbReturn.ToString
        Catch Ex As Exception
            Return "Error " & Ex.Message
        End Try
    End Function

    ''' <summary>
    ''' SetEnvironment function to accept and return result buffers
    ''' </summary>
    ''' <param name="rbfEnvironmentName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <LispFunction("SetEnvironment")> _
    Public Shared Function SetEnvironment(ByVal rbfEnvironmentName As ResultBuffer) As ResultBuffer
        Dim rbfReturn As New ResultBuffer
        Try
            Dim arrEnvironmentName As TypedValue() = rbfEnvironmentName.AsArray
            Dim strEnvironmentName As String = arrEnvironmentName(0).Value.ToString
            Dim strNewValue As String = arrEnvironmentName(1).Value.ToString
            Dim stbNewValue As New System.Text.StringBuilder(1024)
            stbNewValue.Append(strNewValue)
            acedSetEnv(strEnvironmentName, stbNewValue)
            rbfReturn.Add(New TypedValue(&H138D, stbNewValue.ToString))
        Catch Ex As Exception
            rbfReturn.Add(New TypedValue(&H138D, "Error " & Ex.Message))
        End Try
        Return rbfReturn
    End Function

    ''' <summary>
    ''' Overload SetEnvironment function to accept and return strings
    ''' </summary>
    ''' <param name="strEnvironmentName"></param>
    ''' <param name="strNewValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function SetEnvironment(ByVal strEnvironmentName As String, ByVal strNewValue As String) As String
        Try
            Dim stbNewValue As New System.Text.StringBuilder(2048)
            stbNewValue.Append(strNewValue)
            acedSetEnv(strEnvironmentName, stbNewValue)
            Return "OK"
        Catch Ex As Exception
            Return "Error " & Ex.Message
        End Try
    End Function

    '' Sample Get and set application variables
    '' Get the current value from a system variable
    '  Dim nMaxSort As Integer = Application.GetSystemVariable("MAXSORT")
    '' Set system variable to new value
    '  Application.SetSystemVariable("MAXSORT", 100)

End Class




