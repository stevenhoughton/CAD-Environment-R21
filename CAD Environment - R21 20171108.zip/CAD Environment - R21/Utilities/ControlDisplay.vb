﻿Public Module ControlDisplay

    Public Sub XEnabled(ByVal WhichControl As Panel, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Enabled = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XEnabled(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XEnabled(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XEnabled(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XEnabled(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XEnabled(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XEnabled(ByVal WhichControl As GroupBox, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Enabled = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XEnabled(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XEnabled(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XEnabled(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XEnabled(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XEnabled(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XEnabled(ByVal WhichControl As TabPage, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Enabled = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XEnabled(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XEnabled(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XEnabled(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XEnabled(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XEnabled(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XEnabled(ByVal WhichControl As ComboBox, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Enabled = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XEnabled(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XEnabled(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XEnabled(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XEnabled(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XEnabled(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XEnabled(ByVal WhichControl As Label, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Enabled = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XEnabled(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XEnabled(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XEnabled(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XEnabled(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XEnabled(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XVisible(ByVal WhichControl As Panel, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Visible = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XVisible(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XVisible(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XVisible(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XVisible(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XVisible(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XVisible(ByVal WhichControl As GroupBox, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Visible = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XVisible(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XVisible(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XVisible(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XVisible(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XVisible(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XVisible(ByVal WhichControl As TabPage, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Visible = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XVisible(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XVisible(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XVisible(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XVisible(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XVisible(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XVisible(ByVal WhichControl As ComboBox, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Visible = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XVisible(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XVisible(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XVisible(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XVisible(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XVisible(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub

    Public Sub XVisible(ByVal WhichControl As Label, ByVal Value As Boolean)
        For Each Ctrl As Windows.Forms.Control In WhichControl.Controls
            Ctrl.Visible = Value
            If Ctrl.Controls.Count > 0 Then
                If TypeOf Ctrl Is GroupBox Then
                    XVisible(CType(Ctrl, GroupBox), Value)
                ElseIf TypeOf Ctrl Is Panel Then
                    XVisible(CType(Ctrl, Panel), Value)
                ElseIf TypeOf Ctrl Is TabPage Then
                    XVisible(CType(Ctrl, TabPage), Value)
                ElseIf TypeOf Ctrl Is ComboBox Then
                    XVisible(CType(Ctrl, ComboBox), Value)
                ElseIf TypeOf Ctrl Is Label Then
                    XVisible(CType(Ctrl, Label), Value)
                End If
            End If
        Next
    End Sub
End Module
