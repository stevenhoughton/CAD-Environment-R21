﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Collections
Imports System.IO
Imports System.Diagnostics
Imports System.Windows.Forms

Namespace DwgView
    Public NotInheritable Class BlockViewExtensionMethods
        Private Sub New()
        End Sub

        '<System.Runtime.CompilerServices.Extension()> _
        Public Shared Sub DisposeItems(Of T As IDisposable)(ByVal items As IEnumerable(Of T))
            DisposeItems(items.GetEnumerator())
        End Sub

        Private Shared Sub DisposeItems(ByVal e As IEnumerator)
            While e.MoveNext()
                Try
                    Dim disposable As IDisposable = TryCast(e.Current, IDisposable)
                    If disposable IsNot Nothing Then
                        disposable.Dispose()
                    End If
                Catch
                    DisposeItems(e)
                    Throw
                End Try
            End While

        End Sub
    End Class

    Public NotInheritable Class Utils
        Private Sub New()
        End Sub
        Shared m_designMode As Boolean = String.Equals(Path.GetFileNameWithoutExtension(Process.GetCurrentProcess().MainModule.FileName), "devenv", StringComparison.OrdinalIgnoreCase)

        '<System.Runtime.CompilerServices.Extension()> _
        Public Shared Function IsDesignMode(ByVal control As Control) As Boolean
            Return m_designMode
        End Function

        Public Shared ReadOnly Property DesignMode() As Boolean
            Get
                Return m_designMode
            End Get
        End Property

    End Class

End Namespace