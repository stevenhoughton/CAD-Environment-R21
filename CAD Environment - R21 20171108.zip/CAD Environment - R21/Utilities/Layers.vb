﻿Imports Autodesk.AutoCAD
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports System.IO
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports Autodesk.AutoCAD.EditorInput
Imports System.Text.RegularExpressions
Imports System.Collections.Generic
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Autodesk.AutoCAD.Runtime
Imports Jacobs.Common.Settings

Public Module Layers

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Public Sub CreateLayerInCurrentDrawing(ByVal LayerName As String, ByVal LayerLineType As String, ByVal LayerColor As Integer, _
                                           Optional ByRef UseDrawingDatabase As Database = Nothing)

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim db As Database = Nothing
        If UseDrawingDatabase = Nothing Then
            db = Doc.Database
        Else
            db = UseDrawingDatabase
        End If

        Dim ed As Editor = Doc.Editor

        Dim HS As HostApplicationServices = HostApplicationServices.Current
        Dim MeasurementValue As Object = ThisDrawingUtilities.GetVariable("MEASUREMENT")
        Dim FileToFound As String = ""

        Select Case MeasurementValue.ToString
            Case "0" 'Imperial
                FileToFound = HS.FindFile("Acad.lin", db, FindFileHint.CompiledShapeFile)
            Case "1" 'Metric
                FileToFound = HS.FindFile("AcadIso.lin", db, FindFileHint.CompiledShapeFile)
        End Select

        '' Start a transaction
        Dim acTrans As Transaction = db.TransactionManager.StartTransaction()

        Using acTrans

            '' Open the Layer table for read
            Dim acLyrTbl As LayerTable
            acLyrTbl = CType(acTrans.GetObject(db.LayerTableId, OpenMode.ForRead), LayerTable)

            Dim sLayerName As String = LayerName.ToString
            Dim sLayerColor As Autodesk.AutoCAD.Colors.Color = Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                                                                Autodesk.AutoCAD.Colors.ColorMethod.ByAci,
                                                                Short.Parse(LayerColor.ToString))
            Dim acLyrTblRec As LayerTableRecord

            'If layer doesn't exist add it
            If acLyrTbl.Has(sLayerName) = False Then

                'Create New layer record
                acLyrTblRec = New LayerTableRecord()

                '' Assign the layer a name
                acLyrTblRec.Name = sLayerName

                '' Upgrade the Layer table for write
                acLyrTbl.UpgradeOpen()

                '' Append the new layer to the Layer table and the transaction
                acLyrTbl.Add(acLyrTblRec)
                acTrans.AddNewlyCreatedDBObject(acLyrTblRec, True)
            Else
                acLyrTblRec = CType(acTrans.GetObject(acLyrTbl(sLayerName), OpenMode.ForWrite), LayerTableRecord)
            End If

            acLyrTblRec.Color = sLayerColor

            'TODO - May Implent at a later Stage
            'Dim MyLwt As LineWeight = Integer.Parse([Enum].Parse( _
            '                                        GetType(Autodesk.AutoCAD.DatabaseServices.LineWeight), _
            '                                        LayerLineWeight.ToString))
            'acLyrTblRec.LineWeight = MyLwt

            '' Open the Layer table for read
            Dim acLinTbl As LinetypeTable
            acLinTbl = CType(acTrans.GetObject(db.LinetypeTableId,
                                         OpenMode.ForRead), LinetypeTable)

            'Check the existance of the line type
            If acLinTbl.Has(LayerLineType) = True Then
                '' Set the linetype for the layer
                acLyrTblRec.LinetypeObjectId = acLinTbl(LayerLineType)
            Else
                'Need to Load Line tpye if missing
                'from Found File if a file was found
                If FileToFound <> "" Then
                    'Load Line Tpe from FoundFile into current DB
                    If LoadLinetype(FileToFound, LayerLineType, db) Then
                        'Once loaded assign to new layer record
                        acLyrTblRec.LinetypeObjectId = acLinTbl(LayerLineType)
                    Else
                        'TODO - Add georges Error Logger
                        'LogFile.AddLine("LineType Load Failed: " + mLayerLineType.Item(Index).ToString)
                    End If
                Else
                    'TODO - Add georges Error Logger
                    'Log Error that linetype could not be found in current
                End If
            End If

            '' Save the changes and dispose of the transaction
            acTrans.Commit()

        End Using

    End Sub

    ''' <summary>
    ''' Load all the linetypes contained in the passed in linetype file.
    ''' If the linetype exists, a reload will be forced.
    ''' </summary>
    ''' <param name="LineTypeFile">Fully formed path to .lin file.  This is required for the StreamReader.</param>
    Public Sub LoadAllLinetypesFromFile(ByVal LineTypeFile As String, Optional ByRef UseDrawingDatabase As Database = Nothing)
        ' In this case, my CommandFlags are set to 'Session'.
        ' Therefore the document needs to be locked.
        Dim docLock As DocumentLock = Application.DocumentManager.MdiActiveDocument.LockDocument()
        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim db As Database = Nothing
        If UseDrawingDatabase = Nothing Then
            db = Doc.Database
        Else
            db = UseDrawingDatabase
        End If

        Dim Ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        Using docLock
            ' Open, read the contents, and let go of the file.
            ' Most linetype files are not large enough to 
            '                 * generate any processing overheads with this method.
            '                 

            Dim sr As New StreamReader(LineTypeFile)
            Dim fileContent As String = sr.ReadToEnd()
            sr.Close()

            ' Split the contents of the file on new line/carriage return and jettison empty lines
            Dim nameList As List(Of String) = fileContent.Split(New Char() {ControlChars.Cr, ControlChars.Lf}, StringSplitOptions.RemoveEmptyEntries).ToList()

            ' Trim the list down to linetype name lines only
            For i As Integer = nameList.Count - 1 To 0 Step -1
                If nameList(i).StartsWith(";") Then
                    ' If the line starts with ';' it's a comment
                    nameList.RemoveAt(i)
                ElseIf nameList(i).StartsWith("A") Then
                    ' If the line starts with 'A' it's the definition itself.
                    nameList.RemoveAt(i)
                End If
            Next

            ' Process each name in the resulting list
            For Each name As String In nameList
                ' Regex out the name from the string.  We're not interested in the comment.
                ' The 'name' line has the following format
                '                     * - *<Name>,<Description/comment>
                '                     * We're looking for anything between the '*' and the ','
                '                     * The Regex pattern is saying
                '                     * - '^' : from the start of the string
                '                     * - '\*' : starting with and '*', which needs to be escaped for Regex
                '                     * - '(?<Name>.*)' : Open a group called 'Name' accepting any character any number of times
                '                     * - ',' : The pattern is closed when a comma is encountered
                '                     

                Dim ltName As String = Regex.Match(name, "^\*(?<Name>.*),").Groups("Name").Value

                If LoadLinetype(LineTypeFile, ltName, db) Then

                    Acad_MessageBox(ltName & " LineType Loaded", , , , , , , True, LogName)

                End If
            Next
        End Using
    End Sub

    Public Function LoadLinetype(ByVal LineStyleFile As String, ByVal LineStyle As String, Optional ByRef UseDrawingDatabase As Database = Nothing) As Boolean
        ' Connect to the document
        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database
        If UseDrawingDatabase = Nothing Then
            db = doc.Database
        Else
            db = UseDrawingDatabase
        End If

        Dim Ret As Boolean = False

        Using acTrans As Transaction = db.TransactionManager.StartTransaction()
            ' Open the Linetype table for read
            Dim acLineTypTbl As LinetypeTable
            acLineTypTbl = TryCast(acTrans.GetObject(db.LinetypeTableId, OpenMode.ForRead), LinetypeTable)

            If Not acLineTypTbl.Has(LineStyle) Then
                ' If the linetype doesn't exist.
                ' A Kean Walmsley example tries to load all linetypes by feeding "*" in as the linetype.
                '                     * That fails if the linetype exists.  
                '                     * Although he captures the exceptions, the remaining linetypes don't get loaded.
                '                     
                db.LoadLineTypeFile(LineStyle, LineStyleFile)
                Ret = True
            Else
                ' Load the requested Linetype.
                ForceLinetypeReload(LineStyleFile, LineStyle)
                Ret = True
            End If
            ' Force an update from the file.
            ' Commit the changes
            acTrans.Commit()
        End Using

        Return Ret

    End Function

    Public Sub ForceLinetypeReload(ByVal LineStyleFile As String, ByVal LineStyle As String)

        ' Get the current FILEDIA setting for restoration later
        Dim fileDia As Int16 = DirectCast(Application.GetSystemVariable("FILEDIA"), Int16)
        ' Set FILEDIA to 0, to force a 'command line' interaction with the linetype command
        Application.SetSystemVariable("FILEDIA", 0)
        ' Get an instance of the application object
        Dim acObj As [Object] = Application.AcadApplication
        ' Get an instance of the document objecy associated with the application
        Dim acDoc As Object = acObj.[GetType]().InvokeMember("ActiveDocument", System.Reflection.BindingFlags.GetProperty, Nothing, acObj, Nothing)
        ' Establish an array for the command
        Dim dataArray As Object() = New Object(0) {}
        ' Build the command string and add to the array
        dataArray(0) = "-linetype Load " & LineStyle & vbLf & LineStyleFile & vbLf & "Yes" & vbLf & " "
        ' Send the command to AutoCAD.
        acDoc.[GetType]().InvokeMember("SendCommand", System.Reflection.BindingFlags.InvokeMethod, Nothing, acDoc, dataArray)
        ' Reset the FILEDIA variable.
        Application.SetSystemVariable("FILEDIA", fileDia)

    End Sub

    Public Function CheckLinestyleExists(ByVal LineStyleName As String, Optional ByRef UseDrawingDatabase As Database = Nothing) As Boolean
        ' Connect to the document and its database
        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database
        If UseDrawingDatabase = Nothing Then
            db = doc.Database
        Else
            db = UseDrawingDatabase
        End If

        ' Transact with the database
        Using tr As Transaction = db.TransactionManager.StartTransaction()
            ' Get an instance of the line type table
            Dim ltt As LinetypeTable = DirectCast(tr.GetObject(db.LinetypeTableId, OpenMode.ForRead, True), LinetypeTable)
            ' Test if the linetype exists
            If ltt.Has(LineStyleName) Then
                Return True
            End If
            ' If it does return true
            ' If it doesn't return false
            Return False
        End Using
    End Function

    Public Function GetLinestyleIDFromName(ByVal LineStyleName As String, Optional ByRef dbx As Database = Nothing) As ObjectId
        ' Initialise a result
        Dim result As ObjectId = ObjectId.Null

        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database
        If dbx = Nothing Then
            db = doc.Database
        Else
            db = dbx
        End If

        ' Transact with the database
        Dim tr As Transaction = db.TransactionManager.StartTransaction()
        Using tr
            Dim ltt As LinetypeTable = DirectCast(tr.GetObject(db.LinetypeTableId, OpenMode.ForRead), LinetypeTable)
            ' Get an instance of the line type table
            If ltt.Has(LineStyleName) Then
                ' IF the linestyle exists
                result = ltt(LineStyleName)
            End If
            ' Get the linetype object id
            ' Finish the transaction
            tr.Commit()
        End Using

        Return result
    End Function


    '<CommandMethod("EraseLayer")> _
    Public Sub EraseLayer()

        '' Get the current document and database 
        Dim acDoc As Document = Application.DocumentManager.MdiActiveDocument
        Dim acCurDb As Database = acDoc.Database
        '' Start a transaction 
        Using acTrans As Transaction = acCurDb.TransactionManager.StartTransaction()

            '' Open the Layer table for read 
            Dim acLyrTbl As LayerTable
            acLyrTbl = CType(acTrans.GetObject(acCurDb.LayerTableId, OpenMode.ForRead), LayerTable)

            For Each ALayer As Autodesk.AutoCAD.Interop.Common.AcadLayer In ThisDrawingUtilities.Layers

                If acLyrTbl.Has(ALayer.Name) = True Then

                    '' Check to see if it is safe to erase layer           
                    Dim acObjIdColl As ObjectIdCollection = New ObjectIdCollection()
                    acObjIdColl.Add(acLyrTbl(ALayer.Name))
                    acCurDb.Purge(acObjIdColl)
                    If acObjIdColl.Count > 0 Then
                        Dim acLyrTblRec As LayerTableRecord
                        acLyrTblRec = CType(acTrans.GetObject(acObjIdColl(0), OpenMode.ForWrite), LayerTableRecord)
                        Try
                            '' Erase the unreferenced layer                   
                            acLyrTblRec.Erase(True)

                            '' Save the changes and dispose of the transaction                   
                            acTrans.Commit()
                        Catch Ex As Autodesk.AutoCAD.Runtime.Exception
                            '' Layer could not be deleted                   
                            Acad_ExceptionMessageBox(Ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
                        End Try
                    End If
                End If
            Next


        End Using
    End Sub

    Public Function GetAllLayersPropertiesFromCurrentFile(Optional ByVal AllowCommandDebug As Boolean = False) As List(Of clsLayerDetails)

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim layer As LayerTableRecord
        Dim Edd As Editor = Doc.Editor

        Dim Layers As List(Of clsLayerDetails) = New List(Of clsLayerDetails)

        Using DocKock As DocumentLock = Doc.LockDocument

            Using db As Database = Doc.Database

                Using tr As Transaction = db.TransactionManager.StartTransaction()

                    Dim lt As LayerTable = TryCast(tr.GetObject(db.LayerTableId, OpenMode.ForRead), LayerTable)
                    Dim ltt As LinetypeTable = TryCast(tr.GetObject(db.LinetypeTableId, OpenMode.ForRead), LinetypeTable)

                    For Each layerId As ObjectId In lt

                        layer = TryCast(tr.GetObject(layerId, OpenMode.ForWrite), LayerTableRecord)
                        If AllowCommandDebug Then Edd.WriteMessage("Next Layer in Drawing: " & layer.Name & vbCrLf)

                        If AllowCommandDebug Then If layer.IsErased Then Edd.WriteMessage(layer.Name & " is Erased" & vbCrLf)

                        Dim T As New clsLayerDetails(layer.Name)

                        T.IsFrozen = layer.IsFrozen
                        T.IsOff = layer.IsOff
                        T.IsPlotAble = layer.IsPlottable
                        T.IsLocked = layer.IsLocked
                        T.SetLColor = layer.Color
                        Dim LineTRec As LinetypeTableRecord = DirectCast(tr.GetObject(layer.LinetypeObjectId, OpenMode.ForRead), LinetypeTableRecord)

                        T.SetLLineTypeName = LineTRec.Name
                        T.SetLLineType = layer.LinetypeObjectId
                        T.SetLLineTypeTableID = db.LinetypeTableId
                        T.SetLLineWeight = layer.LineWeight

                        Layers.Add(T)

                        If AllowCommandDebug Then Edd.WriteMessage(layer.Name & " Added To Layer Collection" & vbCrLf)

                    Next

                    tr.Commit()

                End Using

            End Using

        End Using

        Return Layers

    End Function

    Public Function ExecuteExistingLayerMapping(ByRef SideDB As Database, ByVal mLayers As List(Of clsLayerDetails), _
                                                ByVal SaveAsFileName As String, _
                                                Optional ByVal AllowCommandLineDebug As Boolean = False) As Boolean

        Dim CurrentDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim CurrentDB As Database = CurrentDoc.Database
        Dim Edd As Editor = CurrentDoc.Editor

        Dim Changed As Boolean = False

        Using DocKock As DocumentLock = CurrentDoc.LockDocument

            Using SideDB

                Changed = False

                Dim layer As LayerTableRecord
                Using tr As Transaction = SideDB.TransactionManager.StartTransaction()

                    Dim lt As LayerTable = TryCast(tr.GetObject(SideDB.LayerTableId, OpenMode.ForWrite), LayerTable)

                    For Each layerId As ObjectId In lt

                        layer = TryCast(tr.GetObject(layerId, OpenMode.ForWrite), LayerTableRecord)
                        Edd.WriteMessage("Analsysing Layer: " & layer.Name & vbCrLf)

                        If layer.IsErased = True Then
                            If AllowCommandLineDebug Then Edd.WriteMessage(layer.Name & " Skipped as it was Erased" & vbCrLf)
                            Continue For
                        End If

                        Dim FoundIndex As Integer = mLayers.FindIndex(Function(Lay As clsLayerDetails) Lay.LayerName = layer.Name)

                        If FoundIndex > -1 Then
                            If AllowCommandLineDebug Then Edd.WriteMessage(layer.Name & " Found" & vbCrLf)
                            mLayers(FoundIndex).LayerFound_Res = True

                            If mLayers(FoundIndex).eFreeze Then layer.IsFrozen = mLayers(FoundIndex).IsFrozen
                            If mLayers(FoundIndex).eOnOff Then layer.IsOff = mLayers(FoundIndex).IsOff
                            If mLayers(FoundIndex).ePlot Then layer.IsPlottable = mLayers(FoundIndex).IsPlotAble
                            If mLayers(FoundIndex).eLock Then layer.IsLocked = mLayers(FoundIndex).IsLocked

                            'Enable this later
                            If mLayers(FoundIndex).eLColor Then layer.Color = mLayers(FoundIndex).SetLColor

                            If mLayers(FoundIndex).eLLineType Then

                                Dim ltt As LinetypeTable = TryCast(tr.GetObject(SideDB.LinetypeTableId, OpenMode.ForWrite), LinetypeTable)

                                If ltt.Has(mLayers(FoundIndex).SetLLineTypeName) = False Then

                                    Dim CloneOIDS As New ObjectIdCollection
                                    CloneOIDS.Add(mLayers(FoundIndex).SetLLineType)

                                    Dim idMap As IdMapping = New IdMapping()
                                    CurrentDB.WblockCloneObjects(CloneOIDS, ltt.ObjectId, idMap, DuplicateRecordCloning.Replace, False)

                                End If

                                layer.LinetypeObjectId = ltt(mLayers(FoundIndex).SetLLineTypeName) ' mLayers(FoundIndex).SetLLineType

                            End If

                            Changed = True

                        Else
                            Edd.WriteMessage(layer.Name & " Skipped as it was not found in Current Drawing" & vbCrLf)
                        End If

                    Next

                    tr.Commit()

                End Using


                If Changed Then
                    SideDB.RetainOriginalThumbnailBitmap = True
                    SideDB.SaveAs(SaveAsFileName, SideDB.OriginalFileVersion) ' DwgVersion.Current)
                End If
            End Using

        End Using

        Return Changed

    End Function
End Module

