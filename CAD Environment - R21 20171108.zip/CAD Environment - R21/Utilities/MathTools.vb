﻿Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports System.Collections.Generic
Imports System.Linq
Imports acrt = Autodesk.AutoCAD.Runtime


Public Module MathTools

    Public Function RadiansToDegrees(ByVal Radians As Double) As Double
        Dim RetValue As Double = 0
        RetValue = Radians * (180 / Math.PI)
        Return RetValue
    End Function

    Public Function DegreesToRadians(ByVal Degrees As Double) As Double
        Dim RetValue As Double = 0
        RetValue = Degrees * (Math.PI / 180)
        Return RetValue
    End Function

    Public Function GetPointTransformed2(ByVal ToPaperSpace As Boolean, ByVal PointToConvert As Point3d, ByRef ConvertedPoint As Point3d, ByVal ViewPortHandle As Handle) As Boolean

        Dim ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
        Dim db As Database = HostApplicationServices.WorkingDatabase
        Dim vp As Autodesk.AutoCAD.DatabaseServices.Viewport

        Dim Result As Boolean = False

        Using tr As Transaction = db.TransactionManager.StartTransaction()

            Try
                vp = CType(tr.GetObject(db.GetObjectId(False, ViewPortHandle, 0), OpenMode.ForRead, False, True), Viewport)

                Select Case ToPaperSpace
                    Case True
                        ConvertedPoint = ModelToPaper(PointToConvert, vp) 'PointToConvert.TransformBy(ModelToPaper(vp))
                    Case False
                        ConvertedPoint = ModelToPaper(PointToConvert, vp) 'PointToConvert.TransformBy(PaperToModel(vp))
                End Select

                Result = Not (IsNothing(ConvertedPoint))

                If Result = True Then
                    ConvertedPoint = New Point3d(ConvertedPoint.X, ConvertedPoint.Y, 0)
                End If
            Catch ex As SystemException
                ed.WriteMessage("" & Chr(10) & "" + ex.Message)
                ed.WriteMessage("" & Chr(10) & "" + ex.StackTrace)
            Finally

            End Try

        End Using

        Return Result

    End Function

    Public Function PaperToModel(ByVal point As Point3d, ByVal vport As Viewport) As Point3d
        Return point.TransformBy(GetModelToPaperTransformMatrix(vport).Inverse())
    End Function

    Public Function ModelToPaper(ByVal point As Point3d, ByVal viewport As Viewport) As Point3d
        Return point.TransformBy(GetModelToPaperTransformMatrix(viewport))
    End Function

    Public Sub PaperToModel(ByVal entity As Entity, ByVal vport As Viewport)
        entity.TransformBy(GetModelToPaperTransformMatrix(vport).Inverse())
    End Sub

    Public Sub ModelToPaper(ByVal entity As Entity, ByVal viewport As Viewport)
        entity.TransformBy(GetModelToPaperTransformMatrix(viewport))
    End Sub

    Public Function GetModelToPaperTransformMatrix(ByVal vport As Viewport) As Matrix3d
        If vport.PerspectiveOn Then
            Throw New NotSupportedException("Perspective views not supported")
        End If
        Dim center As New Point3d(vport.ViewCenter.X, vport.ViewCenter.Y, 0.0)
        Return Matrix3d.Displacement(New Vector3d(vport.CenterPoint.X - center.X, vport.CenterPoint.Y - center.Y, 0.0)) * Matrix3d.Scaling(vport.CustomScale, center) * Matrix3d.Rotation(vport.TwistAngle, Vector3d.ZAxis, Point3d.Origin) * Matrix3d.WorldToPlane(New Plane(vport.ViewTarget, vport.ViewDirection))
    End Function

    Public Function GetPaperToModelTransform(ByVal vport As Viewport) As Matrix3d
        Return GetModelToPaperTransformMatrix(vport).Inverse()
    End Function

    'TODO - These need testing
    Public Function PaperToModel(ByVal source As IEnumerable(Of Point3d), ByVal viewport As Viewport) As IEnumerable(Of Point3d)
        Dim xform As Matrix3d = GetModelToPaperTransformMatrix(viewport).Inverse()
        Return source.[Select](Function(p) p.TransformBy(xform))
    End Function

    Public Function ModelToPaper(ByVal source As IEnumerable(Of Point3d), ByVal viewport As Viewport) As IEnumerable(Of Point3d)
        Dim xform As Matrix3d = GetModelToPaperTransformMatrix(viewport)
        Return source.[Select](Function(p) p.TransformBy(xform))
    End Function

    Public Sub PaperToModel(ByVal src As IEnumerable(Of Entity), ByVal viewport As Viewport)
        Dim xform As Matrix3d = GetModelToPaperTransformMatrix(viewport).Inverse()
        For Each ent As Entity In src
            ent.TransformBy(xform)
        Next
    End Sub

    Public Sub ModelToPaper(ByVal src As IEnumerable(Of Entity), ByVal viewport As Viewport)
        Dim xform As Matrix3d = GetModelToPaperTransformMatrix(viewport)
        For Each ent As Entity In src
            ent.TransformBy(xform)
        Next
    End Sub

    Public Function Polar(ByVal org As Point3d, ByVal angle As Double, ByVal distance As Double) As Point3d
        Return New Point3d(org.X + (distance * Math.Cos(angle)), org.Y + (distance * Math.Sin(angle)), org.Z)
    End Function

    Public Function GetRotationFromX(ByVal InsPt As Point3d, ByVal InsPt2 As Point3d) As Double

        Dim ucsRot As Double = 0

        Dim ucs As Matrix3d = Ed.CurrentUserCoordinateSystem

        Dim ucsNormal As Vector3d = ucs.CoordinateSystem3d.Zaxis
        Dim mat As Matrix3d = Matrix3d.WorldToPlane(New Plane(Point3d.Origin, ucsNormal))
        Dim ucsXDir As Point3d = DirectCast(Autodesk.AutoCAD.ApplicationServices.Application.GetSystemVariable("UCSXDIR"), Point3d)
        ucsRot = Vector3d.XAxis.GetAngleTo(ucsXDir.GetAsVector().TransformBy(mat), Vector3d.ZAxis)

        Dim Xp1 As Point3d = InsPt.TransformBy(mat)
        Dim Xp2 As Point3d = InsPt2.TransformBy(mat)
        ucsRot = Vector3d.XAxis.GetAngleTo(Xp1.GetVectorTo(Xp2), Vector3d.ZAxis)

        Return ucsRot

    End Function

    Public Function IsPointInside(ByVal pt As Point3d, ByVal extents As Extents3d, Optional ByVal Tolerence As Integer = -1, Optional ByVal IgnoreZ As Boolean = False) As Boolean
        'Tolerence Values if Tolerence is Greater then -1
        Dim Xtest As Double = If(Tolerence > -1, Math.Round(pt.X, Tolerence), pt.X)
        Dim Ytest As Double = If(Tolerence > -1, Math.Round(pt.Y, Tolerence), pt.Y)
        Dim Ztest As Double = If(Tolerence > -1, Math.Round(pt.Z, Tolerence), pt.Z)

        'Orginal Function Below
        'Return pt.X > extents.MinPoint.X AndAlso pt.Y > extents.MinPoint.Y AndAlso pt.Z > extents.MinPoint.Z AndAlso pt.X < extents.MaxPoint.X AndAlso pt.Y < extents.MaxPoint.Y AndAlso pt.Z < extents.MaxPoint.Z

        'Add the Ignore Z value
        Dim RetValue As Boolean = False
        Select Case IgnoreZ
            Case True
                RetValue = Xtest > extents.MinPoint.X AndAlso Xtest > extents.MinPoint.Y _
                    AndAlso Xtest < extents.MaxPoint.X AndAlso Ytest < extents.MaxPoint.Y
            Case False
                RetValue = Xtest > extents.MinPoint.X AndAlso Xtest > extents.MinPoint.Y AndAlso Ztest > extents.MinPoint.Z _
                    AndAlso Xtest < extents.MaxPoint.X AndAlso Ytest < extents.MaxPoint.Y AndAlso Ztest < extents.MaxPoint.Z
        End Select

        Return RetValue
    End Function

End Module


