Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.DatabaseServices
Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Linq
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension
Imports System.Xml
Imports System.Data
Imports System.Collections.Generic
Imports Autodesk.AutoCAD.Runtime

'Imports Autodesk.AutoCAD.Runtime

'' The code below breaks the LISP enabled functions like JacobsCONFIG
'' This line is not mandatory, but improves loading performances
'<Assembly: CommandClass(GetType(Jacobs.AutoCAD.Utilities.Utilities))> 

''' <summary>
''' General module of functions
''' </summary>
''' <remarks></remarks>
Public Module Utilities

#Region "Declarations"

    'Public WithEvents ThisDrawing As AcadDocument = CType(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)

    Public ReadOnly Property ThisDrawingUtilities() As AcadDocument
        Get
            Return CType(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)
        End Get
    End Property

    Public Ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor

    Public ConfigurationLevel As String
    Public ConfigurationName As String
    Public FullConfigurationName As String
    Public RUNTIMEConfigPath As String

    Public Const WZ_DGLCODE_LIST_BOX As Integer = 1
    Public Const WZ_DGLCODE_TEXT_BOX As Integer = 2
    Public Const WZ_DGLCODE_TICK_BOX As Integer = 3
    Public Const WZ_DGLCODE_DATAGRIDVIEW As Integer = 4

    Public Const WZ_LINETYPE_TABLE As Integer = 4
    Public Const WZ_LINETYPE_TABLE_SYSVAR As String = "CELTYPE"
    Public Const WZ_LAYER_TABLE As Integer = 6
    Public Const WZ_LAYER_TABLE_SYSVAR As String = "CLAYER"
    Public Const WZ_MULTILINESTYLE_TABLE As Integer = 7
    Public Const WZ_MULTILINESTYLE_TABLE_SYSVAR As String = "CMLSTYLE"
    Public Const WZ_TEXTSTYLE_TABLE As Integer = 8
    Public Const WZ_TEXTSTYLE_TABLE_SYSVAR As String = "TEXTSTYLE"
    Public Const WZ_BLOCK_TABLE As Integer = 9
    Public Const WZ_TABLESTYLE_TABLE As Integer = 10
    Public Const WZ_TABLESTYLE_TABLE_SYSVAR As String = "CTABLESTYLE"
    Public Const WZ_DIMSTYLE_TABLE As Integer = 11
    Public Const WZ_DIMSTYLE_TABLE_SYSVAR As String = "DIMSTYLE"
    Public Const WZ_PLOTSTYLES_TABLE As Integer = 12
    Public Const WZ_PLOTSTYLES_TABLE_SYSVAR As String = "CPLOTSTYLE"
    Public Const WZ_LAYOUTS_TABLE As Integer = 13
    Public Const WZ_LAYOUTS_TABLE_SYSVAR As String = "CTAB"
    Public Const WZ_PAGESETUPS_TABLE As Integer = 14
    Public Const WZ_JUSTIFICATIONS As Integer = 15
    Public Const WZ_COLOUR As Integer = 16
    Public Const WZ_COLOUR_SYSVAR As String = "CECOLOR"
    Public Const WZ_LINEWEIGHT As Integer = 17
    Public Const WZ_LINEWEIGHT_SYSVAR As String = "CLWEIGHT"
    Public Const WZ_LINEWEIGHT_SYSVAR2 As String = "LWDEAFULT"
    Public Const WZ_INSUNITS As Integer = 18
    Public Const WZ_INSUNITS_SYSVAR As String = "INSUNITS"
    Public Const WZ_CUSTOM As Integer = 19
    Public Const WZ_CUSTOM_SYSVAR As String = "CUSTOM"
    Public Const HKLM As Integer = &H80000002           ' HKEY_LOCAL_MACHINE
    Public Const HKCU As Integer = &H80000001           ' HKEY_CURRENT_USER
    Public Const PI As Double = 3.14159265358979        ' Alternatively we could have used use PI = 4 * Atn(1)

    Public Structure ToolDetail               ' Create user-defined type.
        Dim ToolName As String
        Dim ToolGroup As String
        Dim MenuString() As String
        Dim FlyoutString() As String
        Dim HelpString() As String
        Dim ToolBarString() As String
        Dim MNLFileString As String
        Dim PGPFileString() As String
        Dim Description() As String
        Dim Rules() As String
        Dim Accelerators() As String
        Dim GenericRules As String
    End Structure

    '' Dim RuleAccessors As New RuleAccessors

    Public ToolDetails() As ToolDetail

    ' API Function declarations for reading and writing to INI type files
    Public Declare Function GetPrivateProfileSection Lib "kernel32" Alias "GetPrivateProfileSectionA" (ByVal lpAppName As String, ByVal lpReturnedString As String, ByVal nSize As Integer, ByVal lpName As String) As Integer

    Public Enum DynamicModifyStates
        Company_Visibility = 0
        Company_Flip_State = 1
    End Enum

    'Public TemplateBuilderCalled As Boolean = False

#End Region

    ''' <summary>
    ''' Every DLL that implements iextensions applications needs to come here first
    ''' Any external DLL that does not run inside autocad needs to have one of these to collect the object data
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetConfigSettings() As Boolean

        Try
            Dim result As Boolean = False

            Manager.Register("ACADPRODNO", New Manager.Variable.EvaluateExpressionDelegate(AddressOf GetAcadProdNo), True)
            Manager.Register("ROAMABLEROOTPREFIX", New Manager.Variable.EvaluateExpressionDelegate(AddressOf RoamableRootFolder), True)
            Manager.Register("PRODUCTREGISTRYHIVE", New Manager.Variable.EvaluateExpressionDelegate(AddressOf AcadRegKey), True)
            Manager.Register("SHORTNAME", New Manager.Variable.EvaluateExpressionDelegate(AddressOf GetProdShortName), True)
            Manager.Register("PRODUCTNAME", New Manager.Variable.EvaluateExpressionDelegate(AddressOf GetAcadProductName), True)

            '' get current name
            Dim AcadName As String = Manager.EvaluateExpression("[PRODUCTNAME]")

            ' Which AutoCAD is running now?
            For Each Acad As Manager.AutoCADProduct In Settings.Manager.AutoCADs
                If Acad.Name = AcadName Then
                    '' set the current AutoCAD
                    Settings.Manager.AutoCAD = Acad
                    Exit For
                End If
            Next Acad

            '' get current name
            Dim AEName As String = "Jacobs AutoCAD Environment R21"
            For Each AEx As Manager.AEProduct In Settings.Manager.AEs
                If AEx.Name = AEName Then
                    Settings.Manager.AE = AEx
                    result = True
                End If
            Next AEx

            'Settings.Manager.MergeProductSettings(Settings.Manager.AE.UserSettingsFileName))

            '' do we merge our AutoCAD snippet?
            Settings.Manager.MergeProductSettings(Settings.Manager.AutoCAD.UserSettingsFileName)

            Return result

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try

    End Function

    Public Sub ConfigurationSettings()
        Try
            ConfigurationName = GetruleValue("FULLCONFIGNAME")
            If Not String.IsNullOrEmpty(ConfigurationName) Then 'Check if drawing has been configured
                Dim XmlSettings As New XmlWriterSettings()
                XmlSettings.Indent = True
                Settings.Manager.AE.ConfigurationSettingsFileName = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(ConfigurationName).CombinePath("Support").CombinePath(ConfigurationName) & ".xml" 'extract the name of the xml file
                If Not System.IO.File.Exists(Settings.Manager.AE.ConfigurationSettingsFileName) Then 'Check to see if the xml file exists
                    'Write the rules to the configuration.xml file
                    Dim XmlWrt As XmlWriter = XmlWriter.Create(Settings.Manager.AE.ConfigurationSettingsFileName, XmlSettings)
                    XmlWrt.WriteStartDocument()
                    XmlWrt.WriteComment("Configuration Settings")
                    XmlWrt.WriteStartElement("Rules")
                    For Each Rule As Rule In RuleAccessors.GetAllRules
                        Dim ElementName As String = Rule.RuleID
                        If ElementName.Contains("&") Then
                            ElementName = ElementName.Replace("&", "")
                        ElseIf ElementName.Contains(":") Then
                            ElementName = ElementName.Replace(":", "")
                        End If
                        'XmlWrt.WriteStartElement("Rule")
                        XmlWrt.WriteStartElement(ElementName)
                        XmlWrt.WriteString(Rule.value)
                        'XmlWrt.WriteEndElement()
                        XmlWrt.WriteEndElement()
                    Next
                    XmlWrt.WriteEndDocument()
                    XmlWrt.Close()
                End If
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            'Return False
        End Try

    End Sub
    Public Sub setconfigpath()

        If IsThisAnOldConfigName() = True Then

            ' This section will error if the registry entries that are written by Gregs calling program are not present.
            ' It's fine if these next 3 variables are empty - as they are only used when content wizard is running
            ConfigurationLevel = RegistryRead("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey, "ConfigType", True)
            ConfigurationName = RegistryRead("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey, "ConfigName", True)
            FullConfigurationName = RegistryRead("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey, "FullConfigName", True)
            RUNTIMEConfigPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(RuleAccessors.GetruleValue("FULLCONFIGNAME"))

        Else

            ' This next path can only be derived at runtime as the config name varies from drawing to drawing...TO INVESTIGATE what happens when we switch drawing
            RUNTIMEConfigPath = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(RuleAccessors.GetruleValue("FULLCONFIGNAME"))

        End If

        Acad_MessageBox("Config path: " & RUNTIMEConfigPath, , , , , , , True, logName)



    End Sub

    ''' <summary>
    ''' Entlast function attempts to get the last entity drawn by user (does not work 100% yet) but it is used by the BlockFinder tool
    ''' ThisDrawing_EndCommand - to layer blocks
    ''' TO INVESTIGATE
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function entlast() As Autodesk.AutoCAD.Interop.Common.AcadObject
        Try
            If ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acModelSpace Then
                If ThisDrawingUtilities.ModelSpace.Count > 0 Then
                    entlast = CType(ThisDrawingUtilities.ModelSpace.Item(ThisDrawingUtilities.ModelSpace.Count - 1), Autodesk.AutoCAD.Interop.Common.AcadObject)
                Else
                    entlast = Nothing
                End If
            Else
                If WhichSpace() = "FloatingModelSpace" Then
                    If ThisDrawingUtilities.ModelSpace.Count > 0 Then
                        entlast = CType(ThisDrawingUtilities.ModelSpace.Item(ThisDrawingUtilities.ModelSpace.Count - 1), Autodesk.AutoCAD.Interop.Common.AcadObject)
                    Else
                        entlast = Nothing
                    End If
                Else
                    If ThisDrawingUtilities.ActiveLayout.Block.Count > 0 Then
                        entlast = CType(ThisDrawingUtilities.ActiveLayout.Block.Item(ThisDrawingUtilities.ActiveLayout.Block.Count - 1), Autodesk.AutoCAD.Interop.Common.AcadObject)
                    Else
                        entlast = Nothing
                    End If
                End If
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            entlast = Nothing
        End Try

    End Function

    ''' <summary>
    ''' Adds a selection set - if exists it clears it deletes it and returns a new one
    ''' </summary>
    ''' <param name="SSetName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function SSetAdd(ByRef SSetName As String) As Autodesk.AutoCAD.Interop.AcadSelectionSet
        Try

            Dim objSelSet As Autodesk.AutoCAD.Interop.AcadSelectionSet ' Selection set
            Dim objSelCol As Autodesk.AutoCAD.Interop.AcadSelectionSets ' Selection Sets collection

            objSelCol = ThisDrawingUtilities.SelectionSets

            For Each objSelSet In objSelCol
                If objSelSet.Name = SSetName Then
                    If objSelSet.Count < 1 Then
                        objSelSet.Clear() ' first clear the selection set
                    End If
                    objSelSet.Delete() ' then delete it
                    Exit For
                End If
            Next objSelSet
            Return ThisDrawingUtilities.SelectionSets.Add(SSetName)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' Check if layer exists by passing layer name as string - returns true or false (does not check xrefs)
    ''' Can be passed an Acad document to check but by default just checks current drawing - returns true or false
    ''' </summary>
    ''' <param name="strLayerName"></param>
    ''' <param name="AcadDwg"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function LayerExist(ByRef strLayerName As String, Optional ByVal AcadDwg As Autodesk.AutoCAD.Interop.AcadDocument = Nothing) As Boolean
        Try
            Dim aLayer As Autodesk.AutoCAD.Interop.Common.AcadLayer
            Dim LayerColl As Autodesk.AutoCAD.Interop.Common.AcadLayers

            If AcadDwg Is Nothing Then
                LayerColl = ThisDrawingUtilities.Layers
            Else
                LayerColl = AcadDwg.Layers
            End If

            For Each aLayer In LayerColl
                If UCase(strLayerName) = UCase(aLayer.Name) Then
                    Return True
                    Exit For
                End If
            Next aLayer

            Return False

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Check if dimension exists by passing layer name as string - returns true or false (does not check xrefs by default)
    ''' By setting the flag to false it will check Xrefs - return true or false
    ''' </summary>
    ''' <param name="strDimStyleName"></param>
    ''' <param name="bOmitXrefStyles"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DimStyleExist(ByRef strDimStyleName As String, Optional ByRef bOmitXrefStyles As Boolean = True) As Boolean
        Try
            Dim aDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle
            Dim DimStyleColl As Autodesk.AutoCAD.Interop.Common.AcadDimStyles
            Dim bStyleExists As Boolean
            Dim strDimStyleNamex As String

            bStyleExists = False

            DimStyleColl = ThisDrawingUtilities.DimStyles

            ' Cater for the [ special character so that the LIKE command works
            strDimStyleNamex = Replace(strDimStyleName, "[", "[[]")

            For Each aDimStyle In DimStyleColl

                If bOmitXrefStyles = True Then
                    If UCase(aDimStyle.Name) Like UCase(strDimStyleNamex) And Not UCase(aDimStyle.Name) Like "*|*" Then
                        bStyleExists = True
                        Exit For
                    End If
                Else
                    If UCase(aDimStyle.Name) Like UCase(strDimStyleNamex) Then
                        bStyleExists = True
                        Exit For
                    End If
                End If
            Next aDimStyle

            DimStyleExist = bStyleExists
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try


    End Function

    ''' <summary>
    ''' Search or finds a dimension style by name - can be used to search for a dimension style origin(i.e which Xref is it from)
    ''' By setting the flag to false it will check Xrefs - and returns the name of the style with the xref prefix if appropriate
    ''' </summary>
    ''' <param name="strDimStyleName"></param>
    ''' <param name="bOmitXrefStyles"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DimStyleFind(ByRef strDimStyleName As String, Optional ByRef bOmitXrefStyles As Boolean = True) As String
        Try
            Dim aDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle
            Dim DimStyleColl As Autodesk.AutoCAD.Interop.Common.AcadDimStyles
            Dim sStyleName As String
            Dim strDimStyleNamex As String

            sStyleName = ""

            DimStyleColl = ThisDrawingUtilities.DimStyles

            ' Cater for the [ special character so that the LIKE command works
            strDimStyleNamex = Replace(strDimStyleName, "[", "[[]")

            For Each aDimStyle In DimStyleColl

                If bOmitXrefStyles = True Then
                    If UCase(aDimStyle.Name) Like UCase(strDimStyleNamex) And Not UCase(aDimStyle.Name) Like "*|*" Then
                        sStyleName = aDimStyle.Name
                        Exit For
                    End If

                Else
                    If UCase(aDimStyle.Name) Like UCase(strDimStyleNamex) Then
                        sStyleName = aDimStyle.Name
                        Exit For
                    End If
                End If
            Next aDimStyle

            DimStyleFind = sStyleName

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return ""
        End Try
    End Function

    ''' <summary>
    ''' Searches the block collection to see if a block exists and returns true or false
    ''' </summary>
    ''' <param name="strBlockName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function BlockExist(ByRef strBlockName As String) As Boolean
        Try
            Dim aBlock As Autodesk.AutoCAD.Interop.Common.AcadBlock
            Dim BlockColl As Autodesk.AutoCAD.Interop.Common.AcadBlocks
            Dim bBlockExists As Boolean

            bBlockExists = False

            BlockColl = ThisDrawingUtilities.Blocks

            For Each aBlock In BlockColl
                If UCase(strBlockName) = UCase(aBlock.Name) Then
                    bBlockExists = True
                    Exit For
                End If
            Next aBlock

            BlockExist = bBlockExists
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try


    End Function

    ''' <summary>
    ''' Searches the Acad layouts for a matching name and returns true or false
    ''' </summary>
    ''' <param name="strlayoutName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function LayoutExist(ByRef strlayoutName As String) As Boolean
        Try
            Dim alayout As Autodesk.AutoCAD.Interop.Common.AcadLayout
            Dim layoutColl As Autodesk.AutoCAD.Interop.Common.AcadLayouts
            Dim blayoutExists As Boolean

            blayoutExists = False

            layoutColl = ThisDrawingUtilities.Layouts

            For Each alayout In layoutColl
                If UCase(strlayoutName) = UCase(alayout.Name) Then
                    blayoutExists = True
                    Exit For
                End If
            Next alayout

            LayoutExist = blayoutExists

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try
    End Function

    ''' <summary>
    ''' Searches the AcadLineTypes for a matching name and returns true or false
    ''' </summary>
    ''' <param name="strLineTypeName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function LineTypeExist(ByRef strLineTypeName As String) As Boolean
        Try
            Dim aLineType As Autodesk.AutoCAD.Interop.Common.AcadLineType
            Dim LineTypeColl As Autodesk.AutoCAD.Interop.Common.AcadLineTypes
            Dim bLineTypeExists As Boolean

            bLineTypeExists = False

            LineTypeColl = ThisDrawingUtilities.Linetypes

            For Each aLineType In LineTypeColl
                If UCase(strLineTypeName) = UCase(aLineType.Name) Then
                    bLineTypeExists = True
                    Exit For
                End If
            Next aLineType

            LineTypeExist = bLineTypeExists

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Searches the drawing text styles and returns true or false if there is a match
    ''' </summary>
    ''' <param name="strTextStyleName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function TextStyleExist(ByRef strTextStyleName As String) As Boolean
        Try
            Dim aTextStyle As Autodesk.AutoCAD.Interop.Common.AcadTextStyle
            Dim TextStyleColl As Autodesk.AutoCAD.Interop.Common.AcadTextStyles
            Dim bTextStyleExists As Boolean

            bTextStyleExists = False

            TextStyleColl = ThisDrawingUtilities.TextStyles

            For Each aTextStyle In TextStyleColl
                If UCase(strTextStyleName) = UCase(aTextStyle.Name) Then
                    bTextStyleExists = True
                    Exit For
                End If
            Next aTextStyle

            TextStyleExist = bTextStyleExists
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Untested Function to work out if a Table Style exists in the drawing
    ''' Note: The important thing to know is that TableStyle objects are stored in a special dictionary, which can be accessed via a Database's TableStyleDictionaryId property. 
    ''' This ObjectId property allows you to access the dictionary, from which you can query the contents, determine whether your style exists - 
    ''' See more at: http://through-the-interface.typepad.com/through_the_interface/2008/11/creating-a-cust.html#sthash.YVS3V39x.dpuf
    ''' </summary>
    ''' <param name="strTableStyleName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function TableStyleExist(ByRef strTableStyleName As String) As Boolean

        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim db As Database = doc.Database
        Dim tr As Transaction = doc.TransactionManager.StartTransaction()
        Using tr

            Dim sd As DBDictionary = DirectCast(tr.GetObject(db.TableStyleDictionaryId, OpenMode.ForRead), DBDictionary)
            If sd.Contains(strTableStyleName) Then
                Return True
            Else
                Return False
            End If

        End Using


    End Function

    ''' <summary>
    ''' Crates new autocad TYPE objects such as the ones below - if they are read only then they can only be set to current
    ''' TEXTSTYLES, TABLESTYLES, LINETYPES , DIMSTYLE, LAYERS,LAYOUTS,LINEWEIGHT,COLOR,INSUNITS,MULTILINESTYLES, PLOTSTYLES, PAGESETUPS, JUSTIFICATION, CUSTOM
    ''' </summary>
    ''' <param name="ItemName"></param>
    ''' <param name="Table_Type"></param>
    ''' <param name="makecurrent"></param>
    ''' <remarks></remarks>
    Sub CreateContent(ByRef ItemName As String, ByRef Table_Type As String, Optional ByRef makecurrent As Boolean = False)
        Try
            Dim item As Object
            Dim textstyleobject As Autodesk.AutoCAD.Interop.Common.AcadTextStyle

            item = Nothing

            Acad_MessageBox("Creating Content", , , , , , , True, logName)

            Select Case Table_Type

                Case CStr(WZ_BLOCK_TABLE)

                    ' Check to see if the object in this file already
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            If BlockExist(CStr(item)) = False Then
                                Acad_MessageBox("        You will need to create or import this Block:" & item.ToString, , , , , , , True, logName)
                            Else
                                Acad_MessageBox("        Block " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)
                            End If
                        Next item
                    Else
                        If BlockExist(ItemName) = False Then
                            Acad_MessageBox("    You will need to create or import this block:" & ItemName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("    Block " & ItemName & " is present in this drawing (not created).", , , , , , , True, logName)
                        End If
                    End If

                Case CStr(WZ_DIMSTYLE_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If DimStyleExist(CStr(item)) = False Then
                                Acad_MessageBox("        Dim style:" & item.ToString & " not found (default created)", , , , , , , True, logName)
                                ThisDrawingUtilities.DimStyles.Add(CStr(item))

                            Else
                                Acad_MessageBox("        Dim style " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)
                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If DimStyleExist(ItemName) = False Then
                            Acad_MessageBox("    Dim Style:" & ItemName & " not found (default created)", , , , , , , True, logName)
                            ThisDrawingUtilities.DimStyles.Add(ItemName)
                        Else
                            Acad_MessageBox("    Dim style " & ItemName & " is present in this drawing (not created).", , , , , , , True, logName)
                        End If
                    End If
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable("DIMSTYLE", ItemName)
                    End If

                Case CStr(WZ_LAYER_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If LayerExist(CStr(item)) = False Then
                                Acad_MessageBox("        Layer:" & item.ToString & " not found (default created)" & vbCrLf, , , , , , , True, logName)
                                ThisDrawingUtilities.Layers.Add(CStr(item))
                            Else
                                Acad_MessageBox("        Layer " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)
                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If LayerExist(ItemName) = False Then
                            Acad_MessageBox("    Layer:" & ItemName & " not found (default created)", , , , , , , True, logName)
                            ThisDrawingUtilities.Layers.Add(ItemName)
                        Else
                            Acad_MessageBox("    Layer " & ItemName & " is present in this drawing (not created).", , , , , , , True, logName)
                        End If
                    End If
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable("CLAYER", ItemName)
                    End If

                Case CStr(WZ_LINETYPE_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If LineTypeExist(CStr(item)) = False Then
                                Acad_MessageBox("        Line type:" & item.ToString & " not found (default created)", , , , , , , True, logName)
                                ThisDrawingUtilities.Linetypes.Add(CStr(item))
                            Else
                                Acad_MessageBox("        Line type " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)
                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If LineTypeExist(ItemName) = False Then
                            Acad_MessageBox("    Line type:" & ItemName & " not found (default created)", , , , , , , True, logName)
                            ThisDrawingUtilities.Linetypes.Add(ItemName)
                        Else
                            Acad_MessageBox("    Line type " & ItemName & " is present in this drawing (not created).", , , , , , , True, logName)
                        End If
                    End If
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable("CLTYPE", ItemName)
                    End If

                Case CStr(WZ_TEXTSTYLE_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If TextStyleExist(CStr(item)) = False Then
                                Acad_MessageBox("        TextStyle:" & item.ToString & " not found (default created)", , , , , , , True, logName)
                                textstyleobject = ThisDrawingUtilities.TextStyles.Add(CStr(item))
                                textstyleobject.SetFont("txt", False, False, 0, 0)
                            Else
                                Acad_MessageBox("        TextStyle " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)

                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If TextStyleExist(ItemName) = False Then
                            Acad_MessageBox("    TextStyle:" & ItemName & " not found (default created)", , , , , , , True, logName)

                            textstyleobject = ThisDrawingUtilities.TextStyles.Add(ItemName)
                            textstyleobject.SetFont("txt", False, False, 0, 0)
                        Else
                            Acad_MessageBox("    TextStyle " & ItemName & " is present in this drawing (not created).", , , , , , , True, logName)

                        End If
                    End If
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable("TEXTSTYLE", ItemName)
                    End If

                Case CStr(WZ_LAYOUTS_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If LayoutExist(CStr(item)) = False Then
                                Acad_MessageBox("        Layout:" & item.ToString & " not found (default created)", , , , , , , True, logName)

                                ThisDrawingUtilities.Layouts.Add(CStr(item))
                            Else
                                Acad_MessageBox("        Layout " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)
                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If LayoutExist(ItemName) = False Then
                            Acad_MessageBox("    Layout:" & ItemName & " not found (default created)", , , , , , , True, logName)

                            ThisDrawingUtilities.Layouts.Add(ItemName)
                        Else
                            Acad_MessageBox("    Layout " & item.ToString & " is present in this drawing (not created).", , , , , , , True, logName)

                        End If
                    End If

                Case CStr(WZ_LINEWEIGHT)
                    ' This object cannot be imported but it can be set current if desired
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        Line weight:" & item.ToString & " import not required", , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    Line weight:" & ItemName & " import not required", , , , , , , True, logName)

                    End If


                Case CStr(WZ_COLOUR)
                    ' This object cannot be imported but it can be set current if desired
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        Colour:" & item.ToString & " import not required", , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    Colour:" & ItemName & " import not required", , , , , , , True, logName)

                    End If

                Case CStr(WZ_INSUNITS)
                    ' This object cannot be imported but it can be set current if desired
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        InsUnits:" & item.ToString & " import not required", , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    InsUnits:" & ItemName & " import not required", , , , , , , True, logName)

                    End If

                Case CStr(WZ_CUSTOM)
                    ' This object cannot be imported but it can be set current if desired
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        Custom:" & item.ToString & " import not required", , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    Custom:" & ItemName & " import not required", , , , , , , True, logName)

                    End If

                Case CStr(WZ_MULTILINESTYLE_TABLE)

                    Acad_MessageBox("You may need to create or import this MultiLine: " & ItemName, "Style May Require Manual Import", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        You will need to create or import this multiline style: " & item.ToString, , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    You will need to create or import this multiline styles: " & ItemName, , , , , , , True, logName)

                    End If


                Case CStr(WZ_TABLESTYLE_TABLE)

                    Acad_MessageBox("You may need to create or import this TableStyle: " & ItemName, "Style May Require Manual Import", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        You will need to create or import this tablestyle: " & item.ToString, , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    You will need to create or import this tablestyle: " & ItemName, , , , , , , True, logName)

                    End If

                Case CStr(WZ_PLOTSTYLES_TABLE)

                    Acad_MessageBox("You may need to create or import this PlotStyle: " & ItemName, "Style May Require Manual Import", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        You will need to create or import this plotstyle: " & item.ToString, , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    You will need to create or import this plotstyle: " & ItemName, , , , , , , True, logName)

                    End If

                Case CStr(WZ_PAGESETUPS_TABLE)

                    Acad_MessageBox("You may need to create or import this PageSetup: " & ItemName, "Style May Require Manual Import", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        You will need to create or import this pagesetup: " & item.ToString, , , , , , , True, logName)

                        Next item
                    Else
                        Acad_MessageBox("    You will need to create or import this pagesetup: " & ItemName, , , , , , , True, logName)

                    End If

                Case CStr(WZ_JUSTIFICATIONS)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        No content required - Justification:" & item.ToString & " rule has been recorded", , , , , , , True, logName)
                        Next item
                    Else
                        Acad_MessageBox("    No content required - Justification:" & ItemName & " rule has been recorded", , , , , , , True, logName)
                    End If

                Case Else
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            Acad_MessageBox("        The non AutoCAD item: " & item.ToString & " has been recorded no content created.", , , , , , , True, logName)
                        Next item
                    Else
                        Acad_MessageBox("    The non AutoCAD item: " & ItemName & " has been recorded no content created.", , , , , , , True, logName)
                    End If

            End Select
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' For the merge done at the configuration creation level we do not want to use any of the user default overrides.
    ''' For the merge done at the configuration selector process we do need to include the user defaults
    ''' </summary>
    ''' <param name="bolBuildingCFG"></param>
    ''' <remarks></remarks>
    Sub MergeCFGFiles(ByRef bolBuildingCFG As Boolean)
        Try

            Dim rl As Rule

            If bolBuildingCFG = True Then
                ' This means we are in the process of building content for a configuration and we need to get the files from the
                ' (Called by the ContentWizard) - User files are not taken into account
            Else

                ' This means we are in the process of creating a configuration for the user to work with
                ' And we need to get the files from a configuration location
                ' CURRENT USER LOCAL WORKING AREA
                ' (Called from the configuration selector)

                ' This should be windows xp compatible
                ' strCFGPath = RUNTIMEConfigsRoot

                ' Find out the configuration name so we can work out the directory structure
                rl = RuleAccessors.GetRule("FULLCONFIGNAME")

                If rl Is Nothing Then

                Else

                    ' Added  rl.value to these but it wasn't required before need to check

                    If IsThisAnOldConfigName() = True Then

                        'FileMerger(Path.Combine(Settings.Manager.AutoCAD.Path, "UserDataCache\Settings", "Acad.pgp"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Acad.pgp"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Corporate.pgp"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Business Unit.pgp"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Discipline.pgp"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Office.pgp"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Client.pgp"), _
                        '           ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Settings", Settings.Manager.AE.UserPGPFileName))

                        'FileMerger(Settings.Manager.AutoCAD.Path.CombinePath("UserDataCache\Settings", "Acadiso.lin"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Acadiso.lin"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Corporate.lin"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Business Unit.lin"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Discipline.lin"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Office.lin"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Client.lin"), _
                        '           ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Settings", "USER.LIN"))

                        'FileMerger(Settings.Manager.AutoCAD.Path.CombinePath("UserDataCache\Settings", "Acadiso.pat"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Acadiso.pat"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Corporate.pat"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Business Unit.pat"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Discipline.pat"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Office.pat"), _
                        '           RUNTIMEConfigPath.CombinePath("Settings\Client.pat"), _
                        '           ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Settings", "USER.PAT"))
                    Else

                        '' For new configs the config folder is read only so when merging files place the results in the Support folders
                        FileMerger(Path.Combine(Settings.Manager.AutoCAD.Path, "UserDataCache\en-us\Support", "Acad.pgp"),
                                   Settings.Manager.AutoCAD.WorkingFolder.CombinePath("Support\Acad.pgp"),
                                   RUNTIMEConfigPath.CombinePath("Support\Corporate.pgp"),
                                   RUNTIMEConfigPath.CombinePath("Support\Business Unit.pgp"),
                                   RUNTIMEConfigPath.CombinePath("Support\Discipline.pgp"),
                                   RUNTIMEConfigPath.CombinePath("Support\Office.pgp"),
                                   RUNTIMEConfigPath.CombinePath("Support\Client.pgp"),
                                   ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Support", Settings.Manager.AE.UserPGPFileName))

                        FileMerger(Settings.Manager.AutoCAD.Path.CombinePath("UserDataCache\en-us\Support", "Acadiso.lin"),
                                   Settings.Manager.AutoCAD.WorkingFolder.CombinePath("Support\Acadiso.lin"),
                                   RUNTIMEConfigPath.CombinePath("Support\Corporate.lin"),
                                   RUNTIMEConfigPath.CombinePath("Support\Business Unit.lin"),
                                   RUNTIMEConfigPath.CombinePath("Support\Discipline.lin"),
                                   RUNTIMEConfigPath.CombinePath("Support\Office.lin"),
                                   RUNTIMEConfigPath.CombinePath("Support\Client.lin"),
                                   ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Support", "USER.LIN"))

                        FileMerger(Settings.Manager.AutoCAD.Path.CombinePath("UserDataCache\en-us\Support", "Acadiso.pat"),
                                   Settings.Manager.AutoCAD.WorkingFolder.CombinePath("Support\Acadiso.pat"),
                                   RUNTIMEConfigPath.CombinePath("Support\Corporate.pat"),
                                   RUNTIMEConfigPath.CombinePath("Support\Business Unit.pat"),
                                   RUNTIMEConfigPath.CombinePath("Support\Discipline.pat"),
                                   RUNTIMEConfigPath.CombinePath("Support\Office.pat"),
                                   RUNTIMEConfigPath.CombinePath("Support\Client.pat"),
                                   ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX").ToString.CombinePath("Support", "USER.PAT"))
                    End If

                End If

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Merges all text files from all levels for instance Corporate, Business Unit, Discipline, Office, Client and User files 
    ''' Example Acad.pgp + Coporate.PGP + BusinessUnit.pgp + Discipline.pgp + Office.pgp + Client.pgp + User.pgp = Acad.PGP in user area at runtime
    ''' </summary>
    ''' <param name="strMasterFile"></param>
    ''' <param name="strFNameResult"></param>
    ''' <param name="strFile1"></param>
    ''' <param name="strFile2"></param>
    ''' <param name="strFile3"></param>
    ''' <param name="strFile4"></param>
    ''' <param name="strFile5"></param>
    ''' <param name="strFile6"></param>
    ''' <param name="strFile7"></param>
    ''' <remarks></remarks>
    Sub FileMerger(ByRef strMasterFile As String, ByRef strFNameResult As String, Optional ByRef strFile1 As String = "", Optional ByRef strFile2 As String = "", Optional ByRef strFile3 As String = "", Optional ByRef strFile4 As String = "", Optional ByRef strFile5 As String = "", Optional ByRef strFile6 As String = "", Optional ByRef strFile7 As String = "")
        Try
            Dim strLineRead As String

            If System.IO.File.Exists(strMasterFile) = False Then
                Acad_MessageBox(strMasterFile & " *** MISSING MASTER File ***", "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            'objSystemFile.CopyFile(strMasterFile, strFNameResult)
            My.Computer.FileSystem.CopyFile(strMasterFile, strFNameResult, True)

            FileOpen(1, strFNameResult, Microsoft.VisualBasic.OpenMode.Append) ' This is the new pgp file

            If System.IO.File.Exists(strFile1) = True And strFile1 <> "" Then
                FileOpen(2, strFile1, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the corporate level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~Client]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)
                    PrintLine(1, strLineRead)
                End While
            End If
            FileClose(2)

            If System.IO.File.Exists(strFile2) = True And strFile2 <> "" Then
                FileOpen(2, strFile2, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the business unit level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~Office]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)
                    PrintLine(1, strLineRead)
                End While
            End If
            FileClose(2)

            If System.IO.File.Exists(strFile3) = True And strFile3 <> "" Then
                FileOpen(2, strFile3, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the Discipline level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~Discipline]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)
                    PrintLine(1, strLineRead)
                End While
            End If
            FileClose(2)

            If System.IO.File.Exists(strFile4) = True And strFile4 <> "" Then
                FileOpen(2, strFile4, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the Regional level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~Business Unit]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)
                    PrintLine(1, strLineRead)
                End While
            End If
            FileClose(2)

            If System.IO.File.Exists(strFile5) = True And strFile5 <> "" Then
                FileOpen(2, strFile5, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the Client level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~Corporate]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)

                    ' This next section of code was added because we didn't create a tool for this
                    ' We didn't want to rebuild all configs so this bodgy fix was added
                    If UCase(strLineRead) = UCase("ID_STDS      [Jacobs Standard Drawings]^C^C_browser ""http://intranet.Jacobs.com/cad/SKM_CAD_Std_Drgs.html""") Then
                        strLineRead = "ID_STDS      [Jacobs Standard Drawings]^C^C_browser ""http://intranet.Jacobs.com/FunctionalUnits/BusinessProcesses/CAD/skm_cad_std_drgs.htm"""
                    End If
                    If UCase(strLineRead) = UCase("ID_STDS     [_Button(""Jacobs Standard Drawings"", ""Jacobs_STANDARDDRAWINGS.bmp"", ""Jacobs_STANDARDDRAWINGS"")]^C^C_browser ""http://intranet.Jacobs.com/cad/SKM_CAD_Std_Drgs.html""") Then
                        strLineRead = "ID_STDS     [_Button(""Jacobs Standard Drawings"", ""Jacobs_STANDARDDRAWINGS.bmp"", ""Jacobs_STANDARDDRAWINGS"")]^C^C_browser ""http://intranet.Jacobs.com/FunctionalUnits/BusinessProcesses/CAD/skm_cad_std_drgs.htm"""
                    End If

                    PrintLine(1, strLineRead)
                End While
            End If
            FileClose(2)

            If System.IO.File.Exists(strFile6) = True And strFile6 <> "" Then
                FileOpen(2, strFile6, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the Client level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~User]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)
                    PrintLine(1, strLineRead)
                End While
            End If
            FileClose(2)

            If System.IO.File.Exists(strFile7) = True And strFile7 <> "" Then
                FileOpen(2, strFile7, Microsoft.VisualBasic.OpenMode.Input) ' This is the file that contains new additions on the Client level

                If strMasterFile Like "*Jacobs-MAIN.MNU" Then
                    PrintLine(1, "                  [~--]")
                    PrintLine(1, "                  [~User]")
                End If

                While Not EOF(2)
                    strLineRead = LineInput(2)
                    PrintLine(1, strLineRead)
                End While
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        FileClose(1)
        FileClose(2)

    End Sub

    ''' <summary>
    ''' Used when s witching from one config to the other all files are deleted except fonts and plot style tables.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CleanUpFiles()

        Try
            Dim sWorkingPath As String = Settings.Manager.AutoCAD.WorkingFolder & "\Support\"

            Select Case ConfigurationLevel

                Case "CLIENT"
                    RemoveFiles(sWorkingPath.CombinePath("Office"))
                    RemoveFiles(sWorkingPath.CombinePath("Discipline"))
                    RemoveFiles(sWorkingPath.CombinePath("Business Unit"))
                    RemoveFiles(sWorkingPath.CombinePath("Corporate"))

                Case "OFFICE"
                    RemoveFiles(sWorkingPath.CombinePath("Discipline"))
                    RemoveFiles(sWorkingPath.CombinePath("Business Unit"))
                    RemoveFiles(sWorkingPath.CombinePath("Corporate"))

                Case "DISCIPLINE"
                    RemoveFiles(sWorkingPath.CombinePath("Business Unit"))
                    RemoveFiles(sWorkingPath.CombinePath("Corporate"))

                Case "BUSINESS UNIT"
                    RemoveFiles(sWorkingPath.CombinePath("Corporate"))

                Case "CORPORATE"
                    ' Nothing to clean up...

            End Select
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try


    End Sub

    ''' <summary>
    ''' Removes and replaces all config files
    ''' </summary>
    ''' <remarks></remarks>
    Sub RefreshCFGFiles()
        Try
            Dim sworkingpath As String = Settings.Manager.AutoCAD.WorkingFolder & "\Support\"

            Select Case UCase(ConfigurationLevel)

                Case "CLIENT"
                    RemoveFiles(sworkingpath.CombinePath("Corporate"))
                    RemoveFiles(sworkingpath.CombinePath("Business Unit"))
                    RemoveFiles(sworkingpath.CombinePath("Discipline"))
                    RemoveFiles(sworkingpath.CombinePath("Office"))

                Case "OFFICE"
                    RemoveFiles(sworkingpath.CombinePath("Corporate"))
                    RemoveFiles(sworkingpath.CombinePath("Business Unit"))
                    RemoveFiles(sworkingpath.CombinePath("Discipline"))

                Case "DISCIPLINE"
                    RemoveFiles(sworkingpath.CombinePath("Corporate"))
                    RemoveFiles(sworkingpath.CombinePath("Business Unit"))

                Case "BUSINESS UNIT"
                    RemoveFiles(sworkingpath.CombinePath("Corporate"))

            End Select
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Once these files are merged they are no longer required
    ''' </summary>
    ''' <param name="fName"></param>
    ''' <remarks></remarks>
    Sub RemoveFiles(ByRef fName As String)
        Try
            ' Clean up any corporate files that may have been used

            If System.IO.File.Exists(fName & "-Main.mnu") = True Then
                My.Computer.FileSystem.DeleteFile(fName & "-Main.mnu", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & "-ToolBar.mnu") = True Then
                My.Computer.FileSystem.DeleteFile(fName & "-ToolBar.mnu", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & "-Help.mnu") = True Then
                My.Computer.FileSystem.DeleteFile(fName & "-Help.mnu", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & ".pgp") = True Then
                My.Computer.FileSystem.DeleteFile(fName & ".pgp", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & ".mnl") = True Then
                My.Computer.FileSystem.DeleteFile(fName & ".mnl", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & "-Accelerators.mnu") = True Then
                My.Computer.FileSystem.DeleteFile(fName & "-Accelerators.mnu", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & "-Flyouts.mnu") = True Then
                My.Computer.FileSystem.DeleteFile(fName & "-Flyouts.mnu", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & ".xml") = True Then
                My.Computer.FileSystem.DeleteFile(fName & ".xml", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & ".lin") = True Then
                My.Computer.FileSystem.DeleteFile(fName & ".lin", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            If System.IO.File.Exists(fName & ".pat") = True Then
                My.Computer.FileSystem.DeleteFile(fName & ".pat", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            End If

            'If System.IO.File.Exists(fName & "Blocks.csv") = True Then
            '    My.Computer.FileSystem.DeleteFile(fName & "Blocks.csv", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.SendToRecycleBin, FileIO.UICancelOption.ThrowException)
            'End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Magic routine used to populate a combo box based on type and rules, work var Settings that should be in place
    ''' </summary>
    ''' <param name="cboxname"></param>
    ''' <param name="strRuleID"></param>
    ''' <param name="sPopulateMode"></param>
    ''' <param name="sSetDefaultMode"></param>
    ''' <param name="sSysVar"></param>
    ''' <param name="sRuleValue"></param>
    ''' <param name="bIgnoreOverride"></param>
    ''' <remarks></remarks>
    Sub PopulateComboBox(ByRef cboxname As System.Windows.Forms.ComboBox, ByRef strRuleID As String, ByRef sPopulateMode As String, ByRef sSetDefaultMode As String, ByRef sSysVar As String, Optional ByRef sRuleValue As String = "", Optional ByRef bIgnoreOverride As Boolean = True)
        Try
            Dim i As Object
            Dim strCurStyle As String = ""
            Dim sFoundRule As String
            Dim sFoundRules() As String
            Dim vItem As Object
            Dim iCurrentColour As Integer
            Dim strFirstRule As String = ""
            Dim rrule As Rule

            ' Clear the combo box to start with
            cboxname.Items.Clear()

            ' If we want to just show the rule value in the drop down list
            ' and this drawing has been configured
            If sPopulateMode = "JustRuleValues" And ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                ' Search to see if there is a rule present
                sFoundRule = RuleAccessors.GetruleValue(strRuleID, sRuleValue, bIgnoreOverride)

                If sFoundRule <> "" Then

                    rrule = RuleAccessors.GetRule(strRuleID)

                    ' If it's configured and the rule was found check to see if it's a multi value rule.
                    If UBound(Split(sFoundRule, ";")) <> 0 Then
                        ' if there was then split it and add each item to the drop down list (combobox)
                        sFoundRules = Split(sFoundRule, ";")
                        For Each vItem In sFoundRules
                            cboxname.Items.Add(CStr(vItem))
                        Next vItem
                        strCurStyle = sFoundRules(0)
                    Else
                        ' If it's not a multivalue rule then just use the value in the rule
                        cboxname.Items.Add(sFoundRule)
                        strCurStyle = sFoundRule
                    End If
                Else
                    ' This may be a case where we are using the content wizard and trying to populate with the values in tools.ini
                    If sRuleValue <> "" Then
                        If UBound(Split(sRuleValue, ";")) <> 0 Then
                            ' if there was then split it and add each item to the dropdown list (combobox)
                            sFoundRules = Split(sRuleValue, ";")
                            For Each vItem In sFoundRules
                                cboxname.Items.Add(CStr(vItem))
                            Next vItem
                            strCurStyle = sFoundRules(0)
                        Else
                            ' If it's not a multivalue rule then just use the value in the rule
                            cboxname.Items.Add(sRuleValue)
                            strCurStyle = sRuleValue
                        End If
                    Else
                        Acad_MessageBox("Rule was not found: " & strRuleID & "  This drawing was not configured correctly", "Rule Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End If
            End If

            ' Theory is that you should also get the rule values in here as they should be present in the DWG

            If sPopulateMode = "AllAvailable" Or ThisDrawingIsConfigured() = False Then

                ' populate mode was use all available layers to populate list
                ' or this drawing is not configured

                Select Case sSysVar

                    Case "CLAYER"
                        strCurStyle = CStr(ThisDrawingUtilities.GetVariable(sSysVar))
                        For i = 0 To (ThisDrawingUtilities.Layers.Count - 1)
                            cboxname.Items.Add(ThisDrawingUtilities.Layers.Item(i).Name)
                        Next

                    Case "TEXTSTYLE"
                        strCurStyle = CStr(ThisDrawingUtilities.GetVariable(sSysVar))
                        For i = 0 To (ThisDrawingUtilities.TextStyles.Count - 1)
                            cboxname.Items.Add(ThisDrawingUtilities.TextStyles.Item(i).Name)
                        Next

                    Case "DIMSTYLE"
                        strCurStyle = CStr(ThisDrawingUtilities.GetVariable(sSysVar))
                        For i = 0 To (ThisDrawingUtilities.DimStyles.Count - 1)
                            cboxname.Items.Add(ThisDrawingUtilities.DimStyles.Item(i).Name)
                        Next

                    Case "CTABLESTYLE"

                        Acad_MessageBox("PopulateComboBox function - NEEDS WORK in the CTABLESTYLE area", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Case "CELWEIGHT"
                        Acad_MessageBox("PopulateComboBox function - NEEDS WORK in the CLWEIGHT area", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Case "PEN"
                        strCurStyle = "Automatic"
                        For i = 0 To 32
                            If CInt(i) = 0 Then
                                cboxname.Items.Add("Automatic")
                            Else
                                cboxname.Items.Add(i)
                            End If
                        Next

                    Case "BLOCK"
                        strCurStyle = ThisDrawingUtilities.Blocks.Item(0).Name
                        For i = 0 To (ThisDrawingUtilities.Blocks.Count - 1)
                            cboxname.Items.Add(ThisDrawingUtilities.Blocks.Item(i).Name)
                        Next

                    Case "CELTYPE"
                        strCurStyle = CStr(ThisDrawingUtilities.GetVariable(sSysVar))
                        For i = 0 To (ThisDrawingUtilities.Linetypes.Count - 1)
                            cboxname.Items.Add(ThisDrawingUtilities.Linetypes.Item(i).Name)
                        Next

                    Case "CECOLOR"
                        strCurStyle = CStr(ThisDrawingUtilities.GetVariable(sSysVar))
                        If UCase(strCurStyle) = "BYLAYER" Then
                            iCurrentColour = 256
                        Else
                            If UCase(strCurStyle) = "BYBLOCK" Then
                                iCurrentColour = 0
                            Else
                                iCurrentColour = CShort(strCurStyle)
                            End If
                        End If
                        For i = 0 To 256
                            If CInt(i) = 0 Then
                                cboxname.Items.Add("ByBlock")
                            Else
                                If CInt(i) = 256 Then
                                    cboxname.Items.Add("ByLayer")
                                Else
                                    cboxname.Items.Add(i)
                                End If
                            End If
                        Next
                        strCurStyle = CStr(iCurrentColour)

                    Case "TEXTJUSTIFICATION"

                        cboxname.Items.Add("Align")
                        cboxname.Items.Add("BC")
                        cboxname.Items.Add("BL")
                        cboxname.Items.Add("BR")
                        cboxname.Items.Add("Center")
                        cboxname.Items.Add("Fit")
                        cboxname.Items.Add("MC")
                        cboxname.Items.Add("Middle")
                        cboxname.Items.Add("ML")
                        cboxname.Items.Add("MR")
                        cboxname.Items.Add("Right")
                        cboxname.Items.Add("TC")
                        cboxname.Items.Add("TL")
                        cboxname.Items.Add("TR")

                        strCurStyle = "BL" ' This is the AutoCAD default text justification but is not stored anywhere

                    Case "TEXTTYPES"
                        cboxname.Items.Add("DTEXT")
                        cboxname.Items.Add("MTEXT")

                        strCurStyle = sRuleValue

                    Case "AUPREC0" ' Decimal Degrees

                        cboxname.Items.Add(("0")) ' 0
                        cboxname.Items.Add(("0.0")) ' 1
                        cboxname.Items.Add(("0.00")) ' 2
                        cboxname.Items.Add(("0.000")) ' 3
                        cboxname.Items.Add(("0.0000")) ' 4
                        cboxname.Items.Add(("0.00000")) ' 5
                        cboxname.Items.Add(("0.000000")) ' 6
                        cboxname.Items.Add(("0.0000000")) ' 7
                        cboxname.Items.Add(("0.00000000")) ' 8

                        strCurStyle = sRuleValue

                    Case "AUPREC1" ' Degrees minutes and seconds

                        cboxname.Items.Add(("0d")) ' 0
                        cboxname.Items.Add(("0d00")) ' 1
                        cboxname.Items.Add(("0d00")) ' 2
                        cboxname.Items.Add(("0d00'00")) ' 3
                        cboxname.Items.Add(("0d00'00")) ' 4
                        cboxname.Items.Add(("0d00'00.0")) ' 5
                        cboxname.Items.Add(("0d00'00.00")) ' 6
                        cboxname.Items.Add(("0d00'00.000")) ' 7
                        cboxname.Items.Add(("0d00'00.0000")) ' 8

                        strCurStyle = sRuleValue

                    Case "AUPREC2" ' Grads

                        cboxname.Items.Add(("0g")) ' 0
                        cboxname.Items.Add(("0.0g")) ' 1
                        cboxname.Items.Add(("0.00g")) ' 2
                        cboxname.Items.Add(("0.000g")) ' 3
                        cboxname.Items.Add(("0.0000g")) ' 4
                        cboxname.Items.Add(("0.00000g")) ' 5
                        cboxname.Items.Add(("0.000000g")) ' 6
                        cboxname.Items.Add(("0.0000000g")) ' 7
                        cboxname.Items.Add(("0.00000000g")) ' 8

                        strCurStyle = sRuleValue

                    Case "AUPREC3" ' Radians

                        cboxname.Items.Add(("0r")) ' 0
                        cboxname.Items.Add(("0.0r")) ' 1
                        cboxname.Items.Add(("0.00r")) ' 2
                        cboxname.Items.Add(("0.000r")) ' 3
                        cboxname.Items.Add(("0.0000r")) ' 4
                        cboxname.Items.Add(("0.00000r")) ' 5
                        cboxname.Items.Add(("0.000000r")) ' 6
                        cboxname.Items.Add(("0.0000000r")) ' 7
                        cboxname.Items.Add(("0.00000000r")) ' 8

                        strCurStyle = sRuleValue

                    Case "AUPREC4" ' Surveyor's Units

                        cboxname.Items.Add(("N0dE")) ' 0
                        cboxname.Items.Add(("N0d00E")) ' 1
                        cboxname.Items.Add(("N0d00E")) ' 2
                        cboxname.Items.Add(("N0d00'00" & Chr(34) & "E")) ' 3
                        cboxname.Items.Add(("N0d00'00" & Chr(34) & "E")) ' 4
                        cboxname.Items.Add(("N0d00'00.0" & Chr(34) & "E")) ' 5
                        cboxname.Items.Add(("N0d00'00.00" & Chr(34) & "E")) ' 6
                        cboxname.Items.Add(("N0d00'00.000" & Chr(34) & "E")) ' 7
                        cboxname.Items.Add(("N0d00'00.0000" & Chr(34) & "E")) ' 8

                        strCurStyle = sRuleValue

                    Case "AUPREC"

                        cboxname.Items.Add(("Decimal degrees"))
                        cboxname.Items.Add(("Deg/Min/Sec"))
                        cboxname.Items.Add(("Gradians"))
                        cboxname.Items.Add(("Radians"))
                        cboxname.Items.Add(("Surveyor 's units"))

                        strCurStyle = sRuleValue

                    Case "AUNITS"

                        cboxname.Items.Add(("Decimal degrees"))
                        cboxname.Items.Add(("Deg/Min/Sec"))
                        cboxname.Items.Add(("Gradians"))
                        cboxname.Items.Add(("Radians"))
                        cboxname.Items.Add(("Surveyor 's units"))

                        strCurStyle = sRuleValue

                    Case "INSUNITS"

                        'cboxname.Items.Add(("Unspecified (No units)"))
                        'cboxname.Items.Add(("Inches"))
                        'cboxname.Items.Add(("Feet"))
                        'cboxname.Items.Add(("Miles"))
                        cboxname.Items.Add(("Millimeters"))
                        'cboxname.Items.Add(("Centimeters"))
                        cboxname.Items.Add(("Meters"))
                        'cboxname.Items.Add(("Kilometers"))
                        'cboxname.Items.Add(("Microinches"))
                        'cboxname.Items.Add(("Mils"))
                        'cboxname.Items.Add(("Yards"))
                        'cboxname.Items.Add(("Angstroms"))
                        'cboxname.Items.Add(("Nanometers"))
                        'cboxname.Items.Add(("Microns"))
                        'cboxname.Items.Add(("Decimeters"))
                        'cboxname.Items.Add(("Decameters"))
                        'cboxname.Items.Add(("Hectometers"))
                        'cboxname.Items.Add(("Gigameters"))
                        'cboxname.Items.Add(("Astronomical Units"))
                        'cboxname.Items.Add(("Light Years"))
                        'cboxname.Items.Add(("Parsecs"))

                        strCurStyle = sRuleValue

                    Case "LUNITS"

                        cboxname.Items.Add(("Scientific"))
                        cboxname.Items.Add(("Decimal"))
                        cboxname.Items.Add(("Engineering"))
                        cboxname.Items.Add(("Architectural"))
                        cboxname.Items.Add(("Fractional"))

                        strCurStyle = sRuleValue

                    Case "LUPREC0" ' Scientific

                        cboxname.Items.Add(("0E+01"))
                        cboxname.Items.Add(("0.0E+01"))
                        cboxname.Items.Add(("0.00E+01"))
                        cboxname.Items.Add(("0.000E+01"))
                        cboxname.Items.Add(("0.0000E+01"))
                        cboxname.Items.Add(("0.00000E+01"))
                        cboxname.Items.Add(("0.000000E+01"))
                        cboxname.Items.Add(("0.0000000E+01"))
                        cboxname.Items.Add(("0.00000000E+01"))

                        strCurStyle = sRuleValue

                    Case "LUPREC1" ' Decimal

                        cboxname.Items.Add(("0"))
                        cboxname.Items.Add(("0.0"))
                        cboxname.Items.Add(("0.00"))
                        cboxname.Items.Add(("0.000"))
                        cboxname.Items.Add(("0.0000"))
                        cboxname.Items.Add(("0.00000"))
                        cboxname.Items.Add(("0.000000"))
                        cboxname.Items.Add(("0.0000000"))
                        cboxname.Items.Add(("0.00000000"))

                        strCurStyle = sRuleValue

                    Case "LUPREC2" ' Engineering

                        cboxname.Items.Add(("0'-0"))
                        cboxname.Items.Add(("0'-0.0"))
                        cboxname.Items.Add(("0'-0.00"))
                        cboxname.Items.Add(("0'-0.000"))
                        cboxname.Items.Add(("0'-0.0000"))
                        cboxname.Items.Add(("0'-0.00000"))
                        cboxname.Items.Add(("0'-0.000000"))
                        cboxname.Items.Add(("0'-0.0000000"))
                        cboxname.Items.Add(("0'-0.00000000"))

                        strCurStyle = sRuleValue

                    Case "LUPREC3" ' Architectural

                        cboxname.Items.Add(("0'-0"))
                        cboxname.Items.Add(("0'-0 1/2"))
                        cboxname.Items.Add(("0'-0 1/4"))
                        cboxname.Items.Add(("0'-0 1/8"))
                        cboxname.Items.Add(("0'-0 1/16"))
                        cboxname.Items.Add(("0'-0 1/32"))
                        cboxname.Items.Add(("0'-0 1/64"))
                        cboxname.Items.Add(("0'-0 1/128"))
                        cboxname.Items.Add(("0'-0 1/256"))

                        strCurStyle = sRuleValue

                    Case "LUPREC4" ' Fractional

                        cboxname.Items.Add(("0"))
                        cboxname.Items.Add(("0 1/2"))
                        cboxname.Items.Add(("0 1/4"))
                        cboxname.Items.Add(("0 1/8"))
                        cboxname.Items.Add(("0 1/16"))
                        cboxname.Items.Add(("0 1/32"))
                        cboxname.Items.Add(("0 1/64"))
                        cboxname.Items.Add(("0 1/128"))
                        cboxname.Items.Add(("0 1/256"))

                        strCurStyle = sRuleValue

                    Case "CUSTOM"

                        Dim items() As String = (Split(sRuleValue, ";"))
                        Dim element As String
                        For Each element In items
                            cboxname.Items.Add(element)
                        Next

                        strCurStyle = items(0) ' This default is the first one in the list

                End Select


                ' Search to see if there is a rule or workvar present
                sFoundRule = RuleAccessors.GetruleValue(strRuleID, sRuleValue, bIgnoreOverride)

                If sFoundRule <> "" And RuleAndContentArePresent(strRuleID) = True Then

                    rrule = RuleAccessors.GetRule(strRuleID)

                    ' If it's configured and the rule was found check to see if it's a multivalue rule.
                    If UBound(Split(sFoundRule, ";")) <> 0 Then
                        ' if there was then split it and add each item to the dropdown list (combobox)
                        sFoundRules = Split(sFoundRule, ";")

                        For Each vItem In sFoundRules
                            If ItemIsInCombobox(cboxname, CStr(vItem)) = False Then
                                cboxname.Items.Add(CStr(vItem))
                            End If
                        Next vItem

                        strFirstRule = sFoundRules(0)

                    Else
                        ' If it's not a multivalue rule then just use the value in the rule
                        If ItemIsInCombobox(cboxname, sFoundRule) = False Then
                            cboxname.Items.Add(sFoundRule)
                        End If
                        strFirstRule = sFoundRule

                    End If
                Else
                    strFirstRule = strCurStyle
                End If


            End If

            ' To set the default value
            Dim sRuleval As String
            Select Case UCase(sSetDefaultMode)

                Case UCase("UseFirstRule") ' set the 1st rule value to be the default one OR set the AutoCAD default to be the current one
                    '' Old code that used to set first in box now uses last rule or override ?
                    SetComboItem(cboxname, strFirstRule, 0, sSysVar)

                Case UCase("UsePrevious") ' set the last one we picked to be current IE. check for existence of workvar value

                    ' Check to see if a workvar is present and use it if it is

                    ' This is a bit tricky - I am telling it ignore the override just so that I can get only the override
                    ' because the getrulevalue function will try appending the "-DlgBox" to it and will never find "ruleid-DlbBox-DlgBox" so it will think it
                    ' is looking for the base rule called "ruleid-DlgBox" and if it can't find it will return ""
                    ' Hence it only looks for the Override
                    'sRuleval = RuleAccessors.GetruleValue(strRuleID & "-DlgBox", "", True)

                    sRuleval = RuleAccessors.GetruleValue(strRuleID, "")

                    If sRuleval <> "" Then
                        SetComboItem(cboxname, sRuleval, 0, sSysVar)
                    Else
                        ' If the rule override is not present then use the first item on the rule if present else the AcadDefault
                        SetComboItem(cboxname, strCurStyle, 0, sSysVar)
                    End If

                Case UCase("UseAcadDef")
                    SetComboItem(cboxname, strCurStyle, 0, sSysVar)

            End Select


        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub
    ''' <summary>
    ''' Magic routine used to populate a combo box based on system variable - reads the drawing database and populates the combo box accordingly
    ''' The default value is also required
    ''' </summary>
    ''' <param name="TableCode"></param>
    ''' <param name="DefaultVal"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function PopulateColumnTableCode(ByRef TableCode As String, Optional DefaultVal As String = "") As System.Data.DataTable

        Try

            Dim i As Object
            Dim strCurStyle As String = ""
            'Dim iCurrentColour As Integer
            Dim items() As String = Nothing
            Dim cboxname As New System.Data.DataTable

            cboxname.Columns.Add("X", GetType(String))

            Select Case TableCode

                Case "4" ' LINETYPES
                    '' Populate the combo box
                    For i = 0 To (ThisDrawingUtilities.Linetypes.Count - 1)
                        'cboxname.Items.Add(ThisDrawingUtilities.Layers.Item(i).Name)
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = ThisDrawingUtilities.Linetypes.Item(i).Name
                        cboxname.Rows.Add(Nr)
                    Next
                    cboxname.AcceptChanges()

                Case "6" ' LAYER
                    '' Populate the combo box
                    For i = 0 To (ThisDrawingUtilities.Layers.Count - 1)
                        'cboxname.Items.Add(ThisDrawingUtilities.Layers.Item(i).Name)
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = ThisDrawingUtilities.Layers.Item(i).Name
                        cboxname.Rows.Add(Nr)
                    Next
                    cboxname.AcceptChanges()

                Case "8" ' Text Style
                    '' Populate the combo box
                    For i = 0 To (ThisDrawingUtilities.TextStyles.Count - 1)
                        'cboxname.Items.Add(ThisDrawingUtilities.TextStyles.Item(i).Name)
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = ThisDrawingUtilities.TextStyles.Item(i).Name
                        cboxname.Rows.Add(Nr)
                    Next
                    cboxname.AcceptChanges()

                Case "11" ' DIMSTYLE
                    '' Populate the combo box
                    For i = 0 To (ThisDrawingUtilities.DimStyles.Count - 1)
                        'cboxname.Items.Add(ThisDrawingUtilities.DimStyles.Item(i).Name)
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = ThisDrawingUtilities.DimStyles.Item(i).Name
                        cboxname.Rows.Add(Nr)
                    Next
                    cboxname.AcceptChanges()

                Case "24"
                    Acad_MessageBox("PopulateComboBox function - NEEDS WORK in the CTABLESTYLE area", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

                Case "25"
                    Acad_MessageBox("PopulateComboBox function - NEEDS WORK in the CLWEIGHT area", "Developer Note", MessageBoxButtons.OK, MessageBoxIcon.Information)

                Case "23"
                    '' Populate the combo box
                    For i = 0 To 32
                        If CInt(i) = 0 Then
                            'cboxname.Items.Add("Automatic")
                            Dim Nr As System.Data.DataRow = cboxname.NewRow
                            Nr.Item("X") = "Automatic"
                            cboxname.Rows.Add(Nr)
                        Else
                            'cboxname.Items.Add(i)
                            Dim Nr As System.Data.DataRow = cboxname.NewRow
                            Nr.Item("X") = i
                            cboxname.Rows.Add(Nr)
                        End If
                    Next
                    cboxname.AcceptChanges()

                Case "24"
                    '' Populate the combo box
                    For i = 0 To (ThisDrawingUtilities.Blocks.Count - 1)
                        'cboxname.Items.Add(ThisDrawingUtilities.Blocks.Item(i).Name)
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = ThisDrawingUtilities.Blocks.Item(i).Name
                        cboxname.Rows.Add(Nr)
                    Next
                    cboxname.AcceptChanges()

                Case "25"
                    '' Populate the combo box
                    For i = 0 To (ThisDrawingUtilities.Linetypes.Count - 1)
                        'cboxname.Items.Add(ThisDrawingUtilities.Linetypes.Item(i).Name)
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = ThisDrawingUtilities.Linetypes.Item(i).Name
                        cboxname.Rows.Add(Nr)
                    Next
                    cboxname.AcceptChanges()

                Case "62"   'CECOLOR
                    '' Populate the combo box
                    If UCase(strCurStyle) = "BYLAYER" Then
                        'iCurrentColour = 256
                        Dim Nr As System.Data.DataRow = cboxname.NewRow
                        Nr.Item("X") = 256
                        cboxname.Rows.Add(Nr)
                    Else
                        If UCase(strCurStyle) = "BYBLOCK" Then
                            'iCurrentColour = 0
                            Dim Nr As System.Data.DataRow = cboxname.NewRow
                            Nr.Item("X") = 0
                            cboxname.Rows.Add(Nr)

                        Else
                            'iCurrentColour = CShort(strCurStyle)
                            Dim Nr As System.Data.DataRow = cboxname.NewRow
                            Nr.Item("X") = CShort(strCurStyle)
                            cboxname.Rows.Add(Nr)
                        End If
                    End If
                    For i = 0 To 256
                        If CInt(i) = 0 Then
                            'cboxname.Items.Add("ByBlock")
                            Dim Nr As System.Data.DataRow = cboxname.NewRow
                            Nr.Item("X") = "ByBlock"
                            cboxname.Rows.Add(Nr)
                        Else
                            If CInt(i) = 256 Then
                                'cboxname.Items.Add("ByLayer")
                                Dim Nr As System.Data.DataRow = cboxname.NewRow
                                Nr.Item("X") = "ByLayer"
                                cboxname.Rows.Add(Nr)
                            Else
                                'cboxname.Items.Add(i)
                                Dim Nr As System.Data.DataRow = cboxname.NewRow
                                Nr.Item("X") = i
                                cboxname.Rows.Add(Nr)
                            End If
                        End If
                    Next
                    cboxname.AcceptChanges()

                Case "15"     'TEXTJUSTIFICATION
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "Align"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "BC"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "BL"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "BR"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Center"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Fit"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "MC"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Middle"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "ML"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "MR"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Right"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "TC"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "TL"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "TR"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add("Align")
                    'cboxname.Items.Add("BC")
                    'cboxname.Items.Add("BL")
                    'cboxname.Items.Add("BR")
                    'cboxname.Items.Add("Center")
                    'cboxname.Items.Add("Fit")
                    'cboxname.Items.Add("MC")
                    'cboxname.Items.Add("Middle")
                    'cboxname.Items.Add("ML")
                    'cboxname.Items.Add("MR")
                    'cboxname.Items.Add("Right")
                    'cboxname.Items.Add("TC")
                    'cboxname.Items.Add("TL")
                    'cboxname.Items.Add("TR")

                Case "20"  ' TEXTTYPES
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "DTEXT"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "MTEXT"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add("DTEXT")
                    'cboxname.Items.Add("MTEXT")

                Case "26" ' Decimal Degrees
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000000"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("0")) ' 0
                    'cboxname.Items.Add(("0.0")) ' 1
                    'cboxname.Items.Add(("0.00")) ' 2
                    'cboxname.Items.Add(("0.000")) ' 3
                    'cboxname.Items.Add(("0.0000")) ' 4
                    'cboxname.Items.Add(("0.00000")) ' 5
                    'cboxname.Items.Add(("0.000000")) ' 6
                    'cboxname.Items.Add(("0.0000000")) ' 7
                    'cboxname.Items.Add(("0.00000000")) ' 8

                Case "27" ' Degrees minutes and seconds
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0d"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00'00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00'00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00'00.0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00'00.00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00'00.000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0d00'00.0000"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("0d")) ' 0
                    'cboxname.Items.Add(("0d00")) ' 1
                    'cboxname.Items.Add(("0d00")) ' 2
                    'cboxname.Items.Add(("0d00'00")) ' 3
                    'cboxname.Items.Add(("0d00'00")) ' 4
                    'cboxname.Items.Add(("0d00'00.0")) ' 5
                    'cboxname.Items.Add(("0d00'00.00")) ' 6
                    'cboxname.Items.Add(("0d00'00.000")) ' 7
                    'cboxname.Items.Add(("0d00'00.0000")) ' 8

                Case "28" ' Grads
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000000g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000000g"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000000g"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("0g")) ' 0
                    'cboxname.Items.Add(("0.0g")) ' 1
                    'cboxname.Items.Add(("0.00g")) ' 2
                    'cboxname.Items.Add(("0.000g")) ' 3
                    'cboxname.Items.Add(("0.0000g")) ' 4
                    'cboxname.Items.Add(("0.00000g")) ' 5
                    'cboxname.Items.Add(("0.000000g")) ' 6
                    'cboxname.Items.Add(("0.0000000g")) ' 7
                    'cboxname.Items.Add(("0.00000000g")) ' 8

                Case "29" ' Radians
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000000r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000000r"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000000r"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("0r")) ' 0
                    'cboxname.Items.Add(("0.0r")) ' 1
                    'cboxname.Items.Add(("0.00r")) ' 2
                    'cboxname.Items.Add(("0.000r")) ' 3
                    'cboxname.Items.Add(("0.0000r")) ' 4
                    'cboxname.Items.Add(("0.00000r")) ' 5
                    'cboxname.Items.Add(("0.000000r")) ' 6
                    'cboxname.Items.Add(("0.0000000r")) ' 7
                    'cboxname.Items.Add(("0.00000000r")) ' 8

                Case "30" ' Surveyor's Units
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "N0dE"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "N0d00E"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "N0d00E"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = ("N0d00'00" & Chr(34) & "E")
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = ("N0d00'00" & Chr(34) & "E")
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = ("N0d00'00.0" & Chr(34) & "E")
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = ("N0d00'00.00" & Chr(34) & "E")
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = ("N0d00'00.000" & Chr(34) & "E")
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = ("N0d00'00.0000" & Chr(34) & "E")
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("N0dE")) ' 0
                    'cboxname.Items.Add(("N0d00E")) ' 1
                    'cboxname.Items.Add(("N0d00E")) ' 2
                    'cboxname.Items.Add(("N0d00'00" & Chr(34) & "E")) ' 3
                    'cboxname.Items.Add(("N0d00'00" & Chr(34) & "E")) ' 4
                    'cboxname.Items.Add(("N0d00'00.0" & Chr(34) & "E")) ' 5
                    'cboxname.Items.Add(("N0d00'00.00" & Chr(34) & "E")) ' 6
                    'cboxname.Items.Add(("N0d00'00.000" & Chr(34) & "E")) ' 7
                    'cboxname.Items.Add(("N0d00'00.0000" & Chr(34) & "E")) ' 8

                Case "31"
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "Decimal degrees"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Deg/Min/Sec"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Gradians"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Radians"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Surveyor 's units"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("Decimal degrees"))
                    'cboxname.Items.Add(("Deg/Min/Sec"))
                    'cboxname.Items.Add(("Gradians"))
                    'cboxname.Items.Add(("Radians"))
                    'cboxname.Items.Add(("Surveyor 's units"))

                Case "32"
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "Decimal degrees"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Deg/Min/Sec"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Gradians"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Radians"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Surveyor 's units"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("Decimal degrees"))
                    'cboxname.Items.Add(("Deg/Min/Sec"))
                    'cboxname.Items.Add(("Gradians"))
                    'cboxname.Items.Add(("Radians"))
                    'cboxname.Items.Add(("Surveyor 's units"))

                Case "18"
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "Millimeters"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Meters"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("Unspecified (No units)"))
                    'cboxname.Items.Add(("Inches"))
                    'cboxname.Items.Add(("Feet"))
                    'cboxname.Items.Add(("Miles"))
                    'cboxname.Items.Add(("Millimeters"))
                    'cboxname.Items.Add(("Centimeters"))
                    'cboxname.Items.Add(("Meters"))
                    'cboxname.Items.Add(("Kilometers"))
                    'cboxname.Items.Add(("Microinches"))
                    'cboxname.Items.Add(("Mils"))
                    'cboxname.Items.Add(("Yards"))
                    'cboxname.Items.Add(("Angstroms"))
                    'cboxname.Items.Add(("Nanometers"))
                    'cboxname.Items.Add(("Microns"))
                    'cboxname.Items.Add(("Decimeters"))
                    'cboxname.Items.Add(("Decameters"))
                    'cboxname.Items.Add(("Hectometers"))
                    'cboxname.Items.Add(("Gigameters"))
                    'cboxname.Items.Add(("Astronomical Units"))
                    'cboxname.Items.Add(("Light Years"))
                    'cboxname.Items.Add(("Parsecs"))

                Case "34"
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "Scientific"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Decimal"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Engineering"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Architectural"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "Fractional"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("Scientific"))
                    'cboxname.Items.Add(("Decimal"))
                    'cboxname.Items.Add(("Engineering"))
                    'cboxname.Items.Add(("Architectural"))
                    'cboxname.Items.Add(("Fractional"))

                Case "35" ' Scientific
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000000E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000000E+01"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000000E+01"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("0E+01"))
                    'cboxname.Items.Add(("0.0E+01"))
                    'cboxname.Items.Add(("0.00E+01"))
                    'cboxname.Items.Add(("0.000E+01"))
                    'cboxname.Items.Add(("0.0000E+01"))
                    'cboxname.Items.Add(("0.00000E+01"))
                    'cboxname.Items.Add(("0.000000E+01"))
                    'cboxname.Items.Add(("0.0000000E+01"))
                    'cboxname.Items.Add(("0.00000000E+01"))

                Case "36" ' Decimal
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.000000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.0000000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0.00000000"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()


                    'cboxname.Items.Add(("0"))
                    'cboxname.Items.Add(("0.0"))
                    'cboxname.Items.Add(("0.00"))
                    'cboxname.Items.Add(("0.000"))
                    'cboxname.Items.Add(("0.0000"))
                    'cboxname.Items.Add(("0.00000"))
                    'cboxname.Items.Add(("0.000000"))
                    'cboxname.Items.Add(("0.0000000"))
                    'cboxname.Items.Add(("0.00000000"))

                Case "37" ' Engineering
                    '' Populate the combo box
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0'-0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.00"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.0000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.00000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.000000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.0000000"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0.00000000"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()


                    'cboxname.Items.Add(("0'-0"))
                    'cboxname.Items.Add(("0'-0.0"))
                    'cboxname.Items.Add(("0'-0.00"))
                    'cboxname.Items.Add(("0'-0.000"))
                    'cboxname.Items.Add(("0'-0.0000"))
                    'cboxname.Items.Add(("0'-0.00000"))
                    'cboxname.Items.Add(("0'-0.000000"))
                    'cboxname.Items.Add(("0'-0.0000000"))
                    'cboxname.Items.Add(("0'-0.00000000"))

                Case "38" ' Architectural
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0'-0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/2"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/4"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/8"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/16"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/32"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/64"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/128"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0'-0 1/256"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()


                    'cboxname.Items.Add(("0'-0"))
                    'cboxname.Items.Add(("0'-0 1/2"))
                    'cboxname.Items.Add(("0'-0 1/4"))
                    'cboxname.Items.Add(("0'-0 1/8"))
                    'cboxname.Items.Add(("0'-0 1/16"))
                    'cboxname.Items.Add(("0'-0 1/32"))
                    'cboxname.Items.Add(("0'-0 1/64"))
                    'cboxname.Items.Add(("0'-0 1/128"))
                    'cboxname.Items.Add(("0'-0 1/256"))

                Case "39" ' Fractional
                    Dim Nr As System.Data.DataRow = cboxname.NewRow
                    Nr.Item("X") = "0"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/2"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/4"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/8"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/16"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/32"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/64"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/128"
                    cboxname.Rows.Add(Nr)

                    Nr = cboxname.NewRow
                    Nr.Item("X") = "0 1/256"
                    cboxname.Rows.Add(Nr)

                    cboxname.AcceptChanges()

                    'cboxname.Items.Add(("0"))
                    'cboxname.Items.Add(("0 1/2"))
                    'cboxname.Items.Add(("0 1/4"))
                    'cboxname.Items.Add(("0 1/8"))
                    'cboxname.Items.Add(("0 1/16"))
                    'cboxname.Items.Add(("0 1/32"))
                    'cboxname.Items.Add(("0 1/64"))
                    'cboxname.Items.Add(("0 1/128"))
                    'cboxname.Items.Add(("0 1/256"))

            End Select

            'If cboxname.Rows.Contains(DefaultVal) Then
            '    cboxname.Select(DefaultVal)
            'Else
            '    cboxname.Select()
            'End If

            Return cboxname

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' Magic routine used to populate a text box based on type and rules, workvar Settings that should be in place
    ''' </summary>
    ''' <param name="tTextBox"></param>
    ''' <param name="sRuleID"></param>
    ''' <param name="sDefault"></param>
    ''' <param name="sSysVar"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <param name="bIgnoreOverride"></param>
    ''' <param name="sType"></param>
    ''' <remarks></remarks>
    Sub PopulateTextBox(ByRef tTextBox As System.Windows.Forms.TextBox, ByRef sRuleID As String, ByRef sDefault As String, Optional ByRef sSysVar As String = "", Optional ByRef bSetCurrent As Boolean = False, Optional ByRef bIgnoreOverride As Boolean = False, Optional ByRef sType As String = "")

        Try

            Dim sRuleValue As String
            'gad 26-010-06 unsure
            '    tTextBox.text = ""

            sRuleValue = RuleAccessors.GetruleValue(sRuleID, "", bIgnoreOverride)

            If sRuleValue <> "" Then

                Select Case UCase(sType)
                    Case "STRING"
                        tTextBox.Text = CStr(sRuleValue)
                    Case "INTEGER"
                        tTextBox.Text = CStr(CShort(sRuleValue))
                    Case "DOUBLE"
                        tTextBox.Text = CStr(Val(sRuleValue))
                    Case Else
                        tTextBox.Text = sRuleValue
                End Select

            Else

                Select Case UCase(sType)
                    Case "STRING"
                        tTextBox.Text = CStr(sDefault)
                    Case "INTEGER"
                        tTextBox.Text = CStr(CShort(sDefault))
                    Case "DOUBLE"
                        tTextBox.Text = CStr(Val(sDefault))
                    Case Else
                        tTextBox.Text = sDefault
                End Select

            End If

            If bSetCurrent = True And sSysVar <> "" Then
                Select Case TypeName(ThisDrawingUtilities.GetVariable(sSysVar))
                    Case "Integer"
                        ThisDrawingUtilities.SetVariable(sSysVar, CShort(tTextBox.Text))
                    Case "Double"
                        ThisDrawingUtilities.SetVariable(sSysVar, Val(tTextBox.Text))
                    Case Else
                        ThisDrawingUtilities.SetVariable(sSysVar, tTextBox.Text)
                End Select
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Magic routine used to populate a check box based on type and rules, workvar Settings that shuld be in place
    ''' </summary>
    ''' <param name="cCheckBox"></param>
    ''' <param name="sRuleID"></param>
    ''' <param name="sDefault"></param>
    ''' <param name="sSysVar"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <param name="bIgnoreOverride"></param>
    ''' <remarks></remarks>
    Sub PopulateCheckBox(ByRef cCheckBox As System.Windows.Forms.CheckBox, ByRef sRuleID As String, ByRef sDefault As String, Optional ByRef sSysVar As String = "", Optional ByRef bSetCurrent As Boolean = True, Optional ByRef bIgnoreOverride As Boolean = False)

        Try

            cCheckBox.Checked = False

            cCheckBox.Checked = RuleAccessors.GetruleValue(sRuleID, "", bIgnoreOverride).IsTrue

            If bSetCurrent = True And sSysVar <> "" Then

                Select Case ThisDrawingUtilities.GetVariable(sSysVar).GetType.FullName.ToUpper

                    Case "Integer".ToUpper

                        If cCheckBox.Checked = True Then
                            ThisDrawingUtilities.SetVariable(sSysVar, 1)
                        Else
                            ThisDrawingUtilities.SetVariable(sSysVar, 0)
                        End If

                    Case "Double".ToUpper
                        If cCheckBox.Checked = True Then
                            ThisDrawingUtilities.SetVariable(sSysVar, 1.0)
                        Else
                            ThisDrawingUtilities.SetVariable(sSysVar, 0.0)
                        End If

                    Case Else
                        If cCheckBox.Checked = True Then
                            ThisDrawingUtilities.SetVariable(sSysVar, True)
                        Else
                            ThisDrawingUtilities.SetVariable(sSysVar, False)
                        End If

                End Select

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Magic routine used to populate a radio button based on type and rules, workvar Settings that shuld be in place
    ''' </summary>
    ''' <param name="cRadioButton"></param>
    ''' <param name="sRuleID"></param>
    ''' <param name="sDefault"></param>
    ''' <param name="sSysVar"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <param name="bIgnoreOverride"></param>
    ''' <remarks></remarks>
    Sub PopulateRadioButton(ByRef cRadioButton As System.Windows.Forms.RadioButton, ByRef sRuleID As String, ByRef sDefault As String, Optional ByRef sSysVar As String = "", Optional ByRef bSetCurrent As Boolean = True, Optional ByRef bIgnoreOverride As Boolean = False)

        ' ' Dim RuleAccessors As New RuleAccessors

        Try

            cRadioButton.Checked = False

            cRadioButton.Checked = RuleAccessors.GetruleValue(sRuleID, "", bIgnoreOverride).IsTrue

            If bSetCurrent = True And sSysVar <> "" Then

                Select Case ThisDrawingUtilities.GetVariable(sSysVar).GetType.FullName.ToUpper

                    Case "Integer".ToUpper

                        If cRadioButton.Checked = True Then
                            ThisDrawingUtilities.SetVariable(sSysVar, 1)
                        Else
                            ThisDrawingUtilities.SetVariable(sSysVar, 0)
                        End If

                    Case "Double".ToUpper
                        If cRadioButton.Checked = True Then
                            ThisDrawingUtilities.SetVariable(sSysVar, 1.0)
                        Else
                            ThisDrawingUtilities.SetVariable(sSysVar, 0.0)
                        End If

                    Case Else
                        If cRadioButton.Checked = True Then
                            ThisDrawingUtilities.SetVariable(sSysVar, True)
                        Else
                            ThisDrawingUtilities.SetVariable(sSysVar, False)
                        End If

                End Select

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' May be a leftover from VBA it just checks to see if an item exists in the given combo box
    ''' </summary>
    ''' <param name="cComboBox"></param>
    ''' <param name="sItem"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function ItemIsInCombobox(ByRef cComboBox As System.Windows.Forms.ComboBox, ByRef sItem As String) As Boolean

        Try
            Dim bResult As Boolean
            Dim i As Integer

            bResult = False

            For i = 0 To CShort(cComboBox.Items.Count - 1)
                If UCase(UserInterface.GetComboBoxText(cComboBox, i)) = UCase(sItem) Then
                    bResult = True
                End If
            Next

            ItemIsInCombobox = bResult

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Sets the default of a combobox but can rename BYBLOCK and BYCOLOUR instead up using 0 and 255
    ''' </summary>
    ''' <param name="cboxname"></param>
    ''' <param name="ItemValue"></param>
    ''' <param name="Default_Renamed"></param>
    ''' <param name="sType"></param>
    ''' <remarks></remarks>
    Sub SetComboItem(ByRef cboxname As System.Windows.Forms.ComboBox, ByRef ItemValue As String, Optional ByRef Default_Renamed As Integer = 0, Optional ByRef sType As String = "")
        Try
            Dim FoundItem As Boolean
            Dim setto As Integer
            Dim i As Integer

            FoundItem = False

            If cboxname.Items.Count > 0 Then
                For i = 0 To CShort((cboxname.Items.Count - 1))
                    If UCase(cboxname.Items(i).ToString) = UCase(ItemValue) Then
                        FoundItem = True
                        setto = i
                        Exit For
                    End If
                Next

                If FoundItem = True Then
                    If UCase(sType) = "CECOLOR" Then
                        If ItemValue = "256" Or UCase(ItemValue) = "BYLAYER" Then
                            cboxname.Text = "ByLayer"
                        Else
                            If ItemValue = "0" Or UCase(ItemValue) = "BYBLOCK" Then
                                cboxname.Text = "ByBlock"
                            Else
                                cboxname.SelectedIndex = setto
                            End If
                        End If
                    Else
                        cboxname.SelectedIndex = setto
                    End If
                Else
                    If UCase(sType) = "CECOLOR" Then
                        If ItemValue = "256" Then
                            cboxname.SelectedValue = "ByLayer"
                        Else
                            If ItemValue = "0" Then
                                cboxname.SelectedValue = "ByBlock"
                            Else
                                cboxname.SelectedIndex = Default_Renamed
                            End If
                        End If
                    Else
                        cboxname.SelectedIndex = Default_Renamed
                    End If
                End If

            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Checks to see if this drawing configured - returns true or false
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ThisDrawingIsConfigured() As Boolean
        Try

            ' ' Dim RuleAccessors As New RuleAccessors
            Dim rToolRule As Rule
            rToolRule = RuleAccessors.GetRule("FULLCONFIGNAME") ' Get the configuration name
            If Not rToolRule Is Nothing Then
                ThisDrawingIsConfigured = True
            Else
                ThisDrawingIsConfigured = False
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Checks to see if the rule that was sent has it's content in this DWG file
    ''' </summary>
    ''' <param name="strRuleIDFromFile"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function RuleAndContentArePresent(ByRef strRuleIDFromFile As String) As Boolean

        Dim result As Boolean = False

        Try

            ' ' Dim RuleAccessors As New RuleAccessors
            Dim rrule As Rule

            rrule = RuleAccessors.GetRule(strRuleIDFromFile)
            If rrule IsNot Nothing Then
                '' Special consideration for Multi Value Rule such as Data Grid View Rule
                If rrule.DlgCode = WZ_DGLCODE_DATAGRIDVIEW Then

                    ' These characters were selected as separators because they can't be used in the name of a style or layer.
                    ' ToolRule.RuleID      = ANNOTATION18
                    ' ToolRule.Description = Nominate Text Styles default layer and height|Style/8-Layer/6-Height/40
                    ' ToolRule.value       = Standard|TEXT_18|1.8;Standard|TEXT_25|2.5;Standard|TEXT_35|3.5;Standard|TEXT_50|5.0;Standard|TEXT_50|5.0
                    ' ToolRule.DlgCode     = 4
                    ' ToolRule.TableCode   = 41

                    Dim k As Integer = 0
                    '' Work out the column headings and types 
                    For Each ColumnHeading As String In rrule.Description.Split("-"c)
                        Dim ColumnValue As String = String.Empty
                        Dim ColumnHeadingName As String = ColumnHeading.Split("/"c)(0)
                        Dim ColumnHeadingTBLCode As String = ColumnHeading.Split("/"c)(1)

                        If rrule.value.Contains("|") And rrule.value.Contains(";") Then
                            ColumnValue = rrule.value.Split(";"c)(k).Split("|"c)(1)
                        Else
                            If rrule.value.Contains(";") Then
                                ColumnValue = rrule.value.Split(";"c)(k)
                            Else
                                ColumnValue = rrule.value
                            End If
                        End If
                        k = k + 1

                        '' one of the rows in the grid view table contains a value that is not in this DWG file - flag as false and exit
                        If CheckRuleAndContentArePresent(CInt(ColumnHeadingTBLCode), ColumnValue) = False Then
                            result = False
                            Exit For
                        End If

                    Next
                Else
                    result = CheckRuleAndContentArePresent(rrule.TableCode, rrule.value)
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return result

    End Function

    Function CheckRuleAndContentArePresent(RuleTableCode As Integer, RuleValue As String) As Boolean

        Try

            Dim vItem As Object
            Select Case RuleTableCode

                Case WZ_BLOCK_TABLE
                    ' Check to see if the object in this file already
                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            If BlockExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        If BlockExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_DIMSTYLE_TABLE
                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            ' Check to see if the object in this file already
                            If DimStyleExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        ' Check to see if the object in this file already
                        If DimStyleExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_LAYER_TABLE
                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            ' Check to see if the object in this file already
                            If LayerExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        ' Check to see if the object in this file already
                        If LayerExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_LINETYPE_TABLE
                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            ' Check to see if the object in this file already
                            If LineTypeExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        ' Check to see if the object in this file already
                        If LineTypeExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_TEXTSTYLE_TABLE

                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            ' Check to see if the object in this file already
                            If TextStyleExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        ' Check to see if the object in this file already
                        If TextStyleExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_LAYOUTS_TABLE
                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            ' Check to see if the object in this file already
                            If LayoutExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        ' Check to see if the object in this file already
                        If LayoutExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_LINEWEIGHT
                    Return True

                Case WZ_COLOUR
                    Return True

                Case WZ_MULTILINESTYLE_TABLE
                    Return True

                Case WZ_TABLESTYLE_TABLE
                    If UBound(Split(RuleValue, ";")) > 0 Then
                        For Each vItem In Split(RuleValue, ";")
                            ' Check to see if the object in this file already
                            If TableStyleExist(CStr(vItem)) = False Then
                                Return False
                                Exit Function
                            Else
                                Return True
                            End If
                        Next vItem
                    Else
                        ' Check to see if the object in this file already
                        If TableStyleExist((RuleValue)) = False Then
                            Return False
                        Else
                            Return True
                        End If
                    End If

                Case WZ_PLOTSTYLES_TABLE
                    Return True

                Case WZ_PAGESETUPS_TABLE
                    Return True

                Case WZ_JUSTIFICATIONS
                    Return True

                Case WZ_INSUNITS
                    Return True

                Case WZ_CUSTOM
                    Return True

                Case Else
                    Return True

            End Select


        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

            Return False
        End Try
        Return False

    End Function

    ' ''' <summary>
    ' ''' This function will initialize all the rules for the nominated tool
    ' ''' It will check the current file for the rules or rule overrides
    ' ''' It will import all required rules if they are not in this file
    ' ''' It will import the relevant content for each rule if required
    ' ''' </summary>
    ' ''' <param name="sToolName"></param>
    ' ''' <param name="bDisplayDetails"></param>
    ' ''' <param name="bImport"></param>
    ' ''' <param name="bSetCurrent"></param>
    ' ''' <remarks></remarks>
    'Sub InitializeRules(ByRef sToolName As String, Optional ByRef bDisplayDetails As Boolean = False, Optional ByRef bImport As Boolean = False, Optional ByRef bSetCurrent As Boolean = False)
    '    Try

    '        Dim toolrule As Rule
    '        Dim i As Integer
    '        Dim strRuleIDFromFile As String
    '        Dim strRuleValueDescriptionFromFile As String
    '        Dim strDGLCodeFromFile As String
    '        Dim strTBLCodeFromFile As String
    '        Dim strRuleValueFromFile As String
    '        Dim toolindex As Object = Nothing
    '        Dim bCalledFromContentWizard As Boolean

    '        INIFileReadTopics(Settings.Manager.AE.CEBundleContents.CombinePath("Tools.ini"))

    '        ' Go through the tool details list and get a pointer to the relevant tool
    '        For i = 0 To CShort(UBound(ToolDetails))
    '            If UCase(ToolDetails(i).ToolName) = UCase(sToolName) Then
    '                toolindex = i
    '                Exit For
    '            End If
    '        Next

    '        ' Get sFullConfigName from registry) if there is a regkey then we are running inside the Content Wizard
    '        'If GetFullConfigName() = "" Then
    '        bCalledFromContentWizard = False
    '        'Else
    '        '    bCalledFromContentWizard = True
    '        'End If

    '        ' If the tool that was nominated was found in the Tools.INI file then...
    '        If Not toolindex Is Nothing Then

    '            ' If the tool has more than 0 rules then
    '            If UBound(ToolDetails(CInt(toolindex)).Rules) >= 0 Then

    '                ' Find out how many rules the current tool has and iterate through them
    '                For i = 0 To CShort(UBound(ToolDetails(CInt(toolindex)).Rules))

    '                    ' In the ToolDetails array the rules as defined by the tools.ini file
    '                    ' We need to Split the current rule for this tool into variables

    '                    If ToolDetails(CInt(toolindex)).Rules(i) = "" Then
    '                        Exit For
    '                    End If

    '                    strRuleIDFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(0)
    '                    strRuleValueDescriptionFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(1)
    '                    strRuleValueFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(2)
    '                    strDGLCodeFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(3)
    '                    strTBLCodeFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(4)

    '                    ' See if the rules for this tool are set in this file and if the content is present
    '                    If RuleAndContentArePresent(strRuleIDFromFile) = False Then

    '                        ' Find where the rule is defined no matter which level
    '                        toolrule = RuleSearch(strRuleIDFromFile, strRuleValueFromFile, True, bDisplayDetails, True, bImport, bSetCurrent)

    '                        ' Rule Validation Section
    '                        If Not toolrule Is Nothing Then

    '                            ' Compare the structure of the saved rule with what is in the ini file ignoring the value - check for integrity
    '                            If strRuleValueDescriptionFromFile <> toolrule.Description Or CDbl(strDGLCodeFromFile) <> toolrule.DlgCode Or CDbl(strTBLCodeFromFile) <> toolrule.TableCode Then

    '                                ' Since the rule format in in the database is not the same as the Tools.ini file it needs to be updated otherwise it cannot work
    '                                ' with this version of the tool. An override will be created in this file to make the correction

    '                                ' Adjust the drawing file as we have to in order for the tool to work correctly
    '                                toolrule = RuleAccessors.AddRule(strRuleIDFromFile, toolrule.value, strRuleValueDescriptionFromFile, strDGLCodeFromFile, strTBLCodeFromFile)

    '                            Else

    '                                ' Nothing to do as all is going well the rule is valid

    '                            End If

    '                        Else
    '                            If bCalledFromContentWizard = False Then
    '                                RuleAccessors.AddRule(strRuleIDFromFile, strRuleValueFromFile, strRuleValueDescriptionFromFile, strDGLCodeFromFile, strTBLCodeFromFile)
    '                                Acad_MessageBox("--------------------------------------------------------------------------------", , , , , , , True, logName)
    '                                Acad_MessageBox("The " & sToolName & " Tool has a rule for controlling " & strRuleValueDescriptionFromFile & vbCrLf & _
    '                                                  "                       This rule was not found in this Template and has now been set to: " & strRuleValueFromFile, , , , , , , True, logName)
    '                                Acad_MessageBox("If this is incorrect recreate the Template with the desired value.", , , , , , , True, logName)
    '                                Acad_MessageBox("--------------------------------------------------------------------------------", , , , , , , True, logName)
    '                                ' May need to check if content is present
    '                                If RuleAndContentArePresent(strRuleIDFromFile) = False Then
    '                                    ' Need to import or create content
    '                                    CreateContent(strRuleValueFromFile, strTBLCodeFromFile)
    '                                End If

    '                            Else
    '                                ' Else create the rule from the tools.ini file
    '                                RuleAccessors.AddRule(strRuleIDFromFile, strRuleValueFromFile, strRuleValueDescriptionFromFile, strDGLCodeFromFile, strTBLCodeFromFile)

    '                                ' May need to check if content is present
    '                                If RuleAndContentArePresent(strRuleIDFromFile) = False Then
    '                                    ' Need to import or create content
    '                                    CreateContent(strRuleValueFromFile, strTBLCodeFromFile)
    '                                End If

    '                            End If

    '                        End If

    '                    Else

    '                        ' The rule for this tool is set in this file and is present - nothing to be done

    '                    End If

    '                Next  ' Look at the next rule in this tool

    '            End If

    '        End If
    '    Catch ex As System.Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
    '    End Try
    'End Sub


    ''' <summary>
    ''' This function will initialize all the rules for the nominated tool
    ''' It will check the current file for the rules or rule overrides
    ''' It will import all required rules if they are not in this file
    ''' It will import the relevant content for each rule if required
    ''' </summary>
    ''' <param name="sToolName"></param>
    ''' <param name="bDisplayDetails"></param>
    ''' <param name="bImport"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <remarks></remarks>
    Sub InitializeRulesNew(ByRef sToolName As String, Optional ByRef bDisplayDetails As Boolean = False, Optional ByRef bImport As Boolean = False, Optional ByRef bSetCurrent As Boolean = False)

        Try

            Dim toolrule As Rule
            Dim i As Integer
            Dim strRuleIDFromFile As String
            Dim strRuleValueDescriptionFromFile As String
            Dim strDGLCodeFromFile As String
            Dim strTBLCodeFromFile As String
            Dim strRuleValueFromFile As String
            Dim toolindex As Object = Nothing

            INIFileReadTopics(Settings.Manager.AE.AEBundleContents.CombinePath("Tools.ini"))

            ' Go through the tool details list and get a pointer to the relevant tool
            For i = 0 To CShort(UBound(ToolDetails))
                If UCase(ToolDetails(i).ToolName) = UCase(sToolName) Then
                    toolindex = i
                    Exit For
                End If
            Next

            ' If the tool that was nominated was found in the Tools.INI file then...
            If Not toolindex Is Nothing Then

                ' If the tool has more than 0 rules then
                If UBound(ToolDetails(CInt(toolindex)).Rules) >= 0 Then

                    ' Find out how many rules the current tool has and iterate through them
                    For i = 0 To CShort(UBound(ToolDetails(CInt(toolindex)).Rules))

                        ' In the ToolDetails array the rules as defined by the tools.ini file
                        ' We need to Split the current rule for this tool into variables

                        If ToolDetails(CInt(toolindex)).Rules(i) = "" Then
                            Exit For
                        End If

                        strRuleIDFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(0)
                        strRuleValueDescriptionFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(1)
                        strRuleValueFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(2)
                        strDGLCodeFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(3)
                        strTBLCodeFromFile = Split(ToolDetails(CInt(toolindex)).Rules(i), ",")(4)

                        ' See if the rules for this tool are set in this file and if the content is present
                        If RuleAndContentArePresent(strRuleIDFromFile) = False Then

                            ' Find where the rule is defined no matter which level
                            toolrule = RuleSearchNew(strRuleIDFromFile, strRuleValueFromFile, True, bDisplayDetails, True, bImport, bSetCurrent)

                            ' Rule Validation Section
                            If Not toolrule Is Nothing Then

                                ' Compare the structure of the saved rule with what is in the ini file ingnoring the value - check for integrity
                                If strRuleValueDescriptionFromFile <> toolrule.Description Or CDbl(strDGLCodeFromFile) <> toolrule.DlgCode Or CDbl(strTBLCodeFromFile) <> toolrule.TableCode Then

                                    ' Since the rule format in in the database is not the same as the Tools.ini file it needs to be updated otherwise it cannot work
                                    ' with this version of the tool. An override will be created in this file to make the correction

                                    ' Adjust the drawing file as we have to in order for the tool to work correctly
                                    toolrule = RuleAccessors.AddRule(strRuleIDFromFile, toolrule.value, strRuleValueDescriptionFromFile, strDGLCodeFromFile, strTBLCodeFromFile)

                                Else

                                    ' Nothing to do as all is going well the rule is valid

                                End If

                            Else

                                RuleAccessors.AddRule(strRuleIDFromFile, strRuleValueFromFile, strRuleValueDescriptionFromFile, strDGLCodeFromFile, strTBLCodeFromFile)

                                Acad_MessageBox("--------------------------------------------------------------------------------", , , , , , , True, logName)
                                Acad_MessageBox("The " & sToolName & " Tool has a rule for controlling " & strRuleValueDescriptionFromFile & vbCrLf &
                                                  "                       This rule was not found in this Template and has now been set to: " & strRuleValueFromFile, , , , , , , True, logName)
                                Acad_MessageBox("If this is incorrect recreate the Template with the desired value.", , , , , , , True, logName)
                                Acad_MessageBox("--------------------------------------------------------------------------------", , , , , , , True, logName)
                                ' May need to check if content is present
                                If RuleAndContentArePresent(strRuleIDFromFile) = False Then
                                    ' Need to import or create content
                                    CreateContent(strRuleValueFromFile, strTBLCodeFromFile)
                                End If

                            End If

                        Else

                            ' The rule for this tool is set in this file and is present - nothing to be done

                        End If

                    Next  ' Look at the next rule in this tool

                End If

            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    ' ''' <summary>
    ' ''' Searched for a rule in this drawing - and all drawings in hierarchy - can  import the contents from another template and can also be set current
    ' ''' Honours the user overrided if present
    ' ''' </summary>
    ' ''' <param name="strRuleID"></param>
    ' ''' <param name="sDefault"></param>
    ' ''' <param name="bRecordInThisfile"></param>
    ' ''' <param name="bDisplayDetails"></param>
    ' ''' <param name="bIgnoreOverrideInCurrentFile"></param>
    ' ''' <param name="bImport"></param>
    ' ''' <param name="bSetCurrent"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Public Function RuleSearch(ByRef strRuleID As String, ByRef sDefault As String, ByRef bRecordInThisfile As Boolean, Optional ByRef bDisplayDetails As Boolean = False, Optional ByRef bIgnoreOverrideInCurrentFile As Boolean = False, Optional ByRef bImport As Boolean = False, Optional ByRef bSetCurrent As Boolean = False) As Rule

    '    Try

    '        '  ' Dim RuleAccessors As New RuleAccessors
    '        Dim toolrule As Rule = Nothing
    '        ' Check to see if we need to ignore the override or not
    '        If bIgnoreOverrideInCurrentFile = True Then
    '            ' Look in the current file first for original rule value (hence client rule tick is on)
    '            toolrule = RuleAccessors.GetRule(strRuleID)
    '        Else
    '            ' Look in the current file first for rule override value (hence client rule tick is off)
    '            toolrule = RuleAccessors.GetRule(strRuleID & "-DlgBox")
    '            If toolrule Is Nothing Then
    '                toolrule = RuleAccessors.GetRule(strRuleID) ' If the override wasn't present look for the base rule in this file first
    '            End If
    '        End If

    '        ' If the rule or rule override was not present in this file we need to look back trough the other templates to find the rule
    '        If toolrule Is Nothing Then

    '            ' Go in search of rules
    '            toolrule = TraverseFilesForRule(strRuleID, bSetCurrent, sDefault, bImport, bRecordInThisfile)

    '            If toolrule Is Nothing Then
    '                ' The initializerule calling function will take care of the error message
    '                RuleSearch = toolrule
    '                Exit Function
    '            Else
    '                ' Go in search of content
    '                TraverseFilesForContent(strRuleID, toolrule, (toolrule.value), bImport, bSetCurrent, sDefault)
    '            End If

    '        Else
    '            TraverseFilesForContent(strRuleID, toolrule, (toolrule.value), bImport, bSetCurrent, sDefault)
    '        End If

    '        RuleSearch = toolrule
    '    Catch ex As System.Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
    '        Return Nothing
    '    End Try

    'End Function

    ''' <summary>
    ''' Searched for a rule in this drawing - and all drawings in hierarchy - can  import the contents from another template and can also be set current
    ''' Honours the user override if present
    ''' </summary>
    ''' <param name="strRuleID"></param>
    ''' <param name="sDefault"></param>
    ''' <param name="bRecordInThisfile"></param>
    ''' <param name="bDisplayDetails"></param>
    ''' <param name="bIgnoreOverrideInCurrentFile"></param>
    ''' <param name="bImport"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RuleSearchNew(ByRef strRuleID As String, ByRef sDefault As String, ByRef bRecordInThisfile As Boolean, Optional ByRef bDisplayDetails As Boolean = False, Optional ByRef bIgnoreOverrideInCurrentFile As Boolean = False, Optional ByRef bImport As Boolean = False, Optional ByRef bSetCurrent As Boolean = False) As Rule

        Try

            '  ' Dim RuleAccessors As New RuleAccessors
            Dim toolrule As Rule = Nothing
            ' Check to see if we need to ignore the override or not
            If bIgnoreOverrideInCurrentFile = True Then
                ' Look in the current file first for original rule value (hence client rule tick is on)
                toolrule = RuleAccessors.GetRule(strRuleID)
            Else
                ' Look in the current file first for rule override value (hence client rule tick is off)
                toolrule = RuleAccessors.GetRule(strRuleID & "-DlgBox")
                If toolrule Is Nothing Then
                    toolrule = RuleAccessors.GetRule(strRuleID) ' If the override wasn't present look for the base rule in this file first
                End If
            End If

            ' If the rule or rule override was not present in this file we need to look back trough the other templates to find the rule
            If toolrule Is Nothing Then

                'If IsThisAnOldConfigName() = True Then

                '    ' Go in search of rules
                '    toolrule = TraverseFilesForRule(strRuleID, bSetCurrent, sDefault, bImport, bRecordInThisfile)

                'Else

                '' Look in client Level for Rule and Values
                Dim fname As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(GetruleValue("FULLCONFIGNAME"), "Settings", GetruleValue("FULLCONFIGNAME") & ".DWG")

                ' Go in search of rules
                toolrule = TraverseFilesForRuleNew(strRuleID, fname, bSetCurrent, sDefault, bImport, bRecordInThisfile)

                If toolrule Is Nothing Then

                    fname = Settings.Manager.AE.AEBundleContents.CombinePath("Tools.DWG")

                    toolrule = TraverseFilesForRuleNew(strRuleID, fname, bSetCurrent, sDefault, bImport, bRecordInThisfile)

                End If

                'End If

                If toolrule Is Nothing Then
                    ' The initialize rule calling function will take care of the error message
                    RuleSearchNew = toolrule
                    Exit Function
                Else
                    ' Go in search of content
                    'If IsThisAnOldConfigName() = True Then
                    '    TraverseFilesForContent(strRuleID, toolrule, (toolrule.value), bImport, bSetCurrent, sDefault)
                    'Else
                    TraverseFilesForContentNew(strRuleID, toolrule, (toolrule.value), bImport, bSetCurrent, sDefault)
                    'End If

                End If

            Else
                'If IsThisAnOldConfigName() = True Then
                '    ' Go in search of content
                '    TraverseFilesForContent(strRuleID, toolrule, (toolrule.value), bImport, bSetCurrent, sDefault)

                'Else

                '' Look in client Level for Rule and Values
                '' Was looking at DWT file which is purged.

                Dim fname As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(GetruleValue("FULLCONFIGNAME"), "Settings", GetruleValue("FULLCONFIGNAME") & ".DWG")

                If System.IO.File.Exists(fname) Then
                    ' Go in search of rules
                    toolrule = TraverseFilesForRuleNew(strRuleID, fname, bSetCurrent, sDefault, bImport, bRecordInThisfile)

                    If toolrule Is Nothing Then

                        fname = Settings.Manager.AE.AEBundleContents.CombinePath("Tools.DWG")

                        toolrule = TraverseFilesForRuleNew(strRuleID, fname, bSetCurrent, sDefault, bImport, bRecordInThisfile)

                    End If
                Else

                    ' Simply returns the tool rule in this drawing - most likely cause is that we are in the middle of a config upgrade process
                End If


            End If

            'End If

            RuleSearchNew = toolrule
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' Helper function for rule search
    ''' </summary>
    ''' <param name="strRuleID"></param>
    ''' <param name="toolrule"></param>
    ''' <param name="strRuleValue"></param>
    ''' <param name="bImport"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <param name="sDefault"></param>
    ''' <remarks></remarks>
    Sub TraverseFilesForContentNew(ByRef strRuleID As String, ByRef toolrule As Rule, ByRef strRuleValue As String, ByRef bImport As Boolean, ByRef bSetCurrent As Boolean, ByRef sDefault As String)

        Try

            Dim fName As String = ""
            Dim FullCfgName As String

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                ' Retrieve the current configuration name from this drawing
                FullCfgName = GetruleValue("FULLCONFIGNAME")

                ' The DWT is also stored as a DWG file with all content loaded DWT is a leaner version of the DWG file (example - layers purged)
                ' The DWT file is used to create the file we are working on purged content can be retrieved from the DWG file.

                fName = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(FullCfgName, "Settings", FullCfgName & ".dwg")

                If System.IO.File.Exists(fName) = True Then

                    If bImport = True And (toolrule.TableCode = WZ_LINETYPE_TABLE Or toolrule.TableCode = WZ_LAYER_TABLE Or toolrule.TableCode = WZ_TEXTSTYLE_TABLE Or toolrule.TableCode = WZ_BLOCK_TABLE Or toolrule.TableCode = WZ_TABLESTYLE_TABLE Or toolrule.TableCode = WZ_DIMSTYLE_TABLE Or toolrule.TableCode = WZ_LAYOUTS_TABLE) Then

                        If RuleAndContentArePresent(strRuleID) = False Then

                            Acad_MessageBox("New Searching for " & TableCodeToDesc(toolrule.TableCode) & " " & toolrule.value & " in Client Level: " & Split(fName, "\")(5), , , , , , , True, logName)

                            ' If the value is not present in the file
                            If ImporterNew((toolrule.value), CStr((toolrule.TableCode)), bSetCurrent, fName, sDefault) = True Then
                                Acad_MessageBox("Content found and imported at Client level...", , , , , , , True, logName)
                            Else
                                fName = Settings.Manager.AE.AEBundleContents.CombinePath("Tools.DWG")
                                If ImporterNew((toolrule.value), CStr((toolrule.TableCode)), bSetCurrent, fName, sDefault) = True Then
                                    Acad_MessageBox("Content found and imported at Corporate level...", , , , , , , True, logName)
                                Else

                                    Acad_MessageBox("NEED TO CREATE CONTENT ", , , , , , , True, logName)

                                    Select Case CStr((toolrule.TableCode))

                                        Case CStr(WZ_BLOCK_TABLE)


                                        Case CStr(WZ_DIMSTYLE_TABLE)

                                            ThisDrawingUtilities.DimStyles.Add(CStr(toolrule.value))

                                        Case CStr(WZ_TEXTSTYLE_TABLE)

                                            ThisDrawingUtilities.TextStyles.Add(CStr(toolrule.value))

                                        Case CStr(WZ_LAYER_TABLE)

                                            ThisDrawingUtilities.Linetypes.Add(CStr(toolrule.value))

                                        Case CStr(WZ_LAYOUTS_TABLE)

                                            ThisDrawingUtilities.Layouts.Add(CStr(toolrule.value))

                                        Case CStr(WZ_LINEWEIGHT)
                                            ' This object cannot be imported but it can be set current if desired
                                            If bSetCurrent = True Then
                                                ThisDrawingUtilities.SetVariable(WZ_LINEWEIGHT_SYSVAR, sDefault)
                                                Acad_MessageBox("Set Line weight system variable has been set to: " & sDefault, "Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)
                                            End If

                                        Case CStr(WZ_COLOUR)
                                            ' This object cannot be imported but it can be set current if desired
                                            If bSetCurrent = True Then
                                                ThisDrawingUtilities.SetVariable(WZ_COLOUR_SYSVAR, sDefault)
                                                Acad_MessageBox("Set Colour system variable has been set to: " & sDefault, "Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)
                                            End If

                                        Case CStr(WZ_INSUNITS)
                                            ' This object cannot be imported but it can be set current if desired
                                            If bSetCurrent = True Then
                                                ThisDrawingUtilities.SetVariable(WZ_INSUNITS_SYSVAR, sDefault)
                                                Acad_MessageBox("Set InsUnits system variable has been set to: " & sDefault, "Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)
                                            End If

                                        Case CStr(WZ_CUSTOM)

                                            ' NOT RELEVANT
                                            ' This object cannot be imported but it can be set current if desired

                                        Case Else

                                            '  The ITEM: " & ItemName & " selected to import is not an item that can be imported, as it is not saved in the drawing database.

                                    End Select

                                End If


                            End If

                        End If
                    End If
                End If

            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    ''' <summary>
    ''' Converts integer hierarchy numbers to string descriptions
    ''' </summary>
    ''' <param name="code"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function LevelCodeToDesc(ByRef code As Integer) As String
        Try

            Select Case code
                Case 0
                    LevelCodeToDesc = "Corporate"
                Case 1
                    LevelCodeToDesc = "Business Unit"
                Case 2
                    LevelCodeToDesc = "Discipline"
                Case 3
                    LevelCodeToDesc = "Office"
                Case 4
                    LevelCodeToDesc = "Client"
                Case Else
                    LevelCodeToDesc = "Unknown"
            End Select
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            LevelCodeToDesc = "Unknown"
        End Try
    End Function

    ''' <summary>
    ''' Converts integer table style numbers to their string equivalents
    ''' </summary>
    ''' <param name="code"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function TableCodeToDesc(ByRef code As Integer) As String
        Try

            Select Case code
                Case WZ_LINETYPE_TABLE
                    TableCodeToDesc = "Linetype"
                Case WZ_LAYER_TABLE
                    TableCodeToDesc = "Layer"
                Case WZ_TEXTSTYLE_TABLE
                    TableCodeToDesc = "TextStyle"
                Case WZ_BLOCK_TABLE
                    TableCodeToDesc = "Block"
                Case WZ_TABLESTYLE_TABLE
                    TableCodeToDesc = "TableStyle"
                Case WZ_DIMSTYLE_TABLE
                    TableCodeToDesc = "DimensionStyle"
                Case WZ_LAYOUTS_TABLE
                    TableCodeToDesc = "Layout"
                Case Else
                    TableCodeToDesc = "Unknown"
            End Select
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            TableCodeToDesc = "Unknown"
        End Try
    End Function

    ' ''' <summary>
    ' ''' Helper function for rule search function
    ' ''' </summary>
    ' ''' <param name="strRuleID"></param>
    ' ''' <param name="bSetCurrent"></param>
    ' ''' <param name="sDefault"></param>
    ' ''' <param name="bImport"></param>
    ' ''' <param name="bRecordRuleInThisFile"></param>
    ' ''' <returns></returns>
    ' ''' <remarks></remarks>
    'Public Function TraverseFilesForRule(ByRef strRuleID As String, ByRef bSetCurrent As Boolean, ByRef sDefault As String, ByRef bImport As Boolean, Optional ByRef bRecordRuleInThisFile As Boolean = True) As Rule

    '    Try

    '        ' ' Dim RuleAccessors As New RuleAccessors
    '        Dim toolrule As Rule = Nothing
    '        Dim bCalledFromContentWizard As Boolean
    '        Dim LevelCtr As Integer
    '        Dim CurrentLevel As Integer
    '        Dim fName As String = ""
    '        Dim CfgLevel As String
    '        Dim FullCfgName As String

    '        ' Retreive the current configuration name from this drawing
    '        Dim f1 As Object
    '        Dim f2 As String
    '        If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

    '            FullCfgName = RuleAccessors.GetRule("FULLCONFIGNAME").value

    '            ' Retreive the current configuration level from this file
    '            CfgLevel = RuleAccessors.GetruleValue("CONFIGLEVEL")

    '            ' This next case statement determines which level we should start looking from
    '            Select Case UCase(CfgLevel)
    '                Case "CLIENT"
    '                    CurrentLevel = 4
    '                Case "OFFICE"
    '                    CurrentLevel = 3
    '                Case "DISCIPLINE"
    '                    CurrentLevel = 2
    '                Case "BUSINESS UNIT"
    '                    CurrentLevel = 1
    '                Case "CORPORATE"
    '                    CurrentLevel = 0
    '            End Select

    '            ' Get sFullConfigName from registry) if there is a regkey then we are running inside the Content Wizard
    '            'If GetFullConfigName() = "" Then
    '            bCalledFromContentWizard = False
    '            'Else
    '            '    bCalledFromContentWizard = True
    '            'End If

    '            ' Go through all the levels starting at the top and working up to the higher level - Corporate is the last level to check
    '            ' So if it is found in any of the lower levels then that value is kept
    '            ' This will only look in the DWT files
    '            For LevelCtr = CurrentLevel To 0 Step -1

    '                ' Work out file name
    '                If bCalledFromContentWizard = False Then
    '                    If UCase(Split(FullCfgName, "-")(LevelCtr)) <> "NONE" Then
    '                        ' If this is not an empty level then assign the name of the file to search for accordingly
    '                        ' Since the current level will always be 4 or the client level

    '                        If LevelCtr = 0 Then
    '                            If RuleAccessors.GetruleValue("TESTCONFIG", "FALSE", True).IsTrue Then
    '                                ' If this is a TEST configuration we need to strip the T@ from the front of the Corporate level CFG name
    '                                fName = RUNTIMEConfigPath.CombinePath("Settings", Right(Split(FullCfgName, "-")(LevelCtr), Len(Split(FullCfgName, "-")(LevelCtr)) - 2) & ".dwt")
    '                            Else
    '                                fName = RUNTIMEConfigPath.CombinePath("Settings", Split(FullCfgName, "-")(LevelCtr) & ".dwt")
    '                            End If
    '                        Else
    '                            fName = RUNTIMEConfigPath.CombinePath("Settings", Split(FullCfgName, "-")(LevelCtr) & ".dwt")
    '                        End If

    '                    Else
    '                        ' Set the file name to be "" if the Level = "NONE"
    '                        fName = ""
    '                    End If
    '                Else
    '                    If UCase(Split(FullCfgName, "-")(LevelCtr)) <> "NONE" Then
    '                        ' If this is not an empty level then assign the name of the file to search for accordingly
    '                        ' At the content wizard level we could be searching for stuff in levels other than the client
    '                        ' So if we are in the middle of creating Corporate level (0) content then there are no files prior to that to search so
    '                        ' set fname to ""
    '                        If CurrentLevel = 0 Then
    '                            ' This is a special case as Level 0 or corporate level dosen't have any levels above it to search
    '                            fName = ""
    '                        Else
    '                            ' Otherwise we are at one of the other levels , could be Business Unit,Discipline,Office or Client
    '                            If CurrentLevel = LevelCtr Then
    '                                ' AutoCAD can only import DWG files into another drawing file.
    '                                ' All level templates are stored as DWG format so that they can be imported
    '                                ' But the current level is used to create the file we are working on and that level will be saved as a DWT file

    '                                If System.IO.File.Exists(Settings.Manager.AutoCAD.WorkingSupportFolder & Split(FullCfgName, "-")(LevelCtr) & ".dwg") = False Then

    '                                    f1 = Settings.Manager.AutoCAD.WorkingSupportFolder & Split(FullCfgName, "-")(LevelCtr) & ".dwt"
    '                                    f2 = Settings.Manager.AutoCAD.WorkingSupportFolder & Split(FullCfgName, "-")(LevelCtr) & ".dwg"
    '                                    My.Computer.FileSystem.CopyFile(CStr(f1), f2)
    '                                End If

    '                            End If
    '                            fName = Settings.Manager.AutoCAD.WorkingFolderSupport & Split(FullCfgName, "-")(LevelCtr) & ".dwg"
    '                        End If
    '                    End If
    '                End If

    '                ' Check that the file exists and that we are not looking at a NONE level
    '                If fName <> "" Then
    '                    If System.IO.File.Exists(fName) = True Then

    '                        ' This is where we look for the rule in other files
    '                        toolrule = RuleAccessors.GetRule(strRuleID, fName)

    '                        If Not toolrule Is Nothing Then

    '                            ' If we had to go looking for this rule in other files then we might as well record it in this file so it's easier to get to next time
    '                            If bRecordRuleInThisFile = True Then
    '                                RuleAccessors.AddRule(toolrule.RuleID, toolrule.value, toolrule.Description, CStr(toolrule.DlgCode), CStr(toolrule.TableCode))
    '                            End If

    '                            ' Should the contents be imported
    '                            If bImport = True And (toolrule.TableCode = WZ_LINETYPE_TABLE Or toolrule.TableCode = WZ_LAYER_TABLE Or toolrule.TableCode = WZ_TEXTSTYLE_TABLE Or toolrule.TableCode = WZ_BLOCK_TABLE Or toolrule.TableCode = WZ_TABLESTYLE_TABLE Or toolrule.TableCode = WZ_DIMSTYLE_TABLE Or toolrule.TableCode = WZ_LAYOUTS_TABLE) Then


    '                                If RuleAndContentArePresent(strRuleID) = False Then

    '                                    ' If the value is not present in the file
    '                                    If Importer((toolrule.value), CStr((toolrule.TableCode)), bSetCurrent, fName, sDefault) = True Then
    '                                        ' The rule was imported with no problems
    '                                        ' No point in looking any further we found it
    '                                        Exit For
    '                                    Else
    '                                        ' Check to see if the rule can be imported and if so and we reached the end of the search then
    '                                        If LevelCtr = 0 Then
    '                                            ' Record the error message in the array so it can be displayed layer
    '                                            '  AddToMessageArray "Rule " & toolrule.RuleID & ", value: " & toolrule.value & " not found.", arrrulenf, j
    '                                            '                                    AddToMessageArray "Rule " & ToolRule.RuleID & ", value: " & ToolRule.Value & " not found."
    '                                        Else
    '                                            ' We didn't need to import it because it was an item that does not need to be imported
    '                                        End If
    '                                    End If
    '                                Else
    '                                    ' We didn't need to import it because it was already in the current DWG file so don't error
    '                                    ' No point in looking any further we don't need to import this one
    '                                    Exit For
    '                                End If
    '                            Else
    '                                ' We didn't need to import it because the function was told not to by the calling function or it was an item that could not be imported
    '                                ' No point in looking any further it's already in the DWG file
    '                                Exit For
    '                            End If
    '                        Else
    '                            ' Rule is not present in this file let the program continue so it can look at next level
    '                        End If
    '                    Else

    '                        If bCalledFromContentWizard = True Then

    '                        Else
    '                            ' Fname is not where it is supposed to be
    '                        End If

    '                    End If
    '                Else
    '                    If bCalledFromContentWizard = True Then

    '                    Else
    '                        ' If the level ctr = 0 then there is nothing else to search
    '                        If LevelCtr = 0 Then
    '                            ' We have exhausted the search
    '                        End If
    '                    End If

    '                End If
    '            Next  ' Go and look at the next level template

    '        End If

    '        TraverseFilesForRule = toolrule
    '    Catch ex As System.Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
    '        Return Nothing
    '    End Try

    'End Function

    ''' <summary>
    ''' Helper function for rule search function
    ''' This function is called when a tool can't find it's rules in the current file.
    ''' Rules are searched for in the Client DWG file or the Tools.DWG and if not present set to a default ow whatever is the current active style Settings
    ''' </summary>
    ''' <param name="strRuleID"></param>
    ''' <param name="bSetCurrent"></param>
    ''' <param name="sDefault"></param>
    ''' <param name="bImport"></param>
    ''' <param name="bRecordRuleInThisFile"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function TraverseFilesForRuleNew(ByRef strRuleID As String, ByRef fname As String, ByRef bSetCurrent As Boolean, ByRef sDefault As String, ByRef bImport As Boolean, Optional ByRef bRecordRuleInThisFile As Boolean = True) As Rule

        Try
            Dim toolrule As Rule = Nothing
            Dim FullCfgName As String

            If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then

                FullCfgName = GetruleValue("FULLCONFIGNAME")

                If System.IO.File.Exists(fname) = True Then

                    ' This is where we look for the rule in other files
                    toolrule = RuleAccessors.GetRule(strRuleID, fname)

                    If Not toolrule Is Nothing Then

                        ' If we had to go looking for this rule in other files then we might as well record it in this file so it's easier to get to next time
                        If bRecordRuleInThisFile = True Then
                            RuleAccessors.AddRule(toolrule.RuleID, toolrule.value, toolrule.Description, CStr(toolrule.DlgCode), CStr(toolrule.TableCode))
                        End If

                        ' Should the contents be imported
                        If bImport = True And (toolrule.TableCode = WZ_LINETYPE_TABLE Or toolrule.TableCode = WZ_LAYER_TABLE Or toolrule.TableCode = WZ_TEXTSTYLE_TABLE Or toolrule.TableCode = WZ_BLOCK_TABLE Or toolrule.TableCode = WZ_TABLESTYLE_TABLE Or toolrule.TableCode = WZ_DIMSTYLE_TABLE Or toolrule.TableCode = WZ_LAYOUTS_TABLE) Then

                            If RuleAndContentArePresent(strRuleID) = False Then

                                ' If the value is not present in the file
                                If ImporterNew(toolrule.value, CStr(toolrule.TableCode), bSetCurrent, fname, sDefault) = True Then

                                    ' The rule was imported with no problems
                                    ' No point in looking any further we found it

                                Else

                                End If
                            Else
                                ' We didn't need to import it because it was already in the current DWG file so don't error
                                ' No point in looking any further we don't need to import this one

                            End If
                        Else
                            ' We didn't need to import it because the function was told not to by the calling function or it was an item that could not be imported
                            ' No point in looking any further it's already in the DWG file

                        End If
                    Else
                        ' Rule is not present in this file let the program continue so it can look at next level
                    End If
                Else

                End If

            Else

            End If

            TraverseFilesForRuleNew = toolrule

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' Converts a decimal to a ratio - used for scaling viewports 
    ''' EG:  0.5   decimal returns 1:2
    '''      1.0   decimal returns 1:1
    '''      2.0   decimal returns 2:1
    '''      0.008 decimal returns 1:125 
    '''      0.025 decimal returns 1:40
    ''' </summary>
    ''' <param name="dDecimalScale"></param>
    ''' <param name="sDelimeter"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DecimalToRatio(ByRef dDecimalScale As Double, Optional ByRef sDelimeter As String = ":", Optional ByVal WithConversion As Boolean = False) As String


        If dDecimalScale < 1.0# Then

            Return "1" & sDelimeter & (1.0# / dDecimalScale).ToString

        Else

            ' Use the Mod function to divide the scale by 1 and if it returns a remainder then it's not a whole number
            If (dDecimalScale Mod 1) = 0 Then

                ' If it's a whole number then return number : 1
                Return dDecimalScale & sDelimeter & "1"

            Else

                ' Not catering for decimal scales
                Return "1" & sDelimeter & dDecimalScale

            End If

        End If




        '' When Metres return a / b 
        ''If InMM Then
        ''DecimalToRatio = "1" & sDelimeter & dDecimalScale.ToString
        ''Else
        '' DecimalToRatio = "1" & sDelimeter & (1.0# / dDecimalScale).ToString
        ''End If

        'Try
        '    
        '    Dim sRatio As String
        '    Dim dFactor As Double
        '    Dim dResult As Double

        '    dFactor = 1.0#

        '    dResult = remainder(dFactor, dDecimalScale)

        '    If dResult <> 0 Then
        '        If dResult <> 1 Then
        '            dResult = dFactor / dDecimalScale
        '            Do While CStr(dResult) Like "*.*"
        '                dFactor = dFactor + 1
        '                dResult = dFactor / dDecimalScale
        '            Loop

        '            If remainder(dDecimalScale, 1.0#) <> 0 Then
        '                dDecimalScale = dResult
        '                If WithConversion = True Then
        '                    sRatio = dFactor / dFactor & sDelimeter & dDecimalScale / dFactor * InsunitsToMMScaleFactor()
        '                Else
        '                    sRatio = dFactor / dFactor & sDelimeter & dDecimalScale / dFactor
        '                End If
        '            Else
        '                dDecimalScale = dResult
        '                If WithConversion = True Then
        '                    sRatio = dFactor & sDelimeter & dDecimalScale * InsunitsToMMScaleFactor()
        '                Else
        '                    sRatio = dFactor & sDelimeter & dDecimalScale
        '                End If
        '            End If
        '            DecimalToRatio = sRatio
        '        Else
        '            '2:1, 7:1 Anything that returns 1 would mean that the ratio is X:1
        '            sRatio = dDecimalScale & sDelimeter & dFactor
        '            DecimalToRatio = sRatio
        '        End If
        '    Else
        '        '         NFI why this would work
        '        '        If dDecimalScale < 1.0 Then
        '        'dDecimalScale = dFactor / dDecimalScale
        '        'sRatio = dFactor & sDelimeter & dDecimalScale
        '        '        Else

        '        '            sRatio = dFactor & sDelimeter & dDecimalScale
        '        '        End If

        '        If WithConversion = True Then
        '            sRatio = dFactor & sDelimeter & dDecimalScale * InsunitsToMMScaleFactor()
        '        Else
        '            sRatio = dFactor & sDelimeter & dDecimalScale
        '        End If
        '        DecimalToRatio = sRatio
        '    End If
        'Catch ex As Exception
        '    ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        '    Return ""
        'End Try

    End Function

    ''' <summary>
    ''' Does a lot of cheking that the ratio is valid #:# and then 
    ''' Converts a ratio to a decimal by dividing a / b
    ''' For example:
    '''       1:2  Returns 1/2   = 0.5
    '''       1:1  Returns 1/1   = 1.0
    '''       2:1  Returns 2/2   = 2.0
    '''      20:40 Returns 20/40 = 0.5 ... Note converting this back via the DecimalToRatio would result in 1:2 and not 20:40
    '''      40:20 Returns 40/20 = 2.0 ... Note converting this back via the DecimalToRatio would result in 2:1 and not 40:20
    '''      1:125 Returns 1/125 = 0.008
    '''      1:40  Returns 1/40  = 0.25
    ''' The delimeter is a : by default but could be optionally nomiated to be something else by calling function
    ''' </summary>
    ''' <param name="sRatioScale"></param>
    ''' <param name="sDelimeter"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RatioToDecimal(ByRef sRatioScale As String, Optional ByRef sDelimeter As String = ":") As Double

        Try

            Dim a As Double
            Dim b As Double

            If sRatioScale <> "" Then

                If Not sRatioScale Like "*" & sDelimeter & "*" Then
                    RatioToDecimal = 1.0#
                    Exit Function
                Else

                    If IsNumeric(Split(sRatioScale, sDelimeter)(0)) Then
                        a = Val(Split(sRatioScale, sDelimeter)(0))
                    Else
                        Acad_MessageBox("Invalid character in ratio - Ratio format should be like this 1:100 or 2:1 and not A:1", "invalid Character", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , logName)
                        RatioToDecimal = 1.0#
                        Exit Function
                    End If

                    If IsNumeric(Split(sRatioScale, sDelimeter)(1)) Then
                        b = Val(Split(sRatioScale, sDelimeter)(1))
                    Else
                        If Split(sRatioScale, sDelimeter)(1) <> "" Then
                            Acad_MessageBox("Invalid character in ratio - Ratio format should be like this 1:100 or 2:1 and not 1:A", "invalid Character", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , logName)
                        End If
                        RatioToDecimal = 1.0#
                        Exit Function
                    End If

                    If a = 0.0# Or b = 0.0# Then
                        Acad_MessageBox("Invalid character in ratio - Ratio format should be like this 1:1 and not 1:0 or 0:1", "invalid Character", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , logName)
                        RatioToDecimal = 1.0#
                        Exit Function
                    End If

                    RatioToDecimal = a / b

                End If
            Else
                RatioToDecimal = 1.0#
            End If

        Catch ex As System.Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return 1.0#

        End Try

    End Function

    '' Decimal number to Rational - eg - "4.25", it outputs "17/4"
    'Module Module1
    '    Dim n As Decimal
    '    Dim x As Double

    '    Sub Main()

    '        Console.WriteLine("Enter a decimal number")
    '        n = Console.ReadLine

    '        Do Until n / 1 = n \ 1
    '            n *= 10
    '            x += 1
    '        Loop
    '        x = 10 ^ x

    '        Dim divisor As Integer = gcd(n, x)
    '        n /= divisor
    '        x /= divisor
    '        n = Convert.ToInt64(n)

    '        Console.WriteLine("The rational equivalent is " & n & "/" & x)
    '        Console.ReadLine()


    '    End Sub

    '    Function gcd(ByVal a As Integer, ByVal b As Integer) As Integer
    '        If b Mod a = 0 Then
    '            Return a
    '        Else
    '            Return gcd(b, a Mod b)
    '        End If
    '    End Function


    'End Module


    'Public Function RatToDecimal(ByVal frac As String) As String

    '    Dim decimalVal As String = "0"
    '    Dim upper As Decimal = 0
    '    Dim lower As Decimal = 0
    '    Dim remain As Decimal = 0

    '    If frac.IndexOf(":") <> -1 Then

    '        If frac.IndexOf(" ") <> -1 Then
    '            remain = CType(frac.Substring(0, frac.IndexOf(" ")), Decimal)
    '            frac = frac.Substring(frac.IndexOf(" "))
    '        End If

    '    End If

    '    upper = CType(frac.Substring(0, frac.IndexOf(":")), Decimal)
    '    lower = CType(frac.Substring(frac.IndexOf(":") + 1), Decimal)

    '    If upper > lower Then
    '        Return "Error Please Check Fraction"
    '    Else
    '        decimalVal = (remain + (upper / lower)).ToString
    '    End If


    '    Return decimalVal

    'End Function

    ''' <summary>
    ''' As it says returs the remainder when two numbers are divided
    ''' </summary>
    ''' <param name="a"></param>
    ''' <param name="b"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function remainder(ByRef a As Double, ByRef b As Double) As Double
        Try

            Dim x As Integer
            If b <> 0 Then
                x = CInt(a / b)
            Else
                x = 1
            End If
            remainder = a - (b * x)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return 0.0

        End Try
    End Function

    ''' <summary>
    ''' Returns Scale of the drawing by checking the rule value or it's overrides
    ''' This can be called from an event where INSUNINTS can be used to work out conversion or it may be called from a dialog that is about to change to s differentt set of units
    ''' The default is to use INSUNITS to work out the conversion factor - if units of measure are specified then those usints will be used.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetScale(Optional ByVal ConversionRequired As Boolean = False, Optional ByVal UnitOfMeasure As String = "INSUNITS", Optional ByVal dScale As Double = 0.0#) As Double

        Try

            Select Case WhichSpace()

                Case "FloatingModelSpace"

                    ' Do not have to worry about INSUNITS here as viewports would have the scale stored with the convertion factor already worked out
                    Return System.Math.Round(ThisDrawingUtilities.ActivePViewport.CustomScale, 6)

                Case "ModelSpace"

                    ' Decimal scale is not stored so if it's not passed we need to derive it from the scale selected in the scale tool
                    ' Unit of measure does need to be take into account in this case
                    If dScale = 0.0# Then
                        ' See if there is an override on the scale
                        'Disabled Steven Houghton 23/10/17
                        Dim bIgnoreOverrides As Boolean = False '  = WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "False").IsTrue
                        ' Get the Scale of the drawing from the rule or it's override - in the ratio format - eg: 1:100
                        Dim sScale As String = RuleAccessors.GetruleValue("SCALE1", "1:1", bIgnoreOverrides, True)
                        dScale = RatioToDecimal(sScale)
                    End If

                    ' Unlikely that a Scale would ever be passed it's probably always derived as we dont't have buttons to set the scale like we do in the text tool
                    ' To select a particular text height on the go...
                    ' Should have dScale worked out by now - either passed or derived
                    Return dScale * InsunitsToMMScaleFactor()

                Case "PaperSpace"
                    ' Scale is always 1:1 MM so always return 1.0#
                    Return 1.0#

            End Select

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return 1.0#

    End Function
    Public Function GetDimScale() As Double
        Try
            GetDimScale = CDbl(ThisDrawingUtilities.GetVariable("DimScale"))

            If GetDimScale = 0.0# Then
                GetDimScale = 1.0
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return 1.0
        End Try
    End Function

    ''' <summary>
    ''' This function tells us if the user is currently in ModelSpace, PaperSpace or FloatingModelSpace
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function WhichSpace() As String
        Try

            Dim sReturnValue As String

            If ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acModelSpace Then
                sReturnValue = "ModelSpace"
            Else
                If ThisDrawingUtilities.MSpace = False Then
                    sReturnValue = "PaperSpace"
                Else
                    sReturnValue = "FloatingModelSpace"
                End If
            End If

            WhichSpace = sReturnValue
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return ""
        End Try

    End Function

    ''' <summary>
    ''' Converts INSUNIT numeric to INSUNITS as string value - used in dropdown boxes
    ''' By default this gets the INSUNITS system variable and converts the integer value to a String
    ''' If the function is passed a unit short then it will return the String value for that short - 0 to 20 are valid values
    ''' Example way to call this could be 
    '''                                     InsUnitsToStr ( 6 )              ' Returns Meters
    ''' </summary>
    ''' <param name="iInsUnits"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function InsunitsToStr(Optional ByRef iInsUnits As Integer = -1) As String

        Try

            If iInsUnits = -1 Then
                iInsUnits = CShort(ThisDrawingUtilities.GetVariable("INSUNITS"))
            End If

            Select Case iInsUnits
                Case 0
                    Return "Unspecified (No units)"
                Case 1
                    Return "Inches"
                Case 2
                    Return "Feet"
                Case 3
                    Return "Miles"
                Case 4
                    Return "Millimeters"
                Case 5
                    Return "Centimeters"
                Case 6
                    Return "Meters"
                Case 7
                    Return "Kilometers"
                Case 8
                    Return "Microinches"
                Case 9
                    Return "Mils"
                Case 10
                    Return "Yards"
                Case 11
                    Return "Angstroms"
                Case 12
                    Return "Nanometers"
                Case 13
                    Return "Microns"
                Case 14
                    Return "Decimeters"
                Case 15
                    Return "Decameters"
                Case 16
                    Return "Hectometers"
                Case 17
                    Return "Gigameters"
                Case 18
                    Return "Astronomical Units"
                Case 19
                    Return "Light Years"
                Case 20
                    Return "Parsecs"
                Case Else
                    Return Nothing

            End Select

        Catch ex As System.Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

            Return Nothing

        End Try

    End Function

    ''' <summary>
    ''' Converts INSUNITS string names to corresponding numeric this is not case sensitive
    ''' Example
    '''            InsunitsStrToInsunitsVal("Meters")      ' Returns 6 
    ''' </summary>
    ''' <param name="sInsUnitsString"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function InsunitsStrToInsunitsVal(ByRef sInsUnitsString As String) As Integer

        Try

            Select Case UCase(sInsUnitsString)
                Case UCase("Unspecified (No units)")
                    Return 0
                Case UCase("Inches")
                    Return 1
                Case UCase("Feet")
                    Return 2
                Case UCase("Miles")
                    Return 3
                Case UCase("Millimeters")
                    Return 4
                Case UCase("Centimeters")
                    Return 5
                Case UCase("Meters")
                    Return 6
                Case UCase("Kilometers")
                    Return 7
                Case UCase("Microinches")
                    Return 8
                Case UCase("Mils")
                    Return 9
                Case UCase("Yards")
                    Return 10
                Case UCase("Angstroms")
                    Return 11
                Case UCase("Nanometers")
                    Return 12
                Case UCase("Microns")
                    Return 13
                Case UCase("Decimeters")
                    Return 14
                Case UCase("Decameters")
                    Return 15
                Case UCase("Hectometers")
                    Return 16
                Case UCase("Gigameters")
                    Return 17
                Case UCase("Astronomical Units")
                    Return 18
                Case UCase("Light Years")
                    Return 19
                Case UCase("Parsecs")
                    Return 20
                Case Else
                    Return Nothing

            End Select

        Catch ex As System.Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing

        End Try

    End Function

    ''' <summary>
    ''' This function checks the INSUNITS system variable and returns the value which the scale needs to be divided by
    ''' Or in other words how many Millimeters there are in the Unit of measure specified.
    ''' in order to convert it into millimeter units. (AutoCAD plotting units if MEASUREMENT is set to 1)
    ''' </summary>
    ''' <param name="iInsUnits"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function InsunitsToMMScaleFactor(Optional ByRef iInsUnits As Integer = -1) As Double
        Try

            If iInsUnits = -1 Then
                iInsUnits = CInt(ThisDrawingUtilities.GetVariable("INSUNITS"))
            End If

            If CInt(ThisDrawingUtilities.GetVariable("MEASUREMENT")) = 1 Then

                ' This is a metric drawing we assume that the plotting units are in Millimeters

                Select Case iInsUnits
                    Case 0 ' Unspecified (No units)
                        Return 1.0#
                    Case 1 ' Inches
                        Return 25.4
                    Case 2 ' Feet
                        Return 304.8
                    Case 3 ' Miles
                        Return 1609344.0#
                    Case 4 ' Millimeters
                        Return 1.0#
                    Case 5 ' Centimeters
                        Return 10.0#
                    Case 6 ' Meters
                        Return 1000.0#
                    Case 7 ' Kilometers
                        Return 1000000.0#
                    Case 8 ' Microinches
                        Return 0.0000254
                    Case 9 ' Mils
                        Return 0.000254
                    Case 10 ' Yards
                        Return 914.4
                    Case 11 ' Angstroms
                        Return 0.0000000000001
                    Case 12 ' Nanometers
                        Return 0.000001
                    Case 13 ' Microns
                        Return 0.001
                    Case 14 ' Decimeters
                        Return 100.0#
                    Case 15 ' Decameters
                        Return 10000.0#
                    Case 16 ' Hectometers
                        Return 100.0#
                    Case 17 ' Gigameters
                        Return 1000000000000.0
                    Case 18 ' Astronomical Units
                        Return 1.0# ' Unknown  1.49597871 � 1014   ' 1.49597871 to the power of 14 
                    Case 19 ' Light Years
                        Return 9.460528E+18
                    Case 20 ' Parsecs
                        Return 3.085678E+19
                End Select

            Else

                ' This is an IMPERIAL drawing - need to work out all conversion factors accordingly
                ' Currently this is not Supported but can be easily implemented if required.

                Select Case iInsUnits
                    Case 0 ' Unspecified (No units)
                        Return 1.0#
                    Case 1 ' Inches
                        Return 1.0#
                    Case 2 ' Feet
                        Return 1.0#
                    Case 3 ' Miles
                        Return 1.0#
                    Case 4 ' Millimeters
                        Return 1.0#
                    Case 5 ' Centimeters
                        Return 1.0#
                    Case 6 ' Meters
                        Return 1.0#
                    Case 7 ' Kilometers
                        Return 1.0#
                    Case 8 ' Microinches
                        Return 1.0#
                    Case 9 ' Mils
                        Return 1.0#
                    Case 10 ' Yards
                        Return 1.0#
                    Case 11 ' Angstroms
                        Return 1.0#
                    Case 12 ' Nanometers
                        Return 1.0#
                    Case 13 ' Microns
                        Return 1.0#
                    Case 14 ' Decimeters
                        Return 1.0#
                    Case 15 ' Decameters
                        Return 1.0#
                    Case 16 ' Hectometers
                        Return 1.0#
                    Case 17 ' Gigameters
                        Return 1.0#
                    Case 18 ' Astronomical Units
                        Return 1.0#
                    Case 19 ' Light Years
                        Return 1.0#
                    Case 20 ' Parsecs
                        Return 1.0#

                End Select

            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return 1.0
        End Try

        Return 1.0

    End Function

    ''' <summary>
    ''' Gets the current AutoCAD profile as an object
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetCurrentProfile() As Object
        Try

            Dim sCurrentProfile As String
            Dim pPreferences As Autodesk.AutoCAD.Interop.AcadPreferences

            pPreferences = ThisDrawingUtilities.Application.Preferences
            sCurrentProfile = pPreferences.Profiles.ActiveProfile

            GetCurrentProfile = sCurrentProfile
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' We used to control this from a text file we had - ScaleListMetric.reg or something like that TO INVESTIGATE may be discontinued
    ''' </summary>
    ''' <param name="sFileNameAndPath"></param>
    ''' <param name="sMatchStr"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function ScaleListFileRead(ByRef sFileNameAndPath As String, ByRef sMatchStr As String) As String()
        Try

            Dim stemp As String
            Dim ctr As Integer
            Dim flength As Integer
            Dim ReturnValue() As String

            Try
                FileClose(1)
                If System.IO.File.Exists(sFileNameAndPath) = False Then
                    Acad_MessageBox("File Not Found: " & sFileNameAndPath, "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                    ScaleListFileRead = Nothing
                    Exit Function
                End If

                'open the text file
                FileOpen(1, sFileNameAndPath, Microsoft.VisualBasic.OpenMode.Input)

                ' This section is done to work out the size of the array required to store the values to be read
                ' May be possible to do using the preserve command
                flength = 0
                'until the end of file
                While Not EOF(1)
                    'read the line and store it in a variable
                    stemp = LineInput(1)
                    If stemp Like "*" & sMatchStr & "*" Then
                        flength = CShort(flength + 1)
                    End If
                End While
                Dim sLinesReadFromFile(flength - 1) As String

                ' Go back to the top of the file to read it again
                Seek(1, 1)

                If flength = 0 Then ' The dat file is empty - hence it's the first time use
                    Acad_MessageBox("File is empty  : " & sFileNameAndPath, "Empty File", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                    ScaleListFileRead = Nothing
                    Exit Function
                Else
                    ctr = 0
                    'until the end of file
                    While Not EOF(1)
                        'read the line and store it in a variable
                        stemp = LineInput(1)
                        If stemp Like "*" & sMatchStr & "*" Then
                            sLinesReadFromFile(ctr) = stemp
                            ctr = CShort(ctr + 1)
                        End If
                    End While
                    ' close the file
                    FileClose(1)
                End If

                ReturnValue = Array.Copy(sLinesReadFromFile)

                FileClose(1)
            Catch ex As System.Exception
                FileClose(1)
                ReturnValue = Nothing

            End Try

            Return ReturnValue
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' Bad naming convention we had Workspaces before AutoCAD had workspaces - what we are doing here is getting the current config name
    ''' from the drawing database
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetDrawingConfigurationName() As String

        Try

            ' ' Dim RuleAccessors As New RuleAccessors
            Dim sDrawingWorkspace As String
            Dim rConfigRule As Rule

            ' Get drawing workspace (from drawing ruleset)
            sDrawingWorkspace = ""

            If Not (RuleAccessors.GetRule("FULLCONFIGNAME") Is Nothing) Then
                rConfigRule = RuleAccessors.GetRule("FULLCONFIGNAME")
                sDrawingWorkspace = rConfigRule.value
            End If

            GetDrawingConfigurationName = sDrawingWorkspace
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' </summary>
    ''' <remarks></remarks>
    Sub StripScaleFromModeMacro()
        Try

            Dim sModeMacro As String
            Dim sModeMacroNew As String = ""

            sModeMacro = CStr(ThisDrawingUtilities.GetVariable("MODEMACRO"))

            If sModeMacro.ToUpper.Contains("SCALE:") Then
                ' This is one of ours remove everything from scale onwards
                ThisDrawingUtilities.SetVariable("MODEMACRO", "Not Associated")
            End If

            'If UBound(Split(sModeMacro, " ")) > 0 Then
            '    If UCase(Split(sModeMacro, " ")(0)) = "SCALE:" Then
            '        ' This is one of ours remove the first two elements
            '        For i = 2 To CShort(UBound(Split(sModeMacro, " ")))
            '            sModeMacroNew = sModeMacroNew & Split(sModeMacro, " ")(i)
            '        Next
            '        ThisDrawingUtilities.SetVariable("MODEMACRO", Replace(sModeMacroNew, "Configured", "Not Configured"))
            '    End If
            'End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try


    End Sub

    ''' <summary>
    ''' Get current AutoCAD Registry Hive
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetAcadProdNo(ByVal key As String) As String

        Return VB_Product_Key().Split(CChar("\\")).Last
    End Function

    ''' <summary>
    ''' Get current AutoCAD roamablerootprefix location
    ''' </summary>
    ''' <remarks></remarks>
    Private Function RoamableRootFolder(ByVal key As String) As String

        Return CStr(ThisDrawingUtilities.GetVariable("ROAMABLEROOTPREFIX"))
    End Function

    ''' <summary>
    ''' Equivalent of visual lisps VLAX-PRODUCT-KEY 
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function VB_Product_Key_Del(ByVal key As String) As String

        ' Used to be this one
        'Return Autodesk.AutoCAD.Runtime.SystemObjects.DynamicLinker.ProductKey
        ' 2013 changed it to one of these not sure which one ...
        'Return Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.MachineRegistryProductRootKey
        Return Replace(Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.UserRegistryProductRootKey, " - English", "")
    End Function

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_REMOVERULEOVERRIDESANDWORKVARS", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub SwitchRemoveRuleOverrides()
        Try

            If ThisDrawingIsConfigured() Then

                Acad_MessageBox("Cleaning rule overrides and workvars." & vbCrLf, , , , , , , True, logName)
                For Each Rule As Rule In RuleAccessors.GetAllRules
                    If Rule.RuleID.ToUpper.Contains("-DLGBOX") Then
                        RuleAccessors.RemoveRule(Rule.RuleID)
                    End If
                Next

                WorkingVariableAccessors.WorkVarsPurge()

            End If


        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Common exception message which depends on the calling routing to use reflection to work out dll name and function name
    ''' Example call
    '''     Acad_ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    ''' </summary>
    ''' <param name="ex"></param>
    ''' <param name="MethodName"></param>
    ''' <param name="sModuleName"></param>
    ''' <param name="bJustLog"></param>
    ''' <remarks></remarks>
    Public Sub Acad_ExceptionMessageBox(ByVal ex As System.Exception, ByVal MethodName As String, ByVal sModuleName As String, Optional ByVal bJustLog As Boolean = False, Optional ByVal AdditionalInformation As String = "", Optional ByVal LogName As String = "")

        Dim Ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor

        '' Check that a log file name was sent else get the name of this DLL and use it
        If LogName = String.Empty Then
            LogName = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        End If

        If bJustLog = False Then
            If Settings.Manager.AutoCAD.AEAcadWorkingRegKey = Nothing Then
                GeneralMessageBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, sModuleName & " - " & MethodName, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , False, LogName)
            Else
                If Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing", True) <> "True" Then

                    If AdditionalInformation = "" Then
                        Acad_MessageBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, sModuleName & " - " & MethodName, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , LogName)
                    Else
                        Acad_MessageBox(ex.Message & vbCrLf & AdditionalInformation & vbCrLf & vbCrLf & ex.StackTrace, sModuleName & " - " & MethodName, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , LogName)
                    End If
                Else
                    ThisDrawingUtilities.Utility.Prompt(vbCrLf & "Batch processor flag is in execution mode. Message boxes will not be displayed." &
                                    vbCrLf & "You can clear the flag using the Jacobs_ResetBatchProcessor command." & vbCrLf)
                End If

            End If

        End If

        '' The path to all logs is - C:\Users\Public\Documents\JacobsCAD is the best place for them so that CAD Support  staff can access them
        '' Especially now that User name and Asset number are added to the file names.
        Dim LogFolder As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("Jacobs")

        '' Gets the name of the Current AutoCAD DWG file and appends it to the front of the log name
        LogName = LogFolder.CombinePath(System.IO.Path.GetFileNameWithoutExtension(Ed.Document.Name) & "-" & LogName) & Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension)

        WriteToLog(ex.Message & vbCrLf & "!!! ERROR: " & AdditionalInformation & vbCrLf & ex.StackTrace, LogName)

    End Sub

    Public Function Acad_MessageBox(ByVal Text As String, Optional ByVal caption As String = "Jacobs Message", Optional ByVal buttons As MessageBoxButtons = MessageBoxButtons.OK, Optional ByVal icon As MessageBoxIcon = MessageBoxIcon.Information, Optional ByVal MessageBoxDefaultButton As MessageBoxDefaultButton = MessageBoxDefaultButton.Button1, Optional ByVal options As MessageBoxOptions = MessageBoxOptions.DefaultDesktopOnly, Optional ByVal displayhelpbutton As Boolean = False, Optional ByVal bJustLog As Boolean = False, Optional ByVal LogName As String = "") As DialogResult

        Dim Ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor

        Dim ans As DialogResult = DialogResult.Ignore

        '' Ensure every message we deliver is stamped with our name
        If Not caption.ToUpper.Contains("AutoCAD Environment Generated") Then
            caption = "AutoCAD Environment Generated " & caption
        End If

        '' Should we display a message box ?
        '' First check if there is a batch process running
        If Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing") <> "True" Then
            '' If not then check that the call wanted to see a message box or not
            If bJustLog = False Then
                ans = MessageBox.Show(Text, caption, buttons, icon, MessageBoxDefaultButton, options, displayhelpbutton)
            End If
        Else
            ThisDrawingUtilities.Utility.Prompt(vbCrLf & "Batch processor flag is in execution mode. Message boxes will not be displayed." &
                    vbCrLf & "You can clear the flag using the Jacobs_ResetBatchProcessor command." & vbCrLf)
        End If

        If bJustLog = True Then

            '' Check that a log file name was sent else get the name of this DLL and use it
            If LogName = String.Empty Then
                LogName = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            End If

            '' The path to all logs is - C:\Users\Public\Documents\Jacobs is the best place for them so that CAD Support staff can access them
            '' Especially now that User name and Asset number are added to the file names.
            Dim LogFolder As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("Jacobs\Jacobs AutoCAD Environment R21")

            '' Gets the name of the Current AutoCAD DWG file and appends it to the front of the log name
            LogName = LogFolder.CombinePath(System.IO.Path.GetFileNameWithoutExtension(Ed.Document.Name) & "-" & LogName)

            GeneralMessageBox(Text, , , , , , , , True, LogName)

        End If

        Return ans

    End Function

    ''' <summary>
    ''' This function checks if a block with a given name is defined and returns the number of times it is
    '''  used or -1 if it is not defined - note if the block is defined but not used it returns 0
    ''' 
    ''' </summary>
    ''' <param name="Block_Name"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function Block_Check(ByRef Block_Name As String) As Integer

        Dim tBlk As Autodesk.AutoCAD.Interop.Common.AcadBlock
        Dim tSSet As Autodesk.AutoCAD.Interop.AcadSelectionSet
        Dim tDXFCode(0) As Integer
        Dim tDXFValue(0) As Object

        On Error Resume Next

        tBlk = ThisDrawingUtilities.Blocks.Item(Block_Name)

        If (Err.Number = 0) And (Not (tBlk Is Nothing)) Then
            tSSet = ThisDrawingUtilities.SelectionSets.Item("mySelSetName")
            If Err.Number <> 0 Then
                tSSet = ThisDrawingUtilities.SelectionSets.Add("mySelSetName")
                Information.Err.Clear()
            End If
            tSSet.Clear()
            tDXFCode(0) = 2
            tDXFValue(0) = Block_Name
            tSSet.Select(Autodesk.AutoCAD.Interop.Common.AcSelect.acSelectionSetAll, , , tDXFCode, tDXFValue)
            Block_Check = CShort(tSSet.Count) ' The block is inserted this nuber of times - note it could be 0
        Else
            Information.Err.Clear()
            Block_Check = -1 ' The block is not defined
        End If

        On Error GoTo 0

exit_here:
        Exit Function

err_control:
        Select Case Err.Number
            'Add your Case selections here
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Resume exit_here
        End Select
        Resume exit_here

    End Function

    ''' <summary>
    ''' Specific function designed only to read the Tools.INI file based on topic 
    ''' </summary>
    ''' <param name="fil"></param>
    ''' <remarks></remarks>
    Public Sub INIFileReadTopics(ByRef fil As String)

        Dim stemp As String
        Dim ctr As Integer
        Dim x As Object
        Dim ToolsCtr As Integer
        Dim ToolBarCtr As Integer
        Dim PGPCtr As Integer
        Dim RulesCtr As Integer
        Dim HelpStringCtr As Integer
        Dim MenuStringCtr As Integer
        Dim FlyoutStringCtr As Integer
        Dim DescriptionCtr As Integer
        Dim AcceleratorCtr As Integer

        AcceleratorCtr = 0
        RulesCtr = 0
        ToolBarCtr = 0
        PGPCtr = 0
        ToolsCtr = 0
        HelpStringCtr = 0
        MenuStringCtr = 0
        FlyoutStringCtr = 0
        DescriptionCtr = 0

        'Dim ToolDetails() As ToolDetail

        On Error GoTo err_control

        FileClose(1) ' Just in case it was left open

        'open the text file
        On Error Resume Next
        FileOpen(1, fil, Microsoft.VisualBasic.OpenMode.Input)

        Dim flength As Integer
        flength = 0
        'until the end of file
        While Not EOF(1)
            'read the line and store it in a variable
            stemp = LineInput(1)
            flength = CShort(flength + 1)
        End While

        Seek(1, 1)

        Dim config_params(flength) As String

        ctr = 0
        'until the end of file

        While Not EOF(1)
            'read the line and store it in a variable
            stemp = LineInput(1)
            If Right(stemp, 1) = "]" And Left(stemp, 1) = "[" Then
                config_params(ctr) = stemp
                ReDim Preserve ToolDetails(ToolsCtr)

                If stemp <> "" Then
                    ToolDetails(ToolsCtr).ToolName = stemp
                End If


                While Not stemp = "" And Not EOF(1)
                    If Right(stemp, 1) = ";" Then

                    Else
                        stemp = LineInput(1)

                        If Left(stemp, 12) = "ToolGroup = " Then
                            ToolDetails(ToolsCtr).ToolGroup = Mid(stemp, 13, Len(stemp) - 12)
                        End If

                        If Left(stemp, 13) = "MenuString = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).MenuString(MenuStringCtr)
                            ToolDetails(ToolsCtr).MenuString(MenuStringCtr) = Mid(stemp, 14, Len(stemp) - 13)
                            MenuStringCtr = CShort(MenuStringCtr + 1)
                        End If

                        If Left(stemp, 15) = "FlyoutString = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).FlyoutString(FlyoutStringCtr)
                            ToolDetails(ToolsCtr).FlyoutString(FlyoutStringCtr) = Mid(stemp, 16, Len(stemp) - 15)
                            FlyoutStringCtr = CShort(FlyoutStringCtr + 1)
                        End If

                        If Left(stemp, 13) = "HelpString = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).HelpString(HelpStringCtr)
                            ToolDetails(ToolsCtr).HelpString(HelpStringCtr) = Mid(stemp, 14, Len(stemp) - 13)
                            HelpStringCtr = CShort(HelpStringCtr + 1)
                        End If

                        ' May need to be an array of toolbars
                        If Left(stemp, 16) = "ToolBarString = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).ToolBarString(ToolBarCtr)
                            ToolDetails(ToolsCtr).ToolBarString(ToolBarCtr) = Mid(stemp, 17, Len(stemp) - 16)
                            ToolBarCtr = CShort(ToolBarCtr + 1)
                        End If

                        If Left(stemp, 16) = "MNLFileString = " Then
                            ToolDetails(ToolsCtr).MNLFileString = Mid(stemp, 17, Len(stemp) - 16)
                        End If

                        ' May need to be an array of aliases
                        If Left(stemp, 16) = "PGPFileString = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).PGPFileString(PGPCtr)
                            ToolDetails(ToolsCtr).PGPFileString(PGPCtr) = Mid(stemp, 17, Len(stemp) - 16)
                            PGPCtr = CShort(PGPCtr + 1)
                        End If

                        ' May need to be an array of descriptions
                        If Left(stemp, 14) = "Description = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).Description(DescriptionCtr)
                            ToolDetails(ToolsCtr).Description(DescriptionCtr) = Mid(stemp, 15, Len(stemp) - 14)
                            DescriptionCtr = CShort(DescriptionCtr + 1)
                        End If

                        ' May need to be an array of rules
                        If Left(stemp, 7) = "Rule = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).Rules(RulesCtr)
                            ToolDetails(ToolsCtr).Rules(RulesCtr) = Mid(stemp, 8, Len(stemp) - 7)
                            RulesCtr = CShort(RulesCtr + 1)
                        End If

                        ' May need to be an array of Accelerators
                        If Left(stemp, 14) = "Accelerator = " Then
                            ReDim Preserve ToolDetails(ToolsCtr).Accelerators(AcceleratorCtr)
                            ToolDetails(ToolsCtr).Accelerators(AcceleratorCtr) = Mid(stemp, 15, Len(stemp) - 14)
                            AcceleratorCtr = CShort(AcceleratorCtr + 1)
                        End If

                        If Left(stemp, 15) = "GenericRules = " Then
                            ToolDetails(ToolsCtr).GenericRules = Mid(stemp, 16, Len(stemp) - 15)
                        End If

                    End If
                End While

                ToolsCtr = CShort(ToolsCtr + 1)
                RulesCtr = 0
                ToolBarCtr = 0
                PGPCtr = 0
                HelpStringCtr = 0
                MenuStringCtr = 0
                FlyoutStringCtr = 0
                DescriptionCtr = 0
                AcceleratorCtr = 0

            End If
            ctr = CShort(ctr + 1)

        End While
        ' close the file
        FileClose(1)

exit_here:
        Exit Sub

err_control:
        Select Case Err.Number
            'Add your Case selections here
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Resume exit_here
        End Select

    End Sub

    ''' <summary>
    ''' The importer function will only work if the drawing you are using has a CLIENT rule in it telling us where the
    ''' master content file lives.
    ''' </summary>
    ''' <param name="ItemName"></param>
    ''' <param name="Table_Type"></param>
    ''' <param name="makecurrent"></param>
    ''' <param name="fName"></param>
    ''' <param name="sDefault"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Importer(ByRef ItemName As String, ByRef Table_Type As String, Optional ByRef makecurrent As Boolean = False, Optional ByRef fName As String = "", Optional ByRef sDefault As String = "0") As Boolean

        Dim AutocadDoc As Autodesk.AutoCAD.Interop.Common.AxDbDocument ' which WAS A NON loaded Class Now Loaded autocad object dbx 16
        Dim symbolTableRecords(0) As Autodesk.AutoCAD.Interop.Common.AcadObject
        Dim objLayer As Autodesk.AutoCAD.Interop.Common.AcadLayer
        Dim objTextStyle As Autodesk.AutoCAD.Interop.Common.AcadTextStyle
        Dim objDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle
        Dim objLineType As Autodesk.AutoCAD.Interop.Common.AcadLineType
        Dim objLayout As Autodesk.AutoCAD.Interop.Common.AcadLayout
        Dim item As Object

        If fName <> "" Then

            AutocadDoc = New Autodesk.AutoCAD.Interop.Common.AxDbDocument
            AutocadDoc.Open(fName)
            On Error Resume Next

            Select Case Table_Type

                Case CStr(WZ_BLOCK_TABLE)

                    ' Check to see if the object in this file already
                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            If BlockExist(CStr(item)) = False Then
                                ' Check to see if the object in this file we are looking in
                                If AutocadDoc.Blocks.Item(item) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.Blocks.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Blocks)
                                Else

                                    '"The BLOCK: " & item.tostring & " does not exist in the file specified.")
                                    '                        ThisDrawing.Blocks.Add (0,0,0, item)
                                End If
                            Else

                                ''"The BLOCK: " & item.tostring & " does not need to be imported as it is already present in this drawing.")

                            End If
                        Next item
                    Else
                        If BlockExist(CStr(ItemName)) = False Then
                            ' Check to see if the object in this file we are looking in
                            If AutocadDoc.Blocks.Item(ItemName) IsNot Nothing Then
                                symbolTableRecords(0) = CType(AutocadDoc.Blocks.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Blocks)
                            Else

                                '    The BLOCK: " & ItemName & " does not exist in the file specified.

                            End If
                        Else

                            '  "The BLOCK: " & ItemName & " does not need to be imported as it is already present in this drawing.

                        End If
                    End If

                Case CStr(WZ_DIMSTYLE_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If DimStyleExist(CStr(item)) = False Then
                                ' Check to see if the object in this file we are looking in

                                If AutocadDoc.DimStyles.Item(item) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.DimStyles.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.DimStyles)
                                    If makecurrent = True Then
                                        'UPGRADE_WARNING: Couldn't resolve default property of object ThisDrawing.DimStyles. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                        objDimStyle = ThisDrawingUtilities.DimStyles.Item(item)
                                        'UPGRADE_WARNING: Couldn't resolve default property of object ThisDrawing.ActiveDimStyle. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                        'UPGRADE_WARNING: Couldn't resolve default property of object objDimStyle. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                        ThisDrawingUtilities.ActiveDimStyle = objDimStyle
                                    End If
                                Else

                                    ' The DIMENSION STYLE: " & item.tostring & " does not exist in the file specified.

                                    ThisDrawingUtilities.DimStyles.Add(CStr(item))


                                End If
                            Else

                                ' The DIMENSION STYLE: " & item.tostring & " does not need to be imported as it is already present in this drawing.

                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If DimStyleExist(CStr(ItemName)) = False Then
                            ' Check to see if the object in this file we are looking in

                            If AutocadDoc.DimStyles.Item(ItemName) IsNot Nothing Then
                                symbolTableRecords(0) = CType(AutocadDoc.DimStyles.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.DimStyles)
                                If makecurrent = True Then
                                    objDimStyle = ThisDrawingUtilities.DimStyles.Item(ItemName)
                                    ThisDrawingUtilities.ActiveDimStyle = objDimStyle
                                End If
                            Else

                                ' The DIMENSION STYLE: " & ItemName & " does not exist in the file specified.

                                ThisDrawingUtilities.DimStyles.Add(ItemName)

                            End If
                        Else

                            ' The DIMENSION STYLE: " & ItemName & " does not need to be imported as it is already present in this drawing.

                        End If
                    End If

                Case CStr(WZ_LAYER_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If LayerExist(CStr(item)) = False Then

                                ' Check to see if the object in this file we are looking in

                                If AutocadDoc.Layers.Item(item) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.Layers.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layers)
                                    If makecurrent = True Then
                                        objLayer = ThisDrawingUtilities.Layers.Item(item)
                                        ThisDrawingUtilities.ActiveLayer = objLayer
                                    End If
                                Else

                                    ' The LAYER: " & item.tostring & " does not exist in the file specified.

                                    ThisDrawingUtilities.Layers.Add(CStr(item))
                                End If
                            Else
                                ' The LAYER: " & item.tostring & " does not need to be imported as it is already present in this drawing.

                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If LayerExist(CStr(ItemName)) = False Then
                            ' Check to see if the object in this file we are looking in

                            If AutocadDoc.Layers.Item(ItemName) IsNot Nothing Then
                                symbolTableRecords(0) = CType(AutocadDoc.Layers.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layers)
                                If makecurrent = True Then
                                    objLayer = ThisDrawingUtilities.Layers.Item(ItemName)
                                    ThisDrawingUtilities.ActiveLayer = objLayer
                                End If
                            Else

                                ' The LAYER: " & ItemName & " does not exist in the file specified.

                                ThisDrawingUtilities.Layers.Add(ItemName)
                            End If
                        Else

                            ' The LAYER: " & ItemName & " does not need to be imported as it is already present in this drawing.

                        End If
                    End If

                Case CStr(WZ_LINETYPE_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If LineTypeExist(CStr(item)) = False Then
                                ' Check to see if the object in this file we are looking in

                                If AutocadDoc.Linetypes.Item(item) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.Linetypes.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Linetypes)
                                    If makecurrent = True Then
                                        objLineType = ThisDrawingUtilities.Linetypes.Item(item)
                                        ThisDrawingUtilities.ActiveLinetype = objLineType
                                    End If
                                Else
                                    '  The LINETYPE: " & item.tostring & " does not exist in the file specified.
                                    ThisDrawingUtilities.Linetypes.Add(CStr(item))
                                End If
                            Else
                                ' The LINETYPE: " & item.tostring & " does not need to be imported as it is already present in this drawing.
                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If LineTypeExist(CStr(ItemName)) = False Then
                            ' Check to see if the object in this file we are looking in

                            If AutocadDoc.Linetypes.Item(ItemName) IsNot Nothing Then
                                symbolTableRecords(0) = CType(AutocadDoc.Linetypes.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Linetypes)
                                If makecurrent = True Then
                                    objLineType = ThisDrawingUtilities.Linetypes.Item(ItemName)
                                    ThisDrawingUtilities.ActiveLinetype = objLineType
                                End If
                            Else
                                ' The LINETYPE: " & ItemName & " does not exist in the file specified.
                                ThisDrawingUtilities.Linetypes.Add(ItemName)
                            End If
                        Else
                            '  The LINETYPE: " & ItemName & " does not need to be imported as it is already present in this drawing.
                        End If
                    End If

                Case CStr(WZ_TEXTSTYLE_TABLE)

                    If ItemName = "*" Then
                        ' Load all of them
                        For Each st As Autodesk.AutoCAD.Interop.Common.AcadTextStyle In AutocadDoc.TextStyles

                            item = st.Name

                            If TextStyleExist(CStr(item)) = False Then
                                ' Check to see if the object in this file we are looking in
                                If AutocadDoc.TextStyles.Item(item) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.TextStyles.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.TextStyles)
                                    If makecurrent = True Then
                                        objTextStyle = ThisDrawingUtilities.TextStyles.Item(item)
                                        ThisDrawingUtilities.ActiveTextStyle = objTextStyle
                                    End If
                                Else
                                    ' The TEXTSTYLE: " & item.tostring & " does not exist in the file specified.
                                    ThisDrawingUtilities.TextStyles.Add(CStr(item))
                                End If
                            Else
                                ' The TEXTSTYLE: " & item.tostring & " does not need to be imported as it is already present in this drawing.
                            End If

                        Next

                    Else


                        If UBound(Split(ItemName, ";")) > 0 Then
                            For Each item In Split(ItemName, ";")
                                ' Check to see if the object in this file already
                                If TextStyleExist(CStr(item)) = False Then
                                    ' Check to see if the object in this file we are looking in
                                    If AutocadDoc.TextStyles.Item(item) IsNot Nothing Then
                                        symbolTableRecords(0) = CType(AutocadDoc.TextStyles.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                        AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.TextStyles)
                                        If makecurrent = True Then
                                            objTextStyle = ThisDrawingUtilities.TextStyles.Item(item)
                                            ThisDrawingUtilities.ActiveTextStyle = objTextStyle
                                        End If
                                    Else
                                        ' The TEXTSTYLE: " & item.tostring & " does not exist in the file specified.
                                        ThisDrawingUtilities.TextStyles.Add(CStr(item))
                                    End If
                                Else
                                    ' The TEXTSTYLE: " & item.tostring & " does not need to be imported as it is already present in this drawing.
                                End If
                            Next item
                        Else
                            ' Check to see if the object in this file already
                            If TextStyleExist(CStr(ItemName)) = False Then
                                ' Check to see if the object in this file we are looking in

                                If AutocadDoc.TextStyles.Item(ItemName) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.TextStyles.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.TextStyles)
                                    If makecurrent = True Then
                                        objTextStyle = ThisDrawingUtilities.TextStyles.Item(ItemName)
                                        ThisDrawingUtilities.ActiveTextStyle = objTextStyle
                                    End If
                                Else
                                    ' The TEXTSTYLE: " & ItemName & " does not exist in the file specified.
                                    ThisDrawingUtilities.TextStyles.Add(ItemName)
                                End If
                            Else
                                '  The TEXTSTYLE: " & ItemName & " does not need to be imported as it is already present in this drawing.
                            End If
                        End If

                    End If

                Case CStr(WZ_LAYOUTS_TABLE)

                    If UBound(Split(ItemName, ";")) > 0 Then
                        For Each item In Split(ItemName, ";")
                            ' Check to see if the object in this file already
                            If LayoutExist(CStr(item)) = False Then
                                ' Check to see if the object in this file we are looking in

                                If AutocadDoc.Layouts.Item(item) IsNot Nothing Then
                                    symbolTableRecords(0) = CType(AutocadDoc.Layouts.Item(item), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                    AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layouts)
                                    If makecurrent = True Then
                                        objLayout = ThisDrawingUtilities.Layouts.Item(item)
                                        ThisDrawingUtilities.ActiveLayout = objLayout
                                    End If
                                Else
                                    ' The layout: " & item.tostring & " does not exist in the file specified.
                                    ThisDrawingUtilities.Layouts.Add(CStr(item))
                                End If
                            Else
                                '  The layout: " & item.tostring & " does not need to be imported as it is already present in this drawing.
                            End If
                        Next item
                    Else
                        ' Check to see if the object in this file already
                        If LayoutExist(CStr(ItemName)) = False Then
                            ' Check to see if the object in this file we are looking in

                            If AutocadDoc.Layouts.Item(ItemName) IsNot Nothing Then
                                symbolTableRecords(0) = CType(AutocadDoc.Layouts.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layouts)
                                If makecurrent = True Then
                                    objLayout = ThisDrawingUtilities.Layouts.Item(ItemName)
                                    ThisDrawingUtilities.ActiveLayout = objLayout
                                End If
                            Else
                                ' The layout: " & ItemName & " does not exist in the file specified.
                                ThisDrawingUtilities.Layouts.Add(ItemName)
                            End If
                        Else
                            ' The layout: " & ItemName & " does not need to be imported as it is already present in this drawing.
                        End If
                    End If

                Case CStr(WZ_LINEWEIGHT)
                    ' This object cannot be imported but it can be set current if desired
                    If makecurrent = True Then

                        ThisDrawingUtilities.SetVariable(WZ_LINEWEIGHT_SYSVAR, sDefault)
                        Acad_MessageBox("Set Lineweight system variable to: " & sDefault, "System Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)

                    End If

                Case CStr(WZ_COLOUR)
                    ' This object cannot be imported but it can be set current if desired
                    If makecurrent = True Then

                        ThisDrawingUtilities.SetVariable(WZ_COLOUR_SYSVAR, sDefault)
                        Acad_MessageBox("Set Colour system variable to: " & sDefault, "System Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)

                    End If

                Case CStr(WZ_INSUNITS)
                    ' This object cannot be imported but it can be set current if desired
                    If makecurrent = True Then

                        ThisDrawingUtilities.SetVariable(WZ_INSUNITS_SYSVAR, sDefault)
                        Acad_MessageBox("Set InsUnits system variable to: " & sDefault, "System Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)

                    End If

                Case CStr(WZ_CUSTOM)
                    ' NOT RELEVANT
                    ' This object cannot be imported but it can be set current if desired

                Case Else
                    '  The ITEM: " & ItemName & " selected to import is not an item that can be imported, as it is not saved in the drawing database.
            End Select
        Else

            CreateContent(ItemName, Table_Type, makecurrent)

        End If

        AutocadDoc = Nothing

        If symbolTableRecords(0) Is Nothing Then
            Importer = False
        Else
            Importer = True
        End If

exit_here:
        Exit Function

err_control:
        Select Case Err.Number
            'Add your Case selections here
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Resume exit_here
        End Select

    End Function

    ''' <summary>
    ''' The importer function will only work if the drawing you are using has a CLIENT rule in it telling us where the
    ''' master content file lives.
    ''' </summary>
    ''' <param name="ItemName"></param>
    ''' <param name="Table_Type"></param>
    ''' <param name="makecurrent"></param>
    ''' <param name="fName"></param>
    ''' <param name="sDefault"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ImporterNew(ByRef ItemName As String, ByRef Table_Type As String, Optional ByRef makecurrent As Boolean = False, Optional ByRef fName As String = "", Optional ByRef sDefault As String = "0") As Boolean

        Dim AutocadDoc As Autodesk.AutoCAD.Interop.Common.AxDbDocument ' which WAS A NON loaded Class Now Loaded autocad object dbx 16
        Dim symbolTableRecords(0) As Autodesk.AutoCAD.Interop.Common.AcadObject
        Dim objLayer As Autodesk.AutoCAD.Interop.Common.AcadLayer
        Dim objTextStyle As Autodesk.AutoCAD.Interop.Common.AcadTextStyle
        Dim objDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle
        Dim objLineType As Autodesk.AutoCAD.Interop.Common.AcadLineType
        Dim objLayout As Autodesk.AutoCAD.Interop.Common.AcadLayout
        Dim item As Object
        Dim Imported As Boolean = False

        If fName <> "" Then

            AutocadDoc = New Autodesk.AutoCAD.Interop.Common.AxDbDocument
            AutocadDoc.Open(fName)
            On Error Resume Next

            Select Case Table_Type

                Case CStr(WZ_BLOCK_TABLE)

                    If BlockExist(CStr(ItemName)) = False Then

                        ' Check to see if the object in this file we are looking in
                        For i As Integer = 0 To AutocadDoc.Blocks.Count - 1

                            If AutocadDoc.Blocks.Item(i).Name.ToUpper = ItemName.ToUpper Then

                                symbolTableRecords(0) = CType(AutocadDoc.Blocks.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Blocks)

                                Imported = True
                                Exit For

                            End If

                        Next

                        If Imported = False Then
                            Acad_MessageBox("The BLOCK: " & ItemName & " was not found in : " & fName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("The BLOCK: " & ItemName & " was imported from: " & fName, , , , , , , True, logName)
                        End If

                    Else

                        Acad_MessageBox("The BLOCK: " & ItemName & " does not need to be imported as it is already present in this drawing.", , , , , , , True, logName)

                    End If


                Case CStr(WZ_DIMSTYLE_TABLE)

                    ' Check to see if the object in this file already
                    If DimStyleExist(CStr(ItemName)) = False Then

                        ' Check to see if the object in this file we are looking in
                        For i As Integer = 0 To AutocadDoc.DimStyles.Count - 1

                            If AutocadDoc.DimStyles.Item(i).Name.ToUpper = ItemName.ToUpper Then

                                symbolTableRecords(0) = CType(AutocadDoc.DimStyles.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.DimStyles)

                                If makecurrent = True Then
                                    objDimStyle = ThisDrawingUtilities.DimStyles.Item(ItemName)
                                    ThisDrawingUtilities.ActiveDimStyle = objDimStyle
                                End If

                                Imported = True
                                Exit For

                            End If

                        Next

                        If Imported = False Then
                            Acad_MessageBox("The DIMENSION STYLE: " & ItemName & " was not found in : " & fName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("The DIMENSION STYLE: " & ItemName & " was imported from: " & fName, , , , , , , True, logName)
                        End If

                    Else
                        Acad_MessageBox("The DIMENSION STYLE: " & ItemName & " does not need to be imported as it is already present in this drawing.", , , , , , , True, logName)
                    End If

                Case CStr(WZ_TEXTSTYLE_TABLE)

                    ' Check to see if the object in this file already
                    If TextStyleExist(CStr(ItemName)) = False Then

                        ' Check to see if the object in this file we are looking in
                        For i As Integer = 0 To AutocadDoc.TextStyles.Count - 1

                            If AutocadDoc.TextStyles.Item(i).Name.ToUpper = ItemName.ToUpper Then

                                symbolTableRecords(0) = CType(AutocadDoc.TextStyles.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.TextStyles)

                                If makecurrent = True Then
                                    objTextStyle = ThisDrawingUtilities.TextStyles.Item(ItemName)
                                    ThisDrawingUtilities.ActiveTextStyle = objTextStyle
                                End If

                                Imported = True
                                Exit For

                            End If

                        Next

                        If Imported = False Then
                            Acad_MessageBox("The TEXT STYLE: " & ItemName & " was not found in : " & fName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("The TEXT STYLE: " & ItemName & " was imported from: " & fName, , , , , , , True, logName)
                        End If

                    Else
                        Acad_MessageBox("The TEXT STYLE: " & ItemName & " does not need to be imported as it is already present in this drawing.", , , , , , , True, logName)
                    End If

                Case CStr(WZ_LAYER_TABLE)

                    ' Check to see if the object in this file already
                    If LayerExist(CStr(ItemName)) = False Then

                        ' Check to see if the object in this file we are looking in
                        For i As Integer = 0 To AutocadDoc.Layers.Count - 1

                            If AutocadDoc.Layers.Item(i).Name.ToUpper = ItemName.ToUpper Then

                                symbolTableRecords(0) = CType(AutocadDoc.Layers.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layers)

                                If makecurrent = True Then
                                    objLayer = ThisDrawingUtilities.Layers.Item(ItemName)
                                    ThisDrawingUtilities.ActiveLayer = objLayer
                                End If

                                Imported = True
                                Exit For

                            End If

                        Next

                        If Imported = False Then
                            Acad_MessageBox("The LAYER: " & ItemName & " was not found in : " & fName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("The LAYER: " & ItemName & " was imported from: " & fName, , , , , , , True, logName)
                        End If

                    Else
                        Acad_MessageBox("The LAYER: " & ItemName & " does not need to be imported as it is already present in this drawing.", , , , , , , True, logName)
                    End If

                Case CStr(WZ_LINETYPE_TABLE)

                    ' Check to see if the object in this file already
                    If LineTypeExist(CStr(ItemName)) = False Then

                        ' Check to see if the object in this file we are looking in
                        For i As Integer = 0 To AutocadDoc.Linetypes.Count - 1

                            If AutocadDoc.Linetypes.Item(i).Name.ToUpper = ItemName.ToUpper Then

                                symbolTableRecords(0) = CType(AutocadDoc.Linetypes.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Linetypes)

                                If makecurrent = True Then
                                    objLineType = ThisDrawingUtilities.Linetypes.Item(ItemName)
                                    ThisDrawingUtilities.ActiveLinetype = objLineType
                                End If

                                Imported = True
                                Exit For

                            End If

                        Next

                        If Imported = False Then
                            Acad_MessageBox("The LINE TYPE: " & ItemName & " was not found in : " & fName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("The LINE TYPE: " & ItemName & " was imported from: " & fName, , , , , , , True, logName)
                        End If

                    Else
                        Acad_MessageBox("The LINETYPE: " & ItemName & " does not need to be imported as it is already present in this drawing.", , , , , , , True, logName)
                    End If

                Case CStr(WZ_LAYOUTS_TABLE)

                    ' Check to see if the object in this file already
                    If LayoutExist(CStr(ItemName)) = False Then
                        ' Check to see if the object in this file we are looking in

                        ' Check to see if the object in this file we are looking in
                        For i As Integer = 0 To AutocadDoc.Layouts.Count - 1

                            If AutocadDoc.Layouts.Item(i).Name.ToUpper = ItemName.ToUpper Then

                                symbolTableRecords(0) = CType(AutocadDoc.Layouts.Item(ItemName), Autodesk.AutoCAD.Interop.Common.AcadObject)
                                AutocadDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layouts)

                                If makecurrent = True Then
                                    objLayout = ThisDrawingUtilities.Layouts.Item(ItemName)
                                    ThisDrawingUtilities.ActiveLayout = objLayout
                                End If

                                Imported = True
                                Exit For

                            End If

                        Next

                        If Imported = False Then
                            Acad_MessageBox("The LAYOUT: " & ItemName & " was not found in : " & fName, , , , , , , True, logName)
                        Else
                            Acad_MessageBox("The LAYOUT: " & ItemName & " was imported from: " & fName, , , , , , , True, logName)
                        End If

                    Else
                        Acad_MessageBox("The LINETYPE: " & ItemName & " does not need to be imported as it is already present in this drawing.", , , , , , , True, logName)
                    End If

                Case CStr(WZ_LINEWEIGHT)
                    ' This object cannot be imported but it can be set current if desired
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable(WZ_LINEWEIGHT_SYSVAR, sDefault)
                        Acad_MessageBox("Set Lineweight system variable to: " & sDefault, "System Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)
                    End If

                Case CStr(WZ_COLOUR)
                    ' This object cannot be imported but it can be set current if desired
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable(WZ_COLOUR_SYSVAR, sDefault)
                        Acad_MessageBox("Set Colour system variable to: " & sDefault, "System Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)
                    End If

                Case CStr(WZ_INSUNITS)
                    ' This object cannot be imported but it can be set current if desired
                    If makecurrent = True Then
                        ThisDrawingUtilities.SetVariable(WZ_INSUNITS_SYSVAR, sDefault)
                        Acad_MessageBox("Set InsUnits system variable to: " & sDefault, "System Variable Set", MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, logName)
                    End If

                Case CStr(WZ_CUSTOM)
                    ' NOT RELEVANT
                    ' This object cannot be imported but it can be set current if desired

                Case Else
                    '  The ITEM: " & ItemName & " selected to import is not an item that can be imported, as it is not saved in the drawing database.
            End Select
        Else

            CreateContent(ItemName, Table_Type, makecurrent)

        End If

        AutocadDoc = Nothing

        If symbolTableRecords(0) Is Nothing Then
            ImporterNew = False
        Else
            ImporterNew = True
        End If

exit_here:
        Exit Function

err_control:
        Select Case Err.Number
            'Add your Case selections here
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Resume exit_here
        End Select

    End Function


    ''' <summary>
    ''' Send this function a list box with selected file names and it will delet them
    ''' </summary>
    ''' <param name="lBox"></param>
    ''' <param name="sPath"></param>
    ''' <remarks></remarks>
    Public Sub DeleteSelectedFiles(ByVal lBox As ListBox, ByVal sPath As String)

        Dim i As Integer
        Dim ItemsAreSelected As Boolean

        ItemsAreSelected = False

        For i = 0 To CShort(lBox.Items.Count - 1)
            If lBox.GetSelected(i) = True Then
                ItemsAreSelected = True
            End If
        Next i

        If ItemsAreSelected = True Then
            If Acad_MessageBox("Are you sure you wish to delete all selected item(s)?", "Delete Selected", MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , logName) = DialogResult.Yes Then
                For i = 0 To CShort(lBox.Items.Count - 1)
                    If lBox.GetSelected(i) = True Then
                        My.Computer.FileSystem.DeleteFile(sPath.CombinePath(UserInterface.GetListBoxText(lBox, i)))
                    End If
                Next i
            End If
        End If

    End Sub

    ''' <summary>
    ''' Opens up each file in the passed list box in notepad - for editing
    ''' </summary>
    ''' <param name="lBox"></param>
    ''' <param name="sPath"></param>
    ''' <remarks></remarks>
    Public Sub EditSelectedFiles(ByVal lBox As ListBox, ByVal sPath As String)

        Dim i As Integer
        Dim ItemsAreSelected As Boolean

        ItemsAreSelected = False

        For i = 0 To CShort(lBox.Items.Count - 1)
            If lBox.GetSelected(i) = True Then
                ItemsAreSelected = True
            End If
        Next i

        If ItemsAreSelected = True Then
            For i = 0 To CShort(lBox.Items.Count - 1)
                If lBox.GetSelected(i) = True Then
                    Shell("NOTEPAD.EXE " & sPath.CombinePath(UserInterface.GetListBoxText(lBox, i)), AppWinStyle.MaximizedFocus)
                End If
            Next i
        End If

    End Sub

#Region "FileOpenDialogs"


    Public Sub AddAndCopySelectedFiles(ByVal lBox As ListBox, ByVal sFileTypes As String, ByVal sDialogTitle As String, ByVal sTargetPath As String, Optional ByVal sDialogName As String = "")

        Try

            Dim Filenames() As String = AutoCADOpenMultiSelect(sTargetPath, sDialogTitle, sFileTypes, sDialogName)
            Dim sPathedFile As String
            Dim sFile As String

            If Not Filenames Is Nothing Then
                For Each sPathedFile In Filenames
                    sFile = Path.GetFileName(sPathedFile)

                    My.Computer.FileSystem.CopyFile(sPathedFile, sTargetPath.CombinePath(sFile), FileIO.UIOption.AllDialogs)

                    If Not lBox.Items.Contains(sFile) Then
                        lBox.Items.Add(sFile)
                    End If
                Next
                lBox.Sorted = True
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub


    ''' <summary>
    ''' Opens the AutoCAD file open dialog single select - allows user to pick a file then adds the file to the provided list box and copies it to the target path
    ''' </summary>
    ''' <param name="lBox"></param>
    ''' <param name="sFileTypes"></param>
    ''' <param name="sDialogTitle"></param>
    ''' <param name="sTargetPath"></param>
    ''' <param name="sDialogName"></param>
    ''' <param name="sfile"></param>
    ''' <param name="bEditFile"></param>
    ''' <remarks></remarks>
    Public Sub AddAndCopySelectedFile(ByVal lBox As ListBox, ByVal sFileTypes As String, ByVal sDialogTitle As String, ByVal sTargetPath As String, Optional ByVal sDialogName As String = "", Optional ByVal sfile As String = "Client", Optional ByVal bEditFile As Boolean = False)

        Try
            Dim Filename As String = AutoCADOpenSingleSelect(sTargetPath, sDialogTitle, sFileTypes, sDialogName)

            If Not Filename Is Nothing Then
                ' GetConfigSettings()
                If Not ConfigurationLevel Is Nothing Then
                    sfile = ConfigurationLevel
                End If
                sfile = sfile & Path.GetExtension(Filename)
                My.Computer.FileSystem.CopyFile(Filename, sTargetPath.CombinePath(sfile), FileIO.UIOption.AllDialogs)
                If Not lBox.Items.Contains(sfile) Then
                    lBox.Items.Add(sfile)
                End If
                lBox.Sorted = True

                If bEditFile = True Then
                    ' open notepad with file
                    If Acad_MessageBox("A basic " & sfile & " file has been created with default link names." & vbCr &
                              "Do you wish to edit the file now ?", "Edit File Now", MessageBoxButtons.YesNo, , , , , , logName) = DialogResult.Yes Then
                        Shell("NOTEPAD.EXE " & sTargetPath.CombinePath(sfile), AppWinStyle.MaximizedFocus)
                    End If
                End If

            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    ''' <summary>
    ''' Opens the AutoCAD file open dialog enabling multi select - allows user to pick some files then adds the files to the provided list box
    ''' These now work as desined thanks to Stephan - he found that we needed to include DefaultFolder as well as ForceDefault folder in the flags
    ''' </summary>
    ''' <param name="lBox"></param>
    ''' <param name="sFileTypes"></param>
    ''' <param name="sDialogTitle"></param>
    ''' <param name="sTargetPath"></param>
    ''' <param name="sDialogName"></param>
    ''' <remarks></remarks>
    Public Sub AddSelectedFilesToListBox(ByVal lBox As ListBox, ByVal sFileTypes As String, ByVal sDialogTitle As String, ByVal sTargetPath As String, Optional ByVal sDialogName As String = "")
        Try
            Dim Filenames() As String = AutoCADOpenMultiSelect(sTargetPath, sDialogTitle, sFileTypes, sDialogName)

            Dim sPathedFile As String
            Dim sFile As String

            If Not Filenames Is Nothing Then
                For Each sPathedFile In Filenames
                    sFile = Path.GetFileName(sPathedFile)
                    If Not lBox.Items.Contains(sPathedFile) Then
                        lBox.Items.Add(sPathedFile)
                    End If
                Next
                lBox.Sorted = True
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    ''' <summary>
    ''' These now work as desined thanks to Stephan - he found that we needed to include DefaultFolder as well as ForceDefault folder in the flags
    ''' </summary>
    ''' <param name="sPath"></param>
    ''' <param name="sTitle"></param>
    ''' <param name="sTypes"></param>
    ''' <param name="sDialogName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function AutoCADOpenMultiSelect(ByVal sPath As String, Optional ByVal sTitle As String = "", Optional ByVal sTypes As String = "dwg; dwf; *", Optional ByVal sDialogName As String = "") As String()
        Try
            Dim flags As Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags = Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.AllowMultiple _
                                                                                       Or Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.DoNotTransferRemoteFiles _
                                                                                       Or Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.DefaultIsFolder _
                                                                                       Or Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.ForceDefaultFolder
            If System.IO.Directory.Exists(sPath) = False Then
                sPath = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            End If
            Dim ofd As New Autodesk.AutoCAD.Windows.OpenFileDialog(sTitle, sPath, sTypes, sDialogName, flags)
            Dim dr As System.Windows.Forms.DialogResult = ofd.ShowDialog()
            If dr = System.Windows.Forms.DialogResult.OK Then
                Dim Filenames() As String = ofd.GetFilenames

                If Filenames.Length > 0 Then
                    Return ofd.GetFilenames()
                Else
                    Return Nothing
                End If
            Else
                Return Nothing
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    ''' <summary>
    ''' These now work as desined thanks to Stephan - he found that we needed to include DefaultFolder as well as ForceDefault folder in the flags
    ''' </summary>
    ''' <param name="sPath"></param>
    ''' <param name="sTitle"></param>
    ''' <param name="sTypes"></param>
    ''' <param name="sDialogName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function AutoCADOpenSingleSelect(ByVal sPath As String, Optional ByVal sTitle As String = "", Optional ByVal sTypes As String = "dwg; dwf; *", Optional ByVal sDialogName As String = "") As String
        Try
            Dim flags As Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags = Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.DoNotTransferRemoteFiles _
                                                                                       Or Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.DefaultIsFolder _
                                                                                       Or Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.ForceDefaultFolder
            If System.IO.Directory.Exists(sPath) = False Then
                sPath = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            End If
            Dim ofd As New Autodesk.AutoCAD.Windows.OpenFileDialog(sTitle, sPath, sTypes, "SelectFileTest", flags)
            Dim dr As System.Windows.Forms.DialogResult = ofd.ShowDialog()
            If dr = System.Windows.Forms.DialogResult.OK Then
                Return ofd.Filename
            Else
                Return Nothing
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            '                System.Environment.CurrentDirectory = current
            Return Nothing
        End Try


    End Function

    ''' <summary>
    ''' THE NEW WAYS BELOW - TO INVESTIGATE - cannot get any of tehse to open in designated location
    ''' </summary>
    ''' <param name="sPath"></param>
    ''' <param name="sTitle"></param>
    ''' <param name="sTypes"></param>
    ''' <param name="sDialogName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DocumentOpenSingleSelect(ByVal sPath As String, Optional ByVal sTitle As String = "", Optional ByVal sTypes As String = "Drawings (*.dwg;*.dwf)|*.dwg;*.dxf", Optional ByVal sDialogName As String = "") As String
        Try
            If System.IO.Directory.Exists(sPath) = False Then
                sPath = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            End If

            Dim ofd As New OpenFileDialog()
            ofd.InitialDirectory = sPath
            ofd.Filter = sTypes ' & " files (" & sTypes & ")|" & sTypes
            ofd.FilterIndex = 1
            ofd.RestoreDirectory = True
            ofd.Title = sTitle

            Dim dr As System.Windows.Forms.DialogResult = ofd.ShowDialog()

            If dr = System.Windows.Forms.DialogResult.OK Then
                Return ofd.FileName
            Else
                Return Nothing
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

#End Region

    ''' <summary>
    ''' Used by initialising functions to populate list boxes on form load
    ''' </summary>
    ''' <param name="lbox"></param>
    ''' <param name="sPath"></param>
    ''' <param name="FileFilter"></param>
    ''' <remarks></remarks>
    Public Sub PopulateListBoxWithFilesInFolder(ByVal lbox As ListBox, ByVal sPath As String, Optional ByVal FileFilter As String = ".DWT", Optional ByVal recursive As Boolean = True)
        Dim cDirectoryEntries As Collection = New Collection

        lbox.Items.Clear()
        GetDirectoryFiles(sPath, cDirectoryEntries, recursive)

        For Each sFile As String In cDirectoryEntries
            '                If System.IO.Path.GetExtension(sFile).ToUpper.Contains(FileFilter.ToUpper) Then

            If System.IO.Path.GetExtension(sFile).ToUpper Like FileFilter.ToUpper Then

                If Not lbox.Items.Contains(Path.GetFileName(sFile)) Then
                    lbox.Items.Add(Path.GetFileName(sFile))
                End If
            End If

        Next
        lbox.Sorted = True
    End Sub



    ''' <summary>
    ''' Works out if this AutoCAD app is running in 64 bit mode
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property is64bits() As Boolean

        Get
            Return (ThisDrawingUtilities.GetVariable("PLATFORM").ToString().IndexOf("64") > 0)
        End Get
    End Property

#Region "GetPlotStyle"

    <DllImport("Acad.exe", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedPlotstyleDialog@@YA_NPB_W_NAAPA_W@Z")>
    Public Function acedPlotstyleDialog_2010x86(
          ByVal curPS As String, ByVal includeByLayerByBlock As Boolean, ByRef selectedPS As IntPtr) As Boolean
    End Function

    Public Function GetPlotStyle() As String

        Dim name As IntPtr
        Dim ret As Boolean
        If Not is64bits Then
            ret = acedPlotstyleDialog_2010x86("", True, name)
        Else
            ' call 64 bit version
        End If

        If name = IntPtr.Zero Then
            Return ""
        End If

        Return Marshal.PtrToStringUni(name)
    End Function

#End Region

#Region "GetLineType"

    <DllImport("Acad.exe", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedLinetypeDialog@@YA_NVAcDbObjectId@@_NAAPA_WAAV1@@Z")>
    Public Function acedLinetypeDialog_2010x86(ByVal curLT As ObjectId, ByVal includeByLayerByBlock As Boolean, ByRef selectedLTname As IntPtr, ByRef selectedLTid As ObjectId) As Boolean

    End Function

    Public Function GetLineType() As String

        Dim id As New ObjectId()
        Dim name As IntPtr

        Dim ret As Boolean
        If Not is64bits Then
            ret = acedLinetypeDialog_2010x86(id, True, name, id)
        Else
            ' call 64 bit version 
        End If

        If name = IntPtr.Zero Then
            Return ""
        End If

        Return Marshal.PtrToStringUni(name)
    End Function

#End Region

#Region "GetLineWeight"

    <DllImport("Acad.exe", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedLineWeightDialog@@YA_NW4LineWeight@AcDb@@_NAAW412@@Z")>
    Public Function acedLineWeightDialog_2010x86(
          ByVal curLW As LineWeight, ByVal includeByLayerByBlock As Boolean, ByRef selectedLW As LineWeight) As Boolean
    End Function

    Public Function GetLineWeight() As String
        Dim lw As LineWeight = CType(-5, LineWeight) ' use something that does not exist to see if it gets set

        Dim ret As Boolean
        If Not is64bits Then
            ret = acedLineWeightDialog_2010x86(Nothing, True, lw)
        Else
            ' call 64 bit version 
        End If

        If lw = -5 Then
            Return ""
        End If

        Return [Enum].GetName(GetType(LineWeight), lw)
    End Function

#End Region

#Region "GetColor"


    Public Function getcolor() As String
        Dim dlg As New Autodesk.AutoCAD.Windows.ColorDialog()
        'Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(dlg)
        dlg.ShowDialog()
        getcolor = dlg.Color().ToString()
    End Function

#End Region

    ''' <summary>
    ''' If not all tools are to be configured it checks if the named tool needs to be configured.
    ''' </summary>
    ''' <param name="sAssemblyName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function MustBeConfigured(ByVal sAssemblyName As String) As Boolean

        If File.Exists(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.MustBeConfiguredFileName)) Then
            Dim aFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.MustBeConfiguredFileName))
            For Each Str As String In aFileRead
                If Str.ToUpper = sAssemblyName.ToUpper Then
                    Return True
                End If
            Next
        Else
            Acad_MessageBox("Missing file: " & Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.MustBeConfiguredFileName), "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
        Return False

    End Function

    ''' <summary>
    ''' Tools can be told that they require a configured drawing to work on - this chesks if the nominated tool is one of those.
    ''' </summary>
    ''' <param name="sAssemblyName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function IsTemplateAssociatedDrawingRequired(ByVal sAssemblyName As String) As Boolean
        Try
            If MustBeConfigured(sAssemblyName.Replace(".dll", "")) Then
                If Not ThisDrawingIsConfigured() = True Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If

        Catch ex As System.Exception
            Return False
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Function

    ''' <summary>
    ''' Equivalent of visual lisps VLAX-PRODUCT-KEY 
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function VB_Product_Key() As String
        ' Used to be this one
        'Return Autodesk.AutoCAD.Runtime.SystemObjects.DynamicLinker.ProductKey
        ' 2013 changed it to one of these not sure which one ...
        'Return Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.MachineRegistryProductRootKey
        Return Replace(Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.Current.UserRegistryProductRootKey, " - English", "")
    End Function

    ''' <summary>
    ''' Returns the currently running version of AutoCAD for example "AutoCAD 2017"
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetAcadProductName(ByVal key As String) As String

        Return Replace(RegistryRead("HKLM", VB_Product_Key(), "ProductName"), " - English", "")

    End Function

    ''' <summary>
    ''' Get current running install path
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InstallPath(ByVal key As String) As String
        Return RegistryRead("HKLM", VB_Product_Key(), "AcadLocation")
        ' "Software\\Autodesk\\AutoCAD\\R21.0\\Acad-0001:409"

    End Function

    ''' <summary>
    ''' Get Acad Short Name
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetProdShortName(ByVal key As String) As String
        Dim Result As String = String.Empty

        If VB_Product_Key.Contains("Acad-0000") Then
            Result = "C3D"
        End If
        If VB_Product_Key.Contains("Acad-0001") Then
            Result = "Acad"
        End If
        If VB_Product_Key.Contains("Acad-0002") Then
            Result = "MAP"
        End If

        Return Result

        ' "Software\\Autodesk\\AutoCAD\\R21.0\\Acad-0001:409"

    End Function


    ' ''' <summary>
    ' ''' Get current AutoCAD Version
    ' ''' </summary>
    ' ''' <remarks></remarks>
    'Private Function cAcadVersion(k) As String

    '    Return RegistryRead("HKLM", VB_Product_Key(), "Release").Substring(0, 4)

    'End Function

    ''' <summary>
    ''' Get current AutoCAD Registry Hive
    ''' </summary>
    ''' <remarks></remarks>
    Private Function AcadRegKey(ByVal key As String) As String
        Return VB_Product_Key()
    End Function


    '  "T:\1308.2\StevenHo\Drawing Register.dwg"
    ' IsFileOpen return True if the file is open and false if it's not open
    Public Function IsFileOpen(ByVal FileNameAndPath As String) As Boolean

        '   Return False

        Try
            If System.IO.File.Exists(FileNameAndPath) Then
                Dim fs As New FileStream(FileNameAndPath, FileMode.Open, FileAccess.Read, FileShare.None)
                fs.Close()
            End If
            Return False
        Catch ex As System.Exception
            Return True
        End Try
    End Function


    ''' <summary>
    ''' 
    ''' 
    ''' It can get called from the OK button on the SCALE dialog 
    ''' 
    ''' Or it could be called from an event such as these where the values need to be derived
    ''' 
    ''' 
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ChangeScaleSysVars()

        Try


            If WhichSpace() = "FloatingModelSpace" Then
                If ThisDrawingUtilities.ActivePViewport.DisplayLocked = False Then

                    Acad_MessageBox("Scale" & " Tool - Has set " & "INSUNITS, LTSCALE, PSLTSCALE" & " to: " & "Not changed due to unlocked viewport.", , , , , , , True, logName)

                    Exit Sub
                End If
            End If

            Dim iInsunits As Integer
            Dim dLTScale As Double
            'Dim iPSLTScale As Integer
            Dim sLTScaleCompensator As String
            Dim bRegen As Boolean = False
            Dim Scale As String

            Dim SearchForContent As Boolean = True
            If IsMasterFile() = True Then
                SearchForContent = False
            End If

            'If IsThisAnOldConfigName() = True Then
            '    InitializeRules("[Scale]", True, SearchForContent, False)
            'Else
            InitializeRulesNew("[Scale]", True, SearchForContent, False)
            'End If

            ' Work out if the Scale tool rule "Client Config" allows the user to make changes.
            Dim bIgnoreOverrides As Boolean = WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "False").ToString.IsTrue

            Select Case WhichSpace()

                Case "PaperSpace"

                    '' When called and user is in Paper Space
                    '' This would not happen when called from Scale Dialog but may happen 
                    '' When called from an event

                    ' Assumption is made that paperspace will always be in MM
                    ' So INSUNITS = 4,  PSLTSCALE = 1 and dLTScale = 1

                    iInsunits = 4
                    dLTScale = 1.0#
                    'iPSLTScale = 1

                Case Else

                    ' Need to work out INSUNITS first so we get correct value 
                    ' Get the insunits value from the rule
                    iInsunits = InsunitsStrToInsunitsVal(RuleAccessors.GetruleValue("SCALE12", "Millimeters", bIgnoreOverrides, True))

                    ' Work out what LTSCALE should be based on the INSUNITS sytem variable and the Scale being used then
                    sLTScaleCompensator = RuleAccessors.GetruleValue("SCALE6", "1.0", bIgnoreOverrides, True)
                    Scale = RuleAccessors.GetruleValue("SCALE1", "1:1", bIgnoreOverrides, True)
                    dLTScale = CalculateNewLTScale(Scale, InsunitsToStr(iInsunits), sLTScaleCompensator)

                    '' Check as this one could be stored as 1 or 0 or True or False
                    'If RuleAccessors.GetruleValue("SCALE13", "1", bIgnoreOverrides, True).ToString.IsTrue Then
                    '    iPSLTScale = 1
                    'Else
                    '    iPSLTScale = 0
                    'End If

            End Select

            ' I have added a check to see if the tickboxes for change system variables when switching space and switching viewports are BOTH OFF
            ' no to do any variable changes. However if one of these is one it will as I can't work out at this point what has triggered this function
            ' call. Note that this function gets called on start up as well.
            ' Is the tickbox selected to say that we want to change sysvars when switching vieports
            If RuleAccessors.GetruleValue("SCALE14", "True", bIgnoreOverrides, True).ToString.IsTrue = False And
               RuleAccessors.GetruleValue("SCALE3", "True", bIgnoreOverrides, True).ToString.IsTrue = False Then

                ' Both are unticked
                Acad_MessageBox("Scale Tool has been configured not to change system variables - INSUNITS,LTSCALE and PSLTSCALE.", , , , , , , True, logName)
                Exit Sub

            End If

            ' Set INSUNITS if it's not what we expect it to be
            If CInt(ThisDrawingUtilities.GetVariable("INSUNITS")) <> iInsunits Then
                ThisDrawingUtilities.SetVariable("INSUNITS", iInsunits)
                Acad_MessageBox("Scale Tool has set INSUNITS to " & CStr(iInsunits), , , , , , , True, logName)
                bRegen = True
            End If

            ' Set LTSCALE if it's not what we expect it to be
            If CDbl(ThisDrawingUtilities.GetVariable("LTSCALE")) <> dLTScale Then
                ThisDrawingUtilities.SetVariable("LTSCALE", dLTScale)
                bRegen = True
            End If

            ' User wants us to manage PSLTSCLE 
            If RuleAccessors.GetruleValue("SCALE13", "1", bIgnoreOverrides, True).ToString.IsTrue() Then
                ' Se we always set it to 1
                If CInt(ThisDrawingUtilities.GetVariable("PSLTSCALE")) <> 1 Then
                    ThisDrawingUtilities.SetVariable("PSLTSCALE", 1)
                    Acad_MessageBox("Scale Tool has set PSLTSCALE to 1", , , , , , , True, logName)
                    bRegen = True
                End If
            End If


            ' If we canged PSLTScale we need to call a regen of all the active viewports.
            If bRegen = True And CInt(ThisDrawingUtilities.GetVariable("REGENMODE")) = 1 Then
                ThisDrawingUtilities.Regen(Autodesk.AutoCAD.Interop.Common.AcRegenType.acAllViewports)
            End If

        Catch ex As System.Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

    End Sub

    ''' <summary>
    ''' Calculates the new DIMSCALE 
    ''' Based on Scale, Insunits and the current space
    ''' </summary>
    ''' <remarks></remarks>
    Public Function CalculateTextScale(ByVal Scale As String, ByVal newInsunits As String) As Double

        Dim DecimalScale As Double
        Dim newDimScale As Double

        ' Conver the Ratio to a decimal so that it can be used to calculate required LTSCALE and DIMSCALE values
        DecimalScale = RatioToDecimal(Scale)

        ' Work out the conversion factor for the units selected in the InsUnits list box
        Dim Convfactor As Double = InsunitsToMMScaleFactor(InsunitsStrToInsunitsVal(newInsunits))

        ' Work out which space we are in at the moment
        Select Case WhichSpace()

            Case "PaperSpace"

                '' Are we using Annotative Dimensions - more testing required here...

                If CInt(ThisDrawingUtilities.GetVariable("DIMANNO")) = 1 Then
                    Return 0.0#
                Else
                    ' Paperspace DIMSCALE is always 1.0#
                    Return 1.0#
                End If

            Case "FloatingModelSpace"

                newDimScale = (1.0# * Convfactor)

            Case "ModelSpace"

                If newInsunits <> "Millimeters" Then
                    newDimScale = (1.0# / Val(DecimalScale) / Convfactor)
                Else
                    newDimScale = (1.0# / Val(DecimalScale))
                End If

        End Select

        Return newDimScale

    End Function


    Public Function CalculateNewDimScaleDec(ByVal DecimalScale As Double) As Double

        Dim newDimScale As Double

        ' Work out the conversion factor for the units selected in the InsUnits list box
        Dim Convfactor As Double = InsunitsToMMScaleFactor(CInt(ThisDrawingUtilities.GetVariable("INSUNITS")))

        ' Work out which space we are in at the moment
        Select Case WhichSpace()

            Case "PaperSpace"

                '' Are we using Annotative Dimensions - more testing required here...

                If CInt(ThisDrawingUtilities.GetVariable("DIMANNO")) = 1 Then
                    Return 0.0#
                Else
                    ' Paperspace DIMSCALE is always 1.0#
                    Return 1.0#
                End If

            Case "FloatingModelSpace"

                newDimScale = (1.0# * Convfactor)

            Case "ModelSpace"

                If CInt(ThisDrawingUtilities.GetVariable("INSUNITS")) <> 4 Then
                    newDimScale = (1.0# / Val(DecimalScale) / Convfactor)
                Else
                    newDimScale = (1.0# / Val(DecimalScale))
                End If

        End Select

        Return newDimScale

    End Function

    ''' <summary>
    ''' Calculates the new TEXTSIZE
    ''' Based on Scale, Insunits and the current space
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CalculateNewTextSize(Optional ByVal dTextSize As Double = 0.0#) As Double

        Dim DScale As Double = GetScale()

        ' If text size was not provided then get the TextSize specified by the Text Tool Rule TEXT2 which contains desired text size or the override if set.
        Dim bIgnoreTXTOverrides As Boolean = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").ToString.IsTrue

        ' Work out the conversion factor for the units selected in the InsUnits list box
        Dim Convfactor As Double = InsunitsToMMScaleFactor()

        ' Work out which space we are in at the moment so we can return what the correct TEXTSIZE should be
        Select Case WhichSpace()
            Case "PaperSpace"
                ' Assumption is made that paperspace will always be in 1:1 MM
                If dTextSize = 0.0# Then
                    dTextSize = CDbl(RuleAccessors.GetruleValue("TEXT2", ThisDrawingUtilities.GetVariable("TEXTSIZE").ToString, bIgnoreTXTOverrides, True))
                End If

            Case "FloatingModelSpace"
                ' Work out text height by getting the rule value and dividing it by Viewport Scale ?
                DScale = Math.Round(ThisDrawingUtilities.ActivePViewport.CustomScale, 6)
                If dTextSize = 0.0# Then
                    dTextSize = Val(RuleAccessors.GetruleValue("TEXT2", ThisDrawingUtilities.GetVariable("TEXTSIZE").ToString, bIgnoreTXTOverrides, True)) / DScale
                Else
                    ' When called from a button we know the text size to use
                    dTextSize = dTextSize / DScale
                End If

            Case ("ModelSpace")

                ' Work out text height by getting the rule value and dividing it by dimscale
                If dTextSize = 0.0# Then
                    dTextSize = CDbl(RuleAccessors.GetruleValue("TEXT2", ThisDrawingUtilities.GetVariable("TEXTSIZE").ToString, bIgnoreTXTOverrides, True)) / DScale
                Else
                    dTextSize = dTextSize / DScale
                End If

        End Select

        Return dTextSize


    End Function

    ''' <summary>
    ''' Calculates the new LTSCALE 
    ''' Based on Scale, Insunits, LTScaleCompensator and the current space
    ''' </summary>
    ''' <remarks></remarks>
    Public Function CalculateNewLTScale(ByVal Scale As String, ByVal newInsunits As String, ByVal LTScaleCompensator As String) As Double

        Dim DecimalScale As Double
        Dim newLTScale As Double

        ' Conver the Ratio to a decimal so that it can be used to calculate required LTSCALE and DIMSCALE values
        DecimalScale = RatioToDecimal(Scale)

        ' Work out the conversion factor for the units selected in the InsUnits list box
        Dim Convfactor As Double = InsunitsToMMScaleFactor(InsunitsStrToInsunitsVal(newInsunits))

        ' Work out which space we are in at the moment
        Select Case WhichSpace()

            Case "PaperSpace"

                ' Paperspace DIMSCALE is always 1.0#
                Return 1.0#


            Case "FloatingModelSpace"
                ' Use LTSCALE to get the viewport scale manage this for us
                newLTScale = (1.0# * Val(LTScaleCompensator))

            Case ("ModelSpace")
                If newInsunits <> "Millimeters" Then
                    newLTScale = (Val(LTScaleCompensator) / Val(DecimalScale) / Convfactor)
                Else
                    newLTScale = (Val(LTScaleCompensator) / Val(DecimalScale))
                End If

        End Select

        Return newLTScale

    End Function

    ''' <summary>
    ''' Function to display the Scale and Configuration name using the MODEMACRO environment variable.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateModeMacro()

        Dim sFullConfigName As String = RuleAccessors.GetruleValue("FULLCONFIGNAME", , False, True)

        Dim sUnits As String = String.Empty

        If InsunitsToStr() <> "Millimeters" Then
            sUnits = " " & InsunitsToStr()
        End If

        Dim dscale As Double = GetScale()
        Dim sScale As String = DecimalToRatio(1 / InsunitsToMMScaleFactor() * dscale, "-")

        ' = RuleAccessors.GetruleValue("SCALE1")
        ' Mode macro can't depend on SCALE1 because SCALE1 rule is not the true DimScale value but merely the one that was selected in the Scale Dialog box.


        ThisDrawingUtilities.SetVariable("MODEMACRO", "Scale: " & sScale & sUnits & " " & sFullConfigName)

    End Sub

    ''' <summary>
    ''' 
    ''' It can get called from the OK button on the SCALE dialog 
    ''' It can get called from the OK button on the TEXTOPTIONS dialog 
    ''' 
    ''' Or it could be called from an event such as these where the values need to be derived
    ''' 
    ''' 
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ChangeTextSysVars()

        Try

            If WhichSpace() = "FloatingModelSpace" Then
                If ThisDrawingUtilities.ActivePViewport.DisplayLocked = False Then
                    Acad_MessageBox("Text tool has set TEXTSIZE not to change due to a locked viewport", , , , , , , True, logName)
                    Exit Sub
                End If
            End If

            Dim SearchForContent As Boolean = True
            If IsMasterFile() = True Then
                SearchForContent = False
            End If

            ' Initialize the Rules for this tool
            'If IsThisAnOldConfigName() = True Then
            '    InitializeRules("[Text]", True, SearchForContent, False)
            'Else
            InitializeRulesNew("[Text]", True, SearchForContent, False)
            'End If

            Dim dTextSize As Double = CalculateNewTextSize()

            ' call. Note that this function gets called on start up as well.
            ' Is the tickbox selected to say that we want to change sysvars when switching vieports
            If RuleAccessors.GetruleValue("TEXT23", "True", False, True).ToString.IsTrue = False And
               RuleAccessors.GetruleValue("TEXT27", "True", False, True).ToString.IsTrue = False Then

                ' Both are unticked
                Acad_MessageBox("Text tool has been set to not change the TEXTSIZE system variable", , , , , , , True, logName)
                Exit Sub

            End If


            ' Set TEXTSIZE if it's not what we expect it to be
            If CDbl(ThisDrawingUtilities.GetVariable("TEXTSIZE")) <> dTextSize Then
                ThisDrawingUtilities.SetVariable("TEXTSIZE", dTextSize)
                Acad_MessageBox("The text tool has set TEXTSIZE to " & CStr(dTextSize), , , , , , , True, logName)
            End If

        Catch ex As System.Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub


    ''' <summary>
    '''     
    ''' 
    ''' It can get called from the OK button on the SCALE dialog 
    ''' It can get called from the OK button on the DIMENSIONS dialog 
    ''' 
    ''' Or it could be called from an event such as these where the values need to be derived
    ''' 
    ''' 
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ChangeDimensionSysVars()

        Try

            If WhichSpace() = "FloatingModelSpace" Then
                If ThisDrawingUtilities.ActivePViewport.DisplayLocked = False Then
                    Acad_MessageBox("The Dimensions tool has been set not to change DIMSTYLE, DIMSCALE, DIMASSOC variables.", , , , , , , True, logName)
                    Exit Sub
                End If
            End If


            Dim bIgnoreOverrides As Boolean
            Dim dscale As Double
            Dim NewDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle = Nothing
            Dim CurrDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle
            Dim sNewDimStyleName As String
            Dim sCurrDimStyle As String
            Dim bUseFloatingModelSpaceDims As Boolean
            Dim bUseDIMSCALEVariable As Boolean
            Dim dPstdscale As Double
            Dim sPstdstyle As String
            Dim DimAssoc As Short

            Dim SearchForContent As Boolean = True
            If IsMasterFile() = True Then
                SearchForContent = False
            End If

            ' Initialize the Rules for this tool
            'If IsThisAnOldConfigName() = True Then
            '    InitializeRules("[Dimensions]", True, SearchForContent, False)
            'Else
            InitializeRulesNew("[Dimensions]", True, SearchForContent, False)
            'End If


            ' Record the old dimscale & dimstyle so we can check at the end if they have changed
            dPstdscale = CDbl(ThisDrawingUtilities.GetVariable("DIMSCALE"))
            sPstdstyle = CStr(ThisDrawingUtilities.GetVariable("DIMSTYLE"))

            ' Check to see if we need to look for Rules or workvar overrides
            bIgnoreOverrides = WorkingVariableAccessors.GetWorkVarValue("DIMENSIONSClientConfig", "False").IsTrue


            ' Is the tickbox selected to say that we want to change sysvars when switching vieports
            If RuleAccessors.GetruleValue("DIM6", "True", bIgnoreOverrides, True).ToString.IsTrue = False And
               RuleAccessors.GetruleValue("DIM8", "True", bIgnoreOverrides, True).ToString.IsTrue = False Then

                ' Both are unticked
                Acad_MessageBox("Dimensions Tool has been configured not to change system variables - DIMSTYLE, DIMASSOC, DIMANNO, DIMSCALE, MODEMACRO.", , , , , , , True, logName)
                Exit Sub


            End If


            'Dim arrrulenf() As Object = Nothing
            'Dim j As Integer

            ' Work out if the user wishes to use FMS Dims
            ' By ticking FMS or Floatim Model Space dimensions th user wishes to let the Scale of the Viewport (or Active Viewport Custom Scale) determine 
            ' The scale of the Dimension Styles in this scenario DIMSCALE gets set to 0 which shows up as "Scale Dimesions to Layout" in the Fit tab of the dim Style.
            ' Determines a scale factor based on the scaling between the current model space viewport and paper space
            bUseFloatingModelSpaceDims = RuleAccessors.GetruleValue("DIM4", "False", bIgnoreOverrides, True).IsTrue

            ' RuleSearch to import the Default DIMSTYLE based on the rule if not present Also make it current

            Dim DimensionRule As Rule = Nothing
            'If IsThisAnOldConfigName() = True Then
            '    DimensionRule = RuleSearch("DIM5", ThisDrawingUtilities.GetVariable("DIMSTYLE").ToString, True, False, bIgnoreOverrides, True, True)
            'Else
            DimensionRule = RuleSearchNew("DIM5", ThisDrawingUtilities.GetVariable("DIMSTYLE").ToString, True, False, bIgnoreOverrides, True, True)
            'End If


            sCurrDimStyle = DimensionRule.value

            ' Work out if the user wishes to use one dimstyle by using the DIMSCALE variable.. else they wish to create multiple dim styles
            bUseDIMSCALEVariable = RuleAccessors.GetruleValue("DIM3", "True", bIgnoreOverrides, True).IsTrue

            ' Work out the current scale  (returning 0.5) when Meters?
            dscale = GetScale()


            ' Based on FMS MS or PS WORKOUT DIMSTYLE NAME TO USE
            If bUseFloatingModelSpaceDims = True Then
                ' This is when the dialog box has the use FMS ticked
                If DimStyleExist("*[1-FloatingVPScale]") = True Then
                    sNewDimStyleName = DimStyleFind("*[1-FloatingVPScale]")
                Else
                    sNewDimStyleName = sCurrDimStyle & " [1-FloatingVPScale]"
                End If
            Else
                ' Do we wish to use multiple dimension styles?
                If bUseDIMSCALEVariable = False Then
                    ' This is when we have Use system variable unticked
                    Dim sStyleNameToFind As String
                    If CInt(ThisDrawingUtilities.GetVariable("INSUNITS")) = 4 Then
                        sStyleNameToFind = " [" & DecimalToRatio(dscale, "-") & "]"
                    Else
                        If WhichSpace() = "ModelSpace" Then
                            'sStyleNameToFind = " [" & DecimalToRatio(dscale, "-") & "] " & " " & InsunitsToStr

                            ' Tested OK
                            sStyleNameToFind = " [" & DecimalToRatio(1 / InsunitsToMMScaleFactor() * dscale, "-") & "]" & " " & InsunitsToStr()
                        Else
                            ' Floating model space with use dimscale variable unticked...
                            sStyleNameToFind = " [" & DecimalToRatio(1 / InsunitsToMMScaleFactor() * dscale, "-") & "]" & " " & InsunitsToStr()
                        End If
                    End If

                    If DimStyleExist("*" & sStyleNameToFind) = True Then
                        sNewDimStyleName = DimStyleFind("*" & sStyleNameToFind)
                    Else
                        sNewDimStyleName = sCurrDimStyle & sStyleNameToFind
                    End If
                Else
                    ' This is when we use DIMSCALE to control system var overrides and only one dimscale is present
                    sNewDimStyleName = sCurrDimStyle
                End If
            End If

            ' CREATE OR SELECT THE DIMSTYLE
            ' If the dimension style we want exists
            If DimStyleExist(sNewDimStyleName) = True Then
                NewDimStyle = ThisDrawingUtilities.DimStyles.Item(sNewDimStyleName)
            Else
                ' Add a new Dimension Style
                NewDimStyle = ThisDrawingUtilities.DimStyles.Add(sNewDimStyleName)
                ' Capture the current dimstyle Settings
                sCurrDimStyle = ThisDrawingUtilities.GetVariable("DIMSTYLE").ToString
                CurrDimStyle = ThisDrawingUtilities.DimStyles.Item(sCurrDimStyle)


                ' Copy from the Current Dimension Style or the Default one into the new one
                NewDimStyle.CopyFrom(CurrDimStyle)


            End If

            If WhichSpace() = "FloatingModelSpace" Then

                If ThisDrawingUtilities.ActivePViewport.DisplayLocked = False Then
                    Acad_MessageBox("The DIMENSIONS tool has been set not to change DIMSTYLE  due to unlocked viewport.", , , , , , , True, logName)
                End If

            Else
                ' Make it Current
                ThisDrawingUtilities.ActiveDimStyle = NewDimStyle

                If sPstdstyle <> ThisDrawingUtilities.ActiveDimStyle.Name Then
                    Acad_MessageBox("The Dimensions tool has set DIMSTYLE to " & NewDimStyle.Name, , , , , , , True, logName)
                End If

                ' Can't think of any time when we would have DIMASSOC other than 2
                ' The world has changed and due to a bug in Pro Structures there are times when 
                ' Dim Assoc needs to be set to 1 - i.e. when using a structural detailing tool in PS
                DimAssoc = 2
                ' Set DIMASSOC if it's not what we expect it to be
                If CInt(ThisDrawingUtilities.GetVariable("DIMASSOC")) <> DimAssoc Then
                    Acad_MessageBox("If you are using Tran spatial Dimensioning and not using Pro Structures you should set DIMASSOC to 2 now.", , , , , , , True, logName)
                End If
            End If

            If bUseFloatingModelSpaceDims = True Then

                Try
                    If CInt(ThisDrawingUtilities.GetVariable("DIMANNO")) = 0 Then
                        ThisDrawingUtilities.SetVariable("DIMSCALE", 0.0#)
                        Acad_MessageBox("The Dimensions tool has set DIMSCALE to 0.0", , , , , , , True, logName)
                    Else
                        Acad_MessageBox("You are currently using an annotative dimension style - the Dimensions tool cannot set the DIMSCALE system variable", , , , , , , True, logName)
                    End If
                Catch

                End Try


                ' Appy the Acaddocument OVERRIDES to the dimension style
                NewDimStyle.CopyFrom(ThisDrawingUtilities.Application.ActiveDocument)


            Else

                dscale = GetScale()

                Select Case WhichSpace()

                    Case "ModelSpace"

                        If bUseDIMSCALEVariable = True Then
                            'dscale = 1 / dscale / InsunitsToMMScaleFactor
                            dscale = 1 / dscale
                        Else
                            ' Tested in MM setting scale tool to 1:100
                            dscale = 1 / dscale
                        End If

                    Case "PaperSpace"
                        dscale = 1.0#

                    Case "FloatingModelSpace"

                        ''                            dscale = ThisDrawingUtilities.ActivePViewport.CustomScale

                        If bUseDIMSCALEVariable = True Then
                            'dscale = 1 / dscale / InsunitsToMMScaleFactor
                            dscale = 1 / dscale
                        Else
                            ' Tested in MM setting scale tool to 1:100
                            dscale = 1 / dscale
                        End If

                        'If bUseDIMSCALEVariable = True Then
                        '    '        dscale = 1 / dscale / InsunitsToMMScaleFactor
                        '    dscale = 1 / dscale

                        'Else
                        '    ' Tested in MM 1:50 VP
                        '    dscale = 1 / dscale
                        'End If

                End Select

                Try
                    ' Set the dimscale override
                    If CInt(ThisDrawingUtilities.GetVariable("DIMANNO")) = 0 Then
                        If WhichSpace() = "FloatingModelSpace" Then
                            If ThisDrawingUtilities.ActivePViewport.DisplayLocked = False Then
                                Acad_MessageBox("The Dimensions tool has not changed DIMSCALE due to unlocked viewport.", , , , , , , True, logName)
                            Else

                                ThisDrawingUtilities.SetVariable("DIMSCALE", dscale)
                                If dscale <> dPstdscale Then
                                    Acad_MessageBox("The Dimensions tool has set DIMSCALE to: " & CStr(dscale), , , , , , , True, logName)
                                End If

                            End If
                        Else
                            ThisDrawingUtilities.SetVariable("DIMSCALE", dscale)
                            If dscale <> dPstdscale Then
                                Acad_MessageBox("The Dimensions tool has set DIMSCALE to: " & CStr(dscale), , , , , , , True, logName)
                            End If
                        End If
                    Else
                        Acad_MessageBox("You are currently using an annotative dimension style - the Scale tool cannot set the DIMSCALE system variable", , , , , , , True, logName)
                    End If
                Catch ex As System.Exception

                End Try

                ' Do we wish to use multiple dimension styles?
                If bUseDIMSCALEVariable = False Then
                    ' Apply the Acaddocument OVERRIDES to the dimension style
                    NewDimStyle.CopyFrom(ThisDrawingUtilities.Application.ActiveDocument)
                End If

            End If

            ' Display any chages to scale or units in the MODEMACRO system variable for users to see.
            UpdateModeMacro()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Public Function ReadCSVFile(ByRef SourceFile As String, ByRef sBlockName As String) As String
        Try
            Dim f_in As System.IO.StreamReader
            Dim aFileRead() As String
            Dim iCtr As Integer
            Dim ForReading As Integer
            Dim iFromLineNumber As Integer

            ReadCSVFile = "False"
            ForReading = 1

            If System.IO.File.Exists(SourceFile) Then
                If My.Computer.FileSystem.GetFileInfo(SourceFile).Length <> 0 Then
                    f_in = My.Computer.FileSystem.OpenTextFileReader(SourceFile)
                    aFileRead = Split(f_in.ReadToEnd, vbCrLf)
                    For iCtr = 0 To UBound(aFileRead) - 1
                        If (Trim(UCase(Split(aFileRead(iCtr), ",")(0))) = Trim(UCase(sBlockName))) Then
                            If iCtr >= iFromLineNumber Then
                                ReadCSVFile = aFileRead(iCtr)
                            End If
                        End If
                    Next
                End If
            End If
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return ""
        End Try
    End Function

    ''' <summary>
    ''' Check to see if the new config names are in use old config names have 5 sections new ones only have 4
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function IsThisAnOldConfigName() As Boolean

        If ThisDrawingIsConfigured() = True And IsMasterFile() = False Then
            If GetruleValue("FULLCONFIGNAME").Split("-"c).Length = 5 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function

    ''' <summary>
    ''' Check to see if this is a special content DWG file - either a CORPORATEMASTER or a CLIENTMASTER file which contains config data but does not
    ''' Need to be configured when opened - nor do we need to search for rules and content for them
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function IsMasterFile() As Boolean

        If ThisDrawingIsConfigured() = True Then

            If GetruleValue("FULLCONFIGNAME").ToUpper.Contains("GLOBAL-ALL-ALL-ALL") Then
                Return True
            Else
                Return False
            End If

        Else
            Return False
        End If

    End Function

    Function CheckConfigBuilders() As Boolean

        Dim Result As Boolean

        '' Get logged in user name and check if they are allowed to create configs.

        If File.Exists(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName)) Then

            Dim aFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName))
            For Each Str As String In aFileRead
                If Str.ToUpper = Manager.EvaluateExpression(Settings.Manager.UserName).ToUpper Then
                    Result = True
                    Exit For
                End If
            Next
        Else

            GeneralMessageBox("Error Missing File:" & Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName), System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Result = False
        End If

        Return Result

    End Function

    Public Sub CheckIfBuildingTemplateInProgress()

        If System.IO.File.Exists(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt")) Then

            Dim ConfigName As String = ReadTextFile(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt"))(0)
            Dim DwgName As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", ConfigName, "Settings", ConfigName & ".dwg")

            '  MsgBox(ConfigName & vbCrLf & DwgName & vbCrLf & ThisDrawingUtilities.FullName)

            If DwgName.ToUpper.Contains(ConfigName.ToUpper) Then
                If ThisDrawingUtilities.FullName.ToUpper = "" Then

                    ThisDrawingUtilities.SaveAs(DwgName, Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_dwg)

                End If

            End If

            ' MsgBox(ConfigName & vbCrLf & DwgName & vbCrLf & ThisDrawingUtilities.FullName)

            If ThisDrawingUtilities.FullName.ToUpper = DwgName.ToUpper Then

                'ThisDrawingUtilities.SendCommand("(command ""Jacobs_TemplateBuilder"")(command ""RIBBON"")")
                ThisDrawingUtilities.SendCommand("Jacobs_TemplateBuilder" & vbCr)

            End If
            ThisDrawingUtilities.SendCommand("Jacobs_TemplateBuilder" & vbCr)
        End If

    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_SaveTemplate", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub SaveTemplate()

        If ThisDrawingUtilities.Name.ToUpper.Contains(".DWG") Then

            MessageBox.Show("Jacobs_SaveTemplate command cannot be invoked from a DWG file." &
                            "Run the Jacobs_TemplateBuilder and press the finish button" &
                            "Nothing has been saved", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else

            Dim FileName As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", ThisDrawingUtilities.Name.ToUpper.Replace(".DWT", ""), "Settings", ThisDrawingUtilities.Name)


            Acad_MessageBox("Saving Template File on close: " & FileName)

            Dim originalValue As AcSaveAsType
            Dim AcadPref As Autodesk.AutoCAD.Interop.AcadPreferencesOpenSave = ThisDrawingUtilities.Application.Preferences.OpenSave

            ' Store current setting
            originalValue = AcadPref.SaveAsType

            AcadPref.SaveAsType = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_Template


            ' MsgBox("Saving As: " & FileName)


            ThisDrawingUtilities.SaveAs(FileName)
            AcadPref.SaveAsType = originalValue

        End If

    End Sub

    'Public Function SpaceTitle(Title As String) As String

    '    Dim NewTitle As String = Title
    '    Dim UpperCaseCharacters As Integer = 12
    '    Dim i As Integer
    '    Do While i < Title.Length

    '        If char(Title(i)) > UpperCaseCharacters Then
    '            If Char(title(i+1) < UpperCaseCharacters then
    '                ' Add a space
    '                NewTitle = NewTitle.Replace(Title(i) & Title(i + 1), Title(i) & " " & Title(i + 1))
    '            End If
    '        End If
    '        i = i + 1

    '    Loop


    '    Return NewTitle

    'End Function



    ''' <summary>
    ''' Removes - All rules based on the contents of the tools.ini file
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_REMOVERULES", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub RemoveAllRules()
        For i As Integer = 0 To UBound(ToolDetails)
            For Each Rule As String In ToolDetails(CInt(i)).Rules
                If RuleAccessors.HasRule(Rule.Split(","c)(0)) Then
                    RuleAccessors.RemoveRule(Rule.Split(","c)(0))
                End If
                If RuleAccessors.HasRule(Rule.Split(","c)(0) & "-DlgBox") Then
                    RuleAccessors.RemoveRule(Rule.Split(","c)(0) & "-DlgBox")
                End If
            Next
        Next
    End Sub

    ''' <summary>
    ''' Exports - All rules and workvars to a file in "C:\Users\Public\" folder with the name of the configuration which the drawing is 
    ''' The file has two sections a RULES SECTION and if working variables are present a WORKVARS SECTION
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_EXPORTRULES", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub ExportAllRules()

        Dim filename As String = "C:\Users\Public\" & RuleAccessors.GetruleValue("FULLCONFIGNAME") & "-AE Rules & WorkVars.txt"

        If ThisDrawingIsConfigured() Then
            WriteLineToTextFile(filename, "[RULES SECTION]", False)
            For Each Rule As Rule In RuleAccessors.GetAllRules
                WriteLineToTextFile(filename, Rule.RuleID & " - " & Rule.Description & " - " & Rule.value & " - " & Rule.DlgCode & " - " & Rule.TableCode, True)
            Next

            WriteLineToTextFile(filename, "[WORKVARS SECTION]", True)
            If WorkingVariableAccessors.WorkVarCount > 0 Then
                For Each workvar As WorkVars In WorkingVariableAccessors.GetAllWorkVars
                    WriteLineToTextFile(filename, workvar.Name & " - " & workvar.value.ToString, True)
                Next
            Else
                WriteLineToTextFile(filename, "No WorkVars present to export", True)
            End If

        Else
            Acad_MessageBox("This drawing is not configured", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    ''' <summary>
    ''' Rules and rule overrides that are not in the Tools.ini file but are nominated here will be removed
    ''' "WELD"
    ''' "DSS"
    ''' "SS"
    ''' "PID"
    ''' "ELECTRICAL"
    ''' "TESTCONFIG"
    ''' "LAYERCREATOR"
    ''' "MENU"
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_REMOVEOBSOLETERULES", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub RemoveObsoleteRules()

        If ThisDrawingIsConfigured() = True Then

            Dim ObsoleteToolNames As New Collection

            ObsoleteToolNames.Add("WELD")
            ObsoleteToolNames.Add("DSS")
            ObsoleteToolNames.Add("SS")
            ObsoleteToolNames.Add("PID")
            ObsoleteToolNames.Add("ELECTRICAL")

            For Each Tool As String In ObsoleteToolNames
                ' Go through the tool details list and get a pointer to the relevant tool
                For i As Integer = 0 To CShort(UBound(ToolDetails))
                    If UCase(ToolDetails(i).ToolName) = UCase("[" & Tool & "]") Then
                        '' Skip this one as it's now a valid tool
                        ' GeneralMessageBox("Skipping: " & Tool & " when removing obsolete rules", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, True)
                        Exit For
                    Else
                        ' GeneralMessageBox("Removing: " & Tool & " when removing obsolete rules", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , True, True)

                        '' Process this one and remove it and it's overrides
                        For j As Integer = 0 To 30
                            If RuleAccessors.HasRule(Tool & j) Then
                                RuleAccessors.RemoveRule(Tool & j)
                            End If
                            If RuleAccessors.HasRule(Tool & j & "-DlgBox") Then
                                RuleAccessors.RemoveRule(Tool & j & "-DlgBox")
                            End If
                        Next
                    End If
                Next
            Next

            Dim ObsoleteOneOffRules As New Collection

            ObsoleteToolNames.Add("TESTCONFIG")
            ObsoleteToolNames.Add("LAYERCREATOR")
            ObsoleteToolNames.Add("MENU")

            For Each tool As String In ObsoleteOneOffRules
                If RuleAccessors.HasRule(tool) Then
                    RuleAccessors.RemoveRule(tool)
                End If
            Next


        End If

    End Sub

    ''' <summary>
    ''' Prompts for tool name and remove all rules and rule overrides for that tool - does not remove workvars
    ''' May need to have the name of the tool in brackets - don't recall example:  [PID]
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_REMOVERULESBYTOOLNAME", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub RevomeRulesByToolName()

        Dim Tool As String = String.Empty
        Tool = InputBox("Enter Tool Name as seen in SnoopDB rule name: ", "Remove Rules and Overrides Via Tool Name", "")
        For i As Integer = 0 To 100
            If RuleAccessors.HasRule(Tool) Then
                RuleAccessors.RemoveRule(Tool)
            End If
            If RuleAccessors.HasRule(Tool & i) Then
                RuleAccessors.RemoveRule(Tool & i)
            End If
            If RuleAccessors.HasRule(Tool & i & "-DlgBox") Then
                RuleAccessors.RemoveRule(Tool & i & "-DlgBox")
            End If
        Next

    End Sub

    Public Sub SetSearchPath(ByRef sSearchPath As String, ByRef bTopOfList As Boolean)

        Try
            If System.IO.Directory.Exists(sSearchPath) = True Then

                Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences = ThisDrawingUtilities.Application.Preferences

                If InStr(preferences.Files.SupportPath, sSearchPath) = 0 Then
                    If bTopOfList = True Then
                        preferences.Files.SupportPath = sSearchPath & ";" & preferences.Files.SupportPath
                    Else
                        preferences.Files.SupportPath = preferences.Files.SupportPath & ";" & sSearchPath
                    End If
                End If

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

End Module


