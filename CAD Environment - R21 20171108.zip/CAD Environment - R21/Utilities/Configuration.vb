﻿Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Runtime
Imports System.Runtime.InteropServices 'for DllImport()
Imports System.Security
Imports System.Text.StringBuilder
Imports System.Reflection.Assembly
Imports Jacobs.Common.Settings
Imports Jacobs.Common.Core

Public Class Configuration

    ''' <summary>
    ''' Get the value from Jacobs.AE.Config
    ''' eg (setq a (Jacobsconfig "AE.ADSiteName"))
    ''' or (setq b (Jacobsconfig "AutoCAD.Name"))
    ''' </summary>
    ''' <param name="rbConfigPath"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <LispFunction("JacobsConfig")>
    Public Shared Function GetAEConfig(ByVal rbConfigPath As ResultBuffer) As String

        '' bail if no args
        Debug.WriteLine("rbConfigPath: " & rbConfigPath.ToString)
        If rbConfigPath Is Nothing Then
            Return Nothing
        End If

        '' must have one argument
        If rbConfigPath.AsArray.Length < 1 Then
            Return Nothing
        End If

        '' get path to search eg "AutoCAD.AcadProdNo"
        Dim configPath As String = CStr(rbConfigPath.AsArray(0).Value)
        Debug.WriteLine("ConfigPath: " & configPath.ToString)
        'MsgBox(configPath)
        'MsgBox(Settings.Manager)

        '' get the object value
        Dim result As Object = Properties.GetValue(configPath, Settings.Manager)
        If result Is Nothing Then
            Return Nothing
            Debug.WriteLine("Result Nothing")
        End If
        Debug.WriteLine("Result: " & result.ToString)
        '' convert to string
        Return result.ToString()

    End Function

End Class
