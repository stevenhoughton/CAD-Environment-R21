<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewTemplateSelectorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(NewTemplateSelectorForm))
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.Apply_Button = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.DisciplinesGroupBox = New System.Windows.Forms.GroupBox()
        Me.ExistingDisciplinesComboBox = New System.Windows.Forms.ListBox()
        Me.ClientGroupBox = New System.Windows.Forms.GroupBox()
        Me.ExistingClientsComboBox = New System.Windows.Forms.ListBox()
        Me.RegionGroupBox = New System.Windows.Forms.GroupBox()
        Me.ExistingRegionsComboBox = New System.Windows.Forms.ListBox()
        Me.CountryGroupBox = New System.Windows.Forms.GroupBox()
        Me.ExistingCountriesComboBox = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DisciplinesGroupBox.SuspendLayout()
        Me.ClientGroupBox.SuspendLayout()
        Me.RegionGroupBox.SuspendLayout()
        Me.CountryGroupBox.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnHelp
        '
        Me.btnHelp.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnHelp.Location = New System.Drawing.Point(11, 4)
        Me.btnHelp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(85, 32)
        Me.btnHelp.TabIndex = 19
        Me.btnHelp.Text = "&Help"
        '
        'Apply_Button
        '
        Me.Apply_Button.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Apply_Button.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Apply_Button.Enabled = False
        Me.Apply_Button.Location = New System.Drawing.Point(118, 4)
        Me.Apply_Button.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Apply_Button.Name = "Apply_Button"
        Me.Apply_Button.Size = New System.Drawing.Size(85, 32)
        Me.Apply_Button.TabIndex = 15
        Me.Apply_Button.Text = "OK"
        '
        'btnClose
        '
        Me.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClose.Location = New System.Drawing.Point(225, 4)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(85, 32)
        Me.btnClose.TabIndex = 16
        Me.btnClose.Text = "&Cancel"
        '
        'lblTitle
        '
        Me.lblTitle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(225, 35)
        Me.lblTitle.TabIndex = 24
        Me.lblTitle.Text = "Select Template"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 22
        Me.LogoPictureBox.TabStop = False
        '
        'DisciplinesGroupBox
        '
        Me.DisciplinesGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.DisciplinesGroupBox.Controls.Add(Me.ExistingDisciplinesComboBox)
        Me.DisciplinesGroupBox.Location = New System.Drawing.Point(865, 78)
        Me.DisciplinesGroupBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DisciplinesGroupBox.Name = "DisciplinesGroupBox"
        Me.DisciplinesGroupBox.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DisciplinesGroupBox.Size = New System.Drawing.Size(276, 239)
        Me.DisciplinesGroupBox.TabIndex = 50
        Me.DisciplinesGroupBox.TabStop = False
        Me.DisciplinesGroupBox.Text = "Disciplines"
        '
        'ExistingDisciplinesComboBox
        '
        Me.ExistingDisciplinesComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ExistingDisciplinesComboBox.FormattingEnabled = True
        Me.ExistingDisciplinesComboBox.ItemHeight = 16
        Me.ExistingDisciplinesComboBox.Location = New System.Drawing.Point(11, 23)
        Me.ExistingDisciplinesComboBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ExistingDisciplinesComboBox.Name = "ExistingDisciplinesComboBox"
        Me.ExistingDisciplinesComboBox.Size = New System.Drawing.Size(253, 196)
        Me.ExistingDisciplinesComboBox.TabIndex = 3
        '
        'ClientGroupBox
        '
        Me.ClientGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ClientGroupBox.Controls.Add(Me.ExistingClientsComboBox)
        Me.ClientGroupBox.Location = New System.Drawing.Point(581, 78)
        Me.ClientGroupBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ClientGroupBox.Name = "ClientGroupBox"
        Me.ClientGroupBox.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ClientGroupBox.Size = New System.Drawing.Size(276, 239)
        Me.ClientGroupBox.TabIndex = 49
        Me.ClientGroupBox.TabStop = False
        Me.ClientGroupBox.Text = "Client"
        '
        'ExistingClientsComboBox
        '
        Me.ExistingClientsComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ExistingClientsComboBox.FormattingEnabled = True
        Me.ExistingClientsComboBox.ItemHeight = 16
        Me.ExistingClientsComboBox.Location = New System.Drawing.Point(11, 23)
        Me.ExistingClientsComboBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ExistingClientsComboBox.Name = "ExistingClientsComboBox"
        Me.ExistingClientsComboBox.Size = New System.Drawing.Size(253, 196)
        Me.ExistingClientsComboBox.TabIndex = 2
        '
        'RegionGroupBox
        '
        Me.RegionGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RegionGroupBox.Controls.Add(Me.ExistingRegionsComboBox)
        Me.RegionGroupBox.Location = New System.Drawing.Point(297, 78)
        Me.RegionGroupBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RegionGroupBox.Name = "RegionGroupBox"
        Me.RegionGroupBox.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RegionGroupBox.Size = New System.Drawing.Size(276, 239)
        Me.RegionGroupBox.TabIndex = 48
        Me.RegionGroupBox.TabStop = False
        Me.RegionGroupBox.Text = "Region"
        '
        'ExistingRegionsComboBox
        '
        Me.ExistingRegionsComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ExistingRegionsComboBox.FormattingEnabled = True
        Me.ExistingRegionsComboBox.ItemHeight = 16
        Me.ExistingRegionsComboBox.Location = New System.Drawing.Point(9, 23)
        Me.ExistingRegionsComboBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ExistingRegionsComboBox.Name = "ExistingRegionsComboBox"
        Me.ExistingRegionsComboBox.Size = New System.Drawing.Size(253, 196)
        Me.ExistingRegionsComboBox.TabIndex = 1
        '
        'CountryGroupBox
        '
        Me.CountryGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CountryGroupBox.Controls.Add(Me.ExistingCountriesComboBox)
        Me.CountryGroupBox.Location = New System.Drawing.Point(13, 78)
        Me.CountryGroupBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CountryGroupBox.Name = "CountryGroupBox"
        Me.CountryGroupBox.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CountryGroupBox.Size = New System.Drawing.Size(276, 239)
        Me.CountryGroupBox.TabIndex = 47
        Me.CountryGroupBox.TabStop = False
        Me.CountryGroupBox.Text = "Country"
        '
        'ExistingCountriesComboBox
        '
        Me.ExistingCountriesComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ExistingCountriesComboBox.FormattingEnabled = True
        Me.ExistingCountriesComboBox.ItemHeight = 16
        Me.ExistingCountriesComboBox.Location = New System.Drawing.Point(9, 23)
        Me.ExistingCountriesComboBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ExistingCountriesComboBox.Name = "ExistingCountriesComboBox"
        Me.ExistingCountriesComboBox.Size = New System.Drawing.Size(253, 196)
        Me.ExistingCountriesComboBox.TabIndex = 0
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.btnClose, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Apply_Button, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnHelp, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(812, 335)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(321, 44)
        Me.TableLayoutPanel2.TabIndex = 59
        '
        'NewSelectTemplateFrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1149, 394)
        Me.Controls.Add(Me.DisciplinesGroupBox)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.ClientGroupBox)
        Me.Controls.Add(Me.RegionGroupBox)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.CountryGroupBox)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(1165, 430)
        Me.Name = "NewSelectTemplateFrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DisciplinesGroupBox.ResumeLayout(False)
        Me.ClientGroupBox.ResumeLayout(False)
        Me.RegionGroupBox.ResumeLayout(False)
        Me.CountryGroupBox.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnHelp As System.Windows.Forms.Button
    Friend WithEvents Apply_Button As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DisciplinesGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ExistingDisciplinesComboBox As System.Windows.Forms.ListBox
    Friend WithEvents ClientGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ExistingClientsComboBox As System.Windows.Forms.ListBox
    Friend WithEvents RegionGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ExistingRegionsComboBox As System.Windows.Forms.ListBox
    Friend WithEvents CountryGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ExistingCountriesComboBox As System.Windows.Forms.ListBox
End Class
