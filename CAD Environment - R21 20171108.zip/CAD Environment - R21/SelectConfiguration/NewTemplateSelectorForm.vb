Imports System.IO
Imports AutoCADApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Autodesk.AutoCAD.Internal.DatabaseServices       'DataBase
Imports Microsoft.Win32
Imports System.Windows.Forms
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Public Class NewTemplateSelectorForm

    Dim LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) & Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension)
    Dim cDirectoryEntries As Collection = New Collection

    '' Configurations are now stored in Directories and separated by a hyphen '-' 
    '' Every configuration name is made up of 4 columns or sections as follows
    Const cfgCountry As Integer = 0
    Const cfgRegion As Integer = 1
    Const cfgClient As Integer = 2
    Const cfgDisciplines As Integer = 3

    Dim NewConfigName As String = String.Empty
    Dim ExistingConfigName As String = String.Empty

    ''Implements Autodesk.AutoCAD.Runtime.IExtensionApplication

    Public Const RULES_Label As String = "SKM_RULES"
    Public sLastSelectedWorkspace As String = ""
    Public sLastUsedProductName As String = ""
    Public sLastUsedProductInClientselector As String = ""
    Public Shared cFilesFound As New Collection
    Public Shared sFilenameToUse As String
    Public sProductName As String

    Public Const HKCU As String = "HKCU"

    ''' <summary>
    ''' The Template Managers Tab - contains the Existing Templates Combo Boxes 
    ''' This sub populates these
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateExistingComboBoxes()

        Try
            If ExistingCountriesComboBox.Text = String.Empty Then
                PopulateExistingCountries()
            Else
                If ExistingRegionsComboBox.Text = String.Empty Then
                    PopulateExistingRegions()
                Else
                    If ExistingClientsComboBox.Text = String.Empty Then
                        PopulateExistingClients()
                    Else
                        If ExistingDisciplinesComboBox.Text = String.Empty Then
                            PopulateExistingDisciplines()
                        End If
                    End If
                End If
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub
    ''' <summary>
    ''' Populates Country Combo Box - this is exactly the same as the Populate Countrys List box code except it's for a combo box
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <remarks></remarks>
    Private Sub PopulateExistingCountries(Optional ByRef Value As Object = Nothing)

        Try
            Me.ExistingCountriesComboBox.Items.Clear()
            For Each Item As String In cDirectoryEntries
                Dim SplitDir() As String = Item.Split("-"c)
                If SplitDir.Length = 4 Then
                    If Not FindStringInListBox(SplitDir(cfgCountry), Me.ExistingCountriesComboBox) Then
                        Me.ExistingCountriesComboBox.Items.Add(SplitDir(cfgCountry))
                    End If
                Else
                    GeneralMessageBox("Invalid Config Folder Name: " & Item, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
                End If


            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Regions Combo Box - this is exactly the same as the Populate Regions List box code except it's for a combo box
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <remarks></remarks>
    Private Sub PopulateExistingRegions(Optional ByRef Value As Object = Nothing)

        Try
            Me.ExistingRegionsComboBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                'If SplitDir(cfgCountry).ToUpper.Contains(ExistingCountriesComboBox.Text.ToUpper) Then
                '    If Not Me.ExistingRegionsComboBox.Items.Contains(SplitDir(cfgRegion)) Then
                '        Me.ExistingRegionsComboBox.Items.Add(SplitDir(cfgRegion))
                '    End If
                'End If

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If Not FindStringInListBox(SplitDir(cfgRegion), ExistingRegionsComboBox) Then
                        Me.ExistingRegionsComboBox.Items.Add(SplitDir(cfgRegion))
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Clients Combo Box - this is exactly the same as the Populate Clients List box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateExistingClients()
        Try
            Me.ExistingClientsComboBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                'If SplitDir(cfgCountry).ToUpper.Contains(ExistingCountriesComboBox.Text.ToUpper) Then
                '    If SplitDir(cfgRegion).ToUpper.Contains(ExistingRegionsComboBox.Text.ToUpper) Then
                '        If Not Me.ExistingClientsComboBox.Items.Contains(SplitDir(cfgClient)) Then
                '            Me.ExistingClientsComboBox.Items.Add(SplitDir(cfgClient))
                '        End If
                '    End If
                'End If

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = ExistingRegionsComboBox.Text.ToUpper Then
                        If Not FindStringInListBox(SplitDir(cfgClient), ExistingClientsComboBox) Then
                            Me.ExistingClientsComboBox.Items.Add(SplitDir(cfgClient))
                        End If
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' Populates Disciplines Combo Box - this is exactly the same as the Populate Disciplibes List box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateExistingDisciplines()

        Try
            Me.ExistingDisciplinesComboBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                'If SplitDir(cfgCountry).ToUpper.Contains(ExistingCountriesComboBox.Text.ToUpper) Then
                '    If SplitDir(cfgRegion).ToUpper.Contains(ExistingRegionsComboBox.Text.ToUpper) Then
                '        If SplitDir(cfgClient).ToUpper.Contains(ExistingClientsComboBox.Text.ToUpper) Then
                '            If Not Me.ExistingDisciplinesComboBox.Items.Contains(SplitDir(cfgDisciplines)) Then
                '                Me.ExistingDisciplinesComboBox.Items.Add(SplitDir(cfgDisciplines))
                '            End If
                '        End If
                '    End If
                'End If

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = ExistingRegionsComboBox.Text.ToUpper Then
                        If SplitDir(cfgClient).ToUpper = ExistingClientsComboBox.Text.ToUpper Then
                            If Not FindStringInListBox(SplitDir(cfgDisciplines), ExistingDisciplinesComboBox) Then
                                Me.ExistingDisciplinesComboBox.Items.Add(SplitDir(cfgDisciplines))
                            End If
                        End If
                    End If
                End If


            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub InitialiseDocumentData()

        Try

            GetConfigSettings()

            '' Get all client folders in configuration library and store it in a collection
            CEGetDirectories(Settings.Manager.AE.ClientsConfigurationPath, cDirectoryEntries, Settings.Manager.AE.TemplatesToHideFileNamePathed, Settings.IsUserValidSystemAdministrator)

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            '' By populating the countries combo box we trigger the cascading population of the other combo boxes in this name
            PopulateExistingCountries()

            '' Populates the New Name Combo Boxes in the Template Managers tab with all the possible names
            '  PopulateNewNameComboBoxes()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    'Public Sub Terminate() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Terminate

    'End Sub

    Private Sub btnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp.Click

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click

        Me.Hide()
        Me.Close()

    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        InitialiseDocumentData()

    End Sub

    Private Sub Apply_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Apply_Button.Click

        Try

            ' '' Dim RuleAccessors As New RuleAccessors
            SwitchRemoveRuleOverrides()

            Dim NewName As String = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text

            RuleAccessors.AddRule("FULLCONFIGNAME", NewName, "Config Name", CStr(0), CStr(0))
            RuleAccessors.AddRule("CONFIGLEVEL", "Client", "Config Level", CStr(0), CStr(0))

            Me.Hide()
            Me.Close()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Function ReadConfigsFromXML(ByVal XMLFileName As String) As Collection

        Dim confignames As New Collection

        Try
            Dim xmlStructure As New SKM.Common.XML.XmlDocument(XMLFileName)
            Dim ListOfConfigurations As System.Xml.XmlNodeList = xmlStructure.GetElementsByTagName("Configuration")
            For Each Configuration As System.Xml.XmlNode In ListOfConfigurations
                confignames.Add(Configuration.Item("FullConfigName").InnerText)
            Next
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return confignames

    End Function

    ''' <summary>
    ''' '-----------------------------------------------------------------------------
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ExistingCountriesComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExistingCountriesComboBox.SelectedIndexChanged
        ExistingRegionsComboBox.Items.Clear()
        ExistingClientsComboBox.Items.Clear()
        ExistingDisciplinesComboBox.Items.Clear()

        ExistingRegionsComboBox.Text = String.Empty
        ExistingClientsComboBox.Text = String.Empty
        ExistingDisciplinesComboBox.Text = String.Empty

        PopulateExistingComboBoxes()
        EnableDisableApply_Button()
    End Sub

    Private Sub ExistingRegionsComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExistingRegionsComboBox.SelectedIndexChanged
        ExistingClientsComboBox.Items.Clear()
        ExistingDisciplinesComboBox.Items.Clear()

        ExistingClientsComboBox.Text = String.Empty
        ExistingDisciplinesComboBox.Text = String.Empty

        PopulateExistingClients()
        EnableDisableApply_Button()
    End Sub


    Private Sub ExistingClientsComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExistingClientsComboBox.SelectedIndexChanged
        ExistingDisciplinesComboBox.Items.Clear()

        ExistingDisciplinesComboBox.Text = String.Empty

        PopulateExistingDisciplines()
        EnableDisableApply_Button()
    End Sub

    Private Sub ExistingDisciplinesComboBox_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExistingDisciplinesComboBox.DoubleClick

        Try

            ' '' Dim RuleAccessors As New RuleAccessors
            SwitchRemoveRuleOverrides()

            Dim NewName As String = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text

            RuleAccessors.AddRule("FULLCONFIGNAME", NewName, "Config Name", CStr(0), CStr(0))
            RuleAccessors.AddRule("CONFIGLEVEL", "Client", "Config Level", CStr(0), CStr(0))

            Me.Hide()
            Me.Close()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub ExistingDisciplinesComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExistingDisciplinesComboBox.SelectedIndexChanged
        EnableDisableApply_Button()
    End Sub

    Sub EnableDisableApply_Button()

        If ExistingCountriesComboBox.Text = String.Empty Or
            ExistingRegionsComboBox.Text = String.Empty Or
            ExistingClientsComboBox.Text = String.Empty Or
            ExistingDisciplinesComboBox.Text = String.Empty Then
            Apply_Button.Enabled = False
            Exit Sub
        Else
            ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text
            Apply_Button.Enabled = True
        End If

    End Sub

    Private Sub NewSelectTemplateForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        InitialiseDocumentData()
    End Sub

    Private Sub NewSelectTemplateForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

End Class