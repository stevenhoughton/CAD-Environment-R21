Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports System.Windows.Forms
Imports Microsoft.Win32
Imports Jacobs.AutoCAD.Utilities

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.SelectTemplate.TemplateSelector))> 

Public Class TemplateSelector

    <CommandMethod("Jacobs_SelectTemplate", CommandFlags.Session)> _
    Public Sub DisplayWarning()

        Dim WarningDialog As TemplateSelectorWarningForm = New TemplateSelectorWarningForm
        Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(WarningDialog)

    End Sub

    <CommandMethod("Jacobs_ApplyTemplateAssociation", CommandFlags.Session)> _
    Public Sub SwitchConfiguration()

        If IsThisAnOldConfigName() = False Then
            Dim SelectTemplateDialog As NewTemplateSelectorForm = New NewTemplateSelectorForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(SelectTemplateDialog)
        End If

    End Sub

End Class
