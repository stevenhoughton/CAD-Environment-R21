﻿Imports Autodesk.AutoCAD.ApplicationServices
Imports System.Reflection
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices
Imports Jacobs.Common.Settings
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports System.Windows.Forms

Public Module ModExtraTools

    Public Function ToString(Of Annotationscale)(T) As String
        Return T.ToString
    End Function

    <System.Runtime.CompilerServices.Extension()>
    Public Function AsZeroOne(T As Boolean) As Integer
        Dim ReturnValue As Integer = 0
        Select Case T
            Case True
                ReturnValue = 1
            Case False
                ReturnValue = 0
        End Select
        Return ReturnValue
    End Function

    Public Function GetSysVariable(ByVal VariableName As String) As Object

        Dim RetData As Object = Nothing

        If VariableName <> "" Then

            Dim obj As Object = Autodesk.AutoCAD.ApplicationServices.Application.GetSystemVariable(VariableName)

            Select Case obj.GetType
                Case GetType(Double)
                    RetData = CType(obj, Double)
                Case GetType(String)
                    RetData = CType(obj, String)
                Case GetType(Integer), GetType(Short)
                    RetData = CType(obj, Integer)
            End Select

        End If

        Return RetData

    End Function

    Public Sub SetSysVariable(ByVal VariableName As String, ByVal Value As Object)

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument

        Using DocKock As DocumentLock = Doc.LockDocument
            Autodesk.AutoCAD.ApplicationServices.Application.SetSystemVariable(VariableName, Value)
        End Using

    End Sub

    Public Sub SetDimStyleCurrent(DimStyleName As String)

        Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim db As Database = doc.Database

        Using DockLock As DocumentLock = doc.LockDocument

            Using tr As Transaction = doc.TransactionManager.StartTransaction()

                Dim dst As DimStyleTable = DirectCast(tr.GetObject(db.DimStyleTableId, OpenMode.ForRead), DimStyleTable)
                Dim dimId As ObjectId = ObjectId.Null

                dimId = dst(DimStyleName)

                Dim dstr As DimStyleTableRecord = DirectCast(tr.GetObject(dimId, OpenMode.ForRead), DimStyleTableRecord)

                db.Dimstyle = dstr.ObjectId
                db.SetDimstyleData(dstr)

                tr.Commit()

            End Using

        End Using

    End Sub

End Module
