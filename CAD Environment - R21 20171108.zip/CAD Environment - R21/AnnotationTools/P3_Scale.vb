﻿

Imports System.IO
Imports System.Linq
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
'Imports Jacobs.AutoCAD.Utilities.GeometryExtensions
Imports System.Data
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources
Imports System.Windows.Forms

Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.GraphicsInterface
Imports System.Runtime.InteropServices

Public Class P3_Scale

    Private IsInitializing As Boolean = True
    Private mUseSCESettings As Boolean = False

    Private mUseClientSettings As Boolean = True
    'Private mWorkFlowIndex As Integer = 0
    Private mHostClass As AnnotationTools.StartAutoCAD = Nothing

    Public Sub New(ByRef HostClass As AnnotationTools.StartAutoCAD)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        mHostClass = HostClass
        'mUseClientSettings = UseClientSettingsSU

        AddHandler Autodesk.AutoCAD.ApplicationServices.Application.SystemVariableChanged, AddressOf UpDateSettings

    End Sub

    Public WriteOnly Property PalletteEnable() As Boolean
        Set(value As Boolean)
            mUseSCESettings = value

            Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.UseAESettings = mUseSCESettings
            'Disabled by Steven Houghton 29/09/17
            'lblWorkFlow.Enabled = mUseSCESettings
            'cboWorkFlow.Enabled = mUseSCESettings
            'chkUseClientConfig.Enabled = mUseSCESettings

            'disabled Steven Houghton 29/09/17
            'XEnabled(gbxDrawingScale, mUseSCESettings)
            XEnabled(gbxModelSpaceScale, mUseSCESettings)
            'XEnabled(gbxGeneralScaling, mUseSCESettings)
            XEnabled(gbxLineTypeScaling, mUseSCESettings)

            Select Case mUseSCESettings
                Case True
                    tssMessage.Text = "Drawing is Configured"
                    'Disabled by Steven Houghton 29/09/17
                    'chkUseClientConfig_CheckedChanged(Me.chkUseClientConfig, New EventArgs)
                Case False
                    tssMessage.Text = "Drawing is Not Configured"
            End Select
        End Set
    End Property

    'Private Sub P3_Scale_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    '    CheckRules(WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "True").IsTrue) ' Ignore any overrides

    '   IsInitializing = False

    'End Sub

    'Public Property UseClientSettings() As Boolean
    '    Get
    '        Return mUseClientSettings
    '    End Get
    '    Set(ByVal value As Boolean)
    '        mUseClientSettings = value
    '        CheckRules(WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "True").IsTrue) ' Ignore any overrides
    '    End Set
    'End Property

    'Public Property WorkFlowIndex() As Integer
    '    Get
    '        Return mWorkFlowIndex
    '    End Get
    '    Set(ByVal value As Integer)
    '        mWorkFlowIndex = value
    '        'Disabled by Steven Houghton 29/09/17
    '        'cboWorkFlow.SelectedIndex = value
    '        mHostClass.WorkFlowIndex = mWorkFlowIndex
    '    End Set
    'End Property

    'Private Sub CheckRules(Optional ByRef bIgnoreOverrides As Boolean = False)

    '    Dim sWhatToUse As String
    '    Dim sWhatToShow As String
    '    'Dim dscale As Double

    '    Try

    '        If GetruleValue("SCALE0", "True", False, True).IsTrue() Then

    '            ' Allow uses to select if they want to use rules or not
    '            'Disabled by Steven Houghton 29/09/17
    '            'chkUseClientConfig.Enabled = True

    '            ' Work out if the use rules tick box was on or off last time the tool was used - if not used set it to true
    '            'Disabled by Steven Houghton 29/09/17
    '            'chkUseClientConfig.Checked = WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "True").IsTrue()
    '            WorkingVariableAccessors.AddWorkVar("SCALEClientConfig", WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "True").IsTrue())

    '        Else

    '            ' Allow uses to select if they want to use rules or not - since they are present and set the tickbox to what it was if it has bee used before
    '            'Disabled by Steven Houghton 29/09/17
    '            'chkUseClientConfig.Enabled = False

    '            ' If this is the first time the tool is run in this drawing set it to use rules
    '            'Disabled by Steven Houghton 29/09/17
    '            'chkUseClientConfig.Checked = True

    '        End If
    '        'Disabled by Steven Houghton 29/09/17
    '        'If chkUseClientConfig.CheckState = CheckState.Checked Then

    '        Dim SearchForContent As Boolean = True
    '        If IsMasterFile() = True Then
    '            SearchForContent = False
    '        End If

    '        ' Check to see if the rules are already recorded in this drawing - if so don't initialize.
    '        'If IsThisAnOldConfigName() = True Then
    '        '    InitializeRules("[Scale]", True, SearchForContent, False)
    '        'Else
    '        InitializeRulesNew("[Scale]", True, SearchForContent, False)
    '        'End If

    '        ' Enable/Disable relevant fields
    '        'DecimalScale.Enabled = False

    '        'Disabled Steven Houghton 29/09/17
    '        'ScaleList.Enabled = False
    '        'ScaleListLabel.Enabled = False
    '        NewPSLTSCALE.Enabled = False
    '        LTScaleCompensator.Enabled = False
    '        'ScaleBlocksUsingDimscale.Enabled = False
    '        'NewINSUNITSList.Enabled = False
    '        'NewINSUNITSListlbl.Enabled = False
    '        LTScaleCompensatorlbl.Enabled = False

    '        sWhatToUse = "UseFirstRule"
    '        sWhatToShow = "AllAvailable"

    '        'Else

    '        ' User has elected not to use the client rules
    '        ' Enable/Disable relevant fields
    '        'DecimalScale.Enabled = True
    '        'ScaleList.Enabled = True
    '        'ScaleListLabel.Enabled = True
    '        'NewPSLTSCALE.Enabled = True
    '        'LTScaleCompensator.Enabled = True
    '        'ScaleBlocksUsingDimscale.Enabled = True
    '        'NewINSUNITSList.Enabled = True
    '        'NewINSUNITSListlbl.Enabled = True
    '        'LTScaleCompensatorlbl.Enabled = True

    '        'sWhatToUse = "UsePrevious"
    '        'sWhatToShow = "AllAvailable"

    '        'End If

    '        ' This will read the new LTSCALE Compensator Variable
    '        PopulateTextBox(LTScaleCompensator, "SCALE6", "1.0", , False, bIgnoreOverrides, "DOUBLE")

    '        ' This tool only runs when in Model Space or Floating Model Space
    '        If WhichSpace() = "ModelSpace" Then
    '            'Disabled Steven Houghton 29/09/17
    '            'gbxDrawingScale.Text = "Model Space"
    '            'dscale = GetScale()
    '            'DecimalScale.Text = dscale.ToString()

    '        Else

    '            If WhichSpace() = "FloatingModelSpace" Then
    '                'Disabled Steven Houghton 29/09/17
    '                'gbxDrawingScale.Text = "Floating Model Space"
    '                'dscale = GetScale()
    '                'DecimalScale.Text = (dscale / InsunitsToMMScaleFactor()).ToString()
    '            End If

    '        End If

    '        ''Rule = SCALE3,Automatically change system variables when switching space: ,1,3,42
    '        'jacobs.Utilities.PopulateCheckBox(ChangeSysvars, "SCALE3", "True", , False, bIgnoreOverrides)

    '        ''Rule = SCALE14,Automatically change system variables when switching Viewports: ,1,3,42
    '        'jacobs.Utilities.PopulateCheckBox(ChangeSysVarsVP, "SCALE14", "False", , False, bIgnoreOverrides)

    '        ''Rule = SCALE4,Don't show switch space message on this machine: ,1,3,42
    '        'jacobs.Utilities.PopulateCheckBox(DontAskAgain, "SCALE4", "True", , False, bIgnoreOverrides)

    '        'Rule = SCALE7,Use DIMSCALE when inserting blocks: ,0,3,42
    '        'PopulateCheckBox(ScaleBlocksUsingDimscale, "SCALE7", "False", , False, bIgnoreOverrides)

    '        'Rule = SCALE12,Insertion Units,0,3,41
    '        'Disabled Steven Houghton 29/09/17
    '        'PopulateComboBox(NewINSUNITSList, "SCALE12", sWhatToShow, sWhatToUse, "INSUNITS", InsunitsToStr, bIgnoreOverrides)

    '        'Rule = SCALE13,Initial value for PSLTSCALE 1: ,0,3,42
    '        PopulateCheckBox(NewPSLTSCALE, "SCALE13", "True", "PSLTSCALE", False, bIgnoreOverrides)


    '    Catch ex As Exception
    '        'ExceptionMessageDisplay(ex,x "SCE Generated Message - ScaleOptionsFrm.ScaleOptionsFrm.CheckRules", MessageBoxButtons.OK, MessageBoxIcon.Error,,,,,,LogName)
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
    '    End Try

    'End Sub
    'Private Sub chkUseClientConfig_CheckStateChanged(sender As Object, e As System.EventArgs)
    'Disabled by Steven Houghton 29/09/17
    'mHostClass.UseClientSettings = chkUseClientConfig.Checked
    'XEnabled(gbxDrawingScale, Not chkUseClientConfig.Checked)
    'XEnabled(gbxModelSpaceScale, Not chkUseClientConfig.Checked)
    'XEnabled(gbxGeneralScaling, Not chkUseClientConfig.Checked)
    'XEnabled(gbxLineTypeScaling, Not chkUseClientConfig.Checked)

    'End Sub

    'Private Sub cboWorkFlow_SelectedIndexChanged(sender As System.Object, e As System.EventArgs)
    'Disabled by Steven Houghton 29/09/17
    'WorkFlowIndex = cboWorkFlow.SelectedIndex
    'End Sub


    '' <summary>
    '' When the Insertion units drop down list box changes.
    '' </summary>
    '' <param name="sender"></param>
    '' <param name="e"></param>
    '' <remarks></remarks>
    'Private Sub NewINSUNITSList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    ' May need to swap the scales in the list to use the ones for the new Unit of Measure - for instance changing from Meters to Millimeters
    ' Changes the scales that are seen
    'Disabled Steven Houghton 3/10/2017
    'ChangeScaleList()

    ' Work out what the outcome would be if using this new Units
    'CalculateNewProposedLtAndDimScales()

    'End Sub

    '' <summary>
    '' When the scale list changes we need to recalculate the variables
    '' </summary>
    '' <param name="sender"></param>
    '' <param name="e"></param>
    '' <remarks></remarks>
    'Private Sub ScaleList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    ' Work out what the outcome would be if using this new Units
    'CalculateNewProposedLtAndDimScales()
    'Disabled Steven Houghton 29/09/17
    'RuleAccessors.RecordDglRule("SCALE1", ScaleList.Text)

    'End Sub

    '' <summary>
    '' When the LT Scale Compensator changes we need to recalculate the variables
    '' </summary>
    '' <param name="sender"></param>
    '' <param name="e"></param>
    '' <remarks></remarks>
    'Private Sub LTScaleCompensator_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LTScaleCompensator.TextChanged

    ' Work out what the outcome would be if using this new Units
    'CalculateNewProposedLtAndDimScales()

    '   RuleAccessors.RecordDglRule("SCALE6", LTScaleCompensator.Text)

    'End Sub

    Private Sub UpDateSettings(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.SystemVariableChangedEventArgs)

        'If chkUseClientConfig.Checked = False Then
        '    Select Case e.Name
        '        Case "DIMSCALE"
        '            newDimScaleTextBox.Text =
        '    Case "LTSCALE"
        '        LTScaleViewTextBox.Text =
        'End Select
        'Else
        '    Select Case e.Name
        '        Case "DIMSCALE"

        '        Case "LTSCALE"

        '    End Select
        'End If

    End Sub

    'Private Sub LTScaleViewTextBox_TextChanged(sender As System.Object, e As System.EventArgs) Handles LTScaleViewTextBox.TextChanged

    'Disabled Steven Houghton 29/09/17
    'RuleAccessors.RecordDglRule("SCALE12", cboINSUNITS.Text)

    'End Sub

    'Private Sub NewPSLTSCALE_CheckStateChanged(sender As Object, e As System.EventArgs) Handles NewPSLTSCALE.CheckStateChanged
    '    If NewPSLTSCALE.Checked = True Then
    '        RuleAccessors.RecordDglRule("SCALE13", 1)
    '    Else
    '        RuleAccessors.RecordDglRule("SCALE13", 0)
    '    End If
    'End Sub
End Class
