﻿Imports System.IO
Imports System.Linq
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
'Imports Jacobs.AutoCAD.Utilities.GeometryExtensions
Imports System.Data
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources
Imports System.Windows.Forms

Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.GraphicsInterface
Imports System.Runtime.InteropServices
Imports System.ComponentModel
Public Class P1_Text

    Private IsInitializing As Boolean = True
    Private mUseSCESettings As Boolean = False
    Private stoolpath As String = ""
    Private mUseClientSettings As Boolean = True
    Private mWorkFlowIndex As Integer = 0
    Private mHostClass As AnnotationTools.StartAutoCAD = Nothing
    Private TextSettings_DS As DataSet

    Dim sTextType As String
    Dim sPreviousLayer As String = ""
    Dim dPreviousTextScale As Double = 1
    Private Shared myCommandStarted As Boolean = False

    Public Sub New(ByRef HostClass As AnnotationTools.StartAutoCAD)

        ' This call is required by the designer.
        InitializeComponent()

        mHostClass = HostClass

        ' Add any initialization after the InitializeComponent() call.
        tssMessage.Text = ""

        'Disabled Steven Houghton 29/09/17
        'XEnabled(pnlAddSet_TRotation, False)

        AddHandler Autodesk.AutoCAD.ApplicationServices.Application.SystemVariableChanged, AddressOf AdjustForSpace

    End Sub

    Public Property UseClientSettings() As Boolean
        Get
            Return mUseClientSettings
        End Get
        Set(ByVal value As Boolean)
            mUseClientSettings = value
            chkUseClientConfig.Checked = value
        End Set
    End Property

    Public WriteOnly Property PalletteEnable() As Boolean
        Set(value As Boolean)
            mUseSCESettings = value

            Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.UseAESettings = mUseSCESettings

            'lblWorkFlow.Enabled = mUseSCESettings
            'cboWorkFlow.Enabled = mUseSCESettings
            chkUseClientConfig.Enabled = mUseSCESettings

            XEnabled(gbxTextConfigOption, mUseSCESettings)
            XEnabled(gbxClientSettings, mUseSCESettings)
            XEnabled(gbxTextOptions, mUseSCESettings)

            Select Case mUseSCESettings
                Case True
                    tssMessage.Text = "Drawing is Configured"
                    chkUseClientConfig_CheckedChanged(Me.chkUseClientConfig, New EventArgs)
                Case False
                    tssMessage.Text = "Drawing is Not Configured"
            End Select
        End Set
    End Property

    Private Sub P1_Text_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        Try

            Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
            AddHandler Doc.CommandEnded, AddressOf ThisDrawingText_EndCommand

            IsInitializing = True

            TextSettings_DS = New DataSet
            If TextSettings_DS.Tables.Contains("Rules") Then
                TextSettings_DS.Tables.Remove("Rules")
            End If
            TextSettings_DS.Tables.Add("Rules")

            TextSettings_DS.Tables("Rules").Columns.Add("Rule", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("THeight", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("TStyle", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("TLayer", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("TColor", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("ListDisplay", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("IsExist", GetType(System.Boolean))
            TextSettings_DS.Tables("Rules").Columns.Add("IsAnno", GetType(System.Boolean))
            TextSettings_DS.Tables("Rules").Columns.Add("Scale", GetType(System.String))

            Dim pk As System.Data.DataColumn = TextSettings_DS.Tables("Rules").Columns("Rule")

            'Need a primary key to search the datatable for existing Files
            TextSettings_DS.Tables("Rules").PrimaryKey = New System.Data.DataColumn() {pk}
            TextSettings_DS.AcceptChanges()

            Dim TTab As System.Data.DataTable = TextSettings_DS.Tables("Rules").Clone
            TTab.TableName = "CurrentSettings"
            TextSettings_DS.Tables.Add(TTab)
            TextSettings_DS.AcceptChanges()

            'If TextSettings_DS.Tables.Contains("TJustification") Then
            'TextSettings_DS.Tables.Remove("TJustification")
            'End If
            'TextSettings_DS.Tables.Add("TJustification")
            'TextSettings_DS.Tables("TJustification").Columns.Add("ShortName", GetType(System.String))
            'TextSettings_DS.Tables("TJustification").Columns.Add("ListDisplay", GetType(System.String))

            'Dim pkX As System.Data.DataColumn = TextSettings_DS.Tables("TJustification").Columns("ShortName")

            'Need a primary key to search the datatable for existing Files
            'TextSettings_DS.Tables("TJustification").PrimaryKey = New System.Data.DataColumn() {pkX}

            'TextSettings_DS.AcceptChanges()

            'Dim SNameas As String() = New String() {"TL", "TC", "TR", "ML", "MC", "MR", "BL", "BC", "BR"}
            'Dim LNames As String() = New String() {"Top Left", "Top Center", "Top Right",
            ' "Middle Left", "Middle Center", "Middle Right",
            '"Bottom Left", "Bottom Center", "Bottom Right"}
            'For Index As Integer = 0 To 8
            'Dim NRx As DataRow = TextSettings_DS.Tables("TJustification").NewRow
            'NRx.Item("ShortName") = SNameas(Index)
            'NRx.Item("ListDisplay") = LNames(Index)
            'TextSettings_DS.Tables("TJustification").Rows.Add(NRx)
            'NRx = Nothing
            'Next

            'TextSettings_DS.AcceptChanges()

            '' On Dialog_Load events ensure that the first thing we do is read the Configuration Settings 
            '' So that we have access to everything in the Configuration.XML file.

            GetConfigSettings()

            ' '' Assign Global Generic dialog tool tips. Not to be hard coded. Use Global Reference file in jacobs.Utilities
            'ToolTip1.SetToolTip(Help_Button, Global.My.Resources.ToolTipHelp)
            'ToolTip1.SetToolTip(Cancel_Button, Global.My.Resources.ToolTipCancel)
            'ToolTip1.SetToolTip(UseTemplateSettingsRadioButton, Global.My.Resources.ToolTipUseTemplateSettings)
            'ToolTip1.SetToolTip(OverrideTemplateSettingsRadioButton, Global.My.Resources.ToolTipOverrideTemplateSettings)

            ' '' Assign local unique tool tips. Not to be hard coded. Use local reference file
            'ToolTip1.SetToolTip(OK_Button, My.Resources.ToolTipOK)
            'ToolTip1.SetToolTip(lblTitle, My.Resources.ToolSummary)

            '' RULES Section 1
            '' If any user changes the Template Settings with their own Settings (in other words a user override)
            '' We would have written a Working Variable (WorkVar) indicating that the user had made some changes.
            '' The next line of code checks the rules in this drawing and populates the required fields
            '' It will use the user overrides if the WorkVar is true Else it uses the template rules.

            'CheckRules(WorkingVariableAccessors.GetWorkVarValue("SCALEClientConfig", "True").IsTrue) ' Ignore any overrides

            CheckRules(WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "True").IsTrue)

            ' jacobs.WorkingVariableAccessors.AddWorkVar("WELDSClientConfig", UseTemplateSettingsRadioButton.Checked = True)

            IsInitializing = False

            WorkFlowIndex = 0

        Catch ex As Exception

            '' Generic Error Message to handle exceptions - uses reflection to work out where the error was generated.
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

    End Sub
    Private Sub ThisDrawingText_EndCommand(ByVal senderObj As Object, ByVal e As CommandEventArgs)

        If ((myCommandStarted = True) And (UCase(e.GlobalCommandName) = UCase(sTextType))) Then
            'Get the current database
            Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
            Dim acCurDb As Database = acDoc.Database
            'Start a transaction
            Using acTRans As Transaction = acCurDb.TransactionManager.StartTransaction()

                'Restores the original layer name
                If sPreviousLayer <> "" Then
                    If Not sPreviousLayer.Equals(ThisDrawingUtilities.GetVariable("CLAYER").ToString) Then
                        ThisDrawingUtilities.SetVariable("CLAYER", sPreviousLayer)
                    End If
                End If

                Dim myobject As Autodesk.AutoCAD.Interop.Common.AcadObject = entlast()
                If myobject IsNot Nothing Then
                    MsgBox(myobject.ObjectID)
                End If

                myCommandStarted = False
                acTRans.Commit()
            End Using
        End If

    End Sub
    Private Sub chkUseClientConfig_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkUseClientConfig.CheckedChanged
        XEnabled(gbxClientSettings, Not (chkUseClientConfig.Checked))
        lstPreSetTextConfig.Enabled = chkUseClientConfig.Checked

        mHostClass.UseClientSettings = chkUseClientConfig.Checked
    End Sub

    Private Sub lstPreSetTextConfig_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles lstPreSetTextConfig.SelectedValueChanged

        Dim SelRowV As DataRowView = CType(lstPreSetTextConfig.SelectedItem, DataRowView)

        If SelRowV IsNot Nothing Then

            txtTextHeight.Text = SelRowV.Row.Item("THeight").ToString

            cboTextStyle.SelectedItem = SelRowV.Row.Item("TStyle").ToString
            cboTextStyle.SelectedIndex = cboTextStyle.SelectedIndex
            cboTextLayer.SelectedItem = SelRowV.Row.Item("TLayer").ToString
            cboTextLayer.SelectedIndex = cboTextLayer.SelectedIndex
            'cboTStyle.Focus = False


            'SetSysVariable("CLAYER", cboTLayer.SelectedItem.ToString)
            SetSysVariable("TEXTSTYLE", cboTextStyle.SelectedItem.ToString)

            'Test
            SetSysVariable("TEXTSIZE", CType(SelRowV.Row.Item("THeight").ToString, Double))
            'TEXT2
            'Test

            'AnnotationTools.StartAutoCAD.LayerEventTools.TxtLayerName = cboTLayer.SelectedItem.ToString ' mLayerText.TxtLayerName = cboTLayer.SelectedItem.ToString
            'AnnotationTools.StartAutoCAD.LayerEventTools.TxtStyleName = cboTStyle.SelectedItem.ToString 'mLayerText.TxtStyleName = cboTStyle.SelectedItem.ToString

            Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.TxtLayerName = cboTextLayer.SelectedItem.ToString
            Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.TxtStyleName = cboTextStyle.SelectedItem.ToString
        End If

        'AdjustForSpace()

    End Sub

    Private Sub chkUseCurrentLayer_CheckedChanged(sender As System.Object, e As System.EventArgs)
        cboTextLayer.SelectedItem = ThisDrawingUtilities.GetVariable("CLAYER").ToString
        'AdjustForSpace()
    End Sub

    Private Sub chkPromptJustification_CheckedChanged(sender As System.Object, e As System.EventArgs)
        'Disabled Steven Houghton 29/09/17
        'XEnabled(pnlAddSet_TJustification, chkPromptJustification.Checked)
        'AdjustForSpace()
    End Sub

    Private Sub chkPresetRotation_CheckedChanged(sender As System.Object, e As System.EventArgs)
        'Disabled Steven Houghton 29/09/17
        'XEnabled(pnlAddSet_TRotation, chkPresetRotation.Checked)
        'AdjustForSpace()
    End Sub

    Private Sub TextScaleTextBox_TextChanged(sender As Object, e As EventArgs) Handles txtNonAnnotativeScale.TextChanged
        RuleAccessors.RecordDglRule("SCALE1", txtNonAnnotativeScale.Text)
    End Sub

    Private Sub lstPreSetTextConfig_DoubleClick(sender As Object, e As EventArgs) Handles lstPreSetTextConfig.DoubleClick
        cmdPlaceText_Click(sender, e)
    End Sub

    Private Sub cmdPlaceText_Click(sender As System.Object, e As System.EventArgs) Handles cmdAddText.Click

        Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView()

        Dim SelRow As DataRowView = CType(lstPreSetTextConfig.SelectedItem, DataRowView)
        Dim RowX As DataRow

        If chkUseClientConfig.Checked = False Then
            RowX = SelRow.Row

            RowX.Item("THeight") = txtTextHeight.Text
            RowX.Item("TLayer") = cboTextLayer.SelectedItem.ToString
            RowX.Item("TStyle") = cboTextStyle.SelectedItem.ToString

        Else
            RowX = SelRow.Row
        End If

        If rdDText.Checked = True Then
            TextSettings(RowX)
            PlaceText("TEXT")
            'QuickDText(RowX)
        End If

        If rdMText.Checked = True Then
            TextSettings(RowX)
            PlaceText("MTEXT")
            'QuickMText(RowX)
        End If

    End Sub

    Public Sub TextSettings(ByVal SelRow As DataRow)

        myCommandStarted = True

        'Get the current database
        Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim acCurDb As Database = acDoc.Database
        'Start a transaction
        Using acTRans As Transaction = acCurDb.TransactionManager.StartTransaction()

            'Save the current layer
            sPreviousLayer = ThisDrawingUtilities.ActiveLayer.Name.ToString

            'Sets the current Layer from the rule DIM1
            Dim LayerName As String = SelRow.Item("TLayer").ToString
            If LayerExist(LayerName) Then
                If Not sPreviousLayer.Equals(LayerName) Then
                    ThisDrawingUtilities.SetVariable("CLAYER", LayerName)
                End If
            End If

            'Set the TextStyle
            Dim TextStyleName As String = SelRow.Item("TStyle").ToString
            If TextStyleExist(TextStyleName) Then
                Dim objTextStyle As Autodesk.AutoCAD.Interop.Common.AcadTextStyle = ThisDrawingUtilities.TextStyles.Item(TextStyleName)
                ThisDrawingUtilities.ActiveTextStyle = objTextStyle
            End If

            'Sets the Text Height
            If WorkFlowIndex = 0 Then
                Dim TextHeight As Double = CDbl(SelRow.Item("THeight"))
                TextHeight = AnnoToolsCalculateNewTextSize(TextHeight)
                ThisDrawingUtilities.SetVariable("TEXTSIZE", TextHeight)
            End If

            acTRans.Commit()
        End Using
    End Sub

    Sub PlaceText(sTextType As String)
        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Select Case WorkFlowIndex
            Case 0
                Doc.SendStringToExecute(sTextType & " ", True, False, False)
            Case 1
                Doc.SendStringToExecute(sTextType & " ", True, False, True)
        End Select
        Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView()
    End Sub

    'Public Sub QuickDText(ByVal SelRow As DataRow)
    '    Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
    '    Dim DB As Database = Doc.Database
    '    Dim ED As Editor = Doc.Editor

    '    Using acLckdoc As DocumentLock = Doc.LockDocument() ' Lock the document
    '        Using TR As Transaction = DB.TransactionManager.StartTransaction()

    '            Dim BT As BlockTable = TR.GetObject(DB.BlockTableId, OpenMode.ForRead) ' Open the block table, the model space and add our DText
    '            Dim CurrSpace As BlockTableRecord = Nothing 'Create the current space
    '            If WhichSpace() = "ModelSpace" Then 'Checks if Model space is the current space
    '                CurrSpace = TR.GetObject(BT(BlockTableRecord.ModelSpace), OpenMode.ForWrite) 'Makes Modelspace the current space
    '            Else
    '                CurrSpace = TR.GetObject(BT(BlockTableRecord.PaperSpace), OpenMode.ForWrite) 'Makes Paperspace the current space
    '            End If

    '            Dim pPtOpts As PromptPointOptions = New PromptPointOptions("")
    '            pPtOpts.Message = vbLf & "TEXT Specify start point of text or [Justify Style]: "
    '            Dim pPtRes As PromptPointResult = Doc.Editor.GetPoint(pPtOpts) 'Propmts for the location of the text
    '            If pPtRes.Status = PromptStatus.Cancel Then Exit Sub 'Exit if the user presses ESC or cancels the command

    '            Dim DT As DBText = New DBText 'Create the DText object
    '            DT.Position = pPtRes.Value 'Sets the location of the text
    '            DT.Normal = ED.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis

    '            Dim Hgt As Double = 6 'Sets the height of the text
    '            Dim Ans As Boolean = Double.TryParse(SelRow.Item("THeight").ToString, Hgt)
    '            'If chkNoModelScale.Checked = False Then
    '            Hgt = Hgt * 1 'TODO - Add Scale to this, In Testing Below
    '            Hgt = AnnoToolsCalculateNewTextSize(Hgt)
    '            'End If
    '            DT.Height = Hgt

    '            ' Launch the in-place DText editor with the default settings
    '            Dim ids As ObjectId() = New ObjectId(-1) {}
    '            InplaceTextEditor.Invoke(DT, ids)

    '            CurrSpace.AppendEntity(DT)
    '            TR.AddNewlyCreatedDBObject(DT, True)

    '            Dim LayTbl As LayerTable = DirectCast(TR.GetObject(DB.LayerTableId, OpenMode.ForRead), LayerTable)
    '            Dim LayName As String = SelRow.Item("TLayer").ToString
    '            If LayTbl.Has(LayName) = True Then
    '                DT.Layer = LayName
    '            Else
    '                DT.Layer = "0"
    '            End If
    '            'Disabled Steven Houghton 29/09/17
    '            'If chkPresetRotation.Checked Then
    '            'DT.Rotation = CType(txtTRotation.Text, Double) 'Need varification / Validation on this.
    '            'Else
    '            DT.Rotation = 0
    '            'End If

    '            Dim ocm As ObjectContextManager = DB.ObjectContextManager
    '            Dim occ As ObjectContextCollection = ocm.GetContextCollection("ACDB_ANNOTATIONSCALES")
    '            Select Case WorkFlowIndex
    '                Case 0
    '                    DT.Annotative = AnnotativeStates.False
    '                Case 1
    '                    DT.Annotative = AnnotativeStates.True

    '                    For Each A As AnnotationScale In lstAnnotationScales.SelectedItems
    '                        DT.AddContext(A)
    '                        ED.WriteMessage("Scale: " & A.Name & " Added to Text Object!" & vbCrLf)
    '                    Next
    '            End Select

    '            TR.Commit()
    '        End Using
    '    End Using
    'End Sub

    'Public Sub QuickMText(ByVal SelRow As DataRow)

    '    Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
    '    Dim db As Database = doc.Database
    '    Dim ed As Editor = doc.Editor

    '    Using acLckdoc As DocumentLock = doc.LockDocument() ' Lock the document
    '        Using TR As Transaction = db.TransactionManager.StartTransaction()

    '            Dim BT As BlockTable = TR.GetObject(db.BlockTableId, OpenMode.ForRead) ' Open the block table, the model space and add our MText
    '            Dim CurrSpace As BlockTableRecord = Nothing
    '            If WhichSpace() = "ModelSpace" Then
    '                CurrSpace = TR.GetObject(BT(BlockTableRecord.ModelSpace), OpenMode.ForWrite)
    '            Else
    '                CurrSpace = TR.GetObject(BT(BlockTableRecord.PaperSpace), OpenMode.ForWrite)
    '            End If

    '            Dim pPtOpts As PromptPointOptions = New PromptPointOptions("")
    '            pPtOpts.Message = vbLf & "TEXT Specify start point of text or [Justify Style]: "
    '            Dim pPtRes As PromptPointResult = doc.Editor.GetPoint(pPtOpts) 'Propmts for the location of the text
    '            If pPtRes.Status = PromptStatus.Cancel Then Exit Sub 'Exit if the user presses ESC or cancels the command

    '            Dim MT As MText = New MText() ' Create our New MText And set its properties
    '            MT.Location = pPtRes.Value 'Sets the location of the text
    '            MT.Normal = ed.CurrentUserCoordinateSystem.CoordinateSystem3d.Zaxis

    '            Dim Hgt As Double = 6 'Sets the height of the text
    '            Dim Ans As Boolean = Double.TryParse(SelRow.Item("THeight").ToString, Hgt)
    '            'If chkNoModelScale.Checked = False Then
    '            'Hgt = Hgt * 1 'TODO - Add Scale to this, In Testing Below
    '            Hgt = AnnoToolsCalculateNewTextSize(Hgt)
    '            'End If
    '            MT.TextHeight = Hgt

    '            InplaceTextEditor.Invoke(MT, New InplaceTextEditorSettings)

    '            CurrSpace.AppendEntity(MT)
    '            TR.AddNewlyCreatedDBObject(MT, True)

    '            Dim LayTbl As LayerTable = DirectCast(TR.GetObject(db.LayerTableId, OpenMode.ForRead), LayerTable)
    '            Dim LayName As String = SelRow.Item("TLayer").ToString
    '            If LayTbl.Has(LayName) = True Then
    '                MT.Layer = LayName
    '            Else
    '                MT.Layer = "0"
    '            End If
    '            'Disabled Steven Houghton 29/09/17
    '            'If chkPresetRotation.Checked Then
    '            'MT.Rotation = CType(txtTRotation.Text, Double) 'Need varification / Validation on this.
    '            'Else
    '            MT.Rotation = 0
    '            'End If

    '            Dim ocm As ObjectContextManager = db.ObjectContextManager
    '            Dim occ As ObjectContextCollection = ocm.GetContextCollection("ACDB_ANNOTATIONSCALES")
    '            Select Case WorkFlowIndex
    '                Case 0
    '                    MT.Annotative = AnnotativeStates.False
    '                Case 1
    '                    MT.Annotative = AnnotativeStates.True
    '                    For Each A As AnnotationScale In lstAnnotationScales.SelectedItems
    '                        MT.AddContext(A)
    '                        ed.WriteMessage("Scale: " & A.Name & " Added to Text Object!" & vbCrLf)
    '                    Next
    '            End Select


    '            TR.Commit()
    '        End Using
    '    End Using
    'End Sub

    Public Property WorkFlowIndex() As Integer
        Get
            Return mWorkFlowIndex
        End Get
        Set(ByVal value As Integer)
            mWorkFlowIndex = value
            'If cboWorkFlow.SelectedIndex <> value Then cboWorkFlow.SelectedIndex = value
            'Disabled Steven Houghton 6/10/17
            'mHostClass.WorkFlowIndex = mWorkFlowIndex
            If mWorkFlowIndex > 0 Then
                lstAnnotationScales.Visible = True
                gbxNonAnnotativeScales.Visible = False
                Dim OCC As ObjectContextCollection = HostApplicationServices.WorkingDatabase.ObjectContextManager.GetContextCollection("ACDB_ANNOTATIONSCALES")
                Dim X As Database = HostApplicationServices.WorkingDatabase

                Dim ListOfAnnoScales As New List(Of AnnotationScale)
                For Each A As AnnotationScale In OCC
                    ListOfAnnoScales.Add(A)
                Next

                lstAnnotationScales.DataSource = Nothing

                lstAnnotationScales.Items.Clear()

                lstAnnotationScales.DisplayMember = "Name"
                lstAnnotationScales.ValueMember = "Name"
                lstAnnotationScales.DataSource = ListOfAnnoScales

                lstAnnotationScales.SelectedItem = X.Cannoscale

                IsInitializing = False

            Else
                lstAnnotationScales.Visible = False
                gbxNonAnnotativeScales.Visible = True
                'AnnotationTools.StartAutoCAD.LayerEventTools.ClearTxtAnnotationList() ' mLayerText.ClearTxtAnnotationList()
                Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.ClearTxtAnnotationList()
            End If
        End Set
    End Property
    Private Sub AdjustForSpace(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.SystemVariableChangedEventArgs)

        If IsInitializing Then Exit Sub
        If mUseSCESettings = False Then Exit Sub
        If e.Name <> "TILEMODE" Then Exit Sub

        IsInitializing = True

        Select Case WhichSpace()
            Case "ModelSpace", "FloatingModelSpace"
                'chkNoModelScale.Visible = True
            Case "PaperSpace"
                'chkNoModelScale.Checked = False
                'chkNoModelScale.Visible = False
        End Select

    End Sub

    Private Class DBTextPlacementJig
        Inherits EntityJig
        ' Declare some internal state

        Private _db As Database
        Private _tr As Transaction
        Private _position As Point3d
        Private _AllowJustify As Boolean
        Private _ForceRotationValue As Boolean
        Private _angle As Double, _txtSize As Double
        Private _toggleBold As Boolean, _toggleItalic As Boolean
        Private _alignH As TextHorizontalMode
        Private _alignV As TextVerticalMode

        Private _alignFlag As Integer = 0 ' 1 - H & V, 2 - H only

        ' Constructor

        Public Sub New(tr As Transaction, db As Database, ent As Entity, tHeight As Double,
                       AllowJustify As Boolean, Optional Rotation As Double = 0,
                       Optional ForceRotationValue As Boolean = False)
            MyBase.New(ent)
            _db = db
            _tr = tr
            _angle = Rotation
            _txtSize = tHeight
            _AllowJustify = AllowJustify
            _ForceRotationValue = ForceRotationValue
        End Sub

        Protected Overrides Function Sampler(jp As JigPrompts) As SamplerStatus
            ' We acquire a point but with keywords

            Dim po As New JigPromptPointOptions(vbLf & "Position of text")

            po.UserInputControls = (UserInputControls.Accept3dCoordinates Or UserInputControls.NullResponseAccepted Or UserInputControls.NoNegativeResponseAccepted Or UserInputControls.GovernedByOrthoMode)
            Select Case _AllowJustify
                Case True
                    Select Case _ForceRotationValue
                        Case False
                            po.SetMessageAndKeywords(vbLf & "Pick Position of text or " + "[TL/TC/TR/ML/MC/MR/BL/BC/BR/ROtate90(TAB)/Left/Middle/Right]: ", "TL TC TR ML MC MR BL BC BR ROtate90 Left Middle Right")
                        Case True
                            po.SetMessageAndKeywords(vbLf & "Pick Position of text or " + "[TL/TC/TR/ML/MC/MR/BL/BC/BR/Left/Middle/Right]: ", "TL TC TR ML MC MR BL BC BR Left Middle Right")
                    End Select
                Case False
                    Select Case _ForceRotationValue
                        Case False
                            po.SetMessageAndKeywords(vbLf & "Pick Position of text or " + "[ROtate90(TAB)]: ", "ROtate90")
                        Case True
                            po.SetMessageAndKeywords(vbLf & "Pick Position of text", "")
                    End Select
            End Select

            Dim ppr As PromptPointResult = jp.AcquirePoint(po)

            If ppr.Status = PromptStatus.Keyword Then
                Select Case ppr.StringResult
                    Case "TL"
                        If True Then
                            _alignH = TextHorizontalMode.TextLeft
                            _alignV = TextVerticalMode.TextTop
                            _alignFlag = 1
                        End If
                    Case "TC"
                        If True Then
                            _alignH = TextHorizontalMode.TextCenter
                            _alignV = TextVerticalMode.TextTop
                            _alignFlag = 1
                        End If
                    Case "TR"
                        If True Then
                            _alignH = TextHorizontalMode.TextRight
                            _alignV = TextVerticalMode.TextTop
                            _alignFlag = 1
                        End If
                    Case "ML"
                        If True Then
                            _alignH = TextHorizontalMode.TextLeft
                            _alignV = TextVerticalMode.TextVerticalMid
                            _alignFlag = 1
                        End If
                    Case "MC"
                        If True Then
                            _alignH = TextHorizontalMode.TextCenter
                            _alignV = TextVerticalMode.TextVerticalMid
                            _alignFlag = 1
                        End If
                    Case "MR"
                        If True Then
                            _alignH = TextHorizontalMode.TextRight
                            _alignV = TextVerticalMode.TextVerticalMid
                            _alignFlag = 1
                        End If
                    Case "BL"
                        If True Then
                            _alignH = TextHorizontalMode.TextLeft
                            _alignV = TextVerticalMode.TextBottom
                            _alignFlag = 1
                        End If
                    Case "BC"
                        If True Then
                            _alignH = TextHorizontalMode.TextCenter
                            _alignV = TextVerticalMode.TextBottom
                            _alignFlag = 1
                        End If
                    Case "BR"
                        If True Then
                            _alignH = TextHorizontalMode.TextRight
                            _alignV = TextVerticalMode.TextBottom
                            _alignFlag = 1
                        End If
                    Case "ROtate90"
                        If True Then
                            _alignFlag = _alignFlag
                            ' To rotate clockwise we subtract 90 degrees and
                            ' then normalise the angle between 0 and 360

                            _angle -= Math.PI / 2
                            While _angle < Math.PI * 2
                                _angle += Math.PI * 2
                            End While
                            Exit Select
                        End If
                    Case "Left"
                        If True Then
                            _alignH = TextHorizontalMode.TextLeft
                            _alignFlag = 2
                            Exit Select
                        End If
                    Case "Right"
                        If True Then
                            _alignH = TextHorizontalMode.TextRight
                            _alignFlag = 2
                            Exit Select
                        End If
                    Case "Middle"
                        If True Then
                            _alignH = TextHorizontalMode.TextMid
                            _alignFlag = 2
                            Exit Select
                        End If
                End Select

                Return SamplerStatus.OK
            ElseIf ppr.Status = PromptStatus.OK Then
                ' Check if it has changed or not (reduces flicker)

                If _position.DistanceTo(ppr.Value) < Tolerance.[Global].EqualPoint Then
                    Return SamplerStatus.NoChange
                End If

                _position = ppr.Value
                Return SamplerStatus.OK
            End If

            Return SamplerStatus.Cancel
        End Function

        Protected Overrides Function Update() As Boolean
            ' Set properties on our text object

            Dim txt As DBText = DirectCast(Entity, DBText)

            'TODO - Check with ProSteel Text alignment Tool
            txt.Position = _position
            txt.Height = _txtSize
            txt.Rotation = _angle
            Select Case _alignFlag
                Case 1
                    txt.HorizontalMode = _alignH
                    txt.VerticalMode = _alignV
                    txt.AlignmentPoint = _position
                    txt.AdjustAlignment(_db)
                Case 2
                    txt.HorizontalMode = _alignH
            End Select

            Return True

        End Function
    End Class

    Private Class MTextPlacementJig
        Inherits EntityJig
        ' Declare some internal state

        Private _db As Database
        Private _tr As Transaction
        Private _position As Point3d
        Private _AllowJustify As Boolean
        Private _ForceRotationValue As Boolean
        Private _angle As Double, _txtSize As Double
        Private _toggleBold As Boolean, _toggleItalic As Boolean
        Private _TextAttachPoint As AttachmentPoint = AttachmentPoint.TopLeft
        Private _Width As Double = 0

        Private _alignFlag As Integer = 0 ' 1 - H & V, 2 - H only

        Public Sub New(tr As Transaction, db As Database, ent As Entity, tHeight As Double,
                       AllowJustify As Boolean, Optional Rotation As Double = 0,
                       Optional ForceRotationValue As Boolean = False)
            MyBase.New(ent)
            _db = db
            _tr = tr
            _angle = Rotation
            _txtSize = tHeight
            _AllowJustify = AllowJustify
            _ForceRotationValue = ForceRotationValue
        End Sub

        Protected Overrides Function Sampler(jp As JigPrompts) As SamplerStatus
            ' We acquire a point but with keywords

            Dim po As New JigPromptPointOptions(vbLf & "Position of MText")

            po.UserInputControls = (UserInputControls.Accept3dCoordinates Or UserInputControls.NullResponseAccepted Or UserInputControls.NoNegativeResponseAccepted Or UserInputControls.GovernedByOrthoMode)
            Select Case _AllowJustify
                Case True
                    Select Case _ForceRotationValue
                        Case False
                            po.SetMessageAndKeywords(vbLf & "Pick Position of MText or " + "[TL/TC/TR/ML/MC/MR/BL/BC/BR/ROtate90(TAB)/Width]: ", "TL TC TR ML MC MR BL BC BR ROtate90 W")
                        Case True
                            po.SetMessageAndKeywords(vbLf & "Pick Position of MText or " + "[TL/TC/TR/ML/MC/MR/BL/BC/BR/Width]: ", "TL TC TR ML MC MR BL BC BR W")
                    End Select
                Case False
                    Select Case _ForceRotationValue
                        Case False
                            po.SetMessageAndKeywords(vbLf & "Pick Position of MText or " + "[ROtate90(TAB)/Width]: ", "ROtate90 W")
                        Case True
                            po.SetMessageAndKeywords(vbLf & "Pick Position of MText or " + "[Width]: ", "W")
                    End Select
            End Select

            Dim ppr As PromptPointResult = jp.AcquirePoint(po)

            If ppr.Status = PromptStatus.Keyword Then
                Select Case ppr.StringResult
                    Case "TL"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.TopLeft
                            _alignFlag = 1
                        End If
                    Case "TC"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.TopMid
                            _alignFlag = 1
                        End If
                    Case "TR"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.TopRight
                            _alignFlag = 1
                        End If
                    Case "ML"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.MiddleLeft
                            _alignFlag = 1
                        End If
                    Case "MC"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.MiddleMid
                            _alignFlag = 1
                        End If
                    Case "MR"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.MiddleRight
                            _alignFlag = 1
                        End If
                    Case "BL"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.BottomLeft
                            _alignFlag = 1
                        End If
                    Case "BC"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.BottomMid
                            _alignFlag = 1
                        End If
                    Case "BR"
                        If True Then
                            _TextAttachPoint = AttachmentPoint.BottomRight
                            _alignFlag = 1
                        End If
                    Case "ROtate90"
                        If True Then
                            _alignFlag = _alignFlag
                            _angle -= Math.PI / 2
                            While _angle < Math.PI * 2
                                _angle += Math.PI * 2
                            End While
                            Exit Select
                        End If
                        'Case "Left"
                        '    If True Then
                        '        _TextAttachPoint = AttachmentPoint.BaseLeft
                        '        _alignFlag = 2
                        '        Exit Select
                        '    End If
                        'Case "Right"
                        '    If True Then
                        '        _TextAttachPoint = AttachmentPoint.BaseRight
                        '        _alignFlag = 2
                        '        Exit Select
                        '    End If
                        'Case "Middle"
                        '    If True Then
                        '        _TextAttachPoint = AttachmentPoint.BaseMid
                        '        _alignFlag = 2
                        '        Exit Select
                        '    End If
                    Case "W"
                        If True Then
                            Dim GetDoubOp As New PromptDoubleOptions("End MText Width " & "(Current:" & _Width.ToString & ") " & "<Enter To Pick Distance>: ")
                            GetDoubOp.AllowNegative = False
                            GetDoubOp.AllowZero = True
                            GetDoubOp.AllowNone = True
                            Dim DoubRes As PromptDoubleResult = Ed.GetDouble(GetDoubOp)
                            Select Case DoubRes.Status
                                Case PromptStatus.OK
                                    _Width = DoubRes.Value
                                Case Else

                                    Dim PickDistOpt As New PromptDistanceOptions("Pick 2 Points to get MText Width Limits:")
                                    PickDistOpt.DefaultValue = 0
                                    PickDistOpt.UseDashedLine = True
                                    Dim PickRes As PromptDoubleResult = Ed.GetDistance(PickDistOpt)
                                    If PickRes.Status = PromptStatus.OK Then
                                        _Width = PickRes.Value
                                    Else
                                        _Width = 0
                                    End If

                            End Select

                        End If
                End Select

                Return SamplerStatus.OK
            ElseIf ppr.Status = PromptStatus.OK Then
                ' Check if it has changed or not (reduces flicker)

                If _position.DistanceTo(ppr.Value) < Tolerance.[Global].EqualPoint Then
                    Return SamplerStatus.NoChange
                End If

                _position = ppr.Value
                Return SamplerStatus.OK
            End If

            Return SamplerStatus.Cancel
        End Function

        Protected Overrides Function Update() As Boolean
            ' Set properties on our text object

            Dim txt As MText = DirectCast(Entity, MText)

            txt.TextHeight = _txtSize
            txt.Rotation = _angle
            txt.Width = _Width
            txt.Attachment = _TextAttachPoint
            txt.Location = _position

            Return True

        End Function
    End Class

    Public Class TxtRotMsgFilter
        Implements System.Windows.Forms.IMessageFilter
        <DllImport("user32.dll", CharSet:=CharSet.Auto, ExactSpelling:=True)>
        Public Shared Function GetKeyState(keyCode As Integer) As Short
        End Function

        Const WM_KEYDOWN As Integer = 256
        Const VK_CONTROL As Integer = 17

        Private _doc As Document = Nothing

        Public Sub New(doc As Document)
            _doc = doc
        End Sub

        Public Function PreFilterMessage(ByRef m As System.Windows.Forms.Message) As Boolean Implements System.Windows.Forms.IMessageFilter.PreFilterMessage
            If m.Msg = WM_KEYDOWN AndAlso m.WParam = System.Windows.Forms.Keys.Tab AndAlso GetKeyState(VK_CONTROL) >= 0 Then
                _doc.SendStringToExecute("_RO ", True, False, False)
                Return True
            End If
            Return False
        End Function
    End Class

    Private Sub lstAnnotationScales_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstAnnotationScales.SelectedIndexChanged

        If lstAnnotationScales.SelectedItems.Count = 0 Then Exit Sub

        Dim TListAnnoScales As New List(Of AnnotationScale)
        For Each A As AnnotationScale In lstAnnotationScales.SelectedItems
            TListAnnoScales.Add(A)
        Next

        Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.TxtAnnoScales = TListAnnoScales
    End Sub

    Private Sub cboTLayer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboTextLayer.SelectedValueChanged
        Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.TxtLayerName = cboTextLayer.SelectedText.ToString
    End Sub

    Private Sub cboTStyle_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboTextStyle.SelectedValueChanged
        SetSysVariable("TEXTSTYLE", cboTextStyle.SelectedItem.ToString)
        Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.TxtStyleName = cboTextStyle.SelectedItem.ToString
    End Sub

    Private Sub txtTHeight_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtTextHeight.TextChanged
        SetSysVariable("TEXTSIZE", CType(txtTextHeight.Text, Double))
        RuleAccessors.RecordDglRule("TEXT2", txtTextHeight.Text)
    End Sub

    Dim DTLoc As Point3d = Point3d.Origin

    Private Function MyDragCallback(ByVal pt As Point3d, ByRef mat As Matrix3d) As SamplerStatus

        ' If no change has been made, say so
        If DTLoc = pt Then
            Return SamplerStatus.NoChange
        Else
            ' Otherwise we return the displacement matrix for the current position
            mat = Matrix3d.Displacement(DTLoc.GetVectorTo(pt))
        End If

        Return SamplerStatus.OK

    End Function

    Private Sub NonAnnotativeRadioButtonText_CheckedChanged(sender As Object, e As EventArgs) Handles rdNonAnnotativeScale.CheckedChanged
        WorkFlowIndex = 0
    End Sub

    Private Sub AnnotativeRadioButtonText_CheckedChanged(sender As Object, e As EventArgs) Handles rdAnnotativeScale.CheckedChanged
        WorkFlowIndex = 1
    End Sub
    ''' <summary>
    ''' When the scale list changes we need to recalculate the variables
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cboNonAnnotativeScales_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboNonAnnotativeScales.SelectedIndexChanged

        ' Work out what the outcome would be if using this new Units
        CalculateNewProposedLtAndDimScales()

        RuleAccessors.RecordDglRule("SCALE1", cboNonAnnotativeScales.Text)

        UpdateModeMacro()

    End Sub

    ''' <summary>
    ''' When the Insertion units drop down list box changes.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cboNonAnnotativeUnits_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboNonAnnotativeUnits.SelectedIndexChanged

        ' May need to swap the scales in the list to use the ones for the new Unit of Measure - for instance changing from Meters to Millimeters
        ' Changes the scales that are seen
        ChangeScaleList()

        ' Work out what the outcome would be if using this new Units
        CalculateNewProposedLtAndDimScales()

        RuleAccessors.RecordDglRule("SCALE12", cboNonAnnotativeUnits.Text)

        ChangeScaleSysVars()

    End Sub

    Public Function AnnoToolsCalculateNewTextSize(ByVal dTextSize As Double) As Double

        'Dim DScale As Double = GetScale()

        ' If text size was not provided then get the TextSize specified by the Text Tool Rule TEXT2 which contains desired text size or the override if set.
        'Dim bIgnoreTXTOverrides As Boolean = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").ToString.IsTrue

        ' Work out the conversion factor for the units selected in the InsUnits list box
        'Dim Convfactor As Double = InsunitsToMMScaleFactor()

        ' Work out which space we are in at the moment so we can return what the correct TEXTSIZE should be
        Select Case WhichSpace()
            Case "PaperSpace"
                ' Assumption is made that paperspace will always be in 1:1 MM
                If dTextSize = 0.0# Then
                    dTextSize = dTextSize
                End If

            Case "FloatingModelSpace"

                'DScale = Math.Round(ThisDrawingUtilities.ActivePViewport.CustomScale, 6)
                dTextSize = dTextSize * txtNonAnnotativeScale.Text' / DScale

            Case ("ModelSpace")

                dTextSize = dTextSize * txtNonAnnotativeScale.Text ' / DScale

        End Select

        Return dTextSize


    End Function
    ''' <summary>
    ''' Calculate Dimscale and LTScale based on dialog settings - does not set DIMSCALE or LTSCALE
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalculateNewProposedLtAndDimScales()

        ' Calculate the new DIMSCALE based on dialog box values
        txtNonAnnotativeScale.Text = CalculateTextScale(cboNonAnnotativeScales.Text, cboNonAnnotativeUnits.Text).ToString

        ' Calculate new LTSCALE 
        newLTSCALETextBox.Text = CalculateNewLTScale(cboNonAnnotativeScales.Text, cboNonAnnotativeUnits.Text, LTScaleCompensator.Text).ToString

        LTScaleViewTextBox.Text = newLTSCALETextBox.Text

    End Sub
    ''' <summary>
    ''' This is called when the Scale dialiog initializes and when the Insertion Units change in the drop down list
    ''' It Looks for the apropriate file that contains the list of scales to use for the units of measrue specified in the
    ''' InsUnits drop down list box
    ''' The Millimaters scale list file is named AutoCADScaleList.Reg all the othe units of measure have the unit of measure as a suffix
    ''' for example the Meters one is called AutoCADScaleListMeters.Reg
    ''' </summary>
    ''' <remarks></remarks>
    Sub ChangeScaleList()

        Dim vScalesFromRegFile() As String
        Dim sFullConfigName As String
        Dim sFileName As String
        Dim sFileNameAndPath As String

        Try

            ' The name of the Millimeter (default) file that has all the default scale lists
            sFileName = "AutoCADScaleList.Reg"

            ' If this drawing is not in the default Millimeters for a specific unit version of the scale list
            If cboNonAnnotativeUnits.Text <> "Millimeters" Then
                sFileName = sFileName.ToUpper.Replace(".REG", cboNonAnnotativeUnits.Text & ".Reg")
            End If

            ' Configuration extractyion path in case the configuration contains an override list
            sFullConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME", "Not Configured", False, True)

            ' The C:\ProgramData\Autodesk\ApplicationPluggins\Jacobs CAD Environment R20.Bundle\Contents path which contains the Jacobs Corporate scale list
            stoolpath = Settings.Manager.AE.Path

            ' Look for reg file in configuration area
            sFileNameAndPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix & "\" & sFullConfigName & "\Support\" & sFileName

            ' If there is no configuration override then look for the file in the 
            ' C:\ProgramData\Autodesk\ApplicationPluggins\Jacobs CAD Environment R20.Bundle\Contents path which contains the Jacobs Corporate scale list
            If System.IO.File.Exists(sFileNameAndPath) = False Then
                sFileNameAndPath = Settings.Manager.AE.Path.CombinePath(sFileName)
            End If

            ' Capture any units we haven't catered for but may be in use in jacobs.
            If System.IO.File.Exists(sFileNameAndPath) = False Then

                Acad_MessageBox("Unit specific scale list not found: " & sFileName & " Contact cad support to create a list of scales for these units." & vbCrLf &
                       "Will continue using Millimetre set scales for now", "Missing Scale List file for specified units", MessageBoxButtons.OK, MessageBoxIcon.Information)

                sFileNameAndPath = stoolpath.CombinePath("AutoCADScaleList.Reg")

            End If

            ' By now a file must have been found so read the contents 
            vScalesFromRegFile = ScaleListFileRead(sFileNameAndPath, ".ScaleName")

            ' Clear the list of scales in the Scale tool dialog
            cboNonAnnotativeScales.Items.Clear()

            Dim i As Integer

            ' Iterate the list and add them to the drop down list boxes
            For i = LBound(vScalesFromRegFile) To UBound(vScalesFromRegFile)

                ' Remove the " Meters" from the name of the scale as all scales are now represented as 1 Drawing Unit = X Millimetres
                Dim sScaleToUse As String

                ' Get rid of the word Meters from the Scale name if present
                sScaleToUse = Split(Replace(vScalesFromRegFile(i).ToUpper.Replace(" " & InsunitsToStr.ToUpper, ""), """", ""), "=")(1)

                ' Get rid of the word m from the Scale name if present
                sScaleToUse = sScaleToUse.ToUpper.Replace(" m".ToUpper, "")

                Dim a As Double = CDbl(sScaleToUse.Split(":"c)(0))
                Dim b As Double = CDbl(sScaleToUse.Split(":"c)(1))

                If String.IsNullOrEmpty(cboNonAnnotativeUnits.Text) Then
                    cboNonAnnotativeScales.Items.Add(a & ":" & b * InsunitsToMMScaleFactor(CInt(ThisDrawingUtilities.GetVariable("INSUNITS"))))
                Else
                    cboNonAnnotativeScales.Items.Add(a & ":" & b * InsunitsToMMScaleFactor(InsunitsStrToInsunitsVal(cboNonAnnotativeUnits.Text)))
                End If

            Next

            ' Get the rule value to set the Scale value in the list
            Dim Scale As String = RuleAccessors.GetruleValue("SCALE1")

            If cboNonAnnotativeScales.Items.Contains(Scale) Then
                ' If there is the same scale in the new list use that one
                cboNonAnnotativeScales.Text = Scale
            Else
                ' Get the firt scale in the list
                cboNonAnnotativeScales.SelectedIndex = 0
            End If
        Catch ex As Exception
            Acad_MessageBox(ex.Message, "CAD Environment Generated Message - ScaleOptionsFrm.ScaleOptionsFrm.ChangeScaleList", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
        End Try
    End Sub
    Sub CheckRules(Optional ByRef bIgnoreOverrides As Boolean = False)

        '' This is the display mode of the control (which one to use as the default value)  - options are UseFirstRule or UsePrevious
        ''   UseFirstRule would get the first value in the list or array and just sets that as the visible item
        ''   UsePrevious would look for a pre saved workvar or a system variable to work out the default value

        Dim sWhatToUse As String

        '' This is the population mode of the control - options are all Available or JustRuleValues ("JustRuleValues" is for when called by Content Wizard or Template Builder)
        ''   In other words fill the list with only the rule values or all the values - example all layers in this drawing or just the one which is the default one.

        Dim sWhatToShow As String
        Dim dscale As Double
        Try

            '' RULE 0
            '' Every Tool that uses rules needs to have a rule named {ToolName}0 
            '' This rule is used to work out if the template builder will allow users to change the Settings for this tool at runtime.
            ''
            '' Rules are made up of
            ''
            '' Name:            SAMPLESCETOOL0
            '' Description:     Allow users to change default Settings nominated here:
            '' Value:           1
            '' DGL Code:        3      Three types available   1 = List Box
            ''                                                 2 = Single entry Text box
            ''                                                 3 = Boolean tickbox
            '' TBL Code:        42     Nine types Available  
            ''                                                 6 = Layer name (fixed)
            ''                                                 4 = Linetype name (fixed)
            ''                                                 8 = Text style name (fixed)
            ''                                                11 = DimStyle
            ''                                                15 = Text Justifications
            ''                                                40 = Double-precision floating-point values (text height, scale factors, and so on) 
            ''                                                41 = String
            ''                                                42 = Integers
            ''                                                62 = Color number (fixed)
            ''                                                18 = Insunits (fixed)
            ''                                                19 = User Defined List - (send array with items - fixed to that array)
            ''
            '' Rule Definition would look like this in the Tools.ini file.
            '' Rule = SAMPLESCETOOL0,Allow users to change default Settings nominated here:,1,3,42

            ''Case "CLAYER"
            ''Case "TEXTSTYLE"
            ''Case "DIMSTYLE"
            ''Case "CTABLESTYLE"
            ''Case "CELWEIGHT"
            ''Case "PEN"
            ''Case "BLOCK"
            ''Case "CELTYPE"
            ''Case "CECOLOR"
            ''Case "TEXTJUSTIFICATION"
            ''Case "TEXTTYPES"
            ''Case "AUPREC0" ' Decimal Degrees
            ''Case "AUPREC1" ' Degrees minutes and seconds
            ''Case "AUPREC2" ' Grads
            ''Case "AUPREC3" ' Radians
            ''Case "AUPREC4" ' Surveyor's Units
            ''Case "AUPREC"
            ''Case "AUNITS"
            ''Case "INSUNITS"
            ''Case "LUNITS"
            ''Case "LUPREC0" ' Scientific
            ''Case "LUPREC1" ' Decimal
            ''Case "LUPREC2" ' Engineering
            ''Case "LUPREC3" ' Architectural
            ''Case "LUPREC4" ' Fractional
            ''Case "CUSTOM"

            '' Rule = SAMPLESCETOOL0,Allow users to change default Settings nominated here:,1,3,42
            '' This tool by default allows users to change config defaults.

            If GetruleValue("TEXT0", "True").IsTrue() Then

                '' Allow uses to select if they want to use rules or not
                chkUseClientConfig.Enabled = True

                ' Work out if the use rules tick box was on or off last time the tool was used - if not used set it to true
                chkUseClientConfig.Checked = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "True").IsTrue()
                WorkingVariableAccessors.AddWorkVar("TEXTClientConfig", WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "True").IsTrue())

                ' Work out if the use rules tick box was on or off last time the tool was used - if not used set it to true
                'If WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "True").IsTrue Then
                'chkUseClientConfig.Checked = True
                'Else
                'chkUseClientConfig.Checked = True
                'End If

            Else

                '' Template Builder has restricted users from being able to change the template rules
                chkUseClientConfig.Enabled = False

                ' Work out if the use rules tick box was on or off last time the tool was used - if not used set it to true
                chkUseClientConfig.Checked = True

            End If

            '' Now that we have worked out if users could change the Settings or not.
            '' See which one it's set to

            If chkUseClientConfig.Checked = CheckState.Checked Then

                '' User has opted to use the template Settings.
                '' Initialize the rules - this includes loading rules that may have been purged or ones that were never created in the origianal template
                '' For example new rules that now exist due to new tool features..
                '' This function is huge and it included functionality such as importing rules from the hierarchy and importing content from the hierarchy.

                Dim SearchForContent As Boolean = True
                If IsMasterFile() = True Then
                    SearchForContent = False
                End If

                'If IsThisAnOldConfigName() = True Then
                '    InitializeRules("[TEXT]", True, SearchForContent, False)
                'Else
                InitializeRulesNew("[TEXT]", True, SearchForContent, False)
                'End If

                ' Enable/Disable relevant fields on your form - these would only be fields that have rules tied to them.
                ' If you are using the template Settings then normally all of the fields in this section should be disabled..
                'DecimalScale.Enabled = False

                cboNonAnnotativeScales.Enabled = False
                lblNonAnnotativeScales.Enabled = False
                'NewPSLTSCALE.Enabled = False
                'LTScaleCompensator.Enabled = False
                'LTScaleCompensatorlbl.Enabled = False
                'ScaleBlocksUsingDimscale.Enabled = False
                cboNonAnnotativeUnits.Enabled = False
                lblNonAnnotativeUnits.Enabled = False
                'lstAnnotationScales.Enabled = True

                '' Since we are using the rules in the Template the first one will be the only one 
                sWhatToUse = "UseFirstRule"

                '' Next line of code is probably redundant - as users can't select anything from the disabled fields.
                sWhatToShow = "AllAvailable"

            Else

                ' User has elected not to use the client rules
                ' Enable/Disable relevant fields
                ' If the user wishes to override the rules in the template then all the fields in this area should be enable
                'DecimalScale.Enabled = True
                cboNonAnnotativeScales.Enabled = True
                lblNonAnnotativeScales.Enabled = True
                'NewPSLTSCALE.Enabled = True
                'LTScaleCompensator.Enabled = True
                'LTScaleCompensatorlbl.Enabled = True
                'ScaleBlocksUsingDimscale.Enabled = True
                cboNonAnnotativeUnits.Enabled = True
                lblNonAnnotativeUnits.Enabled = True
                'lstAnnotationScales.Enabled = False
                '' This time we are using the user overrides so if the user had picked something before we want to recall it from the workvars
                sWhatToUse = "UsePrevious"

                '' Show all items available so that the user can select
                sWhatToShow = "AllAvailable"

            End If

            ' This will read the new LTSCALE Compensator Variable
            'PopulateTextBox(LTScaleCompensator, "SCALE6", "1.0", , False, bIgnoreOverrides, "DOUBLE")
            ' This tool only runs when in Model Space or Floating Model Space
            If WhichSpace() = "ModelSpace" Then

                gbxNonAnnotativeScales.Text = "Model Space"
                dscale = GetScale()
                'DecimalScale.Text = dscale.ToString()

            Else

                If WhichSpace() = "FloatingModelSpace" Then
                    gbxNonAnnotativeScales.Text = "Floating Model Space"
                    dscale = GetScale()
                    'DecimalScale.Text = (dscale / InsunitsToMMScaleFactor()).ToString()
                End If

            End If

            'Text1
            PopulateComboBox(cboTextStyle, "XX", sWhatToShow, sWhatToUse, "TEXTSTYLE", ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            PopulateTextBox(txtTextHeight, "TEXT2", GetruleValue("TEXT2", , bIgnoreOverrides), , False, bIgnoreOverrides)

            PopulateComboBox(cboTextLayer, "XX", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)

            'Rule = SCALE7,Use DIMSCALE when inserting blocks: ,0,3,42
            'PopulateCheckBox(ScaleBlocksUsingDimscale, "SCALE7", "False", , False, bIgnoreOverrides)

            'Rule = SCALE12,Insertion Units,0,3,41
            PopulateComboBox(cboNonAnnotativeUnits, "SCALE12", sWhatToShow, sWhatToUse, "INSUNITS", InsunitsToStr, bIgnoreOverrides)

            'Rule = SCALE13,Initial value for PSLTSCALE 1: ,0,3,42
            'PopulateCheckBox(NewPSLTSCALE, "SCALE13", "True", "PSLTSCALE", False, bIgnoreOverrides)
            'Disabled Steven Houghton 29/09/17
            'PopulateTextBox(txtTRotation, "TEXT28", GetruleValue("TEXT28", , False), , False, False) 'bIgnoreOverrides
            'PopulateCheckBox(chkPromptJustification, "TEXT26", GetruleValue("TEXT26", , False), , False, False) 'bIgnoreOverrides

            'TextSettings_DS.Tables("Rules").Columns.Add("Rule", GetType(System.String))
            'TextSettings_DS.Tables("Rules").Columns.Add("THeight", GetType(System.String))
            'TextSettings_DS.Tables("Rules").Columns.Add("TStyle", GetType(System.String))
            'TextSettings_DS.Tables("Rules").Columns.Add("TLayer", GetType(System.String))
            'TextSettings_DS.Tables("Rules").Columns.Add("TColor", GetType(System.String))
            'TextSettings_DS.Tables("Rules").Columns.Add("ListDisplay", GetType(System.String))

            'Eventually I reckon get ride of this and and have a Stylre Count as part of the rule.
            '' TEXT3 Rule ' Text layer for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtLay18, "TEXT3", sWhatToShow, sWhatToUse, "CLAYER", Jacobs.Utilities.ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            '' TEXT4 Rule ' Text style for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtSty18, "TEXT4", sWhatToShow, sWhatToUse, "TEXTSTYLE", jacobs.Utilities.ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            '' TEXT5 Rule ' Text colour for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtCol18, "TEXT5", sWhatToShow, sWhatToUse, "CECOLOR", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            '' TEXT6 Rule
            'jacobs.Utilities.PopulateComboBox(TxtJust18, "TEXT6", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)
            Dim NR As DataRow = TextSettings_DS.Tables("Rules").NewRow
            NR.Item("Rule") = "1.8mm Text Rule"
            NR.Item("THeight") = "1.8"
            NR.Item("TLayer") = GetruleValue("TEXT3")
            NR.Item("TStyle") = GetruleValue("TEXT4")
            NR.Item("TColor") = GetruleValue("TEXT5")
            'NR.Item("Justification_Not USED") = jacobs.GetRule("TEXT6")
            NR.Item("ListDisplay") = NR.Item("Rule").ToString & " - Style: " & NR.Item("TStyle").ToString & " - Layer:" & NR.Item("TLayer").ToString
            NR.Item("Scale") = txtNonAnnotativeScale.Text
            TextSettings_DS.Tables("Rules").Rows.Add(NR)
            NR = Nothing

            '' TEXT7 Rule ' Text layer for 25 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtLay25, "TEXT7", sWhatToShow, sWhatToUse, "CLAYER", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            '' TEXT8 Rule ' Text style for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtSty25, "TEXT8", sWhatToShow, sWhatToUse, "TEXTSTYLE", jacobs.Utilities.ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            '' TEXT9 Rule ' Text colour for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtCol25, "TEXT9", sWhatToShow, sWhatToUse, "CECOLOR", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            '' TEXT10 Rule
            'jacobs.Utilities.PopulateComboBox(TxtJust25, "TEXT10", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)
            NR = TextSettings_DS.Tables("Rules").NewRow
            NR.Item("Rule") = "2.5mm Text Rule"
            NR.Item("THeight") = "2.5"
            NR.Item("TLayer") = GetruleValue("TEXT7")
            NR.Item("TStyle") = GetruleValue("TEXT8")
            NR.Item("TColor") = GetruleValue("TEXT9")
            'NR.Item("Justification_Not USED") = jacobs.GetRule("TEXT10")
            NR.Item("ListDisplay") = NR.Item("Rule").ToString & " - Style: " & NR.Item("TStyle").ToString & " - Layer:" & NR.Item("TLayer").ToString
            NR.Item("Scale") = txtNonAnnotativeScale.Text
            TextSettings_DS.Tables("Rules").Rows.Add(NR)
            NR = Nothing

            '' TEXT11 Rule ' Text layer for 35 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtLay35, "TEXT11", sWhatToShow, sWhatToUse, "CLAYER", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            '' TEXT12 Rule ' Text style for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtSty35, "TEXT12", sWhatToShow, sWhatToUse, "TEXTSTYLE", jacobs.Utilities.ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            '' TEXT13 Rule ' Text colour for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtCol35, "TEXT13", sWhatToShow, sWhatToUse, "CECOLOR", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            '' TEXT14 Rule
            'jacobs.Utilities.PopulateComboBox(TxtJust35, "TEXT14", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)
            NR = TextSettings_DS.Tables("Rules").NewRow
            NR.Item("Rule") = "3.5mm Text Rule"
            NR.Item("THeight") = "3.5"
            NR.Item("TLayer") = GetruleValue("TEXT11")
            NR.Item("TStyle") = GetruleValue("TEXT12")
            NR.Item("TColor") = GetruleValue("TEXT13")
            'NR.Item("Justification_Not USED") = jacobs.GetRule("TEXT14")
            NR.Item("ListDisplay") = NR.Item("Rule").ToString & " - Style: " & NR.Item("TStyle").ToString & " - Layer:" & NR.Item("TLayer").ToString
            NR.Item("Scale") = txtNonAnnotativeScale.Text
            TextSettings_DS.Tables("Rules").Rows.Add(NR)
            NR = Nothing

            '' TEXT15 Rule ' Text layer for 50 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtLay50, "TEXT15", sWhatToShow, sWhatToUse, "CLAYER", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            '' TEXT16 Rule ' Text style for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtSty50, "TEXT16", sWhatToShow, sWhatToUse, "TEXTSTYLE", jacobs.Utilities.ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            '' TEXT17 Rule ' Text colour for 18 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtCol50, "TEXT17", sWhatToShow, sWhatToUse, "CECOLOR", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            '' TEXT18 Rule
            'jacobs.Utilities.PopulateComboBox(TxtJust50, "TEXT18", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)
            NR = TextSettings_DS.Tables("Rules").NewRow
            NR.Item("Rule") = "5.0mm Text Rule"
            NR.Item("THeight") = "5.0"
            NR.Item("TLayer") = GetruleValue("TEXT15")
            NR.Item("TStyle") = GetruleValue("TEXT16")
            NR.Item("TColor") = GetruleValue("TEXT17")
            'NR.Item("Justification_Not USED") = jacobs.GetRule("TEXT18")
            NR.Item("ListDisplay") = NR.Item("Rule").ToString & " - Style: " & NR.Item("TStyle").ToString & " - Layer:" & NR.Item("TLayer").ToString
            NR.Item("Scale") = txtNonAnnotativeScale.Text
            TextSettings_DS.Tables("Rules").Rows.Add(NR)
            NR = Nothing

            '' TEXT19 Rule ' Text layer for 70 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtLay70, "TEXT19", sWhatToShow, sWhatToUse, "CLAYER", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)
            '' TEXT20 Rule ' Text style for 70 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtSty70, "TEXT20", sWhatToShow, sWhatToUse, "TEXTSTYLE", jacobs.Utilities.ThisDrawingUtilities.GetVariable("TEXTSTYLE").ToString, bIgnoreOverrides)
            '' TEXT21 Rule ' Text colour for 70 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtCol70, "TEXT21", sWhatToShow, sWhatToUse, "CECOLOR", jacobs.Utilities.ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)
            '' TEXT22 Rule ' Text colour for 70 unit high text
            'jacobs.Utilities.PopulateComboBox(TxtJust70, "TEXT22", sWhatToShow, sWhatToUse, "TEXTJUSTIFICATION", "BL", bIgnoreOverrides)
            NR = TextSettings_DS.Tables("Rules").NewRow
            NR.Item("Rule") = "7.0mm Text Rule"
            NR.Item("THeight") = "7.0" '"TxtLay70"
            NR.Item("TLayer") = GetruleValue("TEXT19")
            NR.Item("TStyle") = GetruleValue("TEXT20")
            NR.Item("TColor") = GetruleValue("TEXT21")
            'NR.Item("Justification_Not USED") = jacobs.GetRule("TEXT22")
            NR.Item("ListDisplay") = NR.Item("Rule").ToString & " - Style: " & NR.Item("TStyle").ToString & " - Layer:" & NR.Item("TLayer").ToString
            NR.Item("Scale") = txtNonAnnotativeScale.Text
            TextSettings_DS.Tables("Rules").Rows.Add(NR)
            NR = Nothing

            lstPreSetTextConfig.DataSource = TextSettings_DS.Tables("Rules")
            lstPreSetTextConfig.ValueMember = "Rule"
            lstPreSetTextConfig.DisplayMember = "ListDisplay"

            'Disabled Steven Houghton 29/09/17
            'cboTJustification.DataSource = TextSettings_DS.Tables("TJustification")
            'cboTJustification.ValueMember = "ShortName"
            'cboTJustification.DisplayMember = "ListDisplay"

        Catch ex As Exception

            '' Generic Error Message to handle exceptions - uses reflection to work out where the error was generated.

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

    End Sub
End Class
