﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class P4_Options
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxCommonOptions = New System.Windows.Forms.GroupBox()
        Me.chkAnnoDisplay = New System.Windows.Forms.CheckBox()
        Me.chkChangeSysVars_ViewPorts = New System.Windows.Forms.CheckBox()
        Me.chkChangeSysVars_Layout = New System.Windows.Forms.CheckBox()
        Me.sstStatus = New System.Windows.Forms.StatusStrip()
        Me.tssMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxTextOptions = New System.Windows.Forms.GroupBox()
        Me.chkAutoStyleText = New System.Windows.Forms.CheckBox()
        Me.chkAutoLayerText = New System.Windows.Forms.CheckBox()
        Me.chkTextFill = New System.Windows.Forms.CheckBox()
        Me.chkMirrorText = New System.Windows.Forms.CheckBox()
        Me.gbxDimensionOptions = New System.Windows.Forms.GroupBox()
        Me.chkAutoStyleDim = New System.Windows.Forms.CheckBox()
        Me.chkAutoLayerDim = New System.Windows.Forms.CheckBox()
        Me.UseDIMVarsToOverride = New System.Windows.Forms.CheckBox()
        Me.gbxCommonOptions.SuspendLayout()
        Me.sstStatus.SuspendLayout()
        Me.gbxTextOptions.SuspendLayout()
        Me.gbxDimensionOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxCommonOptions
        '
        Me.gbxCommonOptions.Controls.Add(Me.chkAnnoDisplay)
        Me.gbxCommonOptions.Controls.Add(Me.chkChangeSysVars_ViewPorts)
        Me.gbxCommonOptions.Controls.Add(Me.chkChangeSysVars_Layout)
        Me.gbxCommonOptions.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxCommonOptions.Location = New System.Drawing.Point(6, 6)
        Me.gbxCommonOptions.Name = "gbxCommonOptions"
        Me.gbxCommonOptions.Size = New System.Drawing.Size(338, 100)
        Me.gbxCommonOptions.TabIndex = 52
        Me.gbxCommonOptions.TabStop = False
        Me.gbxCommonOptions.Text = "Common Options"
        '
        'chkAnnoDisplay
        '
        Me.chkAnnoDisplay.BackColor = System.Drawing.Color.Transparent
        Me.chkAnnoDisplay.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkAnnoDisplay.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkAnnoDisplay.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkAnnoDisplay.Location = New System.Drawing.Point(3, 56)
        Me.chkAnnoDisplay.Name = "chkAnnoDisplay"
        Me.chkAnnoDisplay.Padding = New System.Windows.Forms.Padding(6, 12, 0, 0)
        Me.chkAnnoDisplay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkAnnoDisplay.Size = New System.Drawing.Size(332, 34)
        Me.chkAnnoDisplay.TabIndex = 7
        Me.chkAnnoDisplay.Text = "Toggle Display on Annotative Objects"
        Me.chkAnnoDisplay.UseVisualStyleBackColor = False
        '
        'chkChangeSysVars_ViewPorts
        '
        Me.chkChangeSysVars_ViewPorts.AutoSize = True
        Me.chkChangeSysVars_ViewPorts.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkChangeSysVars_ViewPorts.Location = New System.Drawing.Point(3, 36)
        Me.chkChangeSysVars_ViewPorts.Name = "chkChangeSysVars_ViewPorts"
        Me.chkChangeSysVars_ViewPorts.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkChangeSysVars_ViewPorts.Size = New System.Drawing.Size(332, 20)
        Me.chkChangeSysVars_ViewPorts.TabIndex = 3
        Me.chkChangeSysVars_ViewPorts.Text = "Change system variables when Switching Viewports"
        Me.chkChangeSysVars_ViewPorts.UseVisualStyleBackColor = True
        '
        'chkChangeSysVars_Layout
        '
        Me.chkChangeSysVars_Layout.AutoSize = True
        Me.chkChangeSysVars_Layout.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkChangeSysVars_Layout.Location = New System.Drawing.Point(3, 16)
        Me.chkChangeSysVars_Layout.Name = "chkChangeSysVars_Layout"
        Me.chkChangeSysVars_Layout.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkChangeSysVars_Layout.Size = New System.Drawing.Size(332, 20)
        Me.chkChangeSysVars_Layout.TabIndex = 2
        Me.chkChangeSysVars_Layout.Text = "Change system variables when Switching Layouts"
        Me.chkChangeSysVars_Layout.UseVisualStyleBackColor = True
        '
        'sstStatus
        '
        Me.sstStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tssMessage})
        Me.sstStatus.Location = New System.Drawing.Point(6, 452)
        Me.sstStatus.Name = "sstStatus"
        Me.sstStatus.Size = New System.Drawing.Size(338, 22)
        Me.sstStatus.TabIndex = 53
        Me.sstStatus.Text = "StatusStrip1"
        '
        'tssMessage
        '
        Me.tssMessage.Name = "tssMessage"
        Me.tssMessage.Size = New System.Drawing.Size(22, 17)
        Me.tssMessage.Text = "xxx"
        '
        'gbxTextOptions
        '
        Me.gbxTextOptions.Controls.Add(Me.chkAutoStyleText)
        Me.gbxTextOptions.Controls.Add(Me.chkAutoLayerText)
        Me.gbxTextOptions.Controls.Add(Me.chkTextFill)
        Me.gbxTextOptions.Controls.Add(Me.chkMirrorText)
        Me.gbxTextOptions.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxTextOptions.Location = New System.Drawing.Point(6, 106)
        Me.gbxTextOptions.Name = "gbxTextOptions"
        Me.gbxTextOptions.Size = New System.Drawing.Size(338, 123)
        Me.gbxTextOptions.TabIndex = 54
        Me.gbxTextOptions.TabStop = False
        Me.gbxTextOptions.Text = "Text Options"
        '
        'chkAutoStyleText
        '
        Me.chkAutoStyleText.AutoSize = True
        Me.chkAutoStyleText.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkAutoStyleText.Location = New System.Drawing.Point(3, 88)
        Me.chkAutoStyleText.Name = "chkAutoStyleText"
        Me.chkAutoStyleText.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkAutoStyleText.Size = New System.Drawing.Size(332, 20)
        Me.chkAutoStyleText.TabIndex = 11
        Me.chkAutoStyleText.Text = "Auto Assign Style to Dimensions"
        Me.chkAutoStyleText.UseVisualStyleBackColor = True
        '
        'chkAutoLayerText
        '
        Me.chkAutoLayerText.AutoSize = True
        Me.chkAutoLayerText.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkAutoLayerText.Location = New System.Drawing.Point(3, 59)
        Me.chkAutoLayerText.Name = "chkAutoLayerText"
        Me.chkAutoLayerText.Padding = New System.Windows.Forms.Padding(6, 12, 0, 0)
        Me.chkAutoLayerText.Size = New System.Drawing.Size(332, 29)
        Me.chkAutoLayerText.TabIndex = 8
        Me.chkAutoLayerText.Text = "Auto Layer Text"
        Me.chkAutoLayerText.UseVisualStyleBackColor = True
        '
        'chkTextFill
        '
        Me.chkTextFill.AutoSize = True
        Me.chkTextFill.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkTextFill.Location = New System.Drawing.Point(3, 39)
        Me.chkTextFill.Name = "chkTextFill"
        Me.chkTextFill.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkTextFill.Size = New System.Drawing.Size(332, 20)
        Me.chkTextFill.TabIndex = 7
        Me.chkTextFill.Text = "Text Fill"
        Me.chkTextFill.UseVisualStyleBackColor = True
        '
        'chkMirrorText
        '
        Me.chkMirrorText.AutoSize = True
        Me.chkMirrorText.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkMirrorText.Location = New System.Drawing.Point(3, 16)
        Me.chkMirrorText.Name = "chkMirrorText"
        Me.chkMirrorText.Padding = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.chkMirrorText.Size = New System.Drawing.Size(332, 23)
        Me.chkMirrorText.TabIndex = 6
        Me.chkMirrorText.Text = "Mirror Text"
        Me.chkMirrorText.UseVisualStyleBackColor = True
        '
        'gbxDimensionOptions
        '
        Me.gbxDimensionOptions.Controls.Add(Me.chkAutoStyleDim)
        Me.gbxDimensionOptions.Controls.Add(Me.chkAutoLayerDim)
        Me.gbxDimensionOptions.Controls.Add(Me.UseDIMVarsToOverride)
        Me.gbxDimensionOptions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbxDimensionOptions.Location = New System.Drawing.Point(6, 229)
        Me.gbxDimensionOptions.Name = "gbxDimensionOptions"
        Me.gbxDimensionOptions.Size = New System.Drawing.Size(338, 223)
        Me.gbxDimensionOptions.TabIndex = 55
        Me.gbxDimensionOptions.TabStop = False
        Me.gbxDimensionOptions.Text = "Dimension Options"
        '
        'chkAutoStyleDim
        '
        Me.chkAutoStyleDim.AutoSize = True
        Me.chkAutoStyleDim.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkAutoStyleDim.Location = New System.Drawing.Point(3, 83)
        Me.chkAutoStyleDim.Name = "chkAutoStyleDim"
        Me.chkAutoStyleDim.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkAutoStyleDim.Size = New System.Drawing.Size(332, 20)
        Me.chkAutoStyleDim.TabIndex = 10
        Me.chkAutoStyleDim.Text = "Auto Assign Style to Dimensions"
        Me.chkAutoStyleDim.UseVisualStyleBackColor = True
        '
        'chkAutoLayerDim
        '
        Me.chkAutoLayerDim.AutoSize = True
        Me.chkAutoLayerDim.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkAutoLayerDim.Location = New System.Drawing.Point(3, 54)
        Me.chkAutoLayerDim.Name = "chkAutoLayerDim"
        Me.chkAutoLayerDim.Padding = New System.Windows.Forms.Padding(6, 12, 0, 0)
        Me.chkAutoLayerDim.Size = New System.Drawing.Size(332, 29)
        Me.chkAutoLayerDim.TabIndex = 9
        Me.chkAutoLayerDim.Text = "Auto Layer Dimensions"
        Me.chkAutoLayerDim.UseVisualStyleBackColor = True
        '
        'UseDIMVarsToOverride
        '
        Me.UseDIMVarsToOverride.BackColor = System.Drawing.Color.Transparent
        Me.UseDIMVarsToOverride.Cursor = System.Windows.Forms.Cursors.Default
        Me.UseDIMVarsToOverride.Dock = System.Windows.Forms.DockStyle.Top
        Me.UseDIMVarsToOverride.ForeColor = System.Drawing.SystemColors.ControlText
        Me.UseDIMVarsToOverride.Location = New System.Drawing.Point(3, 16)
        Me.UseDIMVarsToOverride.Name = "UseDIMVarsToOverride"
        Me.UseDIMVarsToOverride.Padding = New System.Windows.Forms.Padding(6, 6, 0, 0)
        Me.UseDIMVarsToOverride.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.UseDIMVarsToOverride.Size = New System.Drawing.Size(332, 38)
        Me.UseDIMVarsToOverride.TabIndex = 7
        Me.UseDIMVarsToOverride.Text = "Use a single Dimension Style by overriding the style values"
        Me.UseDIMVarsToOverride.UseVisualStyleBackColor = False
        '
        'P4_Options
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.gbxDimensionOptions)
        Me.Controls.Add(Me.gbxTextOptions)
        Me.Controls.Add(Me.gbxCommonOptions)
        Me.Controls.Add(Me.sstStatus)
        Me.Name = "P4_Options"
        Me.Padding = New System.Windows.Forms.Padding(6)
        Me.Size = New System.Drawing.Size(350, 480)
        Me.gbxCommonOptions.ResumeLayout(False)
        Me.gbxCommonOptions.PerformLayout()
        Me.sstStatus.ResumeLayout(False)
        Me.sstStatus.PerformLayout()
        Me.gbxTextOptions.ResumeLayout(False)
        Me.gbxTextOptions.PerformLayout()
        Me.gbxDimensionOptions.ResumeLayout(False)
        Me.gbxDimensionOptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxCommonOptions As System.Windows.Forms.GroupBox
    Friend WithEvents chkChangeSysVars_ViewPorts As System.Windows.Forms.CheckBox
    Friend WithEvents chkChangeSysVars_Layout As System.Windows.Forms.CheckBox
    Friend WithEvents sstStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents tssMessage As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents chkAnnoDisplay As System.Windows.Forms.CheckBox
    Friend WithEvents gbxTextOptions As System.Windows.Forms.GroupBox
    Friend WithEvents chkAutoStyleText As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoLayerText As System.Windows.Forms.CheckBox
    Friend WithEvents chkTextFill As System.Windows.Forms.CheckBox
    Friend WithEvents chkMirrorText As System.Windows.Forms.CheckBox
    Friend WithEvents gbxDimensionOptions As System.Windows.Forms.GroupBox
    Friend WithEvents chkAutoStyleDim As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoLayerDim As System.Windows.Forms.CheckBox
    Public WithEvents UseDIMVarsToOverride As System.Windows.Forms.CheckBox

End Class
