﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class P2_Dimension
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(P2_Dimension))
        Me.gbxDimensionOptions = New System.Windows.Forms.GroupBox()
        Me.pnlCfgSet_DimLayer = New System.Windows.Forms.Panel()
        Me.cboDimLayer = New System.Windows.Forms.ComboBox()
        Me.lblDimLayer = New System.Windows.Forms.Label()
        Me.pnlCfgSet_DimStyle = New System.Windows.Forms.Panel()
        Me.lblDimStyle = New System.Windows.Forms.Label()
        Me.cboDimStyle = New System.Windows.Forms.ComboBox()
        Me.pnlCfgSet_DimColor = New System.Windows.Forms.Panel()
        Me.lblDimColor = New System.Windows.Forms.Label()
        Me.cmdDimColor = New System.Windows.Forms.Button()
        Me.cboDimColor = New System.Windows.Forms.ComboBox()
        Me.pnlUseClientSettings = New System.Windows.Forms.Panel()
        Me.chkUseClientConfig = New System.Windows.Forms.CheckBox()
        Me.pnlAnnotatativeOptions = New System.Windows.Forms.Panel()
        Me.rbNonAnnotative = New System.Windows.Forms.RadioButton()
        Me.rbAnnotative = New System.Windows.Forms.RadioButton()
        Me.sstStatus = New System.Windows.Forms.StatusStrip()
        Me.tssMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxAnnotativeScales = New System.Windows.Forms.GroupBox()
        Me.gbxNonAnnotaiveScales = New System.Windows.Forms.GroupBox()
        Me.LTScaleViewTextBox = New System.Windows.Forms.TextBox()
        Me.LTScaleViewTextBoxLabel = New System.Windows.Forms.Label()
        Me.LTScaleCompensator = New System.Windows.Forms.TextBox()
        Me.LTScaleCompensatorlbl = New System.Windows.Forms.Label()
        Me.newLTSCALElbl = New System.Windows.Forms.Label()
        Me.newLTSCALETextBox = New System.Windows.Forms.TextBox()
        Me.txtDimScale = New System.Windows.Forms.TextBox()
        Me.lblDimScale = New System.Windows.Forms.Label()
        Me.lblDimUnits = New System.Windows.Forms.Label()
        Me.cboNonAnnotativeScales = New System.Windows.Forms.ComboBox()
        Me.cboNonAnnotativeUnits = New System.Windows.Forms.ComboBox()
        Me.lblDimScales = New System.Windows.Forms.Label()
        Me.lstAnnotativeScales = New System.Windows.Forms.ListBox()
        Me.gbxAnnotativeTypes = New System.Windows.Forms.GroupBox()
        Me.cmdDimContinue = New System.Windows.Forms.Button()
        Me.cmdDimArc = New System.Windows.Forms.Button()
        Me.cmdDimDia = New System.Windows.Forms.Button()
        Me.cmdDimAlign = New System.Windows.Forms.Button()
        Me.cmdDimHVAlign = New System.Windows.Forms.Button()
        Me.gbxDimensionOptions.SuspendLayout()
        Me.pnlCfgSet_DimLayer.SuspendLayout()
        Me.pnlCfgSet_DimStyle.SuspendLayout()
        Me.pnlCfgSet_DimColor.SuspendLayout()
        Me.pnlUseClientSettings.SuspendLayout()
        Me.pnlAnnotatativeOptions.SuspendLayout()
        Me.sstStatus.SuspendLayout()
        Me.gbxAnnotativeScales.SuspendLayout()
        Me.gbxNonAnnotaiveScales.SuspendLayout()
        Me.gbxAnnotativeTypes.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxDimensionOptions
        '
        Me.gbxDimensionOptions.Controls.Add(Me.pnlCfgSet_DimLayer)
        Me.gbxDimensionOptions.Controls.Add(Me.pnlCfgSet_DimStyle)
        Me.gbxDimensionOptions.Controls.Add(Me.pnlCfgSet_DimColor)
        Me.gbxDimensionOptions.Controls.Add(Me.pnlUseClientSettings)
        Me.gbxDimensionOptions.Controls.Add(Me.pnlAnnotatativeOptions)
        Me.gbxDimensionOptions.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxDimensionOptions.Location = New System.Drawing.Point(6, 6)
        Me.gbxDimensionOptions.Name = "gbxDimensionOptions"
        Me.gbxDimensionOptions.Padding = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.gbxDimensionOptions.Size = New System.Drawing.Size(269, 149)
        Me.gbxDimensionOptions.TabIndex = 1
        Me.gbxDimensionOptions.TabStop = False
        Me.gbxDimensionOptions.Text = "Dimension Options"
        '
        'pnlCfgSet_DimLayer
        '
        Me.pnlCfgSet_DimLayer.Controls.Add(Me.cboDimLayer)
        Me.pnlCfgSet_DimLayer.Controls.Add(Me.lblDimLayer)
        Me.pnlCfgSet_DimLayer.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlCfgSet_DimLayer.Location = New System.Drawing.Point(6, 119)
        Me.pnlCfgSet_DimLayer.MaximumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_DimLayer.MinimumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_DimLayer.Name = "pnlCfgSet_DimLayer"
        Me.pnlCfgSet_DimLayer.Padding = New System.Windows.Forms.Padding(2)
        Me.pnlCfgSet_DimLayer.Size = New System.Drawing.Size(257, 25)
        Me.pnlCfgSet_DimLayer.TabIndex = 11
        '
        'cboDimLayer
        '
        Me.cboDimLayer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDimLayer.FormattingEnabled = True
        Me.cboDimLayer.Location = New System.Drawing.Point(73, 2)
        Me.cboDimLayer.Name = "cboDimLayer"
        Me.cboDimLayer.Size = New System.Drawing.Size(177, 21)
        Me.cboDimLayer.TabIndex = 1
        '
        'lblDimLayer
        '
        Me.lblDimLayer.AutoSize = True
        Me.lblDimLayer.Location = New System.Drawing.Point(5, 8)
        Me.lblDimLayer.Name = "lblDimLayer"
        Me.lblDimLayer.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.lblDimLayer.Size = New System.Drawing.Size(60, 15)
        Me.lblDimLayer.TabIndex = 0
        Me.lblDimLayer.Text = "Dim Layer: "
        '
        'pnlCfgSet_DimStyle
        '
        Me.pnlCfgSet_DimStyle.Controls.Add(Me.lblDimStyle)
        Me.pnlCfgSet_DimStyle.Controls.Add(Me.cboDimStyle)
        Me.pnlCfgSet_DimStyle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlCfgSet_DimStyle.Location = New System.Drawing.Point(6, 94)
        Me.pnlCfgSet_DimStyle.MaximumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_DimStyle.MinimumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_DimStyle.Name = "pnlCfgSet_DimStyle"
        Me.pnlCfgSet_DimStyle.Padding = New System.Windows.Forms.Padding(2)
        Me.pnlCfgSet_DimStyle.Size = New System.Drawing.Size(257, 25)
        Me.pnlCfgSet_DimStyle.TabIndex = 10
        '
        'lblDimStyle
        '
        Me.lblDimStyle.AutoSize = True
        Me.lblDimStyle.Location = New System.Drawing.Point(5, 6)
        Me.lblDimStyle.Name = "lblDimStyle"
        Me.lblDimStyle.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.lblDimStyle.Size = New System.Drawing.Size(57, 15)
        Me.lblDimStyle.TabIndex = 0
        Me.lblDimStyle.Text = "Dim Style: "
        '
        'cboDimStyle
        '
        Me.cboDimStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDimStyle.FormattingEnabled = True
        Me.cboDimStyle.Location = New System.Drawing.Point(74, 0)
        Me.cboDimStyle.Name = "cboDimStyle"
        Me.cboDimStyle.Size = New System.Drawing.Size(176, 21)
        Me.cboDimStyle.TabIndex = 1
        '
        'pnlCfgSet_DimColor
        '
        Me.pnlCfgSet_DimColor.Controls.Add(Me.lblDimColor)
        Me.pnlCfgSet_DimColor.Controls.Add(Me.cmdDimColor)
        Me.pnlCfgSet_DimColor.Controls.Add(Me.cboDimColor)
        Me.pnlCfgSet_DimColor.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlCfgSet_DimColor.Location = New System.Drawing.Point(6, 69)
        Me.pnlCfgSet_DimColor.MaximumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_DimColor.MinimumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_DimColor.Name = "pnlCfgSet_DimColor"
        Me.pnlCfgSet_DimColor.Padding = New System.Windows.Forms.Padding(2)
        Me.pnlCfgSet_DimColor.Size = New System.Drawing.Size(257, 25)
        Me.pnlCfgSet_DimColor.TabIndex = 12
        '
        'lblDimColor
        '
        Me.lblDimColor.AutoSize = True
        Me.lblDimColor.Location = New System.Drawing.Point(6, 6)
        Me.lblDimColor.Name = "lblDimColor"
        Me.lblDimColor.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.lblDimColor.Size = New System.Drawing.Size(58, 15)
        Me.lblDimColor.TabIndex = 0
        Me.lblDimColor.Text = "Dim Color: "
        '
        'cmdDimColor
        '
        Me.cmdDimColor.Location = New System.Drawing.Point(229, 2)
        Me.cmdDimColor.Name = "cmdDimColor"
        Me.cmdDimColor.Size = New System.Drawing.Size(21, 21)
        Me.cmdDimColor.TabIndex = 3
        Me.cmdDimColor.UseVisualStyleBackColor = True
        '
        'cboDimColor
        '
        Me.cboDimColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDimColor.FormattingEnabled = True
        Me.cboDimColor.Location = New System.Drawing.Point(74, 2)
        Me.cboDimColor.Name = "cboDimColor"
        Me.cboDimColor.Size = New System.Drawing.Size(150, 21)
        Me.cboDimColor.TabIndex = 4
        '
        'pnlUseClientSettings
        '
        Me.pnlUseClientSettings.Controls.Add(Me.chkUseClientConfig)
        Me.pnlUseClientSettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlUseClientSettings.Location = New System.Drawing.Point(6, 41)
        Me.pnlUseClientSettings.Name = "pnlUseClientSettings"
        Me.pnlUseClientSettings.Size = New System.Drawing.Size(257, 28)
        Me.pnlUseClientSettings.TabIndex = 17
        '
        'chkUseClientConfig
        '
        Me.chkUseClientConfig.AutoSize = True
        Me.chkUseClientConfig.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkUseClientConfig.Location = New System.Drawing.Point(0, 0)
        Me.chkUseClientConfig.Name = "chkUseClientConfig"
        Me.chkUseClientConfig.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkUseClientConfig.Size = New System.Drawing.Size(257, 20)
        Me.chkUseClientConfig.TabIndex = 2
        Me.chkUseClientConfig.Text = "Use Client Settings"
        Me.chkUseClientConfig.UseVisualStyleBackColor = True
        '
        'pnlAnnotatativeOptions
        '
        Me.pnlAnnotatativeOptions.Controls.Add(Me.rbNonAnnotative)
        Me.pnlAnnotatativeOptions.Controls.Add(Me.rbAnnotative)
        Me.pnlAnnotatativeOptions.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlAnnotatativeOptions.Location = New System.Drawing.Point(6, 16)
        Me.pnlAnnotatativeOptions.Name = "pnlAnnotatativeOptions"
        Me.pnlAnnotatativeOptions.Size = New System.Drawing.Size(257, 25)
        Me.pnlAnnotatativeOptions.TabIndex = 16
        '
        'rbNonAnnotative
        '
        Me.rbNonAnnotative.AutoSize = True
        Me.rbNonAnnotative.Checked = True
        Me.rbNonAnnotative.Location = New System.Drawing.Point(6, 3)
        Me.rbNonAnnotative.Name = "rbNonAnnotative"
        Me.rbNonAnnotative.Size = New System.Drawing.Size(99, 17)
        Me.rbNonAnnotative.TabIndex = 14
        Me.rbNonAnnotative.TabStop = True
        Me.rbNonAnnotative.Text = "Non-Annotative"
        Me.rbNonAnnotative.UseVisualStyleBackColor = True
        '
        'rbAnnotative
        '
        Me.rbAnnotative.AutoSize = True
        Me.rbAnnotative.Location = New System.Drawing.Point(111, 3)
        Me.rbAnnotative.Name = "rbAnnotative"
        Me.rbAnnotative.Size = New System.Drawing.Size(76, 17)
        Me.rbAnnotative.TabIndex = 15
        Me.rbAnnotative.Text = "Annotative"
        Me.rbAnnotative.UseVisualStyleBackColor = True
        '
        'sstStatus
        '
        Me.sstStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tssMessage})
        Me.sstStatus.Location = New System.Drawing.Point(6, 597)
        Me.sstStatus.Name = "sstStatus"
        Me.sstStatus.Size = New System.Drawing.Size(269, 22)
        Me.sstStatus.TabIndex = 51
        Me.sstStatus.Text = "StatusStrip1"
        '
        'tssMessage
        '
        Me.tssMessage.Name = "tssMessage"
        Me.tssMessage.Size = New System.Drawing.Size(22, 17)
        Me.tssMessage.Text = "xxx"
        '
        'gbxAnnotativeScales
        '
        Me.gbxAnnotativeScales.Controls.Add(Me.gbxNonAnnotaiveScales)
        Me.gbxAnnotativeScales.Controls.Add(Me.lstAnnotativeScales)
        Me.gbxAnnotativeScales.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxAnnotativeScales.Location = New System.Drawing.Point(6, 219)
        Me.gbxAnnotativeScales.MinimumSize = New System.Drawing.Size(150, 0)
        Me.gbxAnnotativeScales.Name = "gbxAnnotativeScales"
        Me.gbxAnnotativeScales.Padding = New System.Windows.Forms.Padding(6)
        Me.gbxAnnotativeScales.Size = New System.Drawing.Size(269, 260)
        Me.gbxAnnotativeScales.TabIndex = 53
        Me.gbxAnnotativeScales.TabStop = False
        Me.gbxAnnotativeScales.Text = "Additional Options"
        '
        'gbxNonAnnotaiveScales
        '
        Me.gbxNonAnnotaiveScales.BackColor = System.Drawing.SystemColors.Control
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.LTScaleViewTextBox)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.LTScaleViewTextBoxLabel)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.LTScaleCompensator)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.LTScaleCompensatorlbl)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.newLTSCALElbl)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.newLTSCALETextBox)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.txtDimScale)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.lblDimScale)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.lblDimUnits)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.cboNonAnnotativeScales)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.cboNonAnnotativeUnits)
        Me.gbxNonAnnotaiveScales.Controls.Add(Me.lblDimScales)
        Me.gbxNonAnnotaiveScales.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxNonAnnotaiveScales.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.gbxNonAnnotaiveScales.Location = New System.Drawing.Point(6, 19)
        Me.gbxNonAnnotaiveScales.Name = "gbxNonAnnotaiveScales"
        Me.gbxNonAnnotaiveScales.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.gbxNonAnnotaiveScales.Size = New System.Drawing.Size(257, 101)
        Me.gbxNonAnnotaiveScales.TabIndex = 22
        Me.gbxNonAnnotaiveScales.TabStop = False
        Me.gbxNonAnnotaiveScales.Text = "Drawing Scale"
        Me.gbxNonAnnotaiveScales.Visible = False
        '
        'LTScaleViewTextBox
        '
        Me.LTScaleViewTextBox.AcceptsReturn = True
        Me.LTScaleViewTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.LTScaleViewTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LTScaleViewTextBox.Enabled = False
        Me.LTScaleViewTextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LTScaleViewTextBox.Location = New System.Drawing.Point(143, 160)
        Me.LTScaleViewTextBox.MaxLength = 0
        Me.LTScaleViewTextBox.Name = "LTScaleViewTextBox"
        Me.LTScaleViewTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleViewTextBox.Size = New System.Drawing.Size(107, 20)
        Me.LTScaleViewTextBox.TabIndex = 40
        '
        'LTScaleViewTextBoxLabel
        '
        Me.LTScaleViewTextBoxLabel.AutoSize = True
        Me.LTScaleViewTextBoxLabel.BackColor = System.Drawing.SystemColors.Control
        Me.LTScaleViewTextBoxLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.LTScaleViewTextBoxLabel.Enabled = False
        Me.LTScaleViewTextBoxLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LTScaleViewTextBoxLabel.Location = New System.Drawing.Point(42, 163)
        Me.LTScaleViewTextBoxLabel.Name = "LTScaleViewTextBoxLabel"
        Me.LTScaleViewTextBoxLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleViewTextBoxLabel.Size = New System.Drawing.Size(87, 13)
        Me.LTScaleViewTextBoxLabel.TabIndex = 39
        Me.LTScaleViewTextBoxLabel.Text = "Line Type Scale:"
        '
        'LTScaleCompensator
        '
        Me.LTScaleCompensator.AcceptsReturn = True
        Me.LTScaleCompensator.BackColor = System.Drawing.SystemColors.Window
        Me.LTScaleCompensator.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LTScaleCompensator.Enabled = False
        Me.LTScaleCompensator.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LTScaleCompensator.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LTScaleCompensator.Location = New System.Drawing.Point(143, 129)
        Me.LTScaleCompensator.MaxLength = 0
        Me.LTScaleCompensator.Name = "LTScaleCompensator"
        Me.LTScaleCompensator.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleCompensator.Size = New System.Drawing.Size(107, 21)
        Me.LTScaleCompensator.TabIndex = 38
        '
        'LTScaleCompensatorlbl
        '
        Me.LTScaleCompensatorlbl.AutoSize = True
        Me.LTScaleCompensatorlbl.BackColor = System.Drawing.SystemColors.Control
        Me.LTScaleCompensatorlbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.LTScaleCompensatorlbl.Enabled = False
        Me.LTScaleCompensatorlbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LTScaleCompensatorlbl.ForeColor = System.Drawing.Color.Black
        Me.LTScaleCompensatorlbl.Location = New System.Drawing.Point(17, 132)
        Me.LTScaleCompensatorlbl.Name = "LTScaleCompensatorlbl"
        Me.LTScaleCompensatorlbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleCompensatorlbl.Size = New System.Drawing.Size(120, 13)
        Me.LTScaleCompensatorlbl.TabIndex = 37
        Me.LTScaleCompensatorlbl.Text = "LTSCALE Compensator:"
        Me.LTScaleCompensatorlbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'newLTSCALElbl
        '
        Me.newLTSCALElbl.AutoSize = True
        Me.newLTSCALElbl.BackColor = System.Drawing.SystemColors.Control
        Me.newLTSCALElbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.newLTSCALElbl.Enabled = False
        Me.newLTSCALElbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.newLTSCALElbl.Location = New System.Drawing.Point(43, 106)
        Me.newLTSCALElbl.Name = "newLTSCALElbl"
        Me.newLTSCALElbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newLTSCALElbl.Size = New System.Drawing.Size(90, 13)
        Me.newLTSCALElbl.TabIndex = 36
        Me.newLTSCALElbl.Text = "Global LTSCALE:"
        '
        'newLTSCALETextBox
        '
        Me.newLTSCALETextBox.AcceptsReturn = True
        Me.newLTSCALETextBox.BackColor = System.Drawing.SystemColors.Window
        Me.newLTSCALETextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.newLTSCALETextBox.Enabled = False
        Me.newLTSCALETextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.newLTSCALETextBox.Location = New System.Drawing.Point(144, 103)
        Me.newLTSCALETextBox.MaxLength = 0
        Me.newLTSCALETextBox.Name = "newLTSCALETextBox"
        Me.newLTSCALETextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newLTSCALETextBox.Size = New System.Drawing.Size(107, 20)
        Me.newLTSCALETextBox.TabIndex = 35
        '
        'txtDimScale
        '
        Me.txtDimScale.AcceptsReturn = True
        Me.txtDimScale.BackColor = System.Drawing.SystemColors.Window
        Me.txtDimScale.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDimScale.Enabled = False
        Me.txtDimScale.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDimScale.Location = New System.Drawing.Point(143, 73)
        Me.txtDimScale.MaxLength = 0
        Me.txtDimScale.Name = "txtDimScale"
        Me.txtDimScale.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDimScale.Size = New System.Drawing.Size(107, 20)
        Me.txtDimScale.TabIndex = 34
        '
        'lblDimScale
        '
        Me.lblDimScale.AutoSize = True
        Me.lblDimScale.BackColor = System.Drawing.SystemColors.Control
        Me.lblDimScale.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDimScale.Enabled = False
        Me.lblDimScale.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDimScale.Location = New System.Drawing.Point(42, 76)
        Me.lblDimScale.Name = "lblDimScale"
        Me.lblDimScale.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDimScale.Size = New System.Drawing.Size(89, 13)
        Me.lblDimScale.TabIndex = 33
        Me.lblDimScale.Text = "Dimension Scale:"
        '
        'lblDimUnits
        '
        Me.lblDimUnits.BackColor = System.Drawing.SystemColors.Control
        Me.lblDimUnits.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDimUnits.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDimUnits.ForeColor = System.Drawing.Color.Black
        Me.lblDimUnits.Location = New System.Drawing.Point(45, 46)
        Me.lblDimUnits.Name = "lblDimUnits"
        Me.lblDimUnits.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDimUnits.Size = New System.Drawing.Size(83, 19)
        Me.lblDimUnits.TabIndex = 25
        Me.lblDimUnits.Text = "Insertion Units:"
        '
        'cboNonAnnotativeScales
        '
        Me.cboNonAnnotativeScales.BackColor = System.Drawing.SystemColors.Window
        Me.cboNonAnnotativeScales.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboNonAnnotativeScales.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboNonAnnotativeScales.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboNonAnnotativeScales.Location = New System.Drawing.Point(143, 19)
        Me.cboNonAnnotativeScales.Name = "cboNonAnnotativeScales"
        Me.cboNonAnnotativeScales.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboNonAnnotativeScales.Size = New System.Drawing.Size(107, 21)
        Me.cboNonAnnotativeScales.TabIndex = 23
        '
        'cboNonAnnotativeUnits
        '
        Me.cboNonAnnotativeUnits.BackColor = System.Drawing.SystemColors.Window
        Me.cboNonAnnotativeUnits.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboNonAnnotativeUnits.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboNonAnnotativeUnits.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboNonAnnotativeUnits.Location = New System.Drawing.Point(143, 46)
        Me.cboNonAnnotativeUnits.Name = "cboNonAnnotativeUnits"
        Me.cboNonAnnotativeUnits.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboNonAnnotativeUnits.Size = New System.Drawing.Size(107, 21)
        Me.cboNonAnnotativeUnits.TabIndex = 26
        '
        'lblDimScales
        '
        Me.lblDimScales.BackColor = System.Drawing.SystemColors.Control
        Me.lblDimScales.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDimScales.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblDimScales.Location = New System.Drawing.Point(75, 22)
        Me.lblDimScales.Name = "lblDimScales"
        Me.lblDimScales.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDimScales.Size = New System.Drawing.Size(53, 19)
        Me.lblDimScales.TabIndex = 24
        Me.lblDimScales.Text = "Scale:"
        Me.lblDimScales.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lstAnnotativeScales
        '
        Me.lstAnnotativeScales.FormattingEnabled = True
        Me.lstAnnotativeScales.Location = New System.Drawing.Point(6, 19)
        Me.lstAnnotativeScales.Name = "lstAnnotativeScales"
        Me.lstAnnotativeScales.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstAnnotativeScales.Size = New System.Drawing.Size(257, 238)
        Me.lstAnnotativeScales.TabIndex = 13
        Me.lstAnnotativeScales.Visible = False
        '
        'gbxAnnotativeTypes
        '
        Me.gbxAnnotativeTypes.Controls.Add(Me.cmdDimContinue)
        Me.gbxAnnotativeTypes.Controls.Add(Me.cmdDimArc)
        Me.gbxAnnotativeTypes.Controls.Add(Me.cmdDimDia)
        Me.gbxAnnotativeTypes.Controls.Add(Me.cmdDimAlign)
        Me.gbxAnnotativeTypes.Controls.Add(Me.cmdDimHVAlign)
        Me.gbxAnnotativeTypes.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxAnnotativeTypes.Location = New System.Drawing.Point(6, 155)
        Me.gbxAnnotativeTypes.Name = "gbxAnnotativeTypes"
        Me.gbxAnnotativeTypes.Padding = New System.Windows.Forms.Padding(12, 6, 6, 6)
        Me.gbxAnnotativeTypes.Size = New System.Drawing.Size(269, 64)
        Me.gbxAnnotativeTypes.TabIndex = 54
        Me.gbxAnnotativeTypes.TabStop = False
        Me.gbxAnnotativeTypes.Text = "Type"
        '
        'cmdDimContinue
        '
        Me.cmdDimContinue.Image = CType(resources.GetObject("cmdDimContinue.Image"), System.Drawing.Image)
        Me.cmdDimContinue.Location = New System.Drawing.Point(140, 19)
        Me.cmdDimContinue.Name = "cmdDimContinue"
        Me.cmdDimContinue.Size = New System.Drawing.Size(27, 32)
        Me.cmdDimContinue.TabIndex = 4
        Me.cmdDimContinue.UseVisualStyleBackColor = True
        '
        'cmdDimArc
        '
        Me.cmdDimArc.Image = CType(resources.GetObject("cmdDimArc.Image"), System.Drawing.Image)
        Me.cmdDimArc.Location = New System.Drawing.Point(107, 19)
        Me.cmdDimArc.Name = "cmdDimArc"
        Me.cmdDimArc.Size = New System.Drawing.Size(27, 32)
        Me.cmdDimArc.TabIndex = 3
        Me.cmdDimArc.UseVisualStyleBackColor = True
        '
        'cmdDimDia
        '
        Me.cmdDimDia.Image = CType(resources.GetObject("cmdDimDia.Image"), System.Drawing.Image)
        Me.cmdDimDia.Location = New System.Drawing.Point(74, 19)
        Me.cmdDimDia.Name = "cmdDimDia"
        Me.cmdDimDia.Size = New System.Drawing.Size(27, 32)
        Me.cmdDimDia.TabIndex = 2
        Me.cmdDimDia.UseVisualStyleBackColor = True
        '
        'cmdDimAlign
        '
        Me.cmdDimAlign.Image = CType(resources.GetObject("cmdDimAlign.Image"), System.Drawing.Image)
        Me.cmdDimAlign.Location = New System.Drawing.Point(41, 19)
        Me.cmdDimAlign.Name = "cmdDimAlign"
        Me.cmdDimAlign.Size = New System.Drawing.Size(27, 32)
        Me.cmdDimAlign.TabIndex = 1
        Me.cmdDimAlign.UseVisualStyleBackColor = True
        '
        'cmdDimHVAlign
        '
        Me.cmdDimHVAlign.Image = CType(resources.GetObject("cmdDimHVAlign.Image"), System.Drawing.Image)
        Me.cmdDimHVAlign.Location = New System.Drawing.Point(8, 19)
        Me.cmdDimHVAlign.Name = "cmdDimHVAlign"
        Me.cmdDimHVAlign.Size = New System.Drawing.Size(27, 32)
        Me.cmdDimHVAlign.TabIndex = 0
        Me.cmdDimHVAlign.UseVisualStyleBackColor = True
        '
        'P2_Dimension
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.gbxAnnotativeScales)
        Me.Controls.Add(Me.gbxAnnotativeTypes)
        Me.Controls.Add(Me.sstStatus)
        Me.Controls.Add(Me.gbxDimensionOptions)
        Me.Name = "P2_Dimension"
        Me.Padding = New System.Windows.Forms.Padding(6)
        Me.Size = New System.Drawing.Size(281, 625)
        Me.gbxDimensionOptions.ResumeLayout(False)
        Me.pnlCfgSet_DimLayer.ResumeLayout(False)
        Me.pnlCfgSet_DimLayer.PerformLayout()
        Me.pnlCfgSet_DimStyle.ResumeLayout(False)
        Me.pnlCfgSet_DimStyle.PerformLayout()
        Me.pnlCfgSet_DimColor.ResumeLayout(False)
        Me.pnlCfgSet_DimColor.PerformLayout()
        Me.pnlUseClientSettings.ResumeLayout(False)
        Me.pnlUseClientSettings.PerformLayout()
        Me.pnlAnnotatativeOptions.ResumeLayout(False)
        Me.pnlAnnotatativeOptions.PerformLayout()
        Me.sstStatus.ResumeLayout(False)
        Me.sstStatus.PerformLayout()
        Me.gbxAnnotativeScales.ResumeLayout(False)
        Me.gbxNonAnnotaiveScales.ResumeLayout(False)
        Me.gbxNonAnnotaiveScales.PerformLayout()
        Me.gbxAnnotativeTypes.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxDimensionOptions As System.Windows.Forms.GroupBox
    Friend WithEvents chkUseClientConfig As System.Windows.Forms.CheckBox
    Friend WithEvents sstStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents tssMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbxAnnotativeScales As System.Windows.Forms.GroupBox
    Friend WithEvents lstAnnotativeScales As System.Windows.Forms.ListBox
    Friend WithEvents gbxAnnotativeTypes As System.Windows.Forms.GroupBox
    Friend WithEvents pnlCfgSet_DimLayer As System.Windows.Forms.Panel
    Friend WithEvents cboDimLayer As System.Windows.Forms.ComboBox
    Friend WithEvents lblDimLayer As System.Windows.Forms.Label
    Friend WithEvents pnlCfgSet_DimStyle As System.Windows.Forms.Panel
    Friend WithEvents cboDimStyle As System.Windows.Forms.ComboBox
    Friend WithEvents lblDimStyle As System.Windows.Forms.Label
    Friend WithEvents pnlCfgSet_DimColor As System.Windows.Forms.Panel
    Friend WithEvents cboDimColor As System.Windows.Forms.ComboBox
    Friend WithEvents cmdDimColor As System.Windows.Forms.Button
    Friend WithEvents lblDimColor As System.Windows.Forms.Label
    Public WithEvents gbxNonAnnotaiveScales As Windows.Forms.GroupBox
    Friend WithEvents rbNonAnnotative As Windows.Forms.RadioButton
    Friend WithEvents rbAnnotative As Windows.Forms.RadioButton
    Friend WithEvents pnlUseClientSettings As Windows.Forms.Panel
    Friend WithEvents pnlAnnotatativeOptions As Windows.Forms.Panel
    Friend WithEvents cmdDimContinue As Windows.Forms.Button
    Friend WithEvents cmdDimArc As Windows.Forms.Button
    Friend WithEvents cmdDimDia As Windows.Forms.Button
    Friend WithEvents cmdDimAlign As Windows.Forms.Button
    Friend WithEvents cmdDimHVAlign As Windows.Forms.Button
    Public WithEvents lblDimUnits As Windows.Forms.Label
    Public WithEvents cboNonAnnotativeScales As Windows.Forms.ComboBox
    Public WithEvents cboNonAnnotativeUnits As Windows.Forms.ComboBox
    Public WithEvents lblDimScales As Windows.Forms.Label
    Public WithEvents LTScaleViewTextBox As Windows.Forms.TextBox
    Public WithEvents LTScaleViewTextBoxLabel As Windows.Forms.Label
    Public WithEvents LTScaleCompensator As Windows.Forms.TextBox
    Public WithEvents LTScaleCompensatorlbl As Windows.Forms.Label
    Public WithEvents newLTSCALElbl As Windows.Forms.Label
    Public WithEvents newLTSCALETextBox As Windows.Forms.TextBox
    Public WithEvents txtDimScale As Windows.Forms.TextBox
    Public WithEvents lblDimScale As Windows.Forms.Label
End Class
