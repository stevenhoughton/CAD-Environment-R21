﻿
Imports System.IO
Imports System.Linq
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
'Imports Jacobs.AutoCAD.Utilities.GeometryExtensions
Imports System.Data
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources
Imports Autodesk.AutoCAD.ApplicationServices

Public Class P4_Options

    Private mUseSCESettings As Boolean = False

    Private mIsSyncing As Boolean = False

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        AddHandler Application.SystemVariableChanged, AddressOf UpdateDialogOptions

    End Sub

    Private Sub P4_Options_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        'Common Options
        'ChangeSysvars '- TODO
        'ChangeSysVarsVP '- TODO
        chkAnnoDisplay.Checked = GetSysVariable("ANNOALLVISIBLE").ToString.IsTrue

        'Text Options
        chkMirrorText.Checked = GetSysVariable("MIRRTEXT").ToString.IsTrue
        chkTextFill.Checked = GetSysVariable("TEXTFILL").ToString.IsTrue

        PopulateCheckBox(chkAutoLayerText, "TEXT31", GetruleValue("TEXT31", , False), , False, False) 'bIgnoreOverrides
        PopulateCheckBox(chkAutoStyleText, "TEXT32", GetruleValue("TEXT32", , False), , False, False) 'bIgnoreOverrides

        'Dimension Options
        PopulateCheckBox(chkAutoLayerDim, "DIM9", GetruleValue("DIM9", , False), , False, False) 'bIgnoreOverrides
        PopulateCheckBox(chkAutoStyleDim, "DIM10", GetruleValue("DIM10", , False), , False, False) 'bIgnoreOverrides

    End Sub

    Public WriteOnly Property PalletteEnable() As Boolean
        Set(value As Boolean)
            mUseSCESettings = value

            Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.UseAESettings = mUseSCESettings

            XEnabled(gbxCommonOptions, mUseSCESettings)
            XEnabled(gbxTextOptions, mUseSCESettings)
            XEnabled(gbxDimensionOptions, mUseSCESettings)

            Select Case mUseSCESettings
                Case True
                    tssMessage.Text = "Drawing is Configured"
                Case False
                    tssMessage.Text = "Drawing is Not Configured"
            End Select
        End Set
    End Property

    Private Sub chkMirrorText_CheckStateChanged(sender As Object, e As System.EventArgs)
        If mIsSyncing Then Exit Sub
        SetSysVariable("MIRRTEXT", chkMirrorText.Checked.AsZeroOne)
    End Sub

    Private Sub chkTextFill_CheckStateChanged(sender As Object, e As System.EventArgs)
        If mIsSyncing Then Exit Sub
        SetSysVariable("TEXTFILL", chkTextFill.Checked.AsZeroOne)
    End Sub

    Private Sub chkAnnoDisplay_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkAnnoDisplay.CheckStateChanged
        If mIsSyncing Then Exit Sub
        SetSysVariable("ANNOALLVISIBLE", chkAnnoDisplay.Checked.AsZeroOne)
    End Sub

    Private Sub UpdateDialogOptions(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.SystemVariableChangedEventArgs)

        If mUseSCESettings = False Then Exit Sub

        mIsSyncing = True
        Dim SysVarname As String = e.Name

        Select Case SysVarname
            Case "MIRRTEXT"
                chkMirrorText.Checked = GetSysVariable("MIRRTEXT").ToString.IsTrue
            Case "TEXTFILL"
                chkTextFill.Checked = GetSysVariable("TEXTFILL").ToString.IsTrue
            Case "ANNOALLVISIBLE"
                chkAnnoDisplay.Checked = GetSysVariable("ANNOALLVISIBLE").ToString.IsTrue
        End Select
        'Case "ANNOAUTOSCALE"

        mIsSyncing = False
    End Sub

    Private Sub ChangeSysvars_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkChangeSysVars_Layout.CheckStateChanged
        If chkChangeSysVars_Layout.CheckState = Windows.Forms.CheckState.Indeterminate Then Exit Sub
        RuleAccessors.RecordDglRule("TEXT23", chkChangeSysVars_Layout.Checked)
        ChangeTextSysVars()
        RuleAccessors.RecordDglRule("DIM6", chkChangeSysVars_Layout.Checked)
        ChangeDimensionSysVars()
        RuleAccessors.RecordDglRule("SCALE3", chkChangeSysVars_Layout.Checked)
        ChangeScaleSysVars()
    End Sub

    Private Sub ChangeSysVarsVP_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkChangeSysVars_ViewPorts.CheckStateChanged
        If chkChangeSysVars_ViewPorts.CheckState = Windows.Forms.CheckState.Indeterminate Then Exit Sub
        RuleAccessors.RecordDglRule("TEXT27", chkChangeSysVars_ViewPorts.Checked)
        ChangeTextSysVars()
        RuleAccessors.RecordDglRule("DIM8", chkChangeSysVars_ViewPorts.Checked)
        ChangeDimensionSysVars()
        RuleAccessors.RecordDglRule("SCALE14", chkChangeSysVars_ViewPorts.Checked)
        ChangeScaleSysVars()
    End Sub

End Class
