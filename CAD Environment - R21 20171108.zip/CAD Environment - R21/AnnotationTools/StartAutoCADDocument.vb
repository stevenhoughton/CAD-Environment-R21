﻿' (C) Copyright 2014 by Jacobs
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Internal
Imports Autodesk.AutoCAD.Runtime
Imports acApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Jacobs.AutoCAD.Utilities
Imports System
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings
'Imports Jacobs.AutoCAD.Utilities.GeometryExtensions
Imports System.IO
Imports AutoCADApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Autodesk.AutoCAD.Interop
Imports Jacobs.AutoCAD.SelectTemplate
Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.AnnotationTools.StartAutoCAD))>

' This class is instantiated by AutoCAD for each document when
' a command is called by the user the first time in the context
' of a given document. In other words, non static data in this class
' is implicitly per-document!
Public Class StartAutoCAD

    Dim SelectConfig As New SelectTemplate.TemplateSelector

    Private Shared m_ObjectType As ObjectId
    Friend Shared Pallette_Base As Autodesk.AutoCAD.Windows.PaletteSet
    'Friend Shared LayerEventTools As LayerEvent
    Friend Shared P1 As P1_Text
    Friend Shared P2 As P2_Dimension
    Friend Shared P3 As P3_Scale
    'Friend Shared P4 As P4_Options
    Private mUseClientSettings As Boolean = True
    Private mWorkFlowIndex As Integer = 0
    'Private IsInitializing As Boolean = True
    Private mPalleteIsEnabled As Boolean = False

    Public Sub DocumentActivated(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.DocumentCollectionEventArgs)

        'Check if Drawing is configured
        EnableDisablePallete = ThisDrawingIsConfigured()

    End Sub

    Public Property UseClientSettings() As Boolean
        Get
            Return mUseClientSettings
        End Get
        Set(ByVal value As Boolean)
            mUseClientSettings = value

            WorkingVariableAccessors.AddWorkVar("TEXTClientConfig", value)
            WorkingVariableAccessors.AddWorkVar("DIMENSIONSClientConfig", value)
            WorkingVariableAccessors.AddWorkVar("SCALEClientConfig", value)

            Dim ST As New StackTrace
            If P1 IsNot Nothing AndAlso ST.ToString.Contains("P1") = False Then P1.UseClientSettings = value
            If P2 IsNot Nothing AndAlso ST.ToString.Contains("P2") = False Then P2.UseClientSettings = value
            'If P3 IsNot Nothing AndAlso ST.ToString.Contains("P3") = False Then P3.UseClientSettings = value
        End Set
    End Property

    Public Property EnableDisablePallete() As Boolean
        Get
            Return mPalleteIsEnabled
        End Get
        Set(ByVal value As Boolean)
            If P1 IsNot Nothing Then P1.PalletteEnable = value
            If P2 IsNot Nothing Then P2.PalletteEnable = value
            If P3 IsNot Nothing Then P3.PalletteEnable = value
            'If P4 IsNot Nothing Then P4.PalletteEnable = value
        End Set
    End Property

    ''' <summary>
    ''' Primary command used to kick off the tool.
    ''' </summary>
    ''' <remarks></remarks>
    ''' , Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_AnnotationTools", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub JacobsAnnotationTools()

        Try

            Dim acDocs As DocumentCollection = acApp.DocumentManager
            Dim Doc As Document = acDocs.MdiActiveDocument
            Dim ed As Editor = doc.Editor
            Dim DB As Database = Doc.Database

            AddHandler acDocs.DocumentBecameCurrent, AddressOf DocumentActivated
            AddHandler acDocs.DocumentActivated, AddressOf DocumentActivated


            Dim DisplayDialog As Boolean = True

            ' Check to see if this tool needs to be configured. The flag for this is nominated by the developer and stored in 
            ' Check MustBeConfigure.txt file to see if the DLL needs a Configured drawing

            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then

                ' If it needs to be configured as per the reg key and it's not configured then 
                ' Call the generic function to allow user to select a configuration as this DWG is not configured and it needs to be.
                DisplayDialog = False

                SelectConfig.DisplayWarning()

                ' We gave the user the opportunity to configure the drawing - check that they have done that and not just canceled the 
                ' Select Configuration dialog

                If ThisDrawingIsConfigured() Then

                    ' Present them with the dialog box.
                    DisplayDialog = True

                End If

            Else

                'Get Work Flow Settings & Use Config Settings  'TODO - Create new Settings to be stored in Extension Dictionary


                '' There either was no need to have a configured drawing (most likely for a tool that does not use rules)
                '' Or the drawing is already configured and ready to go.
                If DisplayDialog Then

                    If Pallette_Base Is Nothing Then

                        P1 = New P1_Text(Me)
                        P2 = New P2_Dimension(Me)
                        P3 = New P3_Scale(Me)
                        'P4 = New P4_Options

                        Pallette_Base = New Autodesk.AutoCAD.Windows.PaletteSet("JACOBS Annotation Centre " & Settings.Manager.AE.Version)
                        'Pallette_Base.Icon =
                        Pallette_Base.Style = Autodesk.AutoCAD.Windows.PaletteSetStyles.ShowPropertiesMenu Or
                            Autodesk.AutoCAD.Windows.PaletteSetStyles.ShowAutoHideButton Or
                            Autodesk.AutoCAD.Windows.PaletteSetStyles.ShowCloseButton
                        Pallette_Base.Opacity = 90
                        Pallette_Base.Size = New System.Drawing.Size(350, 650)
                        Pallette_Base.MinimumSize = New System.Drawing.Size(350, 650)
                        Pallette_Base.Add("Text Tools", P1)
                        Pallette_Base.Add("Dimension Tools", P2)
                        Pallette_Base.Add("Scale Tools", P3)
                        'Pallette_Base.Add("Options", P4)
                        'You may or may not need the below code for list/combo boxes to retain focus.
                        Pallette_Base.KeepFocus = True
                        Pallette_Base.Dock = Autodesk.AutoCAD.Windows.DockSides.Left
                        'Pallette_Base.Dock = Autodesk.AutoCAD.Windows.DockSides.None
                        Pallette_Base.Visible = False
                        Pallette_Base.Visible = True
                        'CreateTimer()
                    Else
                        Pallette_Base.Visible = True
                    End If

                End If

            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

End Class
