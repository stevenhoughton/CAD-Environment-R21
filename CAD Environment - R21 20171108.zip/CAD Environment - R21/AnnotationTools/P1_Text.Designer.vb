﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class P1_Text
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(P1_Text))
        Me.gbxTextConfigOption = New System.Windows.Forms.GroupBox()
        Me.rdNonAnnotativeScale = New System.Windows.Forms.RadioButton()
        Me.rdAnnotativeScale = New System.Windows.Forms.RadioButton()
        Me.lstPreSetTextConfig = New System.Windows.Forms.ListBox()
        Me.chkUseClientConfig = New System.Windows.Forms.CheckBox()
        Me.imlBottomButtons = New System.Windows.Forms.ImageList(Me.components)
        Me.imlTabImages = New System.Windows.Forms.ImageList(Me.components)
        Me.imlBitmaps = New System.Windows.Forms.ImageList(Me.components)
        Me.sstStatus = New System.Windows.Forms.StatusStrip()
        Me.tssMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxTextOptions = New System.Windows.Forms.GroupBox()
        Me.rdDText = New System.Windows.Forms.RadioButton()
        Me.rdMText = New System.Windows.Forms.RadioButton()
        Me.gbxNonAnnotativeScales = New System.Windows.Forms.GroupBox()
        Me.LTScaleViewTextBox = New System.Windows.Forms.TextBox()
        Me.LTScaleViewTextBoxLabel = New System.Windows.Forms.Label()
        Me.LTScaleCompensator = New System.Windows.Forms.TextBox()
        Me.LTScaleCompensatorlbl = New System.Windows.Forms.Label()
        Me.newLTSCALElbl = New System.Windows.Forms.Label()
        Me.newLTSCALETextBox = New System.Windows.Forms.TextBox()
        Me.txtNonAnnotativeScale = New System.Windows.Forms.TextBox()
        Me.lblNonAnnotativeTextScale = New System.Windows.Forms.Label()
        Me.lblNonAnnotativeUnits = New System.Windows.Forms.Label()
        Me.cboNonAnnotativeUnits = New System.Windows.Forms.ComboBox()
        Me.lblNonAnnotativeScales = New System.Windows.Forms.Label()
        Me.cboNonAnnotativeScales = New System.Windows.Forms.ComboBox()
        Me.lstAnnotationScales = New System.Windows.Forms.ListBox()
        Me.cmdAddText = New System.Windows.Forms.Button()
        Me.gbxClientSettings = New System.Windows.Forms.GroupBox()
        Me.pnlCfgSet_TLayer = New System.Windows.Forms.Panel()
        Me.cboTextLayer = New System.Windows.Forms.ComboBox()
        Me.lblTextLayer = New System.Windows.Forms.Label()
        Me.pnlCfgSet_TStyle = New System.Windows.Forms.Panel()
        Me.cboTextStyle = New System.Windows.Forms.ComboBox()
        Me.lblTextStyle = New System.Windows.Forms.Label()
        Me.pnlCfgSet_THeight = New System.Windows.Forms.Panel()
        Me.txtTextHeight = New System.Windows.Forms.TextBox()
        Me.lblTextHeight = New System.Windows.Forms.Label()
        Me.gbxTextConfigOption.SuspendLayout()
        Me.sstStatus.SuspendLayout()
        Me.gbxTextOptions.SuspendLayout()
        Me.gbxNonAnnotativeScales.SuspendLayout()
        Me.gbxClientSettings.SuspendLayout()
        Me.pnlCfgSet_TLayer.SuspendLayout()
        Me.pnlCfgSet_TStyle.SuspendLayout()
        Me.pnlCfgSet_THeight.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxTextConfigOption
        '
        Me.gbxTextConfigOption.Controls.Add(Me.rdNonAnnotativeScale)
        Me.gbxTextConfigOption.Controls.Add(Me.rdAnnotativeScale)
        Me.gbxTextConfigOption.Controls.Add(Me.lstPreSetTextConfig)
        Me.gbxTextConfigOption.Controls.Add(Me.chkUseClientConfig)
        Me.gbxTextConfigOption.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxTextConfigOption.Location = New System.Drawing.Point(6, 6)
        Me.gbxTextConfigOption.Name = "gbxTextConfigOption"
        Me.gbxTextConfigOption.Padding = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.gbxTextConfigOption.Size = New System.Drawing.Size(269, 145)
        Me.gbxTextConfigOption.TabIndex = 0
        Me.gbxTextConfigOption.TabStop = False
        Me.gbxTextConfigOption.Text = "Text Options"
        '
        'rdNonAnnotativeScale
        '
        Me.rdNonAnnotativeScale.AutoSize = True
        Me.rdNonAnnotativeScale.Checked = True
        Me.rdNonAnnotativeScale.Location = New System.Drawing.Point(11, 19)
        Me.rdNonAnnotativeScale.Name = "rdNonAnnotativeScale"
        Me.rdNonAnnotativeScale.Size = New System.Drawing.Size(99, 17)
        Me.rdNonAnnotativeScale.TabIndex = 2
        Me.rdNonAnnotativeScale.TabStop = True
        Me.rdNonAnnotativeScale.Text = "Non-Annotative"
        Me.rdNonAnnotativeScale.UseVisualStyleBackColor = True
        '
        'rdAnnotativeScale
        '
        Me.rdAnnotativeScale.AutoSize = True
        Me.rdAnnotativeScale.Location = New System.Drawing.Point(125, 19)
        Me.rdAnnotativeScale.Name = "rdAnnotativeScale"
        Me.rdAnnotativeScale.Size = New System.Drawing.Size(76, 17)
        Me.rdAnnotativeScale.TabIndex = 6
        Me.rdAnnotativeScale.Text = "Annotative"
        Me.rdAnnotativeScale.UseVisualStyleBackColor = True
        '
        'lstPreSetTextConfig
        '
        Me.lstPreSetTextConfig.FormattingEnabled = True
        Me.lstPreSetTextConfig.Location = New System.Drawing.Point(6, 66)
        Me.lstPreSetTextConfig.Name = "lstPreSetTextConfig"
        Me.lstPreSetTextConfig.Size = New System.Drawing.Size(257, 69)
        Me.lstPreSetTextConfig.TabIndex = 4
        '
        'chkUseClientConfig
        '
        Me.chkUseClientConfig.AutoSize = True
        Me.chkUseClientConfig.Location = New System.Drawing.Point(6, 43)
        Me.chkUseClientConfig.Name = "chkUseClientConfig"
        Me.chkUseClientConfig.Padding = New System.Windows.Forms.Padding(6, 3, 0, 0)
        Me.chkUseClientConfig.Size = New System.Drawing.Size(121, 20)
        Me.chkUseClientConfig.TabIndex = 2
        Me.chkUseClientConfig.Text = "Use Client Settings"
        Me.chkUseClientConfig.UseVisualStyleBackColor = True
        '
        'imlBottomButtons
        '
        Me.imlBottomButtons.ImageStream = CType(resources.GetObject("imlBottomButtons.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlBottomButtons.TransparentColor = System.Drawing.Color.Transparent
        Me.imlBottomButtons.Images.SetKeyName(0, "Ico_Yes.ico")
        Me.imlBottomButtons.Images.SetKeyName(1, "ico_cancel.ico")
        Me.imlBottomButtons.Images.SetKeyName(2, "Ico_No.ico")
        Me.imlBottomButtons.Images.SetKeyName(3, "ico_ok.ico")
        '
        'imlTabImages
        '
        Me.imlTabImages.ImageStream = CType(resources.GetObject("imlTabImages.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imlTabImages.TransparentColor = System.Drawing.Color.Transparent
        Me.imlTabImages.Images.SetKeyName(0, "Ico_BlockCenterAddField.ico")
        Me.imlTabImages.Images.SetKeyName(1, "Ico_BlockCenterClearField.ico")
        Me.imlTabImages.Images.SetKeyName(2, "ico_CollisionBackward.ico")
        Me.imlTabImages.Images.SetKeyName(3, "ico_CollisionForward.ico")
        Me.imlTabImages.Images.SetKeyName(4, "Ico_DisplayShowList.ico")
        Me.imlTabImages.Images.SetKeyName(5, "Ico_DwgInfoCopyProject.ico")
        Me.imlTabImages.Images.SetKeyName(6, "Ico_DwgPartlistFoot.ico")
        Me.imlTabImages.Images.SetKeyName(7, "Ico_EdgesDelete.ico")
        Me.imlTabImages.Images.SetKeyName(8, "ico_EndPlateGetSize.ico")
        Me.imlTabImages.Images.SetKeyName(9, "Ico_FormatPaper.ico")
        Me.imlTabImages.Images.SetKeyName(10, "ico_LoadFromFile.ico")
        Me.imlTabImages.Images.SetKeyName(11, "ico_new.ico")
        Me.imlTabImages.Images.SetKeyName(12, "Ico_ProjectLoad.ico")
        Me.imlTabImages.Images.SetKeyName(13, "ico_SaveToFile.ico")
        Me.imlTabImages.Images.SetKeyName(14, "Ico_SettingsNode.ico")
        Me.imlTabImages.Images.SetKeyName(15, "ico_StatikShapeTable.ico")
        Me.imlTabImages.Images.SetKeyName(16, "ico_viewfile.ico")
        Me.imlTabImages.Images.SetKeyName(17, "Ico_BlockCenterChange.ico")
        Me.imlTabImages.Images.SetKeyName(18, "ICO_EndPlateCopySize.ico")
        Me.imlTabImages.Images.SetKeyName(19, "Ico_PlateInsertDiagonal.ico")
        '
        'imlBitmaps
        '
        Me.imlBitmaps.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlBitmaps.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlBitmaps.TransparentColor = System.Drawing.Color.Transparent
        '
        'sstStatus
        '
        Me.sstStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tssMessage})
        Me.sstStatus.Location = New System.Drawing.Point(6, 597)
        Me.sstStatus.Name = "sstStatus"
        Me.sstStatus.Size = New System.Drawing.Size(269, 22)
        Me.sstStatus.TabIndex = 50
        Me.sstStatus.Text = "StatusStrip1"
        '
        'tssMessage
        '
        Me.tssMessage.Name = "tssMessage"
        Me.tssMessage.Size = New System.Drawing.Size(22, 17)
        Me.tssMessage.Text = "xxx"
        '
        'gbxTextOptions
        '
        Me.gbxTextOptions.Controls.Add(Me.rdDText)
        Me.gbxTextOptions.Controls.Add(Me.rdMText)
        Me.gbxTextOptions.Controls.Add(Me.gbxNonAnnotativeScales)
        Me.gbxTextOptions.Controls.Add(Me.lstAnnotationScales)
        Me.gbxTextOptions.Controls.Add(Me.cmdAddText)
        Me.gbxTextOptions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbxTextOptions.Location = New System.Drawing.Point(6, 258)
        Me.gbxTextOptions.Name = "gbxTextOptions"
        Me.gbxTextOptions.Size = New System.Drawing.Size(269, 339)
        Me.gbxTextOptions.TabIndex = 51
        Me.gbxTextOptions.TabStop = False
        Me.gbxTextOptions.Text = "Additional Options"
        '
        'rdDText
        '
        Me.rdDText.AutoSize = True
        Me.rdDText.Location = New System.Drawing.Point(173, 19)
        Me.rdDText.Name = "rdDText"
        Me.rdDText.Size = New System.Drawing.Size(54, 17)
        Me.rdDText.TabIndex = 18
        Me.rdDText.Text = "DText"
        Me.rdDText.UseVisualStyleBackColor = True
        '
        'rdMText
        '
        Me.rdMText.AutoSize = True
        Me.rdMText.Checked = True
        Me.rdMText.Location = New System.Drawing.Point(112, 19)
        Me.rdMText.Name = "rdMText"
        Me.rdMText.Size = New System.Drawing.Size(55, 17)
        Me.rdMText.TabIndex = 17
        Me.rdMText.TabStop = True
        Me.rdMText.Text = "MText"
        Me.rdMText.UseVisualStyleBackColor = True
        '
        'gbxNonAnnotativeScales
        '
        Me.gbxNonAnnotativeScales.BackColor = System.Drawing.SystemColors.Control
        Me.gbxNonAnnotativeScales.Controls.Add(Me.LTScaleViewTextBox)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.LTScaleViewTextBoxLabel)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.LTScaleCompensator)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.LTScaleCompensatorlbl)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.newLTSCALElbl)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.newLTSCALETextBox)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.txtNonAnnotativeScale)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.lblNonAnnotativeTextScale)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.lblNonAnnotativeUnits)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.cboNonAnnotativeUnits)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.lblNonAnnotativeScales)
        Me.gbxNonAnnotativeScales.Controls.Add(Me.cboNonAnnotativeScales)
        Me.gbxNonAnnotativeScales.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.gbxNonAnnotativeScales.Location = New System.Drawing.Point(3, 63)
        Me.gbxNonAnnotativeScales.Name = "gbxNonAnnotativeScales"
        Me.gbxNonAnnotativeScales.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.gbxNonAnnotativeScales.Size = New System.Drawing.Size(263, 100)
        Me.gbxNonAnnotativeScales.TabIndex = 16
        Me.gbxNonAnnotativeScales.TabStop = False
        Me.gbxNonAnnotativeScales.Text = "Drawing Scale"
        Me.gbxNonAnnotativeScales.Visible = False
        '
        'LTScaleViewTextBox
        '
        Me.LTScaleViewTextBox.AcceptsReturn = True
        Me.LTScaleViewTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.LTScaleViewTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LTScaleViewTextBox.Enabled = False
        Me.LTScaleViewTextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LTScaleViewTextBox.Location = New System.Drawing.Point(135, 160)
        Me.LTScaleViewTextBox.MaxLength = 0
        Me.LTScaleViewTextBox.Name = "LTScaleViewTextBox"
        Me.LTScaleViewTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleViewTextBox.Size = New System.Drawing.Size(107, 20)
        Me.LTScaleViewTextBox.TabIndex = 32
        '
        'LTScaleViewTextBoxLabel
        '
        Me.LTScaleViewTextBoxLabel.AutoSize = True
        Me.LTScaleViewTextBoxLabel.BackColor = System.Drawing.SystemColors.Control
        Me.LTScaleViewTextBoxLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.LTScaleViewTextBoxLabel.Enabled = False
        Me.LTScaleViewTextBoxLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LTScaleViewTextBoxLabel.Location = New System.Drawing.Point(34, 163)
        Me.LTScaleViewTextBoxLabel.Name = "LTScaleViewTextBoxLabel"
        Me.LTScaleViewTextBoxLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleViewTextBoxLabel.Size = New System.Drawing.Size(87, 13)
        Me.LTScaleViewTextBoxLabel.TabIndex = 31
        Me.LTScaleViewTextBoxLabel.Text = "Line Type Scale:"
        '
        'LTScaleCompensator
        '
        Me.LTScaleCompensator.AcceptsReturn = True
        Me.LTScaleCompensator.BackColor = System.Drawing.SystemColors.Window
        Me.LTScaleCompensator.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LTScaleCompensator.Enabled = False
        Me.LTScaleCompensator.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LTScaleCompensator.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LTScaleCompensator.Location = New System.Drawing.Point(135, 129)
        Me.LTScaleCompensator.MaxLength = 0
        Me.LTScaleCompensator.Name = "LTScaleCompensator"
        Me.LTScaleCompensator.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleCompensator.Size = New System.Drawing.Size(107, 21)
        Me.LTScaleCompensator.TabIndex = 30
        '
        'LTScaleCompensatorlbl
        '
        Me.LTScaleCompensatorlbl.AutoSize = True
        Me.LTScaleCompensatorlbl.BackColor = System.Drawing.SystemColors.Control
        Me.LTScaleCompensatorlbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.LTScaleCompensatorlbl.Enabled = False
        Me.LTScaleCompensatorlbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LTScaleCompensatorlbl.ForeColor = System.Drawing.Color.Black
        Me.LTScaleCompensatorlbl.Location = New System.Drawing.Point(9, 132)
        Me.LTScaleCompensatorlbl.Name = "LTScaleCompensatorlbl"
        Me.LTScaleCompensatorlbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleCompensatorlbl.Size = New System.Drawing.Size(120, 13)
        Me.LTScaleCompensatorlbl.TabIndex = 29
        Me.LTScaleCompensatorlbl.Text = "LTSCALE Compensator:"
        Me.LTScaleCompensatorlbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'newLTSCALElbl
        '
        Me.newLTSCALElbl.AutoSize = True
        Me.newLTSCALElbl.BackColor = System.Drawing.SystemColors.Control
        Me.newLTSCALElbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.newLTSCALElbl.Enabled = False
        Me.newLTSCALElbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.newLTSCALElbl.Location = New System.Drawing.Point(35, 106)
        Me.newLTSCALElbl.Name = "newLTSCALElbl"
        Me.newLTSCALElbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newLTSCALElbl.Size = New System.Drawing.Size(90, 13)
        Me.newLTSCALElbl.TabIndex = 28
        Me.newLTSCALElbl.Text = "Global LTSCALE:"
        '
        'newLTSCALETextBox
        '
        Me.newLTSCALETextBox.AcceptsReturn = True
        Me.newLTSCALETextBox.BackColor = System.Drawing.SystemColors.Window
        Me.newLTSCALETextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.newLTSCALETextBox.Enabled = False
        Me.newLTSCALETextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.newLTSCALETextBox.Location = New System.Drawing.Point(136, 103)
        Me.newLTSCALETextBox.MaxLength = 0
        Me.newLTSCALETextBox.Name = "newLTSCALETextBox"
        Me.newLTSCALETextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newLTSCALETextBox.Size = New System.Drawing.Size(107, 20)
        Me.newLTSCALETextBox.TabIndex = 27
        '
        'txtNonAnnotativeScale
        '
        Me.txtNonAnnotativeScale.AcceptsReturn = True
        Me.txtNonAnnotativeScale.BackColor = System.Drawing.SystemColors.Window
        Me.txtNonAnnotativeScale.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNonAnnotativeScale.Enabled = False
        Me.txtNonAnnotativeScale.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNonAnnotativeScale.Location = New System.Drawing.Point(135, 73)
        Me.txtNonAnnotativeScale.MaxLength = 0
        Me.txtNonAnnotativeScale.Name = "txtNonAnnotativeScale"
        Me.txtNonAnnotativeScale.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNonAnnotativeScale.Size = New System.Drawing.Size(107, 20)
        Me.txtNonAnnotativeScale.TabIndex = 26
        '
        'lblNonAnnotativeTextScale
        '
        Me.lblNonAnnotativeTextScale.AutoSize = True
        Me.lblNonAnnotativeTextScale.BackColor = System.Drawing.SystemColors.Control
        Me.lblNonAnnotativeTextScale.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNonAnnotativeTextScale.Enabled = False
        Me.lblNonAnnotativeTextScale.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblNonAnnotativeTextScale.Location = New System.Drawing.Point(60, 76)
        Me.lblNonAnnotativeTextScale.Name = "lblNonAnnotativeTextScale"
        Me.lblNonAnnotativeTextScale.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNonAnnotativeTextScale.Size = New System.Drawing.Size(61, 13)
        Me.lblNonAnnotativeTextScale.TabIndex = 25
        Me.lblNonAnnotativeTextScale.Text = "Text Scale:"
        Me.lblNonAnnotativeTextScale.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblNonAnnotativeUnits
        '
        Me.lblNonAnnotativeUnits.BackColor = System.Drawing.SystemColors.Control
        Me.lblNonAnnotativeUnits.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNonAnnotativeUnits.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNonAnnotativeUnits.ForeColor = System.Drawing.Color.Black
        Me.lblNonAnnotativeUnits.Location = New System.Drawing.Point(39, 46)
        Me.lblNonAnnotativeUnits.Name = "lblNonAnnotativeUnits"
        Me.lblNonAnnotativeUnits.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNonAnnotativeUnits.Size = New System.Drawing.Size(83, 19)
        Me.lblNonAnnotativeUnits.TabIndex = 2
        Me.lblNonAnnotativeUnits.Text = "Text Units:"
        Me.lblNonAnnotativeUnits.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboNonAnnotativeUnits
        '
        Me.cboNonAnnotativeUnits.BackColor = System.Drawing.SystemColors.Window
        Me.cboNonAnnotativeUnits.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboNonAnnotativeUnits.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboNonAnnotativeUnits.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboNonAnnotativeUnits.Location = New System.Drawing.Point(135, 46)
        Me.cboNonAnnotativeUnits.Name = "cboNonAnnotativeUnits"
        Me.cboNonAnnotativeUnits.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboNonAnnotativeUnits.Size = New System.Drawing.Size(107, 21)
        Me.cboNonAnnotativeUnits.TabIndex = 3
        '
        'lblNonAnnotativeScales
        '
        Me.lblNonAnnotativeScales.BackColor = System.Drawing.SystemColors.Control
        Me.lblNonAnnotativeScales.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblNonAnnotativeScales.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblNonAnnotativeScales.Location = New System.Drawing.Point(69, 22)
        Me.lblNonAnnotativeScales.Name = "lblNonAnnotativeScales"
        Me.lblNonAnnotativeScales.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblNonAnnotativeScales.Size = New System.Drawing.Size(53, 19)
        Me.lblNonAnnotativeScales.TabIndex = 1
        Me.lblNonAnnotativeScales.Text = "Scales:"
        Me.lblNonAnnotativeScales.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboNonAnnotativeScales
        '
        Me.cboNonAnnotativeScales.BackColor = System.Drawing.SystemColors.Window
        Me.cboNonAnnotativeScales.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboNonAnnotativeScales.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboNonAnnotativeScales.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboNonAnnotativeScales.Location = New System.Drawing.Point(135, 19)
        Me.cboNonAnnotativeScales.Name = "cboNonAnnotativeScales"
        Me.cboNonAnnotativeScales.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboNonAnnotativeScales.Size = New System.Drawing.Size(107, 21)
        Me.cboNonAnnotativeScales.TabIndex = 0
        '
        'lstAnnotationScales
        '
        Me.lstAnnotationScales.FormattingEnabled = True
        Me.lstAnnotationScales.Location = New System.Drawing.Point(3, 60)
        Me.lstAnnotationScales.Name = "lstAnnotationScales"
        Me.lstAnnotationScales.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstAnnotationScales.Size = New System.Drawing.Size(263, 277)
        Me.lstAnnotationScales.TabIndex = 12
        '
        'cmdAddText
        '
        Me.cmdAddText.Image = Global.Jacobs.AutoCAD.AnnotationTools.My.Resources.Resources.Text
        Me.cmdAddText.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdAddText.Location = New System.Drawing.Point(6, 19)
        Me.cmdAddText.Name = "cmdAddText"
        Me.cmdAddText.Size = New System.Drawing.Size(95, 34)
        Me.cmdAddText.TabIndex = 7
        Me.cmdAddText.Text = "Enter"
        Me.cmdAddText.UseVisualStyleBackColor = True
        '
        'gbxClientSettings
        '
        Me.gbxClientSettings.Controls.Add(Me.pnlCfgSet_TLayer)
        Me.gbxClientSettings.Controls.Add(Me.pnlCfgSet_TStyle)
        Me.gbxClientSettings.Controls.Add(Me.pnlCfgSet_THeight)
        Me.gbxClientSettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxClientSettings.Location = New System.Drawing.Point(6, 151)
        Me.gbxClientSettings.Name = "gbxClientSettings"
        Me.gbxClientSettings.Padding = New System.Windows.Forms.Padding(6)
        Me.gbxClientSettings.Size = New System.Drawing.Size(269, 107)
        Me.gbxClientSettings.TabIndex = 1
        Me.gbxClientSettings.TabStop = False
        Me.gbxClientSettings.Text = "Config Settings"
        '
        'pnlCfgSet_TLayer
        '
        Me.pnlCfgSet_TLayer.Controls.Add(Me.cboTextLayer)
        Me.pnlCfgSet_TLayer.Controls.Add(Me.lblTextLayer)
        Me.pnlCfgSet_TLayer.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlCfgSet_TLayer.Location = New System.Drawing.Point(6, 69)
        Me.pnlCfgSet_TLayer.MaximumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_TLayer.MinimumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_TLayer.Name = "pnlCfgSet_TLayer"
        Me.pnlCfgSet_TLayer.Padding = New System.Windows.Forms.Padding(2)
        Me.pnlCfgSet_TLayer.Size = New System.Drawing.Size(257, 25)
        Me.pnlCfgSet_TLayer.TabIndex = 8
        '
        'cboTextLayer
        '
        Me.cboTextLayer.Dock = System.Windows.Forms.DockStyle.Top
        Me.cboTextLayer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTextLayer.FormattingEnabled = True
        Me.cboTextLayer.Location = New System.Drawing.Point(65, 2)
        Me.cboTextLayer.Name = "cboTextLayer"
        Me.cboTextLayer.Size = New System.Drawing.Size(190, 21)
        Me.cboTextLayer.TabIndex = 1
        '
        'lblTextLayer
        '
        Me.lblTextLayer.AutoSize = True
        Me.lblTextLayer.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblTextLayer.Location = New System.Drawing.Point(2, 2)
        Me.lblTextLayer.Name = "lblTextLayer"
        Me.lblTextLayer.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.lblTextLayer.Size = New System.Drawing.Size(63, 15)
        Me.lblTextLayer.TabIndex = 0
        Me.lblTextLayer.Text = "Text Layer: "
        '
        'pnlCfgSet_TStyle
        '
        Me.pnlCfgSet_TStyle.Controls.Add(Me.cboTextStyle)
        Me.pnlCfgSet_TStyle.Controls.Add(Me.lblTextStyle)
        Me.pnlCfgSet_TStyle.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlCfgSet_TStyle.Location = New System.Drawing.Point(6, 44)
        Me.pnlCfgSet_TStyle.MaximumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_TStyle.MinimumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_TStyle.Name = "pnlCfgSet_TStyle"
        Me.pnlCfgSet_TStyle.Padding = New System.Windows.Forms.Padding(2)
        Me.pnlCfgSet_TStyle.Size = New System.Drawing.Size(257, 25)
        Me.pnlCfgSet_TStyle.TabIndex = 7
        '
        'cboTextStyle
        '
        Me.cboTextStyle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.cboTextStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTextStyle.FormattingEnabled = True
        Me.cboTextStyle.Location = New System.Drawing.Point(62, 2)
        Me.cboTextStyle.Name = "cboTextStyle"
        Me.cboTextStyle.Size = New System.Drawing.Size(193, 21)
        Me.cboTextStyle.TabIndex = 1
        '
        'lblTextStyle
        '
        Me.lblTextStyle.AutoSize = True
        Me.lblTextStyle.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblTextStyle.Location = New System.Drawing.Point(2, 2)
        Me.lblTextStyle.Name = "lblTextStyle"
        Me.lblTextStyle.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.lblTextStyle.Size = New System.Drawing.Size(60, 15)
        Me.lblTextStyle.TabIndex = 0
        Me.lblTextStyle.Text = "Text Style: "
        '
        'pnlCfgSet_THeight
        '
        Me.pnlCfgSet_THeight.Controls.Add(Me.txtTextHeight)
        Me.pnlCfgSet_THeight.Controls.Add(Me.lblTextHeight)
        Me.pnlCfgSet_THeight.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlCfgSet_THeight.Location = New System.Drawing.Point(6, 19)
        Me.pnlCfgSet_THeight.MaximumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_THeight.MinimumSize = New System.Drawing.Size(0, 25)
        Me.pnlCfgSet_THeight.Name = "pnlCfgSet_THeight"
        Me.pnlCfgSet_THeight.Padding = New System.Windows.Forms.Padding(2)
        Me.pnlCfgSet_THeight.Size = New System.Drawing.Size(257, 25)
        Me.pnlCfgSet_THeight.TabIndex = 9
        '
        'txtTextHeight
        '
        Me.txtTextHeight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtTextHeight.Location = New System.Drawing.Point(70, 2)
        Me.txtTextHeight.Name = "txtTextHeight"
        Me.txtTextHeight.Size = New System.Drawing.Size(185, 20)
        Me.txtTextHeight.TabIndex = 6
        '
        'lblTextHeight
        '
        Me.lblTextHeight.AutoSize = True
        Me.lblTextHeight.Dock = System.Windows.Forms.DockStyle.Left
        Me.lblTextHeight.Location = New System.Drawing.Point(2, 2)
        Me.lblTextHeight.Name = "lblTextHeight"
        Me.lblTextHeight.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.lblTextHeight.Size = New System.Drawing.Size(68, 15)
        Me.lblTextHeight.TabIndex = 0
        Me.lblTextHeight.Text = "Text Height: "
        '
        'P1_Text
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.gbxTextOptions)
        Me.Controls.Add(Me.gbxClientSettings)
        Me.Controls.Add(Me.gbxTextConfigOption)
        Me.Controls.Add(Me.sstStatus)
        Me.Name = "P1_Text"
        Me.Padding = New System.Windows.Forms.Padding(6)
        Me.Size = New System.Drawing.Size(281, 625)
        Me.gbxTextConfigOption.ResumeLayout(False)
        Me.gbxTextConfigOption.PerformLayout()
        Me.sstStatus.ResumeLayout(False)
        Me.sstStatus.PerformLayout()
        Me.gbxTextOptions.ResumeLayout(False)
        Me.gbxTextOptions.PerformLayout()
        Me.gbxNonAnnotativeScales.ResumeLayout(False)
        Me.gbxNonAnnotativeScales.PerformLayout()
        Me.gbxClientSettings.ResumeLayout(False)
        Me.pnlCfgSet_TLayer.ResumeLayout(False)
        Me.pnlCfgSet_TLayer.PerformLayout()
        Me.pnlCfgSet_TStyle.ResumeLayout(False)
        Me.pnlCfgSet_TStyle.PerformLayout()
        Me.pnlCfgSet_THeight.ResumeLayout(False)
        Me.pnlCfgSet_THeight.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gbxTextConfigOption As System.Windows.Forms.GroupBox
    Friend WithEvents imlBottomButtons As System.Windows.Forms.ImageList
    Friend WithEvents imlTabImages As System.Windows.Forms.ImageList
    Friend WithEvents imlBitmaps As System.Windows.Forms.ImageList
    Friend WithEvents sstStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents tssMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbxTextOptions As System.Windows.Forms.GroupBox
    Friend WithEvents cmdAddText As System.Windows.Forms.Button
    Friend WithEvents lstPreSetTextConfig As System.Windows.Forms.ListBox
    Friend WithEvents chkUseClientConfig As System.Windows.Forms.CheckBox
    Friend WithEvents gbxClientSettings As System.Windows.Forms.GroupBox
    Friend WithEvents pnlCfgSet_TLayer As System.Windows.Forms.Panel
    Friend WithEvents cboTextLayer As System.Windows.Forms.ComboBox
    Friend WithEvents lblTextLayer As System.Windows.Forms.Label
    Friend WithEvents pnlCfgSet_TStyle As System.Windows.Forms.Panel
    Friend WithEvents cboTextStyle As System.Windows.Forms.ComboBox
    Friend WithEvents lblTextStyle As System.Windows.Forms.Label
    Friend WithEvents pnlCfgSet_THeight As System.Windows.Forms.Panel
    Friend WithEvents txtTextHeight As System.Windows.Forms.TextBox
    Friend WithEvents lblTextHeight As System.Windows.Forms.Label
    Friend WithEvents lstAnnotationScales As System.Windows.Forms.ListBox
    Friend WithEvents rdNonAnnotativeScale As Windows.Forms.RadioButton
    Friend WithEvents rdAnnotativeScale As Windows.Forms.RadioButton
    Public WithEvents gbxNonAnnotativeScales As Windows.Forms.GroupBox
    Public WithEvents lblNonAnnotativeUnits As Windows.Forms.Label
    Public WithEvents cboNonAnnotativeUnits As Windows.Forms.ComboBox
    Public WithEvents lblNonAnnotativeScales As Windows.Forms.Label
    Public WithEvents cboNonAnnotativeScales As Windows.Forms.ComboBox
    Friend WithEvents rdDText As Windows.Forms.RadioButton
    Friend WithEvents rdMText As Windows.Forms.RadioButton
    Public WithEvents txtNonAnnotativeScale As Windows.Forms.TextBox
    Public WithEvents lblNonAnnotativeTextScale As Windows.Forms.Label
    Public WithEvents newLTSCALElbl As Windows.Forms.Label
    Public WithEvents newLTSCALETextBox As Windows.Forms.TextBox
    Public WithEvents LTScaleCompensator As Windows.Forms.TextBox
    Public WithEvents LTScaleCompensatorlbl As Windows.Forms.Label
    Public WithEvents LTScaleViewTextBox As Windows.Forms.TextBox
    Public WithEvents LTScaleViewTextBoxLabel As Windows.Forms.Label
End Class
