﻿Imports System.Windows.Forms
Imports AutoCADApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.Windows

Public Class P2_Dimension

    Private IsInitializing As Boolean = True
    Private mUseSCESettings As Boolean = False
    Dim SelectConfig As New SelectTemplate.TemplateSelector
    Dim sDimensionType As String
    Dim sPreviousLayer As String = ""
    Dim dPreviousDimScale As Double = 1

    Private TextSettings_DS As DataSet
    Private stoolpath As String = ""

    Private mUseClientSettings As Boolean = True
    Private mWorkFlowIndex As Integer = 0
    Private Shared myCommandStarted As Boolean = False
    Private mHostClass As AnnotationTools.StartAutoCAD = Nothing

    Private Sub chkUseClientConfig_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkUseClientConfig.CheckedChanged
        mHostClass.UseClientSettings = chkUseClientConfig.Checked

        XEnabled(pnlCfgSet_DimLayer, Not chkUseClientConfig.Checked)
        XEnabled(pnlCfgSet_DimStyle, Not chkUseClientConfig.Checked)
        XEnabled(pnlCfgSet_DimColor, Not chkUseClientConfig.Checked)
    End Sub

    Public WriteOnly Property PalletteEnable() As Boolean
        Set(value As Boolean)
            mUseSCESettings = value

            Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.UseAESettings = mUseSCESettings

            XEnabled(gbxDimensionOptions, mUseSCESettings)
            'XEnabled(gbxSettings, mUseSCESettings)
            XEnabled(gbxAnnotativeScales, mUseSCESettings)
            XEnabled(gbxAnnotativeTypes, mUseSCESettings)

            Select Case mUseSCESettings
                Case True
                    tssMessage.Text = "Drawing is Configured"
                    chkUseClientConfig_CheckedChanged(Me.chkUseClientConfig, New EventArgs)
                Case False
                    tssMessage.Text = "Drawing is Not Configured"
            End Select
        End Set
    End Property

    Private Sub P2_Dimension_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        Try

            Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument

            AddHandler Doc.CommandEnded, AddressOf ThisDrawingDimensions_EndCommand

            IsInitializing = True

            TextSettings_DS = New DataSet
            If TextSettings_DS.Tables.Contains("Rules") Then
                TextSettings_DS.Tables.Remove("Rules")
            End If
            TextSettings_DS.Tables.Add("Rules")

            TextSettings_DS.Tables("Rules").Columns.Add("Rule", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("DColor", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("DStyle", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("DLayer", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("ListDisplay", GetType(System.String))
            TextSettings_DS.Tables("Rules").Columns.Add("IsExist", GetType(System.Boolean))
            TextSettings_DS.Tables("Rules").Columns.Add("IsAnno", GetType(System.Boolean))
            TextSettings_DS.Tables("Rules").Columns.Add("Scale", GetType(System.String))

            Dim pk As System.Data.DataColumn = TextSettings_DS.Tables("Rules").Columns("Rule")

            'Need a primary key to search the datatable for existing Files
            TextSettings_DS.Tables("Rules").PrimaryKey = New System.Data.DataColumn() {pk}
            TextSettings_DS.AcceptChanges()

            Dim TTab As System.Data.DataTable = TextSettings_DS.Tables("Rules").Clone
            TTab.TableName = "CurrentSettings"
            TextSettings_DS.Tables.Add(TTab)
            TextSettings_DS.AcceptChanges()

            GetConfigSettings()

            ' Check rules Ignoring any overridesif if use client config is checked
            CheckRules(WorkingVariableAccessors.GetWorkVarValue("DIMENSIONSClientConfig", "True").ToString.IsTrue)

            IsInitializing = False

            SetDimStyleCurrent(cboDimStyle.SelectedItem.ToString)
            SetSysVariable("CLAYER", cboDimLayer.SelectedItem.ToString)

            WorkFlowIndex = 0
            'mLayerDims.LayerName = cboDLayer.SelectedItem.ToString

        Catch ex As Exception

            '' Generic Error Message to handle exceptions - uses reflection to work out where the error was generated.
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

    End Sub
    Private Sub ThisDrawingDimensions_EndCommand(ByVal senderObj As Object, ByVal e As CommandEventArgs)

        If ((myCommandStarted = True) And (UCase(e.GlobalCommandName) = UCase(sDimensionType))) Then
            'Get the current database
            Dim ActiveDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
            Dim ActiveDataBase As Database = ActiveDoc.Database
            'Start a transaction
            Using ActiveTransaction As Transaction = ActiveDataBase.TransactionManager.StartTransaction()

                'Restores the original layer name
                If sPreviousLayer <> "" Then
                    If Not sPreviousLayer.Equals(ThisDrawingUtilities.GetVariable("CLAYER").ToString) Then
                        ThisDrawingUtilities.SetVariable("CLAYER", sPreviousLayer)
                    End If
                End If

                'Restores the original dim scale
                If dPreviousDimScale <> ThisDrawingUtilities.GetVariable("DIMSCALE") Then
                    ThisDrawingUtilities.SetVariable("DIMSCALE", dPreviousDimScale)
                End If

                If WorkFlowIndex = 1 Then
                    Dim EntLast As Autodesk.AutoCAD.Interop.Common.AcadObject = Utilities.Utilities.entlast()
                    If EntLast IsNot Nothing Then
                        Dim ContextManager As ObjectContextManager = ActiveDataBase.ObjectContextManager
                        If ContextManager <> Nothing Then
                            Dim ContextCollection As ObjectContextCollection = ContextManager.GetContextCollection("ACDB_ANNOTATIONSCALES")
                            If ContextCollection <> Nothing Then
                                For Each AnnotativeScale As AnnotationScale In lstAnnotativeScales.SelectedItems
                                    For Each ObjectContext As ObjectContext In ContextCollection
                                        If ObjectContext.Name = AnnotativeScale.Name Then
                                            EntLast.AnnotationScale = ObjectContext
                                            Exit For
                                        End If
                                    Next
                                Next
                            End If
                        End If
                    End If
                End If
                myCommandStarted = False
                ActiveTransaction.Commit()
            End Using
        End If

    End Sub
    Private Sub cmdGetColor_Click(sender As System.Object, e As System.EventArgs) Handles cmdDimColor.Click

        Dim MyColorDialog As New Autodesk.AutoCAD.Windows.ColorDialog
        Dim Res As New DialogResult

        MyColorDialog.Color = Autodesk.AutoCAD.Colors.Color.FromColorIndex(Autodesk.AutoCAD.Colors.ColorMethod.ByAci, CShort(cboDimColor.SelectedIndex))
        MyColorDialog.IncludeByBlockByLayer = True
        If MyColorDialog.ShowDialog = DialogResult.OK Then

            cboDimColor.SelectedIndex = CType(MyColorDialog.Color.ColorIndex, Integer)

        End If

    End Sub

    Private Sub cboDStyle_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboDimStyle.SelectedValueChanged
        If IsInitializing Then Exit Sub
        'Can not set System Variable Dimstyle is readonly
        SetDimStyleCurrent(cboDimStyle.SelectedItem.ToString)
        RuleAccessors.RecordDglRule("DIM5", cboDimStyle.SelectedItem.ToString)
    End Sub

    Private Sub cboDLayer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboDimLayer.SelectedValueChanged
        If IsInitializing Then Exit Sub
        'SetSysVariable("CLAYER", cboDLayer.SelectedItem.ToString)
        'mLayerDims.LayerName = cboDLayer.SelectedItem.ToString
        RuleAccessors.RecordDglRule("DIM1", cboDimLayer.SelectedItem.ToString)
    End Sub

    Private Sub cboDColor_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboDimColor.SelectedValueChanged
        If IsInitializing Then Exit Sub
        SetSysVariable("CECOLOR", cboDimColor.SelectedIndex.ToString)
        RuleAccessors.RecordDglRule("DIM2", cboDimColor.SelectedItem.ToString)
    End Sub

    Private Sub lstAnnotationScales_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstAnnotativeScales.SelectedIndexChanged

        If lstAnnotativeScales.SelectedItems.Count = 0 Then Exit Sub

        Dim TListAnnoScales As New List(Of AnnotationScale)
        For Each A As AnnotationScale In lstAnnotativeScales.SelectedItems
            TListAnnoScales.Add(A)
        Next

        'mLayerDims.DimAnnoScales = TListAnnoScales
        'AnnotationTools.StartAutoCAD.LayerEventTools.DimAnnoScales = TListAnnoScales
        Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.DimAnnoScales = TListAnnoScales
    End Sub
    Private Sub NonAnnotativeRadioButtonDimension_CheckedChanged(sender As Object, e As EventArgs) Handles rbNonAnnotative.CheckedChanged
        WorkFlowIndex = 0
    End Sub

    Private Sub AnnotativeRadioButtonDimension_CheckedChanged(sender As Object, e As EventArgs) Handles rbAnnotative.CheckedChanged
        WorkFlowIndex = 1
    End Sub

    Private Sub cmdHVAlign_Click(sender As Object, e As EventArgs) Handles cmdDimHVAlign.Click
        DimSettings()
        PlaceDim("DIMLINEAR")
    End Sub

    Private Sub cmdTrueAlign_Click(sender As Object, e As EventArgs) Handles cmdDimAlign.Click
        DimSettings()
        PlaceDim("DIMCONTINUE")
    End Sub

    Private Sub cmdDia_Click(sender As Object, e As EventArgs) Handles cmdDimDia.Click
        DimSettings()
        PlaceDim("DIMDIAMETER")
    End Sub

    Private Sub cmdArc_Click(sender As Object, e As EventArgs) Handles cmdDimArc.Click
        DimSettings()
        PlaceDim("DIMRADIUS")
    End Sub

    Private Sub cmdContinue_Click(sender As Object, e As EventArgs) Handles cmdDimContinue.Click
        DimSettings()
        PlaceDim("DIMCONTINUE")
    End Sub

    Sub PlaceDim(CommandName As String)
        sDimensionType = CommandName
        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Select Case CommandName
            Case "DIMLINEAR"
                Doc.SendStringToExecute("DIMLINEAR ", True, False, False)
            Case "DIMCONTINUE"
                Doc.SendStringToExecute("DIMCONTINUE ", True, False, False)
            Case "DIMALIGNED"
                Doc.SendStringToExecute("DIMALIGNED ", True, False, False)
            Case "DIMDIAMETER"
                Doc.SendStringToExecute("DIMDIAMETER ", True, False, False)
            Case "DIMRADIUS"
                Doc.SendStringToExecute("DIMRADIUS ", True, False, False)
        End Select
        Autodesk.AutoCAD.Internal.Utils.SetFocusToDwgView()
    End Sub

    Public Sub DimSettings()

        myCommandStarted = True

        'Get the current database
        Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim acCurDb As Database = acDoc.Database
        'Start a transaction
        Using acTRans As Transaction = acCurDb.TransactionManager.StartTransaction()

            'Save the current layer
            sPreviousLayer = ThisDrawingUtilities.ActiveLayer.Name.ToString
            'Save the current Dim scale
            dPreviousDimScale = ThisDrawingUtilities.GetVariable("DIMSCALE")

            'Sets the current Layer from the rule DIM1
            Dim LayerName As String = RuleAccessors.GetruleValue("DIM1")
            If LayerExist(LayerName) Then
                If Not sPreviousLayer.Equals(LayerName) Then
                    ThisDrawingUtilities.SetVariable("CLAYER", LayerName)
                End If
            End If

            'Set the Dimstyle
            Dim DimStyleName As String = RuleAccessors.GetruleValue("DIM5")
            If DimStyleExist(DimStyleName) Then
                Dim objDimStyle As Autodesk.AutoCAD.Interop.Common.AcadDimStyle = ThisDrawingUtilities.DimStyles.Item(DimStyleName)
                ThisDrawingUtilities.ActiveDimStyle = objDimStyle
            End If

            'Sets the DimScale
            If WorkFlowIndex = 0 Then
                If dPreviousDimScale <> CDbl(txtDimScale.Text) Then
                    ThisDrawingUtilities.SetVariable("DIMSCALE", CDbl(txtDimScale.Text))
                End If
            End If

            acTRans.Commit()
        End Using
    End Sub

    ''' <summary>
    ''' When the scale list changes we need to recalculate the variables
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cboNonAnnotativeScales_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboNonAnnotativeScales.SelectedIndexChanged

        ' Work out what the outcome would be if using this new Units
        CalculateNewProposedLtAndDimScales()

        RuleAccessors.RecordDglRule("SCALE1", cboNonAnnotativeScales.Text)

        'ThisDrawingUtilities.SetVariable("DIMSCALE", DimScaleTextBox.Text)

        UpdateModeMacro()

    End Sub
    ''' <summary>
    ''' When the Insertion units drop down list box changes.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub cboNonAnnotativeUnits_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboNonAnnotativeUnits.SelectedIndexChanged

        ' May need to swap the scales in the list to use the ones for the new Unit of Measure - for instance changing from Meters to Millimeters
        ' Changes the scales that are seen
        ChangeScaleList()

        ' Work out what the outcome would be if using this new Units
        CalculateNewProposedLtAndDimScales()

        RuleAccessors.RecordDglRule("SCALE12", cboNonAnnotativeUnits.Text)

        ChangeScaleSysVars()

    End Sub
    ''' <summary>
    ''' Calculate Dimscale and LTScale based on dialog settings - does not set DIMSCALE or LTSCALE
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalculateNewProposedLtAndDimScales()

        ' Calculate the new DIMSCALE based on dialog box values
        txtDimScale.Text = CalculateTextScale(cboNonAnnotativeScales.Text, cboNonAnnotativeUnits.Text).ToString

        ' Calculate new LTSCALE 
        newLTSCALETextBox.Text = CalculateNewLTScale(cboNonAnnotativeScales.Text, cboNonAnnotativeUnits.Text, LTScaleCompensator.Text).ToString

        LTScaleViewTextBox.Text = newLTSCALETextBox.Text

    End Sub
    ''' <summary>
    ''' This is called when the Scale dialiog initializes and when the Insertion Units change in the drop down list
    ''' It Looks for the apropriate file that contains the list of scales to use for the units of measrue specified in the
    ''' InsUnits drop down list box
    ''' The Millimaters scale list file is named AutoCADScaleList.Reg all the othe units of measure have the unit of measure as a suffix
    ''' for example the Meters one is called AutoCADScaleListMeters.Reg
    ''' </summary>
    ''' <remarks></remarks>
    Sub ChangeScaleList()

        Dim vScalesFromRegFile() As String
        Dim sFullConfigName As String
        Dim sFileName As String
        Dim sFileNameAndPath As String

        Try

            ' The name of the Millimeter (default) file that has all the default scale lists
            sFileName = "AutoCADScaleList.Reg"

            ' If this drawing is not in the default Millimeters for a specific unit version of the scale list
            If cboNonAnnotativeUnits.Text <> "Millimeters" Then
                sFileName = sFileName.ToUpper.Replace(".REG", cboNonAnnotativeUnits.Text & ".Reg")
            End If

            ' Configuration extractyion path in case the configuration contains an override list
            sFullConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME", "Not Configured", False, True)

            ' The C:\ProgramData\Autodesk\ApplicationPluggins\Jacobs CAD Environment R20.Bundle\Contents path which contains the Jacobs Corporate scale list
            stoolpath = Settings.Manager.AE.Path

            ' Look for reg file in configuration area
            sFileNameAndPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix & "\" & sFullConfigName & "\Support\" & sFileName

            ' If there is no configuration override then look for the file in the 
            ' C:\ProgramData\Autodesk\ApplicationPluggins\Jacobs CAD Environment R20.Bundle\Contents path which contains the Jacobs Corporate scale list
            If System.IO.File.Exists(sFileNameAndPath) = False Then
                sFileNameAndPath = Settings.Manager.AE.Path.CombinePath(sFileName)
            End If

            ' Capture any units we haven't catered for but may be in use in jacobs.
            If System.IO.File.Exists(sFileNameAndPath) = False Then

                Acad_MessageBox("Unit specific scale list not found: " & sFileName & " Contact cad support to create a list of scales for these units." & vbCrLf &
                       "Will continue using Millimetre set scales for now", "Missing Scale List file for specified units", MessageBoxButtons.OK, MessageBoxIcon.Information)

                sFileNameAndPath = stoolpath.CombinePath("AutoCADScaleList.Reg")

            End If

            ' By now a file must have been found so read the contents 
            vScalesFromRegFile = ScaleListFileRead(sFileNameAndPath, ".ScaleName")

            ' Clear the list of scales in the Scale tool dialog
            cboNonAnnotativeScales.Items.Clear()

            Dim i As Integer

            ' Iterate the list and add them to the drop down list boxes
            For i = LBound(vScalesFromRegFile) To UBound(vScalesFromRegFile)

                ' Remove the " Meters" from the name of the scale as all scales are now represented as 1 Drawing Unit = X Millimetres
                Dim sScaleToUse As String

                ' Get rid of the word Meters from the Scale name if present
                sScaleToUse = Split(Replace(vScalesFromRegFile(i).ToUpper.Replace(" " & InsunitsToStr.ToUpper, ""), """", ""), "=")(1)

                ' Get rid of the word m from the Scale name if present
                sScaleToUse = sScaleToUse.ToUpper.Replace(" m".ToUpper, "")

                Dim a As Double = CDbl(sScaleToUse.Split(":"c)(0))
                Dim b As Double = CDbl(sScaleToUse.Split(":"c)(1))

                If String.IsNullOrEmpty(cboNonAnnotativeUnits.Text) Then
                    cboNonAnnotativeScales.Items.Add(a & ":" & b * InsunitsToMMScaleFactor(CInt(ThisDrawingUtilities.GetVariable("INSUNITS"))))
                Else
                    cboNonAnnotativeScales.Items.Add(a & ":" & b * InsunitsToMMScaleFactor(InsunitsStrToInsunitsVal(cboNonAnnotativeUnits.Text)))
                End If

            Next

            ' Get the rule value to set the Scale value in the list
            Dim Scale As String = RuleAccessors.GetruleValue("SCALE1")

            If cboNonAnnotativeScales.Items.Contains(Scale) Then
                ' If there is the same scale in the new list use that one
                cboNonAnnotativeScales.Text = Scale
            Else
                ' Get the firt scale in the list
                cboNonAnnotativeScales.SelectedIndex = 0
            End If
        Catch ex As Exception
            Acad_MessageBox(ex.Message, "CAD Environment Generated Message - ScaleOptionsFrm.ScaleOptionsFrm.ChangeScaleList", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
        End Try
    End Sub

    Public Sub New(ByRef HostClass As AnnotationTools.StartAutoCAD)

        ' This call is required by the designer.
        InitializeComponent()

        mHostClass = HostClass

        XEnabled(pnlCfgSet_DimLayer, chkUseClientConfig.Checked)
        XEnabled(pnlCfgSet_DimStyle, chkUseClientConfig.Checked)
        XEnabled(pnlCfgSet_DimColor, chkUseClientConfig.Checked)

        'mLayerDims = New LayerEvent(True)

    End Sub

    Public Property UseClientSettings() As Boolean
        Get
            Return mUseClientSettings
        End Get
        Set(ByVal value As Boolean)
            mUseClientSettings = value
            chkUseClientConfig.Checked = value
        End Set
    End Property

    Private Property WorkFlowIndex() As Integer
        Get
            Return mWorkFlowIndex
        End Get
        Set(ByVal value As Integer)
            mWorkFlowIndex = value
            'Disabled Steven Houghton 5/10/17
            'If cboWorkFlow.SelectedIndex <> value Then cboWorkFlow.SelectedIndex = value
            If mWorkFlowIndex > 0 Then 'Non Annotative
                gbxNonAnnotaiveScales.Visible = False
                lstAnnotativeScales.Visible = True
                gbxAnnotativeScales.Width = CInt((gbxAnnotativeScales.Parent.Width - (gbxAnnotativeScales.Parent.Padding.Left + gbxAnnotativeScales.Parent.Padding.Right)) / 2)

                Dim OCC As ObjectContextCollection = HostApplicationServices.WorkingDatabase.ObjectContextManager.GetContextCollection("ACDB_ANNOTATIONSCALES")
                Dim X As Database = HostApplicationServices.WorkingDatabase

                Dim ListOfAnnoScales As New List(Of AnnotationScale)
                For Each A As AnnotationScale In OCC
                    ListOfAnnoScales.Add(A)
                Next

                lstAnnotativeScales.DataSource = Nothing

                lstAnnotativeScales.Items.Clear()

                lstAnnotativeScales.DisplayMember = "Name"
                lstAnnotativeScales.ValueMember = "Name"
                lstAnnotativeScales.DataSource = ListOfAnnoScales

                lstAnnotativeScales.SelectedItem = X.Cannoscale

                IsInitializing = False

            Else
                gbxNonAnnotaiveScales.Visible = True
                lstAnnotativeScales.Visible = False
                'mLayerDims.ClearDimAnnotationList()
                'AnnotationTools.StartAutoCAD.LayerEventTools.ClearDimAnnotationList()
                Jacobs.AutoCAD.StartUp.StartUp.oLayerMan.ClearDimAnnotationList()
            End If
            'Disabled Steven Houghton 6/10/17
            'mHostClass.WorkFlowIndex = mWorkFlowIndex
        End Set
    End Property

    Public Function AnnoToolsCalculateNewDimSize(ByVal dTextSize As Double) As Double

        'Dim DScale As Double = GetScale()

        ' If text size was not provided then get the TextSize specified by the Text Tool Rule TEXT2 which contains desired text size or the override if set.
        'Dim bIgnoreTXTOverrides As Boolean = WorkingVariableAccessors.GetWorkVarValue("TEXTClientConfig", "False").ToString.IsTrue

        ' Work out the conversion factor for the units selected in the InsUnits list box
        'Dim Convfactor As Double = InsunitsToMMScaleFactor()

        ' Work out which space we are in at the moment so we can return what the correct TEXTSIZE should be
        Select Case WhichSpace()
            Case "PaperSpace"
                ' Assumption is made that paperspace will always be in 1:1 MM
                If dTextSize = 0.0# Then
                    dTextSize = dTextSize
                End If

            Case "FloatingModelSpace"

                'DScale = Math.Round(ThisDrawingUtilities.ActivePViewport.CustomScale, 6)
                dTextSize = dTextSize * txtDimScale.Text' / DScale

            Case ("ModelSpace")

                dTextSize = dTextSize * txtDimScale.Text ' / DScale

        End Select

        Return dTextSize


    End Function
    Public Sub CheckRules(Optional ByRef bIgnoreOverrides As Boolean = False)
        Dim sWhatToUse As String
        Dim sWhatToShow As String
        Dim dscale As Double
        Try
            If RuleAccessors.GetruleValue("DIM0", "True", False, True).ToString.IsTrue Then
                ' Allow uses to select if they want to use rules or not - since they are present and set the tickbox to what it was if it has bee used before
                chkUseClientConfig.Enabled = True

                ' Work out if the use rules tick box was on or off last time the tool was used - if not used set it to true

                If WorkingVariableAccessors.GetWorkVarValue("DimensionsClientConfig", "True").ToString.IsTrue Then
                    chkUseClientConfig.CheckState = CheckState.Checked
                    WorkingVariableAccessors.AddWorkVar("DimensionsClientConfig", True)
                Else
                    WorkingVariableAccessors.AddWorkVar("DimensionsClientConfig", False)
                    chkUseClientConfig.CheckState = CheckState.Unchecked
                End If

            Else
                ' Allow uses to select if they want to use rules or not - since they are present and set the tickbox to what it was if it has bee used before
                chkUseClientConfig.Enabled = False
                ' If this is the first time the tool is run in this drawing set it to use rules
                chkUseClientConfig.CheckState = CheckState.Checked
            End If

            If chkUseClientConfig.CheckState = CheckState.Checked Then
                ' Check to see if the rules are already recorded in this drawing - if so don't initialize.
                '    InitializeRules("[Dimensions]", True, True, False)

                Dim SearchForContent As Boolean = True
                If IsMasterFile() = True Then
                    SearchForContent = False
                End If

                'If IsThisAnOldConfigName() = True Then
                '    InitializeRules("[Dimensions]", True, SearchForContent, False)
                'Else
                InitializeRulesNew("[Dimensions]", True, SearchForContent, False)
                'End If

                ' Enable/Disable relevant fields
                txtDimScale.Enabled = False
                cboDimLayer.Enabled = False
                'DimensionsTextCol.Enabled = False
                'UseDIMVarsToOverride.Enabled = False
                'ScaleDimensionsToLayoutCheckBox.Enabled = False
                cboDimStyle.Enabled = False

                sWhatToUse = "UseFirstRule"
                sWhatToShow = "AllAvailable"

            Else

                cboDimLayer.Enabled = True
                'DimensionsTextCol.Enabled = True
                'UseDIMVarsToOverride.Enabled = True
                'ScaleDimensionsToLayoutCheckBox.Enabled = True
                cboDimStyle.Enabled = True

                sWhatToUse = "UsePrevious"
                sWhatToShow = "AllAvailable"

            End If

            ' This tool only runs when in Model Space or Floating Model Space
            If WhichSpace() = "ModelSpace" Then

                gbxNonAnnotaiveScales.Text = "Model Space"
                dscale = GetScale()
                txtDimScale.Text = dscale.ToString()

            Else

                If WhichSpace() = "FloatingModelSpace" Then

                    gbxNonAnnotaiveScales.Text = "Floating Model Space"
                    dscale = GetScale()
                    txtDimScale.Text = (dscale / InsunitsToMMScaleFactor()).ToString()
                End If

            End If

            ' Rules are used even if a drawing is not configured - if the rules are not set then the default sent to the populate functions is used.
            'SCALE12,Insertion Units,0,3,41
            PopulateComboBox(cboNonAnnotativeUnits, "SCALE12", sWhatToShow, sWhatToUse, "INSUNITS", InsunitsToStr, bIgnoreOverrides)

            ' DIM1 Rule ' Layer for dimensions
            PopulateComboBox(cboDimLayer, "DIM1", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)

            ' DIM2 Rule ' Colour for dimension text
            PopulateComboBox(cboDimColor, "DIM2", sWhatToShow, sWhatToUse, "CECOLOR", ThisDrawingUtilities.GetVariable("CECOLOR").ToString, bIgnoreOverrides)

            ' DIM5 Rule ' Default dimension style
            PopulateComboBox(cboDimStyle, "DIM5", sWhatToShow, sWhatToUse, "DIMSTYLE", ThisDrawingUtilities.GetVariable("DIMSTYLE").ToString, bIgnoreOverrides)

            ''DIM7 Rule Don't show switch space message on this machine
            'PopulateCheckBox(DontAskAgain, "DIM7", True, , False, bIgnoreOverrides)
        Catch ex As Exception
            Acad_MessageBox(ex.Message, "CAD Environment Generated Message - DimensionOptions.CheckRules", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
        End Try

    End Sub

End Class
