﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class P3_Scale
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxLineTypeScaling = New System.Windows.Forms.GroupBox()
        Me.newLTSCALElbl = New System.Windows.Forms.Label()
        Me.newLTSCALETextBox = New System.Windows.Forms.TextBox()
        Me.LTScaleCompensator = New System.Windows.Forms.TextBox()
        Me.LTScaleCompensatorlbl = New System.Windows.Forms.Label()
        Me.NewPSLTSCALE = New System.Windows.Forms.CheckBox()
        Me.sstStatus = New System.Windows.Forms.StatusStrip()
        Me.tssMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.gbxModelSpaceScale = New System.Windows.Forms.GroupBox()
        Me.LTScaleViewTextBox = New System.Windows.Forms.TextBox()
        Me.LTScaleViewTextBoxLabel = New System.Windows.Forms.Label()
        Me.newDimScaleTextBox = New System.Windows.Forms.TextBox()
        Me.newDimScaleLabel = New System.Windows.Forms.Label()
        Me.DecimalScale = New System.Windows.Forms.TextBox()
        Me.DecimalScaleLabel = New System.Windows.Forms.Label()
        Me.gbxLineTypeScaling.SuspendLayout()
        Me.sstStatus.SuspendLayout()
        Me.gbxModelSpaceScale.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxLineTypeScaling
        '
        Me.gbxLineTypeScaling.BackColor = System.Drawing.SystemColors.Control
        Me.gbxLineTypeScaling.Controls.Add(Me.newLTSCALElbl)
        Me.gbxLineTypeScaling.Controls.Add(Me.newLTSCALETextBox)
        Me.gbxLineTypeScaling.Controls.Add(Me.LTScaleCompensator)
        Me.gbxLineTypeScaling.Controls.Add(Me.LTScaleCompensatorlbl)
        Me.gbxLineTypeScaling.Controls.Add(Me.NewPSLTSCALE)
        Me.gbxLineTypeScaling.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxLineTypeScaling.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.gbxLineTypeScaling.Location = New System.Drawing.Point(6, 133)
        Me.gbxLineTypeScaling.Name = "gbxLineTypeScaling"
        Me.gbxLineTypeScaling.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.gbxLineTypeScaling.Size = New System.Drawing.Size(338, 111)
        Me.gbxLineTypeScaling.TabIndex = 2
        Me.gbxLineTypeScaling.TabStop = False
        Me.gbxLineTypeScaling.Text = "Linetypes"
        '
        'newLTSCALElbl
        '
        Me.newLTSCALElbl.AutoSize = True
        Me.newLTSCALElbl.BackColor = System.Drawing.SystemColors.Control
        Me.newLTSCALElbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.newLTSCALElbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.newLTSCALElbl.Location = New System.Drawing.Point(35, 23)
        Me.newLTSCALElbl.Name = "newLTSCALElbl"
        Me.newLTSCALElbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newLTSCALElbl.Size = New System.Drawing.Size(90, 13)
        Me.newLTSCALElbl.TabIndex = 19
        Me.newLTSCALElbl.Text = "Global LTSCALE:"
        '
        'newLTSCALETextBox
        '
        Me.newLTSCALETextBox.AcceptsReturn = True
        Me.newLTSCALETextBox.BackColor = System.Drawing.SystemColors.Window
        Me.newLTSCALETextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.newLTSCALETextBox.Enabled = False
        Me.newLTSCALETextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.newLTSCALETextBox.Location = New System.Drawing.Point(136, 20)
        Me.newLTSCALETextBox.MaxLength = 0
        Me.newLTSCALETextBox.Name = "newLTSCALETextBox"
        Me.newLTSCALETextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newLTSCALETextBox.Size = New System.Drawing.Size(107, 20)
        Me.newLTSCALETextBox.TabIndex = 18
        '
        'LTScaleCompensator
        '
        Me.LTScaleCompensator.AcceptsReturn = True
        Me.LTScaleCompensator.BackColor = System.Drawing.SystemColors.Window
        Me.LTScaleCompensator.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LTScaleCompensator.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LTScaleCompensator.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LTScaleCompensator.Location = New System.Drawing.Point(136, 47)
        Me.LTScaleCompensator.MaxLength = 0
        Me.LTScaleCompensator.Name = "LTScaleCompensator"
        Me.LTScaleCompensator.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleCompensator.Size = New System.Drawing.Size(107, 21)
        Me.LTScaleCompensator.TabIndex = 15
        '
        'LTScaleCompensatorlbl
        '
        Me.LTScaleCompensatorlbl.AutoSize = True
        Me.LTScaleCompensatorlbl.BackColor = System.Drawing.SystemColors.Control
        Me.LTScaleCompensatorlbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.LTScaleCompensatorlbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LTScaleCompensatorlbl.ForeColor = System.Drawing.Color.Black
        Me.LTScaleCompensatorlbl.Location = New System.Drawing.Point(10, 50)
        Me.LTScaleCompensatorlbl.Name = "LTScaleCompensatorlbl"
        Me.LTScaleCompensatorlbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleCompensatorlbl.Size = New System.Drawing.Size(120, 13)
        Me.LTScaleCompensatorlbl.TabIndex = 14
        Me.LTScaleCompensatorlbl.Text = "LTSCALE Compensator:"
        Me.LTScaleCompensatorlbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'NewPSLTSCALE
        '
        Me.NewPSLTSCALE.BackColor = System.Drawing.SystemColors.Control
        Me.NewPSLTSCALE.Cursor = System.Windows.Forms.Cursors.Default
        Me.NewPSLTSCALE.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NewPSLTSCALE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NewPSLTSCALE.Location = New System.Drawing.Point(18, 74)
        Me.NewPSLTSCALE.Name = "NewPSLTSCALE"
        Me.NewPSLTSCALE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NewPSLTSCALE.Size = New System.Drawing.Size(225, 24)
        Me.NewPSLTSCALE.TabIndex = 2
        Me.NewPSLTSCALE.Text = "Use PSLTSCALE for paperspace scaling"
        Me.NewPSLTSCALE.UseVisualStyleBackColor = False
        '
        'sstStatus
        '
        Me.sstStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tssMessage})
        Me.sstStatus.Location = New System.Drawing.Point(6, 597)
        Me.sstStatus.Name = "sstStatus"
        Me.sstStatus.Size = New System.Drawing.Size(338, 22)
        Me.sstStatus.TabIndex = 51
        Me.sstStatus.Text = "StatusStrip1"
        '
        'tssMessage
        '
        Me.tssMessage.Name = "tssMessage"
        Me.tssMessage.Size = New System.Drawing.Size(22, 17)
        Me.tssMessage.Text = "xxx"
        '
        'gbxModelSpaceScale
        '
        Me.gbxModelSpaceScale.BackColor = System.Drawing.SystemColors.Control
        Me.gbxModelSpaceScale.Controls.Add(Me.LTScaleViewTextBox)
        Me.gbxModelSpaceScale.Controls.Add(Me.LTScaleViewTextBoxLabel)
        Me.gbxModelSpaceScale.Controls.Add(Me.newDimScaleTextBox)
        Me.gbxModelSpaceScale.Controls.Add(Me.newDimScaleLabel)
        Me.gbxModelSpaceScale.Controls.Add(Me.DecimalScale)
        Me.gbxModelSpaceScale.Controls.Add(Me.DecimalScaleLabel)
        Me.gbxModelSpaceScale.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxModelSpaceScale.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.gbxModelSpaceScale.Location = New System.Drawing.Point(6, 6)
        Me.gbxModelSpaceScale.Name = "gbxModelSpaceScale"
        Me.gbxModelSpaceScale.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.gbxModelSpaceScale.Size = New System.Drawing.Size(338, 127)
        Me.gbxModelSpaceScale.TabIndex = 52
        Me.gbxModelSpaceScale.TabStop = False
        Me.gbxModelSpaceScale.Text = "Model Space Scale"
        '
        'LTScaleViewTextBox
        '
        Me.LTScaleViewTextBox.AcceptsReturn = True
        Me.LTScaleViewTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.LTScaleViewTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.LTScaleViewTextBox.Enabled = False
        Me.LTScaleViewTextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LTScaleViewTextBox.Location = New System.Drawing.Point(136, 51)
        Me.LTScaleViewTextBox.MaxLength = 0
        Me.LTScaleViewTextBox.Name = "LTScaleViewTextBox"
        Me.LTScaleViewTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleViewTextBox.Size = New System.Drawing.Size(107, 20)
        Me.LTScaleViewTextBox.TabIndex = 26
        '
        'LTScaleViewTextBoxLabel
        '
        Me.LTScaleViewTextBoxLabel.AutoSize = True
        Me.LTScaleViewTextBoxLabel.BackColor = System.Drawing.SystemColors.Control
        Me.LTScaleViewTextBoxLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.LTScaleViewTextBoxLabel.Enabled = False
        Me.LTScaleViewTextBoxLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LTScaleViewTextBoxLabel.Location = New System.Drawing.Point(35, 54)
        Me.LTScaleViewTextBoxLabel.Name = "LTScaleViewTextBoxLabel"
        Me.LTScaleViewTextBoxLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LTScaleViewTextBoxLabel.Size = New System.Drawing.Size(87, 13)
        Me.LTScaleViewTextBoxLabel.TabIndex = 25
        Me.LTScaleViewTextBoxLabel.Text = "Line Type Scale:"
        '
        'newDimScaleTextBox
        '
        Me.newDimScaleTextBox.AcceptsReturn = True
        Me.newDimScaleTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.newDimScaleTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.newDimScaleTextBox.Enabled = False
        Me.newDimScaleTextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.newDimScaleTextBox.Location = New System.Drawing.Point(136, 78)
        Me.newDimScaleTextBox.MaxLength = 0
        Me.newDimScaleTextBox.Name = "newDimScaleTextBox"
        Me.newDimScaleTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newDimScaleTextBox.Size = New System.Drawing.Size(107, 20)
        Me.newDimScaleTextBox.TabIndex = 24
        '
        'newDimScaleLabel
        '
        Me.newDimScaleLabel.AutoSize = True
        Me.newDimScaleLabel.BackColor = System.Drawing.SystemColors.Control
        Me.newDimScaleLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.newDimScaleLabel.Enabled = False
        Me.newDimScaleLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.newDimScaleLabel.Location = New System.Drawing.Point(35, 81)
        Me.newDimScaleLabel.Name = "newDimScaleLabel"
        Me.newDimScaleLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.newDimScaleLabel.Size = New System.Drawing.Size(89, 13)
        Me.newDimScaleLabel.TabIndex = 23
        Me.newDimScaleLabel.Text = "Dimension Scale:"
        '
        'DecimalScale
        '
        Me.DecimalScale.AcceptsReturn = True
        Me.DecimalScale.BackColor = System.Drawing.SystemColors.Window
        Me.DecimalScale.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.DecimalScale.Enabled = False
        Me.DecimalScale.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DecimalScale.Location = New System.Drawing.Point(136, 20)
        Me.DecimalScale.MaxLength = 0
        Me.DecimalScale.Name = "DecimalScale"
        Me.DecimalScale.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DecimalScale.Size = New System.Drawing.Size(107, 20)
        Me.DecimalScale.TabIndex = 21
        '
        'DecimalScaleLabel
        '
        Me.DecimalScaleLabel.AutoSize = True
        Me.DecimalScaleLabel.BackColor = System.Drawing.SystemColors.Control
        Me.DecimalScaleLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.DecimalScaleLabel.Enabled = False
        Me.DecimalScaleLabel.ForeColor = System.Drawing.Color.DarkRed
        Me.DecimalScaleLabel.Location = New System.Drawing.Point(35, 23)
        Me.DecimalScaleLabel.Name = "DecimalScaleLabel"
        Me.DecimalScaleLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DecimalScaleLabel.Size = New System.Drawing.Size(78, 13)
        Me.DecimalScaleLabel.TabIndex = 22
        Me.DecimalScaleLabel.Text = "Decimal Scale:"
        '
        'P3_Scale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.sstStatus)
        Me.Controls.Add(Me.gbxLineTypeScaling)
        Me.Controls.Add(Me.gbxModelSpaceScale)
        Me.Name = "P3_Scale"
        Me.Padding = New System.Windows.Forms.Padding(6)
        Me.Size = New System.Drawing.Size(350, 625)
        Me.gbxLineTypeScaling.ResumeLayout(False)
        Me.gbxLineTypeScaling.PerformLayout()
        Me.sstStatus.ResumeLayout(False)
        Me.sstStatus.PerformLayout()
        Me.gbxModelSpaceScale.ResumeLayout(False)
        Me.gbxModelSpaceScale.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents gbxLineTypeScaling As System.Windows.Forms.GroupBox
    Public WithEvents newLTSCALElbl As System.Windows.Forms.Label
    Public WithEvents newLTSCALETextBox As System.Windows.Forms.TextBox
    Public WithEvents LTScaleCompensator As System.Windows.Forms.TextBox
    Public WithEvents LTScaleCompensatorlbl As System.Windows.Forms.Label
    Public WithEvents NewPSLTSCALE As System.Windows.Forms.CheckBox
    Friend WithEvents sstStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents tssMessage As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents gbxModelSpaceScale As Windows.Forms.GroupBox
    Public WithEvents LTScaleViewTextBox As Windows.Forms.TextBox
    Public WithEvents LTScaleViewTextBoxLabel As Windows.Forms.Label
    Public WithEvents newDimScaleTextBox As Windows.Forms.TextBox
    Public WithEvents newDimScaleLabel As Windows.Forms.Label
    Public WithEvents DecimalScale As Windows.Forms.TextBox
    Public WithEvents DecimalScaleLabel As Windows.Forms.Label
End Class
