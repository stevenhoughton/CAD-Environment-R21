﻿Public Module ListBoxes

    Public Function FindStringInListBox(ByVal searchString As String, MyListBox As ListBox) As Boolean

        Dim Result As Boolean = False

        ' Ensure we have a proper string to search for. 
        If searchString <> String.Empty Then

            ' Find the item in the list and store the index to the item. 
            Dim index As Integer = MyListBox.FindStringExact(searchString)

            ' Determine if a valid index is returned. Select the item if it is valid. 
            If index <> ListBox.NoMatches Then
                '  MyListBox.SetSelected(index, True)
                Result = True
            Else
                Result = False
            End If

        End If

        Return Result

    End Function

    Public Function FindStringInComboBox(ByVal searchString As String, MyComboBox As ComboBox) As Boolean

        Dim Result As Boolean = False

        ' Ensure we have a proper string to search for. 
        If searchString <> String.Empty Then

            ' Find the item in the list and store the index to the item. 
            Dim index As Integer = MyComboBox.FindStringExact(searchString)

            ' Determine if a valid index is returned. Select the item if it is valid. 
            If index <> ListBox.NoMatches Then
                'MyListBox.SetSelected(index, True)
                Result = True
            Else
                Result = False
            End If

        End If

        Return Result

    End Function

End Module
