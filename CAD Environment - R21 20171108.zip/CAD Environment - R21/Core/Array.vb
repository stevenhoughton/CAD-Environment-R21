﻿'' Copyright (c) 2010, Sinclaire Knight Mertz, Brisbane 4000, Australia.
'' All Rights Reserved.

''' <summary>
''' Array helper functions
''' </summary>
''' <remarks></remarks>
Public Module Array

    ''' <summary>
    ''' Duplicate/copy array of strings
    ''' </summary>
    ''' <param name="src"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Copy(ByVal src() As String) As String()

        '' allocate
        Dim dst As New System.Collections.Generic.List(Of String)
        Dim s As String

        '' bail if failed to allocate
        If dst Is Nothing Then
            Return Nothing
        End If

        '' bail if no input ... just return an empty array
        If src Is Nothing Or src.Length <= 0 Then
            Return dst.ToArray()
        End If

        '' copy accross strings
        For Each s In src
            dst.Add(s)
        Next

        '' return newly create array of strings
        Return dst.ToArray()

    End Function


    ''' <summary>
    ''' Duplicate/copy array of doubles
    ''' </summary>
    ''' <param name="src"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CopyDoubles(ByVal src() As Double) As Double()

        '' allocate
        Dim dst As New System.Collections.Generic.List(Of Double)
        Dim s As String

        '' bail if failed to allocate
        If dst Is Nothing Then
            Return Nothing
        End If

        '' bail if no input ... just return an empty array
        If src Is Nothing Or src.Length <= 0 Then
            Return dst.ToArray()
        End If

        '' copy accross doubles
        For Each s In src
            dst.Add(CDbl(s))
        Next

        '' return newly create array of strings
        Return dst.ToArray()

    End Function

End Module
