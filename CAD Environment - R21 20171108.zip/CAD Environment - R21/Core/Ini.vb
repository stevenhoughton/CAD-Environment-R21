﻿'' Copyright (c) 2010, Sinclaire Knight Mertz, Brisbane 4000, Australia.
'' All Rights Reserved.

Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Collections
Imports System.Diagnostics
Imports System.Collections.Generic

''' <summary>
''' IniFile class used to read and write ini files by loading the file into memory
''' </summary>
''' <remarks></remarks>
Public Class Ini

    ' List of IniSection objects keeps track of all the sections in the INI file
    Private _Sections As Hashtable

    ''' <summary>
    ''' Public constructor
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New()
        _Sections = New Hashtable(StringComparer.InvariantCultureIgnoreCase)
    End Sub

    ''' <summary>
    ''' Loads the Reads the data in the ini file into the IniFile object
    ''' </summary>
    ''' <param name="sFileName"></param>
    ''' <param name="bMerge"></param>
    ''' <remarks></remarks>
    Public Sub Load(ByVal sFileName As String, Optional ByVal bMerge As Boolean = False)

        If Not bMerge Then
            RemoveAllSections()
        End If

        '  Clear the object... 
        Dim tempsection As IniSection = Nothing
        Dim oReader As New StreamReader(sFileName)
        Dim regexcomment As New Regex("^([\s]*#.*)", (RegexOptions.Singleline Or RegexOptions.IgnoreCase))

        ' Broken but left for history
        'Dim regexsection As New Regex("\[[\s]*([^\[\s].*[^\s\]])[\s]*\]", (RegexOptions.Singleline Or RegexOptions.IgnoreCase))

        Dim regexsection As New Regex("^[\s]*\[[\s]*([^\[\s].*[^\s\]])[\s]*\][\s]*$", (RegexOptions.Singleline Or RegexOptions.IgnoreCase))
        'Dim regexkey As New Regex("^\s*([^=\s]*)[^=]*=(.*)", (RegexOptions.Singleline Or RegexOptions.IgnoreCase))
        Dim regexkey As New Regex("^\s*([^=\n\f\t\r\n]*)[^=]*=(.*)", (RegexOptions.Singleline Or RegexOptions.IgnoreCase))

        While Not oReader.EndOfStream
            Dim line As String = oReader.ReadLine()
            If line <> String.Empty Then
                Dim m As Match = Nothing
                If regexcomment.Match(line).Success Then
                    m = regexcomment.Match(line)
                    Trace.WriteLine(String.Format("Skipping Comment: {0}", m.Groups(0).Value))
                ElseIf regexsection.Match(line).Success Then
                    m = regexsection.Match(line)
                    Trace.WriteLine(String.Format("Adding section [{0}]", m.Groups(1).Value))
                    tempsection = AddSection(m.Groups(1).Value)
                ElseIf regexkey.Match(line).Success AndAlso tempsection IsNot Nothing Then
                    m = regexkey.Match(line)
                    Trace.WriteLine(String.Format("Adding Key [{0}]=[{1}]", m.Groups(1).Value, m.Groups(2).Value))
                    tempsection.AddKey(m.Groups(1).Value).Value = m.Groups(2).Value
                ElseIf tempsection IsNot Nothing Then
                    '  Handle Key without value
                    Trace.WriteLine(String.Format("Adding Key [{0}]", line))
                    tempsection.AddKey(line)
                Else
                    '  This should not occur unless the tempsection is not created yet...
                    Trace.WriteLine(String.Format("Skipping unknown type of data: {0}", line))
                End If
            End If
        End While
        oReader.Close()
    End Sub

    ''' <summary>
    ''' Used to save the data back to the file or your choice
    ''' </summary>
    ''' <param name="sFileName"></param>
    ''' <remarks></remarks>
    Public Sub Save(ByVal sFileName As String)
        Dim oWriter As New StreamWriter(sFileName, False)
        For Each s As IniSection In Sections
            Trace.WriteLine(String.Format("Writing Section: [{0}]", s.Name))
            oWriter.WriteLine(String.Format("[{0}]", s.Name))
            For Each k As IniSection.IniKey In s.Keys
                If k.Value <> String.Empty Then
                    Trace.WriteLine(String.Format("Writing Key: {0}={1}", k.Name, k.Value))
                    oWriter.WriteLine(String.Format("{0}={1}", k.Name, k.Value))
                Else
                    Trace.WriteLine(String.Format("Writing Key: {0}", k.Name))
                    oWriter.WriteLine(String.Format("{0}", k.Name))
                End If
            Next
        Next
        oWriter.Close()
    End Sub

    ''' <summary>
    ''' Reads an ini file section and key
    ''' </summary>
    ''' <param name="ini"></param>
    ''' <param name="section"></param>
    ''' <param name="key"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Read(ByVal ini As String, ByVal section As String, ByVal key As String) As String

        '' bail if file does not exist
        If Not System.IO.File.Exists(ini) Then
            Return vbNullString
        End If

        '' create and load
        Dim data As New Ini()
        data.Load(ini)

        '' get section
        Dim datasection As IniSection = data.GetSection(section)
        If (datasection Is Nothing) Then
            Return vbNullString
        End If

        '' get key
        Dim datakey As IniSection.IniKey = datasection.GetKey(key)
        If (datakey Is Nothing) Then
            Return vbNullString
        End If

        '' finally
        Return datakey.Value

    End Function

    ''' <summary>
    ''' Reads a whole section and the values are turned into lists of strings
    ''' </summary>
    ''' <param name="ini"></param>
    ''' <param name="section"></param>
    ''' <param name="del"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ReadValues(ByVal ini As String, ByVal section As String, ByVal del As String) As Dictionary(Of String, List(Of String))

        '' bail if file does not exist
        If Not System.IO.File.Exists(ini) Then
            Return Nothing
        End If

        '' create and load
        Dim data As New Ini()
        data.Load(ini)

        '' get section
        Dim datasection As IniSection = data.GetSection(section)
        If (datasection Is Nothing) Then
            Return Nothing
        End If

        '' result
        Dim results As New Dictionary(Of String, List(Of String))

        '' get all the keys
        For Each key As IniSection.IniKey In datasection.Keys

            '' get the value of this key
            Dim value As String = key.Value
            If String.IsNullOrEmpty(value) Then
                Continue For
            End If

            '' the value
            Dim values As New List(Of String)(value.Split(CChar(del)))

            '' save
            results(key.Name) = values

        Next

        '' yahoo
        Return results

    End Function

    ''' <summary>
    ''' Writes an ini file section and key
    ''' </summary>
    ''' <param name="ini"></param>
    ''' <param name="section"></param>
    ''' <param name="key"></param>
    ''' <param name="value"></param>
    ''' <remarks></remarks>
    Public Shared Sub Write(ByVal ini As String, ByVal section As String, ByVal key As String, ByVal value As String)

        '' create an ini object
        Dim data As New Ini()

        '' bail if file does not exist
        If System.IO.File.Exists(ini) Then
            data.Load(ini)
        End If

        '' add
        data.AddSection(section).AddKey(key).Value = value

        '' save
        data.Save(ini)

    End Sub

    ''' <summary>
    ''' Gets all the sections
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Sections() As System.Collections.ICollection
        Get
            Return _Sections.Values
        End Get
    End Property

    ''' <summary>
    ''' Adds a section to the IniFile object, returns a IniSection object to the new or existing object
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function AddSection(ByVal sSection As String) As IniSection
        Dim s As IniSection = Nothing
        sSection = sSection.Trim()
        ' Trim spaces
        If _Sections.ContainsKey(sSection) Then
            s = DirectCast(_Sections(sSection), IniSection)
        Else
            s = New IniSection(Me, sSection)
            _Sections(sSection) = s
        End If
        Return s
    End Function

    ''' <summary>
    ''' Removes a section by its name sSection, returns trus on success
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RemoveSection(ByVal sSection As String) As Boolean
        sSection = sSection.Trim()
        Return RemoveSection(GetSection(sSection))
    End Function

    ''' <summary>
    ''' Removes section by object, returns trus on success
    ''' </summary>
    ''' <param name="Section"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RemoveSection(ByVal Section As IniSection) As Boolean
        If Section IsNot Nothing Then
            Try
                _Sections.Remove(Section.Name)
                Return True
            Catch ex As Exception
                Trace.WriteLine(ex.Message)
            End Try
        End If
        Return False
    End Function

    ''' <summary>
    ''' Removes all existing sections, returns trus on success
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RemoveAllSections() As Boolean
        _Sections.Clear()
        Return (_Sections.Count = 0)
    End Function

    ''' <summary>
    ''' Returns an IniSection to the section by name, NULL if it was not found
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetSection(ByVal sSection As String) As IniSection
        sSection = sSection.Trim()
        ' Trim spaces
        If _Sections.ContainsKey(sSection) Then
            Return DirectCast(_Sections(sSection), IniSection)
        End If
        Return Nothing
    End Function

    ''' <summary>
    ''' Returns a KeyValue in a certain section
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <param name="sKey"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetKeyValue(ByVal sSection As String, ByVal sKey As String) As String
        Dim s As IniSection = GetSection(sSection)
        If s IsNot Nothing Then
            Dim k As IniSection.IniKey = s.GetKey(sKey)
            If k IsNot Nothing Then
                Return k.Value
            End If
        End If
        Return String.Empty
    End Function

    ''' <summary>
    ''' Sets a KeyValuePair in a certain section
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <param name="sKey"></param>
    ''' <param name="sValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SetKeyValue(ByVal sSection As String, ByVal sKey As String, ByVal sValue As String) As Boolean
        Dim s As IniSection = AddSection(sSection)
        If s IsNot Nothing Then
            Dim k As IniSection.IniKey = s.AddKey(sKey)
            If k IsNot Nothing Then
                k.Value = sValue
                Return True
            End If
        End If
        Return False
    End Function

    ''' <summary>
    ''' Renames an existing section returns true on success, false if the section didn't exist or there was another section with the same sNewSection
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <param name="sNewSection"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RenameSection(ByVal sSection As String, ByVal sNewSection As String) As Boolean
        '  Note string trims are done in lower calls.
        Dim bRval As Boolean = False
        Dim s As IniSection = GetSection(sSection)
        If s IsNot Nothing Then
            bRval = s.SetName(sNewSection)
        End If
        Return bRval
    End Function

    ''' <summary>
    ''' Renames an existing key returns true on success, false if the key didn't exist or there was another section with the same sNewKey
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <param name="sKey"></param>
    ''' <param name="sNewKey"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RenameKey(ByVal sSection As String, ByVal sKey As String, ByVal sNewKey As String) As Boolean
        '  Note string trims are done in lower calls.
        Dim s As IniSection = GetSection(sSection)
        If s IsNot Nothing Then
            Dim k As IniSection.IniKey = s.GetKey(sKey)
            If k IsNot Nothing Then
                Return k.SetName(sNewKey)
            End If
        End If
        Return False
    End Function

    ''' <summary>
    ''' Remove a key by section name and key name
    ''' </summary>
    ''' <param name="sSection"></param>
    ''' <param name="sKey"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function RemoveKey(ByVal sSection As String, ByVal sKey As String) As Boolean
        Dim s As IniSection = GetSection(sSection)
        If s IsNot Nothing Then
            Return s.RemoveKey(sKey)
        End If
        Return False
    End Function

    ''' <summary>
    ''' IniSection class 
    ''' </summary>
    ''' <remarks></remarks>
    Public Class IniSection

        '  IniFile IniFile object instance
        Private _IniFile As Ini

        '  Name of the section
        Private _Section As String

        '  List of IniKeys in the section
        Private _Keys As Dictionary(Of String, IniKey)

        ''' <summary>
        ''' Constuctor so objects are internally managed
        ''' </summary>
        ''' <param name="parent"></param>
        ''' <param name="sSection"></param>
        ''' <remarks></remarks>
        Protected Friend Sub New(ByVal parent As Ini, ByVal sSection As String)
            _IniFile = parent
            _Section = sSection
            _Keys = New Dictionary(Of String, IniKey)
        End Sub

        ''' <summary>
        ''' Returns all the keys in a section
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property Keys As List(Of IniKey)
            Get
                Dim ks As New List(Of IniKey)()
                For Each record As KeyValuePair(Of String, IniKey) In _Keys
                    ks.Add(record.Value)
                Next
                Return ks
            End Get
        End Property

        ''' <summary>
        ''' Returns the section name
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property Name() As String
            Get
                Return _Section
            End Get
        End Property

        ''' <summary>
        ''' Adds a key to the IniSection object, returns a IniKey object to the new or existing object
        ''' </summary>
        ''' <param name="sKey"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function AddKey(ByVal sKey As String) As IniKey
            sKey = sKey.Trim()
            Dim k As IniSection.IniKey = Nothing
            If sKey.Length <> 0 Then
                If _Keys.ContainsKey(sKey) Then
                    k = _Keys(sKey)
                Else
                    k = New IniSection.IniKey(Me, sKey)
                    _Keys(sKey) = k
                End If
            End If
            Return k
        End Function

        ''' <summary>
        ''' Removes a single key by string
        ''' </summary>
        ''' <param name="sKey"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function RemoveKey(ByVal sKey As String) As Boolean
            Return RemoveKey(GetKey(sKey))
        End Function

        ''' <summary>
        ''' Removes a single key by IniKey object
        ''' </summary>
        ''' <param name="Key"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function RemoveKey(ByVal Key As IniKey) As Boolean
            If Key IsNot Nothing Then
                Try
                    _Keys.Remove(Key.Name)
                    Return True
                Catch ex As Exception
                    Trace.WriteLine(ex.Message)
                End Try
            End If
            Return False
        End Function

        ''' <summary>
        ''' Removes all the keys in the section
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function RemoveAllKeys() As Boolean
            _Keys.Clear()
            Return (_Keys.Count = 0)
        End Function

        ''' <summary>
        ''' Returns a IniKey object to the key by name, NULL if it was not found
        ''' </summary>
        ''' <param name="sKey"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetKey(ByVal sKey As String) As IniKey
            sKey = sKey.Trim()
            If _Keys.ContainsKey(sKey) Then
                Return DirectCast(_Keys(sKey), IniKey)
            End If
            Return Nothing
        End Function

        ''' <summary>
        ''' Sets the section name, returns true on success, fails if the section name sSection already exists
        ''' </summary>
        ''' <param name="sSection"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function SetName(ByVal sSection As String) As Boolean
            sSection = sSection.Trim()
            If sSection.Length <> 0 Then
                ' Get existing section if it even exists...
                Dim s As IniSection = _IniFile.GetSection(sSection)
                If s IsNot Me AndAlso s IsNot Nothing Then
                    Return False
                End If
                Try
                    ' Remove the current section
                    _IniFile._Sections.Remove(_Section)

                    ' Set the new section name to this object
                    _IniFile._Sections(sSection) = Me

                    ' Set the new section name
                    _Section = sSection
                    Return True
                Catch ex As Exception
                    Trace.WriteLine(ex.Message)
                End Try
            End If
            Return False
        End Function

        ''' <summary>
        ''' Returns the section name
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Function GetName() As String
            Return _Section
        End Function

        ''' <summary>
        ''' IniKey class
        ''' </summary>
        ''' <remarks></remarks>
        Public Class IniKey

            '  Name of the Key
            Private _Key As String

            '  Value associated
            Private _Value As String

            '  Pointer to the parent CIniSection
            Private _Section As IniSection

            ''' <summary>
            ''' Constuctor so objects are internally managed
            ''' </summary>
            ''' <param name="parent"></param>
            ''' <param name="sKey"></param>
            ''' <remarks></remarks>
            Protected Friend Sub New(ByVal parent As IniSection, ByVal sKey As String)
                _Section = parent
                _Key = sKey
            End Sub

            ''' <summary>
            ''' Returns the name of the Key
            ''' </summary>
            ''' <value></value>
            ''' <returns></returns>
            ''' <remarks></remarks>
            Public ReadOnly Property Name() As String
                Get
                    Return _Key
                End Get
            End Property

            ''' <summary>
            ''' Sets or Gets the value of the key
            ''' </summary>
            ''' <value></value>
            ''' <returns></returns>
            ''' <remarks></remarks>
            Public Property Value() As String
                Get
                    Return _Value
                End Get
                Set(ByVal value As String)
                    _Value = value
                End Set
            End Property

            ''' <summary>
            ''' Sets the value of the key
            ''' </summary>
            ''' <param name="sValue"></param>
            ''' <remarks></remarks>
            Public Sub SetValue(ByVal sValue As String)
                _Value = sValue
            End Sub

            ' Returns the value of the Key
            Public Function GetValue() As String
                Return _Value
            End Function

            ''' <summary>
            ''' Sets the key name. Returns true on success, fails if the section name sKey already exists
            ''' </summary>
            ''' <param name="sKey"></param>
            ''' <returns></returns>
            ''' <remarks></remarks>
            Public Function SetName(ByVal sKey As String) As Boolean
                sKey = sKey.Trim()
                If sKey.Length <> 0 Then
                    Dim k As IniKey = _Section.GetKey(sKey)
                    If k IsNot Me AndAlso k IsNot Nothing Then
                        Return False
                    End If
                    Try
                        ' Remove the current key
                        _Section._Keys.Remove(_Key)
                        ' Set the new key name to this object
                        _Section._Keys(sKey) = Me
                        ' Set the new key name
                        _Key = sKey
                        Return True
                    Catch ex As Exception
                        Trace.WriteLine(ex.Message)
                    End Try
                End If
                Return False
            End Function

            ''' <summary>
            ''' Returns the name of the Key
            ''' </summary>
            ''' <returns></returns>
            ''' <remarks></remarks>
            Public Function GetName() As String
                Return _Key
            End Function

        End Class

    End Class

End Class