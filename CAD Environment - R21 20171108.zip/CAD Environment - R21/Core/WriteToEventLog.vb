﻿Imports System
Imports System.Diagnostics
Imports System.Threading
Imports Jacobs.Common.Core

Public Module EventLogging

    ''' <summary>
    ''' Pass a msg as text and the name of a log file to use
    ''' 
    ''' Example:
    '''      WriteToLog("MyMessage", "MyTool-Runtime.log")
    ''' 
    ''' The log folder will be created if not present 
    ''' All logs written to the same folder
    ''' Every message sent is written on a new line with the current date and time as a prefix
    ''' </summary>
    ''' <param name="msg"></param>
    ''' <remarks></remarks>
    Public Sub WriteToLog(ByVal msg As String, ByVal sLogName As String)
        Try

            '' Writes to the public area - C:\Public\Documents\Jacobs\.... then the sent log name file
            sLogName = sLogName.Replace(".dll", ".log")

            If sLogName.EndsWith(".log") Then

            Else
                sLogName = sLogName & ".log"
            End If

            Dim slogfile As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("Jacobs\Jacobs AutoCAD Environment R21", sLogName)
            'Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]\[AEPRODUCTNAME]"))

            If Not System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(slogfile)) Then
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(slogfile))
            End If

            System.IO.File.AppendAllText(slogfile, vbCrLf & DateAndTime.Now.ToString & " -- " & msg)

        Catch ex As Exception
            GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Delete log file 
    ''' Delete can be delayed by X days
    ''' Parent folder may also be deleted at same time
    ''' </summary>
    ''' <param name="FileToDelete"></param>
    ''' <param name="DeleteParentFolder"></param>
    ''' <param name="DeleteAfterXDays"></param>
    ''' <remarks></remarks>
    Public Sub DeleteLogFile(ByVal FileToDelete As String, Optional ByVal DeleteParentFolder As Boolean = False, Optional ByVal DeleteAfterXDays As Integer = 0)
        Try

            Dim slogfile As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData).CombinePath("Jacobs", FileToDelete)

            If System.IO.File.Exists(slogfile) Then

                Dim filedate As Date = System.IO.File.GetCreationTime(slogfile)
                Dim TimeElapsed As TimeSpan = DateTime.Now.Subtract(filedate)

                If DeleteAfterXDays = 0 Then
                    System.IO.File.Delete(slogfile)
                    If DeleteParentFolder = True Then
                        System.IO.Directory.Delete(System.IO.Path.GetDirectoryName(slogfile))
                    End If
                Else
                    If TimeElapsed.Days > DeleteAfterXDays Then
                        System.IO.File.Delete(slogfile)
                        If DeleteParentFolder = True Then
                            System.IO.Directory.Delete(System.IO.Path.GetDirectoryName(slogfile))
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
        End Try

    End Sub

End Module
