﻿Imports System.Xml.Serialization
Imports System.IO
Imports System.Xml.Linq
Imports System.Linq
Imports System.Xml

Public Module XML

    ''' <summary>
    ''' Find the child object in the list
    ''' </summary>
    ''' <param name="prop"></param>
    ''' <param name="value"></param>
    ''' <param name="list"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function FindChild(prop As String, value As String, list As IEnumerable) As Object

        '' scroll thru
        For Each o As Object In list

            '' get property value
            Dim child As Object = Properties.GetValue(prop, o)
            If child Is Nothing Then
                Continue For
            End If

            '' compare
            If String.Compare(value, child.ToString(), True) = 0 Then
                Return o
            End If
        Next

        '' nothing found
        Return Nothing

    End Function

    ''' <summary>
    ''' Find the named child element
    ''' </summary>
    ''' <param name="e"></param>
    ''' <param name="key"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function FindElement(ByVal e As XElement, ByVal key As String) As String

        '' bail if no children
        If Not e.HasElements Then
            Return ""
        End If

        '' scroll thru children
        For Each child As XElement In e.Elements

            '' get name
            Dim n As String = child.Name.ToString()
            If String.IsNullOrEmpty(n) Then
                Continue For
            End If

            '' compare
            If String.Compare(key, n, True) = 0 Then

                '' do something here
                Return child.Value.ToString

            End If

        Next

        '' bugger
        Return ""

    End Function

    ''' <summary>
    ''' Merge the elements into the object
    ''' </summary>
    ''' <param name="elements"></param>
    ''' <param name="o"></param>
    ''' <remarks></remarks>
    Private Sub Merge(ByVal elements As System.Collections.Generic.IEnumerable(Of XNode), ByVal o As Object)

        '' scroll thru properties
        For Each element As XElement In elements

            '' get the name of the property
            Dim name As String = element.Name.ToString()

            '' children?
            If Not element.HasElements Then

                '' get the element value
                Dim value As Object = element.Value

                '' must have a value
                If Not value Is Nothing Then

                    '' save the property field
                    Properties.SetValue(name, o, value)

                End If

            Else


                '' get object
                Dim prop As Object = Properties.GetValue(name, o)
                If prop Is Nothing Then
                    Continue For
                End If

                '' a list?
                Dim list As IEnumerable = CType(prop, IEnumerable)
                If Not list Is Nothing Then

                    '' scroll thru items
                    For Each e As XElement In element.Elements

                        '' get name?
                        Dim n As String = FindElement(e, "Name")
                        If String.IsNullOrEmpty(n) Then
                            Continue For
                        End If

                        '' find the child object
                        Dim child As Object = FindChild("Name", n, list)
                        If child Is Nothing Then
                            Continue For
                        End If

                        '' drill down
                        Merge(e.Elements, child)

                    Next

                Else

                    '' drill down
                    Merge(element.Elements, prop)

                End If

            End If

        Next

    End Sub

    ''' <summary>
    ''' Merge these two files
    ''' </summary>
    ''' <param name="o"></param>
    ''' <param name="snippet"></param>
    ''' <remarks></remarks>
    Public Sub Merge(o As Object, snippet As String)

        Try

            '' loads the docs
            Dim xml As XDocument = XDocument.Load(snippet)

            '' get first levels properties
            Dim elements As System.Collections.Generic.IEnumerable(Of XNode) = xml.Elements.Elements

            '' do it
            Merge(elements, o)

        Catch ex As Exception

        End Try

    End Sub

    ''' <summary>
    ''' Save a configuration object to disk as an XML file
    ''' </summary>
    ''' <param name="filename"></param>
    ''' <param name="config"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Save(ByVal filename As String, ByVal config As Object) As Boolean

        '' check input, bail if rubbish
        If config Is Nothing Then Return False

        '' this is a safe function
        Try
            '' remove existing?
            If System.IO.File.Exists(filename) Then

                '' remove
                System.IO.File.Delete(filename)

            End If

            '' open the serialiser 2
            Dim serializer As XmlSerializer = New XmlSerializer(config.GetType())

            If System.IO.Directory.Exists(Path.GetDirectoryName(filename)) = False Then
                System.IO.Directory.CreateDirectory(Path.GetDirectoryName(filename))
            End If

            '' stream out with writer
            Using writer As IO.TextWriter = New StreamWriter(filename)

                '' do it
                serializer.Serialize(writer, config)

            End Using

            '' Ok?
            If System.IO.File.Exists(filename) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try

        '' bugger
        Return False

    End Function

    ''' <summary>
    ''' Read in an XML file
    ''' </summary>
    ''' <param name="filename"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ReadLog(Of T)(ByVal filename As String) As T

        '' no good if file does not exist
        If Not System.IO.File.Exists(filename) Then Return Nothing

        '' this is a safe function
        Try

            '' construct a reader 1
            Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(T))

            '' try getting the reader stream
            Using file As New System.IO.StreamReader(filename)

                '' do it
                Return CType(reader.Deserialize(file), T)

            End Using


        Catch ex As Exception

        End Try

        '' bugger
        Return Nothing

    End Function

    Public Function ReadXML(FileName As String) As XmlReader
        Dim XmlSettings As New XmlReaderSettings()
        XmlSettings.ConformanceLevel = ConformanceLevel.Fragment
        XmlSettings.IgnoreWhitespace = True
        XmlSettings.IgnoreComments = True
        Return XmlReader.Create(FileName, XmlSettings)
    End Function
    Public Function Value(XMLFile As XmlReader, Name As String) As String
        XMLFile.ReadToFollowing(Name)
        Value = XMLFile.ReadElementContentAsString()
        If String.IsNullOrEmpty(Value) Then
            Return Nothing
        End If
    End Function
End Module
