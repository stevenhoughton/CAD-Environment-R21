﻿''' <summary>
''' Sink for all logging
''' </summary>
''' <remarks></remarks>
Public Class Logger

    ''' <summary>
    ''' Allow users to listen in on messages
    ''' </summary>
    ''' <param name="message"></param>
    ''' <remarks></remarks>
    Public Event MessageEvent(message As String)

    ''' <summary>
    ''' Allow users to listen in on messages
    ''' </summary>
    ''' <param name="warning"></param>
    ''' <remarks></remarks>
    Public Event WarningEvent(warning As String)

    ''' <summary>
    ''' Allow users to listen in on messages
    ''' </summary>s
    ''' <param name="err"></param>
    ''' <remarks></remarks>
    Public Event ErrorEvent(err As String)

    ''' <summary>
    ''' Dispath a message
    ''' </summary>
    ''' <param name="message"></param>
    ''' <remarks></remarks>
    Public Sub Message(message As String)
        RaiseEvent MessageEvent(message)
    End Sub

    ''' <summary>
    ''' Dispath warning message
    ''' </summary>
    ''' <param name="warning"></param>
    ''' <remarks></remarks>
    Public Sub Warning(warning As String)
        RaiseEvent WarningEvent(warning)
    End Sub

    ''' <summary>
    ''' Dispath error message
    ''' </summary>
    ''' <param name="err"></param>
    ''' <remarks></remarks>
    Public Sub Errors(err As String)
        RaiseEvent ErrorEvent(err)
    End Sub

End Class

