﻿Public Module Messaging

    Public Function GeneralMessageBox(ByVal Text As String,
                                      Optional ByVal caption As String = "Jacobs Message",
                                      Optional ByVal buttons As MessageBoxButtons = MessageBoxButtons.OK,
                                      Optional ByVal icon As MessageBoxIcon = MessageBoxIcon.Information,
                                      Optional ByVal MessageBoxDefaultButton As MessageBoxDefaultButton = MessageBoxDefaultButton.Button1,
                                      Optional ByVal options As MessageBoxOptions = 0,
                                      Optional ByVal displayhelpbutton As Boolean = False,
                                      Optional ByVal log As Boolean = True,
                                      Optional ByVal LogOnly As Boolean = False,
                                      Optional LogName As String = "",
                                      Optional ByVal ex As Exception = Nothing,
                                      Optional ByVal MethodName As String = "",
                                      Optional ByVal sModuleName As String = "") As DialogResult

        Dim ans As DialogResult = DialogResult.Ignore

        caption = caption.Replace("Jacobs AutoCAD Environment R21 Generated", "")
        caption = caption.Replace("AutoCAD Environment Generated", "")

        '' Ensure every message we deliver is stamped with our name on the caption
        If Not caption.ToUpper.Contains("Jacobs Message".ToUpper) Then
            caption = "Jacobs Message " & caption
        End If

        If LogOnly = False Then
            ans = MessageBox.Show(Text, caption, buttons, icon, MessageBoxDefaultButton, options, displayhelpbutton)
        End If

        '' Check that a log file name was sent else get the name of this DLL and use it
        If LogName = String.Empty Then
            LogName = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        End If

        '' Add the User name and asset number to the log file name
        LogName = LogName & "-" & System.Environment.UserName & "-" & My.Computer.Name & ".log"

        If ans <> DialogResult.Ignore Then
            WriteToLog(Text & " Response = " & ans.ToString, LogName)
        Else
            WriteToLog(Text, LogName)
        End If

        Return ans

    End Function

    ''' <summary>
    ''' Common exception message which depends on the calling routing to use reflection to work out dll name and function name
    ''' Example call
    '''     ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    ''' </summary>
    ''' <param name="ex"></param>
    ''' <param name="MethodName"></param>
    ''' <param name="sModuleName"></param>
    ''' <param name="bJustLog"></param>
    ''' <remarks></remarks>
    Public Sub GeneralExceptionMessageBox(ByVal ex As Exception, ByVal MethodName As String, ByVal sModuleName As String, Optional ByVal bJustLog As Boolean = False, Optional ByVal AdditionalInformation As String = "", Optional ByVal LogName As String = "")

        If LogName = String.Empty Then
            LogName = MethodName & "-" & sModuleName
        End If

        GeneralMessageBox(ex.Message & vbCrLf & vbCrLf & ex.StackTrace, "Jacobs Message - " & sModuleName & " - " & MethodName, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , bJustLog, LogName)

    End Sub

End Module

