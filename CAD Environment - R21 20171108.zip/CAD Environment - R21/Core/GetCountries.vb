﻿Imports System.Collections.Generic
Imports System.Globalization


Public Module GetCountries

    Dim countryList As New SortedDictionary(Of String, String)

    Public Sub PopulateWithCountries(ByVal CmbBox As ComboBox, Optional ByVal AddGlobal As Boolean = False)

        countryList.Clear()

        ' Iterate the Framework Cultures...
        For Each ci As CultureInfo In CultureInfo.GetCultures(CultureTypes.SpecificCultures)
            Dim ri As RegionInfo
            Try
                ri = New RegionInfo(ci.Name)
            Catch
                'If a RegionInfo object could not be created don't use the CultureInfo for the country list.
                Continue For
            End Try
            ' Create new country dictionary entry.
            Dim newKeyValuePair As New KeyValuePair(Of String, String)(ri.EnglishName, ri.ThreeLetterISORegionName)
            ' If the country is not already in the countryList add it...
            If Not countryList.ContainsKey(ri.EnglishName) Then
                countryList.Add(newKeyValuePair.Key, newKeyValuePair.Value)
                CmbBox.Items.Add(ri.EnglishName)
            End If

        Next

        If AddGlobal = True Then
            CmbBox.Items.Add("Global")
        End If

        CmbBox.Sorted = True

    End Sub

End Module