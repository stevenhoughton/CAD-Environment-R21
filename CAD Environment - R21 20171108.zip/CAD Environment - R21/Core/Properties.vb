﻿Imports System.Collections.Generic

Public Module Properties

    ''' <summary>
    ''' get the property value
    ''' </summary>
    ''' <param name="path"></param>
    ''' <param name="o"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetProperty(path As String, o As Object) As Object

        If o Is Nothing Then
            Return Nothing
        End If

        '' get object type
        Dim type As System.Type = o.GetType()

        '' get property information
        Dim info As System.Reflection.PropertyInfo = type.GetProperty(path)
        If info Is Nothing Then
            Return Nothing
        End If

        '' get value of property
        Return info.GetValue(o, Nothing)

    End Function

    ''' <summary>
    ''' Recursively get the property value
    ''' </summary>
    ''' <param name="paths"></param>
    ''' <param name="o"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetPropertyValue(paths As List(Of String), o As Object) As Object

        '' get property to look for
        Dim prop As Object = GetProperty(paths(0), o)
        If paths.Count = 1 Then
            Return prop
        End If

        '' remove first string
        paths.RemoveAt(0)

        '' drill down
        Return GetPropertyValue(paths, prop)

    End Function

    ''' <summary>
    ''' Get the reflected property value of an object
    ''' </summary>
    ''' <param name="path"></param>
    ''' <param name="o"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetValue(path As String, o As Object) As Object

        '' bail if object is empty
        If o Is Nothing Then
            Return Nothing
        End If

        '' bail if no path
        If String.IsNullOrEmpty(path) Then
            Return Nothing
        End If

        '' get all paths
        Dim paths As List(Of String) = New List(Of String)(path.Split("."c))

        '' pass to worker function
        Return GetPropertyValue(paths, o)

    End Function

    ''' <summary>GetProperty
    ''' Set the named property a value
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="o"></param>
    ''' <param name="value"></param>
    ''' <remarks></remarks>
    Public Sub SetValue(name As String, o As Object, value As Object)

        '' bail if rubbish name
        If String.IsNullOrEmpty(name) Then
            Return
        End If

        '' bail if rubbish object
        If o Is Nothing Then
            Return
        End If

        '' get object type
        Dim type As System.Type = o.GetType()

        '' get property information
        Dim info As System.Reflection.PropertyInfo = type.GetProperty(name)
        If info Is Nothing Then
            Return
        End If

        If info.PropertyType = GetType(Boolean) Then

            Dim result As Boolean
            Boolean.TryParse(value.ToString(), result)
            info.SetValue(o, result, Nothing)

        Else

            '' finally, do it
            info.SetValue(o, value, Nothing)

        End If

    End Sub

    ''' <summary>
    ''' Set all properties to this value
    ''' </summary>
    ''' <param name="o"></param>
    ''' <param name="value"></param>
    ''' <remarks></remarks>
    Public Sub SetProperties(o As Object, value As Object)

        '' bail if rubbish object
        If o Is Nothing Then
            Return
        End If

        '' get object type
        Dim type As System.Type = o.GetType()
        If type Is Nothing Then
            Return
        End If

        '' get all public properties
        Dim info() As System.Reflection.PropertyInfo = type.GetProperties()
        If info Is Nothing Or info.Length <= 0 Then
            Return
        End If

        '' scroll thru and set values to each property
        For Each prop As System.Reflection.PropertyInfo In info
            If prop.CanWrite Then
                prop.SetValue(o, value, Nothing)
            End If
        Next

    End Sub

End Module
