﻿Imports System.Collections.Generic
Imports Jacobs.Common.Core

''' <summary>
''' Keeps a record of downloaded files in the root destination folder
''' </summary>
''' <remarks></remarks>
Public Class ChangeLog

    ''' <summary>
    ''' Al the files in the cache
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Names As New List(Of String)

    ''' <summary>
    ''' All the corresponding dates
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Dates As New List(Of Date)

    ''' <summary>
    ''' A fast look up of dates per file
    ''' </summary>
    ''' <remarks></remarks>
    Private _Cache As Dictionary(Of String, Date) = New Dictionary(Of String, Date)

    ''' <summary>
    ''' Load data
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Initialise()

        '' clear cache of any read dates
        _Cache.Clear()

        '' add items
        For i As Integer = 0 To Names.Count - 1
            _Cache(Names(i)) = Dates(i)
        Next

    End Sub

    ''' <summary>
    ''' Download if the source file (newDate) is newer than the destination file (dstDate)
    ''' </summary>
    ''' <param name="src"></param>
    ''' <param name="dst"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DownloadFile(ByVal src As String, ByVal dst As String, ByRef newDate As Date) As Boolean

        '' get date of src
        'newDate = System.IO.File.GetCreationTime(src)

        ' try?
        newDate = System.IO.File.GetLastWriteTime(src)

        '' download if destination not present
        If Not System.IO.File.Exists(dst) Then
            Return True
        End If

        '' if dst file is not in cache then download
        If Not _Cache.ContainsKey(dst) Then
            Return True
        End If

        '' get date of dst
        Dim dstDate As Date = _Cache(dst)

        '' compare dates? if they are different
        'Return newDate <> dstDate

        '' compare dates? if the DFS file date if larger or older than date on the PC?
        Return newDate > dstDate

        '' compare dates? if the DFS date is less than or newer than the one on the PC
        'Return newDate < dstDate

    End Function

    ''' <summary>
    ''' Save a file and its date
    ''' </summary>
    ''' <param name="dst"></param>
    ''' <param name="dstDate"></param>
    ''' <remarks></remarks>
    Public Sub Add(ByVal dst As String, ByVal dstDate As Date)

        _Cache(dst) = dstDate

    End Sub

    ''' <summary>
    ''' The name of the file in the root destination
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared ReadOnly _Name As String = "DFSChange.log"

    ''' <summary>
    ''' Save
    ''' </summary>
    ''' <param name="folder"></param>
    ''' <remarks></remarks>
    Public Sub Save(ByVal folder As String)

        '' clear names and dates
        Names.Clear()
        Dates.Clear()

        '' add latest data
        For Each row As KeyValuePair(Of String, Date) In _Cache
            Names.Add(row.Key)
            Dates.Add(row.Value)
        Next

        '' filename
        Dim filename As String = folder.CombinePath(_Name)

        '' save
        XML.Save(filename, Me)

    End Sub

    ''' <summary>
    ''' Load/read in a change log file
    ''' </summary>
    ''' <param name="folder"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function Load(ByVal folder As String) As ChangeLog

        '' filename
        Dim filename As String = folder.CombinePath(_Name)

        '' return blank copy if not exists
        If Not System.IO.File.Exists(filename) Then
            Return New ChangeLog()
        End If

        '' read change
        Dim log As ChangeLog = XML.ReadLog(Of ChangeLog)(filename)
        If log Is Nothing Then
            Return New ChangeLog()
        End If

        '' load in data
        log.Initialise()

        '' return newly read change log 
        Return log

    End Function

End Class


