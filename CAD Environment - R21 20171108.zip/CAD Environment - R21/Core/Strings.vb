﻿Imports System.Collections.Generic

Public Module Strings

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="s"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <System.Runtime.CompilerServices.Extension()> _
    Public Function IsTrue(ByVal s As String) As Boolean

        If s Is Nothing Then
            Return False
        End If

        If String.Compare(s, "true", True) = 0 Then
            Return True
        End If
        If String.Compare(s, "t", True) = 0 Then
            Return True
        End If
        If String.Compare(s, "1", True) = 0 Then
            Return True
        End If
        If String.Compare(s, "-1", True) = 0 Then
            Return True
        End If
        If String.Compare(s, "Checked", True) = 0 Then
            Return True
        End If

        Return False

    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Public Function GetCheckState(ByVal s As String) As CheckState

        If s Is Nothing Then
            Return CheckState.Indeterminate
        End If

        If s.IsTrue Then

            Return CheckState.Checked

        End If

        Return CheckState.Unchecked

    End Function
    ''' <summary>
    ''' Combines paths...as an extension to the string method
    ''' </summary>
    ''' <param name="s"></param>
    ''' <param name="paths"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <System.Runtime.CompilerServices.Extension()> _
    Public Function CombinePath(ByVal s As String, ByVal ParamArray paths() As String) As String

        '' new list of paths
        Dim newPaths As New List(Of String)

        '' header?
        If String.IsNullOrEmpty(s) Then
            Return String.Empty
        End If

        '' save header
        newPaths.Add(s)

        For Each path As String In paths

            If String.IsNullOrEmpty(path) Then
                Return String.Empty
            End If

            ' Remove the starting \
            If path.StartsWith("\") Then
                path = path.Remove(0, 1)
            End If

            ' Remove the trailing \
            If path.EndsWith("\") Then
                path = path.Remove(path.Length - 1, 1)
            End If

            newPaths.Add(path)

        Next

        Return System.IO.Path.Combine(newPaths.ToArray())

    End Function

    ''' <summary>
    ''' Removes the last section of an array which can be sectioned by a character
    ''' Example: "C:\TEMP\O".RemoveLastSection("\"c) would return "C:\TEMP"
    '''          As that particular string can be sectioned by the "\"c
    ''' </summary>
    ''' <param name="s"></param>
    ''' <param name="character"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <System.Runtime.CompilerServices.Extension()> _
    Public Function RemoveLastSection(ByVal s As String, ByVal character As Char) As String

        '' Check for empty string parameter
        If String.IsNullOrEmpty(s) Then
            Return String.Empty
        End If

        '' Check for empty character parameter
        If String.IsNullOrEmpty(character) Then
            Return String.Empty
        End If

        '' Split the string
        Dim NewStringArray() As String = Split(s, character)
        Dim NewString As String = String.Empty

        For i As Integer = 0 To (NewStringArray.Length - 1)
            If i = NewStringArray.Length - 2 Then
                Exit For
            Else
                NewString = NewString & NewStringArray(i) & character
            End If
        Next

        NewString = NewString.Trim("\")

        Return NewString


    End Function


End Module
