﻿Imports System.Collections.Generic

Public Module Files

    '' No access to Settings.Settings.Manager.JCE.LogFileExtension - Extension had to be derived on the fly
    '' Should get Core-GDoderaAdm-AU-N03631.log
    Property logName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    ''' <summary>
    ''' Safely delete this file
    ''' </summary>
    ''' <param name="filename"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Delete(filename As String) As Boolean

        '' wrap a safe try-catch
        Try

            '' bail if rubbish input
            If String.IsNullOrEmpty(filename) Then
                Return False
            End If

            '' bail if not present
            If Not System.IO.File.Exists(filename) Then
                Return False
            End If

            '' Ok, try it
            System.IO.File.Delete(filename)

            '' Ok we have success
            Return True

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, "When Attempting to delete: " & filename)
        End Try

        '' failed if we get here
        Return False

    End Function

    ''' <summary>
    ''' Safely get a list of all files in all sub-folders
    ''' </summary>
    ''' <param name="folder"></param>
    ''' <param name="Filter"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetFiles(folder As String, Filter As String) As List(Of String)

        '' results go here
        Dim results As New List(Of String)

        '' check inpuut
        If String.IsNullOrEmpty(folder) Then
            Return results
        End If

        '' bail if folder does not exist
        If Not System.IO.Directory.Exists(folder) Then
            Return results
        End If

        '' check Filter
        If String.IsNullOrEmpty(Filter) Then
            Filter = "*"
        End If

        '' wrap a safe try-catch
        Try

            '' do it
            Dim files() As String = System.IO.Directory.GetFiles(folder, Filter, IO.SearchOption.AllDirectories)
            If files Is Nothing Or files.Length = 0 Then
                Return results
            End If

            '' add to results
            results.AddRange(files)

            '' Ok
            Return results

        Catch ex As Exception

        End Try

        '' failed if we get here
        Return results

    End Function

    ''' <summary>
    ''' Destination to contain the same folder and files as the source
    ''' </summary>
    ''' <param name="srcFolder"></param>
    ''' <param name="srcFilter"></param>
    ''' <param name="includeDirs"></param>
    ''' <param name="dstFolder"></param>
    ''' <remarks></remarks>
    Public Sub MatchDelete(srcFolder As String, srcFilter As String, includeDirs As Boolean, dstFolder As String)

        WriteToLog(vbCr & "Deleting any files not on DFS" & vbCr, logName)

        '' check source folder exists
        If Not System.IO.Directory.Exists(srcFolder) Then
            Return
        End If

        '' bail if destination does not exist
        If Not System.IO.Directory.Exists(dstFolder) Then
            Return
        End If

        '' get all the files on the source folder
        Dim srcFiles As List(Of String) = GetFiles(srcFolder, srcFilter)
        If srcFiles Is Nothing Or srcFiles.Count = 0 Then
            Return
        End If

        '' get all the files on the destination folder
        Dim dstFiles As List(Of String) = GetFiles(dstFolder, srcFilter)
        If dstFiles Is Nothing Or dstFiles.Count = 0 Then
            Return
        End If

        '' build destination image
        Dim dstImage As List(Of String) = New List(Of String)
        For Each file As String In srcFiles
            dstImage.Add(file.Replace(srcFolder, dstFolder))
        Next

        '' what's in destination and not in image then delete it
        For Each file As String In dstFiles

            '' ok if in destination image
            If dstImage.Contains(file) Then
                Continue For
            End If

            WriteToLog("      Deleting: " & file, logName)

            '' safely delete it
            Delete(file)

        Next

        '' match folders?
        If Not includeDirs Then
            Return
        End If

        '' match destination folder structure
        Folders.Match(srcFolder, dstFolder)

    End Sub

    ''' <summary>
    ''' Generic file read function send it the text file name to read and it will return a string array
    ''' </summary>
    ''' <param name="SourceFile"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ReadTextFile(ByRef SourceFile As String) As String()

        Try
            Dim f_in As System.IO.StreamReader
            Dim aFileRead() As String = Nothing

            If System.IO.File.Exists(SourceFile) Then
                If My.Computer.FileSystem.GetFileInfo(SourceFile).Length <> 0 Then
                    f_in = My.Computer.FileSystem.OpenTextFileReader(SourceFile)
                    aFileRead = Split(f_in.ReadToEnd, vbCrLf)
                    f_in.Close()
                    f_in.Dispose()
                End If
            End If

            Return aFileRead

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return Nothing

    End Function

    Public Function WriteLineToTextFile(ByRef SourceFile As String, ByVal Line As String, Optional ByVal AppendMode As Boolean = False) As Boolean

        Try

            If AppendMode = False Then
                If System.IO.File.Exists(SourceFile) Then
                    System.IO.File.Delete(SourceFile)
                End If
            End If

            If Not System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(SourceFile)) Then
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(SourceFile))
            End If

            Dim OutPut As System.IO.StreamWriter
            OutPut = My.Computer.FileSystem.OpenTextFileWriter(SourceFile, AppendMode)
            OutPut.WriteLine(Line)
            OutPut.Close()
            OutPut.Dispose()

            Return True

        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return False

        End Try

    End Function

    Public Function ReplaceLineInTextFile(ByRef SourceFile As String, ByVal LineToReplace As String, ByVal LineToUse As String) As Boolean

        Try
            If System.IO.File.Exists(SourceFile) Then

                Dim InPut As System.IO.StreamReader
                Dim aFileRead() As String = Nothing

                If My.Computer.FileSystem.GetFileInfo(SourceFile).Length <> 0 Then
                    InPut = My.Computer.FileSystem.OpenTextFileReader(SourceFile)
                    aFileRead = Split(InPut.ReadToEnd, vbCrLf)
                    InPut.Close()
                    InPut.Dispose()
                End If

                Dim OutPut As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(SourceFile, False)

                For Each Line As String In aFileRead
                    If Line.ToUpper Like "*" & LineToReplace.ToUpper & "*" Then
                        Line = LineToUse
                    End If
                    OutPut.WriteLine(Line)
                Next

                OutPut.Close()
                OutPut.Dispose()

                Return True
            Else
                Return False
            End If

        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return False

        End Try

    End Function
    ''' <summary>
    ''' Simply tries to copy a file to the root of C:\ to see if we have machine admin rights
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function DoWeHaveAdminRights() As Boolean

        Dim result As Boolean = False
        Try
            System.IO.File.Copy(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Windows).CombinePath("Notepad.exe"), "C:\Test.TXT", True)
            System.IO.File.Delete("C:\Test.TXT")
            result = True
        Catch ex As Exception
            result = False
        End Try

        Return result

    End Function

End Module
