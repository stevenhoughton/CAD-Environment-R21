﻿Imports System.Collections.Generic

Public Module Folders

    ''' <summary>
    ''' Safely delete this folder
    ''' </summary>
    ''' <param name="folder"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Delete(folder As String, Optional Recursively As Boolean = False) As Boolean

        '' wrap a safe try-catch
        Try

            '' bail if rubbish input
            If String.IsNullOrEmpty(folder) Then
                Return False
            End If

            '' bail if not present
            If Not System.IO.Directory.Exists(folder) Then
                Return False
            End If

            '' get list if files
            Dim contents As List(Of String) = Files.GetFiles(folder, "*")
            If Not (contents Is Nothing) And contents.Count > 0 Then
                Return False
            End If

            '' Ok, try it
            System.IO.Directory.Delete(folder, Recursively)

            '' Ok, we have success
            Return True

        Catch ex As Exception

        End Try

        '' failed if we get here
        Return False

    End Function

    ''' <summary>
    ''' Recursively get a list of sub folders
    ''' </summary>
    ''' <param name="folders"></param>
    ''' <param name="srcFolder"></param>
    ''' <remarks></remarks>
    Public Sub GetFolders(folders As List(Of String), srcFolder As String)

        Try
            '' bail if folder does not exist
            If Not System.IO.Directory.Exists(srcFolder) Then
                Return
            End If

            '' get sub-directories
            Dim subdirs() As String = System.IO.Directory.GetDirectories(srcFolder)
            If subdirs Is Nothing Or subdirs.Length = 0 Then
                Return
            End If

            '' add to result
            folders.AddRange(subdirs)

            '' for folder drill down
            For Each Dir As String In subdirs

                '' get sub folders
                GetFolders(folders, Dir)

            Next

        Catch ex As Exception

        End Try

    End Sub

    ''' <summary>
    ''' Recursively get a list of sub folders
    ''' </summary>
    ''' <param name="srcFolder"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetFolders(srcFolder As String) As List(Of String)

        '' result goes here
        Dim folders As New List(Of String)

        '' do it recursively
        GetFolders(folders, srcFolder)

        '' reverse to ensure sub-folder are read first
        folders.Reverse()

        '' return newly create list of folders and sub-folders
        Return folders

    End Function

    ''' <summary>
    ''' Destination folders to match source folder structure
    ''' </summary>
    ''' <param name="srcFolder"></param>
    ''' <param name="dstFolder"></param>
    ''' <remarks></remarks>
    Public Sub Match(srcFolder As String, dstFolder As String)

        '' check source folder exists
        If Not System.IO.Directory.Exists(srcFolder) Then
            Return
        End If

        '' bail if destination does not exist
        If Not System.IO.Directory.Exists(dstFolder) Then
            Return
        End If

        '' get all the sub-folders on the source folder
        Dim srcFolders As List(Of String) = GetFolders(srcFolder)
        If srcFolders Is Nothing Then
            Return
        End If

        '' get all the sub-folders on the destination folder
        Dim dstFolders As List(Of String) = GetFolders(dstFolder)
        If dstFolders Is Nothing Or dstFolders.Count = 0 Then
            Return
        End If

        '' build destination image, ie destination folder structure
        Dim dstImage As List(Of String) = New List(Of String)
        For Each file As String In srcFolders
            dstImage.Add(file.Replace(srcFolder, dstFolder))
        Next

        '' what's in destination and not in image then delete it
        For Each folder As String In dstFolders

            '' ok if in destination image
            If dstImage.Contains(folder) Then
                Continue For
            End If

            '' delete it
            Delete(folder)

        Next

    End Sub

    ''' <summary>
    ''' Recursively populates the passed collection with all files in a nominated directory.
    ''' </summary>
    ''' <param name="sDirectory"></param>
    ''' <param name="cDirectoryEntries"></param>
    ''' <remarks></remarks>
    Public Sub GetDirectoryFiles(ByVal sDirectory As String, ByRef cDirectoryEntries As Collection, Optional ByVal recursive As Boolean = True)
        Try
            If (System.IO.Directory.Exists(sDirectory)) Then
                Dim sFileEntries As String() = System.IO.Directory.GetFiles(sDirectory)

                If sFileEntries IsNot Nothing Then
                    ' Process the list of files found in the directory
                    For Each sFileName As String In sFileEntries
                        ' If sFileName.ToUpper.Contains(".ZIP") Then
                        cDirectoryEntries.Add(sFileName)
                        'End If
                    Next

                    If recursive = True Then

                        Dim sSubdirectoryEntries As String() = System.IO.Directory.GetDirectories(sDirectory)

                        ' Recurse into subdirectories of this directory
                        For Each sSubdirectory As String In sSubdirectoryEntries
                            GetDirectoryFiles(sSubdirectory, cDirectoryEntries)
                        Next

                    End If

                End If
            End If
        Catch ex As System.Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates the collection that it was sent with all the directories under it
    ''' If a TemplatesToHide text file is sent then any Template in the TemplatesToHide.CSV file will be omitted from the array
    ''' </summary>
    ''' <param name="sDirectory"></param>
    ''' <param name="cDirectoryEntries"></param>
    ''' <remarks></remarks>
    Public Sub CEGetDirectories(ByVal sDirectory As String, ByRef cDirectoryEntries As Collection, Optional ByVal sFileName As String = "", Optional ByVal IsSystemAdmin As Boolean = False, Optional ByVal JustJacobs As Boolean = False)
        Try

            Dim ShowMessage As String = String.Empty
            Dim TemplatesToHide As String() = ReadTextFile(sFileName)

            If sFileName = String.Empty Then
                ShowMessage = "TemplatesToHide file was not specified - all Templates will be shown"
            Else
                If Not System.IO.File.Exists(sFileName) Then
                    ShowMessage = sFileName & " was specified but not found - all Templates will be shown"
                End If
            End If

            If (System.IO.Directory.Exists(sDirectory)) Then
                Dim sDirEntries As String() = System.IO.Directory.GetDirectories(sDirectory)
                If Not (sDirEntries Is Nothing) Then
                    ' Process the list of directories found in the directory
                    For Each sDirName As String In sDirEntries
                        Dim TemplateInConfigsFolders As String() = sDirName.Split("\"c)
                        Dim TemplateInConfigsFolder As String = TemplateInConfigsFolders(TemplateInConfigsFolders.Length - 1)

                        If Not cDirectoryEntries.Contains(TemplateInConfigsFolder) Then
                            ' Get all configs that are not in the hidden list
                            cDirectoryEntries.Add(TemplateInConfigsFolder, TemplateInConfigsFolder)
                        End If

                    Next
                End If
            End If

            If ShowMessage = String.Empty And IsSystemAdmin = False Then
                For Each TemplateToHide As String In TemplatesToHide
                    If cDirectoryEntries.Contains(TemplateToHide) Then
                        cDirectoryEntries.Remove(TemplateToHide)
                    End If
                Next
            Else
                If ShowMessage <> String.Empty Then
                    GeneralMessageBox(ShowMessage)
                End If
            End If

            If JustJacobs = True Then
                For Each Template As String In cDirectoryEntries
                    If Not Template.ToUpper Like ("*-*-*Jacobs*-*") Then
                        cDirectoryEntries.Remove(Template)
                    End If
                Next
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", "")
        End Try

    End Sub


    ''' <summary>
    ''' Copies one directory to another
    ''' </summary>
    ''' <param name="sourcePath"></param>
    ''' <param name="destPath"></param>
    ''' <remarks></remarks>
    Public Sub CopyDirectory(ByVal sourcePath As String, ByVal destPath As String)

        Try
            If Not System.IO.Directory.Exists(destPath) Then
                System.IO.Directory.CreateDirectory(destPath)
            End If

            For Each file As String In System.IO.Directory.GetFiles(sourcePath)
                Dim dest As String = destPath.CombinePath(System.IO.Path.GetFileName(file))

                System.IO.File.Copy(file, dest, FileIO.UIOption.AllDialogs)

            Next

            For Each Folder As String In System.IO.Directory.GetDirectories(sourcePath)
                Dim dest As String = destPath.CombinePath(System.IO.Path.GetFileName(Folder))
                CopyDirectory(Folder, dest)
            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", "")
        End Try

    End Sub

    '' Used the Ooki Dialogs DLL to access the Browse for folders dialog introduced in Windows Vista
    '' Just call the
    Public Function BrowseForFolder() As String

        Dim x As New Ookii.Dialogs.VistaFolderBrowserDialog
        Dim Result As String = String.Empty

        x.RootFolder = System.Environment.SpecialFolder.LocalApplicationData

        x.ShowNewFolderButton = True

        If x.ShowDialog() = DialogResult.OK Then
            Result = x.SelectedPath
        End If

        Return Result

    End Function

End Module
