﻿Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Drawing

Public Module UserInterface

    ''' <summary>
    ''' Return the string a the specified index for the combo box replaces VB6.GetItemString
    ''' </summary>
    ''' <param name="combo"></param>
    ''' <param name="index"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetComboBoxText(ByVal combo As System.Windows.Forms.ComboBox, ByVal index As Integer) As String

        '' bail if null combo
        If (combo Is Nothing) Then
            Return vbNullString
        End If

        '' bail if not in range
        If (index < 0 Or index >= combo.Items.Count) Then
            Return vbNullString
        End If

        '' get object @ index
        Dim o As Object = combo.Items(index)
        If (o Is Nothing) Then
            Return vbNullString
        End If

        '' safe cast
        Return TryCast(o, String)

    End Function

    ''' <summary>
    ''' Return the string a the specified index for the list box
    ''' </summary>
    ''' <param name="combo"></param>
    ''' <param name="index"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetListBoxText(ByVal combo As System.Windows.Forms.ListBox, ByVal index As Integer) As String

        '' bail if null combo
        If (combo Is Nothing) Then
            Return vbNullString
        End If

        '' bail if not in range
        If (index < 0 Or index >= combo.Items.Count) Then
            Return vbNullString
        End If

        '' get object @ index
        Dim o As Object = combo.Items(index)
        If (o Is Nothing) Then
            Return vbNullString
        End If

        '' safe cast
        Return TryCast(o, String)

    End Function

    ''' <summary>
    ''' Common call from all tools to get to their designated help files - depends on calling function using replection to get dll name and module
    ''' CHM file name needs to be same as DLL name
    ''' Example call
    '''      CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    ''' </summary>
    ''' <param name="WindowOwner"></param>
    ''' <param name="AssemblyName"></param>
    ''' <param name="ModuleName"></param>
    ''' <param name="HelpNav"></param>
    ''' <remarks></remarks>
    Public Sub CommonHelpButtonClick(ByVal WindowOwner As System.Windows.Forms.Control, ByVal AssemblyName As String, ByVal ModuleName As String, Optional ByVal HelpNav As HelpNavigator = HelpNavigator.TableOfContents)

        Dim sHelpFilePath As String = GetExecutingAssemblyPath()

        If AssemblyName.Contains(".dll") Then
            sHelpFilePath = sHelpFilePath.CombinePath("Help", AssemblyName.Replace(".dll", ".chm"))
        End If

        If AssemblyName.Contains(".exe") Then
            sHelpFilePath = sHelpFilePath.CombinePath("Help", AssemblyName.Replace(".exe", ".chm"))
        End If

        If System.IO.File.Exists(sHelpFilePath) Then
            Help.ShowHelp(WindowOwner, sHelpFilePath, HelpNav)
        Else
            GeneralMessageBox(String.Format(My.Resources.MissingHelpFile, sHelpFilePath) _
                            , My.Resources.AEMessage & System.Reflection.MethodBase.GetCurrentMethod.Name(), _
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    ''' <summary>
    ''' Imput string is simply the module name by reflection System.Reflection.MethodBase.GetCurrentMethod.Module.Name
    ''' Removes Jacobs_ from the front of the string
    ''' Looks for upper case characters that are not multiple and returns a string with spaces 
    ''' Example.
    ''' "C:\Temp\Jacobs_GetPointID.dll"  --  Would return --  "Get Point ID"
    ''' </summary>
    ''' <param name="sInput"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DeriveTitleFromModuleName(sInput As String) As String

        'sInput = Path.GetFileNameWithoutExtension(sInput).Replace("Jacobs_", "")
        sInput = Path.GetFileNameWithoutExtension(sInput).Replace("Jacobs.AutoCAD.", "")
        'sInput = Path.GetFileNameWithoutExtension(sInput).Replace("Jacobs.AutoCAD.", "")

        Dim Result As String = String.Empty
        Dim mc As MatchCollection = Regex.Matches(sInput, "(\P{Lu}+)|(\p{Lu}+\P{Lu}*)")
        Dim parts As String() = New String(mc.Count - 1) {}

        For i As Integer = 0 To mc.Count - 1
            parts(i) = mc(i).ToString()
            If Result = String.Empty Then
                Result = Result & mc(i).ToString()
            Else
                Result = Result & " " & mc(i).ToString()
            End If
        Next

        Return Result

    End Function

    Public Sub RepositionTitle(ByRef Label As System.Windows.Forms.Label, Window As System.Windows.Forms.Form)

        Label.TextAlign = ContentAlignment.MiddleCenter
        'Dim HorizontalMiddle As Integer = Window.Size.Width / 2.0 - (Label.Size.Width / 2.0)
        Dim HorizontalMiddle As Integer = 143
        Dim VerticalSpot As Integer = 12
        Label.Location = New System.Drawing.Point(HorizontalMiddle, VerticalSpot)

    End Sub

End Module
