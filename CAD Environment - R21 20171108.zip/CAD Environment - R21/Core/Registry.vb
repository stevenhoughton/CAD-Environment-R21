﻿Imports Microsoft.Win32
Imports Jacobs

Public Module Registry

    ''' <summary>
    ''' Read registry giving area etx etc
    ''' </summary>
    ''' <param name="sRegArea"></param>
    ''' <param name="sRegistryHive"></param>
    ''' <param name="sRegistryKey"></param>
    ''' <param name="bIgnoreIfNotPresent"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function RegistryRead(ByVal sRegArea As String, ByVal sRegistryHive As String, ByVal sRegistryKey As String, Optional ByVal bIgnoreIfNotPresent As Boolean = False) As String

        Dim sReadValue As String = "False"

        Try

            If sRegistryHive.StartsWith("\") = True Then sRegistryHive = sRegistryHive.TrimStart("\"c)
            If sRegistryHive.EndsWith("\") = True Then sRegistryHive = sRegistryHive.TrimEnd("\"c)
            If sRegArea.StartsWith("\") = True Then sRegArea = sRegArea.TrimStart("\"c)
            If sRegArea.EndsWith("\") = True Then sRegArea = sRegArea.TrimEnd("\"c)
            If sRegistryKey.StartsWith("\") = True Then sRegistryKey = sRegistryKey.TrimStart("\"c)

            Dim instance As RegistryKey = OpenInstanceOfRegistry(sRegArea, sRegistryHive, False, True)

            If instance IsNot Nothing Then
                sReadValue = CStr(instance.GetValue(sRegistryKey))
                If sReadValue Is Nothing Then
                    sReadValue = ""
                End If

            Else
                sReadValue = ""
            End If

        Catch ex As NullReferenceException
            sReadValue = ""

        Catch ex As Exception

            ' Sometimes we use this to check if registry keys are present by setting the bIgnoreIfNotPresent flag to true
            If bIgnoreIfNotPresent = True Then
                sReadValue = ""
            Else
                '   The following conditions may cause an exception: 
                '       The name of the key is Nothing (ArgumentNullException).
                '       The user does not have permissions to read from registry keys (SecurityException).
                '       The key name exceeds the 255-character limit (ArgumentException).
                GeneralMessageBox(ex.Message & vbCrLf & "In RegistryRead function" & vbCrLf & sRegArea & sRegistryHive & sRegistryKey, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
            End If

        End Try

        Return sReadValue

    End Function

    ''' <summary>
    ''' Generic registry write function - can be used in all areas of registry with various values.
    ''' </summary>
    ''' <param name="sRegArea"></param>
    ''' <param name="sRegistryHive"></param>
    ''' <param name="sRegistryKey"></param>
    ''' <param name="sRegValue"></param>
    ''' <param name="sRegType"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function RegistryWrite(ByVal sRegArea As String, ByVal sRegistryHive As String, ByVal sRegistryKey As String, ByVal sRegValue As String, ByVal sRegType As String, Optional ByVal SupressMessage As Boolean = False) As Boolean

        Dim RegType As Microsoft.Win32.RegistryValueKind
        Dim Sucess As Boolean = False

        Try
            ' Sort out any leading or trailing \ (slashes)
            If sRegistryHive.StartsWith("\") = True Then sRegistryHive = sRegistryHive.TrimStart("\"c)
            If sRegistryHive.EndsWith("\") = True Then sRegistryHive = sRegistryHive.TrimEnd("\"c)
            If sRegArea.StartsWith("\") = True Then sRegArea = sRegArea.TrimStart("\"c)
            If sRegArea.EndsWith("\") = True Then sRegArea = sRegArea.TrimEnd("\"c)
            If sRegValue.StartsWith("\") = True Then sRegValue = sRegValue.TrimStart("\"c)

            RegType = ConvertRegTypeString(sRegType)

            Dim instance As RegistryKey = Nothing
            If Registry.RegistryValueExists(sRegArea, sRegistryHive, sRegistryKey) = True Then
                instance = OpenInstanceOfRegistry(sRegArea, sRegistryHive, True, SupressMessage)
            Else
                instance = CreateInstanceOfRegistry(sRegArea, sRegistryHive, SupressMessage)
            End If

            If instance IsNot Nothing Then
                instance.SetValue(sRegistryKey, sRegValue, RegType)
                Sucess = True
            Else
                Sucess = False
            End If

        Catch ex As System.Exception
            '   The following conditions may cause an exception: 
            '       The name of the key is Nothing (ArgumentNullException).
            '       The user does not have permissions to create registry keys (SecurityException).
            '       The key name exceeds the 255-character limit (ArgumentException).
            '       The key is closed (IOException).
            '       The registry key is read-only (UnauthorizedAccessException).
            Sucess = False

            GeneralMessageBox(ex.Message & vbCrLf & "In RegistryWrite function" & vbCrLf & sRegArea & sRegistryHive & sRegistryKey, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , SupressMessage)

        End Try

        Return Sucess

    End Function

    Function RegistryDelete(ByVal sRegArea As String, ByVal sRegistryHive As String, Optional ByVal sRegistryKey As String = "", Optional ByVal IgnoreErrors As Boolean = False) As Boolean

        Dim Sucess As Boolean = False

        Try

            If sRegistryHive.StartsWith("\") = True Then sRegistryHive = sRegistryHive.TrimStart("\"c)
            If sRegistryHive.EndsWith("\") = True Then sRegistryHive = sRegistryHive.TrimEnd("\"c)
            If sRegArea.StartsWith("\") = True Then sRegArea = sRegArea.TrimStart("\"c)
            If sRegArea.EndsWith("\") = True Then sRegArea = sRegArea.TrimEnd("\"c)

            Dim instance As RegistryKey = OpenInstanceOfRegistry(sRegArea, sRegistryHive, True, True)

            If instance IsNot Nothing Then
                ' Check for an empty key - user may want to delete whole hive - hence no key provided
                If String.IsNullOrEmpty(sRegistryKey) Then

                    ' See if the hive exists
                    Dim sRegistryHiveasArray As String() = Split(sRegistryHive, "\")
                    Dim ctr As Integer = 0
                    Dim sRegistryHiveOneLevelBack As String = String.Empty

                    While ctr < sRegistryHiveasArray.Length - 1
                        sRegistryHiveOneLevelBack = sRegistryHiveOneLevelBack & sRegistryHiveasArray(ctr) & "\"
                        ctr = ctr + 1
                    End While

                    sRegistryHiveOneLevelBack = sRegistryHiveOneLevelBack.Remove(sRegistryHiveOneLevelBack.Length - 1, 1)

                    Dim OneLevelBackInstance As RegistryKey = OpenInstanceOfRegistry(sRegArea, sRegistryHiveOneLevelBack, True, True)

                    If OneLevelBackInstance IsNot Nothing Then
                        OneLevelBackInstance.DeleteSubKeyTree(sRegistryHiveasArray(sRegistryHiveasArray.Length - 1))
                    End If

                Else
                    If RegistryValueExists(sRegArea, sRegistryHive, sRegistryKey) = True Then
                        instance.DeleteValue(sRegistryKey)
                    End If
                End If
            End If

            ' If key does not exist then we still return true as they key is gone regardless
            Sucess = True

        Catch ex As System.Exception
            '   The following conditions may cause an exception: 
            '       The name of the key is Nothing (ArgumentNullException).
            '       The user does not have permissions to delete registry keys (SecurityException).
            '       The key name exceeds the 255-character limit (ArgumentException).
            '       The registry key is read-only (UnauthorizedAccessException).
            Sucess = False
            If IgnoreErrors = False Then

                GeneralMessageBox(ex.Message & vbCrLf & "In RegistryDelete function", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)

            Else

                '' Log Error
                Dim FileName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
                WriteToLog(ex.Message & vbCrLf & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, FileName)

            End If


        End Try

        Return Sucess

    End Function

    Function RegistryValueExists(ByVal sRegArea As String, ByVal sRegistryHive As String, ByVal sRegistryValue As String) As Boolean

        Dim Sucess As Boolean = False

        Try

            If sRegArea.StartsWith("\") = True Then sRegArea = sRegArea.TrimStart("\"c)
            If sRegArea.EndsWith("\") = True Then sRegArea = sRegArea.TrimEnd("\"c)
            If sRegistryHive.StartsWith("\") = True Then sRegistryHive = sRegistryHive.TrimStart("\"c)
            If sRegistryHive.EndsWith("\") = True Then sRegistryHive = sRegistryHive.TrimEnd("\"c)

            sRegArea = ConvertShortRegistryNames(sRegArea)

            If My.Computer.Registry.GetValue(sRegArea & "\" & sRegistryHive, sRegistryValue, Nothing) Is Nothing Then
                Sucess = False
            Else
                Sucess = True
            End If

        Catch ex As System.Exception
            GeneralMessageBox(ex.Message, "Jacobs Message - RegistryValueExists", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
            Sucess = False
        End Try

        Return Sucess

    End Function

    Private Function ConvertShortRegistryNames(ByVal sRegArea As String) As String

        Try

            sRegArea = sRegArea.ToUpper.Replace("HKCU", "HKEY_CURRENT_USER")      'HKCU - Abbreviated from the registry key name HKEY_CURRENT_USER. HKCU stores Settings that are specific to the currently logged-in user. The HKCU key is a link to the subkey of HKEY_USERS that corresponds to the user; the same information is reflected in both locations. 
            sRegArea = sRegArea.ToUpper.Replace("HKLM", "HKEY_LOCAL_MACHINE")     'HKLM - Abbreviated from the registry key name HKEY_LOCAL_MACHINE. HKLM stores Settings that are general to all users on the computer. On my XP system, HKLM contains five subkeys, HARDWARE, SAM, SECURITY, SOFTWARE and SYSTEM. 
            sRegArea = sRegArea.ToUpper.Replace("HKCR", "HKEY_CLASSES_ROOT")      'HKCR - Abbreviated from the registry key name HKEY_CLASSES_ROOT. HKCR stores information about registered applications, such as Associations from File Extensions and OLE Object Class IDs tying them to the applications used to handle these items. 
            sRegArea = sRegArea.ToUpper.Replace("HKU", "HKEY_USERS")              'HKU - Abbreviated from the registry key name HKEY_USERS. HKU contains subkeys corresponding to the HKEY_CURRENT_USER keys for each user registered on the machine. 
            sRegArea = sRegArea.ToUpper.Replace("HKCC", "HKEY_CURRENT_CONFIG")    'HKCC - Abbreviated from the registry key name HKEY_CURRENT_CONFIG. HKCC contains information gathered at runtime; information stored in this key is not permanently stored on the hard disk, but rather regenerated at boot time. 
            sRegArea = sRegArea.ToUpper.Replace("HKPD", "HKEY_PERFORMANCE_DATA")  'HKPD - Abbreviated from the registry key name HKEY_PERFORMANCE_DATA. HKPD provides runtime information into performance data provided by either the operating system kernel itself or other programs that provide performance data. This key is not displayed in the Registry Editor, but it is visible through the registry functions in the Windows API. 

        Catch ex As Exception
            GeneralMessageBox(ex.Message, "Jacobs Message - ConvertShortRegistryNames", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
        End Try

        Return sRegArea

    End Function

    Private Function CreateInstanceOfRegistry(ByVal sRegArea As String, ByVal sRegistryHive As String, Optional ByVal SupressMessage As Boolean = False) As RegistryKey

        Dim Instance As RegistryKey = Nothing

        Try

            sRegArea = ConvertShortRegistryNames(sRegArea)

            ' Create an instance of the desired registry hive
            Select Case sRegArea.ToUpper
                Case "HKEY_CURRENT_USER"
                    Instance = My.Computer.Registry.CurrentUser.CreateSubKey(sRegistryHive)
                Case "HKEY_LOCAL_MACHINE"
                    Instance = My.Computer.Registry.LocalMachine.CreateSubKey(sRegistryHive)
                Case "HKEY_CLASSES_ROOT"
                    Instance = My.Computer.Registry.ClassesRoot.CreateSubKey(sRegistryHive)
                Case "HKEY_USERS"
                    Instance = My.Computer.Registry.Users.CreateSubKey(sRegistryHive)
                Case "HKEY_CURRENT_CONFIG"
                    Instance = My.Computer.Registry.CurrentConfig.CreateSubKey(sRegistryHive)
                Case "HKEY_PERFOMANCE_DATA"
                    Instance = My.Computer.Registry.PerformanceData.CreateSubKey(sRegistryHive)
            End Select


        Catch ex As Exception
            GeneralMessageBox(ex.Message, "Jacobs Message - CreateInstanceOfRegistry: " & sRegistryHive, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , SupressMessage)
        End Try

        Return Instance


    End Function

    Public Function GetRegistrySubKeys(ByVal sRegArea As String, ByVal sRegistryHive As String) As String()

        Dim instance As RegistryKey = OpenInstanceOfRegistry(sRegArea, sRegistryHive, False, True)

        If IsNothing(instance) Then
            Return Nothing
        Else
            Return instance.GetSubKeyNames
        End If

    End Function

    Public Function OpenInstanceOfRegistry(ByVal sRegArea As String, ByVal sRegistryHive As String, ByVal Writable As Boolean, Optional ByVal SuppressMessage As Boolean = False) As RegistryKey

        Dim Instance As RegistryKey = Nothing

        Try

            sRegArea = ConvertShortRegistryNames(sRegArea)

            ' Create an instance of the desired registry hive
            Select Case sRegArea.ToUpper
                Case "HKEY_CURRENT_USER"
                    Instance = My.Computer.Registry.CurrentUser.OpenSubKey(sRegistryHive, Writable)
                Case "HKEY_LOCAL_MACHINE"
                    Instance = My.Computer.Registry.LocalMachine.OpenSubKey(sRegistryHive, Writable)
                Case "HKEY_CLASSES_ROOT"
                    Instance = My.Computer.Registry.ClassesRoot.OpenSubKey(sRegistryHive, Writable)
                Case "HKEY_USERS"
                    Instance = My.Computer.Registry.Users.OpenSubKey(sRegistryHive, Writable)
                Case "HKEY_CURRENT_CONFIG"
                    Instance = My.Computer.Registry.CurrentConfig.OpenSubKey(sRegistryHive, Writable)
                Case "HKEY_PERFOMANCE_DATA"
                    Instance = My.Computer.Registry.PerformanceData.OpenSubKey(sRegistryHive, Writable)
            End Select

        Catch ex As Exception

            GeneralMessageBox(ex.Message, "Jacobs Message - CreateInstanceOfRegistry: " & sRegistryHive, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , SuppressMessage)

        End Try

        Return Instance


    End Function

    Private Function ConvertRegTypeString(ByVal sRegType As String) As RegistryValueKind

        Dim RegType As RegistryValueKind = RegistryValueKind.None

        Try

            ' convert short registry string names to correct types
            Select Case sRegType.ToUpper
                Case "REG_DWORD"
                    RegType = RegistryValueKind.DWord
                Case "REG_SZ"
                    RegType = RegistryValueKind.String
                Case "REG_BINARY"
                    RegType = RegistryValueKind.Binary
                Case "REG_EXPAND_SZ"
                    RegType = RegistryValueKind.ExpandString
                Case "REG_MULTI_SZ"
                    RegType = RegistryValueKind.MultiString
                Case "REG_QWORD"
                    RegType = RegistryValueKind.QWord
            End Select

        Catch ex As Exception
            GeneralMessageBox(ex.Message, "Jacobs Message - ConvertRegTypeString", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
        End Try

        Return RegType

    End Function

    ''' <summary>
    ''' Exports the nominated REG Hive to a REG file - since this is a read function it should be available to all
    ''' Caution ExportFile name shouldn't contain invalid characters
    ''' </summary>
    ''' <param name="sRegArea"></param>
    ''' <param name="sRegistryHive"></param>
    ''' <param name="ExportFileName"></param>
    ''' <param name="IgnoreErrors"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function RegistryHiveExport(ByVal sRegArea As String, ByVal sRegistryHive As String, ByVal ExportFileName As String, Optional ByVal IgnoreErrors As Boolean = False) As Boolean

        Dim Result As Boolean = False

        Try

            Dim p As New System.Diagnostics.ProcessStartInfo
            p.FileName = "REG.EXE"
            p.Arguments = "EXPORT " & sRegArea & "\" & sRegistryHive & " """ & ExportFileName & ".reg"""
            p.WindowStyle = ProcessWindowStyle.Hidden
            Process.Start(p).WaitForExit()

        Catch ex As Exception
            GeneralMessageBox(ex.Message, "Jacobs Message", MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , IgnoreErrors, logName)
            Result = False
        End Try

        Return Result

    End Function

End Module

'' SOME EXAMPLES
'Imports System
'Imports Microsoft.Win32
'Imports Microsoft.VisualBasic

'Public Class Example
'    Public Shared Sub Main()
'        ' Delete and recreate the test key.
'        Registry.CurrentUser.DeleteSubKey("RegistryValueKindExample", False)
'        Dim rk As RegistryKey = Registry.CurrentUser.CreateSubKey("RegistryValueKindExample")

'        ' Create name/value pairs. 
'        ' This overload supports QWord (long) values. 
'        rk.SetValue("QuadWordValue", 42, RegistryValueKind.QWord)

'        ' The following SetValue calls have the same effect as using the 
'        ' SetValue overload that does not specify RegistryValueKind. 
'        '
'        rk.SetValue("DWordValue", 42, RegistryValueKind.DWord)
'        rk.SetValue("MultipleStringValue", New String() {"One", "Two", "Three"}, RegistryValueKind.MultiString)
'        rk.SetValue("BinaryValue", New Byte() {10, 43, 44, 45, 14, 255}, RegistryValueKind.Binary)
'        rk.SetValue("StringValue", "The path is %PATH%", RegistryValueKind.String)

'        ' This overload supports setting expandable string values. Compare 
'        ' the output from this value with the previous string value.
'        rk.SetValue("ExpandedStringValue", "The path is %PATH%", RegistryValueKind.ExpandString)


'        ' Display all name/value pairs stored in the test key, with each 
'        ' registry data type in parentheses. 
'        ' 
'        Dim valueNames As String() = rk.GetValueNames()
'        Dim s As String
'        For Each s In valueNames
'            Dim rvk As RegistryValueKind = rk.GetValueKind(s)
'            Select Case rvk
'                Case RegistryValueKind.MultiString
'                    Dim values As String() = CType(rk.GetValue(s), String())
'                    Console.Write(vbCrLf & " {0} ({1}) =", s, rvk)
'                    For i As Integer = 0 To values.Length - 1
'                        If i <> 0 Then Console.Write(",")
'                        Console.Write(" ""{0}""", values(i))
'                    Next i
'                    Console.WriteLine()

'                Case RegistryValueKind.Binary
'                    Dim bytes As Byte() = CType(rk.GetValue(s), Byte())
'                    Console.Write(vbCrLf & " {0} ({1}) =", s, rvk)
'                    For i As Integer = 0 To bytes.Length - 1
'                        ' Display each byte as two hexadecimal digits.
'                        Console.Write(" {0:X2}", bytes(i))
'                    Next i
'                    Console.WriteLine()

'                Case Else
'                    Console.WriteLine(vbCrLf & " {0} ({1}) = {2}", s, rvk, rk.GetValue(s))
'            End Select
'        Next s
'    End Sub 'Main
'End Class 'Example

'' 
''This code example produces the following output (some output is omitted): 
'' 
'' QuadWordValue (QWord) = 42 
'' 
'' DWordValue (DWord) = 42 
'' 
'' MultipleStringValue (MultiString) = "One", "Two", "Three" 
'' 
'' BinaryValue (Binary) = 0A 2B 2C 2D 0E FF 
'' 
'' StringValue (String) = The path is %PATH% 
'' 
'' ExpandedStringValue (ExpandString) = The path is C:\Program Files\Microsoft.NET\SDK\v2.0\Bin; 
'' [***The remainder of this output is omitted.***]
