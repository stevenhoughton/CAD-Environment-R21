﻿Imports System.IO
Imports System.DirectoryServices
Imports ActiveDs

Public Module Environment

    ''' <summary>
    ''' Search for a file/executable in the search paths
    ''' </summary>
    ''' <param name="searchPaths"></param>
    ''' <param name="file"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SearchPath(ByVal searchPaths As String, ByVal file As String) As String

        '' check if empty search path
        If String.IsNullOrEmpty(searchPaths) Then

            '' default to system search path
            searchPaths = System.Environment.GetEnvironmentVariable("PATH")

        End If

        '' split up
        Dim paths() As String = Split(searchPaths, ";")
        Dim path As String

        '' scroll through  each path
        For Each path In paths

            '' clean path
            path = path.Trim("\"c)
            path = path.Trim("/"c)

            '' construct path
            Dim filename As String = String.Format("{0}\{1}", path, file)

            '' skip if file does not exist
            If Not System.IO.File.Exists(filename) Then
                Continue For
            End If

            '' found it ... Yahoo!
            Return filename
        Next

        '' not found
        Return vbNullString

    End Function

    Public Function SearchFile(ByVal SearchDir As DirectoryInfo, ByVal searchFileName As String) As String
        Dim temp As String = ""
        If SearchDir.GetFiles(searchFileName).Length > 0 Then
            Return SearchDir.FullName & "\" & searchFileName
        End If
        Dim Directories() As DirectoryInfo = SearchDir.GetDirectories("*")
        For Each newDir As DirectoryInfo In Directories
            temp = SearchFile(newDir, searchFileName)
        Next
        Return temp
    End Function

    ''' <summary>
    ''' Creates a shortcut
    ''' </summary>
    ''' <param name="shortcutName"></param>
    ''' <param name="creationDir"></param>
    ''' <param name="targetFullpath"></param>
    ''' <param name="WorkingFolder"></param>
    ''' <param name="iconFile"></param>
    ''' <param name="iconNumber"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function CreateShortCut(ByVal shortcutName As String, ByVal creationDir As String, ByVal targetFullpath As String, ByVal WorkingFolder As String, ByVal iconFile As String, ByVal iconNumber As Integer, Optional ByVal Arguments As String = "") As Boolean

        Try
            '' get access to the shell
            Dim WshShell As New IWshRuntimeLibrary.WshShell

            If Not System.IO.Directory.Exists(creationDir) Then
                System.IO.Directory.CreateDirectory(creationDir)
            End If

            '' short cut files have a .lnk extension
            Dim shortCut As IWshRuntimeLibrary.IWshShortcut = DirectCast(WshShell.CreateShortcut(creationDir.CombinePath(shortcutName)), IWshRuntimeLibrary.IWshShortcut)

            '' set the shortcut properties
            With shortCut
                .TargetPath = targetFullpath   'Application.ExecutablePath
                .WindowStyle = 1I
                .Description = shortcutName
                .WorkingDirectory = WorkingFolder ' Application.StartupPath
                ' the next line gets the first Icon from the executing program
                .IconLocation = iconFile & ", " & iconNumber 'Application.ExecutablePath & ", 0"
                .Arguments = Arguments
                .Save() ' save the shortcut file
            End With

            '' ok, we have success
            Return True

        Catch ex As System.Exception

            '' failed safely
            Return False

        End Try

        '' cant get here
        Return False

    End Function

    ''' <summary>
    ''' Returns Active Directory site name
    ''' eg AU-MEL
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetADSite() As String

        Dim ds As New ActiveDs.ADSystemInfo
        Dim strSiteName As String = String.Empty

        Try
            If ds IsNot Nothing Then
                If ds.SiteName IsNot Nothing Then

                    strSiteName = ds.SiteName.ToString()
                    strSiteName = strSiteName.Replace("-VPN", String.Empty)
                    strSiteName = strSiteName.Replace("AUSYD0-Internal", "AU-SYD")

                    If strSiteName.Contains("AU-GLB") Then

                        strSiteName = String.Empty

                    Else

                        ' If it Then is not Global and not empty record it for next time
                        If Not String.IsNullOrEmpty(strSiteName) Then
                            ' store it as the last valid 
                            RegistryWrite("HKCU", "Software\Jacobs\Jacobs AutoCAD Environment R21", "LastValidADSiteName", strSiteName, "REG_SZ")
                        End If

                    End If

                Else

                    strSiteName = String.Empty

                End If

            Else
                strSiteName = String.Empty
            End If


            ' Check to see if we have a Previously Saved AD-SITE name recorded
            strSiteName = RegistryRead("HKCU", "Software\Jacobs\Jacobs AutoCAD Environment R21", "LastValidADSiteName", True)

            '' Check to see if there was an AD-Site name created at build time ?
            If strSiteName = String.Empty Then
                strSiteName = RegistryRead("HKLM", "SOFTWARE\BuildInfo", "BuildADSite", True)
            End If

            '' Check to see if there was an AD-Site name created at build time ?
            If strSiteName = String.Empty Then
                strSiteName = RegistryRead("HKLM", "SOFTWARE\BuildInfo", "BuildADSite", True)
            End If


        Catch ex As Exception

            ' Check to see if we have a Previously Saved AD-SITE name recorded
            strSiteName = RegistryRead("HKCU", "Software\Jacobs\Jacobs AutoCAD Environment R21", "LastValidADSiteName", True)

            '' Check to see if there was an AD-Site name created at build time ?
            If strSiteName = String.Empty Then
                strSiteName = RegistryRead("HKLM", "SOFTWARE\BuildInfo", "BuildADSite", True)
            End If

            '' Check to see if there was an AD-Site name created at build time ?
            If strSiteName = String.Empty Then
                strSiteName = RegistryRead("HKLM", "SOFTWARE\BuildInfo", "BuildADSite", True)
            End If

        End Try

        Return strSiteName

    End Function

    ''' <summary>
    ''' Return currently running DLL's path in our case the path of the Jacobs.AutoCAD.Utilities.dll
    ''' Which is the ....Bundle\Contents\ folder returns with an ending \
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetExecutingAssemblyPath(Optional WithBackSlashAtEnd As Boolean = True) As String
        If WithBackSlashAtEnd = True Then
            Return System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location) & "\"
        Else
            Return System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location)
        End If
    End Function

    Public Function WorkOutRegion() As String

        Dim Region As String = "Unknown Region"
        Dim ThisRegion As String = String.Empty
        Dim RegionsFile As String = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\Regions.TXT"

        Try
            If System.IO.File.Exists(RegionsFile) Then
                For Each line As String In Jacobs.Common.Core.ReadTextFile(RegionsFile)
                    If Not line.Trim.StartsWith(";") Then
                        ThisRegion = line.Split(":"c)(0).ToString()
                        line = line.ToUpper.Replace(ThisRegion.ToUpper & ":", "")
                        Dim AllADSitesInRegion As String() = line.Split(","c)
                        For Each ADSite As String In AllADSitesInRegion
                            ' check to see if the AD site name matches
                            If Jacobs.Common.Core.GetADSite.ToUpper Like ADSite.ToUpper Then
                                Region = ThisRegion
                            End If
                        Next
                    End If
                Next
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, )
        End Try

        Return Region

    End Function

    '' Use user name to query AD and work out Email Address 
    '' Worst case check - IM Communicator ?
    Public Function WorkOutJPILoginName() As String

        Dim JpiLoginUserName As String = String.Empty

        Try
            GeneralMessageBox("Trying to get email from AD", , , , , , , True, True, logName)
            Dim EmailString As String = System.DirectoryServices.AccountManagement.UserPrincipal.Current.EmailAddress()
            GeneralMessageBox("Email: " & EmailString, , , , , , , True, True, logName)

            ' JpiLoginUserName = Email.ToUpper.Remove(InStr(Email, "@"), (Email.Length - InStr(Email, "@")) + 1)
            If Not String.IsNullOrEmpty(EmailString) Then

                JpiLoginUserName = EmailString.ToUpper.Remove(InStr(EmailString, "@"), EmailString.Length - InStr(EmailString, "@"))
                JpiLoginUserName = JpiLoginUserName.Replace(".", "_")
                JpiLoginUserName = JpiLoginUserName.Replace("@", "") & ".ID"

                GeneralMessageBox("Retrieved from Active Directory: " & JpiLoginUserName, , , , , , , True, True, logName)

            End If
        Catch ex As Exception

            GeneralMessageBox("Failed in retrieving email from AD", , , , , , , True, True, logName, ex)
            GeneralMessageBox("Trying IM Email", , , , , , , True, True, logName, ex)

            '' HKEY_CURRENT_USER\Software\Microsoft\Shared\Ucclient  ServerSipUri
            If RegistryRead("HKCU", "Software\Microsoft\Shared\Ucclient", "ServerSipUri", True) = "" Then
                JpiLoginUserName = String.Empty
                GeneralMessageBox("JPI user name could not be determined at this time. Try again when connected to the network.", , , , , , , , True, logName, ex)
            Else
                Dim EmailString As String = RegistryRead("HKCU", "Software\Microsoft\Shared\Ucclient", "ServerSipUri", True) & ".ID"

                JpiLoginUserName = EmailString.ToUpper.Remove(InStr(EmailString, "@"), EmailString.Length - InStr(EmailString, "@"))
                JpiLoginUserName = JpiLoginUserName.Replace(".", "_")
                JpiLoginUserName = JpiLoginUserName.Replace("@", "") & ".ID"
                GeneralMessageBox("Retrieved from Instant Messenger: " & JpiLoginUserName, , , , , , , True, True, logName)

            End If

        End Try

        Return JpiLoginUserName

    End Function

    ''' <summary>
    ''' Check the for the presence of the optional PossibleDFS.txt file
    ''' If present it has the ability to override the DFS location
    ''' with the first location in the file that is accessible to this machine.
    ''' Else - If none of the locations in the file exist it uses the default one.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function WorkOutDFSShare() As String

        Dim DFSFile As String = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\PossibleDFS.txt"
        Dim Result As String = String.Empty

        If System.IO.File.Exists(DFSFile) Then
            For Each site As String In Jacobs.Common.Core.Files.ReadTextFile(DFSFile)
                If System.IO.Directory.Exists(site) Then
                    Result = site
                    Exit For
                Else
                    Result = "C:\Program Files"
                End If
            Next
            Return Result
            Exit Function

        End If

        If System.IO.Directory.Exists("\\Jacobs.com\CAD\cfr") Then
            Result = "\\Jacobs.com\CAD\cfr"
            'ElseIf System.IO.Directory.Exists("\\Europe.Jacobs.com\CAD\cfr") Then
            '    Result = "\\europe.Jacobs.com\CAD\cfr"
        ElseIf System.IO.Directory.Exists("\\jade.Jacobs.com\CAD\cfr") Then
            Result = "\\jade.Jacobs.com\CAD\cfr"
        ElseIf System.IO.Directory.Exists("\\jec.Jacobs.com\CAD\cfr") Then
            Result = "\\jec.Jacobs.com\CAD\cfr"
        Else
            '' Default setting could not confirm DFS
            Result = "\\Jacobs.com\CAD\cfr"
        End If

        Return Result

    End Function

    Public Function WorkOutSharedAcadName(Version As String) As String

        ' Dim CADCFGFile As String = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\PossibleNetworkCADCFG.txt"
        Dim Result As String = "Autodesk Shared " & Version.Substring(0, 3)

        If Version.Contains("R21") Then
            '  CADCFGFile = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\PossibleNetworkCADCFG.txt"
            Result = "Autodesk Shared " & Version.Substring(0, 3)
        End If

        GeneralMessageBox("Default shared Acad name evaluated to: " & Result, , , , , , , True, True, logName)

        '      If System.IO.File.Exists(CADCFGFile) Then
        'For Each site As String In Jacobs.Common.Core.Files.ReadTextFile(CADCFGFile)
        ' If System.IO.Directory.Exists(site) Then
        ' Dim split As String() = site.Split("\")
        ' Result = split(split.Length - 1)
        ' Exit For
        ' Else
        ' Result = "C:\ProgramData\Jacobs\"
        ' End If
        ' Next
        ' Return Result
        'Exit Function
        'end If

        GeneralMessageBox("Shared Acad name resolved as: " & Result, , , , , , , True, True, logName)

        Return Result

    End Function

    Public Function WorkOutNetworkCADCFG(Version As String) As String

        Dim Result As String = "C:\ProgramData\JacobsCADCFG"
        Dim CADCFGFile As String = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\PossibleNetworkCADCFG.txt"

        If Version.Contains("R21") Then
            CADCFGFile = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings\PossibleNetworkCADCFG.txt"
            '  Result = "Autodesk Shared " & Version.Substring(0, 3)
        End If

        If System.IO.File.Exists(CADCFGFile) Then
            For Each site As String In Jacobs.Common.Core.Files.ReadTextFile(CADCFGFile)
                If System.IO.Directory.Exists(site) Then
                    ' Dim split As String() = site.Split("\")
                    ' Result = split(split.Length - 3) & "\" & split(split.Length - 2)
                    Result = site
                    Exit For
                End If
                '' Result C:\...
            Next
        Else
            Result = "N:\JacobsCADcfg"
        End If

        Return Result

    End Function

End Module
