﻿Imports System.IO
Imports System.Security.Cryptography
Imports System.Net

''' <summary>
''' A standalone file downloader object
''' </summary>
''' <remarks></remarks>
Public Class Downloader

    ''' <summary>
    ''' Download in progress
    ''' </summary>
    ''' <param name="bytes"></param>
    ''' <param name="totalBytes"></param>
    ''' <param name="percentage"></param>
    ''' <remarks></remarks>
    Public Event Downloading(ByVal bytes As Integer, ByVal totalBytes As Integer, ByVal percentage As Integer)

    ''' <summary>
    ''' A new file is about to be downloaded
    ''' </summary>
    ''' <param name="source"></param>
    ''' <param name="destination"></param>
    ''' <param name="index"></param>
    ''' <param name="total"></param>
    ''' <remarks></remarks>
    Public Event StartedFile(ByVal source As String, destination As String, ByVal index As Integer, ByVal total As Integer)

    ''' <summary>
    ''' Everything downloaded
    ''' </summary>
    ''' <remarks></remarks>
    Public Event Completed()

    ''' <summary>
    ''' Source folder to download from
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Source As String

    ''' <summary>
    ''' Destination folder
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Destination As String

    ''' <summary>
    ''' ByPass reg hive
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ByPassKeyHive As String

    ''' <summary>
    ''' ByPass reg key
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ByPassKey As String

    ''' <summary>
    ''' Check the Change log file to work out if we need to do a download
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property CheckDFSChangeLog As Boolean

    ''' <summary>
    ''' Check the Change log file to work out if we need to do a download
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DFSChangesFile As String

    ''' <summary>
    ''' Recurse sub folders under the source folder for all files and folders
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property RecurseSubFolders As Boolean

    ''' <summary>
    ''' The name of the application or process that calls this program used for logging and error messages
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property CallingApp As String

    ''' <summary>
    ''' Folder download Filter
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property FolderFilter As String = "Jacobs*"

    ''' <summary>
    ''' File download Filter
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property FileFilter As String = "*.*"

    ''' <summary>
    ''' Our reference to the downloader worker
    ''' </summary>
    ''' <remarks></remarks>
    Protected _Downloader As System.Net.WebClient

    ''' <summary>
    ''' All the files to download from the source folder
    ''' </summary>
    ''' <remarks></remarks>
    Protected _Folders() As String

    ''' <summary>
    ''' All the files to download from the source folder
    ''' </summary>
    ''' <remarks></remarks>
    Protected _Files() As String

    ''' <summary>
    ''' Current file being downloaded
    ''' </summary>
    ''' <remarks></remarks>
    Protected _Current As Integer = 0

    ''' <summary>
    ''' Start time for download
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Started As DateTime

    ''' <summary>
    ''' Time the download finished
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Finished As DateTime

    ''' <summary>
    ''' Operation is to run synchronously
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Synchronous As Boolean = False

    ''' <summary>
    ''' Log of destination files
    ''' </summary>
    ''' <remarks></remarks>
    Private _ChangeLog As ChangeLog

    ''' <summary>
    ''' Cleanup destination folder to match source?
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DeleteIfNotOnDFS As Boolean = False

    Public Property ProductInstalledKey As String = ""

    Public LogDeletedThisRun As Boolean = False

    Public MessageDisplayedThisRun As Boolean = False

    '' No access to Manager.evaluateexpression(AllSettings.Manager.AE.logfileextension) - Extension had to be derived
    '' Identified the log file for the DFS Downloader
    Property DFSDownloaderLogFileName As String = "Downloader " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name

    ''' <summary>
    ''' Start downloading
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Start() As Boolean

        If LogDeletedThisRun = False Then
            DeleteLogFile(DFSDownloaderLogFileName, True)
            LogDeletedThisRun = True
        End If

        Dim FolderNames() As String = Split(Me.Source, "\"c)
        Dim LastItem As Integer = UBound(FolderNames)
        Dim SectionBeingDownloaded As String = FolderNames(LastItem - 1) & " " & FolderNames(LastItem)

        If DoWeHaveAdminRights() = False Then
            If MessageDisplayedThisRun = False Then
                GeneralMessageBox(System.Environment.UserName & " is running without the required permissions.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                MessageDisplayedThisRun = True
            End If
            Return False
        End If

        Console.WriteLine("Checking: " & SectionBeingDownloaded)

        WriteToLog("<< STARTED >> download task for: " & Me.Source, DFSDownloaderLogFileName)
        WriteToLog(" [ Settings Used For This Task ]", DFSDownloaderLogFileName)
        WriteToLog("", DFSDownloaderLogFileName)
        WriteToLog("  Source              = " & Me.Source, DFSDownloaderLogFileName)
        WriteToLog("  FolderFilter        = " & Me.FolderFilter, DFSDownloaderLogFileName)
        WriteToLog("  FileFilter          = " & Me.FileFilter, DFSDownloaderLogFileName)
        WriteToLog("  Destination         = " & Me.Destination, DFSDownloaderLogFileName)
        WriteToLog("  ByPassKeyHive       = " & Me.ByPassKeyHive, DFSDownloaderLogFileName)
        WriteToLog("  ByPassKey           = " & Me.ByPassKey, DFSDownloaderLogFileName)
        WriteToLog("  CheckDFSChangeLog   = " & Me.CheckDFSChangeLog, DFSDownloaderLogFileName)
        WriteToLog("  DFSChangesFile      = " & Me.DFSChangesFile, DFSDownloaderLogFileName)
        WriteToLog("  RecurseSubFolders   = " & Me.RecurseSubFolders, DFSDownloaderLogFileName)
        WriteToLog("  CallingApp          = " & Me.CallingApp, DFSDownloaderLogFileName)
        WriteToLog("  DeleteIfNotOnDFS    = " & Me.DeleteIfNotOnDFS, DFSDownloaderLogFileName)
        WriteToLog("  ProductInstalledKey = " & Me.ProductInstalledKey, DFSDownloaderLogFileName)
        WriteToLog("", DFSDownloaderLogFileName)

        ' Bail out here at the beginning of everything.. probably using this PC to test content 
        If CheckByPassDFSDownloads() = True Then
            WriteToLog("Bypass download flag encountered for  " & ProductInstalledKey, DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)

            Console.WriteLine("Bypass Key Found, Skipping: " & SectionBeingDownloaded)

            Return False
            Exit Function
        End If

        ' Check if product is installed
        If Not String.IsNullOrEmpty(Me.ProductInstalledKey) Then

            Dim KeyName As String = Me.ProductInstalledKey.Substring(Me.ProductInstalledKey.LastIndexOf("\"), Me.ProductInstalledKey.Length - Me.ProductInstalledKey.LastIndexOf("\"))
            Dim Hive As String = Me.ProductInstalledKey.Replace(KeyName, "")

            KeyName = KeyName.Replace("\", "")

            If RegistryValueExists("HKLM", Hive, KeyName) = False Then
                WriteToLog("Product Not Installed: " & ProductInstalledKey, DFSDownloaderLogFileName)
                WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)

                Console.WriteLine("Not Installed, Skipping: " & SectionBeingDownloaded)

                Return False
                Exit Function
            End If

        End If

        '' check if in progress
        If Not _Downloader Is Nothing Then

            WriteToLog("Download in progress", DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Return False
            Exit Function

        End If

        '' check if valid
        If String.IsNullOrEmpty(Me.Source) Then

            WriteToLog("Invalid source folder key is null or empty", DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Return False
            Exit Function

        End If

        '' check if source exists
        If System.IO.Directory.Exists(Me.Source) = False Then

            WriteToLog("AutoCAD Environment: Source folder does not exist " & Me.Source, DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Return False
            Exit Function

        End If

        '' check if valid
        If String.IsNullOrEmpty(Me.Destination) Then

            WriteToLog("Invalid destination folder key is null or empty", DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Return False
            Exit Function

        End If

        '' check if valid
        If String.IsNullOrEmpty(Me.DFSChangesFile) Then

            WriteToLog("Invalid DFSchangesFile name key is null or empty", DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Return False
            Exit Function

        End If

        '' check if destination exists
        ''   If System.IO.File.Exists(Me.Destination) Then Throw New Exception("Destination folder does not exist")
        '' Should be created...

        '' check if flag set to recurse subfolder - default to true if omitted...
        If String.IsNullOrEmpty(Me.RecurseSubFolders.ToString) Then

            WriteToLog("Recurse sub folders was null or empty - defaulting to TRUE", DFSDownloaderLogFileName)
            Me.RecurseSubFolders = True

        End If

        '' check if flag set to recurse subfolder - default to true if omitted...
        If String.IsNullOrEmpty(Me.DeleteIfNotOnDFS.ToString) Then

            WriteToLog("Do not Delete if DFS was null or empty - defaulting to FALSE", DFSDownloaderLogFileName)
            Me.DeleteIfNotOnDFS = False

        End If

        '' check if flag set to check DFS changelog - default to true...
        If String.IsNullOrEmpty(Me.CheckDFSChangeLog.ToString) Then

            WriteToLog("CheckDFSChangeLog was null or empty - defaulting to TRUE", DFSDownloaderLogFileName)
            Me.CheckDFSChangeLog = True

        End If

        '' check if calling app name has been provided
        If String.IsNullOrEmpty(Me.CallingApp) Then

            WriteToLog("Invalid calling app string - must specify the name  of the app calling the downloader", DFSDownloaderLogFileName)
            WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Return False
            Exit Function

        End If

        '' get the folders to download
        If Me.RecurseSubFolders.ToString.IsTrue Then
            _Folders = System.IO.Directory.GetDirectories(Me.Source, Me.FolderFilter, System.IO.SearchOption.AllDirectories)
        Else
            _Folders = System.IO.Directory.GetDirectories(Me.Source, Me.FolderFilter, System.IO.SearchOption.TopDirectoryOnly)
        End If

        '' get the files to download
        If Me.RecurseSubFolders.ToString.IsTrue Then
            _Files = System.IO.Directory.GetFiles(Me.Source, Me.FileFilter, System.IO.SearchOption.AllDirectories)
        Else
            _Files = System.IO.Directory.GetFiles(Me.Source, Me.FileFilter, System.IO.SearchOption.TopDirectoryOnly)
        End If

        '' check files?
        If _Files Is Nothing Or _Files.Length <= 0 Then

            If Me.RecurseSubFolders.ToString.IsTrue Then
                WriteToLog("No files of type " & Me.FileFilter & " found in folder or sub folders of " & Me.Source, DFSDownloaderLogFileName)
                WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            Else
                WriteToLog("No files of type " & Me.FileFilter & " found in folder " & Me.Source, DFSDownloaderLogFileName)
                WriteToLog("<< EXITING TASK DOWNLOAD >>", DFSDownloaderLogFileName)
            End If

            Return False
            Exit Function

        End If

        If Me.CheckDFSChangeLog = True Then
            '' load change log
            _ChangeLog = ChangeLog.Load(Me.Destination)
        End If

        '' create a new downloader
        _Downloader = New System.Net.WebClient()

        '' subscribe to events
        AddHandler _Downloader.DownloadProgressChanged, AddressOf OnDownloadProgressChanged
        AddHandler _Downloader.DownloadFileCompleted, AddressOf OnDownloadFileCompleted

        '' start
        _Current = 0
        Started = Date.Now

        '' do it
        ' Normally if calling this without a dialog box you would run it Synchronous
        ' If calling it from a dialog box then run asynchronous
        ' Check the show progress bar variable to work out which one to use...

        If Synchronous Then
            RunSynchronous()
        Else
            RunAsynchronous()
        End If

        '' OK
        Return True

    End Function

    ''' <summary>
    ''' Stop downloading
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Cancel() As Boolean

        '' bail if no running
        If _Downloader Is Nothing Then Return False

        '' set to canceled state
        _Current = _Files.Length

        '' stop current
        _Downloader.CancelAsync()

        '' remove reference
        _Downloader = Nothing

        '' Ok
        Return True

    End Function

    ''' <summary>
    ''' Handle download event
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub OnDownloadProgressChanged(ByVal sender As Object, ByVal e As Net.DownloadProgressChangedEventArgs)

        RaiseEvent Downloading(CInt(e.BytesReceived), CInt(e.TotalBytesToReceive), e.ProgressPercentage)

    End Sub

    ''' <summary>
    ''' A file has completed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub OnDownloadFileCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.AsyncCompletedEventArgs)

        '' move to next file
        _Current = _Current + 1

        '' check if canceled?
        If _Current >= _Files.Length Then

            '' get time
            Finished = Date.Now

            '' cleanup?
            If Me.DeleteIfNotOnDFS Then
                Folders.Delete(Me.Destination)
            End If

            '' cleanup?
            If Me.DeleteIfNotOnDFS Then
                Files.MatchDelete(Me.Source, Me.FileFilter, True, Me.Destination)
            End If

            GeneralMessageBox("Started at: " & Started.ToString & vbCr &
                            "Finished at: " & Finished.ToString & vbCr &
                            "Elapsed time: = " & (Finished - Started).ToString,
                             System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

            If Me.CheckDFSChangeLog = True Then
                '' save change log
                _ChangeLog.Save(Me.Destination)
            End If

            '' advise
            RaiseEvent Completed()
            Return

        End If

        '' do the next
        RunAsynchronous()

    End Sub

    ''' <summary>
    ''' Download synchronously
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub RunSynchronous()

        Dim PrevSource As String = String.Empty

        '' scroll through all the files
        For i As Integer = 0 To _Files.Length - 1

            '' next file
            _Current = i

            '' get locations
            Dim source As String = _Files(_Current)
            Dim destination As String = source.Replace(Me.Source, Me.Destination)

            '' advise
            RaiseEvent StartedFile(source, destination, _Current, _Files.Length)

            '' source URL
            Dim url As New Uri("file:" & source)

            ' Check DFSChange.log on server if it's same as on PC - don't even try to download
            Dim srcDate As Date

            Dim DoDownload As Boolean = True

            If _ChangeLog IsNot Nothing Then
                DoDownload = _ChangeLog.DownloadFile(source, destination, srcDate)
            Else
                DoDownload = True
            End If

            If DoDownload = True Then

                ' If Folder not present create it
                If System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(destination)) = False Then
                    System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(destination))
                End If

                Try

                    '' Do it
                    _Downloader.DownloadFile(url, destination)

                Catch ex As Exception

                    Dim MethodName As String = System.Reflection.MethodBase.GetCurrentMethod.Name()
                    Dim ModuleName As String = System.Reflection.MethodBase.GetCurrentMethod.Module.Name()

                    GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, ,
                                                   "Trying to download " & url.ToString & " TO -->> " & destination, DFSDownloaderLogFileName)
                    GeneralMessageBox("Trying to download " & url.ToString & " TO -->> " & destination, )

                End Try

                If Me.Source <> PrevSource Then
                    '' message
                    Dim FolderNames() As String = Split(Me.Source, "\"c)
                    Dim LastItem As Integer = UBound(FolderNames)
                    Dim SectionBeingDownloaded As String = FolderNames(LastItem - 1) & " " & FolderNames(LastItem)

                    Console.WriteLine("Synchronous Downloading Files for: " & SectionBeingDownloaded)

                    ' Console.WriteLine("Synchronous Downloading: " & url.ToString & " to " & destination)
                    PrevSource = Me.Source

                End If

                WriteToLog("      Synchronous Downloading: " & url.ToString & " to " & destination, DFSDownloaderLogFileName)

                If Me.CheckDFSChangeLog = True Then
                    '' save new date
                    _ChangeLog.Add(destination, srcDate)
                End If

            End If

        Next i

        '' cleanup
        _Downloader = Nothing

        '' time please
        Finished = Date.Now

        '' cleanup
        If Me.DeleteIfNotOnDFS Then
            Folders.Delete(Me.Destination)
        End If

        '' cleanup
        If Me.DeleteIfNotOnDFS Then
            Files.MatchDelete(Me.Source, Me.FileFilter, True, Me.Destination)
        End If

        If Me.CheckDFSChangeLog = True Then
            '' save change log
            _ChangeLog.Save(Me.Destination)
        End If

        WriteToLog(vbCr & "<< TASK COMPLETED >> " & Me.Source & vbCr, DFSDownloaderLogFileName)

        '' done here
        RaiseEvent Completed()

    End Sub

    ''' <summary>
    ''' Download completed function signature
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Delegate Sub DownloadFileCompletedDelegate(ByVal sender As Object, ByVal e As System.ComponentModel.AsyncCompletedEventArgs)

    ''' <summary>
    ''' Run ...
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub RunAsynchronous()

        Dim PrevSource As String = String.Empty

        '' check if we have finished?
        If _Current >= _Files.Length Then

            '' cleanup?
            If Me.DeleteIfNotOnDFS Then
                Folders.Delete(Me.Destination)
            End If

            If Me.DeleteIfNotOnDFS Then
                Files.MatchDelete(Me.Source, Me.FileFilter, True, Me.Destination)
            End If

            '' stop running
            Return
        End If

        '' get locations
        Dim source As String = _Files(_Current)
        Dim destination As String = source.Replace(Me.Source, Me.Destination)

        '' advise
        RaiseEvent StartedFile(source, destination, _Current, _Files.Length)

        '' source URL
        Dim url As New Uri("file:" & source)

        ' Check DFSChange.log on server if it's same as on PC - don't even try to download
        Dim srcDate As Date

        Dim DoDownload As Boolean = True

        If _ChangeLog IsNot Nothing Then
            DoDownload = _ChangeLog.DownloadFile(source, destination, srcDate)
        Else
            DoDownload = True
        End If

        If DoDownload = True Then

            ' If Folder not present create it
            If System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(destination)) = False Then
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(destination))
            End If

            Try

                '' download asynchronously  
                _Downloader.DownloadFileAsync(url, destination)

            Catch ex As Exception

                GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , _
                                           "Trying to download " & url.ToString & " TO -->> " & destination, DFSDownloaderLogFileName)

            End Try

            Console.WriteLine("Asynchronous Downloading: " & url.ToString & " to " & destination)

            If Me.Source <> PrevSource Then
                '' message
                Dim FolderNames() As String = Split(Me.Source, "\"c)
                Dim LastItem As Integer = UBound(FolderNames)
                Dim SectionBeingDownloaded As String = FolderNames(LastItem - 1) & " " & FolderNames(LastItem)

                Console.WriteLine("Asynchronous Downloading Files for: " & SectionBeingDownloaded)
                ' Console.WriteLine("Asynchronous Downloading: " & url.ToString & " to " & destination)
                PrevSource = Me.Source
            End If

            If Me.CheckDFSChangeLog = True Then
                '' save new date
                _ChangeLog.Add(destination, srcDate)
            End If

        Else

            '' spawn a completed event, must do an asynchronous call here to avoid the recursive stack overflow exception
            Dim proc As New DownloadFileCompletedDelegate(AddressOf OnDownloadFileCompleted)
            proc.BeginInvoke(Me, Nothing, Nothing, Nothing)

        End If

    End Sub

    ''' <summary>
    ''' Check for presence of the download bypass key returns false unless it finds one that is set to True
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>

    Protected Function CheckByPassDFSDownloads() As Boolean

        Try

            Dim regkeyvalue As String = ""

            Try

                regkeyvalue = RegistryRead("HKCU", Me.ByPassKeyHive, Me.ByPassKey)
                'My.Computer.Registry.CurrentUser.OpenSubKey(Me.ByPassKeyHive, False).GetValue("ByPassDFSDownloads").ToString()

            Catch ex As System.Exception
                ' Assume this was a missing key and return false - since it's only a read call its most likely to be a missing key - which is not required
                Return False

            End Try

            ' If the key is not present then just do downloads
            If regkeyvalue Is Nothing Then
                Return False
            Else
                Dim Result As Boolean
                ' If it is present check the value of the key and convert it from a string to a boolean - must be true for it to download anything else will return a false.
                Boolean.TryParse(regkeyvalue, Result)
                Return Result
            End If

        Catch ex As Exception
            GeneralMessageBox(ex.Message, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , logName)
            Return False
        End Try

    End Function

End Class
