﻿Public Class UserControl1

    Private mRootPath As String = "C:\"
    Property RootPath() As String
        Get
            Return mRootPath
        End Get
        Set(ByVal value As String)
            mRootPath = value
        End Set
    End Property

    Private Sub UserControl1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' when our component is loaded, we initialize the TreeView by adding the root node
        Dim mRootNode As New TreeNode
        mRootNode.Text = RootPath
        mRootNode.Tag = RootPath
        mRootNode.Name = RootPath.ToLower
        mRootNode.Nodes.Add("*DUMMY*")
        TreeView1.Nodes.Add(mRootNode)
    End Sub

    Private Sub TreeView1_BeforeCollapse(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView1.BeforeCollapse
        ' clear the node that is being collapsed
        e.Node.Nodes.Clear()
        ' add a dummy TreeNode to the node being collapsed so it is expandable
        e.Node.Nodes.Add("*DUMMY*")
    End Sub

    Private Sub TreeView1_BeforeExpand(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewCancelEventArgs) Handles TreeView1.BeforeExpand
        ' clear the argNode so we can re-populate, or else we end up with duplicate nodes
        e.Node.Nodes.Clear()
        ' get the directory representing this node
        Dim mNodeDirectory As IO.DirectoryInfo
        mNodeDirectory = New IO.DirectoryInfo(e.Node.Tag.ToString)
        ' add each directory from the file system that is a child of the argNode that was passed in
        For Each mDirectory As IO.DirectoryInfo In mNodeDirectory.GetDirectories
            ' declare a TreeNode for this directory
            Dim mDirectoryNode As New TreeNode
            ' store the full path to this directory in the directory TreeNode's Tag property
            mDirectoryNode.Tag = mDirectory.FullName
            ' set the directory TreeNodes's display text
            mDirectoryNode.Text = mDirectory.Name
            ' TODO: NEW .Name property set
            mDirectoryNode.Name = mDirectory.FullName.ToLower
            ' add a dummy TreeNode to the directory node so that it is expandable
            mDirectoryNode.Nodes.Add("*DUMMY*")
            ' add this directory treenode to the treenode that is being populated
            e.Node.Nodes.Add(mDirectoryNode)
        Next
    End Sub

End Class
