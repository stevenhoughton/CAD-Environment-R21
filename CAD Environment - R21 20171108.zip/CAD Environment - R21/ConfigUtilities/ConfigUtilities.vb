
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.ConfigUtilities.ConfigUtilities))> 

Public Module ConfigUtilities

    ' Dim RuleAccessors As New RuleAccessors
    Dim SelectConfig As New SelectTemplate.TemplateSelector

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_RemoveTemplateAssociation", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub Rcfg()
        Try
            Dim RetCode As DialogResult

            RetCode = Acad_MessageBox("This will remove the configuration reference from this file." & vbCrLf &
                            "It will also save and exit this file automatically. As: " & vbCrLf & vbCrLf &
                            ThisDrawingUtilities.Path & "\" & ThisDrawingUtilities.Name & vbCrLf & vbCrLf &
                            "Are you sure you wish to do this?",
                            System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If RetCode = DialogResult.Yes Then
                RuleAccessors.RemoveRule("FULLCONFIGNAME")
                RuleAccessors.RemoveRule("CONFIGLEVEL")
                RuleAccessors.RemoveRule("MENU")
                RuleAccessors.RemoveRule("DONTASKSWITCHCFG")
                RuleAccessors.RemoveRule("TESTCONFIG")

                Acad_MessageBox("Configuration has been removed. " & vbCrLf & "This file will now be saved.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                ThisDrawingUtilities.Save()
                ThisDrawingUtilities.SetVariable("FILEDIA", 1)

                Acad_MessageBox("Please close and the drawing for the autocad drawing session to be reinitialised correctly.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                'ThisDrawing.Close()

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_ApplyTemplateAssociation", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Sub Scfg()

        Try

            Dim SelectTemplateDialog As NewTemplateSelectorForm = New NewTemplateSelectorForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(SelectTemplateDialog)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_RebuildTemplateAssociation", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub Acfg()

        Try
            ' No Choice here cannot add a config using a non configured drawing
            If ThisDrawingIsConfigured() = False Then

                Acad_MessageBox("The Add Configuration Tool cannot be run while in a non configured drawing. Create a new drawing using the configuration you require then run the Add Configuration Tool",
                                 , MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                DoAdd()
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub DoAdd()

        Dim RetCode As DialogResult
        Dim sFname As String
        Dim InsertedDwg As Autodesk.AutoCAD.Interop.Common.AcadBlockReference
        Dim InsPt(2) As Double
        Dim sSelectedFileName As String

        InsPt(0) = 0.0#
        InsPt(1) = 0.0#
        InsPt(2) = 0.0#

        RetCode = Acad_MessageBox("This will add the configuration from the current drawing to the file you select. " &
                                  "It will import the selected file into this one and save it with a suffix '- AE Configured'" &
                       vbCr & vbCr & vbCr & "Are you sure you wish to do this?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If RetCode = DialogResult.Yes Then
            sFname = AutoCADOpenSingleSelect(ThisDrawingUtilities.GetVariable("DWGPREFIX").ToString, "Select file to Configure", "DWG", "Select file to add configuration")
            If sFname <> "" Then
                sSelectedFileName = sFname
                InsertedDwg = ThisDrawingUtilities.ModelSpace.InsertBlock(InsPt, sFname, 1.0#, 1.0#, 1.0#, 0.0#)
                InsertedDwg.Explode()
                InsertedDwg.Delete()
                ImportAllLayouts(sSelectedFileName)
                sFname = Left(sSelectedFileName, Len(sSelectedFileName) - 4) & "AE Configured.DWG"

                Acad_MessageBox("File Will be saved as: " & sFname, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ThisDrawingUtilities.SaveAs(sFname)
            End If
        End If

    End Sub

    Public Sub ImportAllLayouts(ByRef sFileToImportFrom As String)

        Dim frmImportTableRecords As New frmImportTableRecords
        'Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(frmName)
        ' display the import form
        frmImportTableRecords.Display(sFileToImportFrom)

    End Sub

End Module