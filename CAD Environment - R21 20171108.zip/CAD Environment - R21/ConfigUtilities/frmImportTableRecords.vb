Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings

Friend Class frmImportTableRecords
    Inherits System.Windows.Forms.Form

    ' class variable to hold the dbase we're importing from
    Private m_pAxDoc As Autodesk.AutoCAD.Interop.Common.AxDbDocument
    ' class variable to hold the integer constant of the Acad
    ' symbol table we're editing
    Private m_iSymbolTable As Integer

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   Display
    '
    '   Arguments:      String specifiying the Acad file to import from
    '                   and integer corresponding to the constants defined
    '                   for the symbol table type to import from
    '
    '   Description:    Sets form controls to defaults, then based on integer
    '                   pased in, get's a pointer to the appropriate symbol table,
    '                   then lops that table and populates the listbox.
    '
    '   Returns:        Nothing.
    '
    '------------------------------------------------------------------------------

    Public Sub Display(ByRef sFileToImport As String)

        Dim pAxSymTbl As Autodesk.AutoCAD.Interop.Common.AcadLayouts
        Dim pAxSymTblRcd As Autodesk.AutoCAD.Interop.Common.AcadObject
        Dim pAxDict As Autodesk.AutoCAD.Interop.Common.AcadDictionary
        Dim pAxTableStyle As Autodesk.AutoCAD.Interop.Common.AcadTableStyle

        ' enable error trapping
        On Error GoTo ErrorHandler

        ' set the table we're looking at
        '    m_iSymbolTable = iTable
        ' create a new database doc
        m_pAxDoc = New Autodesk.AutoCAD.Interop.Common.AxDbDocument
        ' open the doc in memory
        m_pAxDoc.Open(sFileToImport)

        ' set the caption for the form
        Me.Text = "Import Layouts"
        ' set the frame caption
        fraImport.Text = "Layouts"
        ' set the symbol table pointer
        pAxSymTbl = m_pAxDoc.Layouts

        ' if we didn't get a pointer to the correct table, bail out
        If pAxSymTbl Is Nothing Then GoTo ExitHere

        ' loop the table and add the items to the listview
        For Each pAxSymTblRcd In pAxSymTbl

            If TypeOf pAxSymTblRcd Is Autodesk.AutoCAD.Interop.Common.AcadBlock Then

                'If pAxSymTblRcd.GetType Is GetType(AcadBlock) Then

                Dim mypAxSymTblRcd As AcadBlock
                mypAxSymTblRcd = CType(pAxSymTblRcd, AcadBlock)
                If Not mypAxSymTblRcd.IsLayout Then
                    If Not mypAxSymTblRcd.IsXRef Then
                        If Not mypAxSymTblRcd.Name Like "*|*" Then
                            lbRecords.Items.Add(mypAxSymTblRcd.Name)
                        End If
                    End If
                End If

                'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
            ElseIf TypeOf pAxSymTblRcd Is Autodesk.AutoCAD.Interop.Common.AcadLayout Then
                '            ElseIf pAxSymTblRcd.GetType Is GetType(AcadLayout) Then

                Dim mypAxSymTblRcd As AcadLayout

                mypAxSymTblRcd = CType(pAxSymTblRcd, AcadLayout)

                If UCase(mypAxSymTblRcd.Name) <> "MODEL" Then
                    lbRecords.Items.Add(mypAxSymTblRcd.Name)
                End If

                'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
            ElseIf TypeOf pAxSymTblRcd Is Autodesk.AutoCAD.Interop.Common.AcadPlotConfiguration Then
                '            ElseIf pAxSymTblRcd.GetType Is GetType(AcadPlotConfiguration) Then

                Dim mypAxSymTblRcd As AcadPlotConfiguration
                mypAxSymTblRcd = CType(pAxSymTblRcd, AcadPlotConfiguration)

                lbRecords.Items.Add(mypAxSymTblRcd.Name)
            Else
                ''Dim mypAxSymTblRcd As AcadEntity
                ''mypAxSymTblRcd = CType(pAxSymTblRcd, AcadEntity)

                'If Not pAxSymTblRcd.Name Like "*|*" Then
                '    lbRecords.Items.Add(pAxSymTblRcd.Name)
                'End If

                Acad_ExceptionMessageBox(New Exception("pAxSymTblRcdnot added to lbrecirds type: " & pAxSymTblRcd.GetType().FullName), System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

            End If
        Next pAxSymTblRcd

ExitHere:
        ' show the form
        Me.ShowDialog()
        ' bail out
        Exit Sub

ErrorHandler:
        Select Case Err.Number
            Case -2145386476 ' key not found
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                Resume ExitHere
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                Resume ExitHere
        End Select

    End Sub

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   cmdCancel_Click
    '
    '   Arguments:      None
    '
    '   Description:    Cancel button event procedure.
    '
    '   Returns:        Nothing
    '
    '------------------------------------------------------------------------------

    'Private Sub cmdCancel_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Me.Close()
    'End Sub

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   cmdOK_Click
    '
    '   Arguments:      None
    '
    '   Description:    OK button event procedure.
    '                   Loops thru the listbox entries, get's the selected ones,
    '                   then depending on the table type, clones them from the dbase
    '                   to the appropriate symbol table in the current drawing.
    '
    '   Returns:        Nothing
    '
    '------------------------------------------------------------------------------

    Private Sub cmdOk_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOk.Click

        Dim WZ_PAGESETUPS_TABLE As Integer
        Dim WZ_LAYOUTS_TABLE As Integer
        Dim WZ_TABLESTYLE_TABLE As Integer
        Dim WZ_TEXTSTYLE_TABLE As Integer
        Dim WZ_LINETYPE_TABLE As Integer
        Dim WZ_LAYER_TABLE As Integer
        Dim WZ_DIMSTYLE_TABLE As Integer
        Dim WZ_BLOCK_TABLE As Integer

        Dim i, j As Integer
        Dim symbolTableRecords() As Autodesk.AutoCAD.Interop.Common.AcadObject = Nothing

        ' enable rror trapping
        On Error GoTo ErrorHandler

        j = -1
        Dim pLayout As Autodesk.AutoCAD.Interop.Common.AcadLayout
        Dim k As Integer
        Dim pAxLayout As Autodesk.AutoCAD.Interop.Common.AcadLayout
        Dim pAxLayoutBlkTblRcd As Autodesk.AutoCAD.Interop.Common.AcadBlock
        Dim pAxEnt As Autodesk.AutoCAD.Interop.Common.AcadEntity
        Dim pAxBlockEnts() As Autodesk.AutoCAD.Interop.Common.AcadEntity = Nothing
        Dim bFoundObjects As Boolean
        For i = 0 To lbRecords.Items.Count - 1
            If lbRecords.GetSelected(i) Then
                j = j + 1
                ' resize our array
                ReDim Preserve symbolTableRecords(j)
                ' check which table we need to process

                ' can't import a layout of the same name as this
                ' will cause Acad to fall over kicking and screaming
                ' so we have to see if the selected layout already exists.
                ' If it DOES, then we suffix the name with a number like Acad does
                ' and try again. If it doesn't exist it's safe to add it
                'pAxLayout = m_pAxDoc.Layouts.Item(VB6.GetItemString(lbRecords, i))
                pAxLayout = m_pAxDoc.Layouts.Item(UserInterface.GetListBoxText(lbRecords, i))
                k = -1
                Do
                    'UPGRADE_NOTE: Object pLayout may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
                    pLayout = Nothing
                    k = k + 1
                    pLayout = ThisDrawingUtilities.Layouts.Add(UserInterface.GetListBoxText(lbRecords, i) & IIf(k > 0, String.Format("({0})", k), "").ToString())
                    If Not pLayout Is Nothing Then Exit Do
                Loop
                ' copy the plot setting over
                'UPGRADE_WARNING: Couldn't resolve default property of object pAxLayout. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                pLayout.CopyFrom(CType(pAxLayout, Autodesk.AutoCAD.Interop.Common.AcadPlotConfiguration))
                ' get the block associated with this layout from the dbase in memory
                pAxLayoutBlkTblRcd = pAxLayout.Block
                ' re-init our counter
                k = -1
                ' loop the block table record of the layout
                For Each pAxEnt In pAxLayoutBlkTblRcd
                    k = k + 1
                    ReDim Preserve pAxBlockEnts(k)
                    ' add our entity into the array
                    pAxBlockEnts(k) = pAxEnt
                    bFoundObjects = True
                Next pAxEnt
                ' clone the array of entities into our new layout
                ' in the current drawing
                If bFoundObjects Then
                    m_pAxDoc.CopyObjects(pAxBlockEnts, pLayout.Block)
                End If
            End If
        Next

        ' check which table in the current drawing we need to clone to...
        Select Case m_iSymbolTable
            Case WZ_BLOCK_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Blocks)
            Case WZ_DIMSTYLE_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.DimStyles)
            Case WZ_LAYER_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Layers)
            Case WZ_LINETYPE_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Linetypes)
            Case WZ_TEXTSTYLE_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.TextStyles)
            Case WZ_TABLESTYLE_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.Dictionaries.Item("ACAD_TABLESTYLE"))
            Case WZ_LAYOUTS_TABLE
                ' do nothing here as we did it all above for layouts
            Case WZ_PAGESETUPS_TABLE
                m_pAxDoc.CopyObjects(symbolTableRecords, ThisDrawingUtilities.PlotConfigurations)
        End Select

        ' release the dwg dbase
        m_pAxDoc = Nothing

        ' get rid of the form
        Me.Close()

BailOut:
        Exit Sub

ErrorHandler:
        Select Case Err.Number
            Case -2145386475 ' duplicate key
                Information.Err.Clear()
                Resume Next
            Case -2145386476 ' key not found
                'clear the error
                Information.Err.Clear()
                Resume Next
            Case Else
                Acad_MessageBox(Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Information.Err.Clear()
                Resume BailOut
        End Select
    End Sub

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   lbRecords_Change
    '
    '   Arguments:      None.
    '
    '   Description:    Listbox change event procedure. Enables the OK button.
    '
    '   Returns:        Nothing.
    '
    '------------------------------------------------------------------------------

    Private Sub lbRecords_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbRecords.SelectedIndexChanged
        cmdOk.Enabled = True
    End Sub

    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub frmImportTableRecords_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '' Workout out the Dialog Box Title 
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        ' Now that we have things like the AEVersion number and Title display it on the dialog name 
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version
        RepositionTitle(Me.lblTitle, Me)
    End Sub

    Private Sub frmImportTableRecords_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

End Class