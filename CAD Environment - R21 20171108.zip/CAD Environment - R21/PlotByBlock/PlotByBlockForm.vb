﻿Imports System.IO
Imports System.Windows.Forms
Imports Jacobs.Common.Core

Public Class PlotByBlockForm

    Dim FormData_DS As New DataSet
    Dim XMLFileToRead As String = ""
    Dim SearchFilePath As String = ""

    Public WriteOnly Property FilePath() As String
        Set(ByVal value As String)
            SearchFilePath = value
        End Set
    End Property

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Dim objAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly
        Dim VNumber As String
        'Get each part of the version through the assembly object
        VNumber = objAssembly.GetName().Version.Major & "." & objAssembly.GetName().Version.Minor & "." & _
            objAssembly.GetName().Version.Build & "." & objAssembly.GetName().Version.Revision

        Me.Text = objAssembly.GetName().Name & " - " & VNumber

    End Sub

    Private Sub frmPlotByBlock_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim FStream As FileStream
        Dim ContinueFlag As Boolean = True
        Dim ErrorInMainTry As Boolean = False

        Try
            If SearchFilePath <> "" Then
                XMLFileToRead = SearchFilePath.Replace(".dll", ".xml")
            Else
                ContinueFlag = False
            End If

        Catch ex As Exception
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            Try

                FStream = New FileStream(XMLFileToRead, FileMode.Open)

                FormData_DS.ReadXml(FStream)

                FStream.Close()

                If FormData_DS.Tables.Count > 0 Then

                    FormData_DS.Tables(0).TableName = "PLOTSETTING"

                    Dim dtCloned As DataTable = FormData_DS.Tables(0).Clone()
                    dtCloned.Columns(1).DataType = GetType(String)
                    dtCloned.Columns(2).DataType = GetType(String)
                    dtCloned.Columns(3).DataType = GetType(String)
                    dtCloned.Columns(4).DataType = GetType(String)
                    dtCloned.Columns(5).DataType = GetType(String)

                    For Each row As DataRow In FormData_DS.Tables(0).Rows
                        dtCloned.ImportRow(row)
                    Next

                    FormData_DS.Tables.Remove("PLOTSETTING")
                    FormData_DS.AcceptChanges()

                    FormData_DS.Tables.Add(dtCloned.Copy)
                    FormData_DS.AcceptChanges()

                End If

            Catch ex As Exception
                FormData_DS.Tables.Add(CreateEmptyDataTable)
            Finally
                FStream = Nothing
            End Try

        Else
            FormData_DS.Tables.Add(CreateEmptyDataTable)
        End If

        If FormData_DS.Tables(0).Rows.Count = 1 Then
            lstBlockNames.Items.Clear()
            txtPageSetup.Text = FormData_DS.Tables(0).Rows(0).Item("PAGESETUP").ToString
            lstFrameNames.Items.AddRange(FormData_DS.Tables(0).Rows(0).Item("FRAMES").ToString.Split(","))
            lstBlockNames.Items.AddRange(FormData_DS.Tables(0).Rows(0).Item("BLOCKNAMES").ToString.Split(","))
            txtDrawingNoAtt.Text = FormData_DS.Tables(0).Rows(0).Item("DWGNUMBERATT").ToString
            txtDrawingRevAtt.Text = FormData_DS.Tables(0).Rows(0).Item("DWGREVATT").ToString
            txtOutPutPath.Text = FormData_DS.Tables(0).Rows(0).Item("OUTPUTPATH").ToString
        End If

    End Sub

    Public Function CreateEmptyDataTable() As DataTable

        Dim DatTable As New DataTable

        DatTable.TableName = "PLOTSETTING"
        DatTable.Columns.Add("PAGESETUP", GetType(String))
        DatTable.Columns.Add("FRAMES", GetType(String))
        DatTable.Columns.Add("BLOCKNAMES", GetType(String))
        DatTable.Columns.Add("DWGNUMBERATT", GetType(String))
        DatTable.Columns.Add("DWGREVATT", GetType(String))
        DatTable.Columns.Add("OUTPUTPATH", GetType(String))

        Return DatTable

    End Function

    Private Sub txtPageSetup_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPageSetup.TextChanged
        UpdateOKButtons()
    End Sub

    Private Sub txtDrawingNoAtt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDrawingNoAtt.TextChanged
        UpdateOKButtons()
    End Sub

    Private Sub txtDrawingRevAtt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtDrawingRevAtt.TextChanged
        UpdateOKButtons()
    End Sub

    Private Sub txtOutPutPath_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOutPutPath.TextChanged
        UpdateOKButtons()
    End Sub

    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        If txtNewBlockName.Text <> "" Then
            If lstBlockNames.Items.Contains(txtNewBlockName.Text) = False Then
                lstBlockNames.Items.Add(txtNewBlockName.Text)
                txtNewBlockName.Text = ""
            End If
        End If
        UpdateOKButtons()
    End Sub

    Private Sub cmdRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
        If lstBlockNames.SelectedItems.Count = 1 Then
            lstBlockNames.Items.Remove(lstBlockNames.SelectedItems(0))
        End If
        UpdateOKButtons()
    End Sub

    Private Sub txtNewBlockName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNewBlockName.TextChanged

        If txtNewBlockName.Text <> "" Then
            cmdAdd.Enabled = True
            cmdRemove.Enabled = False
        Else
            cmdAdd.Enabled = False
            cmdRemove.Enabled = False
        End If

    End Sub

    Private Sub lstBlockNames_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstBlockNames.SelectedValueChanged

        If lstBlockNames.SelectedItems.Count = 1 Then
            cmdRemove.Enabled = True
        Else
            cmdRemove.Enabled = False
        End If

    End Sub

    Private Sub UpdateOKButtons()

        Dim Cnter As Integer = 0

        If txtPageSetup.Text <> "" Then
            FormData_DS.Tables(0).Rows(0).Item("PAGESETUP") = txtPageSetup.Text
            Cnter += 1
        End If

        If txtDrawingRevAtt.Text <> "" Then
            FormData_DS.Tables(0).Rows(0).Item("DWGREVATT") = txtDrawingRevAtt.Text
            Cnter += 1
        End If

        If txtDrawingNoAtt.Text <> "" Then
            FormData_DS.Tables(0).Rows(0).Item("DWGNUMBERATT") = txtDrawingNoAtt.Text
            Cnter += 1
        End If

        If lstBlockNames.Items.Count > 0 Then
            FormData_DS.Tables(0).Rows(0).Item("BLOCKNAMES") = ""
            For Index As Integer = 0 To lstBlockNames.Items.Count - 1
                FormData_DS.Tables(0).Rows(0).Item("BLOCKNAMES") += lstBlockNames.Items(Index).ToString & If(Index < (lstBlockNames.Items.Count - 1), ",", "")
            Next
            Cnter += 1
        End If

        If lstFrameNames.Items.Count > 0 Then
            FormData_DS.Tables(0).Rows(0).Item("FRAMES") = ""
            For Index As Integer = 0 To lstFrameNames.Items.Count - 1
                FormData_DS.Tables(0).Rows(0).Item("FRAMES") += lstFrameNames.Items(Index).ToString & If(Index < (lstFrameNames.Items.Count - 1), ",", "")
            Next
            Cnter += 1
        End If

        If txtOutPutPath.Text <> "" Then
            If Directory.Exists(txtOutPutPath.Text) Then
                FormData_DS.Tables(0).Rows(0).Item("OUTPUTPATH") = txtOutPutPath.Text
                Cnter += 1
            End If
        End If

        If Cnter = 6 Then
            cmdSaveSettings.Enabled = True
        Else
            cmdSaveSettings.Enabled = False
        End If

    End Sub

    'Only used if the XML is missing from PC to create new XML
    Public WriteOnly Property DS() As DataSet
        Set(ByVal value As DataSet)
            FormData_DS = value
        End Set
    End Property

    Public Sub SaveXML(ByVal PDesc As String, ByVal FilePath As String)

        If FormData_DS.Tables("PLOTSETTING").Rows.Count > 0 Then

            If File.Exists(FilePath) Then
                File.Delete(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Settings File has been deleted" & vbCrLf)
                FormData_DS.WriteXml(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Settings File has been ReWritten!" & vbCrLf)
            Else
                FormData_DS.WriteXml(FilePath)
            End If
        End If

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveSettings.Click

        If FormData_DS.HasChanges Then

            FormData_DS.AcceptChanges()
            SaveXML("PLOT Settings", XMLFileToRead)

        End If

        Close()

    End Sub

    Private Sub cmdBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowse.Click

        'Dim NewPath As New FolderBrowserDialog
        'If NewPath.ShowDialog = Windows.Forms.DialogResult.OK Then
        '    txtOutPutPath.Text = NewPath.SelectedPath
        'End If

        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                txtOutPutPath.Text = ReturnedFolder
                UpdateOKButtons()
            Else
                GeneralMessageBox("Path does not exist - please try again")
            End If
        End If

    End Sub

    Private Sub lstBlockNames_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstBlockNames.SelectedIndexChanged

    End Sub

    Private Sub lstFrameNames_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstFrameNames.SelectedValueChanged

        If lstFrameNames.SelectedItems.Count = 1 Then
            cmdDeleteFrame.Enabled = True
        Else
            cmdDeleteFrame.Enabled = False
        End If

    End Sub

    Private Sub cmdAddFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddFrame.Click
        If txtFrameName.Text <> "" Then
            If lstFrameNames.Items.Contains(txtFrameName.Text) = False Then
                lstFrameNames.Items.Add(txtFrameName.Text)
                txtFrameName.Text = ""
            End If
        End If
        UpdateOKButtons()
    End Sub

    Private Sub cmdDeleteFrame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDeleteFrame.Click
        If lstFrameNames.SelectedItems.Count = 1 Then
            lstFrameNames.Items.Remove(lstFrameNames.SelectedItems(0))
        End If
        UpdateOKButtons()
    End Sub

    Private Sub txtFrameName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFrameName.TextChanged

        If txtFrameName.Text <> "" Then
            cmdAddFrame.Enabled = True
            cmdDeleteFrame.Enabled = False
        Else
            cmdAddFrame.Enabled = False
            cmdDeleteFrame.Enabled = False
        End If

    End Sub
End Class