﻿Option Strict On
Option Explicit On

Imports System.IO
Imports System.Data
Imports System.Collections.Specialized
Imports System.Collections.Generic
Imports System.Runtime.InteropServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.GraphicsInterface
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD
Imports Jacobs.AutoCAD.BatchProcessorPlugin
Imports Jacobs.AutoCAD.Utilities.MathTools
Imports Autodesk.AutoCAD.PlottingServices
Imports Autodesk.AutoCAD.Internal.Reactors
Imports Autodesk.AutoCAD.Runtime
Imports Acadx = Autodesk.AutoCAD.ApplicationServices.Application
Imports ED = Autodesk.AutoCAD.EditorInput.Editor

Public Class PlotByBlock
    Implements BatchPlugin.iBatchPlugin

    Public mSettingsTableName As String = "PLOT Settings"

    <DllImport("Acad.exe", CallingConvention:=CallingConvention.Cdecl, EntryPoint:="acedTrans")>
    Private Shared Function acedTrans(ByVal point As Double(), ByVal fromRb As IntPtr, ByVal toRb As IntPtr, ByVal disp As Integer, ByVal result As Double()) As Integer
    End Function

    Private mResultMessage As String = ""
    Private mHasSettingsDialog As Boolean = True

    Public Class Blk2Plt
        Public BlkIndexNumber As Integer = 0
        Public BlockRef As BlockReference
        Public LayoutObj As Layout
        Public DrawingNo As String = ""
        Public DrawingRevNo As String = ""
        Public FromBlocksElseFrames As Boolean
        Public FrameReference As Integer = 0
        Public PosDrawingNo As Point3d
        Public PosDrawingRevNo As Point3d
        Public BlkExtents As Extents3d
    End Class

    Private msgs As New List(Of String)()

    Public ReadOnly Property ResultMessage() As String Implements BatchPlugin.iBatchPlugin.ResultMessage
        Get
            Return mResultMessage
        End Get
    End Property

    Public ReadOnly Property HasSettingsDialog() As Boolean Implements BatchPlugin.iBatchPlugin.HasSettingsDialog
        Get
            Return mHasSettingsDialog
        End Get
    End Property

    'The Command Method is just for Testing.  RunProcess Will Be called from BacthProcessor
    Public Sub RunProcess(Optional ByVal SettingsFilePath As String = "") Implements BatchPlugin.iBatchPlugin.RunProcess

        'Read XML File into Datase
        Dim FStream As FileStream
        Dim TempDS As New DataSet
        Dim ContinueFlag As Boolean = True
        Dim PlotSucessfullyInMainTry As Boolean = False
        Dim XMLFileToRead As String = ""

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim EDx As Editor = Doc.Editor

        Try

            If SettingsFilePath <> "" Then
                XMLFileToRead = SettingsFilePath.Replace(".dll", ".xml")
            Else
                ContinueFlag = False
            End If

        Catch ex As Exception
            mResultMessage = "XML Failed TO Read from : " & XMLFileToRead
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            Try

                FStream = New FileStream(XMLFileToRead, FileMode.Open)

                TempDS.ReadXml(FStream)

                FStream.Close()

                If TempDS.Tables.Count > 0 Then

                    Dim SettingsRow As DataRow = TempDS.Tables(0).Rows(0)

                    Application.SetSystemVariable("BACKGROUNDPLOT", 0)
                    Using DokLock As DocumentLock = Doc.LockDocument

                        Using tr As Transaction = Application.DocumentManager.MdiActiveDocument.TransactionManager.StartTransaction()

                            Try

                                Dim PlotDic As DBDictionary = DirectCast(Doc.Database.PlotSettingsDictionaryId.GetObject(OpenMode.ForRead), DBDictionary)
                                Dim PageSetupName As String = SettingsRow.Item("PAGESETUP").ToString
                                Dim FramesStr As String = SettingsRow.Item("FRAMES").ToString.ToUpper
                                Dim BlockNameStr As String = SettingsRow.Item("BLOCKNAMES").ToString.ToUpper
                                Dim BlockRevAtt As String = SettingsRow.Item("DWGREVATT").ToString.ToUpper
                                Dim BlockNumberAtt As String = SettingsRow.Item("DWGNUMBERATT").ToString.ToUpper
                                Dim OutPath As String = SettingsRow.Item("OUTPUTPATH").ToString.ToUpper

                                If OutPath.EndsWith("\") = False Then OutPath += "\"

                                If PlotDic.Contains(PageSetupName) Then

                                    Dim PlotSettingsOBJ As PlotSettings = DirectCast(PlotDic.GetAt(PageSetupName).GetObject(OpenMode.ForRead), PlotSettings)

                                    Dim BlkNames() As String = BlockNameStr.Split(","c)
                                    Dim Frames() As String = FramesStr.Split(","c)

                                    'True result if a sucessful Plot
                                    PlotSucessfullyInMainTry = PlotBlockColToPageSetup(Frames, BlkNames, PlotSettingsOBJ, BlockNumberAtt, BlockRevAtt, OutPath, mResultMessage)

                                    'If PlotSucessfullyInMainTry = False Then
                                    '    mResultMessage += "Plot Function Falied" & vbCrLf
                                    'End If

                                Else

                                    PlotSucessfullyInMainTry = False
                                    mResultMessage += "No Pages Setup Found (" & PageSetupName & ")" & vbCrLf
                                    mResultMessage += "Found Page Setup in " & Doc.Name & " are:" & vbCrLf
                                    For Each plotDictEntry As DBDictionaryEntry In PlotDic
                                        Dim np As PlotSettings = DirectCast(tr.GetObject(plotDictEntry.Value, OpenMode.ForRead), PlotSettings)
                                        mResultMessage += np.PlotSettingsName & vbCrLf
                                    Next

                                End If

                                tr.Commit()

                            Catch ex As System.Exception

                                PlotSucessfullyInMainTry = False
                                mResultMessage += ex.Message & vbCrLf

                            End Try

                        End Using

                    End Using

                End If

            Catch ex As Exception

                PlotSucessfullyInMainTry = False
                mResultMessage += ex.ToString & vbCrLf

            Finally

                TempDS = Nothing
                FStream = Nothing

                If PlotSucessfullyInMainTry = True Then
                    mResultMessage += "Plot By Block Sucessfully Completed!"
                Else
                    mResultMessage += "Plot By Block Failed!"
                End If

            End Try

        End If

    End Sub

    Public Sub Settings(Optional ByVal SettingsFilePath As String = "") Implements iBatchPlugin.ShowSettingsDialog

        Dim ContinueFlag As Boolean = False
        Dim XMLFileToRead As String = ""

        Dim MyForm As New PlotByBlockForm

        Try
            If SettingsFilePath <> "" Then
                XMLFileToRead = SettingsFilePath.Replace(".dll", ".xml")
                If File.Exists(XMLFileToRead) = False Then
                    Dim NewDS As New DataSet
                    NewDS.Tables.Add(MyForm.CreateEmptyDataTable)
                    NewDS.AcceptChanges()
                    MyForm.DS = NewDS
                    MyForm.SaveXML(mSettingsTableName, XMLFileToRead)
                    ContinueFlag = True
                Else
                    ContinueFlag = True
                End If
            Else
                ContinueFlag = False
            End If
        Catch ex As Exception
            mResultMessage = "XML Failed TO Read from : " & XMLFileToRead
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            MyForm.FilePath = SettingsFilePath
            MyForm.ShowDialog()

        End If

        MyForm = Nothing

    End Sub

    Private Shared Function EffectiveName(ByVal blkref As BlockReference) As String
        If blkref.IsDynamicBlock Then
            Using obj As BlockTableRecord = DirectCast(blkref.DynamicBlockTableRecord.GetObject(OpenMode.ForRead), BlockTableRecord)
                Return obj.Name
            End Using
        End If
        Return blkref.Name
    End Function

    Private Shared Sub GetBlocksToPlotCollection(ByVal db As Database, ByVal ed As Editor, ByVal tr As Transaction, ByVal BlockName() As String,
                                                 ByVal Frames() As String,
                                                 ByVal DrawingNoAtt As String, ByVal DrawingRevAtt As String, ByRef BlockCol As List(Of Blk2Plt),
                                                 ByRef RetMessage As String)

        Dim blkRefNoInt As Integer = 1

        Dim bt As BlockTable = DirectCast(tr.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)
        For Each btrId As ObjectId In bt
            Dim btr As BlockTableRecord = DirectCast(tr.GetObject(btrId, OpenMode.ForRead), BlockTableRecord)
            If btr.IsLayout Then
                Dim lo As Layout = DirectCast(tr.GetObject(btr.LayoutId, OpenMode.ForRead), Layout)
                Dim ms As BlockTableRecord = DirectCast(tr.GetObject(lo.BlockTableRecordId, OpenMode.ForRead), BlockTableRecord)
                For Each objId As ObjectId In ms

                    Dim ent As Entity = Nothing
                    Dim blk As BlockReference = Nothing

                    Try
                        'Do Checks a balances from ObjectID, Continue For is incorrect
                        If objId.IsNull Or objId.IsErased Then Continue For
                        If objId.ObjectClass <> RXClass.GetClass(GetType(BlockReference)) Then Continue For

                        'Get the Ent from the Object ID
                        ent = DirectCast(tr.GetObject(objId, OpenMode.ForRead), Entity)
                        If ent Is Nothing Then
                            Continue For
                        End If

                        'get block reference from Ent, Continue for if there are any errors
                        blk = TryCast(ent, BlockReference)
                        If blk Is Nothing Then
                            Continue For
                        End If

                        If blk.IsDisposed Or blk.IsErased Then
                            Continue For
                        End If

                        'Get Actual Name of BlockReference Incase its a Dynamic Block that has been edited
                        Dim Effn As String = EffectiveName(blk)
                        If (Not BlockName.Contains(Effn.ToUpper)) AndAlso (Not Frames.Contains(Effn.ToUpper)) Then
                            Continue For
                        End If


                        'Store Data For Plotting
                        Dim theBlk As New Blk2Plt()
                        theBlk.BlkIndexNumber = blkRefNoInt
                        theBlk.BlockRef = blk
                        theBlk.BlkExtents = blk.GeometricExtents
                        theBlk.LayoutObj = lo
                        theBlk.DrawingNo = "NoDrawningNo"
                        theBlk.DrawingRevNo = blk.Handle.ToString
                        theBlk.FromBlocksElseFrames = BlockName.Contains(Effn.ToUpper)

                        If theBlk.FromBlocksElseFrames = True Then

                            Dim AttCol As AttributeCollection = blk.AttributeCollection

                            For Each AttOID As ObjectId In AttCol

                                Dim AttDef As AttributeReference = DirectCast(tr.GetObject(AttOID, OpenMode.ForRead), AttributeReference)

                                Select Case AttDef.Tag.ToUpper
                                    Case DrawingNoAtt
                                        theBlk.DrawingNo = AttDef.TextString
                                        theBlk.PosDrawingNo = AttDef.Position
                                    Case DrawingRevAtt
                                        theBlk.DrawingRevNo = AttDef.TextString
                                        theBlk.PosDrawingRevNo = AttDef.Position
                                End Select
                            Next

                            RetMessage += Effn & " Found in Layout: " & lo.LayoutName & ", With Attribute Values of:" & vbCrLf &
                                "Drawing Number: " & theBlk.DrawingNo.ToString & vbCrLf &
                                "Drawing Rev: " & theBlk.DrawingRevNo.ToString & vbCrLf

                        End If

                        BlockCol.Add(theBlk)

                        blkRefNoInt += 1

                    Catch ex As Exception
                        RetMessage += "Error on Object Handle: " & objId.Handle.ToString & vbCrLf & "Continuing Function" & vbCrLf &
                            "************ SUGGEST AUIDT on This File************" & vbCrLf &
                            "Error Code: " & ex.Message & vbCrLf
                        'Continue For
                    End Try

                    'blk = Nothing
                    'ent = Nothing

                Next

            End If

        Next

        'Search Complete now to match up Attributebute Block with Extents Blocks

        'Step thru each block
        For Index As Integer = 0 To BlockCol.Count - 1

            Dim TestItem As Blk2Plt = BlockCol.Item(Index)

            'Is this block found a Attribute block and has it got no reference to an Frame block
            If TestItem.FromBlocksElseFrames = True And TestItem.FrameReference = 0 Then

                'Start Search Blocks
                For SubSearchIndex As Integer = 0 To BlockCol.Count - 1

                    'Check to make suer the index numbers are not the same
                    If SubSearchIndex <> Index Then

                        'Get Class Object
                        Dim SearchItem As Blk2Plt = BlockCol.Item(SubSearchIndex)

                        'if its a frame blocks
                        If SearchItem.FromBlocksElseFrames = False Then

                            'if the TestItem Drawing Number Attribute Position inside the Frame Block Extents
                            If IsPointInside(TestItem.PosDrawingNo, SearchItem.BlkExtents) Then

                                'Set Reference and exit current for loop
                                TestItem.FrameReference = SearchItem.BlkIndexNumber
                                TestItem.BlockRef = SearchItem.BlockRef
                                TestItem.BlkExtents = SearchItem.BlkExtents
                                Exit For

                            End If

                        End If

                    End If


                Next

            End If

        Next

    End Sub

    Private Shared Function PlotBlockColToPageSetup(ByVal FrameNames() As String, ByVal BlockNames() As String, ByVal PltSets As PlotSettings,
                                               ByVal DrawingNoAtt As String, ByVal DrawingRevAtt As String,
                                               ByVal OutPutPath As String, ByRef RetMessages As String) As Boolean

        Dim Ret As Boolean = False

        Dim doc As Document = Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = doc.Editor
        Dim db As Database = doc.Database
        Dim tr As Transaction = db.TransactionManager.StartTransaction()
        Dim SysVarBackPlot As Object = Application.GetSystemVariable("BACKGROUNDPLOT")
        Application.SetSystemVariable("BACKGROUNDPLOT", 0)

        Using DocLok As DocumentLock = doc.LockDocument

            Using tr

                Dim BlocksToPlot As New List(Of Blk2Plt)

                GetBlocksToPlotCollection(db, ed, tr, BlockNames, FrameNames, DrawingNoAtt, DrawingRevAtt, BlocksToPlot, RetMessages)

                If BlocksToPlot.Count < 1 Then
                    Return False
                End If

                If PlotFactory.ProcessPlotState = ProcessPlotState.NotPlotting Then

                    For Each gblk As Blk2Plt In BlocksToPlot

                        Dim PlotInError As Boolean = False

                        Try

                            If gblk.FromBlocksElseFrames = False AndAlso gblk.FrameReference = 0 Then
                                PlotInError = True
                                Continue For
                            End If

                            Dim acPlEng As PlotEngine = PlotFactory.CreatePublishEngine()
                            Using acPlEng

                                Dim numSheet As Integer = 1

                                acPlEng.BeginPlot(Nothing, Nothing)

                                Dim piv As New PlotInfoValidator()
                                piv.MediaMatchingPolicy = MatchingPolicy.MatchEnabled
                                Dim acPlPageInfo As New PlotPageInfo()
                                Dim acPlInfo As New PlotInfo()
                                Dim blk As BlockReference = gblk.BlockRef
                                Dim lo As Layout = gblk.LayoutObj

                                ' Getting coodinates of window to plot
                                Dim ext As Extents3d = blk.GeometricExtents 'DirectCast(blk.GeometricExtents, Extents3d)
                                Dim first As Point3d = ext.MaxPoint
                                Dim second As Point3d = ext.MinPoint
                                Dim rbFrom As New ResultBuffer(New TypedValue(5003, 1)), rbTo As New ResultBuffer(New TypedValue(5003, 2))
                                Dim firres As Double() = New Double() {0, 0, 0}
                                Dim secres As Double() = New Double() {0, 0, 0}
                                acedTrans(first.ToArray(), rbFrom.UnmanagedObject, rbTo.UnmanagedObject, 0, firres)
                                acedTrans(second.ToArray(), rbFrom.UnmanagedObject, rbTo.UnmanagedObject, 0, secres)
                                Dim window As New Extents2d(secres(0), secres(1), firres(0), firres(1))

                                ' We need a PlotSettings object based on the layout Settings which we then customize
                                Dim ps As New PlotSettings(lo.ModelType)
                                LayoutManager.Current.CurrentLayout = lo.LayoutName
                                acPlInfo.Layout = lo.Id
                                ps.CopyFrom(lo)
                                ps.PlotSettingsName = PltSets.PlotSettingsName

                                ' The PlotSettingsValidator helps create a valid PlotSettings object
                                Dim psv As PlotSettingsValidator = PlotSettingsValidator.Current
                                psv.SetPlotWindowArea(ps, window)
                                psv.SetPlotType(ps, Autodesk.AutoCAD.DatabaseServices.PlotType.Window)
                                psv.SetUseStandardScale(ps, PltSets.UseStandardScale)
                                psv.SetPlotCentered(ps, PltSets.PlotCentered)
                                psv.SetStdScaleType(ps, StdScaleType.ScaleToFit)
                                psv.SetPlotRotation(ps, PltSets.PlotRotation)

                                psv.SetPlotConfigurationName(ps, PltSets.PlotConfigurationName,
                                                        PltSets.CanonicalMediaName)
                                acPlInfo.OverrideSettings = ps
                                piv.Validate(acPlInfo)

                                'If numSheet = 1 Then
                                acPlEng.BeginDocument(acPlInfo, doc.Name, Nothing, 1, True, OutPutPath & gblk.DrawingNo & "-" & gblk.DrawingRevNo)
                                'End If
                                ' Create document for the first page
                                ' Plot the window
                                acPlEng.BeginPage(acPlPageInfo, acPlInfo, True, Nothing)
                                acPlEng.BeginGenerateGraphics(Nothing)
                                acPlEng.EndGenerateGraphics(Nothing)

                                ' Finish the sheet
                                acPlEng.EndPage(Nothing)
                                numSheet += 1

                                ' Finish the document and finish the plot
                                acPlEng.EndDocument(Nothing)
                                acPlEng.EndPlot(Nothing)
                                'ed.WriteMessage(vbLf & "Plot completed successfully!" & vbLf & vbLf)
                                RetMessages += "Plot completed to " & OutPutPath & gblk.DrawingNo & "-" & gblk.DrawingRevNo & vbCrLf

                            End Using

                        Catch ex As Exception

                            RetMessages += "Plotting Failed while Plotting: " & gblk.BlockRef.Name & " in Layout: " & gblk.LayoutObj.LayoutName & vbCrLf & ex.Message & vbCrLf
                            PlotInError = True

                        Finally

                            If PlotInError = False Then
                                RetMessages += "Plotting Sucessfull: " & gblk.BlockRef.Name & " in Layout: " & gblk.LayoutObj.LayoutName & vbCrLf
                            End If

                        End Try

                        'reset variablefor next plot
                        PlotInError = False


                    Next 'Loop for next plot

                    Ret = True

                Else
                    RetMessages += "Another plot is in progress." & vbCrLf
                End If

                tr.Commit()

            End Using

        End Using

        Application.SetSystemVariable("BACKGROUNDPLOT", SysVarBackPlot)

        Return Ret

    End Function

End Class
