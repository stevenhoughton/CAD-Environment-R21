﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PlotByBlockForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PlotByBlockForm))
        Me.pnlButtons = New System.Windows.Forms.Panel()
        Me.cmdSaveSettings = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.gbxPageSetup = New System.Windows.Forms.GroupBox()
        Me.txtPageSetup = New System.Windows.Forms.TextBox()
        Me.gbxTitleBlockDetails = New System.Windows.Forms.GroupBox()
        Me.txtDrawingRevAtt = New System.Windows.Forms.TextBox()
        Me.lblDrawingRevAtt = New System.Windows.Forms.Label()
        Me.txtDrawingNoAtt = New System.Windows.Forms.TextBox()
        Me.lblDrawingNoAtt = New System.Windows.Forms.Label()
        Me.pnlBlocks = New System.Windows.Forms.Panel()
        Me.lstBlockNames = New System.Windows.Forms.ListBox()
        Me.txtNewBlockName = New System.Windows.Forms.TextBox()
        Me.lblBlockNames = New System.Windows.Forms.Label()
        Me.pnlSelectedScriptsTools = New System.Windows.Forms.Panel()
        Me.cmdRemove = New System.Windows.Forms.Button()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.gbxOutPut = New System.Windows.Forms.GroupBox()
        Me.cmdBrowse = New System.Windows.Forms.Button()
        Me.txtOutPutPath = New System.Windows.Forms.TextBox()
        Me.gbxDrawingBorderFrames = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lstFrameNames = New System.Windows.Forms.ListBox()
        Me.txtFrameName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cmdDeleteFrame = New System.Windows.Forms.Button()
        Me.cmdAddFrame = New System.Windows.Forms.Button()
        Me.pnlButtons.SuspendLayout()
        Me.gbxPageSetup.SuspendLayout()
        Me.gbxTitleBlockDetails.SuspendLayout()
        Me.pnlBlocks.SuspendLayout()
        Me.pnlSelectedScriptsTools.SuspendLayout()
        Me.gbxOutPut.SuspendLayout()
        Me.gbxDrawingBorderFrames.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlButtons
        '
        Me.pnlButtons.Controls.Add(Me.cmdSaveSettings)
        Me.pnlButtons.Controls.Add(Me.cmdCancel)
        Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtons.Location = New System.Drawing.Point(0, 631)
        Me.pnlButtons.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlButtons.MaximumSize = New System.Drawing.Size(0, 57)
        Me.pnlButtons.MinimumSize = New System.Drawing.Size(0, 57)
        Me.pnlButtons.Name = "pnlButtons"
        Me.pnlButtons.Size = New System.Drawing.Size(611, 57)
        Me.pnlButtons.TabIndex = 2
        '
        'cmdSaveSettings
        '
        Me.cmdSaveSettings.Location = New System.Drawing.Point(383, 14)
        Me.cmdSaveSettings.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdSaveSettings.Name = "cmdSaveSettings"
        Me.cmdSaveSettings.Size = New System.Drawing.Size(100, 28)
        Me.cmdSaveSettings.TabIndex = 3
        Me.cmdSaveSettings.Text = "Save"
        Me.cmdSaveSettings.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(491, 14)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(100, 28)
        Me.cmdCancel.TabIndex = 2
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'gbxPageSetup
        '
        Me.gbxPageSetup.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxPageSetup.Controls.Add(Me.txtPageSetup)
        Me.gbxPageSetup.Location = New System.Drawing.Point(20, 6)
        Me.gbxPageSetup.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxPageSetup.Name = "gbxPageSetup"
        Me.gbxPageSetup.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxPageSetup.Size = New System.Drawing.Size(571, 68)
        Me.gbxPageSetup.TabIndex = 9
        Me.gbxPageSetup.TabStop = False
        Me.gbxPageSetup.Text = "Page Setup"
        '
        'txtPageSetup
        '
        Me.txtPageSetup.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPageSetup.Location = New System.Drawing.Point(17, 23)
        Me.txtPageSetup.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtPageSetup.Name = "txtPageSetup"
        Me.txtPageSetup.Size = New System.Drawing.Size(529, 22)
        Me.txtPageSetup.TabIndex = 5
        '
        'gbxTitleBlockDetails
        '
        Me.gbxTitleBlockDetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxTitleBlockDetails.Controls.Add(Me.txtDrawingRevAtt)
        Me.gbxTitleBlockDetails.Controls.Add(Me.lblDrawingRevAtt)
        Me.gbxTitleBlockDetails.Controls.Add(Me.txtDrawingNoAtt)
        Me.gbxTitleBlockDetails.Controls.Add(Me.lblDrawingNoAtt)
        Me.gbxTitleBlockDetails.Controls.Add(Me.pnlBlocks)
        Me.gbxTitleBlockDetails.Location = New System.Drawing.Point(20, 267)
        Me.gbxTitleBlockDetails.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxTitleBlockDetails.Name = "gbxTitleBlockDetails"
        Me.gbxTitleBlockDetails.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxTitleBlockDetails.Size = New System.Drawing.Size(571, 281)
        Me.gbxTitleBlockDetails.TabIndex = 10
        Me.gbxTitleBlockDetails.TabStop = False
        Me.gbxTitleBlockDetails.Text = "Title Block Details (File Name Parameters)"
        '
        'txtDrawingRevAtt
        '
        Me.txtDrawingRevAtt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDrawingRevAtt.Location = New System.Drawing.Point(17, 235)
        Me.txtDrawingRevAtt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDrawingRevAtt.Name = "txtDrawingRevAtt"
        Me.txtDrawingRevAtt.Size = New System.Drawing.Size(529, 22)
        Me.txtDrawingRevAtt.TabIndex = 16
        '
        'lblDrawingRevAtt
        '
        Me.lblDrawingRevAtt.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblDrawingRevAtt.AutoSize = True
        Me.lblDrawingRevAtt.Location = New System.Drawing.Point(17, 215)
        Me.lblDrawingRevAtt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDrawingRevAtt.Name = "lblDrawingRevAtt"
        Me.lblDrawingRevAtt.Size = New System.Drawing.Size(174, 17)
        Me.lblDrawingRevAtt.TabIndex = 15
        Me.lblDrawingRevAtt.Text = "Drawing Revision Attribute"
        '
        'txtDrawingNoAtt
        '
        Me.txtDrawingNoAtt.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtDrawingNoAtt.Location = New System.Drawing.Point(17, 187)
        Me.txtDrawingNoAtt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDrawingNoAtt.Name = "txtDrawingNoAtt"
        Me.txtDrawingNoAtt.Size = New System.Drawing.Size(529, 22)
        Me.txtDrawingNoAtt.TabIndex = 14
        '
        'lblDrawingNoAtt
        '
        Me.lblDrawingNoAtt.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblDrawingNoAtt.AutoSize = True
        Me.lblDrawingNoAtt.Location = New System.Drawing.Point(17, 167)
        Me.lblDrawingNoAtt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDrawingNoAtt.Name = "lblDrawingNoAtt"
        Me.lblDrawingNoAtt.Size = New System.Drawing.Size(170, 17)
        Me.lblDrawingNoAtt.TabIndex = 13
        Me.lblDrawingNoAtt.Text = "Drawing Number Attribute"
        '
        'pnlBlocks
        '
        Me.pnlBlocks.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlBlocks.Controls.Add(Me.lstBlockNames)
        Me.pnlBlocks.Controls.Add(Me.txtNewBlockName)
        Me.pnlBlocks.Controls.Add(Me.lblBlockNames)
        Me.pnlBlocks.Controls.Add(Me.pnlSelectedScriptsTools)
        Me.pnlBlocks.Location = New System.Drawing.Point(13, 31)
        Me.pnlBlocks.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlBlocks.Name = "pnlBlocks"
        Me.pnlBlocks.Padding = New System.Windows.Forms.Padding(4, 4, 0, 4)
        Me.pnlBlocks.Size = New System.Drawing.Size(535, 133)
        Me.pnlBlocks.TabIndex = 12
        '
        'lstBlockNames
        '
        Me.lstBlockNames.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstBlockNames.FormattingEnabled = True
        Me.lstBlockNames.ItemHeight = 16
        Me.lstBlockNames.Location = New System.Drawing.Point(4, 43)
        Me.lstBlockNames.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.lstBlockNames.Name = "lstBlockNames"
        Me.lstBlockNames.Size = New System.Drawing.Size(482, 86)
        Me.lstBlockNames.TabIndex = 10
        '
        'txtNewBlockName
        '
        Me.txtNewBlockName.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtNewBlockName.Location = New System.Drawing.Point(4, 21)
        Me.txtNewBlockName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtNewBlockName.Name = "txtNewBlockName"
        Me.txtNewBlockName.Size = New System.Drawing.Size(482, 22)
        Me.txtNewBlockName.TabIndex = 9
        '
        'lblBlockNames
        '
        Me.lblBlockNames.AutoSize = True
        Me.lblBlockNames.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblBlockNames.Location = New System.Drawing.Point(4, 4)
        Me.lblBlockNames.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblBlockNames.Name = "lblBlockNames"
        Me.lblBlockNames.Size = New System.Drawing.Size(412, 17)
        Me.lblBlockNames.TabIndex = 8
        Me.lblBlockNames.Text = "Drawing Sheet Block Names To Select Following Attributes From"
        '
        'pnlSelectedScriptsTools
        '
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdRemove)
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdAdd)
        Me.pnlSelectedScriptsTools.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlSelectedScriptsTools.Location = New System.Drawing.Point(486, 4)
        Me.pnlSelectedScriptsTools.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlSelectedScriptsTools.MaximumSize = New System.Drawing.Size(49, 0)
        Me.pnlSelectedScriptsTools.MinimumSize = New System.Drawing.Size(49, 0)
        Me.pnlSelectedScriptsTools.Name = "pnlSelectedScriptsTools"
        Me.pnlSelectedScriptsTools.Padding = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.pnlSelectedScriptsTools.Size = New System.Drawing.Size(49, 125)
        Me.pnlSelectedScriptsTools.TabIndex = 7
        '
        'cmdRemove
        '
        Me.cmdRemove.Dock = System.Windows.Forms.DockStyle.Top
        Me.cmdRemove.Enabled = False
        Me.cmdRemove.Font = New System.Drawing.Font("Wingdings", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdRemove.Location = New System.Drawing.Point(5, 36)
        Me.cmdRemove.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdRemove.Name = "cmdRemove"
        Me.cmdRemove.Size = New System.Drawing.Size(39, 36)
        Me.cmdRemove.TabIndex = 22
        Me.cmdRemove.Text = "û"
        Me.cmdRemove.UseVisualStyleBackColor = True
        '
        'cmdAdd
        '
        Me.cmdAdd.Dock = System.Windows.Forms.DockStyle.Top
        Me.cmdAdd.Enabled = False
        Me.cmdAdd.Font = New System.Drawing.Font("Wingdings", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdAdd.Location = New System.Drawing.Point(5, 0)
        Me.cmdAdd.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(39, 36)
        Me.cmdAdd.TabIndex = 17
        Me.cmdAdd.Text = "ü"
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'gbxOutPut
        '
        Me.gbxOutPut.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxOutPut.Controls.Add(Me.cmdBrowse)
        Me.gbxOutPut.Controls.Add(Me.txtOutPutPath)
        Me.gbxOutPut.Location = New System.Drawing.Point(20, 555)
        Me.gbxOutPut.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxOutPut.Name = "gbxOutPut"
        Me.gbxOutPut.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxOutPut.Size = New System.Drawing.Size(571, 73)
        Me.gbxOutPut.TabIndex = 11
        Me.gbxOutPut.TabStop = False
        Me.gbxOutPut.Text = "PDF Output Path"
        '
        'cmdBrowse
        '
        Me.cmdBrowse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdBrowse.Location = New System.Drawing.Point(467, 23)
        Me.cmdBrowse.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdBrowse.Name = "cmdBrowse"
        Me.cmdBrowse.Size = New System.Drawing.Size(81, 28)
        Me.cmdBrowse.TabIndex = 10
        Me.cmdBrowse.Text = "Browse..."
        Me.cmdBrowse.UseVisualStyleBackColor = True
        '
        'txtOutPutPath
        '
        Me.txtOutPutPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtOutPutPath.Location = New System.Drawing.Point(17, 26)
        Me.txtOutPutPath.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtOutPutPath.Name = "txtOutPutPath"
        Me.txtOutPutPath.Size = New System.Drawing.Size(440, 22)
        Me.txtOutPutPath.TabIndex = 9
        '
        'gbxDrawingBorderFrames
        '
        Me.gbxDrawingBorderFrames.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxDrawingBorderFrames.Controls.Add(Me.Panel1)
        Me.gbxDrawingBorderFrames.Location = New System.Drawing.Point(20, 81)
        Me.gbxDrawingBorderFrames.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxDrawingBorderFrames.Name = "gbxDrawingBorderFrames"
        Me.gbxDrawingBorderFrames.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbxDrawingBorderFrames.Size = New System.Drawing.Size(571, 178)
        Me.gbxDrawingBorderFrames.TabIndex = 12
        Me.gbxDrawingBorderFrames.TabStop = False
        Me.gbxDrawingBorderFrames.Text = "Drawing Border Frame"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.lstFrameNames)
        Me.Panel1.Controls.Add(Me.txtFrameName)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(19, 23)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Padding = New System.Windows.Forms.Padding(4, 4, 0, 4)
        Me.Panel1.Size = New System.Drawing.Size(535, 145)
        Me.Panel1.TabIndex = 13
        '
        'lstFrameNames
        '
        Me.lstFrameNames.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstFrameNames.FormattingEnabled = True
        Me.lstFrameNames.ItemHeight = 16
        Me.lstFrameNames.Location = New System.Drawing.Point(4, 43)
        Me.lstFrameNames.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.lstFrameNames.Name = "lstFrameNames"
        Me.lstFrameNames.Size = New System.Drawing.Size(482, 98)
        Me.lstFrameNames.TabIndex = 10
        '
        'txtFrameName
        '
        Me.txtFrameName.Dock = System.Windows.Forms.DockStyle.Top
        Me.txtFrameName.Location = New System.Drawing.Point(4, 21)
        Me.txtFrameName.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtFrameName.Name = "txtFrameName"
        Me.txtFrameName.Size = New System.Drawing.Size(482, 22)
        Me.txtFrameName.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Location = New System.Drawing.Point(4, 4)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(393, 17)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Drawing Sheet Block Used to Find Extejnts For Plot Boundary"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cmdDeleteFrame)
        Me.Panel2.Controls.Add(Me.cmdAddFrame)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(486, 4)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel2.MaximumSize = New System.Drawing.Size(49, 0)
        Me.Panel2.MinimumSize = New System.Drawing.Size(49, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Padding = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Panel2.Size = New System.Drawing.Size(49, 137)
        Me.Panel2.TabIndex = 7
        '
        'cmdDeleteFrame
        '
        Me.cmdDeleteFrame.Dock = System.Windows.Forms.DockStyle.Top
        Me.cmdDeleteFrame.Enabled = False
        Me.cmdDeleteFrame.Font = New System.Drawing.Font("Wingdings", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdDeleteFrame.Location = New System.Drawing.Point(5, 36)
        Me.cmdDeleteFrame.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdDeleteFrame.Name = "cmdDeleteFrame"
        Me.cmdDeleteFrame.Size = New System.Drawing.Size(39, 36)
        Me.cmdDeleteFrame.TabIndex = 22
        Me.cmdDeleteFrame.Text = "û"
        Me.cmdDeleteFrame.UseVisualStyleBackColor = True
        '
        'cmdAddFrame
        '
        Me.cmdAddFrame.Dock = System.Windows.Forms.DockStyle.Top
        Me.cmdAddFrame.Enabled = False
        Me.cmdAddFrame.Font = New System.Drawing.Font("Wingdings", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdAddFrame.Location = New System.Drawing.Point(5, 0)
        Me.cmdAddFrame.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdAddFrame.Name = "cmdAddFrame"
        Me.cmdAddFrame.Size = New System.Drawing.Size(39, 36)
        Me.cmdAddFrame.TabIndex = 17
        Me.cmdAddFrame.Text = "ü"
        Me.cmdAddFrame.UseVisualStyleBackColor = True
        '
        'PlotByBlockForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(611, 688)
        Me.Controls.Add(Me.gbxDrawingBorderFrames)
        Me.Controls.Add(Me.gbxOutPut)
        Me.Controls.Add(Me.gbxTitleBlockDetails)
        Me.Controls.Add(Me.gbxPageSetup)
        Me.Controls.Add(Me.pnlButtons)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximumSize = New System.Drawing.Size(629, 733)
        Me.MinimumSize = New System.Drawing.Size(629, 733)
        Me.Name = "PlotByBlockForm"
        Me.Text = "Plot By Block Settings"
        Me.pnlButtons.ResumeLayout(False)
        Me.gbxPageSetup.ResumeLayout(False)
        Me.gbxPageSetup.PerformLayout()
        Me.gbxTitleBlockDetails.ResumeLayout(False)
        Me.gbxTitleBlockDetails.PerformLayout()
        Me.pnlBlocks.ResumeLayout(False)
        Me.pnlBlocks.PerformLayout()
        Me.pnlSelectedScriptsTools.ResumeLayout(False)
        Me.gbxOutPut.ResumeLayout(False)
        Me.gbxOutPut.PerformLayout()
        Me.gbxDrawingBorderFrames.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlButtons As System.Windows.Forms.Panel
    Friend WithEvents cmdSaveSettings As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents gbxPageSetup As System.Windows.Forms.GroupBox
    Friend WithEvents txtPageSetup As System.Windows.Forms.TextBox
    Friend WithEvents gbxTitleBlockDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtDrawingRevAtt As System.Windows.Forms.TextBox
    Friend WithEvents lblDrawingRevAtt As System.Windows.Forms.Label
    Friend WithEvents txtDrawingNoAtt As System.Windows.Forms.TextBox
    Friend WithEvents lblDrawingNoAtt As System.Windows.Forms.Label
    Friend WithEvents pnlBlocks As System.Windows.Forms.Panel
    Friend WithEvents lstBlockNames As System.Windows.Forms.ListBox
    Friend WithEvents txtNewBlockName As System.Windows.Forms.TextBox
    Friend WithEvents lblBlockNames As System.Windows.Forms.Label
    Friend WithEvents pnlSelectedScriptsTools As System.Windows.Forms.Panel
    Friend WithEvents cmdRemove As System.Windows.Forms.Button
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents gbxOutPut As System.Windows.Forms.GroupBox
    Friend WithEvents cmdBrowse As System.Windows.Forms.Button
    Friend WithEvents txtOutPutPath As System.Windows.Forms.TextBox
    Friend WithEvents gbxDrawingBorderFrames As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lstFrameNames As System.Windows.Forms.ListBox
    Friend WithEvents txtFrameName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cmdDeleteFrame As System.Windows.Forms.Button
    Friend WithEvents cmdAddFrame As System.Windows.Forms.Button
End Class
