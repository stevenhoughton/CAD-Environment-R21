﻿' (C) Copyright 2013 by Sinclair Knight Merz 
'
Imports System
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.Common.Settings

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.LayerImporter.LayerImporterMain))> 

' This class is instantiated by AutoCAD for each document when
' a command is called by the user the first time in the context
' of a given document. In other words, non static data in this class
' is implicitly per-document!
Public Class LayerImporterMain

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    ' The CommandMethod attribute can be applied to any public  member 
    ' function of any public class.
    ' The function should take no arguments and return nothing.
    ' If the method is an instance member then the enclosing class is 
    ' instantiated for each document. If the member is a static member then
    ' the enclosing class is NOT instantiated.
    '
    ' NOTE: CommandMethod has overloads where you can provide help id and
    ' context menu.

    ' Modal Command with localized name
    ' AutoCAD will search for a resource string with Id "MyCommandLocal" in the 
    ' same namespace as this command class. 
    ' If a resource string is not found, then the string "MyLocalCommand" is used 
    ' as the localized command name.
    ' To view/edit the resx file defining the resource strings for this command, 
    ' * click the 'Show All Files' button in the Solution Explorer;
    ' * expand the tree node for myCommands.vb;
    ' * and double click on myCommands.resx
    <CommandMethod("MyGroup", "MyCommand", "MyCommandLocal", CommandFlags.Modal)> _
    Public Sub MyCommand() ' This method can have any name
        ' Put your command code here
    End Sub

    ' Modal Command with pickfirst selection
    <CommandMethod("MyGroup", "MyPickFirst", "MyPickFirstLocal", CType(CommandFlags.Modal + CommandFlags.UsePickSet, CommandFlags))> _
    Public Sub MyPickFirst() ' This method can have any name
        Dim result As PromptSelectionResult = Application.DocumentManager.MdiActiveDocument.Editor.GetSelection()
        If (result.Status = PromptStatus.OK) Then
            ' There are selected entities
            ' Put your command using pickfirst set code here
        Else
            ' There are no selected entities
            ' Put your command code here
        End If
    End Sub

    ' Application Session Command with localized name
    <CommandMethod("MyGroup", "MySessionCmd", "MySessionCmdLocal", CType(CommandFlags.Modal + CommandFlags.Session, CommandFlags))> _
    Public Sub MySessionCmd() ' This method can have any name
        ' Put your command code here
    End Sub

    ' LispFunction is similar to CommandMethod but it creates a lisp 
    ' callable function. Many return types are supported not just string
    ' or integer.
    <LispFunction("MyLispFunction", "MyLispFunctionLocal")> _
    Public Function MyLispFunction(ByVal args As ResultBuffer) As Integer ' This method can have any name
        ' Put your command code here

        ' Return a value to the AutoCAD Lisp Interpreter
        Return 1
    End Function

    ' This allows us to access the AE's Select Configuration dialog and configure the drawing if required.
    Dim SelectConfig As New SelectTemplate.TemplateSelector

    '' Create an instance of the form that we can use
    Dim LayerImporterFormInst As New LayerImporterForm

    ''' <summary>
    ''' Primary command used to kick off the tool.
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_LAYERIMPORTER", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub LayerImporter()

        Try


            '' Check to see if this tool needs to be configured. The flag for this is nominated by the developer and stored in 
            '' HKEY_LOCAL_MACHINE\SOFTWARE\[MANUFACTURER]\[PRODUCTNAME]\Applications\{DLL Name without extension}\MustBeconfigured = True or False
            '' The registry key is created with the installer (don't forget to add it in). Adding a new tool via the DFS will require the a call 
            '' to the Client Selector to add this key for that tool.

            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then

                '' If it needs to be configured as per the reg key and it's not configured then 
                '' Call the generic function to allow user to select a configuration as this DWG is not configured and it needs to be.

                SelectConfig.DisplayWarning()

                '' We gave the user the opportunity to configure the drawing - check that they have done that and not just canceled the 
                '' Select Configuration dialog

                If ThisDrawingIsConfigured() Then

                    '' Present them with the dialog box.
                    Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(LayerImporterFormInst)

                End If

            Else

                '' There either was no need to have a configured drawing (most likely for a tool that does not use rules)
                '' Or the drawing is already configured and ready to go.

                Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(LayerImporterFormInst)

            End If

        Catch ex As System.Exception

            ' Generic exception handling - using reflection to let us know where the error came from.

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

        End Try

    End Sub

End Class

