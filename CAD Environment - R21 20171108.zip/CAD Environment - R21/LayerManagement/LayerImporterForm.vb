﻿Imports System.Windows.Forms
Imports System.IO
Imports System.Data
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports System.Drawing
Imports System.ComponentModel
Imports Jacobs.Common.Settings
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources
Imports Jacobs.AutoCAD.StylesLoader

Public Class LayerImporterForm

    Private Class LayerDets

        Private mLayerName As String = ""
        Public Property LayerName() As String
            Get
                Return mLayerName
            End Get
            Set(ByVal value As String)
                mLayerName = value
            End Set
        End Property

        Public LayerObjectID As ObjectId = ObjectId.Null
        Private mLineTypeName As String = ""
        Public Property LineTypeName() As String
            Get
                Return mLineTypeName
            End Get
            Set(ByVal value As String)
                mLineTypeName = value
            End Set
        End Property

        Public LinetypeObjectID As ObjectId = ObjectId.Null
        Public LineWeightOBJ As LineWeight = LineWeight.ByLayer
        Public Transparency As Autodesk.AutoCAD.Colors.Transparency

        Private mLayerColor As Autodesk.AutoCAD.Colors.Color
        Public WriteOnly Property LayerColor() As Autodesk.AutoCAD.Colors.Color
            Set(ByVal value As Autodesk.AutoCAD.Colors.Color)
                mLayerColor = value
            End Set
        End Property
        Public ReadOnly Property LayerColorObj() As Autodesk.AutoCAD.Colors.Color
            Get
                Return mLayerColor
            End Get
        End Property
        Public ReadOnly Property LayerColorName() As String
            Get
                Return mLayerColor.ColorIndex.ToString
            End Get
        End Property

        Private mDescription As String
        Public Property Description() As String
            Get
                Return mDescription
            End Get
            Set(ByVal value As String)
                mDescription = value
            End Set
        End Property

        Private mIsPlotable As Boolean = False
        Private mIsFrozen As Boolean = False
        Private mIsOff As Boolean = False
        Private mIsLocked As Boolean = False
        Public Property IsPlotAble() As Boolean
            Get
                Return mIsPlotable
            End Get
            Set(ByVal value As Boolean)
                mIsPlotable = value
            End Set
        End Property

        Public Property IsLocked() As Boolean
            Get
                Return mIsLocked
            End Get
            Set(ByVal value As Boolean)
                mIsLocked = value
            End Set
        End Property

        Public Property IsOff() As Boolean
            Get
                Return mIsOff
            End Get
            Set(ByVal value As Boolean)
                mIsOff = value
            End Set
        End Property

        Public Property IsFrozen() As Boolean
            Get
                Return mIsFrozen
            End Get
            Set(ByVal value As Boolean)
                mIsFrozen = value
            End Set
        End Property

        Public IsExistsInCurrentDB As Boolean = False
    End Class

    Private WithEvents LayerBind As BindingSource

    Dim IsInitializing As Boolean = True
    Dim mLayerDetails As New DataSet("LayerFiles")

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        LayerBind = New BindingSource

    End Sub

    Private Sub LayerImporterForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            dgvLayerDetails.AutoGenerateColumns = False

            IsInitializing = True

            '' On Dialog_Load events ensure that the first thing we do is read the Configuration Settings 
            '' So that we have access to everything in the Configuration.XML file.

            GetConfigSettings()

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            '' Assign Global Generic dialog tool tips. Not to be hard coded. Use Global Reference file in Utilities

            ToolTip1.SetToolTip(cmdHelp, UtilitiesMyResources.ToolTipHelp)
            ToolTip1.SetToolTip(cmdCancel, UtilitiesMyResources.ToolTipCancel)

            '' Assign local unique tool tips. Not to be hard coded. Use local reference file

            ToolTip1.SetToolTip(cmdOK, My.Resources.ToolTipOK)
            ToolTip1.SetToolTip(lblTitle, My.Resources.ToolSummary)

            '' RULES Section 1
            '' If any user changes the Template Settings with their own Settings (in other words a user override)
            '' We would have written a Working Variable (WorkVar) indicating that the user had made some changes.
            '' The next line of code checks the rules in this drawing and populates the required fields
            '' It will use the user overrides if the WorkVar is true Else it uses the template rules.
            Dim ConfigSettingsPath As String = String.Empty

            If IsThisAnOldConfigName() = True Then
                ConfigSettingsPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(RuleAccessors.GetruleValue("FullConfigName"), "Support")
            Else
                ConfigSettingsPath = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(RuleAccessors.GetruleValue("FullConfigName").CombinePath("Support"))
            End If

            'Get all DWT and Layer_*.dwg
            mLayerDetails.Tables.Clear()

            mLayerDetails.Tables.Add("DWT_LAYERS")
            mLayerDetails.Tables.Item("DWT_LAYERS").Columns.Add("FULLNAME", GetType(System.String))
            mLayerDetails.Tables.Item("DWT_LAYERS").Columns.Add("DISPLAYNAME", GetType(System.String))

            Dim Tx As System.Data.DataTable = mLayerDetails.Tables("DWT_LAYERS").Clone
            Tx.TableName = "LAYER_FILES"

            mLayerDetails.Tables.Add(Tx)
            mLayerDetails.AcceptChanges()

            If Directory.Exists(ConfigSettingsPath) = True Then

                Dim TemplateFileSearch As IEnumerable(Of String) = Directory.EnumerateFiles(ConfigSettingsPath & "\", RuleAccessors.GetruleValue("FullConfigName") & ".dwg", SearchOption.TopDirectoryOnly)
                Dim Cnt As Integer = 0
                For Each Res As String In TemplateFileSearch

                    If Cnt = 0 Then
                        Dim NR As DataRow = mLayerDetails.Tables.Item("DWT_LAYERS").NewRow
                        NR.Item("FULLNAME") = Res
                        NR.Item("DISPLAYNAME") = Path.GetFileNameWithoutExtension(Res)
                        mLayerDetails.Tables.Item("DWT_LAYERS").Rows.Add(NR)
                        NR = Nothing

                    Else
                        MsgBox("Multiple DWG Found in Template")
                    End If

                Next

                lblDwtName.Text = mLayerDetails.Tables.Item("DWT_LAYERS").Rows(0).Item("FULLNAME").ToString

                mLayerDetails.AcceptChanges()

                Dim LayerFilesSearch As IEnumerable(Of String) = Directory.EnumerateFiles(ConfigSettingsPath & "\", "Layer_*.dwg", SearchOption.TopDirectoryOnly)
                For Each Res As String In LayerFilesSearch
                    Dim NR As DataRow = mLayerDetails.Tables.Item("LAYER_FILES").NewRow
                    NR.Item("FULLNAME") = Res
                    NR.Item("DISPLAYNAME") = Path.GetFileNameWithoutExtension(Res)
                    mLayerDetails.Tables.Item("LAYER_FILES").Rows.Add(NR)
                    NR = Nothing
                Next

                mLayerDetails.AcceptChanges()

            End If

            If mLayerDetails.Tables.Item("DWT_LAYERS").Rows.Count = 0 Then
                Dim NR As DataRow = mLayerDetails.Tables.Item("DWT_LAYERS").NewRow
                NR.Item("FULLNAME") = "No DWT Files found"
                NR.Item("DISPLAYNAME") = "No DWT Files found"
                mLayerDetails.Tables.Item("DWT_LAYERS").Rows.Add(NR)
                NR = Nothing

                cboLayerFiles.Enabled = False
                lblDwtName.Text = "No Template Found"
                mLayerDetails.AcceptChanges()
            End If

            If mLayerDetails.Tables.Item("LAYER_FILES").Rows.Count = 0 Then
                Dim NR As DataRow = mLayerDetails.Tables.Item("LAYER_FILES").NewRow
                NR.Item("FULLNAME") = "No Layer_ Files found"
                NR.Item("DISPLAYNAME") = "No Layer_ Files found"
                mLayerDetails.Tables.Item("LAYER_FILES").Rows.Add(NR)
                NR = Nothing

                cboLayerFiles.Enabled = False

                mLayerDetails.AcceptChanges()
            End If

            cboLayerFiles.ValueMember = "FULLNAME"
            cboLayerFiles.DataSource = mLayerDetails.Tables.Item("LAYER_FILES")
            cboLayerFiles.DisplayMember = "DISPLAYNAME"

            IsInitializing = False

            lblDwtName.Location = New Point(optFromAssociatedTemplate.Location.X + optFromAssociatedTemplate.Width + 3, optFromAssociatedTemplate.Location.Y)

            If lblDwtName.Text <> "" Then

                optFromAssociatedTemplate.Checked = True

            Else

                optFromAssociatedTemplate.Enabled = False
                If mLayerDetails.Tables.Item("LAYER_FILES").Rows.Count = 1 AndAlso mLayerDetails.Tables.Item("LAYER_FILES").Rows(0).Item("DISPLAYNAME").ToString = "No Layer_ Files found" Then

                    optFromLayerFile.Enabled = False
                    optFromExternalFile.Checked = True

                Else

                    optFromLayerFile.Enabled = True

                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    'Centres the Title of dialog in the middle of the Dialog
    Private Sub frmLayoutTools_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        lblTitle.Left = Me.Width \ 2 - Me.lblTitle.Width \ 2
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.OK

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = Doc.Editor()

        Dim SelLayers As List(Of LayerDets) = New List(Of LayerDets)

        For Each Dt As DataGridViewRow In dgvLayerDetails.SelectedRows
            Dim DTrw As LayerDets = CType(Dt.DataBoundItem, LayerDets)
            SelLayers.Add(DTrw)
        Next

        If SelLayers.Count > 0 Then

            If optFromAssociatedTemplate.Checked Then
                ed.WriteMessage(ImportLayersFromFile(lblDwtName.Text, SelLayers))
            End If

            If optFromLayerFile.Checked Then
                Dim SelItem As DataRowView = CType(cboLayerFiles.SelectedItem, DataRowView)
                If SelItem IsNot Nothing Then
                    ed.WriteMessage(ImportLayersFromFile(SelItem.Item("FULLNAME").ToString, SelLayers))
                End If
            End If

            If optFromExternalFile.Checked Then
                ed.WriteMessage(ImportLayersFromFile(txtExternalFile.Text, SelLayers))
            End If

        Else
            MsgBox("No Layers are selected to Import!")
        End If

        Me.Hide()
        Me.Close()

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel

        Me.Hide()
        Me.Close()

    End Sub

    ''' <summary>
    ''' The Help button must have the same code in every tool.
    ''' Reflection is used to work out the name of the CHM file based on the name of the DLL.
    ''' If a CHM file is not present a generic message is displayed notifying the user that
    ''' help is not available and that they should pressure CAD Support team to make it available.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub cmdGetFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGetFile.Click

        Dim Ret As String = AutoCADOpenSingleSelect(My.Computer.FileSystem.SpecialDirectories.MyDocuments,
                                                                  "Select External File to Read Layer Information",
                                                                  "dwg; dwt; *",
                                                                  "External Layers")
        If Ret <> "" Then
            txtExternalFile.Text = Ret
            LoadDGV(txtExternalFile.Text)
        End If

    End Sub

    Private Function ImportLayersFromFile(ByVal SourceFileName As String, ByVal LayerNames As List(Of LayerDets)) As String

        Dim CurrentDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = CurrentDoc.Editor()

        'Get original drawing
        Dim CurrentDB As Database = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database
        Dim Result As String = ""

        'Create List Of class to store data about layers

        Try

            'Step thru each Selected Layers Collected from Dialog
            For Each LayerX As LayerDets In LayerNames

                'If line type is missing, import it first
                If LayerX.IsExistsInCurrentDB = False Then

                    'Import LineType
                    CurrentDB.ImportSymbolTableRecord(Of LinetypeTable)(SourceFileName, LayerX.LineTypeName, chkOverWriteLayer.Checked)

                End If

                'Import Layer
                CurrentDB.ImportSymbolTableRecord(Of LayerTable)(SourceFileName, LayerX.LayerName, chkOverWriteLayer.Checked)

            Next

            Result = "Layers Imported from " & SourceFileName & vbCrLf

        Catch ex As Exception

            Result = ex.ToString

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

        Return Result

    End Function

    Private Function GetAllLayersFromSelectedFile(ByVal LayerFileName As String) As List(Of LayerDets)

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim layer As LayerTableRecord

        Dim Layers As List(Of LayerDets) = New List(Of LayerDets)

        If File.Exists(LayerFileName) = False Then Return Layers

        Using DocKock As DocumentLock = Doc.LockDocument

            Dim SourceDB As Database = New Database(True, False)
            SourceDB.ReadDwgFile(LayerFileName, System.IO.FileShare.Read, False, "")

            Using db As Database = SourceDB 'Doc.Database

                Using tr As Transaction = db.TransactionManager.StartTransaction()

                    Dim lt As LayerTable = TryCast(tr.GetObject(db.LayerTableId, OpenMode.ForRead), LayerTable)
                    For Each layerId As ObjectId In lt

                        layer = TryCast(tr.GetObject(layerId, OpenMode.ForWrite), LayerTableRecord)

                        'Initialise CLass
                        Dim NewLay As New LayerDets

                        NewLay.LayerName = layer.Name
                        NewLay.LayerObjectID = layer.ObjectId
                        NewLay.LayerColor = layer.Color

                        'Set LineType Information
                        Dim LineTypeRec As LinetypeTableRecord = TryCast(tr.GetObject(layer.LinetypeObjectId, OpenMode.ForRead), LinetypeTableRecord)
                        NewLay.LineTypeName = LineTypeRec.Name
                        NewLay.LinetypeObjectID = layer.LinetypeObjectId

                        NewLay.Description = layer.Description

                        'Add to Class List
                        Layers.Add(NewLay)

                    Next

                    tr.Commit()

                End Using

            End Using

        End Using

        CheckIfLineTypesExist(Layers)

        Return Layers

    End Function

    Private Sub CheckIfLineTypesExist(ByRef TheLayers As List(Of LayerDets))

        Dim CurrentDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = CurrentDoc.Editor()

        Dim CurrentDB As Database = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database
        Dim Result As String = ""

        'lock the current drawing
        Using DokLock As DocumentLock = CurrentDoc.LockDocument

            'start Transaction
            Using tr As Transaction = CurrentDB.TransactionManager.StartTransaction()

                'Get LineType Table
                Dim CurrentLineTypeTable As LinetypeTable = TryCast(tr.GetObject(CurrentDB.LinetypeTableId, OpenMode.ForRead), LinetypeTable)

                For Each LayDet As LayerDets In TheLayers

                    LayDet.IsExistsInCurrentDB = CurrentLineTypeTable.Has(LayDet.LineTypeName)

                Next

                tr.Commit()

            End Using

        End Using

    End Sub

    Private Sub optFromLayerFile_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optFromLayerFile.CheckedChanged

        If cboLayerFiles.SelectedItem Is Nothing Then Exit Sub

        XEnabled(pnlLayerFiles, optFromLayerFile.Checked)
        XEnabled(pnlExternalFile, Not (optFromAssociatedTemplate.Checked))

        dgvLayerDetails.DataSource = Nothing

        Dim DtRwo As DataRowView = CType(cboLayerFiles.SelectedItem, DataRowView)
        LoadDGV(DtRwo.Item("FULLNAME").ToString)

    End Sub

    Private Sub optFromExternalFile_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optFromExternalFile.CheckedChanged, txtExternalFile.TextChanged

        If optFromExternalFile.Checked = False Then Exit Sub

        XEnabled(pnlLayerFiles, Not (optFromExternalFile.Checked))
        XEnabled(pnlExternalFile, optFromExternalFile.Checked)
        dgvLayerDetails.DataSource = Nothing

        If txtExternalFile.Text <> "" Then
            LoadDGV(txtExternalFile.Text)
        End If

    End Sub

    Private Sub optFromDwt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optFromAssociatedTemplate.CheckedChanged

        If optFromAssociatedTemplate.Checked = False Then Exit Sub

        XEnabled(pnlLayerFiles, Not (optFromAssociatedTemplate.Checked))
        XEnabled(pnlExternalFile, Not (optFromAssociatedTemplate.Checked))
        dgvLayerDetails.DataSource = Nothing

        LoadDGV(lblDwtName.Text)
    End Sub

    Private Sub LoadDGV(ByVal LoadFile As String)
        Dim SelData As List(Of LayerDets) = GetAllLayersFromSelectedFile(LoadFile)

        SelData.Sort(Function(x, y) x.LayerName.CompareTo(y.LayerName))

        dgvLayerDetails.AllowDrop = False
        dgvLayerDetails.DataSource = SelData
        'dgvLayerDetails.DataMember = FileToProcess_DS.Tables("DFiles").TableName


    End Sub

    Private Sub dgvLayerDetails_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgvLayerDetails.CellFormatting

        Dim DtRow As LayerDets = CType(dgvLayerDetails.Rows(e.RowIndex).DataBoundItem, LayerDets)

        Dim R As Integer = CType(DtRow.LayerColorObj.ColorValue.R.ToString, Integer)
        Dim B As Integer = CType(DtRow.LayerColorObj.ColorValue.B.ToString, Integer)
        Dim G As Integer = CType(DtRow.LayerColorObj.ColorValue.G.ToString, Integer)

        Dim MyColor As Drawing.Color = Drawing.Color.FromArgb(R, B, G)

        Dim HasColor As Boolean = True
        If HasColor Then
            If e.ColumnIndex = 1 Then
                e.CellStyle.BackColor = MyColor
            End If
        End If

    End Sub

    Private Sub cboLayerFiles_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLayerFiles.SelectedIndexChanged

        If IsInitializing Then Exit Sub

        If cboLayerFiles.SelectedItem Is Nothing Then Exit Sub

        Dim DtRwo As DataRowView = CType(cboLayerFiles.SelectedItem, DataRowView)
        LoadDGV(DtRwo.Item("FULLNAME").ToString)

    End Sub

    Private Sub PictureBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles LogoPictureBox.DoubleClick
        lblDwtName.Visible = Not (lblDwtName.Visible)
    End Sub

    Private Sub LayerImporter_Form_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

    Private Sub Row_Changed(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)

        If mLayerDetails.Tables.Item("DWT_LAYERS").Rows.Count > 0 Then
            cmdOK.Enabled = True
        Else
            cmdOK.Enabled = False
        End If

    End Sub

    Private Sub dgvLayerDetails_DataBindingComplete(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewBindingCompleteEventArgs) Handles dgvLayerDetails.DataBindingComplete

        For Each Column As DataGridViewColumn In dgvLayerDetails.Columns
            Column.SortMode = DataGridViewColumnSortMode.Programmatic
        Next

        If Not dgvLayerDetails.DataSource Is Nothing Then

            Dim Col As ICollection(Of LayerDets) = CType(dgvLayerDetails.DataSource, ICollection(Of LayerDets))

            If Col.Count = 0 Then
                cmdOK.Enabled = False
            Else
                cmdOK.Enabled = True
            End If

        Else
            cmdOK.Enabled = False
        End If

    End Sub


End Class




