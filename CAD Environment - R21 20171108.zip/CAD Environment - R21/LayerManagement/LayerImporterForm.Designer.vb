﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LayerImporterForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LayerImporterForm))
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.tlpButtons = New System.Windows.Forms.TableLayoutPanel()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblDwtName = New System.Windows.Forms.Label()
        Me.chkOverWriteLayer = New System.Windows.Forms.CheckBox()
        Me.pnlExternalFile = New System.Windows.Forms.Panel()
        Me.txtExternalFile = New System.Windows.Forms.TextBox()
        Me.cmdGetFile = New System.Windows.Forms.Button()
        Me.optFromExternalFile = New System.Windows.Forms.RadioButton()
        Me.pnlLayerFiles = New System.Windows.Forms.Panel()
        Me.cboLayerFiles = New System.Windows.Forms.ComboBox()
        Me.optFromLayerFile = New System.Windows.Forms.RadioButton()
        Me.optFromAssociatedTemplate = New System.Windows.Forms.RadioButton()
        Me.dgvLayerDetails = New System.Windows.Forms.DataGridView()
        Me.LayerName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LayerColor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LayerLineType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LayerDescription = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tlpButtons.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.pnlExternalFile.SuspendLayout()
        Me.pnlLayerFiles.SuspendLayout()
        CType(Me.dgvLayerDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdOK.Location = New System.Drawing.Point(118, 6)
        Me.cmdOK.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(85, 32)
        Me.cmdOK.TabIndex = 0
        Me.cmdOK.Text = "OK"
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(225, 6)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(85, 32)
        Me.cmdCancel.TabIndex = 1
        Me.cmdCancel.Text = "Cancel"
        '
        'lblTitle
        '
        Me.lblTitle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(206, 35)
        Me.lblTitle.TabIndex = 23
        Me.lblTitle.Text = "Layer Importer"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdHelp
        '
        Me.cmdHelp.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(11, 6)
        Me.cmdHelp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(85, 32)
        Me.cmdHelp.TabIndex = 26
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'tlpButtons
        '
        Me.tlpButtons.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tlpButtons.ColumnCount = 3
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpButtons.Controls.Add(Me.cmdCancel, 2, 0)
        Me.tlpButtons.Controls.Add(Me.cmdOK, 1, 0)
        Me.tlpButtons.Controls.Add(Me.cmdHelp, 0, 0)
        Me.tlpButtons.Location = New System.Drawing.Point(403, 578)
        Me.tlpButtons.Margin = New System.Windows.Forms.Padding(4)
        Me.tlpButtons.Name = "tlpButtons"
        Me.tlpButtons.RowCount = 1
        Me.tlpButtons.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpButtons.Size = New System.Drawing.Size(321, 44)
        Me.tlpButtons.TabIndex = 27
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 0
        Me.LogoPictureBox.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.lblDwtName)
        Me.GroupBox1.Controls.Add(Me.chkOverWriteLayer)
        Me.GroupBox1.Controls.Add(Me.pnlExternalFile)
        Me.GroupBox1.Controls.Add(Me.optFromExternalFile)
        Me.GroupBox1.Controls.Add(Me.pnlLayerFiles)
        Me.GroupBox1.Controls.Add(Me.optFromLayerFile)
        Me.GroupBox1.Controls.Add(Me.optFromAssociatedTemplate)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 79)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(709, 263)
        Me.GroupBox1.TabIndex = 71
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Read Layers From"
        '
        'lblDwtName
        '
        Me.lblDwtName.AutoSize = True
        Me.lblDwtName.Location = New System.Drawing.Point(257, 26)
        Me.lblDwtName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDwtName.Name = "lblDwtName"
        Me.lblDwtName.Size = New System.Drawing.Size(0, 17)
        Me.lblDwtName.TabIndex = 72
        Me.lblDwtName.Visible = False
        '
        'chkOverWriteLayer
        '
        Me.chkOverWriteLayer.AutoSize = True
        Me.chkOverWriteLayer.Location = New System.Drawing.Point(21, 231)
        Me.chkOverWriteLayer.Margin = New System.Windows.Forms.Padding(4)
        Me.chkOverWriteLayer.Name = "chkOverWriteLayer"
        Me.chkOverWriteLayer.Size = New System.Drawing.Size(156, 21)
        Me.chkOverWriteLayer.TabIndex = 71
        Me.chkOverWriteLayer.Text = "Overwrite On Import"
        Me.chkOverWriteLayer.UseVisualStyleBackColor = True
        '
        'pnlExternalFile
        '
        Me.pnlExternalFile.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlExternalFile.Controls.Add(Me.txtExternalFile)
        Me.pnlExternalFile.Controls.Add(Me.cmdGetFile)
        Me.pnlExternalFile.Location = New System.Drawing.Point(21, 165)
        Me.pnlExternalFile.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlExternalFile.Name = "pnlExternalFile"
        Me.pnlExternalFile.Size = New System.Drawing.Size(669, 55)
        Me.pnlExternalFile.TabIndex = 4
        '
        'txtExternalFile
        '
        Me.txtExternalFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExternalFile.Location = New System.Drawing.Point(4, 20)
        Me.txtExternalFile.Margin = New System.Windows.Forms.Padding(4)
        Me.txtExternalFile.Name = "txtExternalFile"
        Me.txtExternalFile.ReadOnly = True
        Me.txtExternalFile.Size = New System.Drawing.Size(613, 22)
        Me.txtExternalFile.TabIndex = 70
        '
        'cmdGetFile
        '
        Me.cmdGetFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdGetFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGetFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGetFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGetFile.Location = New System.Drawing.Point(627, 15)
        Me.cmdGetFile.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdGetFile.Name = "cmdGetFile"
        Me.cmdGetFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGetFile.Size = New System.Drawing.Size(40, 30)
        Me.cmdGetFile.TabIndex = 69
        Me.cmdGetFile.Text = "..."
        Me.cmdGetFile.UseVisualStyleBackColor = False
        '
        'optFromExternalFile
        '
        Me.optFromExternalFile.AutoSize = True
        Me.optFromExternalFile.Location = New System.Drawing.Point(20, 134)
        Me.optFromExternalFile.Margin = New System.Windows.Forms.Padding(4)
        Me.optFromExternalFile.Name = "optFromExternalFile"
        Me.optFromExternalFile.Size = New System.Drawing.Size(187, 21)
        Me.optFromExternalFile.TabIndex = 3
        Me.optFromExternalFile.TabStop = True
        Me.optFromExternalFile.Text = "External File (dwg or dwt)"
        Me.optFromExternalFile.UseVisualStyleBackColor = True
        '
        'pnlLayerFiles
        '
        Me.pnlLayerFiles.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlLayerFiles.Controls.Add(Me.cboLayerFiles)
        Me.pnlLayerFiles.Location = New System.Drawing.Point(21, 76)
        Me.pnlLayerFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlLayerFiles.Name = "pnlLayerFiles"
        Me.pnlLayerFiles.Size = New System.Drawing.Size(675, 46)
        Me.pnlLayerFiles.TabIndex = 2
        '
        'cboLayerFiles
        '
        Me.cboLayerFiles.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboLayerFiles.BackColor = System.Drawing.SystemColors.Window
        Me.cboLayerFiles.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboLayerFiles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLayerFiles.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboLayerFiles.Location = New System.Drawing.Point(4, 11)
        Me.cboLayerFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.cboLayerFiles.Name = "cboLayerFiles"
        Me.cboLayerFiles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboLayerFiles.Size = New System.Drawing.Size(665, 24)
        Me.cboLayerFiles.Sorted = True
        Me.cboLayerFiles.TabIndex = 68
        '
        'optFromLayerFile
        '
        Me.optFromLayerFile.AutoSize = True
        Me.optFromLayerFile.Location = New System.Drawing.Point(20, 52)
        Me.optFromLayerFile.Margin = New System.Windows.Forms.Padding(4)
        Me.optFromLayerFile.Name = "optFromLayerFile"
        Me.optFromLayerFile.Size = New System.Drawing.Size(91, 21)
        Me.optFromLayerFile.TabIndex = 1
        Me.optFromLayerFile.TabStop = True
        Me.optFromLayerFile.Text = "Layer File"
        Me.optFromLayerFile.UseVisualStyleBackColor = True
        '
        'optFromAssociatedTemplate
        '
        Me.optFromAssociatedTemplate.AutoSize = True
        Me.optFromAssociatedTemplate.Location = New System.Drawing.Point(20, 23)
        Me.optFromAssociatedTemplate.Margin = New System.Windows.Forms.Padding(4)
        Me.optFromAssociatedTemplate.Name = "optFromAssociatedTemplate"
        Me.optFromAssociatedTemplate.Size = New System.Drawing.Size(161, 21)
        Me.optFromAssociatedTemplate.TabIndex = 0
        Me.optFromAssociatedTemplate.TabStop = True
        Me.optFromAssociatedTemplate.Text = "Associated Template"
        Me.optFromAssociatedTemplate.UseVisualStyleBackColor = True
        '
        'dgvLayerDetails
        '
        Me.dgvLayerDetails.AllowUserToAddRows = False
        Me.dgvLayerDetails.AllowUserToDeleteRows = False
        Me.dgvLayerDetails.AllowUserToResizeColumns = False
        Me.dgvLayerDetails.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvLayerDetails.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvLayerDetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvLayerDetails.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvLayerDetails.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvLayerDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLayerDetails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LayerName, Me.LayerColor, Me.LayerLineType, Me.LayerDescription})
        Me.dgvLayerDetails.Location = New System.Drawing.Point(16, 358)
        Me.dgvLayerDetails.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvLayerDetails.Name = "dgvLayerDetails"
        Me.dgvLayerDetails.ReadOnly = True
        Me.dgvLayerDetails.RowTemplate.Height = 24
        Me.dgvLayerDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvLayerDetails.Size = New System.Drawing.Size(703, 210)
        Me.dgvLayerDetails.TabIndex = 72
        '
        'LayerName
        '
        Me.LayerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LayerName.DataPropertyName = "LayerName"
        Me.LayerName.HeaderText = "Layer"
        Me.LayerName.Name = "LayerName"
        Me.LayerName.ReadOnly = True
        Me.LayerName.Width = 69
        '
        'LayerColor
        '
        Me.LayerColor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LayerColor.HeaderText = "Color"
        Me.LayerColor.Name = "LayerColor"
        Me.LayerColor.ReadOnly = True
        Me.LayerColor.Width = 66
        '
        'LayerLineType
        '
        Me.LayerLineType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LayerLineType.DataPropertyName = "LineTypeName"
        Me.LayerLineType.HeaderText = "LineType"
        Me.LayerLineType.Name = "LayerLineType"
        Me.LayerLineType.ReadOnly = True
        Me.LayerLineType.Width = 92
        '
        'LayerDescription
        '
        Me.LayerDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.LayerDescription.DataPropertyName = "Description"
        Me.LayerDescription.HeaderText = "Description"
        Me.LayerDescription.Name = "LayerDescription"
        Me.LayerDescription.ReadOnly = True
        '
        'LayerImporterForm
        '
        Me.AcceptButton = Me.cmdOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CancelButton = Me.cmdCancel
        Me.ClientSize = New System.Drawing.Size(741, 642)
        Me.Controls.Add(Me.dgvLayerDetails)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.tlpButtons)
        Me.Controls.Add(Me.lblTitle)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(757, 679)
        Me.Name = "LayerImporterForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.tlpButtons.ResumeLayout(False)
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.pnlExternalFile.ResumeLayout(False)
        Me.pnlExternalFile.PerformLayout()
        Me.pnlLayerFiles.ResumeLayout(False)
        CType(Me.dgvLayerDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Friend WithEvents tlpButtons As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkOverWriteLayer As System.Windows.Forms.CheckBox
    Friend WithEvents pnlExternalFile As System.Windows.Forms.Panel
    Friend WithEvents txtExternalFile As System.Windows.Forms.TextBox
    Public WithEvents cmdGetFile As System.Windows.Forms.Button
    Friend WithEvents optFromExternalFile As System.Windows.Forms.RadioButton
    Friend WithEvents pnlLayerFiles As System.Windows.Forms.Panel
    Public WithEvents cboLayerFiles As System.Windows.Forms.ComboBox
    Friend WithEvents optFromLayerFile As System.Windows.Forms.RadioButton
    Friend WithEvents optFromAssociatedTemplate As System.Windows.Forms.RadioButton
    Friend WithEvents dgvLayerDetails As System.Windows.Forms.DataGridView
    Friend WithEvents lblDwtName As System.Windows.Forms.Label
    Friend WithEvents LayerName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LayerColor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LayerLineType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LayerDescription As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
