﻿Public Module BatchPlugin

    Public Interface iBatchPlugin
        Sub RunProcess(Optional ByVal SettingsFilePath As String = "")
        Sub ShowSettingsDialog(Optional ByVal SettingsFilePath As String = "")
        ReadOnly Property ResultMessage() As String
        ReadOnly Property HasSettingsDialog() As Boolean
    End Interface

End Module
