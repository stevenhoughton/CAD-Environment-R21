﻿Imports System.IO
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports System.Windows.Forms
Imports Jacobs.AutoCAD.Utilities

Public Class ImportPageSetupsForm

    Dim mDisableUpdate As Boolean = False

    Dim FormData_DS As New DataSet

    Dim XMLFileToRead As String = ""
    Dim SearchFilePath As String = ""

    Public WriteOnly Property FilePath() As String
        Set(ByVal value As String)
            SearchFilePath = value
        End Set
    End Property

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Dim objAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly
        Dim VNumber As String
        'Get each part of the version through the assembly object
        VNumber = objAssembly.GetName().Version.Major & "." & objAssembly.GetName().Version.Minor & "." & _
            objAssembly.GetName().Version.Build & "." & objAssembly.GetName().Version.Revision

        Me.Text = objAssembly.GetName().Name & " - " & VNumber

    End Sub

    Private Sub frmPlotByBlock_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim FStream As FileStream
        Dim ContinueFlag As Boolean = True
        Dim ErrorInMainTry As Boolean = False

        Try
            If SearchFilePath <> "" Then
                XMLFileToRead = SearchFilePath.Replace(".dll", ".xml")
            Else
                ContinueFlag = False
            End If

        Catch ex As Exception
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            Try

                FStream = New FileStream(XMLFileToRead, FileMode.Open)

                FormData_DS.ReadXml(FStream)

                FStream.Close()

                If FormData_DS.Tables.Count > 0 Then

                    FormData_DS.Tables(0).TableName = "IMPORTSettings"

                    Dim dtCloned As System.Data.DataTable = FormData_DS.Tables(0).Clone()
                    dtCloned.Columns(0).DataType = GetType(String)
                    dtCloned.Columns(1).DataType = GetType(String)

                    For Each row As DataRow In FormData_DS.Tables(0).Rows
                        dtCloned.ImportRow(row)
                    Next

                    FormData_DS.Tables.Remove("IMPORTSettings")
                    FormData_DS.AcceptChanges()

                    FormData_DS.Tables.Add(dtCloned.Copy)
                    FormData_DS.AcceptChanges()

                End If

            Catch ex As Exception
                FormData_DS.Tables.Add(CreateEmptyDataTable)
            Finally
                FStream = Nothing
            End Try

        Else
            FormData_DS.Tables.Add(CreateEmptyDataTable)
        End If

        If FormData_DS.Tables(0).Rows.Count = 1 Then
            'lstBlockNames.Items.Clear()
            txtOutPutPath.Text = FormData_DS.Tables(0).Rows(0).Item("FILEPATH").ToString
            Dim ChkVals() As String = FormData_DS.Tables(0).Rows(0).Item("PAGESETUP").ToString.Split(",")

            If File.Exists(txtOutPutPath.Text) Then
                LoadPageSetups()

                For Index As Integer = 0 To chklstPageSetups.Items.Count - 1
                    If ChkVals.Contains(chklstPageSetups.Items(Index).ToString) Then
                        chklstPageSetups.SetItemChecked(Index, True)
                    Else
                        chklstPageSetups.SetItemChecked(Index, False)
                    End If
                Next

            End If

        End If

    End Sub

    Public Function CreateEmptyDataTable() As System.Data.DataTable

        Dim DatTable As New System.Data.DataTable

        DatTable.TableName = "IMPORTSettings"
        DatTable.Columns.Add("PAGESETUP", GetType(String))
        DatTable.Columns.Add("FILEPATH", GetType(String))

        Return DatTable

    End Function

    Private Sub LoadPageSetups()

        ' Get the current document and database

        Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim readDwgDB As Database = New Database(False, True)

        Dim CopyInOID As New ObjectIdCollection
        chklstPageSetups.Items.Clear()

        Try

            Using DokLock As DocumentLock = acDoc.LockDocument
                readDwgDB.ReadDwgFile(txtOutPutPath.Text, FileOpenMode.OpenForReadAndReadShare, True, "")

                Using trans As Transaction = readDwgDB.TransactionManager.StartTransaction

                    Dim plSettings As DBDictionary = trans.GetObject(readDwgDB.PlotSettingsDictionaryId, OpenMode.ForRead)

                    For Each item As DBDictionaryEntry In plSettings

                        chklstPageSetups.Items.Add(item.Key)

                    Next

                End Using

            End Using

        Catch ex As Exception

        End Try

    End Sub

    'Only used if the XML is missing from PC to create new XML
    Public WriteOnly Property DS() As DataSet
        Set(ByVal value As DataSet)
            FormData_DS = value
        End Set
    End Property

    Public Sub SaveXML(ByVal PDesc As String, ByVal FilePath As String)

        If FormData_DS.Tables("IMPORTSettings").Rows.Count > 0 Then

            If File.Exists(FilePath) Then
                File.Delete(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Settings File has been deleted" & vbCrLf)
                FormData_DS.WriteXml(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Settings File has been ReWritten!" & vbCrLf)
            Else
                FormData_DS.WriteXml(FilePath)
            End If
        End If

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveSettings.Click

        Dim PgSetups As String = ""

        For Index As Integer = 0 To chklstPageSetups.CheckedItems.Count - 1
            PgSetups += chklstPageSetups.CheckedItems(Index).ToString & If(Index < (chklstPageSetups.CheckedItems.Count - 1), ",", "")
        Next
        FormData_DS.Tables(0).Rows(0).Item("PAGESETUP") = PgSetups
        FormData_DS.Tables(0).Rows(0).Item("FILEPATH") = txtOutPutPath.Text
        'TempDS.Tables(0).AcceptChanges()

        If FormData_DS.HasChanges Then

            FormData_DS.AcceptChanges()
            SaveXML("IMPORT PAGESETUP Settings", XMLFileToRead)

        End If

        Close()

    End Sub

    Private Sub chklstPageSetups_ItemCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemCheckEventArgs) Handles chklstPageSetups.ItemCheck
        If mDisableUpdate Then Exit Sub

        mDisableUpdate = True

        Dim clb As CheckedListBox = DirectCast(sender, CheckedListBox)
        ' Switch off event handler

        chklstPageSetups.SetItemCheckState(e.Index, e.NewValue)
        ' Switch on event handler

        If chklstPageSetups.Items.Count > 0 Then
            cmdSaveSettings.Enabled = True
        Else
            cmdSaveSettings.Enabled = False
        End If

        mDisableUpdate = False
    End Sub

    Private Sub txtOutPutPath_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtOutPutPath.LostFocus
        If File.Exists(txtOutPutPath.Text) = True Then
            LoadPageSetups()
        End If
    End Sub

    Private Sub cmdBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowse.Click

        Dim Ret As String = AutoCADOpenSingleSelect(My.Computer.FileSystem.SpecialDirectories.MyDocuments, _
                                                          "Select Drawing Files...", _
                                                          "dwg; *", _
                                                          "Drawing Files")

        If Ret <> "" Then
            txtOutPutPath.Text = Ret
            LoadPageSetups()
        End If

    End Sub

    Private Function AutoCADOpenSingleSelect(myDocuments As String, v1 As String, v2 As String, v3 As String) As String
        Throw New NotImplementedException()
    End Function
End Class