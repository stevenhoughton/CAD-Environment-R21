﻿Option Strict On
Option Explicit On

Imports System.IO
Imports System.Data
Imports System.Collections.Specialized
Imports System.Collections.Generic
Imports System.Runtime.InteropServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.GraphicsInterface
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD
Imports Jacobs.AutoCAD.BatchProcessorPlugin
Imports Autodesk.AutoCAD.PlottingServices
Imports Autodesk.AutoCAD.Internal.Reactors
Imports Autodesk.AutoCAD.Runtime
Imports Acadx = Autodesk.AutoCAD.ApplicationServices.Application
Imports ED = Autodesk.AutoCAD.EditorInput.Editor

Public Class ImportPageSetups
    Implements BatchPlugin.iBatchPlugin

    Public mSettingsTableName As String = "IMPORT PAGESETUP Settings"

    <DllImport("Acad.exe", CallingConvention:=CallingConvention.Cdecl, EntryPoint:="acedTrans")>
    Private Shared Function acedTrans(ByVal point As Double(), ByVal fromRb As IntPtr, ByVal toRb As IntPtr, ByVal disp As Integer, ByVal result As Double()) As Integer
    End Function

    Private mResultMessage As String = ""
    Private mHasSettingsDialog As Boolean = True

    Public Class Blk2Plt
        Public BlockRef As BlockReference
        Public LayoutObj As Layout
        Public DrawingNo As String
        Public DrawingRevNo As String
    End Class

    Private msgs As New List(Of String)()

    Public ReadOnly Property ResultMessage() As String Implements BatchPlugin.iBatchPlugin.ResultMessage
        Get
            Return mResultMessage
        End Get
    End Property

    Public ReadOnly Property HasSettingsDialog() As Boolean Implements BatchPlugin.iBatchPlugin.HasSettingsDialog
        Get
            Return mHasSettingsDialog
        End Get
    End Property


    'The Command Method is just for Testing.  RunProcess Will Be called from BacthProcessor
    Public Sub RunProcess(Optional ByVal SettingsFilePath As String = "") Implements BatchPlugin.iBatchPlugin.RunProcess

        'Read XML File into Datase
        Dim FStream As FileStream
        Dim TempDS As New DataSet
        Dim ContinueFlag As Boolean = True
        Dim ErrorInMainTry As Boolean = False
        Dim XMLFileToRead As String = ""

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim EDx As Editor = Doc.Editor

        Try

            If SettingsFilePath <> "" Then
                XMLFileToRead = SettingsFilePath.Replace(".dll", ".xml")
            Else
                ContinueFlag = False
            End If

        Catch ex As Exception
            mResultMessage = "XML Failed TO Read from : " & XMLFileToRead
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            Try

                FStream = New FileStream(XMLFileToRead, FileMode.Open)

                TempDS.ReadXml(FStream)

                FStream.Close()

                If TempDS.Tables.Count > 0 Then

                    Dim SettingsRow As DataRow = TempDS.Tables(0).Rows(0)

                    Application.SetSystemVariable("BACKGROUNDPLOT", 0)
                    Using DokLock As DocumentLock = Doc.LockDocument

                        Using tr As Transaction = Application.DocumentManager.MdiActiveDocument.TransactionManager.StartTransaction()

                            Try

                                Dim PlotDic As DBDictionary = DirectCast(Doc.Database.PlotSettingsDictionaryId.GetObject(OpenMode.ForWrite), DBDictionary)
                                Dim PageSetupNames() As String = SettingsRow.Item("PAGESETUP").ToString.Split(","c)
                                Dim PageSetupXMLFilePath As String = SettingsRow.Item("FILEPATH").ToString.ToUpper

                                For Each PageSetup As String In PageSetupNames

                                    If PlotDic.Contains(PageSetup) Then

                                        Dim PlotSettingsOBJ As PlotSettings = DirectCast(PlotDic.GetAt(PageSetup).GetObject(OpenMode.ForWrite), PlotSettings)

                                        PlotSettingsOBJ.Erase()

                                        mResultMessage += "Existing PageSetup: " & PageSetup & " Erased" & vbCrLf

                                    End If

                                Next

                                tr.Commit()

                                For Each PageSetup As String In PageSetupNames

                                    AddPlotSettings(PageSetupXMLFilePath, PageSetup)

                                Next

                            Catch ex As System.Exception

                                ErrorInMainTry = True
                                mResultMessage = ex.Message & vbCrLf

                            End Try

                        End Using



                    End Using

                End If

            Catch ex As Exception

                ErrorInMainTry = True
                mResultMessage = ex.ToString

            Finally

                TempDS = Nothing
                FStream = Nothing

                If ErrorInMainTry = False Then
                    mResultMessage += "Page Setups Import Completed!"
                Else
                    mResultMessage += "Page Setups Import Failed!"
                End If

            End Try

        End If

    End Sub

    Public Function AddPlotSettings(ByVal PlotSettingsFile As String, ByVal PlotSettingsName As String) As String

        Dim CurrentDatabase As Database = HostApplicationServices.WorkingDatabase

        Dim layName As String = Nothing
        Dim RetStr As String = "Error in Adding New PageSetup: " & PlotSettingsName & " from " & PlotSettingsFile & vbCrLf

        Using SourceDatabase As New Database(False, True)
            SourceDatabase.ReadDwgFile(PlotSettingsFile, FileOpenMode.OpenForReadAndAllShare, True, "")
            Using currentTransaction As Transaction = CurrentDatabase.TransactionManager.StartTransaction
                Using sourceTransaction As Transaction = SourceDatabase.TransactionManager.StartTransaction
                    Dim sourcePlotDic As DBDictionary = CType(SourceDatabase.PlotSettingsDictionaryId.GetObject(OpenMode.ForRead), DBDictionary)
                    If sourcePlotDic.Contains(PlotSettingsName) Then
                        Dim objID As ObjectId = sourcePlotDic.GetAt(PlotSettingsName)
                        Dim pl As PlotSettings = CType(objID.GetObject(OpenMode.ForRead), PlotSettings)
                        Dim cpl As New PlotSettings(pl.ModelType)
                        'Application.ShowAlertDialog(pl.GetType.Name)
                        'Application.ShowAlertDialog(cpl.GetType.Name)
                        cpl.CopyFrom(pl)
                        cpl.AddToPlotSettingsDictionary(CurrentDatabase)
                        Dim bt As BlockTable = CType(CurrentDatabase.BlockTableId.GetObject(OpenMode.ForRead), BlockTable)
                        Dim btr As BlockTableRecord = CType(bt(BlockTableRecord.PaperSpace).GetObject(OpenMode.ForRead), BlockTableRecord)

                        If pl.ModelType Then
                            btr = CType(bt(BlockTableRecord.ModelSpace).GetObject(OpenMode.ForRead), BlockTableRecord)
                        Else
                            btr = CType(bt(BlockTableRecord.PaperSpace).GetObject(OpenMode.ForRead), BlockTableRecord)
                        End If

                        Dim lay As Layout = CType(btr.LayoutId.GetObject(OpenMode.ForWrite), Layout)
                        lay.CopyFrom(cpl)
                        layName = lay.LayoutName
                        RetStr = " PageSetup: " & PlotSettingsName & " Added Successfully from " & PlotSettingsFile & vbCrLf
                    End If
                    sourceTransaction.Commit()
                End Using
                currentTransaction.Commit()
            End Using
        End Using

        If Not layName = Nothing Then
            LayoutManager.Current.CurrentLayout = layName
        End If

        Return RetStr

    End Function

    Private Sub ClonePlot(ByVal SourceDatabase As Database, ByVal CurrentDatabase As Database, ByVal PageSetupName As String)
        Using currentTransaction As Transaction = CurrentDatabase.TransactionManager.StartTransaction
            Using sourceTransaction As Transaction = SourceDatabase.TransactionManager.StartTransaction
                Dim sourcePlotDic As DBDictionary = CType(SourceDatabase.PlotSettingsDictionaryId.GetObject(OpenMode.ForRead), DBDictionary)
                Dim objID As ObjectId
                If sourcePlotDic.Contains(PageSetupName) Then
                    objID = sourcePlotDic.GetAt(PageSetupName)
                    Dim pl As PlotSettings = CType(objID.GetObject(OpenMode.ForRead), PlotSettings)
                    Dim cpl As New PlotSettings(False)
                    cpl.CopyFrom(pl)
                    cpl.AddToPlotSettingsDictionary(CurrentDatabase)
                End If
                currentTransaction.Commit()
            End Using
        End Using
    End Sub

    Public Sub Settings(Optional ByVal SettingsFilePath As String = "") Implements iBatchPlugin.ShowSettingsDialog

        Dim ContinueFlag As Boolean = False
        Dim XMLFileToRead As String = ""

        Dim MyForm As New ImportPageSetupsForm

        Try
            If SettingsFilePath <> "" Then
                XMLFileToRead = SettingsFilePath.Replace(".dll", ".xml")
                If File.Exists(XMLFileToRead) = False Then
                    Dim NewDS As New DataSet
                    NewDS.Tables.Add(MyForm.CreateEmptyDataTable)
                    NewDS.AcceptChanges()
                    MyForm.DS = NewDS
                    MyForm.SaveXML(mSettingsTableName, XMLFileToRead)
                    ContinueFlag = True
                Else
                    ContinueFlag = True
                End If
            Else
                ContinueFlag = False
            End If
        Catch ex As Exception
            mResultMessage = "XML Failed TO Read from : " & XMLFileToRead
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            MyForm.FilePath = SettingsFilePath
            MyForm.ShowDialog()

        End If

        MyForm = Nothing

    End Sub

End Class

