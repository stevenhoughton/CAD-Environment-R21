﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ImportPageSetupsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ImportPageSetupsForm))
        Me.pnlButtons = New System.Windows.Forms.Panel()
        Me.cmdSaveSettings = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.lblOutputPath = New System.Windows.Forms.Label()
        Me.txtOutPutPath = New System.Windows.Forms.TextBox()
        Me.cmdBrowse = New System.Windows.Forms.Button()
        Me.chklstPageSetups = New System.Windows.Forms.CheckedListBox()
        Me.pnlButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlButtons
        '
        Me.pnlButtons.Controls.Add(Me.cmdSaveSettings)
        Me.pnlButtons.Controls.Add(Me.cmdCancel)
        Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtons.Location = New System.Drawing.Point(0, 371)
        Me.pnlButtons.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlButtons.MaximumSize = New System.Drawing.Size(0, 57)
        Me.pnlButtons.MinimumSize = New System.Drawing.Size(0, 57)
        Me.pnlButtons.Name = "pnlButtons"
        Me.pnlButtons.Size = New System.Drawing.Size(537, 57)
        Me.pnlButtons.TabIndex = 2
        '
        'cmdSaveSettings
        '
        Me.cmdSaveSettings.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdSaveSettings.Enabled = False
        Me.cmdSaveSettings.Location = New System.Drawing.Point(317, 14)
        Me.cmdSaveSettings.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdSaveSettings.Name = "cmdSaveSettings"
        Me.cmdSaveSettings.Size = New System.Drawing.Size(100, 28)
        Me.cmdSaveSettings.TabIndex = 3
        Me.cmdSaveSettings.Text = "Save"
        Me.cmdSaveSettings.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(425, 14)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(100, 28)
        Me.cmdCancel.TabIndex = 2
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'lblOutputPath
        '
        Me.lblOutputPath.AutoSize = True
        Me.lblOutputPath.Location = New System.Drawing.Point(19, 9)
        Me.lblOutputPath.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblOutputPath.Name = "lblOutputPath"
        Me.lblOutputPath.Size = New System.Drawing.Size(170, 17)
        Me.lblOutputPath.TabIndex = 3
        Me.lblOutputPath.Text = "Page Setup Drawing Path"
        '
        'txtOutPutPath
        '
        Me.txtOutPutPath.Location = New System.Drawing.Point(16, 28)
        Me.txtOutPutPath.Margin = New System.Windows.Forms.Padding(4)
        Me.txtOutPutPath.Name = "txtOutPutPath"
        Me.txtOutPutPath.Size = New System.Drawing.Size(409, 22)
        Me.txtOutPutPath.TabIndex = 4
        '
        'cmdBrowse
        '
        Me.cmdBrowse.Location = New System.Drawing.Point(435, 22)
        Me.cmdBrowse.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdBrowse.Name = "cmdBrowse"
        Me.cmdBrowse.Size = New System.Drawing.Size(80, 28)
        Me.cmdBrowse.TabIndex = 8
        Me.cmdBrowse.Text = "Browse..."
        Me.cmdBrowse.UseVisualStyleBackColor = True
        '
        'chklstPageSetups
        '
        Me.chklstPageSetups.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chklstPageSetups.CheckOnClick = True
        Me.chklstPageSetups.FormattingEnabled = True
        Me.chklstPageSetups.Location = New System.Drawing.Point(19, 59)
        Me.chklstPageSetups.Margin = New System.Windows.Forms.Padding(4)
        Me.chklstPageSetups.Name = "chklstPageSetups"
        Me.chklstPageSetups.Size = New System.Drawing.Size(493, 293)
        Me.chklstPageSetups.TabIndex = 9
        '
        'ImportPageSetupsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 428)
        Me.Controls.Add(Me.chklstPageSetups)
        Me.Controls.Add(Me.cmdBrowse)
        Me.Controls.Add(Me.txtOutPutPath)
        Me.Controls.Add(Me.lblOutputPath)
        Me.Controls.Add(Me.pnlButtons)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "ImportPageSetupsForm"
        Me.Text = "Import Pages Setup"
        Me.pnlButtons.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlButtons As System.Windows.Forms.Panel
    Friend WithEvents cmdSaveSettings As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents lblOutputPath As System.Windows.Forms.Label
    Friend WithEvents txtOutPutPath As System.Windows.Forms.TextBox
    Friend WithEvents cmdBrowse As System.Windows.Forms.Button
    Friend WithEvents chklstPageSetups As System.Windows.Forms.CheckedListBox
End Class
