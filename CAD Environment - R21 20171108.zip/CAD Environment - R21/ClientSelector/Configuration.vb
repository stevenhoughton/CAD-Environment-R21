Public Class Configuration

    Private config_name As String
    Private config_value As String

    Public Overrides Function ToString() As String
        Return config_name
    End Function

    Public Sub New(ByVal itemData As String, ByVal itemText As String)
        config_value = itemData
        config_name = itemText
    End Sub

    Public ReadOnly Property Data() As String
        Get
            Data = config_value
        End Get

    End Property


    Public ReadOnly Property DisplayText() As String
        Get
            DisplayText = config_name
        End Get

    End Property

End Class
