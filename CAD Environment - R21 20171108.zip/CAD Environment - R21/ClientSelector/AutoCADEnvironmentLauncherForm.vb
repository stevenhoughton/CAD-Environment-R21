﻿Imports System.Windows.Forms
Imports Microsoft.Win32
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Linq
Imports Microsoft.VisualBasic
Imports System.Net.Mail
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings
Imports Jacobs.AutoCAD.Utilities
Imports System.Environment
Imports System.Xml

Public Class CADEnvironmentLauncherForm

#Region "Variables"

    Dim cDirectoryEntries As Collection = New Collection

    '' Configurations are now stored in Directories and separated by a hyphen '-' 
    '' Every configuration name is made up of 4 columns or sections as follows
    Const cfgCountry As Integer = 0
    Const cfgRegion As Integer = 1
    Const cfgClient As Integer = 2
    Const cfgDisciplines As Integer = 3

    Dim NewConfigName As String = String.Empty
    Dim ExistingConfigName As String = String.Empty

    Dim DFSLocation As String = Jacobs.Common.Settings.Manager.EvaluateExpression("[DFSSHARE]").CombinePath("Jacobs")
    'Dim DFSLocation As String = "\\AU-GLB-DFS01\cfr\Replicated\Jacobs"

    Public Shared lista As New Collections.ArrayList

    '' Used to store user Settings that don't need to be kept with the DWG file.
    '' Settings that need to be kept in dwg file should be stored in Rules.
    'Private UserSettings As New SaveToolSettings(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData).CombinePath("Jacobs\Jacobs AutoCAD Environment R21", System.Reflection.MethodBase.GetCurrentMethod.Module.Name), System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name))

    Public LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

#End Region

#Region "Start Here"

    ''' <summary>
    ''' Loader for the form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        Initializer()

    End Sub

    Public Sub DisplayVersionOnDialog()

        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen

        Dim BundlePath As String = System.IO.Directory.GetParent(Settings.Manager.AE.Path).ToString

        If Settings.Manager.AE.Version.Contains("(") Then

            ' In Some king of testing phase either UAT or Testing
            Dim sTextFileName As String = Settings.Manager.AE.Version.Split("("c)(1).Replace(")"c, "").ToString
            sTextFileName = sTextFileName & ".TXT"

            If System.IO.File.Exists(BundlePath.CombinePath(sTextFileName)) = True Then
                Me.Text = Me.lblTitle.Text & " - " & Settings.Manager.AE.Version
            Else
                Me.Text = Me.lblTitle.Text & " - " & Settings.Manager.AE.Version & " Reboot Required"
            End If

        Else

            ' In production check that there are not TXT files in the Bundle folder
            If System.IO.Directory.GetFiles(BundlePath, "*.TXT", SearchOption.TopDirectoryOnly).Length = 0 Then
                Me.Text = Me.lblTitle.Text & " - " & Settings.Manager.AE.Version
            Else
                Me.Text = Me.lblTitle.Text & " - " & Settings.Manager.AE.Version & " Reboot Required"
            End If

        End If

    End Sub

    Private Sub AE_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
        RepositionAndResizeListBoxes()
    End Sub


    Private Sub DisableCommonfields()

        ProductComboBox.Visible = False
        ProductLabel.Visible = False
        ProfileComboBox.Visible = False
        ProfileLabel.Visible = False
        RefreshProfileAndProductButton.Visible = False
        WorkSpaceTextBox.Visible = False
        WorkspaceLabel.Visible = False

    End Sub

    Private Sub EnableCommonfields()

        ProductComboBox.Visible = True
        ProductLabel.Visible = True
        ProfileComboBox.Visible = True
        ProfileLabel.Visible = True
        RefreshProfileAndProductButton.Visible = True
        WorkSpaceTextBox.Visible = True
        WorkspaceLabel.Visible = True

    End Sub

    Private Sub RepositionAndResizeListBoxes()

        Dim Margin As Integer = (Me.Size.Width / 204) '166.4)

        Dim StartWidth As Integer = (ClientsearchButton.Location.X / 5) - (Margin * 1.5)

        Dim StartHeight As Integer = SummaryGroupBox.Location.Y - (Margin * 5)

        Dim NewSize As New System.Drawing.Point(StartWidth, StartHeight)

        CountriesListBox.Size = NewSize
        RegionsListBox.Size = NewSize
        ClientsListBox.Size = NewSize
        DisciplinesListBox.Size = NewSize
        PartialMenuListBox.Size = NewSize

        Dim location1 As New System.Drawing.Point(Margin, CountriesListBox.Location.Y)
        CountriesListBox.Location = location1
        Dim lblocation1 As New System.Drawing.Point(Margin, CountryLBLabel.Location.Y)
        CountryLBLabel.Location = lblocation1

        Dim location2 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin, CountriesListBox.Location.Y)
        RegionsListBox.Location = location2
        Dim lblocation2 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin, CountryLBLabel.Location.Y)
        RegionLBLabel.Location = lblocation2

        Dim location3 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin, CountriesListBox.Location.Y)
        ClientsListBox.Location = location3
        Dim lblocation3 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin, CountryLBLabel.Location.Y)
        ClientLBLabel.Location = lblocation3
        Dim lblocation4 As New System.Drawing.Point(ClientLBLabel.Size.Width + Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin, CountryLBLabel.Location.Y - 2)
        ShowJacobsOnlyCheckBox.Location = lblocation4

        Dim location5 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin + ClientsListBox.Size.Width + Margin, CountriesListBox.Location.Y)
        DisciplinesListBox.Location = location5
        Dim lblocation5 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin + ClientsListBox.Size.Width + Margin, CountryLBLabel.Location.Y)
        DisciplinesLBLabel.Location = lblocation5

        Dim location6 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin + ClientsListBox.Size.Width + Margin + DisciplinesListBox.Size.Width + Margin, CountriesListBox.Location.Y)
        PartialMenuListBox.Location = location6
        Dim lblocation6 As New System.Drawing.Point(Margin + CountriesListBox.Size.Width + Margin + RegionsListBox.Size.Width + Margin + ClientsListBox.Size.Width + Margin + DisciplinesListBox.Size.Width + Margin, CountryLBLabel.Location.Y)
        PartialMenuLabel.Location = lblocation6

    End Sub


    ''' <summary>
    ''' Initialization of form code
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Initializer()

        '' Get the Settings.Manager details for the AE Product
        GetAEConfigSettings()
        'MsgBox(Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSShareLocation)

        'DeleteLogFile(LogName)

        '' Delete old Log Files 2 days - to allow them to be deleted after each week end
        DeleteOldLogFiles(2)

        DeleteLegacyCADShortCuts()

        '' Create Jacobs Legacy CAD Shortcuts
        CreateLegacyCADShortcuts()

        '' Workout out the Dialog Box Title
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

        ' Now that we have things like the AEVersion number and Title display it on the dialog name
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

        '' Currently hard coded override until we change the name of the EXE file from Clientselector.exe to
        ' CADEnvironmentLauncher.exe - next two lines can be commented out after that change is made
        ' Note that change will affect how Avetco works so the new exe would need to be added
        Me.lblTitle.Text = "AutoCAD Environment Launcher" 'DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        Me.Text = "AutoCAD Environment Launcher" & Settings.Manager.AE.Version

        RepositionTitle(Me.lblTitle, Me)
        RepositionAndResizeListBoxes()

        DisplayVersionOnDialog()

        '' Associate the DWG and DWT file types with the AcadLauncher.exe
        FileAssociation()

        '' Trial attempt to update the DFS Downloader with latest code...
        ' R21 has a new Downloader
        TryUpdateDFSDownloaderDlls()

        '' Update User Files
        UpdateUserFiles()

        '' Check Permissions - only machine admins and users that exist in the ConfigBuilders.txt file can access the Template Manager tab controls
        GeneralMessageBox("Check Permissions - only users that exist in the ConfigBuilders.txt file can access the Template Manager tab controls", , , , , , , , True, LogName)
        If IsUserValidTemplateAdministrator() = False Then DisableTemplateTabControls()

        GeneralMessageBox("Check Permissions - only users that exist in the SystemsAdministrators.txt file can access the Administrator tab controls", , , , , , , , True, LogName)
        If Settings.IsUserValidSystemAdministrator = False Then DisableAdminitrationTabControls()

        '' Check that Resets can be performed
        EnableDisableResetButtons()

        '' EnableDisableProjectWiseButtons

        EnableDisableProjectWiseButtons()

        '' EnableDisableAEButtons

        EnableDisableAEButtons()

        '' EnableDisableButtonsThatRequireAdminRights

        EnableDisableButtonsThatRequireAdminRights()

        '' ManageLists

        ManageLists()

        '' RestoreDialogSettings

        RestoreDialogSettings()

    End Sub


    Sub ManageLists()

        '' Get all client folders in configuration library and store it in a collection
        CEGetDirectories(Settings.Manager.AE.ClientsConfigurationPath, cDirectoryEntries, Settings.Manager.AE.TemplatesToHideFileNamePathed, Settings.IsUserValidSystemAdministrator, ShowJacobsOnlyCheckBox.Checked)

        '' By populating the countries list box we trigger the cascading population of the other list boxes in this name
        PopulateCountryListBox()

        '' Now we popluate the the menus list
        PopulatePartialMenuListBox()

        '' Clear Report list box ? This may not be in the correct spot
        ContentsReportListBox.Items.Clear()

        '' Populate the Product Combo Box based on installed products and configuration.xml Contents
        PopulateProductComboBox()

        '' Now that we know the AutoCAD product ...
        PopulateProfileComboBox()

        '' By populating the countries combo box we trigger the cascading population of the other combo boxes in this name
        PopulateExistingCountries()

        '' Populates the New Name Combo Boxes in the Template Managers tab with all the possible names
        PopulateNewNameComboBoxes()

    End Sub

    Public Sub CreateLegacyCADShortcuts()

        Try
            GeneralMessageBox("Creating legacy Jacobs shortcuts", , , , , , , , True, LogName)

            Dim CommonDesktop As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDesktopDirectory).CombinePath("Jacobs AutoCAD")

            Dim ProfilesFolder As String = "[BUNDLECONTENTS]"

            If System.IO.Directory.Exists(ProfilesFolder) Then
                For Each File As String In System.IO.Directory.GetFiles(ProfilesFolder, "*.ARG", SearchOption.AllDirectories)

                    Dim LinkFileName As String = System.IO.Path.GetFileNameWithoutExtension(File).Replace("2017_", "AutoCAD 2017 ")
                    LinkFileName = LinkFileName.Replace("_", " ") & ".lnk"

                    If Not System.IO.File.Exists(CommonDesktop.CombinePath(LinkFileName)) Then

                        ' To Create or modify Shortcut on the desktop
                        Jacobs.Common.Core.Environment.CreateShortCut(LinkFileName,
                        CommonDesktop,
                        Jacobs.Common.Settings.Settings.Manager.AutoCAD.Path.CombinePath("Acad.exe"),
                        Jacobs.Common.Settings.Settings.Manager.AutoCAD.Path,
                        Jacobs.Common.Settings.Settings.Manager.AutoCAD.Path.CombinePath("Acad.exe"), 0,
                        "-p """ & File & """")
                        GeneralMessageBox("Creating legacy Jacobs shortcut: " & LinkFileName, , , , , , , , True, LogName)
                    End If

                Next
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, , LogName)
        End Try

    End Sub
    Public Sub DeleteLegacyCADShortCuts()

        Try
            GeneralMessageBox("Deleting legacy Jacobs shortcuts", , , , , , , , True, LogName)
            Dim CommonDesktop As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDesktopDirectory).CombinePath("Jacobs AutoCAD")
            If System.IO.Directory.Exists(CommonDesktop) Then
                For Each File As String In System.IO.Directory.GetFiles(CommonDesktop)
                    Jacobs.Common.Core.Files.Delete(File)
                    GeneralMessageBox("Deleting: " & File, , , , , , , , True, LogName)
                Next
            End If

        Catch Ex As Exception
            GeneralExceptionMessageBox(Ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, , LogName)
        End Try

    End Sub
#End Region

#Region "Helper Functions"

    ''' <summary>
    ''' Check to see if the logged in user is a nominated Template Builder - by reading the ConfigBuilder.txt file
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsUserValidTemplateAdministrator() As Boolean

        Dim Result As Boolean = False

        Try

            If File.Exists(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName)) Then

                Dim aFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName))

                For Each Str As String In aFileRead
                    '' Get logged in user name and check if they are allowed to create configs.
                    If Str.ToUpper = Manager.EvaluateExpression(Settings.Manager.UserName).ToUpper Then

                        Result = True

                        Exit For
                    End If
                Next

            Else
                GeneralMessageBox("Error Missing File:" & Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName), System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

        Return Result

    End Function

    ''' <summary>
    ''' 
    ''' Other products tend to hijack the DWG and DWT file extensions on install
    ''' This is an attempt to keep them associated with the AcLauncher.exe
    ''' 
    ''' HKEY_USERS\S-1-5-18\Software\Classes\AutoCADTemplate.21\shell\open\command
    ''' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
    ''' HKEY_USERS\S-1-5-21-117609710-1547161642-725345543-202000\Software\Classes\AutoCADTemplate.21\shell\open\command
    ''' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
    ''' HKEY_USERS\S-1-5-21-117609710-1547161642-725345543-202000_Classes\AutoCADTemplate.21\shell\open\command
    ''' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
    ''' This next bit not working but if I manually delete them they work
    ''' When a user creates these manually they get some kind of extra permissions that don't allow us to delete them
    ''' If they are created by the client selector then it works okay
    ''' RegistryDelete("HKEY_CURRENT_USER", "Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.dwg")
    ''' RegistryDelete("HKEY_CURRENT_USER", "Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.dwt")
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub FileAssociation()

        Try
            '  Dim LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) & Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension)
            GeneralMessageBox("Associating the DWG and DWT file types with the AcadLauncher.exe", , , , , , , , True, LogName)

            '' DWG
            '' HKEY_CURRENT_USER\Software\Classes\AutoCAD.Drawing.21\shell\open\command
            '' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
            GeneralMessageBox("Set the Open HKCU command for AutoCAD DWG files to AcLauncher.exe", , , , , , , , True, LogName)
            RegistryWrite("HKEY_CURRENT_USER", "Software\Classes\AutoCAD.Drawing.21\shell\open\command", "", """C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe"" /O ""%1""", "REG_SZ", True)

            '' HKEY_CLASSES_ROOT\AutoCADDrawing.21\shell\open\command
            '' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
            GeneralMessageBox("Set the Open HKCR command for AutoCAD DWG files to AcLauncher.exe", , , , , , , , True, LogName)
            RegistryWrite("HKEY_CLASSES_ROOT", "AutoCAD.Drawing.21\shell\open\command", "", """C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe"" /O ""%1""", "REG_SZ", True)

            '' HKEY_USERS\.DEFAULT\Software\Classes\AutoCADDrawing.21\shell\open\command
            '' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
            GeneralMessageBox("Set the Open HKU command for AutoCAD DWG files to AcLauncher.exe", , , , , , , , True, LogName)
            RegistryWrite("HKEY_USERS", ".DEFAULT\Software\Classes\AutoCAD.Drawing.21\shell\open\command", "", """C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe"" /O ""%1""", "REG_SZ", True)

            '' DWT
            '' HKEY_CURRENT_USER\Software\Classes\AutoCADTemplate.21\shell\open\command
            '' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
            GeneralMessageBox("Set the Open HKCU command for AutoCAD DWT files to AcLauncher.exe", , , , , , , , True, LogName)
            RegistryWrite("HKEY_CURRENT_USER", "Software\Classes\AutoCADTemplate.21\shell\open\command", "", """C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe"" /O ""%1""", "REG_SZ", True)

            '' HKEY_CLASSES_ROOT\AutoCADTemplate.21\shell\open\command
            '' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
            GeneralMessageBox("Set the Open HKCR command for AutoCAD DWT files to AcLauncher.exe", , , , , , , , True, LogName)
            RegistryWrite("HKEY_CLASSES_ROOT", "AutoCADTemplate.21\shell\open\command", "", """C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe"" /O ""%1""", "REG_SZ", True)

            '' HKEY_USERS\.DEFAULT\Software\Classes\AutoCADTemplate.21\shell\open\command
            '' "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe" /O "%1"
            GeneralMessageBox("Set the Open HKU command for AutoCAD DWT files to AcLauncher.exe", , , , , , , , True, LogName)
            RegistryWrite("HKEY_USERS", ".DEFAULT\Software\Classes\AutoCADTemplate.21\shell\open\command", "", """C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe"" /O ""%1""", "REG_SZ", True)

            '     Associate("DWG", "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe")
            '     Associate("DWT", "C:\Program Files\Common Files\Autodesk Shared\AcShellEx\AcLauncher.exe")

        Catch ex As Exception
            '' Log the error but don't bother user
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, "Error associating DWG and DWT with ACLauncher.exe - " & ex.Message, LogName)
        End Try

    End Sub

    ''' <summary>
    ''' This function won't work if the user changes the file association manually because 
    ''' 
    ''' We would need to delete these two Protected Registry Keys
    '''
    '''  HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.dwg\UserChoice
    '''  ProgID
    ''' AND
    '''  HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.dwt\UserChoice
    '''  ProgID
    ''' 
    ''' Hopefully the Bentley guys haven't worked out how to modify the ProdgID in these hives
    ''' If they are using our method this should work OK
    ''' 
    ''' </summary>
    ''' <param name="extension"></param>
    ''' <param name="TxtProgram"></param>
    ''' <remarks></remarks>
    Private Sub Associate(ByVal extension As String, ByVal TxtProgram As String)

        'Ensure the extension has a leading dot
        If Not extension.StartsWith(".") Then extension = "." & extension
        Dim fileTypeName As String = extension.Substring(1, extension.Length - 1)
        My.Computer.Registry.ClassesRoot.CreateSubKey(extension).SetValue("", fileTypeName, Microsoft.Win32.RegistryValueKind.String)
        My.Computer.Registry.ClassesRoot.CreateSubKey(fileTypeName & "\shell\open\command").SetValue("", TxtProgram & " ""%l"" ", Microsoft.Win32.RegistryValueKind.String)

    End Sub

    ''' <summary>
    ''' Look through all the AutoCAD and Microstation products in the Configuration.XML file if they are installed on the PC then add them to the combo box
    ''' Set the last used one if there was one recorded in the registry. Else set it to the first one on the list.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateProductComboBox()

        Try

            ProductComboBox.Items.Clear()

            '' Get all AutoCAD products installed on this PC and populate the combo box
            '' Restrict to 2017 products
            For Each Acad As Manager.AutoCADProduct In Settings.Manager.AutoCADs
                If RegistryValueExists("HKLM", Acad.RegKey, Acad.CheckKeyForProductExist) Then
                    If Acad.Name.Contains("2017") Then
                        ProductComboBox.Items.Add(Acad.Name)
                    End If
                End If
            Next

            ProductComboBox.Text = ProductComboBox.Items(0).ToString

            '' Look in registry for previous run values
            Dim lastprod As String = Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, Settings.Manager.AE.LastUsedProductName)

            ' If we had recorded the last used product then make it current in the combo box
            If Not String.IsNullOrEmpty(lastprod) Then
                ProductComboBox.Text = lastprod              ' Just the name
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub EditFileWithNotepad(ByVal sLogFile As String)

        Try
            If System.IO.File.Exists(sLogFile) Then
                Shell("NOTEPAD.EXE " & sLogFile, AppWinStyle.MaximizedFocus, True)
                CopySettingsToSettingsWorkingArea(sLogFile)
            Else
                MessageBox.Show("No Log file present at this time." & vbCrLf & sLogFile, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub
    Private Sub LoadPartialMenus()
        Try
            'Find bundle contain folders
            Dim ApplicationPluginsFolder As String = Jacobs.Common.Settings.Manager.EvaluateExpression("[PROGRAMFILES]" & "\" & "[APPLICATIONPLUGINS]") '=  "C:\Program Files\Autodesk\ApplicationPlugins
            If Directory.Exists(ApplicationPluginsFolder) Then 'Check to see if the ApplicationPluginFolder exists
                Dim Folder As DirectoryInfo = New DirectoryInfo(ApplicationPluginsFolder) 'Extracts each folder from the ApplicationPlugins
                Dim BundleFolders As DirectoryInfo() = Folder.GetDirectories("*.bundle") 'Extracts the Bundle content folders
                For Each BundleFolder As DirectoryInfo In BundleFolders 'Extracts each of the Bundle folders
                    Dim XmlFile As FileInfo() = BundleFolder.GetFiles("*.xml", SearchOption.TopDirectoryOnly) 'Extracts the xml filename from each bundle folders
                    Dim PartialMenuEnabled As Boolean = CType(Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, Microsoft.VisualBasic.Strings.Left(BundleFolder.Name, Len(BundleFolder.Name) - 7), "False"), Boolean)
                    If XmlFile.Length = 1 Then 'Check to see if there is more tham xml files
                        If PartialMenuEnabled = True Then 'Checks to see if the menu is to be enabled
                            If XmlFile(0).Name.Contains("-Disabled") = True Then 'Checks if the Xml file has been disabled in the past
                                My.Computer.FileSystem.RenameFile(XmlFile(0).FullName, Microsoft.VisualBasic.Strings.Left(XmlFile(0).Name, Len(XmlFile(0).Name) - 9)) 'Adds Disabled to the xml file name
                            End If
                        End If
                        If PartialMenuEnabled = False Then 'Checks to see if the menu is to be disabled
                            If XmlFile(0).Name.Contains("-Disabled") = False Then 'Checks if the Xml file has been disabled in the past
                                My.Computer.FileSystem.RenameFile(XmlFile(0).FullName, XmlFile(0).Name & "-Disabled") 'Adds Disabled to the xml file name
                            End If
                        End If
                    Else
                        If PartialMenuEnabled = True Then 'Checks to see if the menu is to be enabled
                            If XmlFile(0).Name.Contains("-Disabled") = True Then 'Checks if the Xml file has been disabled in the past
                                My.Computer.FileSystem.DeleteFile(XmlFile(0).FullName)
                            Else
                                My.Computer.FileSystem.DeleteFile(XmlFile(1).FullName)
                            End If
                        End If
                        If PartialMenuEnabled = False Then 'Checks to see if the menu is to be disabled
                            If XmlFile(0).Name.Contains("-Disabled") = True Then 'Checks if the Xml file has been disabled in the past
                                My.Computer.FileSystem.DeleteFile(XmlFile(1).FullName)
                            Else
                                My.Computer.FileSystem.DeleteFile(XmlFile(0).FullName)
                            End If
                        End If
                    End If
                Next
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try
    End Sub
    Private Function PingAsset(ByVal AssetNumber As String) As Boolean

        Dim result As Boolean = False

        Try
            If My.Computer.Network.Ping(AssetNumber) Then
                result = True
            Else
                GeneralMessageBox("Ping request to " & AssetNumber & " timed out. Deployment aborted.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                result = False
            End If
        Catch ex As Exception
            GeneralMessageBox(AssetNumber & " may Not exist. Deployment aborted.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
            result = False
        End Try

        Return result

    End Function

    Private Sub LaunchAutoCAD(Optional ByVal sConfigName As String = "")

        'If UCase(ProductComboBox.Text) Like UCase("micro*") Then

        '    GeneralMessageBox("The Microstation range of products Is Not currently accessible via this interface." & vbCrLf &
        '            "In future releases it will be. " & vbCrLf &
        '            "In the meantime please use the dedicated Microstation AE Icon on your desktop", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
        '    Exit Sub

        'End If

        LoadPartialMenus()

        If (sConfigName <> "") Then

            ' Opening an AutoCAD Session by selected configuration

            Dim sTemplateName As String

            If sConfigName.ToUpper.Contains(".DWG") Then
                sTemplateName = sConfigName
            Else
                ' Look for the template file that belongs to the configuration
                sTemplateName = Settings.Manager.AE.ClientsConfigurationPath & "\" & sConfigName & "\Support\" & sConfigName & ".dwt"
            End If

            ' Sets the /t flag to open a template file
            SetLastUsedProduct(True)

            RunCADApplication(sTemplateName)

        Else

            '' Open Standard Application
            GetAcadConfigSettings(ProductComboBox.Text)

            ' Sets the /t flag to open templates
            SetLastUsedProduct(True)

            RunCADApplication(Settings.Manager.AutoCAD.FileDefaultTemplate)

        End If

        ' Removes the /t flag for templates
        SetLastUsedProduct()

        GeneralMessageBox("Process Running Check:  " & Settings.Manager.AutoCAD.Path.CombinePath("Acad.exe"), , , , , , , , True, LogName)

        If IsAlreadyRunning(Settings.Manager.AutoCAD.Path.CombinePath("Acad.exe")) = True Then
            ProfileComboBox.Enabled = False
            ProductComboBox.Enabled = False

        Else
            ProfileComboBox.Enabled = True
            ProductComboBox.Enabled = True

        End If

    End Sub

    Public Sub MakeConfig(ByVal FromConfigName As String, ByVal ToConfigName As String)

        Try

            Dim Source As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(FromConfigName)
            Dim Destination As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(ToConfigName))

            If System.IO.Directory.Exists(Destination) = True Then
                If GeneralMessageBox("The destination folder " & Destination & " already exists." & vbCrLf &
                                     "Would you like to delete it and start fresh ?" & vbCrLf &
                                     "Selecting No will allow you to continue editing this template.", , MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , True, False, LogName) = Windows.Forms.DialogResult.Yes Then

                    System.IO.Directory.Delete(Destination, True)
                    If File.Exists(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt")) Then
                        System.IO.File.Delete(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt"))
                    End If

                    GeneralMessageBox("Template working folder deleted: " & Destination, , , , , , , , , LogName)

                    System.IO.Directory.CreateDirectory(Destination)

                    CopyDirectory(Source, Destination)

                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwg")) Then
                        System.IO.File.Copy(Destination.CombinePath("Support", FromConfigName & ".dwg"), Destination.CombinePath("Support", NewConfigName & ".dwg"))
                    End If

                    ' The Global ALL ALL ALL DWT exists?
                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwt")) Then
                        System.IO.File.Copy(Destination.CombinePath("Support", FromConfigName & ".dwt"), Destination.CombinePath("Support", NewConfigName & ".dwt"))
                    End If

                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwt")) Then
                        System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwt"))
                    End If

                    '' Clean up
                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwg")) Then
                        System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwg"))
                    End If

                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".bak")) Then
                        System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".bak"))
                    End If

                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwl")) Then
                        System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwl"))
                    End If

                    If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwl2")) Then
                        System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwl2"))
                    End If

                Else
                    GeneralMessageBox("The New Template was not deleted: " & Path.GetFileNameWithoutExtension(Destination) & vbCrLf &
                                      "You may now continue modifying the template.", , , MessageBoxIcon.Information, , , , True, False, LogName)
                End If
            Else

                System.IO.Directory.CreateDirectory(Destination)

                CopyDirectory(Source, Destination)

                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwg")) Then
                    System.IO.File.Copy(Destination.CombinePath("Support", FromConfigName & ".dwg"), Destination.CombinePath("Support", NewConfigName & ".dwg"))
                End If

                ' The Global ALL ALL ALL DWT exists?
                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwt")) Then
                    System.IO.File.Copy(Destination.CombinePath("Support", FromConfigName & ".dwt"), Destination.CombinePath("Support", NewConfigName & ".dwt"))
                End If

                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwt")) Then
                    System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwt"))
                End If

                '' Clean up
                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwg")) Then
                    System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwg"))
                End If

                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".bak")) Then
                    System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".bak"))
                End If

                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwl")) Then
                    System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwl"))
                End If

                If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwl2")) Then
                    System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwl2"))
                End If

            End If

            WriteTriggerFile(ToConfigName)

            '' Launch AutoCAD
            LaunchAutoCAD(Destination.CombinePath("Support", ToConfigName & ".dwg"))

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Public Sub NewConfig()

        Try
            MakeConfig("Global-All-All-All", NewConfigName)

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Create a new configuration (template) using an existing one.
    ''' Copy the folder across
    ''' Rename the DWG to have the new name
    ''' Stamp the DWG file with the FullConfigName and ConfigLevel Rules
    ''' Delete the old DWG and DWT files
    ''' Use the new DWG file which is already stamped to create a DWT file.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub NewUsing()

        Try
            MakeConfig(ExistingConfigName, NewConfigName)

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub NewUsingUserProvided()

        Try
            Dim FromConfigName As String = "Global-All-All-All"
            Dim UserProvidedDWGFile As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(FromConfigName)
            Dim GetFileDialog As New OpenFileDialog

            GetFileDialog.Multiselect = False
            GetFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
            GetFileDialog.Filter = "Drawing files (*.dwg)|*.dwg|Drawing Template files (*.dwt)|*.dwt"
            GetFileDialog.Title = "Select a user provided DWG or DWT file to use for the basis of this Template"
            GetFileDialog.RestoreDirectory = True

            If GetFileDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
                UserProvidedDWGFile = GetFileDialog.FileName
            Else
                Exit Sub
            End If

            If Not (UserProvidedDWGFile.ToUpper.Contains(".DWT") Or UserProvidedDWGFile.ToUpper.Contains(".DWG")) Then

                GeneralMessageBox("Invalid file type selected.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                Exit Sub

            End If

            '' Little different here as we want all the Settings files from corporate Global-All-All-All and only the DWG or DWT file from the user selected one
            Dim Source As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(FromConfigName)
            Dim Destination As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(NewConfigName))

            System.IO.Directory.CreateDirectory(Destination)

            CopyDirectory(Source, Destination)

            If UserProvidedDWGFile.ToUpper.Contains(".DWG") Then
                If System.IO.File.Exists(UserProvidedDWGFile) Then
                    System.IO.File.Copy(UserProvidedDWGFile, Destination.CombinePath("Support", NewConfigName & ".dwg"))
                End If
            End If

            If UserProvidedDWGFile.ToUpper.Contains(".DWT") Then
                If System.IO.File.Exists(UserProvidedDWGFile) Then
                    System.IO.File.Copy(UserProvidedDWGFile, Destination.CombinePath("Support", NewConfigName & ".dwg"))
                End If
            End If

            If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwt")) Then
                System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwt"))
            End If

            If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwg")) Then
                System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwg"))
            End If

            If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".bak")) Then
                System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".bak"))
            End If

            If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwl")) Then
                System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwl"))
            End If

            If System.IO.File.Exists(Destination.CombinePath("Support", FromConfigName & ".dwl2")) Then
                System.IO.File.Delete(Destination.CombinePath("Support", FromConfigName & ".dwl2"))
            End If

            '   StatusLabel.Text = "WritingTrigger File for: " & NewConfigName
            WriteTriggerFile(NewConfigName)

            '  StatusLabel.Text = "Launching " & ProductComboBox.Text & " with: " & sPath.CombinePath("Support", NewConfigName & ".DWG")
            '' Launch AutoCAD with the DWG file just created
            LaunchAutoCAD(Destination.CombinePath("Support", NewConfigName & ".DWG"))

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub ModifyConfig()

        Try
            Dim sPath As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(ExistingConfigName)

            Dim Destination As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(ExistingConfigName))

            System.IO.Directory.CreateDirectory(Destination)

            CopyDirectory(sPath, Destination)

            WriteTriggerFile(ExistingConfigName)

            LaunchAutoCAD(Destination.CombinePath("Support", ExistingConfigName & ".DWG"))

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub WriteTriggerFile(ByVal newconfigname As String)

        Try
            Dim TriggerFile As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt")
            If System.IO.File.Exists(TriggerFile) Then
                System.IO.File.Delete(TriggerFile)
            End If
            WriteLineToTextFile(TriggerFile, newconfigname)
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub ClearAllExistingComboBoxes()

        Try

            ExistingCountriesComboBox.Items.Clear()
            ExistingRegionsComboBox.Items.Clear()
            ExistingClientsComboBox.Items.Clear()
            ExistingDisciplinesComboBox.Items.Clear()

            ExistingCountriesComboBox.Text = String.Empty
            ExistingRegionsComboBox.Text = String.Empty
            ExistingClientsComboBox.Text = String.Empty
            ExistingDisciplinesComboBox.Text = String.Empty

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub ClearAllListBoxes()

        Try

            CountriesListBox.Items.Clear()
            RegionsListBox.Items.Clear()
            ClientsListBox.Items.Clear()
            DisciplinesListBox.Items.Clear()

            'ExistingCountriesComboBox.Text = String.Empty
            'ExistingRegionsComboBox.Text = String.Empty
            'ExistingClientsComboBox.Text = String.Empty
            'ExistingDisciplinesComboBox.Text = String.Empty

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub


    ''' <summary>
    ''' Launches the selected product
    ''' If the product has not been run before it calls the EXE file directly (eg. Acad.exe)
    ''' If the product has been run before it calls the DWT or DWG file and lets AcLauncher.EXE work out what to open it with
    ''' This enables us to use the smarts in AcLauncher.exe to work out if a product is already running to open the files in the running application.
    ''' 
    ''' </summary>
    ''' <param name="sDrawingName"></param>
    ''' <remarks></remarks>
    Private Sub RunCADApplication(ByVal sDrawingName As String)

        Try

            Dim startInfo As New ProcessStartInfo

            If System.IO.File.Exists(sDrawingName) Then

                FileAssociation()
                SetLastUsedProduct(True)

                '' Check if AutoCAD product has been run once...
                If RegistryValueExists("HKCU", Settings.Manager.AutoCAD.RegKey, Settings.Manager.AutoCAD.CheckKeyForProductRun) = False Then
                    '' Can't rely on AcLauncher.exe as the selected Product has not been run yet..?
                    startInfo.FileName = Settings.Manager.AutoCAD.AutoCADLaunchString
                    startInfo.Arguments = " /t """ & sDrawingName & """" & " /p """ & ProfileComboBox.Text & """"
                    startInfo.UseShellExecute = False
                Else
                    '' This relies on AcLauncher.exe which is what the DGW and DWT file format should be associated with to launch Autocad.
                    startInfo.FileName = sDrawingName
                    'startInfo.UseShellExecute = String.Empty
                End If

                GeneralMessageBox("Executing Process: " & startInfo.FileName & vbCrLf & "With these arguments: " & startInfo.Arguments, , , , , , , , True, LogName)

                Process.Start(startInfo)

                ' Set AutoCAD to be AutoCAD
                SetLastUsedProduct()

            Else
                GeneralMessageBox("File not yet available: " & sDrawingName, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , True, True, LogName)
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub
    ''' <summary>
    ''' 
    ''' All viable installed programs will already have a folder in:
    ''' HKEY_CURRENT_USER\Software\Autodesk\DwgCommon\shellex\apps\
    ''' example: I have AutoCAD, AutoCAD Mechanical, and Inventor
    ''' HKEY_CURRENT_USER\Software\Autodesk\DwgCommon\shellex\apps{56A0F03C-50A5-425e-B919-1E5E40FA0168}:AcadMPP
    ''' HKEY_CURRENT_USER\Software\Autodesk\DwgCommon\shellex\apps{DE84900D-6D4B-7345-89E6-FB89C7CF723F}:Inventor
    ''' HKEY_CURRENT_USER\Software\Autodesk\DwgCommon\shellex\apps{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD
    ''' In the folder for the program you want to launch edit the "DefaultResourceLCID" string value so it is empty.
    ''' The "DefaultResourceLCID" string value for all other programs should be "enu"(without the quotes) .
    ''' ONLY ONE KEY SHOULD HAVE A BLANK VALUE DATA FOR "DefaultResourceLCID"
    ''' ALL OTHERS SHOULD BE "enu"
    ''' 
    ''' The comment above may be correct for other versions... however.
    ''' In the 2017 products for some reason they don't separate the products - they all sit under 
    ''' Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD
    ''' Each of the products Map AutoCAD and Civil change the sub keys under that hive
    ''' 
    ''' Remember to set the default one here so that ACLauncher Knows what to do.
    '''                Software\Autodesk\DwgCommon\shellex\apps
    ''' 
    ''' </summary>
    ''' <remarks></remarks>

    Private Sub SetLastUsedProduct(Optional ByVal Template As Boolean = False)

        Try
            ' check if AutoCAD is running and gray out profile combo box if it is..
            GeneralMessageBox("Process Running Check: " & Settings.Manager.AutoCAD.Path.CombinePath("Acad.exe") & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , , , , , , True, LogName)

            If IsAlreadyRunning(Settings.Manager.AutoCAD.Path.CombinePath("Acad.exe")) = True Then
                PopulateProfileComboBox()
                ProfileComboBox.Enabled = False
                ProductComboBox.Enabled = False

            Else
                ProfileComboBox.Enabled = True
                ProductComboBox.Enabled = True

            End If

            GeneralMessageBox("Recording last used Product Details in HKCU", , , , , , , , True, LogName)
            GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & Settings.Manager.AE.AEWorkingRegKey & vbCrLf & "KEY: " & Settings.Manager.AE.LastUsedProductInClientselector & vbCrLf & "VALUE: " & Settings.Manager.AutoCAD.AutoCADLaunchString & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)
            RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, Settings.Manager.AE.LastUsedProductInClientselector, Settings.Manager.AutoCAD.AutoCADLaunchString, "REG_SZ")
            GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & Settings.Manager.AE.AEWorkingRegKey & vbCrLf & "KEY: " & Settings.Manager.AE.LastUsedProductName & vbCrLf & "VALUE: " & ProductComboBox.Text & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)

            If ProductComboBox.Text.Contains("AutoCAD 2017") Then
                If RegistryValueExists("HKCU", "Software\Autodesk\AutoCAD\R21.0\Acad-0001:409\Profiles", "") = True Then

                    GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & "Software\Autodesk\AutoCAD\R21.0\Acad-0001:409\Profiles" & vbCrLf & "KEY: " & "@" & "VALUE: " & ProfileComboBox.Text & "Type: " & "REG_SZ", , , , , , , , True)
                    RegistryWrite("HKCU", "Software\Autodesk\AutoCAD\R21.0\Acad-0001:409\Profiles", "", ProfileComboBox.Text, "REG_SZ")

                End If

                If Template = False Then

                    GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD" & vbCrLf & "KEY: " & "OpenLaunch" & vbCrLf & "VALUE: " & """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" ""%1"" /p """ & ProfileComboBox.Text & """" & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)
                    RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")

                Else
                    GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD" & vbCrLf & "KEY: " & "OpenLaunch" & vbCrLf & "VALUE: " & """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /t ""%1"" /p """ & ProfileComboBox.Text & """" & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)
                    RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /t ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")

                End If


                GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD" & vbCrLf & "KEY: " & "PrintLaunch" & vbCrLf & "VALUE: " & """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /print ""%1""" & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)
                RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "PrintLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /print ""%1""", "REG_SZ")
                GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & "Software\Autodesk\AutoCAD\R21.0" & vbCrLf & "KEY: " & "CurVer" & vbCrLf & "VALUE: " & "Acad-0001:409" & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)

                ' Set the last product used version for AutoCAD
                RegistryWrite("HKCU", "Software\Autodesk\AutoCAD\R21.0", "CurVer", "Acad-0001:409", "REG_SZ")
                GeneralMessageBox("Writing: " & vbCrLf & "AREA: " & "HKCU" & vbCrLf & "HIVE: " & "Software\Autodesk\DwgCommon\shellex\apps" & vbCrLf & "KEY: " & "@" & vbCrLf & "VALUE: " & "{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD" & vbCrLf & "Type: " & "REG_SZ", , , , , , , , True)

            End If

            'If ProductComboBox.Text.Contains("Map 3D") Then

            '    If RegistryValueExists("HKCU", "Software\Autodesk\AutoCAD\R21.0\Acad-0002:409\Profiles", "") = True Then
            '        RegistryWrite("HKCU", "Software\Autodesk\AutoCAD\R21.0\Acad-0002:409\Profiles", "", ProfileComboBox.Text, "REG_SZ")
            '    End If

            '    If Template = False Then
            '        RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD Map 3D 2017\Acad.exe"" ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")
            '    Else
            '        RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD Map 3D 2017\Acad.exe"" /t ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")
            '    End If

            '    RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "PrintLaunch", """C:\Program Files\Autodesk\AutoCAD Map 3D 2017\Acad.exe"" /print ""%1""", "REG_SZ")

            '    ' Set the last product used version for AutoCAD Map 3D
            '    RegistryWrite("HKCU", "Software\Autodesk\AutoCAD\R21.0", "CurVer", "Acad-0002:409", "REG_SZ")

            '    ' Make AutoCAD MAP the default one to use
            '    RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps", "", "{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "REG_SZ")

            'End If

            If ProductComboBox.Text.Contains("Civil 3D") Then
                If RegistryValueExists("HKCU", "Software\Autodesk\AutoCAD\R21.0\Acad-0000:409\Profiles", "") = True Then
                    RegistryWrite("HKCU", "Software\Autodesk\AutoCAD\R21.0\Acad-0000:409\Profiles", "", ProfileComboBox.Text, "REG_SZ")
                End If

                If Template = False Then
                    'RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")
                    RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", Chr(34) & "C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe" & Chr(34) & "/ld " & Chr(34) & "C:\Program Files\Autodesk\AutoCAD 2017\\AecBase.dbx" & Chr(34) & "/p " & Chr(34) & ProfileComboBox.Text & Chr(34) & "/product " & Chr(34) & "C3D" & Chr(34) & "/language " & Chr(34) & "en-US" & Chr(34), "REG_SZ")
                    '                                                                                                                                                                   "C:\Program Files\Autodesk\AutoCAD 2017\acad.exe" /ld "C:\Program Files\Autodesk\AutoCAD 2017\\AecBase.dbx" /p "<<C3D_Metric>>" /product "C3D" /language "en-US"
                Else
                    'RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /t ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")
                    RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "OpenLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /t ""%1"" /p """ & ProfileComboBox.Text & """", "REG_SZ")
                End If

                RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps\{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "PrintLaunch", """C:\Program Files\Autodesk\AutoCAD 2017\Acad.exe"" /print ""%1""", "REG_SZ")

                ' Set the last product used version for AutoCAD Civil 3D
                RegistryWrite("HKCU", "Software\Autodesk\AutoCAD\R21.0", "CurVer", "Acad-0000:409", "REG_SZ")

            End If

            GeneralMessageBox("Telling AcadLauncher.exe which product to use", , , , , , , , True, LogName)

            ' Make AutoCAD the default one to use because depending on the product they would have the correct keys by now
            RegistryWrite("HKCU", "Software\Autodesk\DwgCommon\shellex\apps", "", "{F29F85E0-4FF9-1068-AB91-08002B27B3D9}:AutoCAD", "REG_SZ")

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Public Function IsAlreadyRunning(ByVal PathedProgramName As String) As Boolean

        Try
            Dim processName As String = System.IO.Path.GetFileNameWithoutExtension(PathedProgramName)
            For Each p As Process In Process.GetProcessesByName(processName)
                If p.MainModule.FileName.ToUpper = PathedProgramName.ToUpper Then
                    Return True
                End If
            Next p
        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, "Looking for: " & PathedProgramName, LogName)
        End Try

        Return False

    End Function

    Public Function GetAcadConfigSettings(ByVal prodname As String) As Boolean

        Dim Result As Boolean = False

        Try
            '' get current name
            For Each Acad As Manager.AutoCADProduct In Settings.Manager.AutoCADs
                If Acad.Name = prodname Then
                    Settings.Manager.AutoCAD = Acad
                    Result = True
                    Exit For
                End If
            Next Acad

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return Result

    End Function

    Public Function GetAEConfigSettings() As Boolean

        Dim Result As Boolean = False

        Try

            Manager.Register("AEPRODUCTNAME", "Jacobs AutoCAD Environment R21")
            '' get current name
            Dim AEName As String = "Jacobs AutoCAD Environment R21"
            ' Which AE is running now?
            Try
                If IsNothing(Settings.Manager.AEs) Then
                End If
                For Each AEx As Manager.AEProduct In Settings.Manager.AEs
                    If AEx.Name = AEName Then
                        Settings.Manager.AE = AEx
                        Result = True
                        Exit For
                    End If
                Next AEx
            Catch ex As Exception

                GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , "Permission Related Issue only happens on laptops - currently under review.", LogName)
            End Try

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return Result

    End Function

    ''' <summary>
    ''' Funky Code to try and update the core dll and bits and pieces...
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub TryUpdateDFSDownloaderDlls()

        Dim strfrom As String = String.Empty
        Dim strto As String = String.Empty

        Try

            GeneralMessageBox("Attempt to update the DFS Downloader with latest code...", , , , , , , , True, LogName)

            If System.IO.Directory.Exists("C:\Program Files\Jacobs\DFS Manager R20") Then

                GeneralMessageBox("DFS Downloader folder is installed.", , , , , , , , True, LogName)

                If CheckIfRunning("ConsoleDownloader") = False Then

                    strfrom = Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents.CombinePath("Jacobs.Common.Core.DLL")
                    strto = "C:\Program Files\Jacobs\DFS Manager R20\Jacobs.Common.Core.DLL"

                    If System.IO.File.Exists(strfrom) Then
                        System.IO.File.Copy(strfrom, strto, True)
                    End If

                    strfrom = Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents.CombinePath("Jacobs.Common.Settings.DLL")
                    strto = "C:\Program Files\Jacobs\DFS Manager R20\Jacobs.Common.Settings.DLL"
                    If System.IO.File.Exists(strfrom) Then
                        System.IO.File.Copy(strfrom, strto, True)
                    End If

                Else
                    ' Ignore if the Downloader is running
                    ' The console downloader is running at the moment - will try again next time
                End If
            Else

                GeneralMessageBox("DFS Downloader folder is not installed.", , , , , , , , True, LogName)
            End If

        Catch ex As Exception

            ' If permissions don't allow it just log the issue but don't bother user.
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True,
                                 "Ask local IT to check that the USER account and ASSET are both in correct Win 7 OU in AD - Contact CAD Support", LogName)

        End Try

    End Sub

    Private Function CheckIfRunning(ByVal ProcessName As String) As Boolean

        Try

            If Process.GetProcessesByName(ProcessName).Length > 0 Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            '' If in doubt say yes
            Return True
        End Try

    End Function

    ''' <summary>
    ''' Update MyDocument user files for the user if not present
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub UpdateUserFiles()

        Dim strfrom As String = String.Empty
        Dim strto As String = String.Empty

        Try

            GeneralMessageBox("Update User Files if not Present", , , , , , , , True, LogName)

            strfrom = Settings.Manager.AE.AECacheSupport.CombinePath(Settings.Manager.AE.UserPGPFileName)
            strto = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\Settings", Settings.Manager.AE.UserPGPFileName)

            GeneralMessageBox("Checking existence of folder: " & System.IO.Path.GetDirectoryName(strto), , , , , , , , True, LogName)
            If System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(strto)) = False Then
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(strto))
                GeneralMessageBox("Folder Created: " & System.IO.Path.GetDirectoryName(strto), , , , , , , , True, LogName)
            End If

            '' Copy from cache location if not present
            GeneralMessageBox("Checking existence of file: " & strto, , , , , , , , True, LogName)
            If System.IO.File.Exists(strfrom) Then
                If System.IO.File.Exists(strto) = False Then
                    System.IO.File.Copy(strfrom, strto, True)
                    GeneralMessageBox("File not found so this one was copied: " & strfrom, , , , , , , , True, LogName)
                End If
            End If

            strfrom = Settings.Manager.AE.AECacheSupport.CombinePath(Settings.Manager.AE.UserMNLFileName)
            strto = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\Settings", Settings.Manager.AE.UserMNLFileName)

            '' Copy from cache location if not present
            GeneralMessageBox("Checking existence of file: " & strto, , , , , , , , True, LogName)
            If System.IO.File.Exists(strfrom) Then
                If System.IO.File.Exists(strto) = False Then
                    System.IO.File.Copy(strfrom, strto, True)
                    GeneralMessageBox("File not found so this one was copied: " & strfrom, , , , , , , , True, LogName)
                End If
            End If

            strfrom = Settings.Manager.AE.AECacheSupport.CombinePath(Settings.Manager.AE.UserCUIXFileName)
            strto = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\Settings", Settings.Manager.AE.UserCUIXFileName)

            '' Copy from cache location if not present
            GeneralMessageBox("Checking existence of file: " & strto, , , , , , , , True, LogName)
            If System.IO.File.Exists(strfrom) Then
                If System.IO.File.Exists(strto) = False Then
                    System.IO.File.Copy(strfrom, strto, True)
                    GeneralMessageBox("File not found so this one was copied: " & strfrom, , , , , , , , True, LogName)
                End If
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, True, , LogName)
        End Try

    End Sub

#End Region

#Region "Enabling and Disabling Controls"

    ''' <summary>
    ''' SCCM Deployments don't leave the MSI files locally on the PC. They reside in a network location on the Domain
    ''' Users should not perform a reset if the network folder is not accessible - as the secondary stage installers will not function
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub EnableDisableResetButtons()

        Try

            '' SCCM Deployments don't leave the MSI files locally on the PC they reside in a network location
            '' Users should not perform a reset if the network folder is not accessible - as the secondary stage installers will not function

            GeneralMessageBox("Checking if Reset and Reset All buttons should be disabled", , , , , , , , True, LogName)

            If SourceMSIsArePresent(ProductComboBox.Text) = True Then
                '     ResetAllButton.Enabled = True
                ResetSelectedButton.Enabled = True
                GeneralMessageBox("Reset buttons enabled", , , , , , , , True, LogName)
            Else
                '    ResetAllButton.Enabled = False
                ResetSelectedButton.Enabled = False
                GeneralMessageBox("Reset buttons disabled", , , , , , , , True, LogName)
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

        '    '' Check that we can see one of the local DFS replicated shares
        '    If Directory.Exists(Settings.Manager.AE.DFSDownloadSettingsPath) Then
        '        '' Yes we can so enable the resets
        '        ResetAllButton.Enabled = True
        '        ResetSelectedButton.Enabled = True
        '        GeneralMessageBox("Reset and Reset All buttons enabled", , , , , , , , True, LogName)
        '    Else
        '        '' No we can't so enable the resets
        '        ResetAllButton.Enabled = False
        '        ResetSelectedButton.Enabled = False
        '        GeneralMessageBox("Reset and Reset All buttons disabled", , , , , , , , True, LogName)
        '    End If
        'Catch ex As Exception
        '    GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        'End Try

    End Sub

    Public Sub EnableDisableAEButtons()
        Try

            If System.IO.File.Exists(System.IO.Directory.GetParent(Settings.Manager.AE.AEBundleContents).FullName.CombinePath("PackageContents.xml")) Then
                DisableAEButton.Enabled = True
                EnableAEButton.Enabled = False
            Else
                DisableAEButton.Enabled = False
                EnableAEButton.Enabled = True
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", "")
        End Try

    End Sub
    ''' <summary>
    ''' Enables the controls on the Template Builder TAB 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DisableTemplateTabControls()
        GeneralMessageBox("Disabling - TemplateManagement and TemplateDeployment tabs as this user is not a content builder.", , , , , , , , True, LogName)
        MainTabControl.TabPages.RemoveByKey("TemplateManagement")
        MainTabControl.TabPages.RemoveByKey("TemplateDeployment")
    End Sub

    ''' <summary>
    ''' Enables the controls on the Template Builder TAB 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DisableAdminitrationTabControls()
        GeneralMessageBox("Disabling - AEAdministration and AdministrationDeployment tabs as this user is not an administrator.", , , , , , , , True, LogName)
        MainTabControl.TabPages.RemoveByKey("AEAdministration")
        MainTabControl.TabPages.RemoveByKey("AdministrationDeployment")
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Sizable
    End Sub

    Private Sub EnableDisableProjectWiseButtons()

        Try

            Dim Root As String = "HKLM"

            ' AutoCAD - Assumption made that all PCs have AutoCAD no need to check other products.
            '' We could use Selected Product as well but don;t think there is a need
            'HKEY_LOCAL_MACHINE\SOFTWARE\Autodesk\AutoCAD\R21.0\Acad-0001:409\Applications\ProjectWise

            If RegistryValueExists(Root, "SOFTWARE\Autodesk\AutoCAD\R21.0\Acad-0001:409\Applications\ProjectWise", "LOADER") = True Then
                ProjectWiseOnButton.Enabled = False
                ProjectWiseOffButton.Enabled = True
            Else
                ProjectWiseOnButton.Enabled = True
                ProjectWiseOffButton.Enabled = False
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", "")
        End Try

    End Sub

    Private Sub EnableDisableStartButton()

        If DisciplinesListBox.SelectedIndex <> -1 Then
            OK_Button.Enabled = True
        Else
            OK_Button.Enabled = False
        End If

    End Sub

    Private Sub EnableDisableSelectNewGroupBoxes()

        Try
            If NewRadioButton.Checked = True Or NewUsingUserProvidedRadioButton.Checked = True Then
                SelectExistingGroupBox.Enabled = False
                SelectExistingGroupBox.Visible = False
                NewGroupBox.Enabled = True
                NewGroupBox.Visible = True
            End If
            If ModifyRadioButton.Checked = True Then ' Or DeployRadioButton.Checked = True Then
                SelectExistingGroupBox.Enabled = True
                SelectExistingGroupBox.Visible = True
                NewGroupBox.Enabled = False
                NewGroupBox.Visible = False
            End If
            If NewUsingRadioButton.Checked = True Then
                SelectExistingGroupBox.Enabled = True
                SelectExistingGroupBox.Visible = True
                NewGroupBox.Enabled = True
                NewGroupBox.Visible = True
            End If
            If RemoveRadioButton.Checked = True Then
                SelectExistingGroupBox.Enabled = True
                SelectExistingGroupBox.Visible = True
                NewGroupBox.Enabled = False
                NewGroupBox.Visible = False
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub EnableDisableProcessButton()

        Try
            If NewRadioButton.Checked = True Or NewUsingUserProvidedRadioButton.Checked = True Then
                If CountriesComboBox.Text = String.Empty Or
                    RegionsComboBox.Text = String.Empty Or
                    ClientTextBox.Text = String.Empty Or
                    DisciplinesComboBox.Text = String.Empty Then
                    ProcessTemplateOKButton.Enabled = False
                    Exit Sub
                Else
                    NewConfigName = CountriesComboBox.Text & "-" & RegionsComboBox.Text & "-" & ClientTextBox.Text & "-" & DisciplinesComboBox.Text
                    If System.IO.Directory.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewConfigName)) Then
                        GeneralMessageBox("New Configuration Name " & ClientTextBox.Text & " already exists try a different name.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                        ClientTextBox.Clear()
                        ProcessTemplateOKButton.Enabled = False
                    Else
                        ProcessTemplateOKButton.Enabled = True
                    End If
                End If
            End If
            If ModifyRadioButton.Checked = True Then 'Or DeployRadioButton.Checked = True Then
                If ExistingCountriesComboBox.Text = String.Empty Or
                    ExistingRegionsComboBox.Text = String.Empty Or
                    ExistingClientsComboBox.Text = String.Empty Or
                    ExistingDisciplinesComboBox.Text = String.Empty Then
                    ProcessTemplateOKButton.Enabled = False
                    Exit Sub
                Else
                    ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text
                    ProcessTemplateOKButton.Enabled = True
                End If
            End If
            If NewUsingRadioButton.Checked = True Then
                If CountriesComboBox.Text = String.Empty Or
                    RegionsComboBox.Text = String.Empty Or
                    ClientTextBox.Text = String.Empty Or
                    DisciplinesComboBox.Text = String.Empty Or
                    ExistingCountriesComboBox.Text = String.Empty Or
                    ExistingRegionsComboBox.Text = String.Empty Or
                    ExistingClientsComboBox.Text = String.Empty Or
                    ExistingDisciplinesComboBox.Text = String.Empty Then
                    ProcessTemplateOKButton.Enabled = False
                    Exit Sub
                Else
                    NewConfigName = CountriesComboBox.Text & "-" & RegionsComboBox.Text & "-" & ClientTextBox.Text & "-" & DisciplinesComboBox.Text
                    ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text

                    If System.IO.Directory.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewConfigName)) Then
                        GeneralMessageBox("New Configuration Name " & ClientTextBox.Text & " already exists try a different name.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                        ClientTextBox.Clear()
                        ProcessTemplateOKButton.Enabled = False
                    Else
                        ProcessTemplateOKButton.Enabled = True
                    End If

                End If
            End If
            If RemoveRadioButton.Checked = True Then
                If ExistingCountriesComboBox.Text = String.Empty Or
                    ExistingRegionsComboBox.Text = String.Empty Or
                    ExistingClientsComboBox.Text = String.Empty Or
                    ExistingDisciplinesComboBox.Text = String.Empty Then
                    ProcessTemplateOKButton.Enabled = False
                    Exit Sub
                Else
                    ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text
                    ProcessTemplateOKButton.Enabled = True
                End If
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

#End Region

#Region "List Box Management Using Templates Tab"

    Sub PopulateListBoxes()
        Try
            ContentsReportListBox.Items.Clear()
            If String.IsNullOrEmpty(CountriesListBox.Text) Then
                PopulateCountryListBox()
            Else
                If String.IsNullOrEmpty(RegionsListBox.Text) Then
                    PopulateRegionListBox()
                Else
                    If String.IsNullOrEmpty(ClientsListBox.Text) Then
                        PopulateClientListBox()
                    Else
                        If String.IsNullOrEmpty(DisciplinesListBox.Text) Then
                            PopulateDisciplinesListBox()
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' Populates the Country List box in the first Tab "Using Template"
    ''' Based on the collection created by reading the directories in the Clients folder
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <remarks></remarks>
    Private Sub PopulateCountryListBox(Optional ByRef Value As Object = Nothing)

        Try
            Me.CountriesListBox.Items.Clear()
            For Each Item As String In cDirectoryEntries
                Dim SplitDir() As String = Item.Split("-"c)

                If SplitDir.Length = 4 Then
                    If Not FindStringInListBox(SplitDir(cfgCountry), CountriesListBox) Then
                        Me.CountriesListBox.Items.Add(SplitDir(cfgCountry))
                    End If
                Else
                    GeneralMessageBox("Invalid Template Folder Name: " & Item, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Regions List Box - this is exactly the same as the Populate Regions Combo box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateRegionListBox(Optional ByRef Value As Object = Nothing)

        Try
            Me.RegionsListBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                If SplitDir(cfgCountry).ToUpper = CountriesListBox.Text.ToUpper Then
                    If Not FindStringInListBox(SplitDir(cfgRegion), RegionsListBox) Then
                        Me.RegionsListBox.Items.Add(SplitDir(cfgRegion))
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Clients List Box - this is exactly the same as the Populate Clients Combo box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateClientListBox()
        Try
            Me.ClientsListBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                If SplitDir(cfgCountry).ToUpper = CountriesListBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = RegionsListBox.Text.ToUpper Then
                        If Not FindStringInListBox(SplitDir(cfgClient), ClientsListBox) Then
                            Me.ClientsListBox.Items.Add(SplitDir(cfgClient))
                        End If
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' Populates Disciplines List Box - this is exactly the same as the Populate Disciplines combo box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateDisciplinesListBox()

        Try
            Me.DisciplinesListBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                If SplitDir(cfgCountry).ToUpper = CountriesListBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = RegionsListBox.Text.ToUpper Then
                        If SplitDir(cfgClient).ToUpper = ClientsListBox.Text.ToUpper Then
                            If Not FindStringInListBox(SplitDir(cfgDisciplines), DisciplinesListBox) Then
                                Me.DisciplinesListBox.Items.Add(SplitDir(cfgDisciplines))
                            End If
                        End If
                    End If
                End If

            Next

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub PopulateConfigurationDescription()

        Try
            ContentsReportListBox.Items.Clear()
            Dim sConfigurationName As String = CountriesListBox.Text & "-" & RegionsListBox.Text & "-" & ClientsListBox.Text & "-" & DisciplinesListBox.Text
            Dim FileName As String = Settings.Manager.AE.ClientsConfigurationPath & "\" & sConfigurationName & "\Support\" & sConfigurationName & ".TXT"

            If System.IO.File.Exists(FileName) Then
                Dim aFileRead() As String = ReadTextFile(FileName)
                If aFileRead IsNot Nothing Then
                    For iCtr As Integer = 0 To UBound(aFileRead)
                        ContentsReportListBox.Items.Add(aFileRead(iCtr))
                    Next
                End If
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

#End Region

#Region "Combo Box Management"

    ''' <summary>
    ''' Work out all the profiles used on the selected product
    ''' Populate the Profiles Combo Box and set the last one used (according to registry) to be the default one
    ''' Displays the last used workspace if available in the workspace text box
    ''' </summary>
    ''' <remarks></remarks>
    Sub PopulateProfileComboBox()

        Try
            ProfileComboBox.Items.Clear()
            ProfileComboBox.Text = ""
            WorkSpaceTextBox.Text = String.Empty

            If ProductComboBox.Text Like "Auto*" Then

                ProfileComboBox.Enabled = True

                '' get current name
                Dim AcadName As String = ProductComboBox.Text

                ' Which AutoCAD is selected in the Product Box now?
                For Each Acad As Manager.AutoCADProduct In Settings.Manager.AutoCADs
                    If Acad.Name = AcadName Then
                        '' set the current AutoCAD
                        Settings.Manager.AutoCAD = Acad
                        Exit For
                    End If
                Next Acad

                Dim sRegistryLocationProf As String = Settings.Manager.AutoCAD.RegKey & "\Profiles"  ' GetConfigurationValueForProduct(cmbProduct.Text, "RegKey") & "\Profiles"
                Dim ProfregVersion As RegistryKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(sRegistryLocationProf, False)

                If Not ProfregVersion Is Nothing Then

                    Dim SubKeyName As String

                    For Each SubKeyName In ProfregVersion.GetSubKeyNames
                        ProfileComboBox.Items.Add(SubKeyName)
                        Dim x As RegistryKey = ProfregVersion.OpenSubKey(SubKeyName)
                        WorkSpaceTextBox.Text = CStr(x.GetValue("WorkspaceNameAtProfileSave"))
                    Next

                    If Not ProfregVersion.GetValue("").ToString = "" Then
                        ProfileComboBox.Text = ProfregVersion.GetValue("").ToString
                    Else
                        ProfileComboBox.Items.Add(Settings.Manager.AutoCAD.Profilename)
                        ProfileComboBox.Text = Settings.Manager.AutoCAD.Profilename
                    End If

                    ProfregVersion.Close()

                Else

                    ProfileComboBox.Items.Add(Settings.Manager.AutoCAD.Profilename)
                    ProfileComboBox.Text = Settings.Manager.AutoCAD.Profilename

                End If
            Else
                ProfileComboBox.Enabled = False
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , "PopoulateProfile Error", LogName)
        End Try

    End Sub
    ''' <summary>
    ''' Work out all the menus available from the C:\Program Files\AutoCAD\ApplicatePlugins\Jacobs ***.bundle
    ''' </summary>
    ''' <remarks></remarks>
    Sub PopulatePartialMenuListBox()

        'Enable the package.content.xml files
        'Disable the unused
        'Save the Settings
        Try
            'Clear the Menu Comobbox
            PartialMenuListBox.Items.Clear()
            PartialMenuListBox.Enabled = True
            'PartialMenuListBox.Items.Add("<<None>>")

            'Find bundle contain folders
            Dim ApplicationPuginsFolder As String = Jacobs.Common.Settings.Manager.EvaluateExpression("[PROGRAMFILES]" & "\" & "[APPLICATIONPLUGINS]") '=  "C:\Program Files\Autodesk\ApplicationPlugins"
            'Extract the bundle folder names
            For Each BundleDirectory As String In Directory.GetDirectories(ApplicationPuginsFolder)
                If BundleDirectory.Contains(".bundle") Then
                    BundleDirectory = Mid(BundleDirectory, (Len(ApplicationPuginsFolder) + 2))
                    PartialMenuListBox.Items.Add(Mid(BundleDirectory, 1, Len(BundleDirectory) - 7))
                End If
            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , "PopulateMenu Error", LogName)
        End Try

    End Sub


    ''' <summary>
    ''' The Template Managers Tab - contains the Existing Templates Combo Boxes 
    ''' This sub populates these
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateExistingComboBoxes()

        Try
            If ExistingCountriesComboBox.Text = String.Empty Then
                PopulateExistingCountries()
            Else
                If ExistingRegionsComboBox.Text = String.Empty Then
                    PopulateExistingRegions()
                Else
                    If ExistingClientsComboBox.Text = String.Empty Then
                        PopulateExistingClients()
                    Else
                        If ExistingDisciplinesComboBox.Text = String.Empty Then
                            PopulateExistingDisciplines()
                        End If
                    End If
                End If
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Country Combo Box - this is exactly the same as the Populate Countrys List box code except it's for a combo box
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <remarks></remarks>
    Private Sub PopulateExistingCountries(Optional ByRef Value As Object = Nothing)

        Try
            Me.ExistingCountriesComboBox.Items.Clear()
            For Each Item As String In cDirectoryEntries
                Dim SplitDir() As String = Item.Split("-"c)
                '' Quick check to see that we haven't created invalid Configuration folder - only cad Support would see this dialog
                'If SplitDir.Length = 4 Then
                '    If Not FindMySpecificString(SplitDir(cfgCountry), Me.ExistingCountriesComboBox) Then
                '        Me.ExistingCountriesComboBox.Items.Add(SplitDir(cfgCountry))
                '    End If
                'Else
                '    GeneralMessageBox("Invalid Config Folder Name: " & Item,  System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error,,,,,,LogName)
                'End If

                If SplitDir.Length = 4 Then
                    If Not FindStringInComboBox(SplitDir(cfgCountry), Me.ExistingCountriesComboBox) Then
                        Me.ExistingCountriesComboBox.Items.Add(SplitDir(cfgCountry))
                    End If
                Else
                    GeneralMessageBox("Invalid Template Folder Name: " & Item, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Regions Combo Box - this is exactly the same as the Populate Regions List box code except it's for a combo box
    ''' </summary>
    ''' <param name="Value"></param>
    ''' <remarks></remarks>
    Private Sub PopulateExistingRegions(Optional ByRef Value As Object = Nothing)

        Try
            Me.ExistingRegionsComboBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                'If SplitDir(cfgCountry).ToUpper.Contains(ExistingCountriesComboBox.Text.ToUpper) Then
                '    If Not Me.ExistingRegionsComboBox.Items.Contains(SplitDir(cfgRegion)) Then
                '        Me.ExistingRegionsComboBox.Items.Add(SplitDir(cfgRegion))
                '    End If
                'End If

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If Not FindStringInComboBox(SplitDir(cfgRegion), ExistingRegionsComboBox) Then
                        Me.ExistingRegionsComboBox.Items.Add(SplitDir(cfgRegion))
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    ''' <summary>
    ''' Populates Clients Combo Box - this is exactly the same as the Populate Clients List box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateExistingClients()
        Try
            Me.ExistingClientsComboBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                'If SplitDir(cfgCountry).ToUpper.Contains(ExistingCountriesComboBox.Text.ToUpper) Then
                '    If SplitDir(cfgRegion).ToUpper.Contains(ExistingRegionsComboBox.Text.ToUpper) Then
                '        If Not Me.ExistingClientsComboBox.Items.Contains(SplitDir(cfgClient)) Then
                '            Me.ExistingClientsComboBox.Items.Add(SplitDir(cfgClient))
                '        End If
                '    End If
                'End If

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = ExistingRegionsComboBox.Text.ToUpper Then
                        If Not FindStringInComboBox(SplitDir(cfgClient), ExistingClientsComboBox) Then
                            Me.ExistingClientsComboBox.Items.Add(SplitDir(cfgClient))
                        End If
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    ''' <summary>
    ''' Populates Disciplines Combo Box - this is exactly the same as the Populate Disciplines List box code except it's for a combo box
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub PopulateExistingDisciplines()

        Try
            Me.ExistingDisciplinesComboBox.Items.Clear()
            For Each DirectoryItem As String In cDirectoryEntries
                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                'If SplitDir(cfgCountry).ToUpper.Contains(ExistingCountriesComboBox.Text.ToUpper) Then
                '    If SplitDir(cfgRegion).ToUpper.Contains(ExistingRegionsComboBox.Text.ToUpper) Then
                '        If SplitDir(cfgClient).ToUpper.Contains(ExistingClientsComboBox.Text.ToUpper) Then
                '            If Not Me.ExistingDisciplinesComboBox.Items.Contains(SplitDir(cfgDisciplines)) Then
                '                Me.ExistingDisciplinesComboBox.Items.Add(SplitDir(cfgDisciplines))
                '            End If
                '        End If
                '    End If
                'End If

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = ExistingRegionsComboBox.Text.ToUpper Then
                        If SplitDir(cfgClient).ToUpper = ExistingClientsComboBox.Text.ToUpper Then
                            If Not FindStringInComboBox(SplitDir(cfgDisciplines), ExistingDisciplinesComboBox) Then
                                Me.ExistingDisciplinesComboBox.Items.Add(SplitDir(cfgDisciplines))
                            End If
                        End If
                    End If
                End If

            Next
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Public Sub PopulateWithCountriesFromFile(ByVal CmbBox As ComboBox, Optional ByVal AddGlobal As Boolean = False)

        Try

            RegionsComboBox.Text = String.Empty
            For Each Region As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.RegionsFileName))
                If Not CmbBox.Items.Contains(Region.Split(","c)(0)) Then
                    CmbBox.Items.Add(Region.Split(","c)(0))
                End If
            Next

            If AddGlobal = True Then
                ' Discontinued when using Regions file to derive countries
                'If Not CmbBox.Items.Contains("Global") Then
                '    CmbBox.Items.Add("Global")
                'End If
            End If
            CmbBox.Sorted = True

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub PopulateNewNameComboBoxes()

        '' Load the Combo Boxes if required
        Try
            If CountriesComboBox.Items.Count = 0 Then
                ' GetCountries.PopulateWithCountries(CountriesComboBox, True)
                PopulateWithCountriesFromFile(CountriesComboBox, True)
            End If

            If RegionsComboBox.Items.Count = 0 Then
                PopulateRegionsComboBox()
            End If

            If DisciplinesComboBox.Items.Count = 0 Then
                PopulateDisciplinesComboBox()
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub PopulateRegionsComboBox()

        Try
            RegionsComboBox.Items.Clear()
            RegionsComboBox.Text = String.Empty

            For Each Region As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.RegionsFileName))
                If Region.Split(","c)(0).ToUpper = CountriesComboBox.Text.ToUpper Then
                    RegionsComboBox.Items.Add(Region.Split(","c)(1))
                End If
            Next

            RegionsComboBox.Sorted = True
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Sub PopulateDisciplinesComboBox()
        Try
            DisciplinesComboBox.Items.Clear()
            DisciplinesComboBox.Text = String.Empty

            For Each Discipline As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.DisciplinesFileName))
                DisciplinesComboBox.Items.Add(Discipline)
            Next
            DisciplinesComboBox.Sorted = True
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

#End Region

#Region "Buttons"

    ''' <summary>
    ''' In the first TAB Using Template - launches selected product with selected template
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        FileAssociation()

        ' Set last used product is done in the LaunchAutoCAD function
        ' SetLastUsedProduct()

        'Saved in settings in the class
        SaveDialogSettings()

        'Enable the xml file

        '' Launches the selected product passing the template name based on what the user selected
        LaunchAutoCAD(CountriesListBox.Text & "-" & RegionsListBox.Text & "-" & ClientsListBox.Text & "-" & DisciplinesListBox.Text)

    End Sub

    Private Sub SaveDialogSettings()

        '' In the OK button....
        '' Save Settings to 
        'UserSettings.Reset()

        '' Saves the settings to the class
        'UserSettings.DialogSettings("CountriesListBox") = CountriesListBox.Text
        'UserSettings.DialogSettings("RegionsListBox") = RegionsListBox.Text
        'UserSettings.DialogSettings("ClientsListBox") = ClientsListBox.Text
        'UserSettings.DialogSettings("DisciplinesListBox") = DisciplinesListBox.Text
        'UserSettings.DialogSettings("PartialMenuComboBox") = PartialMenuComboBox.Text

        'Saves the settings to the Regsitry
        RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedCountryList", CountriesListBox.Text, "REG_SZ")
        RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedRegionList", RegionsListBox.Text, "REG_SZ")
        RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedClientsList", ClientsListBox.Text, "REG_SZ")
        RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedDisciplineList", DisciplinesListBox.Text, "REG_SZ")
        'Save the current configuration name in the registry
        RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, "FULLCONFIGNAME", CountriesListBox.Text & "-" & RegionsListBox.Text & "-" & ClientsListBox.Text & "-" & DisciplinesListBox.Text, "REG_SZ")

        For Each PartialMenu As Object In Me.PartialMenuListBox.Items
            Dim PartialMenuEnabled As Boolean = False
            For Each CheckedItem As Object In Me.PartialMenuListBox.CheckedItems
                If PartialMenu.ToString = CheckedItem.ToString Then
                    PartialMenuEnabled = True
                    Exit For
                Else
                    PartialMenuEnabled = False
                End If
            Next
            RegistryWrite("HKCU", Settings.Manager.AE.AEWorkingRegKey, PartialMenu.ToString(), PartialMenuEnabled, "REG_SZ")
        Next
        '' Save the XML file
        'UserSettings.SaveDialogSettings()

    End Sub

    Private Sub RestoreDialogSettings()

        '' In the load
        '' Reads the settings from the Registry
        'UserSettings.ReadDialogSettings()

        'If UserSettings.DialogSettings("CountriesListBox") <> String.Empty Then

        Dim LastCountrySelected As String = Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedCountryList")
        If Not String.IsNullOrEmpty(LastCountrySelected) Then
            CountriesListBox.SetSelected(CountriesListBox.Items.IndexOf(LastCountrySelected), True)

            Dim LastRegionSelected As String = Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedRegionList")
            If Not String.IsNullOrEmpty(LastRegionSelected) Then
                RegionsListBox.SetSelected(RegionsListBox.Items.IndexOf(LastRegionSelected), True)

                Dim LastClientsSelected As String = Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedClientsList")
                If Not String.IsNullOrEmpty(LastClientsSelected) Then
                    ClientsListBox.SetSelected(ClientsListBox.Items.IndexOf(LastClientsSelected), True)

                    Dim LastDisciplinesSelected As String = Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, "LastUsedDisciplineList")
                    If Not String.IsNullOrEmpty(LastDisciplinesSelected) Then
                        DisciplinesListBox.SetSelected(DisciplinesListBox.Items.IndexOf(LastDisciplinesSelected), True)
                    End If
                End If
            End If
        End If


        For Index As Integer = 0 To Me.PartialMenuListBox.Items.Count - 1
            Dim PartialMenuName As String = Me.PartialMenuListBox.Items(Index)
            Dim PartialMenuEnabled As String = Common.Core.Registry.RegistryRead("HKCU", Settings.Manager.AE.AEWorkingRegKey, PartialMenuName)
            If PartialMenuEnabled = "True" Or String.IsNullOrEmpty(PartialMenuEnabled) = True Then
                PartialMenuListBox.SetItemChecked(Index, True)
            Else
                PartialMenuListBox.SetItemCheckState(Index, CheckState.Unchecked)
            End If
        Next

    End Sub

    Private Sub ClientsearchButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClientsearchButton.Click

        Try
            Dim frmSearch As AutoCADEnvironmentLauncher_SearchForm = New AutoCADEnvironmentLauncher_SearchForm
            Dim res As Windows.Forms.DialogResult = frmSearch.ShowDialog(Me)
            Dim sSelectedConfiguration As String
            If res = Windows.Forms.DialogResult.Yes Then

                sSelectedConfiguration = frmSearch.lbTestConfigurations.SelectedItem.ToString

                'FindStringInListBox(sSelectedConfiguration.Split("-"c)(cfgCountry), CountriesListBox)
                'FindStringInListBox(sSelectedConfiguration.Split("-"c)(cfgRegion), RegionsListBox)
                'FindStringInListBox(sSelectedConfiguration.Split("-"c)(cfgClient), ClientsListBox)
                'FindStringInListBox(sSelectedConfiguration.Split("-"c)(cfgDisciplines), DisciplinesListBox)

                Me.CountriesListBox.SetSelected(CountriesListBox.Items.IndexOf(sSelectedConfiguration.Split("-"c)(cfgCountry)), True)
                Me.RegionsListBox.SetSelected(RegionsListBox.Items.IndexOf(sSelectedConfiguration.Split("-"c)(cfgRegion)), True)
                Me.ClientsListBox.SetSelected(ClientsListBox.Items.IndexOf(sSelectedConfiguration.Split("-"c)(cfgClient)), True)
                Me.DisciplinesListBox.SetSelected(DisciplinesListBox.Items.IndexOf(sSelectedConfiguration.Split("-"c)(cfgDisciplines)), True)

            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    'Private Function FindStringInListBox(ByVal myListBox As ListBox, ByVal searchString As String) As Boolean

    '    Dim Result As Boolean = False
    '    Try
    '        ' Ensure we have a proper string to search for. 
    '        If searchString <> String.Empty Then
    '            ' Find the item in the list and store the index to the item. 
    '            Dim index As Integer = myListBox.FindString(searchString)
    '            ' Determine if a valid index is returned. Select the item if it is valid. 
    '            If index <> -1 Then
    '                myListBox.SetSelected(index, True)
    '                Result = True
    '            End If
    '        End If

    '    Catch ex As Exception
    '        Result = False
    '    End Try
    '    Return Result

    'End Function

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

    Private Sub HelpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())

    End Sub


    ''' <summary>
    ''' Resets the selected product - for the current user
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Reset() As Boolean

        Dim Result As Boolean = False

        GetAcadConfigSettings(Me.ProductComboBox.Text)

        Try
            '' Get User confirmation
            If GeneralMessageBox("Are you sure you wish to reset " & Jacobs.Common.Settings.Settings.Manager.AutoCAD.Name & " And its associated 3rd party applications ?",
                                  System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name,
                                 MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.No Then
                Return False
                Exit Function
            End If

            '' Check that the product is installed
            If Jacobs.Common.Core.RegistryRead("HKLM", Jacobs.Common.Settings.Settings.Manager.AutoCAD.RegKey, Jacobs.Common.Settings.Settings.Manager.AutoCAD.CheckKeyForProductExist, True) = "" Then
                Return False
                Exit Function
            End If

            '' Check the MSI source files are available
            If SourceMSIsArePresent(ProductComboBox.Text) = False Then
                GeneralMessageBox("Cannot reset the selected product - one of it's secondary stage installer files is not present.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                Return False
                Exit Function
            End If

            '' Check to see if the selected product is running
            If CheckIfRunning("Acad") = True Then
                GeneralMessageBox("Cannot reset the selected product as it is currently running" & vbCrLf &
                                  "Please close " & Jacobs.Common.Settings.Settings.Manager.AutoCAD.Name & " and try again.",
                                   System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                Return False
                Exit Function
            End If

            'Software-AutodeskTuesday, 2 September 2014 at 1-04-21 PM
            Dim DateTimeStamp As String = Date.Now.ToString("- dd MMM yyyy HH-mm-ss")

            '' Get the RoamableRootFolder which is the first one to delete
            Dim DirectoryToDelete As String = Jacobs.Common.Core.RegistryRead("HKCU", Jacobs.Common.Settings.Settings.Manager.AutoCAD.RegKey, "RoamableRootFolder", True)
            '' Work Out The new name
            Dim NewLocation As String = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData) & "\Autodesk\" & Jacobs.Common.Settings.Settings.Manager.AutoCAD.Name & DateTimeStamp
            '' Check that we got something back - if not - the product has already been reset 
            If DirectoryToDelete <> String.Empty Then

                '' If the directory exists then move it
                If System.IO.Directory.Exists(DirectoryToDelete) Then
                    Dim DirectoryToDel As DirectoryInfo = My.Computer.FileSystem.GetDirectoryInfo(DirectoryToDelete)
                    DirectoryToDelete = DirectoryToDel.Parent.Parent.FullName
                    DirectoryToDel.Parent.Parent.MoveTo(NewLocation)
                End If

            End If

            '' Get the LocalRoot folder name
            DirectoryToDelete = DirectoryToDelete.Replace("Roaming", "Local")
            '' Work Out The new name
            NewLocation = System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData) & "\Autodesk\" & Jacobs.Common.Settings.Settings.Manager.AutoCAD.Name & DateTimeStamp
            '' If the directory exists then move it
            If System.IO.Directory.Exists(DirectoryToDelete) Then
                Dim DirectoryToDel As DirectoryInfo = My.Computer.FileSystem.GetDirectoryInfo(DirectoryToDelete)
                DirectoryToDel.MoveTo(NewLocation)
            End If

            Dim ExportFileName As String = My.Computer.FileSystem.GetDirectoryInfo(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData)).Parent.Parent.FullName & "\" & Jacobs.Common.Settings.Settings.Manager.AutoCAD.RegKey.Replace("\", "-").Trim("-").Replace(":", "-") & DateTimeStamp & ".REG"

            '' Export Secondary installers hives
            For Each Hive As String In GetSecondaryStageInstallerHKCUHives(Jacobs.Common.Settings.Settings.Manager.AutoCAD)
                ExportFileName = My.Computer.FileSystem.GetDirectoryInfo(System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData)).Parent.Parent.FullName & "\" & Hive.Replace("\", "-").Trim("-").Replace(":", "-") & DateTimeStamp & ".REG"
                '' Export the Hive
                Jacobs.Common.Core.RegistryHiveExport("HKCU", Hive, ExportFileName, True)
            Next

            '' Secondary installers delete the hives
            For Each Hive As String In GetSecondaryStageInstallerHKCUHives(Jacobs.Common.Settings.Settings.Manager.AutoCAD)
                '' Deletes the hive
                Jacobs.Common.Core.RegistryDelete("HKCU", Hive, "", True)
            Next


            '' Exports the registry hive
            Jacobs.Common.Core.RegistryHiveExport("HKCU", Jacobs.Common.Settings.Settings.Manager.AutoCAD.RegKey, ExportFileName, True)
            '' Deletes the user's AutoCAD Registry hive
            Jacobs.Common.Core.RegistryDelete("HKCU", Jacobs.Common.Settings.Settings.Manager.AutoCAD.RegKey, "", True)

            '' Remove the last run Application from the User's area
            Jacobs.Common.Core.RegistryDelete("HKCU", "Software\Autodesk\AutoCAD\" & Jacobs.Common.Settings.Settings.Manager.AutoCAD.Version, "CurVer", True)
            '' Backup the User's JacobsCAD Folder

            DirectoryToDelete = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData).CombinePath(Jacobs.Common.Settings.Manager.EvaluateExpression("[MANUFACTURER]"))

            NewLocation = DirectoryToDelete & DateTimeStamp
            '' If the directory exists then move it
            If System.IO.Directory.Exists(DirectoryToDelete) Then
                System.IO.Directory.Move(DirectoryToDelete, NewLocation)
            End If

            '' Backup the Public JacobsCAD Folder
            DirectoryToDelete = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath(Jacobs.Common.Settings.Manager.EvaluateExpression("[MANUFACTURER]"))
            NewLocation = DirectoryToDelete & DateTimeStamp
            '' If the directory exists then move it
            If System.IO.Directory.Exists(DirectoryToDelete) Then
                System.IO.Directory.Move(DirectoryToDelete, NewLocation)
            End If

            '' Only at this point did the reset work ok
            Result = True

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

        Return Result

    End Function

    Private Sub ResetAllSilent()

        Try
            GeneralMessageBox("Resetting all Autodesk Products, don't forget to wait until the process complete dialog appears.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

            Dim p As Process

            p = Process.Start(Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents.CombinePath("ResetAll.VBS"))
            p.WaitForExit()
            PopulateProfileComboBox()

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub ResetAll()

        Try
            GeneralMessageBox("Resetting all Autodesk Products, don't forget to wait until the process complete dialog appears.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

            Dim p As Process

            p = Process.Start(Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents.CombinePath("ResetAll.VBS"))
            p.WaitForExit()
            PopulateProfileComboBox()

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub


    Private Sub ResetSelectedButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetSelectedButton.Click

        '' Check if shift was held down when the button was clicked
        If CBool(Control.ModifierKeys And Keys.Shift) Then
            ResetAll()
            Exit Sub
        End If

        If Reset() = True Then
            PopulateProfileComboBox()
            If GeneralMessageBox("Reset Complete." & vbCrLf & "  Would you like to start the selected product now ?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                '' Associate the DWG and DWT file types with the AcadLauncher.exe
                FileAssociation()
                SetLastUsedProduct()
                LaunchAutoCAD()
            End If
        End If

    End Sub

    Private Sub VirusRemoverButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VirusRemoverButton.Click

        Try
            Dim sFile As String = Settings.Manager.AE.AEBundleContents.CombinePath("Remove Acad LSP Virus From Network.vbs")
            Dim sFile2 As String = Settings.Manager.AE.AEBundleContents.CombinePath("Remove Acad LSP Virus From Network.hta")

            Dim PSI2 As New ProcessStartInfo(sFile2)
            PSI2.WindowStyle = ProcessWindowStyle.Maximized
            Process.Start(PSI2)

            Dim PSI As New ProcessStartInfo(sFile)
            PSI.WindowStyle = ProcessWindowStyle.Minimized
            Process.Start(PSI)
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub ProjectWiseOnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProjectWiseOnButton.Click

        Try
            Dim sFile As String = "C:\Program Files\Autodesk\ApplicationPlugins\Project Wise Manager.Bundle\Contents\PWSwitch.EXE"
            Dim PSI As New ProcessStartInfo(sFile)
            PSI.WindowStyle = ProcessWindowStyle.Minimized
            PSI.Arguments = "ON"
            Process.Start(PSI).WaitForExit()

            ' Dim Root As String = "HKLM"
            ' If RegistryValueExists(Root, "SOFTWARE\Autodesk\AutoCAD\R21.0\Acad-0001:409\Applications\ProjectWise", "LOADER") = True Then
            ' End If

            EnableDisableProjectWiseButtons()
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub ProjectWiseOffButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProjectWiseOffButton.Click

        Try
            Dim sFile As String = "C:\Program Files\Autodesk\ApplicationPlugins\Project Wise Manager.Bundle\Contents\PWSwitch.EXE"
            Dim PSI As New ProcessStartInfo(sFile)
            PSI.WindowStyle = ProcessWindowStyle.Minimized
            PSI.Arguments = "OFF"
            Process.Start(PSI).WaitForExit()
            EnableDisableProjectWiseButtons()
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub ProcessButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcessTemplateOKButton.Click

        If NewRadioButton.Checked = True Then
            NewConfig()
        End If

        If ModifyRadioButton.Checked = True Then
            ModifyConfig()
        End If

        If NewUsingRadioButton.Checked = True Then
            NewUsing()
        End If

        If NewUsingUserProvidedRadioButton.Checked = True Then
            NewUsingUserProvided()
        End If

        'If RemoveRadioButton.Checked = True Then
        '    RemoveExisting()
        'End If

        'If DeployRadioButton.Checked = True Then
        '    DeployContent()
        'End If

    End Sub

    Private Sub NavigateToLogFilesFolderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NavigateToLogFilesFolderButton.Click

        Dim LogFolder As String = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]"))
        Shell("explorer.exe " & LogFolder, AppWinStyle.NormalFocus, False)

    End Sub

    Private Sub ClearAllLogFilesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearAllLogFilesButton.Click

        Try
            Dim LogFolder As String = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]"))
            If System.IO.Directory.Exists(LogFolder) Then
                For Each File As String In System.IO.Directory.GetFiles(LogFolder)
                    System.IO.File.Delete(File)
                Next
                MessageBox.Show("Log files cleared.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub DisableAEButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisableAEButton.Click

        Try

            'Dim pwd As String = String.Empty
            If GeneralMessageBox("Are you sure you wish to disable the AE and the Download manager?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then

                'pwd = InputBox("Password: ", "Enter Password to Disable the AE and the DFS Downloader: ")

                '                If pwd = ((Date.Today.Day + Date.Today.Month) * Date.Today.Year).ToString Then

                '  ResetAllSilent()

                Dim FileName As String = System.IO.Directory.GetParent(Settings.Manager.AE.AEBundleContents).FullName.CombinePath("PackageContents.xml")

                If System.IO.File.Exists(FileName) Then
                    System.IO.File.Move(FileName, FileName & "-old")
                End If

                '' Backup the link back in the public area
                FileName = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonStartup).ToString.CombinePath("DFS Download Manager R20.lnk")
                Dim BackupFileLocation As String = Manager.EvaluateExpression("[COMMON]").CombinePath(Path.GetFileName(FileName))
                If System.IO.File.Exists(FileName) Then
                    System.IO.File.Move(FileName, BackupFileLocation)
                End If

                EnableDisableAEButtons()

                If GeneralMessageBox("We recommend that the selected product is launched at this point." & vbCrLf &
                                     "Would you like to launch the Selected Product now?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then
                    LaunchAutoCAD()
                End If

                'Else
                '   GeneralMessageBox("Incorrect Password - Access Denied", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                'End If
            Else
                GeneralMessageBox("No Action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub EnableAEButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnableAEButton.Click

        Try
            '     ResetAllSilent()

            Dim FileName As String = System.IO.Directory.GetParent(Settings.Manager.AE.AEBundleContents).FullName.CombinePath("PackageContents.xml")
            If System.IO.File.Exists(FileName & "-old") Then
                System.IO.File.Move(FileName & "-old", FileName)
            End If

            '' Get the link back from the public area
            FileName = System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonStartup).ToString.CombinePath("DFS Download Manager R20.lnk")
            Dim BackupFileLocation As String = Manager.EvaluateExpression("[COMMON]").CombinePath(Path.GetFileName(FileName))
            If System.IO.File.Exists(BackupFileLocation) Then
                System.IO.File.Move(BackupFileLocation, FileName)
            End If

            EnableDisableAEButtons()

            If GeneralMessageBox("We recommend that the selected product is launched at this point." & vbCrLf &
                               "Would you like to launch the Selected Product now?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then
                LaunchAutoCAD()
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub


#End Region

#Region "Change Events"

    Private Sub CountryListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CountriesListBox.SelectedIndexChanged

        RegionsListBox.Items.Clear()
        ClientsListBox.Items.Clear()
        DisciplinesListBox.Items.Clear()

        PopulateListBoxes()
        EnableDisableStartButton()

    End Sub

    Private Sub RegionListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegionsListBox.SelectedIndexChanged

        ClientsListBox.Items.Clear()
        DisciplinesListBox.Items.Clear()

        PopulateListBoxes()
        EnableDisableStartButton()

    End Sub

    Private Sub ClientListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClientsListBox.SelectedIndexChanged

        DisciplinesListBox.Items.Clear()

        PopulateListBoxes()
        EnableDisableStartButton()

    End Sub

    Private Sub DisciplinesListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisciplinesListBox.SelectedIndexChanged

        If CountriesListBox.Text = "Global" And
            RegionsListBox.Text = "All" And
            ClientsListBox.Text = "All" And
            DisciplinesListBox.Text = "All" Then

            GeneralMessageBox("Reserved Name Cannot be used to create deliverables.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

            DisciplinesListBox.ClearSelected()
        End If

        PopulateConfigurationDescription()
        EnableDisableStartButton()

    End Sub

    Private Sub NewRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewRadioButton.CheckedChanged

        ToolTip1.SetToolTip(ProcessTemplateOKButton, "Create a new Template")

        EnableDisableSelectNewGroupBoxes()
        EnableDisableProcessButton()

    End Sub

    Private Sub NewUsingUserProvidedRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewUsingUserProvidedRadioButton.CheckedChanged

        ToolTip1.SetToolTip(ProcessTemplateOKButton, "Create a new Template Using a user provided DWG file")

        EnableDisableSelectNewGroupBoxes()
        EnableDisableProcessButton()

    End Sub

    Private Sub ModifyRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModifyRadioButton.CheckedChanged

        ToolTip1.SetToolTip(ProcessTemplateOKButton, "Modify the Selected Exsiting Template")

        EnableDisableSelectNewGroupBoxes()
        EnableDisableProcessButton()

    End Sub

    Private Sub NewUsingRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewUsingRadioButton.CheckedChanged

        ToolTip1.SetToolTip(ProcessTemplateOKButton, "Create a New Template Based on the Selected Existing Template ")

        EnableDisableSelectNewGroupBoxes()
        EnableDisableProcessButton()

    End Sub

    Private Sub RemoveRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveRadioButton.CheckedChanged

        ToolTip1.SetToolTip(ProcessTemplateOKButton, "Remove the Selected Existing Template from this Machine")

        EnableDisableSelectNewGroupBoxes()
        EnableDisableProcessButton()

    End Sub

    'Private Sub DeployRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeployRadioButton.CheckedChanged

    '    ToolTip1.SetToolTip(ProcessButton, "Deploy the Selected Existing Template to the Checked Distribution Location below")

    '    EnableDisableSelectNewGroupBoxes()
    '    EnableDisableProcessButton()

    'End Sub

    Private Sub CountryComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CountriesComboBox.SelectedIndexChanged

        PopulateDisciplinesComboBox()
        PopulateRegionsComboBox()
        EnableDisableProcessButton()

    End Sub

    Private Sub RegionsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegionsComboBox.SelectedIndexChanged

        EnableDisableProcessButton()

    End Sub

    Private Sub DisciplineComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisciplinesComboBox.SelectedIndexChanged

        EnableDisableProcessButton()

    End Sub

    Private Sub ExistingCountriesComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingCountriesComboBox.SelectedIndexChanged

        ExistingRegionsComboBox.Items.Clear()
        ExistingClientsComboBox.Items.Clear()
        ExistingDisciplinesComboBox.Items.Clear()

        ExistingRegionsComboBox.Text = String.Empty
        ExistingClientsComboBox.Text = String.Empty
        ExistingDisciplinesComboBox.Text = String.Empty

        PopulateExistingComboBoxes()
        EnableDisableProcessButton()

    End Sub

    Private Sub ExistingRegionsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingRegionsComboBox.SelectedIndexChanged

        ExistingClientsComboBox.Items.Clear()
        ExistingDisciplinesComboBox.Items.Clear()

        ExistingClientsComboBox.Text = String.Empty
        ExistingDisciplinesComboBox.Text = String.Empty

        PopulateExistingClients()
        EnableDisableProcessButton()

    End Sub

    Private Sub ExistingClientsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingClientsComboBox.SelectedIndexChanged

        ExistingDisciplinesComboBox.Items.Clear()

        ExistingDisciplinesComboBox.Text = String.Empty

        PopulateExistingDisciplines()
        EnableDisableProcessButton()

    End Sub

    Private Sub ExistingDisciplinesComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingDisciplinesComboBox.SelectedIndexChanged

        EnableDisableProcessButton()

    End Sub

    Private Sub ClientTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClientTextBox.TextChanged

        Try
            If ClientTextBox.Text Like "*[<>/\"":;?*|,='_]*" Or ClientTextBox.Text Like "*-*" Then
                GeneralMessageBox("Invalid Character In Client Name. " &
                                "The name cannot contain any of these characters <>/\"":;?*|,='-_ ", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                ClientTextBox.Text = String.Empty
            Else
                EnableDisableProcessButton()
            End If
        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

#End Region

    Private Sub ContentDeployer(ByVal Source As String, ByVal dest As String)

        If GeneralMessageBox(ExistingConfigName & " Will be deployed to " & dest & vbCrLf & vbCrLf &
                                   "Would you like to deploy now ?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then

            GeneralMessageBox("Copy Folder from: " & vbCrLf & vbCrLf &
                              Source & vbCrLf &
                              "TO" & vbCrLf & vbCrLf &
                              dest & vbCrLf, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)

            CopyDirectory(Source, dest)

        Else

            GeneralMessageBox("No action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

        End If

    End Sub

    Public Sub DeploySettings()

        Try
            Dim AssetNumber As String = String.Empty
            Dim Dest As String = String.Empty

            If ToAssetNoAEAdminCheckBox.Checked = False Then
                If ProductionAEAdminCheckBox.Checked = False Then
                    If TestingAEAdminCheckBox.Checked = False Then
                        If UATAEAdminCheckBox.Checked = False Then
                            GeneralMessageBox("You need to select a distribution location before we can deploy.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                            Exit Sub
                        End If
                    End If
                End If
            End If

            If ToAssetNoAEAdminCheckBox.Checked = True Then
                AssetNumber = InputBox("Enter the asset number to target: ", "Select Asset To Deploy", "Example AU-D12345 or AU-N12345")
                '' Check for valid asset number - AA-N##### or AA-D######
                If Not AssetNumber.ToUpper Like "[A-Z][A-Z]-[DN]#####" Then
                    GeneralMessageBox("Invalid asset number: " & AssetNumber & " - deployment by asset aborted", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                Else
                    If PingAsset(AssetNumber) = True Then
                        If GeneralMessageBox(ExistingConfigName & " Will be deployed to: " & AssetNumber & vbCrLf &
                               "You need to contact the user of " & AssetNumber & " and ask them to close all applications" &
                               " and wait for you to advise them that the deployment has finished" & vbCrLf & vbCrLf &
                               "Would you like to deploy now ?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then
                            Dest = Settings.Manager.AE.AEBundleContents
                            Dest = Dest.Replace("C:\", "\\" & AssetNumber & "\c$\")

                        Else
                            GeneralMessageBox("No action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                        End If
                    End If
                End If
            End If

            For Each item As String In SettingFilesToDeployListBox.SelectedItems

                Dim source As String = item.ToString()
                Dim ExistingSettingsFileName As String = System.IO.Path.GetFileName(source)

                '' Deploy by Asset if requested and all OK
                If Dest <> String.Empty Then
                    '' By default the bundleContents folder
                    SettingsDeployer(source, Dest.CombinePath(ExistingSettingsFileName))
                End If

                If ProductionAEAdminCheckBox.Checked = True Then
                    SettingsDeployer(source, DFSLocation.CombinePath("Production\CAD Environment\Autodesk\AutoCAD 2017 Bundle\Contents", ExistingSettingsFileName))
                End If

                If TestingAEAdminCheckBox.Checked = True Then
                    SettingsDeployer(source, DFSLocation.CombinePath("Testing\CAD Environment\Autodesk\AutoCAD 2017 Bundle\Contents", ExistingSettingsFileName))
                End If

                If UATAEAdminCheckBox.Checked = True Then
                    SettingsDeployer(source, DFSLocation.CombinePath("Development\CAD Environment\Autodesk\AutoCAD 2017 Bundle\Contents", ExistingSettingsFileName))
                End If

            Next


        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub SettingsDeployer(SourceFile As String, ByVal DestinationFile As String)

        'C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.Bundle\Contents"
        Dim SearchForLocalPath As String = Settings.Manager.AE.AEBundleContents.Substring(3, Settings.Manager.AE.AEBundleContents.Length - 3).ToUpper
        Dim SearchForDFSPath As String = "AutoCAD 2017 Bundle\Contents".ToUpper

        If SourceFile.ToUpper.Contains("configuration.xml".ToUpper) Or SourceFile.ToUpper.Contains("DrawingSheetSetup.ini".ToUpper) Then
            If DestinationFile.ToUpper.Contains("c$".ToUpper) Then
                '' C:\Users\Public\Jacobs\Jacobs\AutoCAD Environment R21\Settings
                DestinationFile = DestinationFile.ToUpper.Replace(SearchForLocalPath, "Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Settings")
            Else
                DestinationFile = DestinationFile.ToUpper.Replace(SearchForDFSPath, "AutoCAD 2017 Settings")
            End If
        Else
            If SourceFile.ToUpper.Contains("blockfinder.dat".ToUpper) Then
                If DestinationFile.Contains("c$") Then
                    '' "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Lib"
                    DestinationFile = DestinationFile.ToUpper.Replace(SearchForLocalPath, "Users\Public\Jacobs\Jacobs AutoCAD Environmnet R21\Lib")
                Else
                    DestinationFile = DestinationFile.ToUpper.Replace(SearchForDFSPath, "AutoCAD 2017 BlockLibrary")
                End If
            Else
                If SourceFile.ToUpper.Contains("TemplatesToHide.csv".ToUpper) Then
                    If DestinationFile.Contains("c$") Then
                        '' C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Clients
                        DestinationFile = DestinationFile.ToUpper.Replace(SearchForLocalPath, "Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Clients")
                    Else
                        DestinationFile = DestinationFile.ToUpper.Replace(SearchForDFSPath.ToUpper, "AutoCAD 2017 Configurations\Clients")
                    End If
                End If
            End If
        End If

        If GeneralMessageBox(SourceFile & " Will be deployed to " & DestinationFile & vbCrLf & vbCrLf &
                                   "Would you like to deploy now ?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then

            GeneralMessageBox("Copy File from: " & vbCrLf & vbCrLf &
                              SourceFile & vbCrLf &
                              "TO" & vbCrLf & vbCrLf &
                              DestinationFile & vbCrLf, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , True, LogName)

            System.IO.File.Copy(SourceFile, DestinationFile, True)

        Else
            GeneralMessageBox("No action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
        End If

    End Sub

    ''' <summary>
    ''' Quick way to check if user has or hasn't got ADM permissions
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub LogoPictureBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoPictureBox.Click

        If DoWeHaveAdminRights() = True Then
            GeneralMessageBox("Running with Administrative Rights", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
        Else
            GeneralMessageBox("Running without Administrative Rights", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
        End If

    End Sub

    Private Sub PurgeRegisteredAppsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PurgeRegisteredAppsButton.Click

        RunProcess(Jacobs.Common.Settings.Settings.Manager.AutoCAD.Path.CombinePath("CleanupRegapp.exe"), True)

    End Sub

    Private Sub ScaleListCleanUpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScaleListCleanUpButton.Click

        'Windows Registry Editor Version 5.00
        '[HKEY_CURRENT_USER\Software\Autodesk\CleanupScales]
        '[HKEY_CURRENT_USER\Software\Autodesk\CleanupScales\Profiles]
        '[HKEY_CURRENT_USER\Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs]
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder0", "History", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder0Display", "History", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder0Ext", "", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder1", "Personal", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder1Display", "Documents", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder1Ext", "", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder2", "Favorites", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder2Display", "Favorites", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder2Ext", "", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder3", "Desktop", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder3Display", "Desktop", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder3Ext", "", "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\AllAnavDialogs", "PlacesOrder4", "", "REG_SZ")

        '[HKEY_CURRENT_USER\Software\Autodesk\CleanupScales\Profiles\Select Template]
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\Select Template", "FileNameMRU0", Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents.CombinePath("UserDataCache\Template\Jacobs.dwt"), "REG_SZ")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\Select Template", "InitialFilterIndex", "2", "REG_DWORD")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\Select Template", "ViewMode", "4", "REG_DWORD")
        RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Profiles\Select Template", "InitialDirectory", Jacobs.Common.Settings.Settings.Manager.AE.AEBundleContents.CombinePath("UserDataCache\Template\"), "REG_SZ")

        '' Check to see if the tool has been used before and if not set 
        '' SaveFidelity to be un ticked
        If RegistryValueExists("HKCU", "Software\Autodesk\CleanupScales\Settings", "SaveFidelity") = False Then
            RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Settings", "SaveFidelity", "0", "REG_DWORD")
        End If

        '' Turn off SaveFidelity every time
        '  RegistryWrite("HKCU", "Software\Autodesk\CleanupScales\Settings", "SaveFidelity", "0", "REG_DWORD")




        '"X"=dword:00000288
        '"Y"=dword:00000145
        '"Width"=dword:00000271
        '"Height"=dword:00000187

        RunProcess(Jacobs.Common.Settings.Settings.Manager.AutoCAD.Path.CombinePath("CleanupScales.exe"), True)

    End Sub

    Public Sub RunProcess(ByVal ProgramToRun As String, Optional ByVal Wait As Boolean = True)

        Dim p As Process

        Dim ProgramName As String = Path.GetFileName(ProgramToRun)

        If System.IO.File.Exists(ProgramToRun) Then
            p = Process.Start(ProgramToRun)
            If Wait = True Then
                p.WaitForExit()
            End If
        Else
            GeneralMessageBox("File not installed: " & ProgramName, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
        End If

    End Sub


    Public Sub PopulateTemplatesToDeployList()

        TemplatesToDeployListBox.Items.Clear()
        If Directory.Exists(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea")) Then
            For Each folder As String In System.IO.Directory.GetDirectories(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea"))
                If Not folder.Contains("SettingFiles") Then
                    TemplatesToDeployListBox.Items.Add(folder)
                End If
                TemplatesToDeployListBox.Sorted = True
            Next
        Else
            GeneralMessageBox("Not templates have been created " & Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea"), System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
        End If

    End Sub


    Public Sub PopulateSettingsFilesToDeployList()

        SettingFilesToDeployListBox.Items.Clear()

        Dim WorkingAreaSettingsPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "SettingFiles")

        Dim FilesToDeploy As New Collection

        FilesToDeploy.Clear()

        If System.IO.File.Exists(Settings.Manager.AE.AEBundleContents.CombinePath("EditableSettingsFiles.txt")) Then
            For Each FileToDeploy As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath("EditableSettingsFiles.txt"))
                If System.IO.File.Exists(WorkingAreaSettingsPath.CombinePath(System.IO.Path.GetFileName(FileToDeploy))) Then
                    SettingFilesToDeployListBox.Items.Add(WorkingAreaSettingsPath.CombinePath(System.IO.Path.GetFileName(FileToDeploy)))
                End If
            Next

        End If

    End Sub


    'Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles DeleteTemplateButton.Click
    '    For Each item As String In TemplatesToDeployListBox.SelectedItems
    '        DelTemplate(item.ToString)
    '    Next
    '    PopulateTemplatesToDeployList()
    'End Sub

    Sub DelFolder(ByVal TemplatePathAndName As String)
        If System.IO.Directory.Exists(TemplatePathAndName) Then
            System.IO.Directory.Delete(TemplatePathAndName, True)
        End If
    End Sub

    Private Sub NavigateToBlockLibraryButton_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NavigateToBlockLibraryButton.Click

        Shell("explorer.exe " & Settings.Manager.AE.BlockLibraryFolder, AppWinStyle.NormalFocus, False)

    End Sub

    Private Sub NavigateToBlockLibraryButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Shell("explorer.exe " & Settings.Manager.AE.BlockLibraryFolder, AppWinStyle.NormalFocus, False)

    End Sub


    Private Sub CreateToolsDWGButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateToolsDWGButton.Click
        Try

            Dim GName As String = "Global-All-All-All"
            Dim TName As String = Settings.Manager.AE.AEBundleContents.CombinePath("Tools.dwg")

            If GeneralMessageBox("This will create a new Tools.DWG file from the " & GName & " template?" &
                                 "Are you sure you wish to do that ?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then

                GName = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(GName, "Support", GName & ".DWG")

                If System.IO.File.Exists(GName) Then
                    System.IO.File.Copy(GName, TName, True)
                    GeneralMessageBox("File Copied From: " & vbCrLf & GName & vbCrLf & "To" & vbCrLf & TName, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                Else
                    GeneralMessageBox(GName & " file not found" &
                        "No Action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                End If

            Else

                GeneralMessageBox("No Action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

            End If

        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)

        End Try
    End Sub

    Private Sub TemplateBuildersFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TemplateBuildersFileButton.Click
        Dim sLogFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationBuildersFileName)
        Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "SettingFiles")
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub HideTemplateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HideTemplateButton.Click
        Dim sLogFile As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(Settings.Manager.AE.TemplatesToHideFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub RegionsFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegionsFileButton.Click
        Dim sLogFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.RegionsFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub SettingsFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsFileButton.Click
        Dim sLogFile As String = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DefaultConfigurationFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub TemplateMappingFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TemplateMappingFileButton.Click
        Dim sLogFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigMappingFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub DisciplinesFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisciplinesFileButton.Click
        Dim sLogFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.DisciplinesFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Sub CopySettingsToSettingsWorkingArea(slogfile As String)

        Dim Dest As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "SettingFiles")

        If System.IO.Directory.Exists(Dest) = False Then
            System.IO.Directory.CreateDirectory(Dest)
        End If
        System.IO.File.Copy(slogfile, Settings.Manager.AutoCAD.WorkingFolder.CombinePath(Dest, Path.GetFileName(slogfile)), True)

    End Sub

    Private Sub OfficeAddressesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OfficeAddressesButton.Click
        Dim sLogFile As String = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub ToolsINIButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolsINIButton.Click
        Dim sLogFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.AEBundleContents.CombinePath("Tools.ini"))
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub ShowPWDButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowPWDButton.Click

        GeneralMessageBox("Todays Password is: " & ((Date.Today.Day + Date.Today.Month) * Date.Today.Year).ToString, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

    End Sub

    Private Sub BlockfinderFavouritesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlockfinderFavouritesButton.Click

        If System.IO.File.Exists(Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Symbols", "BlockFinder.Dat")) Then
            EditFileWithNotepad(Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Symbols", "BlockFinder.Dat"))
        Else
            GeneralMessageBox("File not found: " & Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Symbols", "BlockFinder.Dat"))
        End If

    End Sub

    Private Sub NavigateToLayerDefinitionsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NavigateToLayerDefinitionsButton.Click
        Dim Folder As String = Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Layer Definitions")

        Shell("explorer.exe " & Folder, AppWinStyle.NormalFocus, False)
    End Sub

    Private Sub DrawingSheetsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawingSheetsButton.Click

        Dim Folder As String = Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Drawing Sheets")
        Shell("explorer.exe " & Folder, AppWinStyle.NormalFocus, False)

    End Sub

    Private Sub RefreshSettingsFilesToDeployListButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshSettingsFilesToDeployListButton.Click
        PopulateSettingsFilesToDeployList()
    End Sub

    Private Sub DeploySettingsFilesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeploySettingsFilesOKButton.Click
        DeploySettings()
    End Sub

    Private Sub SettingFilesTodeployButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingFilesTodeployButton.Click

        Dim LogFolder As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea")
        Shell("explorer.exe " & LogFolder, AppWinStyle.NormalFocus, False)

    End Sub

    Private Sub DeleteSelectedSettingsFilesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteSelectedSettingsFilesButton.Click
        For Each item As String In SettingFilesToDeployListBox.SelectedItems
            System.IO.File.Delete(item.ToString)
        Next
        PopulateSettingsFilesToDeployList()
    End Sub

    Private Sub MainTabControl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MainTabControl.SelectedIndexChanged

        SortOutOKButtons()

    End Sub

    Public Function OpenEmail(ByVal EmailAddress As String, Optional ByVal Subject As String = "", Optional ByVal Body As String = "") As Boolean

        Dim bAns As Boolean = True
        Dim sParams As String
        sParams = EmailAddress

        Dim cc As String = Jacobs.Common.Settings.Manager.EvaluateExpression("[JPILOGINNAME]").Replace(".ID", "").Replace("_", ".") & ".Jacobs.com"

        'Manager.EvaluateExpression(Settings.Manager.UserName)
        'If cc.ToUpper.EndsWith("_A") Then
        '    cc = cc.ToUpper.Replace("_A", "")
        'End If
        ''cc = StrConv(cc, EmailName.ProperCase) & ".Jacobs.com"

        If LCase(Microsoft.VisualBasic.Strings.Left(sParams, 7)) <> "mailto:" Then _
            sParams = "mailto:" & sParams

        If LCase(Microsoft.VisualBasic.Strings.Left(sParams, 7)) <> "cc:" Then _
            sParams = "cc:" & sParams & ";" & cc


        If Subject <> "" Then sParams = sParams &
              "?subject=" & Subject

        If Body <> "" Then
            sParams = sParams & IIf(Subject = "", "?", "&")
            sParams = sParams & "body=" & Body
        End If

        Try

            System.Diagnostics.Process.Start(sParams)

        Catch
            bAns = False
        End Try

        Return bAns

    End Function

    Private Sub SortOutOKButtons()

        Dim OKLocation As New System.Drawing.Point(88, 5)

        OK_Button.Visible = False
        DeploySettingsFilesOKButton.Visible = False
        LaunchAutoCADOKButton.Visible = False
        DeployTemplateOKButton.Visible = False
        ProcessTemplateOKButton.Visible = False

        Try
            TableLayoutPanelHelpOKCancel.Controls.Remove(OK_Button)
            TableLayoutPanelHelpOKCancel.Controls.Remove(DeploySettingsFilesOKButton)
            TableLayoutPanelHelpOKCancel.Controls.Remove(LaunchAutoCADOKButton)
            TableLayoutPanelHelpOKCancel.Controls.Remove(ProcessTemplateOKButton)
            TableLayoutPanelHelpOKCancel.Controls.Remove(DeployTemplateOKButton)
        Catch

        End Try

        If MainTabControl.SelectedTab.Name = "UsingTemplate" Then
            OK_Button.Visible = True
            TableLayoutPanelHelpOKCancel.Controls.Add(OK_Button, 1, 0)
            EnableCommonfields()
            RepositionAndResizeListBoxes()
        End If

        If MainTabControl.SelectedTab.Name = "StandardApplication" Then
            LaunchAutoCADOKButton.Visible = True
            TableLayoutPanelHelpOKCancel.Controls.Add(LaunchAutoCADOKButton, 1, 0)
            EnableCommonfields()
        End If

        If MainTabControl.SelectedTab.Name = "AdditionalTools" Then
            EnableCommonfields()
        End If

        If MainTabControl.SelectedTab.Name = "Logs" Then
            DisableCommonfields()
        End If

        If MainTabControl.SelectedTab.Name = "TemplateManagement" Then
            ProcessTemplateOKButton.Visible = True
            TableLayoutPanelHelpOKCancel.Controls.Add(ProcessTemplateOKButton, 1, 0)
            EnableCommonfields()
        End If

        If MainTabControl.SelectedTab.Name = "TemplateDeployment" Then
            DeployTemplateOKButton.Visible = True
            TableLayoutPanelHelpOKCancel.Controls.Add(DeployTemplateOKButton, 1, 0)
            DisableCommonfields()
        End If

        If MainTabControl.SelectedTab.Name = "AEAdministration" Then
            DisableCommonfields()
        End If

        If MainTabControl.SelectedTab.Name = "AdministrationDeployment" Then
            DeploySettingsFilesOKButton.Visible = True
            TableLayoutPanelHelpOKCancel.Controls.Add(DeploySettingsFilesOKButton, 1, 0)
            DisableCommonfields()
        End If

    End Sub
    Private Sub BrowseToClientsToDeployButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseToClientsToDeployButton.Click
        Dim LogFolder As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea")
        Shell("explorer.exe " & LogFolder, AppWinStyle.NormalFocus, False)
    End Sub

    Private Sub RefreshConfigsToDeployListButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshConfigsToDeployListButton.Click
        PopulateTemplatesToDeployList()
    End Sub

    Private Sub DeleteTemplateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteTemplateButton.Click
        For Each item As String In TemplatesToDeployListBox.SelectedItems
            DelFolder(item.ToString)
        Next
        PopulateTemplatesToDeployList()
    End Sub

    Private Sub DeployTemplateOKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeployTemplateOKButton.Click

        If ToAssetCheckBox.Checked = False Then
            If ProductionCheckBox.Checked = False Then
                If TestingCheckBox.Checked = False Then
                    If UATCheckBox.Checked = False Then
                        GeneralMessageBox("You need to select a distribution location before we can deploy.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                        Exit Sub
                    End If
                End If
            End If
        End If

        Dim AssetDest As String = String.Empty
        Dim AssetNumber As String = String.Empty

        If ToAssetCheckBox.Checked = True Then
            AssetNumber = InputBox("Enter the asset number to target: ", "Select Asset To Deploy", "Example AU-D12345 or AU-N12345")
            '' Check for valid asset number - AA-N##### or AA-D######
            If Not AssetNumber.ToUpper Like "[A-Z][A-Z]-[DN]#####" Then
                GeneralMessageBox("Invalid asset number: " & AssetNumber & " - deployment by asset aborted", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
            Else
                If PingAsset(AssetNumber) = True Then
                    If GeneralMessageBox("You need to contact the user of " & AssetNumber & " and ask them to close all applications" &
                           " and wait for you to advise them that the deployment has finished" & vbCrLf & vbCrLf &
                           "Would you like to deploy now ?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then

                        AssetDest = Settings.Manager.AE.ClientsConfigurationPath
                        AssetDest = AssetDest.Replace("C:\", "\\" & AssetNumber & "\c$\")

                    Else
                        GeneralMessageBox("No action taken", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)
                    End If
                End If

            End If

        End If

        For Each item As String In TemplatesToDeployListBox.SelectedItems

            Dim source As String = item.ToString()
            Dim ExistingConfigFolderName As String = System.IO.Path.GetFileNameWithoutExtension(source)

            '' Deploy by Asset if requested and all OK
            If AssetDest <> String.Empty Then
                AssetDest = AssetDest.CombinePath(ExistingConfigFolderName)
                ContentDeployer(source, AssetDest)
            End If

            If ProductionCheckBox.Checked = True Then
                ContentDeployer(source, DFSLocation.CombinePath("Production\CAD Environment\Autodesk\AutoCAD 2017 Configurations\Clients", ExistingConfigFolderName))
            End If

            If TestingCheckBox.Checked = True Then
                ContentDeployer(source, DFSLocation.CombinePath("Testing\CAD Environment\Autodesk\AutoCAD 2017 Configurations\Clients", ExistingConfigFolderName))
            End If

            If UATCheckBox.Checked = True Then
                ContentDeployer(source, DFSLocation.CombinePath("Development\CAD Environment\Autodesk\AutoCAD 2017 Configurations\Clients", ExistingConfigFolderName))
            End If

        Next

        PopulateTemplatesToDeployList()
    End Sub

    Private Sub ProductionButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProductionButton.Click

        'Dim Mode As String = "AE"
        Dim DispMode As String = "Production"

        If GeneralMessageBox("Are you sure you wish to point to the " & DispMode & " Area?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then
            ' Check DFS is present
            Dim ForceDownloadConfigXMLFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigProduction)
            If File.Exists(ForceDownloadConfigXMLFile) Then
                ' Copy Configuration.XML from DFS to this machine
                FileCopy(ForceDownloadConfigXMLFile, Settings.Manager.AE.DefaultConfigurationFilePathed)
                ' Notify user that they need to reboot
                MessageBox.Show("This PC is now pointing to the " & DispMode & " code. Please Log Off and On to receive the " & DispMode & " files.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                'DFSDownloadSettingsPath
                PointingToLabel.Text = "Pointing to " & DispMode
            Else
                MessageBox.Show("DFS-R File not present: " & ForceDownloadConfigXMLFile, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("No action taken.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub TestingButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestingButton.Click

        '  Dim Mode As String = "Testing"
        Dim DispMode As String = "Testing"

        'Dim pwd As String = String.Empty
        'If GeneralMessageBox("Are you sure you wish to point to the " & DispMode & " Area?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then
        'pwd = InputBox("Password: ", "Enter Password: ")
        'If pwd = ((Date.Today.Day + Date.Today.Month) * Date.Today.Year).ToString Then
        ' Check DFS is present
        Dim ForceDownloadConfigXMLFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigTesting)
        If File.Exists(ForceDownloadConfigXMLFile) Then
            ' Copy Configuration.XML from DFS to this machine
            FileCopy(ForceDownloadConfigXMLFile, Settings.Manager.AE.DefaultConfigurationFilePathed)
            ' Notify user that they need to reboot
            MessageBox.Show("This PC is now pointing to the " & DispMode & " code. Please Log Off and On to receive the " & DispMode & " files.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            'DFSDownloadSettingsPath
            PointingToLabel.Text = "Pointing to " & DispMode
        Else
            MessageBox.Show("DFS-R File not present: " & ForceDownloadConfigXMLFile, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        'Else
        'MessageBox.Show("Incorrect Password.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        'End If
        'Else
        'MessageBox.Show("No action taken.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        'End If

    End Sub

    Private Sub DevelopmentButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DevelopmentButton.Click

        ' Dim Mode As String = "UAT"
        Dim DispMode As String = "Development"

        'Dim pwd As String = String.Empty
        'If GeneralMessageBox("Are you sure you wish to point to the " & DispMode & " Area?", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, , , , , , LogName) = Windows.Forms.DialogResult.Yes Then
        'pwd = InputBox("Password: ", "Enter Password: ")
        'If pwd = ((Date.Today.Day + Date.Today.Month) * Date.Today.Year).ToString Then
        ' Check DFS is present
        Dim ForceDownloadConfigXMLFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigDevelopment)
        If File.Exists(ForceDownloadConfigXMLFile) Then
            ' Copy Configuration.XML from DFS to this machine
            FileCopy(ForceDownloadConfigXMLFile, Settings.Manager.AE.DefaultConfigurationFilePathed)
            ' Notify user that they need to reboot
            MessageBox.Show("This PC is now pointing to the " & DispMode & " code. Please Log Off and On to receive the " & DispMode & " files.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            'DFSDownloadSettingsPath
            PointingToLabel.Text = "Pointing to " & DispMode
        Else
            MessageBox.Show("DFS-R File not present: " & ForceDownloadConfigXMLFile, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        'Else
        'MessageBox.Show("Incorrect Password.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        'End If
        'Else
        'MessageBox.Show("No action taken.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        'End If

    End Sub

    Private Sub EmailPasswordButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmailPasswordButton.Click
        OpenEmail("", "CAD Support Generated Password Email", "Todays AE Password is: " & ((Date.Today.Day + Date.Today.Month) * Date.Today.Year).ToString)
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click

        '' Associate the DWG and DWT file types with the AcadLauncher.exe
        FileAssociation()

        SetLastUsedProduct()

        LaunchAutoCAD()

    End Sub

    ''' <summary>
    ''' Delete any log file older than 10 days from the logs folder
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub DeleteOldLogFiles(Optional days As Integer = 10)

        Try
            GeneralMessageBox("Deleting log files older than " & days.ToString & " days", , , , , , , , True, LogName)

            Dim LogFolder As String = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]"))

            If System.IO.Directory.Exists(LogFolder) Then
                For Each File As String In System.IO.Directory.GetFiles(LogFolder)
                    DeleteLogFile(System.IO.Path.GetFileName(File), False, days)
                Next
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub RefreshProfileAndProductButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshProfileAndProductButton.Click

        PopulateProductComboBox()
        PopulateProfileComboBox()
        PopulatePartialMenuListBox()
        '' Associate the DWG and DWT file types with the AcadLauncher.exe
        FileAssociation()

        SetLastUsedProduct()

    End Sub

    Private Sub DisciplinesListBox_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles DisciplinesListBox.DoubleClick

        If CountriesListBox.Text = "Global" And
           RegionsListBox.Text = "All" And
           ClientsListBox.Text = "All" And
           DisciplinesListBox.Text = "All" Then

            GeneralMessageBox("Reserved Name Cannot be used to create deliverables.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , , LogName)

            DisciplinesListBox.ClearSelected()
        End If

        PopulateConfigurationDescription()
        EnableDisableStartButton()

        '' Associate the DWG and DWT file types with the AcadLauncher.exe
        FileAssociation()

        SetLastUsedProduct()

        '' Launches the selected product passing the template name based on what the user selected
        LaunchAutoCAD(CountriesListBox.Text & "-" & RegionsListBox.Text & "-" & ClientsListBox.Text & "-" & DisciplinesListBox.Text)

    End Sub

    Private Sub LaunchAutoCADButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaunchAutoCADOKButton.Click

        '' Associate the DWG and DWT file types with the AcadLauncher.exe
        FileAssociation()

        SetLastUsedProduct()

        LaunchAutoCAD()

    End Sub

    Private Sub BrowseClientsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim LogFolder As String = Settings.Manager.AE.ClientsConfigurationPath
        Shell("explorer.exe " & LogFolder, AppWinStyle.NormalFocus, False)

    End Sub

    Private Sub SystemAdministratorsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SystemAdministratorsButton.Click
        Dim sLogFile As String = Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.SystemAdministratorsFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub EditUserPGPButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditUserPGPButton.Click
        Dim sLogFile As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\Settings", Settings.Manager.AE.UserPGPFileName)
        EditFileWithNotepad(sLogFile)
    End Sub

    Private Sub ActivateUserPGPButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ActivateUserPGPButton.Click

        Dim strfrom As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\Settings", Settings.Manager.AE.UserPGPFileName)
        Dim strto As String = Settings.Manager.AE.UserSettingsFolder.CombinePath(Settings.Manager.AE.UserPGPFileName)

        '' Copy from cache location if not present
        If System.IO.File.Exists(strfrom) Then
            If System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(strto)) = True Then
                System.IO.File.Copy(strfrom, strto, True)
                GeneralMessageBox("Your User PGP file has been Activated", , , , , , , , , LogName)
            Else
                GeneralMessageBox("Unable to Activate your User PGP file" & vbCrLf & "You need to launch the AutoCAD application before you can reinstate the PGP file.", , , , , , , , , LogName)
            End If
        Else
            GeneralMessageBox("Unable to Activate your User PGP file" & vbCrLf & "File Not Present: " & strfrom, , , , , , , , , LogName)
        End If

    End Sub

    Private Sub ShowJacobsOnlyCheckBox_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles ShowJacobsOnlyCheckBox.CheckedChanged

        DisciplinesListBox.Items.Clear()
        ClientsListBox.Items.Clear()
        RegionsListBox.Items.Clear()
        CountriesListBox.Items.Clear()

        ManageLists()

    End Sub

    '' Returns false only if an AutoCAD product that is controlled by the AE - is installed on the machine and one of it's  
    '' Secondary Stage installers Install Source locations is missing
    '' Else it returns true
    Private Function SourceMSIsArePresent(ProductName As String) As Boolean
        Dim Result As Boolean = True

        ' Iterate all the AutoCAD based products AutoCAD, Map, Civil etc
        GeneralMessageBox("Checking if necessary MSI files are present to see if resets can be performed", , , , , , , , True, LogName)
        For Each Product As Jacobs.Common.Settings.Manager.AutoCADProduct In Jacobs.Common.Settings.Settings.Manager.AutoCADs
            If Product.Name.ToUpper = ProductName.ToUpper Then


                ' See if this AutoCAD is installed
                If Jacobs.Common.Core.RegistryValueExists("HKLM", Product.RegKey, Product.CheckKeyForProductExist) Then
                    ' Iterate it's Secondary Stage installers
                    Dim instance As RegistryKey = OpenInstanceOfRegistry("HKLM", Product.RegKey & "\UserData", False, True)
                    ' Get all the KeyValues in the UserData hive
                    Dim Keys As String() = instance.GetValueNames
                    ' Make sure we had some
                    If Keys.Length <> 0 Then
                        ' Go through each of the keys found 
                        For Each KeyVal As String In Keys
                            ' Check that they are valid GUIDs
                            If KeyVal.StartsWith("{") Then
                                ' Find the MSI source location on the Uninstall hive for the related product
                                Dim InstallerID As String = ConvertGUIDtoInstallerID(KeyVal)
                                Dim LocalPackage As String = RegistryRead("HKLM", "SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\" & InstallerID & "\InstallProperties", "LocalPackage", False)
                                Dim DisplayName As String = RegistryRead("HKLM", "SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\" & InstallerID & "\InstallProperties", "DisplayName", False)
                                ' Hopefully there was one there
                                If LocalPackage <> Nothing Then
                                    ' Check to see if that location was there
                                    If System.IO.File.Exists(LocalPackage) <> True Then
                                        Result = False
                                        GeneralMessageBox("Install Source for " & KeyVal & " not Found ! ", , , , , , , , True, LogName)
                                    Else
                                        GeneralMessageBox("Install Source Found for: " & DisplayName & " -> " & LocalPackage, , , , , , , , True, LogName)
                                    End If
                                Else
                                    ' Skip no InstallSource registry key available to check
                                    GeneralMessageBox("No InstallSource registry key available", , , , , , , , True, LogName)
                                    GeneralMessageBox("Checking if DFS location is present", , , , , , , , True, LogName)
                                    ' At the very least check that the DFS location is present (which would mean a connection to a company domain)
                                    If System.IO.Directory.Exists(Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSShareLocation) <> True Then
                                        Result = False
                                        GeneralMessageBox("DFS location is not present", , , , , , , , True, LogName)
                                    Else
                                        GeneralMessageBox("DFS location is present", , , , , , , , True, LogName)
                                    End If
                                End If
                            Else
                                ' Skip this is not a GUID for product code
                                GeneralMessageBox("This Key not a GUID for product code skipped: " & KeyVal, , , , , , , , True, LogName)
                            End If
                        Next
                    Else
                        ' Skip there were no secondary stage installers for this product
                        GeneralMessageBox("No secondary stage installers for this product", , , , , , , , True, LogName)
                    End If
                Else
                    ' Skip the AutoCAD product tested is not installed on this machine
                    GeneralMessageBox("AutoCAD product tested is not installed on this machine", , , , , , , , True, LogName)
                End If
            End If

        Next

        Return Result

    End Function

    ''' <summary>
    ''' Returns all the Secondary Installer GUIDs currently installed for the selected AutoCAD based product
    ''' </summary>
    ''' <param name="Product"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSecondaryStageInstallerGUIDs(Product As Jacobs.Common.Settings.Manager.AutoCADProduct) As Collection

        Dim Result As New Collection

        ' See if this AutoCAD is installed
        If Jacobs.Common.Core.RegistryValueExists("HKLM", Product.RegKey, Product.CheckKeyForProductExist) Then

            ' Iterate it's Secondary Stage installers
            Dim instance As RegistryKey = OpenInstanceOfRegistry("HKLM", Product.RegKey & "\UserData", False, True)

            ' Get all the KeyValues in the UserData hive
            Dim Keys As String() = instance.GetValueNames

            ' Make sure we had some
            If Keys.Length <> 0 Then
                ' Go through each of the keys found 
                For Each KeyVal As String In Keys
                    ' Check that they are valid GUIDs
                    If KeyVal.StartsWith("{") Then
                        Result.Add(KeyVal)
                    End If
                Next
            End If
        End If

        Return Result

    End Function

    ''' <summary>
    ''' Returns all the Secondary Installer GUIDs currently installed for the selected AutoCAD based product
    ''' </summary>
    ''' <param name="Product"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetSecondaryStageInstallerHKCUHives(Product As Jacobs.Common.Settings.Manager.AutoCADProduct) As Collection

        Dim Result As New Collection

        ' See if this AutoCAD is installed
        If Jacobs.Common.Core.RegistryValueExists("HKLM", Product.RegKey, Product.CheckKeyForProductExist) Then

            ' Iterate it's Secondary Stage installers
            Dim instance As RegistryKey = OpenInstanceOfRegistry("HKLM", Product.RegKey & "\UserData", False, True)

            ' Get all the KeyValues in the UserData hive
            Dim Keys As String() = instance.GetValueNames

            ' Make sure we had some
            If Keys.Length <> 0 Then
                ' Go through each of the keys found 
                For Each KeyVal As String In Keys
                    ' Check that they are valid GUIDs
                    If KeyVal.StartsWith("{") Then

                        Result.Add(instance.GetValue(KeyVal))

                    End If
                Next
            End If
        End If

        Return Result

    End Function


    ''' <summary>
    ''' Converts a GUID to a windows Installer ID 
    ''' The Install ID can be derived from the GUID 
    '''     {40B71988-5830-4A5E-B866-B5C7ABF3CF02}
    ''' 1. Remove braces
    ''' 2. Split the original GUID string up into 2 parts after the second hyphen, 
    '''     40B71988-5830-4A5E      -     B866-B5C7ABF3CF02
    ''' 3. In the first part each block is just reversed hyphens removed 
    '''     88917B04 0385 E5A4
    ''' 4. In the second part characters are reversed in groups of 2 (hyphens removed)
    '''     8B 66 5B 7C BA 3F FC 20
    ''' Result 
    '''   88917B040385E5A48B665B7CBA3FFC20
    ''' </summary>
    ''' <param name="GUID"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function ConvertGUIDtoInstallerID(GUID As String) As String

        Dim NewID As String = String.Empty

        '' Remove the braces to get a clean GUID
        GUID = GUID.Replace("{", "")
        GUID = GUID.Replace("}", "")

        Dim FirstPartGUID As String = GUID.Split("-")(0) & "-" & GUID.Split("-")(1) & "-" & GUID.Split("-")(2)
        Dim SecondPartGUID As String = GUID.Split("-")(3) & GUID.Split("-")(4)

        FirstPartGUID = StrReverse(FirstPartGUID.Split("-")(0)) & StrReverse(FirstPartGUID.Split("-")(1)) & StrReverse(FirstPartGUID.Split("-")(2))

        SecondPartGUID = StrReverse(SecondPartGUID.Substring(0, 2)) &
                            StrReverse(SecondPartGUID.Substring(2, 2)) &
                            StrReverse(SecondPartGUID.Substring(4, 2)) &
                            StrReverse(SecondPartGUID.Substring(6, 2)) &
                            StrReverse(SecondPartGUID.Substring(8, 2)) &
                            StrReverse(SecondPartGUID.Substring(10, 2)) &
                            StrReverse(SecondPartGUID.Substring(12, 2)) &
                            StrReverse(SecondPartGUID.Substring(14, 2))

        NewID = FirstPartGUID & SecondPartGUID

        Return NewID

    End Function

    ''' <summary>
    ''' These buttons carry out functions that require administrative permissions 
    ''' If the program is not being elevated by Avecto or is not being run by an administrator
    ''' These buttons will not be available.
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub EnableDisableButtonsThatRequireAdminRights()

        If DoWeHaveAdminRights() = True Then
            ProductionButton.Visible = True
            TestingButton.Visible = True
            DevelopmentButton.Visible = True
            EnableAEButton.Visible = True
            DisableAEButton.Visible = True
            VirusRemoverButton.Visible = True
            ProjectWiseOnButton.Visible = True
            ProjectWiseOffButton.Visible = True
        Else
            ProductionButton.Visible = False
            TestingButton.Visible = False
            DevelopmentButton.Visible = False
            EnableAEButton.Visible = False
            DisableAEButton.Visible = False
            VirusRemoverButton.Visible = False
            ProjectWiseOnButton.Visible = False
            ProjectWiseOffButton.Visible = False
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim ExeFileName As String = CombinePath(Jacobs.Common.Settings.Settings.Manager.DFSManager.Path, Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSDownloaderWindowsFileName)
        'Click the Shift Key
        If My.Computer.Keyboard.ShiftKeyDown Then
            DorobocopyCopy()
            'To update the client selector added by SHoughton 17/01/17
            'PopulateListBoxes()
        Else
            If File.Exists(ExeFileName) Then
                DoDFSDownloaderCopy(ExeFileName)
            Else
                DorobocopyCopy()
                'To update the client selector added by SHoughton 17/01/17
                'PopulateListBoxes()
            End If
        End If

    End Sub

    Private Sub DoDFSDownloaderCopy(ExeFileName As String)

        Dim p As New System.Diagnostics.Process

        Dim Arguments As String = "Source=" & CombinePath(Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSShareLocation, "\Jacobs\Production\CAD Environment\Autodesk\AutoCAD 2017 BlockLibrary") & ";" &
                                  "FolderFilter=Jacobs*;" &
                                  "FileFilter=*.*;" &
                                  "Destination=C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Lib;" &
                                  "ByPassKeyHive=Software\Jacobs\Lib R21\DFSDownloadBypass;" &
                                  "ByPassKey=DFSDownload;" &
                                  "CheckDFSChangeLog=False;" &
                                  "DFSChangesFile=DFSChange.LOG;" &
                                  "RecurseSubFolders=TRUE;" &
                                  "CallingApp=User Activated Manual Download;" &
                                  "DeleteIfNotOnDFS=False;" &
                                  "ProductInstalledKey="
        Try
            p.StartInfo.UseShellExecute = False
            p.StartInfo.FileName = ExeFileName
            p.StartInfo.Arguments = Arguments
            p.StartInfo.CreateNoWindow = True
            p.StartInfo.WindowStyle = ProcessWindowStyle.Maximized

            p.Start()
            p.WaitForExit()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Arguments = "Source=" & CombinePath(Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSShareLocation, "\Jacobs\Production\CAD Environment\Autodesk\AutoCAD 2017 Configurations") & ";" &
                    "FolderFilter=Jacobs*;" &
                    "FileFilter=*.*;" &
                    "Destination=C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Clients;" &
                    "ByPassKeyHive=Software\Jacobs\Configurations R21\DFSDownloadBypass;" &
                    "ByPassKey=DFSDownload;" &
                    "CheckDFSChangeLog=False;" &
                    "DFSChangesFile=DFSChange.LOG;" &
                    "RecurseSubFolders=TRUE;" &
                    "CallingApp=User Activate Manual Download;" &
                    "DeleteIfNotOnDFS=False;" &
                    "ProductInstalledKey="

        Try
            p.StartInfo.Arguments = Arguments
            p.Start()
            p.WaitForExit()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub DorobocopyCopy()

        ' Dim Switches As String = "/MIR /R:1 /W:1 /LOG+:" & """%TMP%\UpdatingCADEnvironment-%ComputerName%-%UserDomain%-%UserName%.log"""

        Dim TempFolder As String = Jacobs.Common.Settings.Manager.EvaluateExpression("[TEMP]")
        'Removed Log file by Shoughton 19/12/16
        Dim Switches As String = "/S /R:1 /W:1" & Chr(34)
        'Dim Switches As String = "/S /R:1 /W:1 /LOG+:" & Chr(34) & TempFolder & "\UpdatingCADEnvironment.log" & Chr(34)

        Dim SourceFolder As String = CombinePath(Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSShareLocation, "\Jacobs\Production\CAD Environment\Autodesk\AutoCAD 2017 Configurations")
        Dim DestFolder As String = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Clients"
        Dim AppToCopy As String = Chr(34) & SourceFolder & Chr(34) & " " & Chr(34) & DestFolder & Chr(34) & " " & Switches

        domirror(AppToCopy)

        'Removed Log file reference from message box by SHoughton 19/12/16
        MessageBox.Show("Blocklibrary Update Configurations Complete.", "Robocopy Completed", MessageBoxButtons.OK)
        'MessageBox.Show("Blocklibrary Update Configurations Complete." & vbCrLf & "See %temp%\UpdatingCADEnvironment.log for details", "Robocopy Completed", MessageBoxButtons.OK)

        SourceFolder = CombinePath(Jacobs.Common.Settings.Settings.Manager.DFSManager.DFSShareLocation, "\Jacobs\Production\CAD Environment\Autodesk\AutoCAD 2017 BlockLibrary")
        DestFolder = "C:\Users\Public\Jacobs\Jacobs AutoCAD Environment R21\Lib"

        AppToCopy = Chr(34) & SourceFolder & Chr(34) & " " & Chr(34) & DestFolder & Chr(34) & " " & Switches

        domirror(AppToCopy)

        'Remove Log file rerference from message box by SHoughton 19/12/16
        MessageBox.Show("Blocklibrary Update Block Library Complete.", "Robocopy Copleted", MessageBoxButtons.OK)
        'MessageBox.Show("Blocklibrary Update Block Library Complete." & vbCrLf & "See %temp%\UpdatingCADEnvironment.log for details", "Robocopy Copleted", MessageBoxButtons.OK)

    End Sub

    Private Sub domirror(AppToCopy As String)

        If MessageBox.Show("Are you sure you wish to try a Robocopy ? " & vbCrLf & vbCrLf & "ROBOCOPY.EXE " & AppToCopy, "Confirm Robocopy", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            Dim p As New System.Diagnostics.Process

            'Remove Show log by SHoughton 19/12/16
            'ShowLog("%Tmp%\UpdatingCADEnvironment.log")


            Try
                p.StartInfo.UseShellExecute = False
                p.StartInfo.FileName = "Robocopy.Exe"
                p.StartInfo.Arguments = AppToCopy
                p.StartInfo.CreateNoWindow = True
                p.StartInfo.WindowStyle = ProcessWindowStyle.Maximized

                'Added Curse style by Steven Houghton 16/01/17
                Me.Cursor = Cursors.WaitCursor

                p.Start()
                p.WaitForExit()

                'Changed Curse style back to arrow by Steven Houghton 16/01/17
                Me.Cursor = Cursors.Arrow

                'Removed log file by SHoughton 19/12/16
                'If Not System.IO.File.Exists("C:\Windows\CCM\Logs\CMTrace.exe") Then
                'Process.Start("notepad.exe " & "%Tmp%\UpdatingCADEnvironment.log")
                'End If


            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Public Sub ShowLog(Optional OtherLogFile As String = "")
        Dim LogReader As String = "C:\Windows\CCM\Logs\CMTrace.exe"

        Dim mylog As String = String.Empty
        Dim LogName As String = "%Tmp%\UpdatingCADEnvironment.log"

        If OtherLogFile <> "" Then
            mylog = ReplaceWithEvironmentVars(OtherLogFile)
        Else
            If LogName <> String.Empty Then
                mylog = ReplaceWithEvironmentVars(LogName)
            Else
                mylog = ReplaceWithEvironmentVars("UpdatingCADEnvironment-%ComputerName%-%UserDomain%-%UserName%.log")
            End If
        End If

        '' Create a dummy log file if one does not exist so that we can open the log reader before the log actually exists
        If Not System.IO.File.Exists(mylog) Then
            WriteLineToTextFile(mylog, " ", True)
        End If

        Dim myLogReader As String = String.Empty

        If System.IO.File.Exists("C:\Windows\CCM\Logs\CMTrace.exe") Then
            myLogReader = "C:\Windows\CCM\Logs\CMTrace.exe"
        Else
            If System.IO.File.Exists("C:\CMTrace.exe") Then
                myLogReader = "C:\Windows\CCM\Logs\CMTrace.exe"
            Else
                myLogReader = "Notepad.exe"
            End If
        End If


        If LogName.Contains("\") Then
            myLogReader = LogReader
        Else
            myLogReader = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly.Location), LogReader)
        End If

        If System.IO.File.Exists(myLogReader) Then
            Shell(LogReader & " " & mylog)
        Else
            MessageBox.Show("The log reader program could not be found !" & vbCrLf & myLogReader, "Missing File Notification", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Function ReplaceWithEvironmentVars(StringToConvert As String) As String

        Do While StringToConvert.Contains("%")
            Dim VarStr As String = GetBetween(StringToConvert, "%", "%").ToString()
            StringToConvert = StringToConvert.Replace("%" & VarStr & "%", System.Environment.GetEnvironmentVariable(VarStr))
        Loop
        Return StringToConvert

    End Function

    Public Function GetBetween(IStringStr As String, IBefore As String, IPast As String)
        Dim iString As String
        iString = IStringStr
        iString = Microsoft.VisualBasic.Strings.Right(iString, Len(iString) - InStr(iString, IBefore) - Len(IBefore) + 1)
        iString = Mid(iString, 1, InStr(iString, IPast) - 1)
        GetBetween = iString
    End Function

End Class

