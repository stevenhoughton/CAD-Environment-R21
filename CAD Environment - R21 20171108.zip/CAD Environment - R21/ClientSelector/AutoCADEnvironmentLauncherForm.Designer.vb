﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CADEnvironmentLauncherForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CADEnvironmentLauncherForm))
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.RefreshProfileAndProductButton = New System.Windows.Forms.Button()
        Me.ResetSelectedButton = New System.Windows.Forms.Button()
        Me.WorkspaceLabel = New System.Windows.Forms.Label()
        Me.ProfileLabel = New System.Windows.Forms.Label()
        Me.ProfileComboBox = New System.Windows.Forms.ComboBox()
        Me.ProductLabel = New System.Windows.Forms.Label()
        Me.ProductComboBox = New System.Windows.Forms.ComboBox()
        Me.WorkSpaceTextBox = New System.Windows.Forms.TextBox()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.SummaryGroupBox = New System.Windows.Forms.GroupBox()
        Me.ContentsReportListBox = New System.Windows.Forms.ListBox()
        Me.DisciplinesListBox = New System.Windows.Forms.ListBox()
        Me.ClientsListBox = New System.Windows.Forms.ListBox()
        Me.ClientsearchButton = New System.Windows.Forms.Button()
        Me.RegionsListBox = New System.Windows.Forms.ListBox()
        Me.CountriesListBox = New System.Windows.Forms.ListBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.MainTabControl = New System.Windows.Forms.TabControl()
        Me.UsingTemplate = New System.Windows.Forms.TabPage()
        Me.PartialMenuListBox = New System.Windows.Forms.CheckedListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PartialMenuLabel = New System.Windows.Forms.Label()
        Me.ShowJacobsOnlyCheckBox = New System.Windows.Forms.CheckBox()
        Me.CountryLBLabel = New System.Windows.Forms.Label()
        Me.RegionLBLabel = New System.Windows.Forms.Label()
        Me.ClientLBLabel = New System.Windows.Forms.Label()
        Me.DisciplinesLBLabel = New System.Windows.Forms.Label()
        Me.StandardApplication = New System.Windows.Forms.TabPage()
        Me.AdditionalTools = New System.Windows.Forms.TabPage()
        Me.ActivateUserPGPButton = New System.Windows.Forms.Button()
        Me.EditUserPGPButton = New System.Windows.Forms.Button()
        Me.PointingToLabel = New System.Windows.Forms.Label()
        Me.ProductionButton = New System.Windows.Forms.Button()
        Me.TestingButton = New System.Windows.Forms.Button()
        Me.DevelopmentButton = New System.Windows.Forms.Button()
        Me.ScaleListCleanUpButton = New System.Windows.Forms.Button()
        Me.PurgeRegisteredAppsButton = New System.Windows.Forms.Button()
        Me.EnableAEButton = New System.Windows.Forms.Button()
        Me.ProjectWiseOffButton = New System.Windows.Forms.Button()
        Me.DisableAEButton = New System.Windows.Forms.Button()
        Me.VirusRemoverButton = New System.Windows.Forms.Button()
        Me.ProjectWiseOnButton = New System.Windows.Forms.Button()
        Me.Logs = New System.Windows.Forms.TabPage()
        Me.NavigateToLogFilesFolderButton = New System.Windows.Forms.Button()
        Me.ClearAllLogFilesButton = New System.Windows.Forms.Button()
        Me.TemplateManagement = New System.Windows.Forms.TabPage()
        Me.TemplatesGroupBox = New System.Windows.Forms.GroupBox()
        Me.ActionGroupBox = New System.Windows.Forms.GroupBox()
        Me.NewUsingUserProvidedRadioButton = New System.Windows.Forms.RadioButton()
        Me.RemoveRadioButton = New System.Windows.Forms.RadioButton()
        Me.NewUsingRadioButton = New System.Windows.Forms.RadioButton()
        Me.NewRadioButton = New System.Windows.Forms.RadioButton()
        Me.ModifyRadioButton = New System.Windows.Forms.RadioButton()
        Me.NewGroupBox = New System.Windows.Forms.GroupBox()
        Me.CountriesComboBox = New System.Windows.Forms.ComboBox()
        Me.CountriesLabel = New System.Windows.Forms.Label()
        Me.RegionsComboBox = New System.Windows.Forms.ComboBox()
        Me.RegionsLabel = New System.Windows.Forms.Label()
        Me.ClientTextBox = New System.Windows.Forms.TextBox()
        Me.ClientLabel = New System.Windows.Forms.Label()
        Me.DisciplinesComboBox = New System.Windows.Forms.ComboBox()
        Me.DisciplinesLabel = New System.Windows.Forms.Label()
        Me.SelectExistingGroupBox = New System.Windows.Forms.GroupBox()
        Me.ExistingClientsComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingCountriesComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingCountriesLabel = New System.Windows.Forms.Label()
        Me.ExistingRegionsComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingRegionsLabel = New System.Windows.Forms.Label()
        Me.ExistingClientsLabel = New System.Windows.Forms.Label()
        Me.ExistingDisciplinesComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingDisciplinesLabel = New System.Windows.Forms.Label()
        Me.TemplateDeployment = New System.Windows.Forms.TabPage()
        Me.TemplateDeploymentGroupBox = New System.Windows.Forms.GroupBox()
        Me.DeleteTemplateButton = New System.Windows.Forms.Button()
        Me.BrowseToClientsToDeployButton = New System.Windows.Forms.Button()
        Me.RefreshConfigsToDeployListButton = New System.Windows.Forms.Button()
        Me.TemplatesToDeployListBox = New System.Windows.Forms.ListBox()
        Me.DistributionGroupBox = New System.Windows.Forms.GroupBox()
        Me.UATCheckBox = New System.Windows.Forms.CheckBox()
        Me.TestingCheckBox = New System.Windows.Forms.CheckBox()
        Me.ProductionCheckBox = New System.Windows.Forms.CheckBox()
        Me.ToAssetCheckBox = New System.Windows.Forms.CheckBox()
        Me.AEAdministration = New System.Windows.Forms.TabPage()
        Me.SettingsFilesGroupBox = New System.Windows.Forms.GroupBox()
        Me.SystemAdministratorsButton = New System.Windows.Forms.Button()
        Me.EmailPasswordButton = New System.Windows.Forms.Button()
        Me.ShowPWDButton = New System.Windows.Forms.Button()
        Me.CreateToolsDWGButton = New System.Windows.Forms.Button()
        Me.ToolsINIButton = New System.Windows.Forms.Button()
        Me.NavigateToLayerDefinitionsButton = New System.Windows.Forms.Button()
        Me.DrawingSheetsButton = New System.Windows.Forms.Button()
        Me.BlockfinderFavouritesButton = New System.Windows.Forms.Button()
        Me.NavigateToBlockLibraryButton = New System.Windows.Forms.Button()
        Me.HideTemplateButton = New System.Windows.Forms.Button()
        Me.SettingsFileButton = New System.Windows.Forms.Button()
        Me.RegionsFileButton = New System.Windows.Forms.Button()
        Me.OfficeAddressesButton = New System.Windows.Forms.Button()
        Me.TemplateBuildersFileButton = New System.Windows.Forms.Button()
        Me.DisciplinesFileButton = New System.Windows.Forms.Button()
        Me.TemplateMappingFileButton = New System.Windows.Forms.Button()
        Me.AdministrationDeployment = New System.Windows.Forms.TabPage()
        Me.SettingsFilesToDeployGroupBox = New System.Windows.Forms.GroupBox()
        Me.SettingFilesTodeployButton = New System.Windows.Forms.Button()
        Me.RefreshSettingsFilesToDeployListButton = New System.Windows.Forms.Button()
        Me.DeleteSelectedSettingsFilesButton = New System.Windows.Forms.Button()
        Me.SettingFilesToDeployListBox = New System.Windows.Forms.ListBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.UATAEAdminCheckBox = New System.Windows.Forms.CheckBox()
        Me.TestingAEAdminCheckBox = New System.Windows.Forms.CheckBox()
        Me.ProductionAEAdminCheckBox = New System.Windows.Forms.CheckBox()
        Me.ToAssetNoAEAdminCheckBox = New System.Windows.Forms.CheckBox()
        Me.LaunchAutoCADOKButton = New System.Windows.Forms.Button()
        Me.DeploySettingsFilesOKButton = New System.Windows.Forms.Button()
        Me.ProcessTemplateOKButton = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.DeployTemplateOKButton = New System.Windows.Forms.Button()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.TableLayoutPanelHelpOKCancel = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SummaryGroupBox.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MainTabControl.SuspendLayout()
        Me.UsingTemplate.SuspendLayout()
        Me.StandardApplication.SuspendLayout()
        Me.AdditionalTools.SuspendLayout()
        Me.Logs.SuspendLayout()
        Me.TemplateManagement.SuspendLayout()
        Me.TemplatesGroupBox.SuspendLayout()
        Me.ActionGroupBox.SuspendLayout()
        Me.NewGroupBox.SuspendLayout()
        Me.SelectExistingGroupBox.SuspendLayout()
        Me.TemplateDeployment.SuspendLayout()
        Me.TemplateDeploymentGroupBox.SuspendLayout()
        Me.DistributionGroupBox.SuspendLayout()
        Me.AEAdministration.SuspendLayout()
        Me.SettingsFilesGroupBox.SuspendLayout()
        Me.AdministrationDeployment.SuspendLayout()
        Me.SettingsFilesToDeployGroupBox.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TableLayoutPanelHelpOKCancel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(168, 5)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(64, 26)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        Me.ToolTip1.SetToolTip(Me.Cancel_Button, "Cancel operation")
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.OK_Button.Enabled = False
        Me.OK_Button.Location = New System.Drawing.Point(88, 5)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(64, 26)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        Me.ToolTip1.SetToolTip(Me.OK_Button, "Launch Autodesk Product Using Selected Template")
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(410, 27)
        Me.lblTitle.TabIndex = 11
        Me.lblTitle.Text = "AutoCAD Environment R21 Launcher"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 12
        Me.LogoPictureBox.TabStop = False
        '
        'RefreshProfileAndProductButton
        '
        Me.RefreshProfileAndProductButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RefreshProfileAndProductButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Button_Refresh_icon__Small
        Me.RefreshProfileAndProductButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.RefreshProfileAndProductButton.Location = New System.Drawing.Point(695, 430)
        Me.RefreshProfileAndProductButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RefreshProfileAndProductButton.Name = "RefreshProfileAndProductButton"
        Me.RefreshProfileAndProductButton.Size = New System.Drawing.Size(40, 39)
        Me.RefreshProfileAndProductButton.TabIndex = 21
        Me.RefreshProfileAndProductButton.UseVisualStyleBackColor = True
        '
        'ResetSelectedButton
        '
        Me.ResetSelectedButton.BackgroundImage = CType(resources.GetObject("ResetSelectedButton.BackgroundImage"), System.Drawing.Image)
        Me.ResetSelectedButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ResetSelectedButton.Location = New System.Drawing.Point(14, 15)
        Me.ResetSelectedButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ResetSelectedButton.Name = "ResetSelectedButton"
        Me.ResetSelectedButton.Size = New System.Drawing.Size(188, 40)
        Me.ResetSelectedButton.TabIndex = 20
        Me.ResetSelectedButton.Text = "       Reset Selected"
        Me.ToolTip1.SetToolTip(Me.ResetSelectedButton, "Resets Selected Product to a Pre Run State")
        Me.ResetSelectedButton.UseVisualStyleBackColor = True
        '
        'WorkspaceLabel
        '
        Me.WorkspaceLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WorkspaceLabel.AutoSize = True
        Me.WorkspaceLabel.Location = New System.Drawing.Point(739, 413)
        Me.WorkspaceLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.WorkspaceLabel.Name = "WorkspaceLabel"
        Me.WorkspaceLabel.Size = New System.Drawing.Size(113, 13)
        Me.WorkspaceLabel.TabIndex = 18
        Me.WorkspaceLabel.Text = "Last Workspace Used"
        '
        'ProfileLabel
        '
        Me.ProfileLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProfileLabel.AutoSize = True
        Me.ProfileLabel.Location = New System.Drawing.Point(442, 413)
        Me.ProfileLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ProfileLabel.Name = "ProfileLabel"
        Me.ProfileLabel.Size = New System.Drawing.Size(36, 13)
        Me.ProfileLabel.TabIndex = 16
        Me.ProfileLabel.Text = "Profile"
        '
        'ProfileComboBox
        '
        Me.ProfileComboBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProfileComboBox.FormattingEnabled = True
        Me.ProfileComboBox.Location = New System.Drawing.Point(445, 437)
        Me.ProfileComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ProfileComboBox.Name = "ProfileComboBox"
        Me.ProfileComboBox.Size = New System.Drawing.Size(242, 21)
        Me.ProfileComboBox.TabIndex = 15
        '
        'ProductLabel
        '
        Me.ProductLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProductLabel.AutoSize = True
        Me.ProductLabel.Location = New System.Drawing.Point(203, 413)
        Me.ProductLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ProductLabel.Name = "ProductLabel"
        Me.ProductLabel.Size = New System.Drawing.Size(44, 13)
        Me.ProductLabel.TabIndex = 14
        Me.ProductLabel.Text = "Product"
        '
        'ProductComboBox
        '
        Me.ProductComboBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProductComboBox.FormattingEnabled = True
        Me.ProductComboBox.Location = New System.Drawing.Point(206, 437)
        Me.ProductComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ProductComboBox.Name = "ProductComboBox"
        Me.ProductComboBox.Size = New System.Drawing.Size(232, 21)
        Me.ProductComboBox.TabIndex = 13
        '
        'WorkSpaceTextBox
        '
        Me.WorkSpaceTextBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WorkSpaceTextBox.Enabled = False
        Me.WorkSpaceTextBox.Location = New System.Drawing.Point(744, 437)
        Me.WorkSpaceTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.WorkSpaceTextBox.Name = "WorkSpaceTextBox"
        Me.WorkSpaceTextBox.Size = New System.Drawing.Size(242, 20)
        Me.WorkSpaceTextBox.TabIndex = 23
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Help_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Help_Button.Location = New System.Drawing.Point(8, 5)
        Me.Help_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.Size = New System.Drawing.Size(64, 26)
        Me.Help_Button.TabIndex = 24
        Me.Help_Button.Text = "Help"
        Me.ToolTip1.SetToolTip(Me.Help_Button, "Display help")
        '
        'SummaryGroupBox
        '
        Me.SummaryGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SummaryGroupBox.Controls.Add(Me.ContentsReportListBox)
        Me.SummaryGroupBox.Location = New System.Drawing.Point(8, 183)
        Me.SummaryGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SummaryGroupBox.Name = "SummaryGroupBox"
        Me.SummaryGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.SummaryGroupBox.Size = New System.Drawing.Size(956, 128)
        Me.SummaryGroupBox.TabIndex = 31
        Me.SummaryGroupBox.TabStop = False
        Me.SummaryGroupBox.Text = "Summary"
        '
        'ContentsReportListBox
        '
        Me.ContentsReportListBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ContentsReportListBox.FormattingEnabled = True
        Me.ContentsReportListBox.Location = New System.Drawing.Point(8, 22)
        Me.ContentsReportListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContentsReportListBox.Name = "ContentsReportListBox"
        Me.ContentsReportListBox.Size = New System.Drawing.Size(936, 56)
        Me.ContentsReportListBox.TabIndex = 6
        '
        'DisciplinesListBox
        '
        Me.DisciplinesListBox.FormattingEnabled = True
        Me.DisciplinesListBox.Location = New System.Drawing.Point(562, 28)
        Me.DisciplinesListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.DisciplinesListBox.Name = "DisciplinesListBox"
        Me.DisciplinesListBox.Size = New System.Drawing.Size(172, 108)
        Me.DisciplinesListBox.TabIndex = 3
        '
        'ClientsListBox
        '
        Me.ClientsListBox.FormattingEnabled = True
        Me.ClientsListBox.Location = New System.Drawing.Point(379, 28)
        Me.ClientsListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ClientsListBox.Name = "ClientsListBox"
        Me.ClientsListBox.Size = New System.Drawing.Size(172, 108)
        Me.ClientsListBox.TabIndex = 2
        '
        'ClientsearchButton
        '
        Me.ClientsearchButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClientsearchButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.search_b_icon_x_32
        Me.ClientsearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientsearchButton.Location = New System.Drawing.Point(928, 74)
        Me.ClientsearchButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClientsearchButton.Name = "ClientsearchButton"
        Me.ClientsearchButton.Size = New System.Drawing.Size(40, 39)
        Me.ClientsearchButton.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.ClientsearchButton, "Search though existing templates")
        Me.ClientsearchButton.UseVisualStyleBackColor = True
        '
        'RegionsListBox
        '
        Me.RegionsListBox.FormattingEnabled = True
        Me.RegionsListBox.Location = New System.Drawing.Point(192, 28)
        Me.RegionsListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.RegionsListBox.Name = "RegionsListBox"
        Me.RegionsListBox.Size = New System.Drawing.Size(172, 108)
        Me.RegionsListBox.TabIndex = 1
        '
        'CountriesListBox
        '
        Me.CountriesListBox.FormattingEnabled = True
        Me.CountriesListBox.Location = New System.Drawing.Point(8, 28)
        Me.CountriesListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.CountriesListBox.Name = "CountriesListBox"
        Me.CountriesListBox.Size = New System.Drawing.Size(172, 108)
        Me.CountriesListBox.TabIndex = 0
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.PictureBox2.ErrorImage = Nothing
        Me.PictureBox2.Location = New System.Drawing.Point(20, 11)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(938, 307)
        Me.PictureBox2.TabIndex = 32
        Me.PictureBox2.TabStop = False
        '
        'MainTabControl
        '
        Me.MainTabControl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MainTabControl.Controls.Add(Me.UsingTemplate)
        Me.MainTabControl.Controls.Add(Me.StandardApplication)
        Me.MainTabControl.Controls.Add(Me.AdditionalTools)
        Me.MainTabControl.Controls.Add(Me.Logs)
        Me.MainTabControl.Controls.Add(Me.TemplateManagement)
        Me.MainTabControl.Controls.Add(Me.TemplateDeployment)
        Me.MainTabControl.Controls.Add(Me.AEAdministration)
        Me.MainTabControl.Controls.Add(Me.AdministrationDeployment)
        Me.MainTabControl.Location = New System.Drawing.Point(9, 65)
        Me.MainTabControl.Margin = New System.Windows.Forms.Padding(4)
        Me.MainTabControl.Name = "MainTabControl"
        Me.MainTabControl.SelectedIndex = 0
        Me.MainTabControl.Size = New System.Drawing.Size(986, 346)
        Me.MainTabControl.TabIndex = 33
        '
        'UsingTemplate
        '
        Me.UsingTemplate.Controls.Add(Me.PartialMenuListBox)
        Me.UsingTemplate.Controls.Add(Me.Button1)
        Me.UsingTemplate.Controls.Add(Me.PartialMenuLabel)
        Me.UsingTemplate.Controls.Add(Me.ShowJacobsOnlyCheckBox)
        Me.UsingTemplate.Controls.Add(Me.CountryLBLabel)
        Me.UsingTemplate.Controls.Add(Me.RegionLBLabel)
        Me.UsingTemplate.Controls.Add(Me.CountriesListBox)
        Me.UsingTemplate.Controls.Add(Me.ClientsearchButton)
        Me.UsingTemplate.Controls.Add(Me.ClientLBLabel)
        Me.UsingTemplate.Controls.Add(Me.SummaryGroupBox)
        Me.UsingTemplate.Controls.Add(Me.DisciplinesLBLabel)
        Me.UsingTemplate.Controls.Add(Me.RegionsListBox)
        Me.UsingTemplate.Controls.Add(Me.DisciplinesListBox)
        Me.UsingTemplate.Controls.Add(Me.ClientsListBox)
        Me.UsingTemplate.Location = New System.Drawing.Point(4, 22)
        Me.UsingTemplate.Margin = New System.Windows.Forms.Padding(4)
        Me.UsingTemplate.Name = "UsingTemplate"
        Me.UsingTemplate.Padding = New System.Windows.Forms.Padding(4)
        Me.UsingTemplate.Size = New System.Drawing.Size(978, 320)
        Me.UsingTemplate.TabIndex = 0
        Me.UsingTemplate.Text = "Select Template"
        Me.UsingTemplate.UseVisualStyleBackColor = True
        '
        'PartialMenuListBox
        '
        Me.PartialMenuListBox.FormattingEnabled = True
        Me.PartialMenuListBox.HorizontalScrollbar = True
        Me.PartialMenuListBox.Location = New System.Drawing.Point(745, 28)
        Me.PartialMenuListBox.Name = "PartialMenuListBox"
        Me.PartialMenuListBox.Size = New System.Drawing.Size(172, 109)
        Me.PartialMenuListBox.TabIndex = 50
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(928, 28)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(40, 39)
        Me.Button1.TabIndex = 49
        Me.ToolTip1.SetToolTip(Me.Button1, "Download Configs and Block Library Updates")
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PartialMenuLabel
        '
        Me.PartialMenuLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PartialMenuLabel.AutoSize = True
        Me.PartialMenuLabel.Location = New System.Drawing.Point(746, 8)
        Me.PartialMenuLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PartialMenuLabel.Name = "PartialMenuLabel"
        Me.PartialMenuLabel.Size = New System.Drawing.Size(93, 13)
        Me.PartialMenuLabel.TabIndex = 35
        Me.PartialMenuLabel.Text = "Partial Menu Load"
        '
        'ShowJacobsOnlyCheckBox
        '
        Me.ShowJacobsOnlyCheckBox.AutoSize = True
        Me.ShowJacobsOnlyCheckBox.Location = New System.Drawing.Point(425, 6)
        Me.ShowJacobsOnlyCheckBox.Name = "ShowJacobsOnlyCheckBox"
        Me.ShowJacobsOnlyCheckBox.Size = New System.Drawing.Size(84, 17)
        Me.ShowJacobsOnlyCheckBox.TabIndex = 48
        Me.ShowJacobsOnlyCheckBox.Text = "Jacobs Only"
        Me.ShowJacobsOnlyCheckBox.UseVisualStyleBackColor = True
        '
        'CountryLBLabel
        '
        Me.CountryLBLabel.AutoSize = True
        Me.CountryLBLabel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CountryLBLabel.Location = New System.Drawing.Point(5, 8)
        Me.CountryLBLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.CountryLBLabel.Name = "CountryLBLabel"
        Me.CountryLBLabel.Size = New System.Drawing.Size(43, 13)
        Me.CountryLBLabel.TabIndex = 47
        Me.CountryLBLabel.Text = "Country"
        '
        'RegionLBLabel
        '
        Me.RegionLBLabel.AutoSize = True
        Me.RegionLBLabel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.RegionLBLabel.Location = New System.Drawing.Point(189, 8)
        Me.RegionLBLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.RegionLBLabel.Name = "RegionLBLabel"
        Me.RegionLBLabel.Size = New System.Drawing.Size(41, 13)
        Me.RegionLBLabel.TabIndex = 44
        Me.RegionLBLabel.Text = "Region"
        '
        'ClientLBLabel
        '
        Me.ClientLBLabel.AutoSize = True
        Me.ClientLBLabel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ClientLBLabel.Location = New System.Drawing.Point(375, 8)
        Me.ClientLBLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ClientLBLabel.Name = "ClientLBLabel"
        Me.ClientLBLabel.Size = New System.Drawing.Size(33, 13)
        Me.ClientLBLabel.TabIndex = 46
        Me.ClientLBLabel.Text = "Client"
        '
        'DisciplinesLBLabel
        '
        Me.DisciplinesLBLabel.AutoSize = True
        Me.DisciplinesLBLabel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.DisciplinesLBLabel.Location = New System.Drawing.Point(560, 8)
        Me.DisciplinesLBLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.DisciplinesLBLabel.Name = "DisciplinesLBLabel"
        Me.DisciplinesLBLabel.Size = New System.Drawing.Size(57, 13)
        Me.DisciplinesLBLabel.TabIndex = 45
        Me.DisciplinesLBLabel.Text = "Disciplines"
        '
        'StandardApplication
        '
        Me.StandardApplication.Controls.Add(Me.PictureBox2)
        Me.StandardApplication.Location = New System.Drawing.Point(4, 22)
        Me.StandardApplication.Margin = New System.Windows.Forms.Padding(4)
        Me.StandardApplication.Name = "StandardApplication"
        Me.StandardApplication.Padding = New System.Windows.Forms.Padding(4)
        Me.StandardApplication.Size = New System.Drawing.Size(978, 320)
        Me.StandardApplication.TabIndex = 1
        Me.StandardApplication.Text = "Standard Application"
        Me.StandardApplication.UseVisualStyleBackColor = True
        '
        'AdditionalTools
        '
        Me.AdditionalTools.Controls.Add(Me.ActivateUserPGPButton)
        Me.AdditionalTools.Controls.Add(Me.EditUserPGPButton)
        Me.AdditionalTools.Controls.Add(Me.PointingToLabel)
        Me.AdditionalTools.Controls.Add(Me.ProductionButton)
        Me.AdditionalTools.Controls.Add(Me.TestingButton)
        Me.AdditionalTools.Controls.Add(Me.DevelopmentButton)
        Me.AdditionalTools.Controls.Add(Me.ScaleListCleanUpButton)
        Me.AdditionalTools.Controls.Add(Me.ResetSelectedButton)
        Me.AdditionalTools.Controls.Add(Me.PurgeRegisteredAppsButton)
        Me.AdditionalTools.Controls.Add(Me.EnableAEButton)
        Me.AdditionalTools.Controls.Add(Me.ProjectWiseOffButton)
        Me.AdditionalTools.Controls.Add(Me.DisableAEButton)
        Me.AdditionalTools.Controls.Add(Me.VirusRemoverButton)
        Me.AdditionalTools.Controls.Add(Me.ProjectWiseOnButton)
        Me.AdditionalTools.Location = New System.Drawing.Point(4, 22)
        Me.AdditionalTools.Margin = New System.Windows.Forms.Padding(4)
        Me.AdditionalTools.Name = "AdditionalTools"
        Me.AdditionalTools.Size = New System.Drawing.Size(978, 320)
        Me.AdditionalTools.TabIndex = 2
        Me.AdditionalTools.Text = "Additional Tools"
        Me.AdditionalTools.UseVisualStyleBackColor = True
        '
        'ActivateUserPGPButton
        '
        Me.ActivateUserPGPButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.process_accept_icon_x32
        Me.ActivateUserPGPButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ActivateUserPGPButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ActivateUserPGPButton.Location = New System.Drawing.Point(301, 256)
        Me.ActivateUserPGPButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ActivateUserPGPButton.Name = "ActivateUserPGPButton"
        Me.ActivateUserPGPButton.Size = New System.Drawing.Size(188, 40)
        Me.ActivateUserPGPButton.TabIndex = 68
        Me.ActivateUserPGPButton.Text = "    Activate User PGP"
        Me.ToolTip1.SetToolTip(Me.ActivateUserPGPButton, "User PGP file needs to be manually activated after a reset")
        Me.ActivateUserPGPButton.UseVisualStyleBackColor = True
        '
        'EditUserPGPButton
        '
        Me.EditUserPGPButton.BackgroundImage = CType(resources.GetObject("EditUserPGPButton.BackgroundImage"), System.Drawing.Image)
        Me.EditUserPGPButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EditUserPGPButton.Location = New System.Drawing.Point(301, 208)
        Me.EditUserPGPButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EditUserPGPButton.Name = "EditUserPGPButton"
        Me.EditUserPGPButton.Size = New System.Drawing.Size(188, 40)
        Me.EditUserPGPButton.TabIndex = 63
        Me.EditUserPGPButton.Text = "     User PGP"
        Me.ToolTip1.SetToolTip(Me.EditUserPGPButton, "Edit your user PGP file - this file is not removed by reset")
        Me.EditUserPGPButton.UseVisualStyleBackColor = True
        '
        'PointingToLabel
        '
        Me.PointingToLabel.AutoSize = True
        Me.PointingToLabel.Location = New System.Drawing.Point(321, 171)
        Me.PointingToLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.PointingToLabel.Name = "PointingToLabel"
        Me.PointingToLabel.Size = New System.Drawing.Size(16, 13)
        Me.PointingToLabel.TabIndex = 42
        Me.PointingToLabel.Text = "..."
        '
        'ProductionButton
        '
        Me.ProductionButton.BackgroundImage = CType(resources.GetObject("ProductionButton.BackgroundImage"), System.Drawing.Image)
        Me.ProductionButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ProductionButton.Location = New System.Drawing.Point(301, 15)
        Me.ProductionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ProductionButton.Name = "ProductionButton"
        Me.ProductionButton.Size = New System.Drawing.Size(188, 40)
        Me.ProductionButton.TabIndex = 32
        Me.ProductionButton.Text = "      Point To Production"
        Me.ToolTip1.SetToolTip(Me.ProductionButton, "Point the PC to the Production area - next time a user logs in the files will be " &
        "downloaded")
        Me.ProductionButton.UseVisualStyleBackColor = True
        '
        'TestingButton
        '
        Me.TestingButton.BackgroundImage = CType(resources.GetObject("TestingButton.BackgroundImage"), System.Drawing.Image)
        Me.TestingButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TestingButton.Location = New System.Drawing.Point(301, 63)
        Me.TestingButton.Margin = New System.Windows.Forms.Padding(4)
        Me.TestingButton.Name = "TestingButton"
        Me.TestingButton.Size = New System.Drawing.Size(188, 40)
        Me.TestingButton.TabIndex = 33
        Me.TestingButton.Text = "     Point To Testing"
        Me.ToolTip1.SetToolTip(Me.TestingButton, "Point the PC to the Testing area - next time a user logs in the files will be dow" &
        "nloaded")
        Me.TestingButton.UseVisualStyleBackColor = True
        '
        'DevelopmentButton
        '
        Me.DevelopmentButton.BackgroundImage = CType(resources.GetObject("DevelopmentButton.BackgroundImage"), System.Drawing.Image)
        Me.DevelopmentButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DevelopmentButton.Location = New System.Drawing.Point(301, 111)
        Me.DevelopmentButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DevelopmentButton.Name = "DevelopmentButton"
        Me.DevelopmentButton.Size = New System.Drawing.Size(188, 40)
        Me.DevelopmentButton.TabIndex = 41
        Me.DevelopmentButton.Text = "       Point To Development"
        Me.ToolTip1.SetToolTip(Me.DevelopmentButton, "Point the PC to the Development area - next time a user logs in the files will be" &
        " downloaded")
        Me.DevelopmentButton.UseVisualStyleBackColor = True
        '
        'ScaleListCleanUpButton
        '
        Me.ScaleListCleanUpButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Scale
        Me.ScaleListCleanUpButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ScaleListCleanUpButton.Location = New System.Drawing.Point(588, 62)
        Me.ScaleListCleanUpButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ScaleListCleanUpButton.Name = "ScaleListCleanUpButton"
        Me.ScaleListCleanUpButton.Size = New System.Drawing.Size(188, 40)
        Me.ScaleListCleanUpButton.TabIndex = 22
        Me.ScaleListCleanUpButton.Text = "      Purge Scale Lists"
        Me.ScaleListCleanUpButton.UseVisualStyleBackColor = True
        '
        'PurgeRegisteredAppsButton
        '
        Me.PurgeRegisteredAppsButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.BroomClean
        Me.PurgeRegisteredAppsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PurgeRegisteredAppsButton.Location = New System.Drawing.Point(588, 15)
        Me.PurgeRegisteredAppsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PurgeRegisteredAppsButton.Name = "PurgeRegisteredAppsButton"
        Me.PurgeRegisteredAppsButton.Size = New System.Drawing.Size(188, 40)
        Me.PurgeRegisteredAppsButton.TabIndex = 21
        Me.PurgeRegisteredAppsButton.Text = "     Purge Reg Apps"
        Me.PurgeRegisteredAppsButton.UseVisualStyleBackColor = True
        '
        'EnableAEButton
        '
        Me.EnableAEButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Actions_network_connect_icon_x_32
        Me.EnableAEButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EnableAEButton.Location = New System.Drawing.Point(14, 208)
        Me.EnableAEButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EnableAEButton.Name = "EnableAEButton"
        Me.EnableAEButton.Size = New System.Drawing.Size(188, 40)
        Me.EnableAEButton.TabIndex = 62
        Me.EnableAEButton.Text = "  Enable AE"
        Me.ToolTip1.SetToolTip(Me.EnableAEButton, "Enables the AutoCAD Environment R21 and DFS Downloads - Will Reset All Products")
        Me.EnableAEButton.UseVisualStyleBackColor = True
        '
        'ProjectWiseOffButton
        '
        Me.ProjectWiseOffButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Close_icon
        Me.ProjectWiseOffButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ProjectWiseOffButton.Location = New System.Drawing.Point(588, 208)
        Me.ProjectWiseOffButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ProjectWiseOffButton.Name = "ProjectWiseOffButton"
        Me.ProjectWiseOffButton.Size = New System.Drawing.Size(188, 40)
        Me.ProjectWiseOffButton.TabIndex = 31
        Me.ProjectWiseOffButton.Text = "       Project Wise Off"
        Me.ToolTip1.SetToolTip(Me.ProjectWiseOffButton, "Project Wise is currently ON clicking on this button will turn it OFF")
        Me.ProjectWiseOffButton.UseVisualStyleBackColor = True
        '
        'DisableAEButton
        '
        Me.DisableAEButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Actions_network_disconnect_icon_x_32
        Me.DisableAEButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DisableAEButton.Location = New System.Drawing.Point(14, 255)
        Me.DisableAEButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DisableAEButton.Name = "DisableAEButton"
        Me.DisableAEButton.Size = New System.Drawing.Size(188, 40)
        Me.DisableAEButton.TabIndex = 61
        Me.DisableAEButton.Text = "Disable AE"
        Me.ToolTip1.SetToolTip(Me.DisableAEButton, "Disables the AutoCAD Environment and prevents DFS Downloads - This Requires a Pas" &
        "sword and will reset all products")
        Me.DisableAEButton.UseVisualStyleBackColor = True
        '
        'VirusRemoverButton
        '
        Me.VirusRemoverButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Actions_irc_remove_operator_icon_x_32
        Me.VirusRemoverButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.VirusRemoverButton.Location = New System.Drawing.Point(588, 159)
        Me.VirusRemoverButton.Margin = New System.Windows.Forms.Padding(4)
        Me.VirusRemoverButton.Name = "VirusRemoverButton"
        Me.VirusRemoverButton.Size = New System.Drawing.Size(188, 40)
        Me.VirusRemoverButton.TabIndex = 24
        Me.VirusRemoverButton.Text = "     Virus Remover"
        Me.ToolTip1.SetToolTip(Me.VirusRemoverButton, "Run the Virus Remover tool on this machine - Note: This may take a while but it d" &
        "oes run in the background")
        Me.VirusRemoverButton.UseVisualStyleBackColor = True
        '
        'ProjectWiseOnButton
        '
        Me.ProjectWiseOnButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.check_icon
        Me.ProjectWiseOnButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ProjectWiseOnButton.Location = New System.Drawing.Point(588, 255)
        Me.ProjectWiseOnButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ProjectWiseOnButton.Name = "ProjectWiseOnButton"
        Me.ProjectWiseOnButton.Size = New System.Drawing.Size(188, 40)
        Me.ProjectWiseOnButton.TabIndex = 30
        Me.ProjectWiseOnButton.Text = "       Project Wise On"
        Me.ToolTip1.SetToolTip(Me.ProjectWiseOnButton, "Project wise is currently OFF clicking on this button will turn it ON")
        Me.ProjectWiseOnButton.UseVisualStyleBackColor = True
        '
        'Logs
        '
        Me.Logs.Controls.Add(Me.NavigateToLogFilesFolderButton)
        Me.Logs.Controls.Add(Me.ClearAllLogFilesButton)
        Me.Logs.Location = New System.Drawing.Point(4, 22)
        Me.Logs.Margin = New System.Windows.Forms.Padding(4)
        Me.Logs.Name = "Logs"
        Me.Logs.Size = New System.Drawing.Size(978, 320)
        Me.Logs.TabIndex = 5
        Me.Logs.Text = "Logs"
        Me.Logs.UseVisualStyleBackColor = True
        '
        'NavigateToLogFilesFolderButton
        '
        Me.NavigateToLogFilesFolderButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Windows_icon_x_32
        Me.NavigateToLogFilesFolderButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.NavigateToLogFilesFolderButton.Location = New System.Drawing.Point(316, 30)
        Me.NavigateToLogFilesFolderButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NavigateToLogFilesFolderButton.Name = "NavigateToLogFilesFolderButton"
        Me.NavigateToLogFilesFolderButton.Size = New System.Drawing.Size(160, 40)
        Me.NavigateToLogFilesFolderButton.TabIndex = 36
        Me.NavigateToLogFilesFolderButton.Text = "Log Files"
        Me.ToolTip1.SetToolTip(Me.NavigateToLogFilesFolderButton, "Runs windows explorer and navigates to user log folder")
        Me.NavigateToLogFilesFolderButton.UseVisualStyleBackColor = True
        '
        'ClearAllLogFilesButton
        '
        Me.ClearAllLogFilesButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.File_Delete_icon_x_32
        Me.ClearAllLogFilesButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClearAllLogFilesButton.Location = New System.Drawing.Point(316, 91)
        Me.ClearAllLogFilesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ClearAllLogFilesButton.Name = "ClearAllLogFilesButton"
        Me.ClearAllLogFilesButton.Size = New System.Drawing.Size(160, 40)
        Me.ClearAllLogFilesButton.TabIndex = 34
        Me.ClearAllLogFilesButton.Text = "Clear All"
        Me.ToolTip1.SetToolTip(Me.ClearAllLogFilesButton, "Delete all log files")
        Me.ClearAllLogFilesButton.UseVisualStyleBackColor = True
        '
        'TemplateManagement
        '
        Me.TemplateManagement.Controls.Add(Me.TemplatesGroupBox)
        Me.TemplateManagement.Location = New System.Drawing.Point(4, 22)
        Me.TemplateManagement.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplateManagement.Name = "TemplateManagement"
        Me.TemplateManagement.Size = New System.Drawing.Size(978, 320)
        Me.TemplateManagement.TabIndex = 4
        Me.TemplateManagement.Text = "Template Management"
        Me.TemplateManagement.ToolTipText = "Displays the password to disable the AE for today"
        Me.TemplateManagement.UseVisualStyleBackColor = True
        '
        'TemplatesGroupBox
        '
        Me.TemplatesGroupBox.Controls.Add(Me.ActionGroupBox)
        Me.TemplatesGroupBox.Controls.Add(Me.NewGroupBox)
        Me.TemplatesGroupBox.Controls.Add(Me.SelectExistingGroupBox)
        Me.TemplatesGroupBox.Location = New System.Drawing.Point(11, 14)
        Me.TemplatesGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplatesGroupBox.Name = "TemplatesGroupBox"
        Me.TemplatesGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.TemplatesGroupBox.Size = New System.Drawing.Size(749, 300)
        Me.TemplatesGroupBox.TabIndex = 63
        Me.TemplatesGroupBox.TabStop = False
        Me.TemplatesGroupBox.Text = "Template Creation and Modification"
        '
        'ActionGroupBox
        '
        Me.ActionGroupBox.Controls.Add(Me.NewUsingUserProvidedRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.RemoveRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.NewUsingRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.NewRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.ModifyRadioButton)
        Me.ActionGroupBox.Location = New System.Drawing.Point(18, 22)
        Me.ActionGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ActionGroupBox.Name = "ActionGroupBox"
        Me.ActionGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.ActionGroupBox.Size = New System.Drawing.Size(715, 80)
        Me.ActionGroupBox.TabIndex = 57
        Me.ActionGroupBox.TabStop = False
        Me.ActionGroupBox.Text = "Action"
        '
        'NewUsingUserProvidedRadioButton
        '
        Me.NewUsingUserProvidedRadioButton.AutoSize = True
        Me.NewUsingUserProvidedRadioButton.Location = New System.Drawing.Point(501, 32)
        Me.NewUsingUserProvidedRadioButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NewUsingUserProvidedRadioButton.Name = "NewUsingUserProvidedRadioButton"
        Me.NewUsingUserProvidedRadioButton.Size = New System.Drawing.Size(147, 17)
        Me.NewUsingUserProvidedRadioButton.TabIndex = 5
        Me.NewUsingUserProvidedRadioButton.Text = "New Using User Provided"
        Me.NewUsingUserProvidedRadioButton.UseVisualStyleBackColor = True
        '
        'RemoveRadioButton
        '
        Me.RemoveRadioButton.AutoSize = True
        Me.RemoveRadioButton.Location = New System.Drawing.Point(818, 32)
        Me.RemoveRadioButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RemoveRadioButton.Name = "RemoveRadioButton"
        Me.RemoveRadioButton.Size = New System.Drawing.Size(65, 17)
        Me.RemoveRadioButton.TabIndex = 3
        Me.RemoveRadioButton.Text = "Remove"
        Me.RemoveRadioButton.UseVisualStyleBackColor = True
        Me.RemoveRadioButton.Visible = False
        '
        'NewUsingRadioButton
        '
        Me.NewUsingRadioButton.AutoSize = True
        Me.NewUsingRadioButton.Location = New System.Drawing.Point(288, 32)
        Me.NewUsingRadioButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NewUsingRadioButton.Name = "NewUsingRadioButton"
        Me.NewUsingRadioButton.Size = New System.Drawing.Size(116, 17)
        Me.NewUsingRadioButton.TabIndex = 2
        Me.NewUsingRadioButton.Text = "New Using Existing"
        Me.NewUsingRadioButton.UseVisualStyleBackColor = True
        '
        'NewRadioButton
        '
        Me.NewRadioButton.AutoSize = True
        Me.NewRadioButton.Checked = True
        Me.NewRadioButton.Location = New System.Drawing.Point(29, 32)
        Me.NewRadioButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NewRadioButton.Name = "NewRadioButton"
        Me.NewRadioButton.Size = New System.Drawing.Size(47, 17)
        Me.NewRadioButton.TabIndex = 1
        Me.NewRadioButton.TabStop = True
        Me.NewRadioButton.Text = "New"
        Me.NewRadioButton.UseVisualStyleBackColor = True
        '
        'ModifyRadioButton
        '
        Me.ModifyRadioButton.AutoSize = True
        Me.ModifyRadioButton.Location = New System.Drawing.Point(151, 32)
        Me.ModifyRadioButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ModifyRadioButton.Name = "ModifyRadioButton"
        Me.ModifyRadioButton.Size = New System.Drawing.Size(56, 17)
        Me.ModifyRadioButton.TabIndex = 0
        Me.ModifyRadioButton.Text = "Modify"
        Me.ModifyRadioButton.UseVisualStyleBackColor = True
        '
        'NewGroupBox
        '
        Me.NewGroupBox.Controls.Add(Me.CountriesComboBox)
        Me.NewGroupBox.Controls.Add(Me.CountriesLabel)
        Me.NewGroupBox.Controls.Add(Me.RegionsComboBox)
        Me.NewGroupBox.Controls.Add(Me.RegionsLabel)
        Me.NewGroupBox.Controls.Add(Me.ClientTextBox)
        Me.NewGroupBox.Controls.Add(Me.ClientLabel)
        Me.NewGroupBox.Controls.Add(Me.DisciplinesComboBox)
        Me.NewGroupBox.Controls.Add(Me.DisciplinesLabel)
        Me.NewGroupBox.Location = New System.Drawing.Point(18, 210)
        Me.NewGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.NewGroupBox.Name = "NewGroupBox"
        Me.NewGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.NewGroupBox.Size = New System.Drawing.Size(715, 80)
        Me.NewGroupBox.TabIndex = 56
        Me.NewGroupBox.TabStop = False
        Me.NewGroupBox.Text = "New Name"
        '
        'CountriesComboBox
        '
        Me.CountriesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Australia", "Brazil", "Chile", "China", "India", "Malaysia", "Singapore", "United Kingdom"})
        Me.CountriesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CountriesComboBox.FormattingEnabled = True
        Me.CountriesComboBox.Location = New System.Drawing.Point(11, 44)
        Me.CountriesComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.CountriesComboBox.Name = "CountriesComboBox"
        Me.CountriesComboBox.Size = New System.Drawing.Size(160, 21)
        Me.CountriesComboBox.Sorted = True
        Me.CountriesComboBox.TabIndex = 36
        '
        'CountriesLabel
        '
        Me.CountriesLabel.AutoSize = True
        Me.CountriesLabel.Location = New System.Drawing.Point(11, 22)
        Me.CountriesLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.CountriesLabel.Name = "CountriesLabel"
        Me.CountriesLabel.Size = New System.Drawing.Size(43, 13)
        Me.CountriesLabel.TabIndex = 35
        Me.CountriesLabel.Text = "Country"
        '
        'RegionsComboBox
        '
        Me.RegionsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RegionsComboBox.FormattingEnabled = True
        Me.RegionsComboBox.Location = New System.Drawing.Point(185, 44)
        Me.RegionsComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.RegionsComboBox.Name = "RegionsComboBox"
        Me.RegionsComboBox.Size = New System.Drawing.Size(160, 21)
        Me.RegionsComboBox.TabIndex = 37
        '
        'RegionsLabel
        '
        Me.RegionsLabel.AutoSize = True
        Me.RegionsLabel.Location = New System.Drawing.Point(185, 22)
        Me.RegionsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.RegionsLabel.Name = "RegionsLabel"
        Me.RegionsLabel.Size = New System.Drawing.Size(41, 13)
        Me.RegionsLabel.TabIndex = 31
        Me.RegionsLabel.Text = "Region"
        '
        'ClientTextBox
        '
        Me.ClientTextBox.Location = New System.Drawing.Point(359, 46)
        Me.ClientTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ClientTextBox.Name = "ClientTextBox"
        Me.ClientTextBox.Size = New System.Drawing.Size(160, 20)
        Me.ClientTextBox.TabIndex = 38
        '
        'ClientLabel
        '
        Me.ClientLabel.AutoSize = True
        Me.ClientLabel.Location = New System.Drawing.Point(359, 22)
        Me.ClientLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ClientLabel.Name = "ClientLabel"
        Me.ClientLabel.Size = New System.Drawing.Size(33, 13)
        Me.ClientLabel.TabIndex = 34
        Me.ClientLabel.Text = "Client"
        '
        'DisciplinesComboBox
        '
        Me.DisciplinesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Architecture", "Electrical", "Mechanical", "Piping", "Mining", "Civil", "Spatial"})
        Me.DisciplinesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DisciplinesComboBox.FormattingEnabled = True
        Me.DisciplinesComboBox.Location = New System.Drawing.Point(532, 44)
        Me.DisciplinesComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.DisciplinesComboBox.Name = "DisciplinesComboBox"
        Me.DisciplinesComboBox.Size = New System.Drawing.Size(160, 21)
        Me.DisciplinesComboBox.Sorted = True
        Me.DisciplinesComboBox.TabIndex = 33
        '
        'DisciplinesLabel
        '
        Me.DisciplinesLabel.AutoSize = True
        Me.DisciplinesLabel.Location = New System.Drawing.Point(532, 22)
        Me.DisciplinesLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.DisciplinesLabel.Name = "DisciplinesLabel"
        Me.DisciplinesLabel.Size = New System.Drawing.Size(57, 13)
        Me.DisciplinesLabel.TabIndex = 32
        Me.DisciplinesLabel.Text = "Disciplines"
        '
        'SelectExistingGroupBox
        '
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingClientsComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingCountriesComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingCountriesLabel)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingRegionsComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingRegionsLabel)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingClientsLabel)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingDisciplinesComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingDisciplinesLabel)
        Me.SelectExistingGroupBox.Location = New System.Drawing.Point(18, 118)
        Me.SelectExistingGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SelectExistingGroupBox.Name = "SelectExistingGroupBox"
        Me.SelectExistingGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.SelectExistingGroupBox.Size = New System.Drawing.Size(715, 80)
        Me.SelectExistingGroupBox.TabIndex = 54
        Me.SelectExistingGroupBox.TabStop = False
        Me.SelectExistingGroupBox.Text = "Existing"
        '
        'ExistingClientsComboBox
        '
        Me.ExistingClientsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExistingClientsComboBox.FormattingEnabled = True
        Me.ExistingClientsComboBox.Location = New System.Drawing.Point(359, 39)
        Me.ExistingClientsComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ExistingClientsComboBox.Name = "ExistingClientsComboBox"
        Me.ExistingClientsComboBox.Size = New System.Drawing.Size(160, 21)
        Me.ExistingClientsComboBox.TabIndex = 46
        '
        'ExistingCountriesComboBox
        '
        Me.ExistingCountriesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Australia", "Brazil", "Chile", "China", "India", "Malaysia", "Singapore", "United Kingdom"})
        Me.ExistingCountriesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExistingCountriesComboBox.FormattingEnabled = True
        Me.ExistingCountriesComboBox.Location = New System.Drawing.Point(11, 39)
        Me.ExistingCountriesComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ExistingCountriesComboBox.Name = "ExistingCountriesComboBox"
        Me.ExistingCountriesComboBox.Size = New System.Drawing.Size(160, 21)
        Me.ExistingCountriesComboBox.Sorted = True
        Me.ExistingCountriesComboBox.TabIndex = 44
        '
        'ExistingCountriesLabel
        '
        Me.ExistingCountriesLabel.AutoSize = True
        Me.ExistingCountriesLabel.Location = New System.Drawing.Point(11, 18)
        Me.ExistingCountriesLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ExistingCountriesLabel.Name = "ExistingCountriesLabel"
        Me.ExistingCountriesLabel.Size = New System.Drawing.Size(43, 13)
        Me.ExistingCountriesLabel.TabIndex = 43
        Me.ExistingCountriesLabel.Text = "Country"
        '
        'ExistingRegionsComboBox
        '
        Me.ExistingRegionsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExistingRegionsComboBox.FormattingEnabled = True
        Me.ExistingRegionsComboBox.Location = New System.Drawing.Point(185, 39)
        Me.ExistingRegionsComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ExistingRegionsComboBox.Name = "ExistingRegionsComboBox"
        Me.ExistingRegionsComboBox.Size = New System.Drawing.Size(160, 21)
        Me.ExistingRegionsComboBox.TabIndex = 45
        '
        'ExistingRegionsLabel
        '
        Me.ExistingRegionsLabel.AutoSize = True
        Me.ExistingRegionsLabel.Location = New System.Drawing.Point(185, 18)
        Me.ExistingRegionsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ExistingRegionsLabel.Name = "ExistingRegionsLabel"
        Me.ExistingRegionsLabel.Size = New System.Drawing.Size(41, 13)
        Me.ExistingRegionsLabel.TabIndex = 39
        Me.ExistingRegionsLabel.Text = "Region"
        '
        'ExistingClientsLabel
        '
        Me.ExistingClientsLabel.AutoSize = True
        Me.ExistingClientsLabel.Location = New System.Drawing.Point(359, 18)
        Me.ExistingClientsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ExistingClientsLabel.Name = "ExistingClientsLabel"
        Me.ExistingClientsLabel.Size = New System.Drawing.Size(33, 13)
        Me.ExistingClientsLabel.TabIndex = 42
        Me.ExistingClientsLabel.Text = "Client"
        '
        'ExistingDisciplinesComboBox
        '
        Me.ExistingDisciplinesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Architecture", "Electrical", "Mechanical", "Piping", "Mining", "Civil", "Spatial"})
        Me.ExistingDisciplinesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ExistingDisciplinesComboBox.FormattingEnabled = True
        Me.ExistingDisciplinesComboBox.Location = New System.Drawing.Point(532, 39)
        Me.ExistingDisciplinesComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ExistingDisciplinesComboBox.Name = "ExistingDisciplinesComboBox"
        Me.ExistingDisciplinesComboBox.Size = New System.Drawing.Size(160, 21)
        Me.ExistingDisciplinesComboBox.Sorted = True
        Me.ExistingDisciplinesComboBox.TabIndex = 41
        '
        'ExistingDisciplinesLabel
        '
        Me.ExistingDisciplinesLabel.AutoSize = True
        Me.ExistingDisciplinesLabel.Location = New System.Drawing.Point(532, 18)
        Me.ExistingDisciplinesLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ExistingDisciplinesLabel.Name = "ExistingDisciplinesLabel"
        Me.ExistingDisciplinesLabel.Size = New System.Drawing.Size(57, 13)
        Me.ExistingDisciplinesLabel.TabIndex = 40
        Me.ExistingDisciplinesLabel.Text = "Disciplines"
        '
        'TemplateDeployment
        '
        Me.TemplateDeployment.Controls.Add(Me.TemplateDeploymentGroupBox)
        Me.TemplateDeployment.Location = New System.Drawing.Point(4, 22)
        Me.TemplateDeployment.Margin = New System.Windows.Forms.Padding(2)
        Me.TemplateDeployment.Name = "TemplateDeployment"
        Me.TemplateDeployment.Size = New System.Drawing.Size(978, 320)
        Me.TemplateDeployment.TabIndex = 7
        Me.TemplateDeployment.Text = "Template Deployment"
        Me.TemplateDeployment.UseVisualStyleBackColor = True
        '
        'TemplateDeploymentGroupBox
        '
        Me.TemplateDeploymentGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TemplateDeploymentGroupBox.Controls.Add(Me.DeleteTemplateButton)
        Me.TemplateDeploymentGroupBox.Controls.Add(Me.BrowseToClientsToDeployButton)
        Me.TemplateDeploymentGroupBox.Controls.Add(Me.RefreshConfigsToDeployListButton)
        Me.TemplateDeploymentGroupBox.Controls.Add(Me.TemplatesToDeployListBox)
        Me.TemplateDeploymentGroupBox.Controls.Add(Me.DistributionGroupBox)
        Me.TemplateDeploymentGroupBox.Location = New System.Drawing.Point(11, 14)
        Me.TemplateDeploymentGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplateDeploymentGroupBox.Name = "TemplateDeploymentGroupBox"
        Me.TemplateDeploymentGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.TemplateDeploymentGroupBox.Size = New System.Drawing.Size(928, 300)
        Me.TemplateDeploymentGroupBox.TabIndex = 65
        Me.TemplateDeploymentGroupBox.TabStop = False
        Me.TemplateDeploymentGroupBox.Text = "  Templates Availble for Deployment"
        '
        'DeleteTemplateButton
        '
        Me.DeleteTemplateButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Button_Delete_icon_32
        Me.DeleteTemplateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteTemplateButton.Location = New System.Drawing.Point(252, 190)
        Me.DeleteTemplateButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DeleteTemplateButton.Name = "DeleteTemplateButton"
        Me.DeleteTemplateButton.Size = New System.Drawing.Size(188, 40)
        Me.DeleteTemplateButton.TabIndex = 64
        Me.DeleteTemplateButton.Text = "     Delete"
        Me.ToolTip1.SetToolTip(Me.DeleteTemplateButton, "Delete Selected Templates")
        Me.DeleteTemplateButton.UseVisualStyleBackColor = True
        '
        'BrowseToClientsToDeployButton
        '
        Me.BrowseToClientsToDeployButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Windows_icon_x_32
        Me.BrowseToClientsToDeployButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BrowseToClientsToDeployButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BrowseToClientsToDeployButton.Location = New System.Drawing.Point(11, 190)
        Me.BrowseToClientsToDeployButton.Margin = New System.Windows.Forms.Padding(4)
        Me.BrowseToClientsToDeployButton.Name = "BrowseToClientsToDeployButton"
        Me.BrowseToClientsToDeployButton.Size = New System.Drawing.Size(188, 40)
        Me.BrowseToClientsToDeployButton.TabIndex = 63
        Me.BrowseToClientsToDeployButton.Text = "      Navigate"
        Me.ToolTip1.SetToolTip(Me.BrowseToClientsToDeployButton, "Opens up windows explorer in the templates to deploy folder.")
        Me.BrowseToClientsToDeployButton.UseVisualStyleBackColor = True
        '
        'RefreshConfigsToDeployListButton
        '
        Me.RefreshConfigsToDeployListButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Button_Refresh_icon__Small
        Me.RefreshConfigsToDeployListButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RefreshConfigsToDeployListButton.Location = New System.Drawing.Point(205, 190)
        Me.RefreshConfigsToDeployListButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RefreshConfigsToDeployListButton.Name = "RefreshConfigsToDeployListButton"
        Me.RefreshConfigsToDeployListButton.Size = New System.Drawing.Size(40, 40)
        Me.RefreshConfigsToDeployListButton.TabIndex = 41
        Me.RefreshConfigsToDeployListButton.UseVisualStyleBackColor = True
        '
        'TemplatesToDeployListBox
        '
        Me.TemplatesToDeployListBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TemplatesToDeployListBox.FormattingEnabled = True
        Me.TemplatesToDeployListBox.Location = New System.Drawing.Point(11, 20)
        Me.TemplatesToDeployListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplatesToDeployListBox.Name = "TemplatesToDeployListBox"
        Me.TemplatesToDeployListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.TemplatesToDeployListBox.Size = New System.Drawing.Size(895, 147)
        Me.TemplatesToDeployListBox.TabIndex = 40
        '
        'DistributionGroupBox
        '
        Me.DistributionGroupBox.Controls.Add(Me.UATCheckBox)
        Me.DistributionGroupBox.Controls.Add(Me.TestingCheckBox)
        Me.DistributionGroupBox.Controls.Add(Me.ProductionCheckBox)
        Me.DistributionGroupBox.Controls.Add(Me.ToAssetCheckBox)
        Me.DistributionGroupBox.Location = New System.Drawing.Point(11, 240)
        Me.DistributionGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.DistributionGroupBox.Name = "DistributionGroupBox"
        Me.DistributionGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.DistributionGroupBox.Size = New System.Drawing.Size(715, 50)
        Me.DistributionGroupBox.TabIndex = 39
        Me.DistributionGroupBox.TabStop = False
        Me.DistributionGroupBox.Text = "Distribution Locations"
        '
        'UATCheckBox
        '
        Me.UATCheckBox.AutoSize = True
        Me.UATCheckBox.Location = New System.Drawing.Point(568, 20)
        Me.UATCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.UATCheckBox.Name = "UATCheckBox"
        Me.UATCheckBox.Size = New System.Drawing.Size(89, 17)
        Me.UATCheckBox.TabIndex = 34
        Me.UATCheckBox.Text = "Development"
        Me.UATCheckBox.UseVisualStyleBackColor = True
        '
        'TestingCheckBox
        '
        Me.TestingCheckBox.AutoSize = True
        Me.TestingCheckBox.Location = New System.Drawing.Point(411, 20)
        Me.TestingCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TestingCheckBox.Name = "TestingCheckBox"
        Me.TestingCheckBox.Size = New System.Drawing.Size(61, 17)
        Me.TestingCheckBox.TabIndex = 33
        Me.TestingCheckBox.Text = "Testing"
        Me.TestingCheckBox.UseVisualStyleBackColor = True
        '
        'ProductionCheckBox
        '
        Me.ProductionCheckBox.AutoSize = True
        Me.ProductionCheckBox.Location = New System.Drawing.Point(232, 20)
        Me.ProductionCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ProductionCheckBox.Name = "ProductionCheckBox"
        Me.ProductionCheckBox.Size = New System.Drawing.Size(77, 17)
        Me.ProductionCheckBox.TabIndex = 32
        Me.ProductionCheckBox.Text = "Production"
        Me.ProductionCheckBox.UseVisualStyleBackColor = True
        '
        'ToAssetCheckBox
        '
        Me.ToAssetCheckBox.AutoSize = True
        Me.ToAssetCheckBox.Location = New System.Drawing.Point(12, 20)
        Me.ToAssetCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ToAssetCheckBox.Name = "ToAssetCheckBox"
        Me.ToAssetCheckBox.Size = New System.Drawing.Size(107, 17)
        Me.ToAssetCheckBox.TabIndex = 31
        Me.ToAssetCheckBox.Text = "By Asset Number"
        Me.ToAssetCheckBox.UseVisualStyleBackColor = True
        '
        'AEAdministration
        '
        Me.AEAdministration.Controls.Add(Me.SettingsFilesGroupBox)
        Me.AEAdministration.Location = New System.Drawing.Point(4, 22)
        Me.AEAdministration.Margin = New System.Windows.Forms.Padding(4)
        Me.AEAdministration.Name = "AEAdministration"
        Me.AEAdministration.Padding = New System.Windows.Forms.Padding(4)
        Me.AEAdministration.Size = New System.Drawing.Size(978, 320)
        Me.AEAdministration.TabIndex = 6
        Me.AEAdministration.Text = "AE Administration"
        Me.AEAdministration.UseVisualStyleBackColor = True
        '
        'SettingsFilesGroupBox
        '
        Me.SettingsFilesGroupBox.Controls.Add(Me.SystemAdministratorsButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.EmailPasswordButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.ShowPWDButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.CreateToolsDWGButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.ToolsINIButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.NavigateToLayerDefinitionsButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.DrawingSheetsButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.BlockfinderFavouritesButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.NavigateToBlockLibraryButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.HideTemplateButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.SettingsFileButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.RegionsFileButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.OfficeAddressesButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.TemplateBuildersFileButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.DisciplinesFileButton)
        Me.SettingsFilesGroupBox.Controls.Add(Me.TemplateMappingFileButton)
        Me.SettingsFilesGroupBox.Location = New System.Drawing.Point(11, 14)
        Me.SettingsFilesGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SettingsFilesGroupBox.Name = "SettingsFilesGroupBox"
        Me.SettingsFilesGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.SettingsFilesGroupBox.Size = New System.Drawing.Size(771, 300)
        Me.SettingsFilesGroupBox.TabIndex = 42
        Me.SettingsFilesGroupBox.TabStop = False
        Me.SettingsFilesGroupBox.Text = "Settings Files"
        '
        'SystemAdministratorsButton
        '
        Me.SystemAdministratorsButton.BackgroundImage = CType(resources.GetObject("SystemAdministratorsButton.BackgroundImage"), System.Drawing.Image)
        Me.SystemAdministratorsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SystemAdministratorsButton.Location = New System.Drawing.Point(520, 23)
        Me.SystemAdministratorsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SystemAdministratorsButton.Name = "SystemAdministratorsButton"
        Me.SystemAdministratorsButton.Size = New System.Drawing.Size(160, 40)
        Me.SystemAdministratorsButton.TabIndex = 70
        Me.SystemAdministratorsButton.Text = "Sys Admins"
        Me.ToolTip1.SetToolTip(Me.SystemAdministratorsButton, "Edit the file that nomitates the System Administrators")
        Me.SystemAdministratorsButton.UseVisualStyleBackColor = True
        '
        'EmailPasswordButton
        '
        Me.EmailPasswordButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.App_password_icon_x_32
        Me.EmailPasswordButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EmailPasswordButton.Enabled = False
        Me.EmailPasswordButton.Location = New System.Drawing.Point(555, 242)
        Me.EmailPasswordButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EmailPasswordButton.Name = "EmailPasswordButton"
        Me.EmailPasswordButton.Size = New System.Drawing.Size(160, 40)
        Me.EmailPasswordButton.TabIndex = 69
        Me.EmailPasswordButton.Text = "      Email PWD"
        Me.ToolTip1.SetToolTip(Me.EmailPasswordButton, "Generate Disable AE Password for Today")
        Me.EmailPasswordButton.UseVisualStyleBackColor = True
        Me.EmailPasswordButton.Visible = False
        '
        'ShowPWDButton
        '
        Me.ShowPWDButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.App_password_icon_x_32
        Me.ShowPWDButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ShowPWDButton.Location = New System.Drawing.Point(352, 188)
        Me.ShowPWDButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ShowPWDButton.Name = "ShowPWDButton"
        Me.ShowPWDButton.Size = New System.Drawing.Size(160, 40)
        Me.ShowPWDButton.TabIndex = 68
        Me.ShowPWDButton.Text = "      Show PWD"
        Me.ToolTip1.SetToolTip(Me.ShowPWDButton, "Generate Disable AE Password for Today")
        Me.ShowPWDButton.UseVisualStyleBackColor = True
        '
        'CreateToolsDWGButton
        '
        Me.CreateToolsDWGButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.process_accept_icon_x32
        Me.CreateToolsDWGButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CreateToolsDWGButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CreateToolsDWGButton.Location = New System.Drawing.Point(352, 132)
        Me.CreateToolsDWGButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CreateToolsDWGButton.Name = "CreateToolsDWGButton"
        Me.CreateToolsDWGButton.Size = New System.Drawing.Size(160, 40)
        Me.CreateToolsDWGButton.TabIndex = 67
        Me.CreateToolsDWGButton.Text = "     Tools DWG"
        Me.ToolTip1.SetToolTip(Me.CreateToolsDWGButton, "Edit the list of users allowed to build Templates")
        Me.CreateToolsDWGButton.UseVisualStyleBackColor = True
        '
        'ToolsINIButton
        '
        Me.ToolsINIButton.BackgroundImage = CType(resources.GetObject("ToolsINIButton.BackgroundImage"), System.Drawing.Image)
        Me.ToolsINIButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ToolsINIButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ToolsINIButton.Location = New System.Drawing.Point(184, 188)
        Me.ToolsINIButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ToolsINIButton.Name = "ToolsINIButton"
        Me.ToolsINIButton.Size = New System.Drawing.Size(160, 40)
        Me.ToolsINIButton.TabIndex = 66
        Me.ToolsINIButton.Text = "     Tools INI"
        Me.ToolTip1.SetToolTip(Me.ToolsINIButton, "Edit the list of users allowed to build Templates")
        Me.ToolsINIButton.UseVisualStyleBackColor = True
        '
        'NavigateToLayerDefinitionsButton
        '
        Me.NavigateToLayerDefinitionsButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Windows_icon_x_32
        Me.NavigateToLayerDefinitionsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.NavigateToLayerDefinitionsButton.Location = New System.Drawing.Point(16, 242)
        Me.NavigateToLayerDefinitionsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NavigateToLayerDefinitionsButton.Name = "NavigateToLayerDefinitionsButton"
        Me.NavigateToLayerDefinitionsButton.Size = New System.Drawing.Size(160, 40)
        Me.NavigateToLayerDefinitionsButton.TabIndex = 65
        Me.NavigateToLayerDefinitionsButton.Text = "     Layer"
        Me.ToolTip1.SetToolTip(Me.NavigateToLayerDefinitionsButton, "Navigate to Layer Definitions folder")
        Me.NavigateToLayerDefinitionsButton.UseVisualStyleBackColor = True
        '
        'DrawingSheetsButton
        '
        Me.DrawingSheetsButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Windows_icon_x_32
        Me.DrawingSheetsButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DrawingSheetsButton.Location = New System.Drawing.Point(352, 242)
        Me.DrawingSheetsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DrawingSheetsButton.Name = "DrawingSheetsButton"
        Me.DrawingSheetsButton.Size = New System.Drawing.Size(160, 40)
        Me.DrawingSheetsButton.TabIndex = 64
        Me.DrawingSheetsButton.Text = "     DWG Sheets"
        Me.ToolTip1.SetToolTip(Me.DrawingSheetsButton, "Navigate to Drawing Sheets folder")
        Me.DrawingSheetsButton.UseVisualStyleBackColor = True
        '
        'BlockfinderFavouritesButton
        '
        Me.BlockfinderFavouritesButton.BackgroundImage = CType(resources.GetObject("BlockfinderFavouritesButton.BackgroundImage"), System.Drawing.Image)
        Me.BlockfinderFavouritesButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.BlockfinderFavouritesButton.Location = New System.Drawing.Point(16, 188)
        Me.BlockfinderFavouritesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.BlockfinderFavouritesButton.Name = "BlockfinderFavouritesButton"
        Me.BlockfinderFavouritesButton.Size = New System.Drawing.Size(160, 40)
        Me.BlockfinderFavouritesButton.TabIndex = 64
        Me.BlockfinderFavouritesButton.Text = "       Block DAT "
        Me.ToolTip1.SetToolTip(Me.BlockfinderFavouritesButton, "Edit the Block tools corporate favourites list")
        Me.BlockfinderFavouritesButton.UseVisualStyleBackColor = True
        '
        'NavigateToBlockLibraryButton
        '
        Me.NavigateToBlockLibraryButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Windows_icon_x_32
        Me.NavigateToBlockLibraryButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.NavigateToBlockLibraryButton.Location = New System.Drawing.Point(184, 242)
        Me.NavigateToBlockLibraryButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NavigateToBlockLibraryButton.Name = "NavigateToBlockLibraryButton"
        Me.NavigateToBlockLibraryButton.Size = New System.Drawing.Size(160, 40)
        Me.NavigateToBlockLibraryButton.TabIndex = 63
        Me.NavigateToBlockLibraryButton.Text = "     Block Lib"
        Me.ToolTip1.SetToolTip(Me.NavigateToBlockLibraryButton, "Navigate to Block Library folder")
        Me.NavigateToBlockLibraryButton.UseVisualStyleBackColor = True
        '
        'HideTemplateButton
        '
        Me.HideTemplateButton.BackgroundImage = CType(resources.GetObject("HideTemplateButton.BackgroundImage"), System.Drawing.Image)
        Me.HideTemplateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.HideTemplateButton.Location = New System.Drawing.Point(184, 132)
        Me.HideTemplateButton.Margin = New System.Windows.Forms.Padding(4)
        Me.HideTemplateButton.Name = "HideTemplateButton"
        Me.HideTemplateButton.Size = New System.Drawing.Size(160, 40)
        Me.HideTemplateButton.TabIndex = 36
        Me.HideTemplateButton.Text = "Hide"
        Me.ToolTip1.SetToolTip(Me.HideTemplateButton, "Edit the file that hides the obsolete templates that have alredy gone to producti" &
        "on")
        Me.HideTemplateButton.UseVisualStyleBackColor = True
        '
        'SettingsFileButton
        '
        Me.SettingsFileButton.BackgroundImage = CType(resources.GetObject("SettingsFileButton.BackgroundImage"), System.Drawing.Image)
        Me.SettingsFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SettingsFileButton.Location = New System.Drawing.Point(352, 23)
        Me.SettingsFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SettingsFileButton.Name = "SettingsFileButton"
        Me.SettingsFileButton.Size = New System.Drawing.Size(160, 40)
        Me.SettingsFileButton.TabIndex = 37
        Me.SettingsFileButton.Text = "     Settings"
        Me.ToolTip1.SetToolTip(Me.SettingsFileButton, "Edit the Configuration.xml file")
        Me.SettingsFileButton.UseVisualStyleBackColor = True
        '
        'RegionsFileButton
        '
        Me.RegionsFileButton.BackgroundImage = CType(resources.GetObject("RegionsFileButton.BackgroundImage"), System.Drawing.Image)
        Me.RegionsFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RegionsFileButton.Location = New System.Drawing.Point(184, 22)
        Me.RegionsFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RegionsFileButton.Name = "RegionsFileButton"
        Me.RegionsFileButton.Size = New System.Drawing.Size(160, 40)
        Me.RegionsFileButton.TabIndex = 35
        Me.RegionsFileButton.Text = "     Regions"
        Me.ToolTip1.SetToolTip(Me.RegionsFileButton, "Edit regions for each country")
        Me.RegionsFileButton.UseVisualStyleBackColor = True
        '
        'OfficeAddressesButton
        '
        Me.OfficeAddressesButton.BackgroundImage = CType(resources.GetObject("OfficeAddressesButton.BackgroundImage"), System.Drawing.Image)
        Me.OfficeAddressesButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.OfficeAddressesButton.Location = New System.Drawing.Point(184, 78)
        Me.OfficeAddressesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.OfficeAddressesButton.Name = "OfficeAddressesButton"
        Me.OfficeAddressesButton.Size = New System.Drawing.Size(160, 40)
        Me.OfficeAddressesButton.TabIndex = 34
        Me.OfficeAddressesButton.Text = "      Addresses"
        Me.ToolTip1.SetToolTip(Me.OfficeAddressesButton, "Edit the address file for each office")
        Me.OfficeAddressesButton.UseVisualStyleBackColor = True
        '
        'TemplateBuildersFileButton
        '
        Me.TemplateBuildersFileButton.BackgroundImage = CType(resources.GetObject("TemplateBuildersFileButton.BackgroundImage"), System.Drawing.Image)
        Me.TemplateBuildersFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TemplateBuildersFileButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.TemplateBuildersFileButton.Location = New System.Drawing.Point(16, 22)
        Me.TemplateBuildersFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplateBuildersFileButton.Name = "TemplateBuildersFileButton"
        Me.TemplateBuildersFileButton.Size = New System.Drawing.Size(160, 40)
        Me.TemplateBuildersFileButton.TabIndex = 33
        Me.TemplateBuildersFileButton.Text = "     Builders"
        Me.ToolTip1.SetToolTip(Me.TemplateBuildersFileButton, "Edit the list of users allowed to build Templates")
        Me.TemplateBuildersFileButton.UseVisualStyleBackColor = True
        '
        'DisciplinesFileButton
        '
        Me.DisciplinesFileButton.BackgroundImage = CType(resources.GetObject("DisciplinesFileButton.BackgroundImage"), System.Drawing.Image)
        Me.DisciplinesFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DisciplinesFileButton.Location = New System.Drawing.Point(16, 78)
        Me.DisciplinesFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DisciplinesFileButton.Name = "DisciplinesFileButton"
        Me.DisciplinesFileButton.Size = New System.Drawing.Size(160, 40)
        Me.DisciplinesFileButton.TabIndex = 32
        Me.DisciplinesFileButton.Text = "       Disciplines"
        Me.ToolTip1.SetToolTip(Me.DisciplinesFileButton, "Edit discipline names")
        Me.DisciplinesFileButton.UseVisualStyleBackColor = True
        '
        'TemplateMappingFileButton
        '
        Me.TemplateMappingFileButton.BackgroundImage = CType(resources.GetObject("TemplateMappingFileButton.BackgroundImage"), System.Drawing.Image)
        Me.TemplateMappingFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TemplateMappingFileButton.Location = New System.Drawing.Point(16, 132)
        Me.TemplateMappingFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplateMappingFileButton.Name = "TemplateMappingFileButton"
        Me.TemplateMappingFileButton.Size = New System.Drawing.Size(160, 40)
        Me.TemplateMappingFileButton.TabIndex = 31
        Me.TemplateMappingFileButton.Text = "     Mapping"
        Me.ToolTip1.SetToolTip(Me.TemplateMappingFileButton, "Edit the Template mapping file which is used to convert old config names to new o" &
        "nes")
        Me.TemplateMappingFileButton.UseVisualStyleBackColor = True
        '
        'AdministrationDeployment
        '
        Me.AdministrationDeployment.Controls.Add(Me.SettingsFilesToDeployGroupBox)
        Me.AdministrationDeployment.Location = New System.Drawing.Point(4, 22)
        Me.AdministrationDeployment.Margin = New System.Windows.Forms.Padding(2)
        Me.AdministrationDeployment.Name = "AdministrationDeployment"
        Me.AdministrationDeployment.Size = New System.Drawing.Size(978, 320)
        Me.AdministrationDeployment.TabIndex = 8
        Me.AdministrationDeployment.Text = "Administration Deployment"
        Me.AdministrationDeployment.UseVisualStyleBackColor = True
        '
        'SettingsFilesToDeployGroupBox
        '
        Me.SettingsFilesToDeployGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SettingsFilesToDeployGroupBox.Controls.Add(Me.SettingFilesTodeployButton)
        Me.SettingsFilesToDeployGroupBox.Controls.Add(Me.RefreshSettingsFilesToDeployListButton)
        Me.SettingsFilesToDeployGroupBox.Controls.Add(Me.DeleteSelectedSettingsFilesButton)
        Me.SettingsFilesToDeployGroupBox.Controls.Add(Me.SettingFilesToDeployListBox)
        Me.SettingsFilesToDeployGroupBox.Controls.Add(Me.GroupBox3)
        Me.SettingsFilesToDeployGroupBox.Location = New System.Drawing.Point(11, 14)
        Me.SettingsFilesToDeployGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SettingsFilesToDeployGroupBox.Name = "SettingsFilesToDeployGroupBox"
        Me.SettingsFilesToDeployGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.SettingsFilesToDeployGroupBox.Size = New System.Drawing.Size(928, 300)
        Me.SettingsFilesToDeployGroupBox.TabIndex = 44
        Me.SettingsFilesToDeployGroupBox.TabStop = False
        Me.SettingsFilesToDeployGroupBox.Text = "Settings Files Available for Deployment"
        '
        'SettingFilesTodeployButton
        '
        Me.SettingFilesTodeployButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.SettingFilesTodeployButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Windows_icon_x_32
        Me.SettingFilesTodeployButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SettingFilesTodeployButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.SettingFilesTodeployButton.Location = New System.Drawing.Point(11, 192)
        Me.SettingFilesTodeployButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SettingFilesTodeployButton.Name = "SettingFilesTodeployButton"
        Me.SettingFilesTodeployButton.Size = New System.Drawing.Size(160, 40)
        Me.SettingFilesTodeployButton.TabIndex = 66
        Me.SettingFilesTodeployButton.Text = "     Navigate"
        Me.ToolTip1.SetToolTip(Me.SettingFilesTodeployButton, "Opens up windows explorer in the templates to deploy folder.")
        Me.SettingFilesTodeployButton.UseVisualStyleBackColor = True
        '
        'RefreshSettingsFilesToDeployListButton
        '
        Me.RefreshSettingsFilesToDeployListButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.RefreshSettingsFilesToDeployListButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Button_Refresh_icon__Small
        Me.RefreshSettingsFilesToDeployListButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.RefreshSettingsFilesToDeployListButton.Location = New System.Drawing.Point(179, 192)
        Me.RefreshSettingsFilesToDeployListButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RefreshSettingsFilesToDeployListButton.Name = "RefreshSettingsFilesToDeployListButton"
        Me.RefreshSettingsFilesToDeployListButton.Size = New System.Drawing.Size(40, 40)
        Me.RefreshSettingsFilesToDeployListButton.TabIndex = 43
        Me.RefreshSettingsFilesToDeployListButton.UseVisualStyleBackColor = True
        '
        'DeleteSelectedSettingsFilesButton
        '
        Me.DeleteSelectedSettingsFilesButton.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DeleteSelectedSettingsFilesButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.DeleteSelectedSettingsFilesButton.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.Button_Delete_icon_32
        Me.DeleteSelectedSettingsFilesButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeleteSelectedSettingsFilesButton.Location = New System.Drawing.Point(228, 192)
        Me.DeleteSelectedSettingsFilesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DeleteSelectedSettingsFilesButton.Name = "DeleteSelectedSettingsFilesButton"
        Me.DeleteSelectedSettingsFilesButton.Size = New System.Drawing.Size(343, 40)
        Me.DeleteSelectedSettingsFilesButton.TabIndex = 65
        Me.DeleteSelectedSettingsFilesButton.Text = "     Delete"
        Me.ToolTip1.SetToolTip(Me.DeleteSelectedSettingsFilesButton, "Delete Selected Templates")
        Me.DeleteSelectedSettingsFilesButton.UseVisualStyleBackColor = True
        '
        'SettingFilesToDeployListBox
        '
        Me.SettingFilesToDeployListBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SettingFilesToDeployListBox.FormattingEnabled = True
        Me.SettingFilesToDeployListBox.Location = New System.Drawing.Point(11, 20)
        Me.SettingFilesToDeployListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SettingFilesToDeployListBox.Name = "SettingFilesToDeployListBox"
        Me.SettingFilesToDeployListBox.Size = New System.Drawing.Size(895, 147)
        Me.SettingFilesToDeployListBox.TabIndex = 42
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.UATAEAdminCheckBox)
        Me.GroupBox3.Controls.Add(Me.TestingAEAdminCheckBox)
        Me.GroupBox3.Controls.Add(Me.ProductionAEAdminCheckBox)
        Me.GroupBox3.Controls.Add(Me.ToAssetNoAEAdminCheckBox)
        Me.GroupBox3.Location = New System.Drawing.Point(11, 240)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(715, 50)
        Me.GroupBox3.TabIndex = 41
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Distribution Locations"
        '
        'UATAEAdminCheckBox
        '
        Me.UATAEAdminCheckBox.Location = New System.Drawing.Point(568, 20)
        Me.UATAEAdminCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.UATAEAdminCheckBox.Name = "UATAEAdminCheckBox"
        Me.UATAEAdminCheckBox.Size = New System.Drawing.Size(124, 21)
        Me.UATAEAdminCheckBox.TabIndex = 34
        Me.UATAEAdminCheckBox.Text = "Development"
        Me.UATAEAdminCheckBox.UseVisualStyleBackColor = True
        '
        'TestingAEAdminCheckBox
        '
        Me.TestingAEAdminCheckBox.Location = New System.Drawing.Point(411, 18)
        Me.TestingAEAdminCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.TestingAEAdminCheckBox.Name = "TestingAEAdminCheckBox"
        Me.TestingAEAdminCheckBox.Size = New System.Drawing.Size(102, 26)
        Me.TestingAEAdminCheckBox.TabIndex = 33
        Me.TestingAEAdminCheckBox.Text = "Testing"
        Me.TestingAEAdminCheckBox.UseVisualStyleBackColor = True
        '
        'ProductionAEAdminCheckBox
        '
        Me.ProductionAEAdminCheckBox.Location = New System.Drawing.Point(232, 18)
        Me.ProductionAEAdminCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ProductionAEAdminCheckBox.Name = "ProductionAEAdminCheckBox"
        Me.ProductionAEAdminCheckBox.Size = New System.Drawing.Size(131, 26)
        Me.ProductionAEAdminCheckBox.TabIndex = 32
        Me.ProductionAEAdminCheckBox.Text = "Production"
        Me.ProductionAEAdminCheckBox.UseVisualStyleBackColor = True
        '
        'ToAssetNoAEAdminCheckBox
        '
        Me.ToAssetNoAEAdminCheckBox.Location = New System.Drawing.Point(12, 18)
        Me.ToAssetNoAEAdminCheckBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ToAssetNoAEAdminCheckBox.Name = "ToAssetNoAEAdminCheckBox"
        Me.ToAssetNoAEAdminCheckBox.Size = New System.Drawing.Size(185, 26)
        Me.ToAssetNoAEAdminCheckBox.TabIndex = 31
        Me.ToAssetNoAEAdminCheckBox.Text = "By Asset Number"
        Me.ToAssetNoAEAdminCheckBox.UseVisualStyleBackColor = True
        '
        'LaunchAutoCADOKButton
        '
        Me.LaunchAutoCADOKButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LaunchAutoCADOKButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LaunchAutoCADOKButton.Location = New System.Drawing.Point(199, 476)
        Me.LaunchAutoCADOKButton.Margin = New System.Windows.Forms.Padding(4)
        Me.LaunchAutoCADOKButton.Name = "LaunchAutoCADOKButton"
        Me.LaunchAutoCADOKButton.Size = New System.Drawing.Size(64, 26)
        Me.LaunchAutoCADOKButton.TabIndex = 33
        Me.LaunchAutoCADOKButton.Text = "OK"
        Me.ToolTip1.SetToolTip(Me.LaunchAutoCADOKButton, "Launch plain Autodesk selected Product uses Jacobs.DWT")
        Me.LaunchAutoCADOKButton.Visible = False
        '
        'DeploySettingsFilesOKButton
        '
        Me.DeploySettingsFilesOKButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DeploySettingsFilesOKButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeploySettingsFilesOKButton.Location = New System.Drawing.Point(411, 476)
        Me.DeploySettingsFilesOKButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DeploySettingsFilesOKButton.Name = "DeploySettingsFilesOKButton"
        Me.DeploySettingsFilesOKButton.Size = New System.Drawing.Size(64, 26)
        Me.DeploySettingsFilesOKButton.TabIndex = 29
        Me.DeploySettingsFilesOKButton.Text = "OK"
        Me.ToolTip1.SetToolTip(Me.DeploySettingsFilesOKButton, "Distributes the Settings files and block library to checked distribution location" &
        "s")
        Me.DeploySettingsFilesOKButton.UseVisualStyleBackColor = True
        Me.DeploySettingsFilesOKButton.Visible = False
        '
        'ProcessTemplateOKButton
        '
        Me.ProcessTemplateOKButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProcessTemplateOKButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ProcessTemplateOKButton.Location = New System.Drawing.Point(271, 476)
        Me.ProcessTemplateOKButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ProcessTemplateOKButton.Name = "ProcessTemplateOKButton"
        Me.ProcessTemplateOKButton.Size = New System.Drawing.Size(64, 26)
        Me.ProcessTemplateOKButton.TabIndex = 25
        Me.ProcessTemplateOKButton.Text = "OK"
        Me.ToolTip1.SetToolTip(Me.ProcessTemplateOKButton, "Create or Modify  A New Template")
        Me.ProcessTemplateOKButton.UseVisualStyleBackColor = True
        Me.ProcessTemplateOKButton.Visible = False
        '
        'DeployTemplateOKButton
        '
        Me.DeployTemplateOKButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DeployTemplateOKButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.DeployTemplateOKButton.Location = New System.Drawing.Point(341, 476)
        Me.DeployTemplateOKButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DeployTemplateOKButton.Name = "DeployTemplateOKButton"
        Me.DeployTemplateOKButton.Size = New System.Drawing.Size(64, 26)
        Me.DeployTemplateOKButton.TabIndex = 30
        Me.DeployTemplateOKButton.Text = "OK"
        Me.ToolTip1.SetToolTip(Me.DeployTemplateOKButton, "Deploy Template")
        Me.DeployTemplateOKButton.UseVisualStyleBackColor = True
        Me.DeployTemplateOKButton.Visible = False
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.FileName = "OpenFileDialog1"
        '
        'TableLayoutPanelHelpOKCancel
        '
        Me.TableLayoutPanelHelpOKCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanelHelpOKCancel.ColumnCount = 3
        Me.TableLayoutPanelHelpOKCancel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelHelpOKCancel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelHelpOKCancel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelHelpOKCancel.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanelHelpOKCancel.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanelHelpOKCancel.Controls.Add(Me.OK_Button, 1, 0)
        Me.TableLayoutPanelHelpOKCancel.Location = New System.Drawing.Point(754, 476)
        Me.TableLayoutPanelHelpOKCancel.Margin = New System.Windows.Forms.Padding(2)
        Me.TableLayoutPanelHelpOKCancel.Name = "TableLayoutPanelHelpOKCancel"
        Me.TableLayoutPanelHelpOKCancel.RowCount = 1
        Me.TableLayoutPanelHelpOKCancel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanelHelpOKCancel.Size = New System.Drawing.Size(241, 36)
        Me.TableLayoutPanelHelpOKCancel.TabIndex = 34
        '
        'CADEnvironmentLauncherForm
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(1004, 521)
        Me.Controls.Add(Me.TableLayoutPanelHelpOKCancel)
        Me.Controls.Add(Me.ProcessTemplateOKButton)
        Me.Controls.Add(Me.WorkSpaceTextBox)
        Me.Controls.Add(Me.LaunchAutoCADOKButton)
        Me.Controls.Add(Me.RefreshProfileAndProductButton)
        Me.Controls.Add(Me.WorkspaceLabel)
        Me.Controls.Add(Me.ProfileLabel)
        Me.Controls.Add(Me.DeployTemplateOKButton)
        Me.Controls.Add(Me.ProfileComboBox)
        Me.Controls.Add(Me.ProductLabel)
        Me.Controls.Add(Me.ProductComboBox)
        Me.Controls.Add(Me.MainTabControl)
        Me.Controls.Add(Me.DeploySettingsFilesOKButton)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.lblTitle)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(829, 553)
        Me.Name = "CADEnvironmentLauncherForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SummaryGroupBox.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MainTabControl.ResumeLayout(False)
        Me.UsingTemplate.ResumeLayout(False)
        Me.UsingTemplate.PerformLayout()
        Me.StandardApplication.ResumeLayout(False)
        Me.AdditionalTools.ResumeLayout(False)
        Me.AdditionalTools.PerformLayout()
        Me.Logs.ResumeLayout(False)
        Me.TemplateManagement.ResumeLayout(False)
        Me.TemplatesGroupBox.ResumeLayout(False)
        Me.ActionGroupBox.ResumeLayout(False)
        Me.ActionGroupBox.PerformLayout()
        Me.NewGroupBox.ResumeLayout(False)
        Me.NewGroupBox.PerformLayout()
        Me.SelectExistingGroupBox.ResumeLayout(False)
        Me.SelectExistingGroupBox.PerformLayout()
        Me.TemplateDeployment.ResumeLayout(False)
        Me.TemplateDeploymentGroupBox.ResumeLayout(False)
        Me.DistributionGroupBox.ResumeLayout(False)
        Me.DistributionGroupBox.PerformLayout()
        Me.AEAdministration.ResumeLayout(False)
        Me.SettingsFilesGroupBox.ResumeLayout(False)
        Me.AdministrationDeployment.ResumeLayout(False)
        Me.SettingsFilesToDeployGroupBox.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.TableLayoutPanelHelpOKCancel.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents RefreshProfileAndProductButton As System.Windows.Forms.Button
    Friend WithEvents ResetSelectedButton As System.Windows.Forms.Button
    Friend WithEvents WorkspaceLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileLabel As System.Windows.Forms.Label
    Friend WithEvents ProfileComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ProductLabel As System.Windows.Forms.Label
    Friend WithEvents ProductComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Help_Button As System.Windows.Forms.Button
    Friend WithEvents SummaryGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ContentsReportListBox As System.Windows.Forms.ListBox
    Friend WithEvents DisciplinesListBox As System.Windows.Forms.ListBox
    Friend WithEvents ClientsearchButton As System.Windows.Forms.Button
    Friend WithEvents ClientsListBox As System.Windows.Forms.ListBox
    Friend WithEvents RegionsListBox As System.Windows.Forms.ListBox
    Friend WithEvents CountriesListBox As System.Windows.Forms.ListBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents WorkSpaceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MainTabControl As System.Windows.Forms.TabControl
    Friend WithEvents UsingTemplate As System.Windows.Forms.TabPage
    Friend WithEvents StandardApplication As System.Windows.Forms.TabPage
    Friend WithEvents AdditionalTools As System.Windows.Forms.TabPage
    Friend WithEvents TestingButton As System.Windows.Forms.Button
    Friend WithEvents ProductionButton As System.Windows.Forms.Button
    Friend WithEvents ProjectWiseOffButton As System.Windows.Forms.Button
    Friend WithEvents ProjectWiseOnButton As System.Windows.Forms.Button
    Friend WithEvents VirusRemoverButton As System.Windows.Forms.Button
    Friend WithEvents ScaleListCleanUpButton As System.Windows.Forms.Button
    Friend WithEvents PurgeRegisteredAppsButton As System.Windows.Forms.Button
    Friend WithEvents LaunchAutoCADOKButton As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents DevelopmentButton As System.Windows.Forms.Button
    Friend WithEvents TemplateManagement As System.Windows.Forms.TabPage
    Friend WithEvents ProcessTemplateOKButton As System.Windows.Forms.Button
    Friend WithEvents Logs As System.Windows.Forms.TabPage
    Friend WithEvents NavigateToLogFilesFolderButton As System.Windows.Forms.Button
    Friend WithEvents ClearAllLogFilesButton As System.Windows.Forms.Button
    Friend WithEvents SelectExistingGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ExistingClientsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingCountriesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingCountriesLabel As System.Windows.Forms.Label
    Friend WithEvents ExistingRegionsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingRegionsLabel As System.Windows.Forms.Label
    Friend WithEvents ExistingClientsLabel As System.Windows.Forms.Label
    Friend WithEvents ExistingDisciplinesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingDisciplinesLabel As System.Windows.Forms.Label
    Friend WithEvents NewGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents CountriesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CountriesLabel As System.Windows.Forms.Label
    Friend WithEvents RegionsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents RegionsLabel As System.Windows.Forms.Label
    Friend WithEvents ClientTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ClientLabel As System.Windows.Forms.Label
    Friend WithEvents DisciplinesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DisciplinesLabel As System.Windows.Forms.Label
    Friend WithEvents ActionGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents RemoveRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NewUsingRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NewRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ModifyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents TemplatesGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents EnableAEButton As System.Windows.Forms.Button
    Friend WithEvents DisableAEButton As System.Windows.Forms.Button
    Friend WithEvents NewUsingUserProvidedRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents AEAdministration As System.Windows.Forms.TabPage
    Friend WithEvents SettingsFilesGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ShowPWDButton As System.Windows.Forms.Button
    Friend WithEvents CreateToolsDWGButton As System.Windows.Forms.Button
    Friend WithEvents ToolsINIButton As System.Windows.Forms.Button
    Friend WithEvents NavigateToLayerDefinitionsButton As System.Windows.Forms.Button
    Friend WithEvents DrawingSheetsButton As System.Windows.Forms.Button
    Friend WithEvents BlockfinderFavouritesButton As System.Windows.Forms.Button
    Friend WithEvents NavigateToBlockLibraryButton As System.Windows.Forms.Button
    Friend WithEvents HideTemplateButton As System.Windows.Forms.Button
    Friend WithEvents SettingsFileButton As System.Windows.Forms.Button
    Friend WithEvents RegionsFileButton As System.Windows.Forms.Button
    Friend WithEvents OfficeAddressesButton As System.Windows.Forms.Button
    Friend WithEvents TemplateBuildersFileButton As System.Windows.Forms.Button
    Friend WithEvents DisciplinesFileButton As System.Windows.Forms.Button
    Friend WithEvents TemplateMappingFileButton As System.Windows.Forms.Button
    Friend WithEvents TemplateDeployment As System.Windows.Forms.TabPage
    Friend WithEvents AdministrationDeployment As System.Windows.Forms.TabPage
    Friend WithEvents SettingsFilesToDeployGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents SettingFilesTodeployButton As System.Windows.Forms.Button
    Friend WithEvents DeleteSelectedSettingsFilesButton As System.Windows.Forms.Button
    Friend WithEvents RefreshSettingsFilesToDeployListButton As System.Windows.Forms.Button
    Friend WithEvents SettingFilesToDeployListBox As System.Windows.Forms.ListBox
    Friend WithEvents DeploySettingsFilesOKButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents UATAEAdminCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TestingAEAdminCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ProductionAEAdminCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ToAssetNoAEAdminCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TemplateDeploymentGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents DeleteTemplateButton As System.Windows.Forms.Button
    Friend WithEvents BrowseToClientsToDeployButton As System.Windows.Forms.Button
    Friend WithEvents RefreshConfigsToDeployListButton As System.Windows.Forms.Button
    Friend WithEvents TemplatesToDeployListBox As System.Windows.Forms.ListBox
    Friend WithEvents DeployTemplateOKButton As System.Windows.Forms.Button
    Friend WithEvents DistributionGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents UATCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TestingCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ProductionCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ToAssetCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents CountryLBLabel As System.Windows.Forms.Label
    Friend WithEvents RegionLBLabel As System.Windows.Forms.Label
    Friend WithEvents ClientLBLabel As System.Windows.Forms.Label
    Friend WithEvents DisciplinesLBLabel As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanelHelpOKCancel As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents EmailPasswordButton As System.Windows.Forms.Button
    Friend WithEvents PointingToLabel As System.Windows.Forms.Label
    Friend WithEvents SystemAdministratorsButton As System.Windows.Forms.Button
    Friend WithEvents EditUserPGPButton As System.Windows.Forms.Button
    Friend WithEvents ActivateUserPGPButton As System.Windows.Forms.Button
    Friend WithEvents ShowJacobsOnlyCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PartialMenuLabel As Label
    Friend WithEvents PartialMenuListBox As CheckedListBox
End Class
