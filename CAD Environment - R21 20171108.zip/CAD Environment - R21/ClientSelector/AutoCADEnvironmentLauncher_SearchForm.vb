Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings

Public Class AutoCADEnvironmentLauncher_SearchForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lbTestConfigurations As System.Windows.Forms.ListBox
    Friend WithEvents txtClient As System.Windows.Forms.TextBox
    Friend WithEvents lblClient As System.Windows.Forms.Label
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents btnSelect As System.Windows.Forms.Button
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents Help_Button As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AutoCADEnvironmentLauncher_SearchForm))
        Me.lbTestConfigurations = New System.Windows.Forms.ListBox()
        Me.txtClient = New System.Windows.Forms.TextBox()
        Me.lblClient = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbTestConfigurations
        '
        Me.lbTestConfigurations.Location = New System.Drawing.Point(12, 102)
        Me.lbTestConfigurations.Name = "lbTestConfigurations"
        Me.lbTestConfigurations.Size = New System.Drawing.Size(538, 147)
        Me.lbTestConfigurations.TabIndex = 1
        '
        'txtClient
        '
        Me.txtClient.Location = New System.Drawing.Point(88, 70)
        Me.txtClient.Name = "txtClient"
        Me.txtClient.Size = New System.Drawing.Size(392, 20)
        Me.txtClient.TabIndex = 2
        '
        'lblClient
        '
        Me.lblClient.Location = New System.Drawing.Point(12, 72)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(70, 16)
        Me.lblClient.TabIndex = 3
        Me.lblClient.Text = "Containing: "
        '
        'btnSearch
        '
        Me.btnSearch.BackgroundImage = Global.Jacobs.ClientSelector.My.Resources.Resources.search_b_icon_x_32
        Me.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnSearch.Location = New System.Drawing.Point(495, 62)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(33, 34)
        Me.btnSearch.TabIndex = 4
        '
        'btnSelect
        '
        Me.btnSelect.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnSelect.Location = New System.Drawing.Point(72, 4)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(54, 23)
        Me.btnSelect.TabIndex = 5
        Me.btnSelect.Text = "OK"
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancel.Location = New System.Drawing.Point(139, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(53, 23)
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.Text = "&Cancel"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(111, 47)
        Me.LogoPictureBox.TabIndex = 8
        Me.LogoPictureBox.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(119, 10)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(204, 27)
        Me.lblTitle.TabIndex = 10
        Me.lblTitle.Text = "Search Templates"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.Location = New System.Drawing.Point(6, 4)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.Size = New System.Drawing.Size(53, 23)
        Me.Help_Button.TabIndex = 11
        Me.Help_Button.Text = "&Help"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnSelect, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.btnCancel, 2, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(465, 318)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(200, 31)
        Me.TableLayoutPanel2.TabIndex = 29
        '
        'AutoCADEnvironmentLauncher_SearchForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(675, 359)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.lblClient)
        Me.Controls.Add(Me.txtClient)
        Me.Controls.Add(Me.lbTestConfigurations)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(567, 340)
        Me.Name = "AutoCADEnvironmentLauncher_SearchForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        lbTestConfigurations.Items.Clear()
        Do_Search()

    End Sub
    '' ''    Dim testCheck As Boolean
    '' ''    ' The following statement returns True (does "F" satisfy "F"?)
    '' ''testCheck = "F" Like "F"
    '' ''    ' The following statement returns False for Option Compare Binary
    '' ''    '    and True for Option Compare Text (does "F" satisfy "f"?)
    '' ''testCheck = "F" Like "f"
    '' ''    ' The following statement returns False (does "F" satisfy "FFF"?)
    '' ''testCheck = "F" Like "FFF"
    '' ''    ' The following statement returns True (does "aBBBa" have an "a" at the
    '' ''    '    beginning, an "a" at the end, and any number of characters in 
    '' ''    '    between?)
    '' ''testCheck = "aBBBa" Like "a*a"
    '' ''    ' The following statement returns True (does "F" occur in the set of
    '' ''    '    characters from "A" through "Z"?)
    '' ''testCheck = "F" Like "[A-Z]"
    '' ''    ' The following statement returns False (does "F" NOT occur in the 
    '' ''    '    set of characters from "A" through "Z"?)
    '' ''testCheck = "F" Like "[!A-Z]"
    '' ''    ' The following statement returns True (does "a2a" begin and end with
    '' ''    '    an "a" and have any single-digit number in between?)
    '' ''testCheck = "a2a" Like "a#a"
    '' ''    ' The following statement returns True (does "aM5b" begin with an "a",
    '' ''    '    followed by any character from the set "L" through "P", followed
    '' ''    '    by any single-digit number, and end with any character NOT in
    '' ''    '    the character set "c" through "e"?)
    '' ''testCheck = "aM5b" Like "a[L-P]#[!c-e]"
    '' ''    ' The following statement returns True (does "BAT123khg" begin with a
    '' ''    '    "B", followed by any single character, followed by a "T", and end
    '' ''    '    with zero or more characters of any type?)
    '' ''testCheck = "BAT123khg" Like "B?T*"
    '' ''    ' The following statement returns False (does "CAT123khg"?) begin with
    '' ''    '    a "B", followed by any single character, followed by a "T", and
    '' ''    '    end with zero or more characters of any type?)
    '' ''testCheck = "CAT123khg" Like "B?T*"
    Private Sub Do_Search()

        Dim cDirectoryEntries As Collection = New Collection

        CEGetDirectories(Settings.Manager.AE.ClientsConfigurationPath, cDirectoryEntries, Settings.Manager.AE.TemplatesToHideFileNamePathed, Settings.IsUserValidSystemAdministrator)

        Dim strClient As String = ""
        lbTestConfigurations.Items.Clear()

        For Each strFile As String In cDirectoryEntries
            Try
                If strFile.ToUpper Like "*" & txtClient.Text.ToUpper & "*" Then
                    If Not lbTestConfigurations.Items.Contains(strFile) Then
                        lbTestConfigurations.Items.Add(strFile)
                    End If
                End If
            Catch ex As Exception

                GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , "Valid search characters include * ? # [charlist] [!charlist]")
                txtClient.Text = String.Empty

            End Try

        Next

        If lbTestConfigurations.Items.Count = 0 Then

            GeneralMessageBox("No results found, please refine your search criteria  and search again.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If


    End Sub

    Private Sub txtClient_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtClient.KeyPress

        If Asc(e.KeyChar) = 13 Then
            Do_Search()
        End If

    End Sub

    Private Sub btnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSelect.Click

        If lbTestConfigurations.SelectedIndex = -1 Then
            GeneralMessageBox("Please do a search, select a configuration then click Select.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Me.DialogResult = Windows.Forms.DialogResult.Yes

            Me.Close()
        End If

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click

        Me.DialogResult = Windows.Forms.DialogResult.No
        Me.Close()

    End Sub

    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub SearchForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '' Workout out the Dialog Box Title 
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        ' Now that we have things like the AEVersion number and Title display it on the dialog name 
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version
    End Sub


End Class
