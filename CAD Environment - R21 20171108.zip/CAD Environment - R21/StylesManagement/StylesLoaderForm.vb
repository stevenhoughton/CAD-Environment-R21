﻿Imports System.Windows.Forms
Imports System.IO
Imports System.Data
Imports System.Linq
Imports System.Collections.Generic
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports System.Drawing
Imports Jacobs.Common.Settings
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources

Public Class StylesLoaderForm

    Dim IsInitializing As Boolean = True

    Dim mStyleDetails As New DataSet("LayerFiles")


    ''' <summary>
    ''' Example of a Dialog_Load function for a tool that uses Rules.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub StylesManagement_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try

            dgvLayerDetails.AutoGenerateColumns = False

            IsInitializing = True

            '' On Dialog_Load events ensure that the first thing we do is read the Configuration Settings 
            '' So that we have access to everything in the Configuration.XML file.

            GetConfigSettings()

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            '' Assign Global Generic dialog tool tips. Not to be hard coded. Use Global Reference file in Utilities

            ToolTip1.SetToolTip(cmdHelp, UtilitiesMyResources.ToolTipHelp)
            ToolTip1.SetToolTip(cmdCancel, UtilitiesMyResources.ToolTipCancel)

            '' Assign local unique tool tips. Not to be hard coded. Use local reference file

            ToolTip1.SetToolTip(cmdApply, My.Resources.ToolTipOK)
            ToolTip1.SetToolTip(lblTitle, My.Resources.ToolSummary)

            '' RULES Section 1
            '' If any user changes the Template Settings with their own Settings (in other words a user override)
            '' We would have written a Working Variable (WorkVar) indicating that the user had made some changes.
            '' The next line of code checks the rules in this drawing and populates the required fields
            '' It will use the user overrides if the WorkVar is true Else it uses the template rules.


            Dim ConfigSettingsPath As String = String.Empty

            If IsThisAnOldConfigName() = True Then
                ConfigSettingsPath = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(RuleAccessors.GetruleValue("FullConfigName"), "Support")
            Else
                ConfigSettingsPath = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(RuleAccessors.GetruleValue("FullConfigName").CombinePath("Support"))
            End If

            'Get all DWT and Layer_*.dwg
            mStyleDetails.Tables.Clear()

            mStyleDetails.Tables.Add("DWT_STYLES")
            mStyleDetails.Tables.Item("DWT_STYLES").Columns.Add("FULLNAME", GetType(System.String))
            mStyleDetails.Tables.Item("DWT_STYLES").Columns.Add("DISPLAYNAME", GetType(System.String))

            Dim Tx As System.Data.DataTable = mStyleDetails.Tables("DWT_STYLES").Clone
            Tx.TableName = "EXT_STYLES"

            mStyleDetails.Tables.Add(Tx)
            mStyleDetails.AcceptChanges()

            If Directory.Exists(ConfigSettingsPath) = True Then

                Dim TemplateFileSearch As IEnumerable(Of String) = Directory.EnumerateFiles(ConfigSettingsPath & "\", RuleAccessors.GetruleValue("FullConfigName") & ".dwg", SearchOption.TopDirectoryOnly)
                Dim Cnt As Integer = 0
                For Each Res As String In TemplateFileSearch

                    If Cnt = 0 Then
                        Dim NR As DataRow = mStyleDetails.Tables.Item("DWT_STYLES").NewRow
                        NR.Item("FULLNAME") = Res
                        NR.Item("DISPLAYNAME") = Path.GetFileNameWithoutExtension(Res)
                        mStyleDetails.Tables.Item("DWT_STYLES").Rows.Add(NR)
                        NR = Nothing

                        If optFromDwg.Text.Contains("(DWG)") Then
                            optFromDwg.Text = optFromDwg.Text.Replace("(DWG)", "(" & RuleAccessors.GetruleValue("FullConfigName") & ".dwg)")
                        End If
                    Else
                        MsgBox("Multiple DWG Found in Config")
                    End If

                Next

                lblDwtName.Text = mStyleDetails.Tables.Item("DWT_STYLES").Rows(0).Item("FULLNAME").ToString

                mStyleDetails.AcceptChanges()

                If mStyleDetails.Tables.Item("DWT_STYLES").Rows.Count = 0 Then
                    Dim NR As DataRow = mStyleDetails.Tables.Item("DWT_STYLES").NewRow
                    NR.Item("FULLNAME") = "No DWT Files found"
                    NR.Item("DISPLAYNAME") = "No DWT Files found"
                    mStyleDetails.Tables.Item("DWT_STYLES").Rows.Add(NR)
                    NR = Nothing

                    mStyleDetails.AcceptChanges()
                End If

            Else

                If mStyleDetails.Tables.Item("DWT_STYLES").Rows.Count = 0 Then
                    Dim NR As DataRow = mStyleDetails.Tables.Item("DWT_STYLES").NewRow
                    NR.Item("FULLNAME") = "No DWT - Invalid Config File Path"
                    NR.Item("DISPLAYNAME") = "No DWT - Invalid Config File Path"
                    mStyleDetails.Tables.Item("DWT_STYLES").Rows.Add(NR)
                    NR = Nothing

                    lblDwtName.Text = "No Template Found"
                    mStyleDetails.AcceptChanges()
                End If

            End If

            optTextStyles.Checked = True

            IsInitializing = False

            lblDwtName.Location = New Point(optFromDwg.Location.X + optFromDwg.Width + 3, optFromDwg.Location.Y)

            If lblDwtName.Text <> "" Then
                optFromDwg.Checked = True
            Else
                optFromExternalFile.Checked = True
            End If

        Catch ex As Exception

            '' Generic Error Message to handle exceptions - uses reflection to work out where the error was generated.

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

    End Sub

    'Centers the Title of dialog in the middle of the Dialog
    Private Sub frmLayoutTools_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        lblTitle.Left = Me.Width \ 2 - Me.lblTitle.Width \ 2
    End Sub

    Private Sub cmdApply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdApply.Click
        AddSelectedData()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

    Private Sub cmdOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        AddSelectedData()
        Me.Close()
    End Sub

    Private Sub AddSelectedData()

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = Doc.Editor()

        Dim SelStyles As List(Of String) = New List(Of String)

        For Each Dt As DataGridViewRow In dgvLayerDetails.SelectedRows
            Dim DTrw As StyleDets = CType(Dt.DataBoundItem, StyleDets)
            SelStyles.Add(DTrw.StyleName.ToUpper)
        Next

        If SelStyles.Count > 0 Then

            If optFromDwg.Checked Then
                ed.WriteMessage(ImportStylesFromFile(lblDwtName.Text, SelStyles))
            End If

            If optFromExternalFile.Checked Then
                ed.WriteMessage(ImportStylesFromFile(txtExternalFile.Text, SelStyles))
            End If

        Else

            MsgBox("No Styles are selected to Import!")

        End If

    End Sub

    ''' <summary>
    ''' The Help button must have the same code in every tool.
    ''' Reflection is used to work out the name of the CHM file based on the name of the DLL.
    ''' If a CHM file is not present a generic message is displayed notifying the user that
    ''' help is not available and that they should pressure CAD Settings team to make it available.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub cmdGetFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGetFile.Click

        Dim OpFile As New OpenFileDialog

        'AutoCADOpenSingleSelect(sTargetPath, sDialogTitle, sFileTypes, sDialogName)
        'ByVal sTypes As String = "dwg; dwf; *"

        OpFile.Multiselect = True
        OpFile.Filter = "dwg files (*.dwg)|*.dwg|dwt files (*.dwt)|*.dwt|All files (*.*)|*.*"
        OpFile.FilterIndex = 1
        If OpFile.ShowDialog = Windows.Forms.DialogResult.OK Then

            txtExternalFile.Text = OpFile.FileName

        End If

        OpFile = Nothing

    End Sub

    Private Function ImportStylesFromFile(ByVal SourceFileName As String, ByVal StyleNames As List(Of String)) As String

        Dim CurrentDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = CurrentDoc.Editor()

        'Get orignal drawing
        Dim CurrentDB As Database = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database
        Dim Result As String = ""



        Try

            If optTextStyles.Checked Then

                For Each StyleName As String In StyleNames

                    'ImportSymbolTableRecord(Of TextStyleTable)(CurrentDB, SourceFileName, StyleName, chkOverWriteLayer.Checked)
                    CurrentDB.ImportSymbolTableRecord(Of TextStyleTable)(SourceFileName, StyleName, chkOverWriteLayer.Checked)

                Next

            End If

            If optDimensionStyles.Checked Then

                For Each StyleName As String In StyleNames

                    CurrentDB.ImportSymbolTableRecord(Of DimStyleTable)(SourceFileName, StyleName, chkOverWriteLayer.Checked)

                Next

            End If

            If optLineStyles.Checked Then

                For Each StyleName As String In StyleNames

                    CurrentDB.ImportSymbolTableRecord(Of LinetypeTable)(SourceFileName, StyleName, chkOverWriteLayer.Checked)

                Next

            End If

            If optTableStyles.Checked Then

                For Each StyleName As String In StyleNames

                    CurrentDB.ImportDBDictionaryRecord(SourceFileName, StyleName, chkOverWriteLayer.Checked, 0)

                Next

            End If

            If optMultiLeaderStyle.Checked Then

                For Each StyleName As String In StyleNames

                    'ImportDBDictionaryRecord(1, CurrentDB, SourceFileName, StyleName, chkOverWriteLayer.Checked)
                    CurrentDB.ImportDBDictionaryRecord(SourceFileName, StyleName, chkOverWriteLayer.Checked, 1)

                Next

            End If

        Catch ex As Exception

            Result = ex.ToString

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

        Return Result

    End Function

    Private Function GetAllStylesFromSelectedFile(ByVal LayerFileName As String) As List(Of StyleDets)

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument

        Dim Styles As List(Of StyleDets) = New List(Of StyleDets)

        If File.Exists(LayerFileName) = False Then Return Styles

        Dim DefaultSymbolsToExclude As List(Of String)

        Using DocKock As DocumentLock = Doc.LockDocument

            Dim SourceDB As Database = New Database(True, False)
            SourceDB.ReadDwgFile(LayerFileName, System.IO.FileShare.Read, False, "")

            Using db As Database = SourceDB 'Doc.Database

                Using tr As Transaction = db.TransactionManager.StartTransaction()

                    Dim NextSymbolTable As SymbolTable = Nothing
                    Dim NextDict As DBDictionary = Nothing
                    For Index As Integer = 0 To 4

                        DefaultSymbolsToExclude = New List(Of String)

                        Select Case Index
                            Case 0 'TextStyles
                                NextSymbolTable = DirectCast(tr.GetObject(SourceDB.TextStyleTableId, OpenMode.ForRead), SymbolTable)
                                DefaultSymbolsToExclude.Add("")
                            Case 1 'Dimension Styles
                                NextSymbolTable = DirectCast(tr.GetObject(SourceDB.DimStyleTableId, OpenMode.ForRead), SymbolTable)
                                DefaultSymbolsToExclude.Add("")
                            Case 2 'Line Types
                                NextSymbolTable = DirectCast(tr.GetObject(SourceDB.LinetypeTableId, OpenMode.ForRead), SymbolTable)
                                DefaultSymbolsToExclude.Add("ByLayer")
                                DefaultSymbolsToExclude.Add("ByBlock")
                                DefaultSymbolsToExclude.Add("Continuous")
                                DefaultSymbolsToExclude.Add("BYLAYER")
                                DefaultSymbolsToExclude.Add("BYBLOCK")
                                DefaultSymbolsToExclude.Add("CONTINUOUS")
                            Case 3 'Table Styles 
                                NextDict = DirectCast(tr.GetObject(SourceDB.TableStyleDictionaryId, OpenMode.ForRead), DBDictionary)
                                DefaultSymbolsToExclude.Add("")
                            Case 4 'Multi Leader Styles
                                NextDict = DirectCast(tr.GetObject(SourceDB.MLeaderStyleDictionaryId, OpenMode.ForRead), DBDictionary)
                                DefaultSymbolsToExclude.Add("")
                        End Select

                        If NextDict IsNot Nothing Then
                            Select Case Index
                                Case 3
                                    For Each DBEnt As DBDictionaryEntry In NextDict
                                        If DBEnt.Value.IsEffectivelyErased = False Then
                                            Dim tStyle As TableStyle = DirectCast(tr.GetObject(DBEnt.Value, OpenMode.ForRead), TableStyle)
                                            If DefaultSymbolsToExclude.Contains(tStyle.Name) = False Then
                                                Styles.Add(New StyleDets(Index, tStyle.Name))
                                            End If
                                        End If
                                    Next
                                Case 4
                                    For Each DBEnt As DBDictionaryEntry In NextDict
                                        If DBEnt.Value.IsEffectivelyErased = False Then
                                            Dim mLStyle As MLeaderStyle = DirectCast(tr.GetObject(DBEnt.Value, OpenMode.ForRead), MLeaderStyle)
                                            If DefaultSymbolsToExclude.Contains(mLStyle.Name) = False Then
                                                Styles.Add(New StyleDets(Index, mLStyle.Name))
                                            End If
                                        End If
                                    Next
                            End Select

                            NextDict = Nothing
                        End If

                        'text and dimension and linetypes
                        If NextSymbolTable IsNot Nothing Then
                            For Each id As ObjectId In NextSymbolTable
                                Dim symbol As SymbolTableRecord = DirectCast(tr.GetObject(id, OpenMode.ForRead), SymbolTableRecord)
                                If DefaultSymbolsToExclude.Contains(symbol.Name) = False Then
                                    Styles.Add(New StyleDets(Index, symbol.Name))
                                End If
                            Next
                            NextSymbolTable = Nothing
                        End If

                    Next

                    tr.Commit()

                End Using

            End Using

        End Using

        Return Styles

    End Function

    Private Sub optFromExternalFile_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optFromExternalFile.CheckedChanged, txtExternalFile.TextChanged

        XEnabled(pnlExternalFile, optFromExternalFile.Checked)
        LoadDGV(txtExternalFile.Text)

    End Sub

    Private Sub optFromDwt_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optFromDwg.CheckedChanged

        XEnabled(pnlExternalFile, Not (optFromDwg.Checked))
        LoadDGV(lblDwtName.Text)

    End Sub

    Private Sub LoadDGV(ByVal LoadFile As String)
        dgvLayerDetails.DataSource = Nothing

        If LoadFile = "" Then Exit Sub

        Dim SelData As List(Of StyleDets) = GetAllStylesFromSelectedFile(LoadFile)

        Dim ListFilter As Integer = -1

        If optTextStyles.Checked Then
            ListFilter = 0
        Else
            If optDimensionStyles.Checked Then
                ListFilter = 1
            Else
                If optLineStyles.Checked Then
                    ListFilter = 2
                Else
                    If optTableStyles.Checked Then
                        ListFilter = 3
                    Else
                        If optMultiLeaderStyle.Checked Then
                            ListFilter = 4
                        End If
                    End If
                End If
            End If
        End If

        Dim FilteredList As List(Of StyleDets) = (From P In SelData.AsEnumerable() _
                                                  .Where(Function(P) P.StyleFilter = ListFilter)).ToList

        dgvLayerDetails.AllowDrop = False
        dgvLayerDetails.DataSource = FilteredList

    End Sub

    Private Sub optTextStyles_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTextStyles.CheckedChanged
        LoadSelectedStyleData()
    End Sub

    Private Sub optDimensionStyles_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optDimensionStyles.CheckedChanged
        LoadSelectedStyleData()
    End Sub

    Private Sub optLineStyles_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optLineStyles.CheckedChanged
        LoadSelectedStyleData()
    End Sub

    Private Sub optTableStyles_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optTableStyles.CheckedChanged
        LoadSelectedStyleData()
    End Sub

    Private Sub optMultiLeaderStyle_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optMultiLeaderStyle.CheckedChanged
        LoadSelectedStyleData()
    End Sub

    Private Sub LoadSelectedStyleData()

        If IsInitializing Then Exit Sub

        If optFromDwg.Checked Then
            LoadDGV(lblDwtName.Text)
        Else
            LoadDGV(txtExternalFile.Text)
        End If

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoPictureBox.Click

    End Sub

    Private Sub PictureBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles LogoPictureBox.DoubleClick

        lblDwtName.Visible = Not (lblDwtName.Visible)

    End Sub

    Private Sub StylesLoaderForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub


    Private Sub dgvLayerDetails_DataBindingComplete(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewBindingCompleteEventArgs) Handles dgvLayerDetails.DataBindingComplete

        If Not dgvLayerDetails.DataSource Is Nothing Then

            Dim Col As ICollection(Of StyleDets) = CType(dgvLayerDetails.DataSource, ICollection(Of StyleDets))

            If Col.Count = 0 Then
                cmdOK.Enabled = False
            Else
                cmdOK.Enabled = True
            End If

        Else
            cmdOK.Enabled = False
        End If

    End Sub

End Class





