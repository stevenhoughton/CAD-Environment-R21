﻿
Public Class StyleDets

    Public Sub New(ByVal StyleFilter As Integer, ByVal StyleName As String)
        mStyleFilter = StyleFilter
        mStyleName = StyleName
    End Sub

    Private mStyleName As String = ""
    Public Property StyleName() As String
        Get
            Return mStyleName
        End Get
        Set(ByVal value As String)
            mStyleName = value
        End Set
    End Property

    Private mStyleFilter As Integer = -1
    Public Property StyleFilter() As Integer
        Get
            Return mStyleFilter
        End Get
        Set(ByVal value As Integer)
            mStyleFilter = value
        End Set
    End Property

End Class
