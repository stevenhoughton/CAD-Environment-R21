﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StylesLoaderForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StylesLoaderForm))
        Me.cmdApply = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.tlpButtons = New System.Windows.Forms.TableLayoutPanel()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblDwtName = New System.Windows.Forms.Label()
        Me.chkOverWriteLayer = New System.Windows.Forms.CheckBox()
        Me.pnlExternalFile = New System.Windows.Forms.Panel()
        Me.txtExternalFile = New System.Windows.Forms.TextBox()
        Me.cmdGetFile = New System.Windows.Forms.Button()
        Me.optFromExternalFile = New System.Windows.Forms.RadioButton()
        Me.optFromDwg = New System.Windows.Forms.RadioButton()
        Me.dgvLayerDetails = New System.Windows.Forms.DataGridView()
        Me.StyleName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StyleGroupBox = New System.Windows.Forms.GroupBox()
        Me.optMultiLeaderStyle = New System.Windows.Forms.RadioButton()
        Me.optTableStyles = New System.Windows.Forms.RadioButton()
        Me.optLineStyles = New System.Windows.Forms.RadioButton()
        Me.optDimensionStyles = New System.Windows.Forms.RadioButton()
        Me.optTextStyles = New System.Windows.Forms.RadioButton()
        Me.tlpButtons.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.pnlExternalFile.SuspendLayout()
        CType(Me.dgvLayerDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StyleGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdApply
        '
        Me.cmdApply.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdApply.Location = New System.Drawing.Point(97, 6)
        Me.cmdApply.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdApply.Name = "cmdApply"
        Me.cmdApply.Size = New System.Drawing.Size(85, 32)
        Me.cmdApply.TabIndex = 10
        Me.cmdApply.Text = "Apply"
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(287, 6)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(85, 32)
        Me.cmdCancel.TabIndex = 11
        Me.cmdCancel.Text = "Cancel"
        '
        'lblTitle
        '
        Me.lblTitle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(265, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(196, 35)
        Me.lblTitle.TabIndex = 23
        Me.lblTitle.Text = "Styles Loader"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdHelp
        '
        Me.cmdHelp.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(4, 6)
        Me.cmdHelp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(85, 32)
        Me.cmdHelp.TabIndex = 9
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'tlpButtons
        '
        Me.tlpButtons.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tlpButtons.ColumnCount = 4
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93.0!))
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93.0!))
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 93.0!))
        Me.tlpButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.tlpButtons.Controls.Add(Me.cmdHelp, 0, 0)
        Me.tlpButtons.Controls.Add(Me.cmdCancel, 3, 0)
        Me.tlpButtons.Controls.Add(Me.cmdApply, 1, 0)
        Me.tlpButtons.Controls.Add(Me.cmdOK, 2, 0)
        Me.tlpButtons.Location = New System.Drawing.Point(345, 582)
        Me.tlpButtons.Margin = New System.Windows.Forms.Padding(4)
        Me.tlpButtons.Name = "tlpButtons"
        Me.tlpButtons.RowCount = 1
        Me.tlpButtons.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpButtons.Size = New System.Drawing.Size(380, 44)
        Me.tlpButtons.TabIndex = 27
        '
        'cmdOK
        '
        Me.cmdOK.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.cmdOK.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdOK.Location = New System.Drawing.Point(190, 6)
        Me.cmdOK.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(85, 32)
        Me.cmdOK.TabIndex = 12
        Me.cmdOK.Text = "OK"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 0
        Me.LogoPictureBox.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.lblDwtName)
        Me.GroupBox1.Controls.Add(Me.chkOverWriteLayer)
        Me.GroupBox1.Controls.Add(Me.pnlExternalFile)
        Me.GroupBox1.Controls.Add(Me.optFromExternalFile)
        Me.GroupBox1.Controls.Add(Me.optFromDwg)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 133)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(711, 177)
        Me.GroupBox1.TabIndex = 71
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Read Layers From"
        '
        'lblDwtName
        '
        Me.lblDwtName.AutoSize = True
        Me.lblDwtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDwtName.Location = New System.Drawing.Point(257, 26)
        Me.lblDwtName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDwtName.Name = "lblDwtName"
        Me.lblDwtName.Size = New System.Drawing.Size(0, 17)
        Me.lblDwtName.TabIndex = 72
        Me.lblDwtName.Visible = False
        '
        'chkOverWriteLayer
        '
        Me.chkOverWriteLayer.AutoSize = True
        Me.chkOverWriteLayer.Location = New System.Drawing.Point(21, 149)
        Me.chkOverWriteLayer.Margin = New System.Windows.Forms.Padding(4)
        Me.chkOverWriteLayer.Name = "chkOverWriteLayer"
        Me.chkOverWriteLayer.Size = New System.Drawing.Size(156, 21)
        Me.chkOverWriteLayer.TabIndex = 8
        Me.chkOverWriteLayer.Text = "Overwrite On Import"
        Me.chkOverWriteLayer.UseVisualStyleBackColor = True
        '
        'pnlExternalFile
        '
        Me.pnlExternalFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlExternalFile.Controls.Add(Me.txtExternalFile)
        Me.pnlExternalFile.Controls.Add(Me.cmdGetFile)
        Me.pnlExternalFile.Location = New System.Drawing.Point(21, 82)
        Me.pnlExternalFile.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlExternalFile.Name = "pnlExternalFile"
        Me.pnlExternalFile.Size = New System.Drawing.Size(672, 64)
        Me.pnlExternalFile.TabIndex = 4
        '
        'txtExternalFile
        '
        Me.txtExternalFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExternalFile.Location = New System.Drawing.Point(4, 20)
        Me.txtExternalFile.Margin = New System.Windows.Forms.Padding(4)
        Me.txtExternalFile.Name = "txtExternalFile"
        Me.txtExternalFile.ReadOnly = True
        Me.txtExternalFile.Size = New System.Drawing.Size(605, 22)
        Me.txtExternalFile.TabIndex = 70
        '
        'cmdGetFile
        '
        Me.cmdGetFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdGetFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGetFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGetFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGetFile.Location = New System.Drawing.Point(619, 15)
        Me.cmdGetFile.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdGetFile.Name = "cmdGetFile"
        Me.cmdGetFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGetFile.Size = New System.Drawing.Size(40, 30)
        Me.cmdGetFile.TabIndex = 7
        Me.cmdGetFile.Text = "..."
        Me.cmdGetFile.UseVisualStyleBackColor = False
        '
        'optFromExternalFile
        '
        Me.optFromExternalFile.AutoSize = True
        Me.optFromExternalFile.Location = New System.Drawing.Point(20, 52)
        Me.optFromExternalFile.Margin = New System.Windows.Forms.Padding(4)
        Me.optFromExternalFile.Name = "optFromExternalFile"
        Me.optFromExternalFile.Size = New System.Drawing.Size(180, 21)
        Me.optFromExternalFile.TabIndex = 6
        Me.optFromExternalFile.TabStop = True
        Me.optFromExternalFile.Text = "Read From External File"
        Me.optFromExternalFile.UseVisualStyleBackColor = True
        '
        'optFromDwg
        '
        Me.optFromDwg.AutoSize = True
        Me.optFromDwg.Location = New System.Drawing.Point(20, 23)
        Me.optFromDwg.Margin = New System.Windows.Forms.Padding(4)
        Me.optFromDwg.Name = "optFromDwg"
        Me.optFromDwg.Size = New System.Drawing.Size(162, 21)
        Me.optFromDwg.TabIndex = 5
        Me.optFromDwg.TabStop = True
        Me.optFromDwg.Text = "Read From Template"
        Me.optFromDwg.UseVisualStyleBackColor = True
        '
        'dgvLayerDetails
        '
        Me.dgvLayerDetails.AllowUserToAddRows = False
        Me.dgvLayerDetails.AllowUserToDeleteRows = False
        Me.dgvLayerDetails.AllowUserToResizeColumns = False
        Me.dgvLayerDetails.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvLayerDetails.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvLayerDetails.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvLayerDetails.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.dgvLayerDetails.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvLayerDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLayerDetails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StyleName})
        Me.dgvLayerDetails.Location = New System.Drawing.Point(16, 322)
        Me.dgvLayerDetails.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvLayerDetails.Name = "dgvLayerDetails"
        Me.dgvLayerDetails.ReadOnly = True
        Me.dgvLayerDetails.RowTemplate.Height = 24
        Me.dgvLayerDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvLayerDetails.Size = New System.Drawing.Size(711, 241)
        Me.dgvLayerDetails.TabIndex = 72
        '
        'StyleName
        '
        Me.StyleName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.StyleName.DataPropertyName = "StyleName"
        Me.StyleName.HeaderText = "Style Name"
        Me.StyleName.Name = "StyleName"
        Me.StyleName.ReadOnly = True
        '
        'StyleGroupBox
        '
        Me.StyleGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StyleGroupBox.Controls.Add(Me.optMultiLeaderStyle)
        Me.StyleGroupBox.Controls.Add(Me.optTableStyles)
        Me.StyleGroupBox.Controls.Add(Me.optLineStyles)
        Me.StyleGroupBox.Controls.Add(Me.optDimensionStyles)
        Me.StyleGroupBox.Controls.Add(Me.optTextStyles)
        Me.StyleGroupBox.Location = New System.Drawing.Point(17, 78)
        Me.StyleGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.StyleGroupBox.Name = "StyleGroupBox"
        Me.StyleGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.StyleGroupBox.Size = New System.Drawing.Size(709, 48)
        Me.StyleGroupBox.TabIndex = 74
        Me.StyleGroupBox.TabStop = False
        Me.StyleGroupBox.Text = "Style"
        '
        'optMultiLeaderStyle
        '
        Me.optMultiLeaderStyle.AutoSize = True
        Me.optMultiLeaderStyle.Dock = System.Windows.Forms.DockStyle.Left
        Me.optMultiLeaderStyle.Location = New System.Drawing.Point(508, 19)
        Me.optMultiLeaderStyle.Margin = New System.Windows.Forms.Padding(4)
        Me.optMultiLeaderStyle.Name = "optMultiLeaderStyle"
        Me.optMultiLeaderStyle.Padding = New System.Windows.Forms.Padding(0, 0, 16, 0)
        Me.optMultiLeaderStyle.Size = New System.Drawing.Size(166, 25)
        Me.optMultiLeaderStyle.TabIndex = 9
        Me.optMultiLeaderStyle.Text = "Multi-Leader Styles"
        Me.optMultiLeaderStyle.UseVisualStyleBackColor = True
        '
        'optTableStyles
        '
        Me.optTableStyles.AutoSize = True
        Me.optTableStyles.Dock = System.Windows.Forms.DockStyle.Left
        Me.optTableStyles.Location = New System.Drawing.Point(385, 19)
        Me.optTableStyles.Margin = New System.Windows.Forms.Padding(4)
        Me.optTableStyles.Name = "optTableStyles"
        Me.optTableStyles.Padding = New System.Windows.Forms.Padding(0, 0, 16, 0)
        Me.optTableStyles.Size = New System.Drawing.Size(123, 25)
        Me.optTableStyles.TabIndex = 8
        Me.optTableStyles.Text = "Table Styles"
        Me.optTableStyles.UseVisualStyleBackColor = True
        '
        'optLineStyles
        '
        Me.optLineStyles.AutoSize = True
        Me.optLineStyles.Dock = System.Windows.Forms.DockStyle.Left
        Me.optLineStyles.Location = New System.Drawing.Point(271, 19)
        Me.optLineStyles.Margin = New System.Windows.Forms.Padding(4)
        Me.optLineStyles.Name = "optLineStyles"
        Me.optLineStyles.Padding = New System.Windows.Forms.Padding(0, 0, 16, 0)
        Me.optLineStyles.Size = New System.Drawing.Size(114, 25)
        Me.optLineStyles.TabIndex = 7
        Me.optLineStyles.Text = "Line Styles"
        Me.optLineStyles.UseVisualStyleBackColor = True
        '
        'optDimensionStyles
        '
        Me.optDimensionStyles.AutoSize = True
        Me.optDimensionStyles.Dock = System.Windows.Forms.DockStyle.Left
        Me.optDimensionStyles.Location = New System.Drawing.Point(118, 19)
        Me.optDimensionStyles.Margin = New System.Windows.Forms.Padding(4)
        Me.optDimensionStyles.Name = "optDimensionStyles"
        Me.optDimensionStyles.Padding = New System.Windows.Forms.Padding(0, 0, 16, 0)
        Me.optDimensionStyles.Size = New System.Drawing.Size(153, 25)
        Me.optDimensionStyles.TabIndex = 6
        Me.optDimensionStyles.Text = "Dimension Styles"
        Me.optDimensionStyles.UseVisualStyleBackColor = True
        '
        'optTextStyles
        '
        Me.optTextStyles.AutoSize = True
        Me.optTextStyles.Dock = System.Windows.Forms.DockStyle.Left
        Me.optTextStyles.Location = New System.Drawing.Point(4, 19)
        Me.optTextStyles.Margin = New System.Windows.Forms.Padding(4)
        Me.optTextStyles.Name = "optTextStyles"
        Me.optTextStyles.Padding = New System.Windows.Forms.Padding(0, 0, 16, 0)
        Me.optTextStyles.Size = New System.Drawing.Size(114, 25)
        Me.optTextStyles.TabIndex = 5
        Me.optTextStyles.Text = "Text Styles"
        Me.optTextStyles.UseVisualStyleBackColor = True
        '
        'StylesLoaderForm
        '
        Me.AcceptButton = Me.cmdApply
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CancelButton = Me.cmdCancel
        Me.ClientSize = New System.Drawing.Size(741, 639)
        Me.Controls.Add(Me.StyleGroupBox)
        Me.Controls.Add(Me.dgvLayerDetails)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.tlpButtons)
        Me.Controls.Add(Me.lblTitle)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(757, 675)
        Me.Name = "StylesLoaderForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.tlpButtons.ResumeLayout(False)
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.pnlExternalFile.ResumeLayout(False)
        Me.pnlExternalFile.PerformLayout()
        CType(Me.dgvLayerDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StyleGroupBox.ResumeLayout(False)
        Me.StyleGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdApply As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Friend WithEvents tlpButtons As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents chkOverWriteLayer As System.Windows.Forms.CheckBox
    Friend WithEvents pnlExternalFile As System.Windows.Forms.Panel
    Friend WithEvents txtExternalFile As System.Windows.Forms.TextBox
    Public WithEvents cmdGetFile As System.Windows.Forms.Button
    Friend WithEvents optFromExternalFile As System.Windows.Forms.RadioButton
    Friend WithEvents dgvLayerDetails As System.Windows.Forms.DataGridView
    Friend WithEvents lblDwtName As System.Windows.Forms.Label
    Friend WithEvents StyleName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents StyleGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents optMultiLeaderStyle As System.Windows.Forms.RadioButton
    Friend WithEvents optTableStyles As System.Windows.Forms.RadioButton
    Friend WithEvents optLineStyles As System.Windows.Forms.RadioButton
    Friend WithEvents optDimensionStyles As System.Windows.Forms.RadioButton
    Friend WithEvents optTextStyles As System.Windows.Forms.RadioButton
    Friend WithEvents optFromDwg As System.Windows.Forms.RadioButton

End Class
