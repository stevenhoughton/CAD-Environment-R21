﻿Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput

Public Module DbExtensionFunctions

    <System.Runtime.CompilerServices.Extension()> _
    Public Function ImportSymbolTableRecord(Of T As SymbolTable)(targetDb As Database, sourceFile As String, recordName As String, ByVal OverWrite As Boolean) As ObjectId

        Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = doc.Editor

        Dim StylesToClone As New ObjectIdCollection()
        Dim extdb As Database = Nothing

        Try

            Using docLock As DocumentLock = doc.LockDocument

                extdb = New Database(False, True)
                Dim tr As Transaction = targetDb.TransactionManager.StartTransaction()

                Using tr

                    extdb.ReadDwgFile(sourceFile, System.IO.FileShare.Read, True, Nothing)

                    If extdb Is Nothing Then
                        Return ObjectId.Null
                    End If

                    Dim sourceTableId As ObjectId, targetTableId As ObjectId

                    Dim tr2 As Transaction = extdb.TransactionManager.StartTransaction()
                    Using tr2

                        Select Case GetType(T).Name
                            Case "LayerTable"
                                sourceTableId = extdb.LayerTableId
                                targetTableId = targetDb.LayerTableId
                                Exit Select
                            Case "DimStyleTable"
                                sourceTableId = extdb.DimStyleTableId
                                targetTableId = targetDb.DimStyleTableId
                                Exit Select
                            Case "LinetypeTable"
                                sourceTableId = extdb.LinetypeTableId
                                targetTableId = targetDb.LinetypeTableId
                                Exit Select
                            Case "TextStyleTable"
                                sourceTableId = extdb.TextStyleTableId
                                targetTableId = targetDb.TextStyleTableId
                                Exit Select
                            Case Else
                                Throw New ArgumentException("Requires a concrete type derived from SymbolTable")
                        End Select

                        ' Open the Textsyle table
                        Dim tt As T = DirectCast(tr2.GetObject(sourceTableId, OpenMode.ForRead), T)

                        If Not tt.Has(recordName) Then
                            Return ObjectId.Null
                        End If

                        If tt(recordName).IsErased = True Then
                            Return ObjectId.Null
                        End If

                        StylesToClone.Add(tt(recordName))

                        tr2.Commit()
                    End Using

                    Dim DupValues As DuplicateRecordCloning = If(OverWrite <> False, DuplicateRecordCloning.Replace, DuplicateRecordCloning.Ignore)

                    If StylesToClone.Count > 0 Then

                        Dim idMap As New IdMapping()
                        targetDb.WblockCloneObjects(StylesToClone, targetTableId, idMap, DupValues, False)
                        extdb.Dispose()

                    End If

                    ed.WriteMessage(vbLf & vbTab & "Imported: {0} " & GetType(T).Name.Replace("Table", ""), recordName)

                    tr.Commit()

                End Using

            End Using
        Catch ex As System.Exception
            ed.WriteMessage(ex.Message)
        Finally
        End Try

    End Function

    <System.Runtime.CompilerServices.Extension()> _
    Public Function ImportDBDictionaryRecord(targetDb As Database, sourceFile As String, recordName As String, ByVal OverWrite As Boolean, ByVal DictType As Integer) As ObjectId

        Dim doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim ed As Editor = doc.Editor
        Dim RetName As String = ""

        Dim StylesToClone As New ObjectIdCollection()
        Dim extdb As Database = Nothing

        Try

            Using docLock As DocumentLock = doc.LockDocument

                extdb = New Database(False, True)
                Dim tr As Transaction = targetDb.TransactionManager.StartTransaction()

                Using tr

                    extdb.ReadDwgFile(sourceFile, System.IO.FileShare.Read, True, Nothing)

                    If extdb Is Nothing Then
                        Return ObjectId.Null
                    End If

                    Dim sourceTableId As ObjectId, targetTableId As ObjectId

                    Dim tr2 As Transaction = extdb.TransactionManager.StartTransaction()
                    Using tr2

                        Select Case DictType
                            Case 0
                                sourceTableId = extdb.TableStyleDictionaryId
                                targetTableId = targetDb.TableStyleDictionaryId
                                RetName = "Table Style"
                                Exit Select
                            Case 1
                                sourceTableId = extdb.MLeaderStyleDictionaryId
                                targetTableId = targetDb.MLeaderStyleDictionaryId
                                RetName = "MultiLeader Style"
                                Exit Select
                            Case Else
                                Throw New ArgumentException("Requires a concrete type derived from SymbolTable")
                        End Select

                        Dim tt As DBDictionary = DirectCast(tr2.GetObject(sourceTableId, OpenMode.ForRead), DBDictionary)

                        If tt Is Nothing Then
                            Return ObjectId.Null
                        End If

                        If DirectCast(tt(recordName), ObjectId) = ObjectId.Null Then
                            Return ObjectId.Null
                        End If

                        StylesToClone.Add(DirectCast(tt(recordName), ObjectId))

                        tr2.Commit()

                    End Using

                    Dim DupValues As DuplicateRecordCloning = If(OverWrite <> False, DuplicateRecordCloning.Replace, DuplicateRecordCloning.Ignore)

                    If StylesToClone.Count > 0 Then

                        Dim idMap As New IdMapping()
                        targetDb.WblockCloneObjects(StylesToClone, targetTableId, idMap, DupValues, False)
                        extdb.Dispose()

                    End If

                    ed.WriteMessage(vbLf & vbTab & "Imported: {0} " & RetName, recordName)

                    tr.Commit()

                End Using

            End Using
        Catch ex As System.Exception
            ed.WriteMessage(ex.Message)

        Finally
        End Try

    End Function

    '<System.Runtime.CompilerServices.Extension()> _
    'Public Function ImportDBDictionaryRecord(targetDb As Database, sourceFile As String, recordName As String, ByVal OverWrite As Boolean, ByVal DictType As Integer) As ObjectId

    '    Dim CurrentDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument

    '    Using DokLock As DocumentLock = CurrentDoc.LockDocument

    '        Using sourceDb As New Database()

    '            sourceDb.ReadDwgFile(sourceFile, System.IO.FileShare.Read, False, "")

    '            Dim sourceTableId As ObjectId, targetTableId As ObjectId

    '            Select Case DictType
    '                Case 0
    '                    sourceTableId = sourceDb.TableStyleDictionaryId
    '                    targetTableId = targetDb.TableStyleDictionaryId
    '                    Exit Select
    '                Case 1
    '                    sourceTableId = sourceDb.MLeaderStyleDictionaryId
    '                    targetTableId = targetDb.MLeaderStyleDictionaryId
    '                    Exit Select
    '                Case Else
    '                    Throw New ArgumentException("Requires a concrete type derived from SymbolTable")
    '            End Select

    '            Dim DupValues As DuplicateRecordCloning = If(OverWrite <> False, DuplicateRecordCloning.Replace, DuplicateRecordCloning.Ignore)

    '            Using tr As Transaction = sourceDb.TransactionManager.StartTransaction()
    '                Dim sourceTable As DBDictionary = DirectCast(tr.GetObject(sourceTableId, OpenMode.ForRead), DBDictionary)
    '                If sourceTable(recordName) Is Nothing Then
    '                    Return ObjectId.Null
    '                End If
    '                Dim idCol As New ObjectIdCollection()
    '                Dim sourceTableRecordId As ObjectId = DirectCast(sourceTable(recordName), ObjectId) 'sourceTable(recordName)
    '                idCol.Add(sourceTableRecordId)
    '                Dim idMap As New IdMapping()
    '                sourceDb.WblockCloneObjects(idCol, targetTableId, idMap, DupValues, False)
    '                tr.Commit()
    '                Return idMap(sourceTableRecordId).Value
    '            End Using
    '        End Using
    '    End Using
    'End Function

End Module

