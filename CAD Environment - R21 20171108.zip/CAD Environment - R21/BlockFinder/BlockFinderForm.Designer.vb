
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.Utilities.DwgView

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class BlockFinderForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BlockFinderForm))
        Me.pnlButtonBtm = New System.Windows.Forms.Panel()
        Me.cmdInsertBlock = New System.Windows.Forms.Button()
        Me.cmdOpenDC = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.spcPageLayout = New System.Windows.Forms.SplitContainer()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.spcBasic = New System.Windows.Forms.SplitContainer()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.CorporateFavouriteListView = New System.Windows.Forms.ListView()
        Me.ColumnName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Path = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ConfigFavListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.UserFavListView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.BrowseButton = New System.Windows.Forms.Button()
        Me.dpcBlockViewBasic = New DwgPreviewControl
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.spcAdvanced = New System.Windows.Forms.SplitContainer()
        Me.spcAdvancedTop = New System.Windows.Forms.SplitContainer()
        Me.DirectSearchFrame = New System.Windows.Forms.GroupBox()
        Me.SearchTextBox = New System.Windows.Forms.TextBox()
        Me.cmdClear = New System.Windows.Forms.Button()
        Me.FiltersFrame = New System.Windows.Forms.GroupBox()
        Me.BusinessUnitComboBox = New System.Windows.Forms.ComboBox()
        Me.BusinessUnitLabel = New System.Windows.Forms.Label()
        Me.DisciplineComboBox = New System.Windows.Forms.ComboBox()
        Me.DisciplineLabel = New System.Windows.Forms.Label()
        Me.RegionComboBox = New System.Windows.Forms.ComboBox()
        Me.RegionLabel = New System.Windows.Forms.Label()
        Me.TypeComboBox = New System.Windows.Forms.ComboBox()
        Me.TypeLabel = New System.Windows.Forms.Label()
        Me.dpcBlockViewAdv = New DwgPreviewControl
        Me.FilteredLocationsFrame = New System.Windows.Forms.GroupBox()
        Me.FilteredLocationsListView = New System.Windows.Forms.ListView()
        Me.pnlButtons = New System.Windows.Forms.Panel()
        Me.cmdAddToFavourites = New System.Windows.Forms.Button()
        Me.cmdRemoveFromFavourites = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.gbxInsertOnClose = New System.Windows.Forms.GroupBox()
        Me.gbxBlockDets = New System.Windows.Forms.GroupBox()
        Me.dpcBlockViewBlk = New DwgPreviewControl
        Me.lstBlockNames = New System.Windows.Forms.ListBox()
        Me.gbxBlockMisc = New System.Windows.Forms.GroupBox()
        Me.chkRotOnInsert = New System.Windows.Forms.CheckBox()
        Me.txtRotate = New System.Windows.Forms.TextBox()
        Me.lblRotate = New System.Windows.Forms.Label()
        Me.gbxBlockScale = New System.Windows.Forms.GroupBox()
        Me.chkInsertUseDimScale = New System.Windows.Forms.CheckBox()
        Me.txtScaleZ = New System.Windows.Forms.TextBox()
        Me.txtScaleY = New System.Windows.Forms.TextBox()
        Me.txtScaleX = New System.Windows.Forms.TextBox()
        Me.lblScaleZ = New System.Windows.Forms.Label()
        Me.lblScaleY = New System.Windows.Forms.Label()
        Me.lblScaleX = New System.Windows.Forms.Label()
        Me.chkUniScale = New System.Windows.Forms.CheckBox()
        Me.pnlBanner = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.chkEditAttributesOnEdit = New System.Windows.Forms.CheckBox()
        Me.pnlButtonBtm.SuspendLayout()
        CType(Me.spcPageLayout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.spcPageLayout.Panel1.SuspendLayout()
        Me.spcPageLayout.Panel2.SuspendLayout()
        Me.spcPageLayout.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.spcBasic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.spcBasic.Panel1.SuspendLayout()
        Me.spcBasic.Panel2.SuspendLayout()
        Me.spcBasic.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.spcAdvanced, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.spcAdvanced.Panel1.SuspendLayout()
        Me.spcAdvanced.Panel2.SuspendLayout()
        Me.spcAdvanced.SuspendLayout()
        CType(Me.spcAdvancedTop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.spcAdvancedTop.Panel1.SuspendLayout()
        Me.spcAdvancedTop.Panel2.SuspendLayout()
        Me.spcAdvancedTop.SuspendLayout()
        Me.DirectSearchFrame.SuspendLayout()
        Me.FiltersFrame.SuspendLayout()
        Me.FilteredLocationsFrame.SuspendLayout()
        Me.pnlButtons.SuspendLayout()
        Me.gbxInsertOnClose.SuspendLayout()
        Me.gbxBlockDets.SuspendLayout()
        Me.gbxBlockMisc.SuspendLayout()
        Me.gbxBlockScale.SuspendLayout()
        Me.pnlBanner.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlButtonBtm
        '
        Me.pnlButtonBtm.Controls.Add(Me.cmdInsertBlock)
        Me.pnlButtonBtm.Controls.Add(Me.cmdOpenDC)
        Me.pnlButtonBtm.Controls.Add(Me.Cancel_Button)
        Me.pnlButtonBtm.Controls.Add(Me.cmdHelp)
        Me.pnlButtonBtm.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtonBtm.Location = New System.Drawing.Point(0, 732)
        Me.pnlButtonBtm.Name = "pnlButtonBtm"
        Me.pnlButtonBtm.Padding = New System.Windows.Forms.Padding(12, 6, 12, 6)
        Me.pnlButtonBtm.Size = New System.Drawing.Size(921, 37)
        Me.pnlButtonBtm.TabIndex = 33
        '
        'cmdInsertBlock
        '
        Me.cmdInsertBlock.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInsertBlock.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInsertBlock.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmdInsertBlock.Enabled = False
        Me.cmdInsertBlock.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdInsertBlock.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInsertBlock.Location = New System.Drawing.Point(592, 6)
        Me.cmdInsertBlock.Name = "cmdInsertBlock"
        Me.cmdInsertBlock.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInsertBlock.Size = New System.Drawing.Size(99, 25)
        Me.cmdInsertBlock.TabIndex = 38
        Me.cmdInsertBlock.Text = "Insert Block"
        Me.cmdInsertBlock.UseVisualStyleBackColor = False
        '
        'cmdOpenDC
        '
        Me.cmdOpenDC.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOpenDC.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdOpenDC.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmdOpenDC.Enabled = False
        Me.cmdOpenDC.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOpenDC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdOpenDC.Location = New System.Drawing.Point(691, 6)
        Me.cmdOpenDC.Name = "cmdOpenDC"
        Me.cmdOpenDC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdOpenDC.Size = New System.Drawing.Size(119, 25)
        Me.cmdOpenDC.TabIndex = 34
        Me.cmdOpenDC.Text = "Design Center"
        Me.cmdOpenDC.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.Dock = System.Windows.Forms.DockStyle.Right
        Me.Cancel_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(810, 6)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(99, 25)
        Me.Cancel_Button.TabIndex = 35
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'cmdHelp
        '
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.Dock = System.Windows.Forms.DockStyle.Left
        Me.cmdHelp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(12, 6)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(99, 25)
        Me.cmdHelp.TabIndex = 36
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'spcPageLayout
        '
        Me.spcPageLayout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spcPageLayout.Location = New System.Drawing.Point(0, 52)
        Me.spcPageLayout.Name = "spcPageLayout"
        Me.spcPageLayout.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'spcPageLayout.Panel1
        '
        Me.spcPageLayout.Panel1.Controls.Add(Me.TabControl2)
        Me.spcPageLayout.Panel1.Padding = New System.Windows.Forms.Padding(3)
        '
        'spcPageLayout.Panel2
        '
        Me.spcPageLayout.Panel2.Controls.Add(Me.gbxInsertOnClose)
        Me.spcPageLayout.Panel2.Padding = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.spcPageLayout.Size = New System.Drawing.Size(921, 680)
        Me.spcPageLayout.SplitterDistance = 446
        Me.spcPageLayout.SplitterWidth = 10
        Me.spcPageLayout.TabIndex = 35
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.Location = New System.Drawing.Point(3, 3)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(915, 440)
        Me.TabControl2.TabIndex = 33
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.spcBasic)
        Me.TabPage4.Location = New System.Drawing.Point(4, 26)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(907, 410)
        Me.TabPage4.TabIndex = 0
        Me.TabPage4.Text = "Basic"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'spcBasic
        '
        Me.spcBasic.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spcBasic.Location = New System.Drawing.Point(3, 3)
        Me.spcBasic.Name = "spcBasic"
        '
        'spcBasic.Panel1
        '
        Me.spcBasic.Panel1.Controls.Add(Me.TabControl1)
        Me.spcBasic.Panel1.Padding = New System.Windows.Forms.Padding(3)
        Me.spcBasic.Panel1MinSize = 250
        '
        'spcBasic.Panel2
        '
        Me.spcBasic.Panel2.Controls.Add(Me.dpcBlockViewBasic)
        Me.spcBasic.Panel2.Padding = New System.Windows.Forms.Padding(3)
        Me.spcBasic.Size = New System.Drawing.Size(901, 404)
        Me.spcBasic.SplitterDistance = 312
        Me.spcBasic.TabIndex = 0
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(3, 3)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(306, 398)
        Me.TabControl1.TabIndex = 32
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.CorporateFavouriteListView)
        Me.TabPage3.Location = New System.Drawing.Point(4, 26)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(298, 368)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Corporate"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'CorporateFavouriteListView
        '
        Me.CorporateFavouriteListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnName, Me.Path})
        Me.CorporateFavouriteListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CorporateFavouriteListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.CorporateFavouriteListView.Location = New System.Drawing.Point(3, 3)
        Me.CorporateFavouriteListView.Name = "CorporateFavouriteListView"
        Me.CorporateFavouriteListView.Scrollable = False
        Me.CorporateFavouriteListView.Size = New System.Drawing.Size(292, 362)
        Me.CorporateFavouriteListView.TabIndex = 0
        Me.CorporateFavouriteListView.UseCompatibleStateImageBehavior = False
        Me.CorporateFavouriteListView.View = System.Windows.Forms.View.Details
        '
        'ColumnName
        '
        Me.ColumnName.Width = 500
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.ConfigFavListView)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(298, 370)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Client Template"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ConfigFavListView
        '
        Me.ConfigFavListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3, Me.ColumnHeader4})
        Me.ConfigFavListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ConfigFavListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.ConfigFavListView.Location = New System.Drawing.Point(3, 3)
        Me.ConfigFavListView.Name = "ConfigFavListView"
        Me.ConfigFavListView.Scrollable = False
        Me.ConfigFavListView.Size = New System.Drawing.Size(292, 363)
        Me.ConfigFavListView.TabIndex = 0
        Me.ConfigFavListView.UseCompatibleStateImageBehavior = False
        Me.ConfigFavListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Width = 400
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.UserFavListView)
        Me.TabPage1.Controls.Add(Me.BrowseButton)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(298, 370)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "User"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'UserFavListView
        '
        Me.UserFavListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.UserFavListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.UserFavListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.UserFavListView.Location = New System.Drawing.Point(3, 3)
        Me.UserFavListView.Name = "UserFavListView"
        Me.UserFavListView.Scrollable = False
        Me.UserFavListView.Size = New System.Drawing.Size(292, 363)
        Me.UserFavListView.TabIndex = 0
        Me.UserFavListView.UseCompatibleStateImageBehavior = False
        Me.UserFavListView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Width = 400
        '
        'BrowseButton
        '
        Me.BrowseButton.BackColor = System.Drawing.SystemColors.Control
        Me.BrowseButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.BrowseButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BrowseButton.Location = New System.Drawing.Point(6, 484)
        Me.BrowseButton.Name = "BrowseButton"
        Me.BrowseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BrowseButton.Size = New System.Drawing.Size(386, 33)
        Me.BrowseButton.TabIndex = 23
        Me.BrowseButton.Text = "Alternative Favourites"
        Me.BrowseButton.UseVisualStyleBackColor = False
        '
        'dpcBlockViewBasic
        '
        Me.dpcBlockViewBasic.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dpcBlockViewBasic.Location = New System.Drawing.Point(3, 3)
        Me.dpcBlockViewBasic.Name = "dpcBlockViewBasic"
        Me.dpcBlockViewBasic.Size = New System.Drawing.Size(579, 398)
        Me.dpcBlockViewBasic.TabIndex = 33
        Me.dpcBlockViewBasic.Text = "DwgPreviewControl1"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.spcAdvanced)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(907, 411)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "Advanced"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'spcAdvanced
        '
        Me.spcAdvanced.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spcAdvanced.Location = New System.Drawing.Point(3, 3)
        Me.spcAdvanced.Name = "spcAdvanced"
        Me.spcAdvanced.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'spcAdvanced.Panel1
        '
        Me.spcAdvanced.Panel1.Controls.Add(Me.spcAdvancedTop)
        '
        'spcAdvanced.Panel2
        '
        Me.spcAdvanced.Panel2.Controls.Add(Me.FilteredLocationsFrame)
        Me.spcAdvanced.Panel2.Controls.Add(Me.pnlButtons)
        Me.spcAdvanced.Panel2.Controls.Add(Me.Label1)
        Me.spcAdvanced.Size = New System.Drawing.Size(901, 405)
        Me.spcAdvanced.SplitterDistance = 199
        Me.spcAdvanced.TabIndex = 1
        '
        'spcAdvancedTop
        '
        Me.spcAdvancedTop.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spcAdvancedTop.Location = New System.Drawing.Point(0, 0)
        Me.spcAdvancedTop.Name = "spcAdvancedTop"
        '
        'spcAdvancedTop.Panel1
        '
        Me.spcAdvancedTop.Panel1.Controls.Add(Me.DirectSearchFrame)
        Me.spcAdvancedTop.Panel1.Controls.Add(Me.FiltersFrame)
        Me.spcAdvancedTop.Panel1.Padding = New System.Windows.Forms.Padding(12, 24, 12, 3)
        '
        'spcAdvancedTop.Panel2
        '
        Me.spcAdvancedTop.Panel2.Controls.Add(Me.dpcBlockViewAdv)
        Me.spcAdvancedTop.Panel2.Padding = New System.Windows.Forms.Padding(3)
        Me.spcAdvancedTop.Size = New System.Drawing.Size(901, 199)
        Me.spcAdvancedTop.SplitterDistance = 298
        Me.spcAdvancedTop.TabIndex = 0
        '
        'DirectSearchFrame
        '
        Me.DirectSearchFrame.Controls.Add(Me.SearchTextBox)
        Me.DirectSearchFrame.Controls.Add(Me.cmdClear)
        Me.DirectSearchFrame.Dock = System.Windows.Forms.DockStyle.Top
        Me.DirectSearchFrame.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DirectSearchFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DirectSearchFrame.Location = New System.Drawing.Point(12, 136)
        Me.DirectSearchFrame.Name = "DirectSearchFrame"
        Me.DirectSearchFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DirectSearchFrame.Size = New System.Drawing.Size(274, 48)
        Me.DirectSearchFrame.TabIndex = 30
        Me.DirectSearchFrame.TabStop = False
        Me.DirectSearchFrame.Text = "Feeling Lucky"
        '
        'SearchTextBox
        '
        Me.SearchTextBox.AcceptsReturn = True
        Me.SearchTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SearchTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.SearchTextBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SearchTextBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchTextBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SearchTextBox.Location = New System.Drawing.Point(18, 16)
        Me.SearchTextBox.MaxLength = 0
        Me.SearchTextBox.Name = "SearchTextBox"
        Me.SearchTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SearchTextBox.Size = New System.Drawing.Size(156, 24)
        Me.SearchTextBox.TabIndex = 0
        '
        'cmdClear
        '
        Me.cmdClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdClear.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClear.Location = New System.Drawing.Point(188, 16)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClear.Size = New System.Drawing.Size(77, 27)
        Me.cmdClear.TabIndex = 1
        Me.cmdClear.Text = "Clear"
        Me.cmdClear.UseVisualStyleBackColor = False
        '
        'FiltersFrame
        '
        Me.FiltersFrame.Controls.Add(Me.BusinessUnitComboBox)
        Me.FiltersFrame.Controls.Add(Me.BusinessUnitLabel)
        Me.FiltersFrame.Controls.Add(Me.DisciplineComboBox)
        Me.FiltersFrame.Controls.Add(Me.DisciplineLabel)
        Me.FiltersFrame.Controls.Add(Me.RegionComboBox)
        Me.FiltersFrame.Controls.Add(Me.RegionLabel)
        Me.FiltersFrame.Controls.Add(Me.TypeComboBox)
        Me.FiltersFrame.Controls.Add(Me.TypeLabel)
        Me.FiltersFrame.Dock = System.Windows.Forms.DockStyle.Top
        Me.FiltersFrame.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiltersFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FiltersFrame.Location = New System.Drawing.Point(12, 24)
        Me.FiltersFrame.Name = "FiltersFrame"
        Me.FiltersFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FiltersFrame.Size = New System.Drawing.Size(274, 112)
        Me.FiltersFrame.TabIndex = 28
        Me.FiltersFrame.TabStop = False
        Me.FiltersFrame.Text = "Search Filters"
        '
        'BusinessUnitComboBox
        '
        Me.BusinessUnitComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BusinessUnitComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.BusinessUnitComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.BusinessUnitComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BusinessUnitComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.BusinessUnitComboBox.Location = New System.Drawing.Point(102, 16)
        Me.BusinessUnitComboBox.Name = "BusinessUnitComboBox"
        Me.BusinessUnitComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BusinessUnitComboBox.Size = New System.Drawing.Size(163, 25)
        Me.BusinessUnitComboBox.TabIndex = 0
        '
        'BusinessUnitLabel
        '
        Me.BusinessUnitLabel.AutoSize = True
        Me.BusinessUnitLabel.BackColor = System.Drawing.SystemColors.Control
        Me.BusinessUnitLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.BusinessUnitLabel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BusinessUnitLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BusinessUnitLabel.Location = New System.Drawing.Point(9, 20)
        Me.BusinessUnitLabel.Name = "BusinessUnitLabel"
        Me.BusinessUnitLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BusinessUnitLabel.Size = New System.Drawing.Size(87, 17)
        Me.BusinessUnitLabel.TabIndex = 1
        Me.BusinessUnitLabel.Text = "Business Unit"
        '
        'DisciplineComboBox
        '
        Me.DisciplineComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DisciplineComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.DisciplineComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.DisciplineComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisciplineComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DisciplineComboBox.Location = New System.Drawing.Point(102, 48)
        Me.DisciplineComboBox.Name = "DisciplineComboBox"
        Me.DisciplineComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DisciplineComboBox.Size = New System.Drawing.Size(163, 25)
        Me.DisciplineComboBox.TabIndex = 2
        '
        'DisciplineLabel
        '
        Me.DisciplineLabel.AutoSize = True
        Me.DisciplineLabel.BackColor = System.Drawing.SystemColors.Control
        Me.DisciplineLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.DisciplineLabel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisciplineLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DisciplineLabel.Location = New System.Drawing.Point(34, 52)
        Me.DisciplineLabel.Name = "DisciplineLabel"
        Me.DisciplineLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DisciplineLabel.Size = New System.Drawing.Size(62, 17)
        Me.DisciplineLabel.TabIndex = 3
        Me.DisciplineLabel.Text = "Discipline"
        '
        'RegionComboBox
        '
        Me.RegionComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RegionComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.RegionComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RegionComboBox.Location = New System.Drawing.Point(102, 80)
        Me.RegionComboBox.Name = "RegionComboBox"
        Me.RegionComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionComboBox.Size = New System.Drawing.Size(163, 25)
        Me.RegionComboBox.TabIndex = 4
        '
        'RegionLabel
        '
        Me.RegionLabel.AutoSize = True
        Me.RegionLabel.BackColor = System.Drawing.SystemColors.Control
        Me.RegionLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionLabel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RegionLabel.Location = New System.Drawing.Point(46, 84)
        Me.RegionLabel.Name = "RegionLabel"
        Me.RegionLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionLabel.Size = New System.Drawing.Size(50, 17)
        Me.RegionLabel.TabIndex = 5
        Me.RegionLabel.Text = "Region"
        '
        'TypeComboBox
        '
        Me.TypeComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.TypeComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.TypeComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TypeComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TypeComboBox.Location = New System.Drawing.Point(82, 112)
        Me.TypeComboBox.Name = "TypeComboBox"
        Me.TypeComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TypeComboBox.Size = New System.Drawing.Size(252, 25)
        Me.TypeComboBox.TabIndex = 6
        Me.TypeComboBox.Visible = False
        '
        'TypeLabel
        '
        Me.TypeLabel.AutoSize = True
        Me.TypeLabel.BackColor = System.Drawing.SystemColors.Control
        Me.TypeLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.TypeLabel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TypeLabel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TypeLabel.Location = New System.Drawing.Point(50, 116)
        Me.TypeLabel.Name = "TypeLabel"
        Me.TypeLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TypeLabel.Size = New System.Drawing.Size(39, 17)
        Me.TypeLabel.TabIndex = 7
        Me.TypeLabel.Text = "Type"
        Me.TypeLabel.Visible = False
        '
        'dpcBlockViewAdv
        '
        Me.dpcBlockViewAdv.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dpcBlockViewAdv.Location = New System.Drawing.Point(3, 3)
        Me.dpcBlockViewAdv.Name = "dpcBlockViewAdv"
        Me.dpcBlockViewAdv.Size = New System.Drawing.Size(593, 193)
        Me.dpcBlockViewAdv.TabIndex = 34
        '
        'FilteredLocationsFrame
        '
        Me.FilteredLocationsFrame.Controls.Add(Me.FilteredLocationsListView)
        Me.FilteredLocationsFrame.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FilteredLocationsFrame.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FilteredLocationsFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FilteredLocationsFrame.Location = New System.Drawing.Point(30, 26)
        Me.FilteredLocationsFrame.Name = "FilteredLocationsFrame"
        Me.FilteredLocationsFrame.Padding = New System.Windows.Forms.Padding(6)
        Me.FilteredLocationsFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FilteredLocationsFrame.Size = New System.Drawing.Size(871, 176)
        Me.FilteredLocationsFrame.TabIndex = 8
        Me.FilteredLocationsFrame.TabStop = False
        Me.FilteredLocationsFrame.Text = "Filtered Locations"
        '
        'FilteredLocationsListView
        '
        Me.FilteredLocationsListView.BackColor = System.Drawing.SystemColors.Window
        Me.FilteredLocationsListView.Cursor = System.Windows.Forms.Cursors.Default
        Me.FilteredLocationsListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FilteredLocationsListView.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FilteredLocationsListView.ForeColor = System.Drawing.SystemColors.WindowText
        Me.FilteredLocationsListView.GridLines = True
        Me.FilteredLocationsListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.FilteredLocationsListView.LabelWrap = False
        Me.FilteredLocationsListView.Location = New System.Drawing.Point(6, 22)
        Me.FilteredLocationsListView.Name = "FilteredLocationsListView"
        Me.FilteredLocationsListView.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FilteredLocationsListView.Size = New System.Drawing.Size(859, 148)
        Me.FilteredLocationsListView.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.FilteredLocationsListView.TabIndex = 0
        Me.FilteredLocationsListView.UseCompatibleStateImageBehavior = False
        Me.FilteredLocationsListView.View = System.Windows.Forms.View.List
        '
        'pnlButtons
        '
        Me.pnlButtons.Controls.Add(Me.cmdAddToFavourites)
        Me.pnlButtons.Controls.Add(Me.cmdRemoveFromFavourites)
        Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlButtons.Location = New System.Drawing.Point(0, 26)
        Me.pnlButtons.MaximumSize = New System.Drawing.Size(30, 0)
        Me.pnlButtons.MinimumSize = New System.Drawing.Size(30, 0)
        Me.pnlButtons.Name = "pnlButtons"
        Me.pnlButtons.Size = New System.Drawing.Size(30, 176)
        Me.pnlButtons.TabIndex = 7
        '
        'cmdAddToFavourites
        '
        Me.cmdAddToFavourites.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddToFavourites.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddToFavourites.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddToFavourites.Location = New System.Drawing.Point(2, 94)
        Me.cmdAddToFavourites.Name = "cmdAddToFavourites"
        Me.cmdAddToFavourites.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddToFavourites.Size = New System.Drawing.Size(27, 36)
        Me.cmdAddToFavourites.TabIndex = 20
        Me.cmdAddToFavourites.Text = "+"
        Me.cmdAddToFavourites.UseVisualStyleBackColor = False
        '
        'cmdRemoveFromFavourites
        '
        Me.cmdRemoveFromFavourites.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveFromFavourites.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveFromFavourites.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveFromFavourites.Location = New System.Drawing.Point(2, 136)
        Me.cmdRemoveFromFavourites.Name = "cmdRemoveFromFavourites"
        Me.cmdRemoveFromFavourites.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveFromFavourites.Size = New System.Drawing.Size(27, 36)
        Me.cmdRemoveFromFavourites.TabIndex = 21
        Me.cmdRemoveFromFavourites.Text = "-"
        Me.cmdRemoveFromFavourites.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(901, 26)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Label1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'gbxInsertOnClose
        '
        Me.gbxInsertOnClose.Controls.Add(Me.gbxBlockDets)
        Me.gbxInsertOnClose.Controls.Add(Me.gbxBlockMisc)
        Me.gbxInsertOnClose.Controls.Add(Me.gbxBlockScale)
        Me.gbxInsertOnClose.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbxInsertOnClose.Location = New System.Drawing.Point(6, 0)
        Me.gbxInsertOnClose.Name = "gbxInsertOnClose"
        Me.gbxInsertOnClose.Size = New System.Drawing.Size(909, 224)
        Me.gbxInsertOnClose.TabIndex = 35
        Me.gbxInsertOnClose.TabStop = False
        Me.gbxInsertOnClose.Text = "Insert Options"
        '
        'gbxBlockDets
        '
        Me.gbxBlockDets.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxBlockDets.Controls.Add(Me.dpcBlockViewBlk)
        Me.gbxBlockDets.Controls.Add(Me.lstBlockNames)
        Me.gbxBlockDets.Location = New System.Drawing.Point(14, 20)
        Me.gbxBlockDets.Name = "gbxBlockDets"
        Me.gbxBlockDets.Size = New System.Drawing.Size(505, 199)
        Me.gbxBlockDets.TabIndex = 2
        Me.gbxBlockDets.TabStop = False
        Me.gbxBlockDets.Text = "Block Details"
        '
        'dpcBlockViewBlk
        '
        Me.dpcBlockViewBlk.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dpcBlockViewBlk.Location = New System.Drawing.Point(162, 17)
        Me.dpcBlockViewBlk.Name = "dpcBlockViewBlk"
        Me.dpcBlockViewBlk.Size = New System.Drawing.Size(338, 171)
        Me.dpcBlockViewBlk.TabIndex = 1
        Me.dpcBlockViewBlk.Text = "DwgPreviewControl1"
        '
        'lstBlockNames
        '
        Me.lstBlockNames.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lstBlockNames.FormattingEnabled = True
        Me.lstBlockNames.HorizontalScrollbar = True
        Me.lstBlockNames.Location = New System.Drawing.Point(12, 17)
        Me.lstBlockNames.Name = "lstBlockNames"
        Me.lstBlockNames.Size = New System.Drawing.Size(135, 123)
        Me.lstBlockNames.TabIndex = 0
        '
        'gbxBlockMisc
        '
        Me.gbxBlockMisc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxBlockMisc.Controls.Add(Me.chkEditAttributesOnEdit)
        Me.gbxBlockMisc.Controls.Add(Me.chkRotOnInsert)
        Me.gbxBlockMisc.Controls.Add(Me.txtRotate)
        Me.gbxBlockMisc.Controls.Add(Me.lblRotate)
        Me.gbxBlockMisc.Location = New System.Drawing.Point(714, 20)
        Me.gbxBlockMisc.Name = "gbxBlockMisc"
        Me.gbxBlockMisc.Size = New System.Drawing.Size(183, 199)
        Me.gbxBlockMisc.TabIndex = 1
        Me.gbxBlockMisc.TabStop = False
        Me.gbxBlockMisc.Text = "Misc"
        '
        'chkRotOnInsert
        '
        Me.chkRotOnInsert.AutoSize = True
        Me.chkRotOnInsert.Location = New System.Drawing.Point(14, 56)
        Me.chkRotOnInsert.Name = "chkRotOnInsert"
        Me.chkRotOnInsert.Size = New System.Drawing.Size(134, 21)
        Me.chkRotOnInsert.TabIndex = 7
        Me.chkRotOnInsert.Text = "Rotate On Insert"
        Me.chkRotOnInsert.UseVisualStyleBackColor = True
        '
        'txtRotate
        '
        Me.txtRotate.Location = New System.Drawing.Point(79, 21)
        Me.txtRotate.Name = "txtRotate"
        Me.txtRotate.Size = New System.Drawing.Size(92, 24)
        Me.txtRotate.TabIndex = 6
        Me.txtRotate.Text = "0"
        '
        'lblRotate
        '
        Me.lblRotate.AutoSize = True
        Me.lblRotate.Location = New System.Drawing.Point(11, 24)
        Me.lblRotate.Name = "lblRotate"
        Me.lblRotate.Size = New System.Drawing.Size(65, 17)
        Me.lblRotate.TabIndex = 5
        Me.lblRotate.Text = "Rotation:"
        '
        'gbxBlockScale
        '
        Me.gbxBlockScale.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbxBlockScale.Controls.Add(Me.chkInsertUseDimScale)
        Me.gbxBlockScale.Controls.Add(Me.txtScaleZ)
        Me.gbxBlockScale.Controls.Add(Me.txtScaleY)
        Me.gbxBlockScale.Controls.Add(Me.txtScaleX)
        Me.gbxBlockScale.Controls.Add(Me.lblScaleZ)
        Me.gbxBlockScale.Controls.Add(Me.lblScaleY)
        Me.gbxBlockScale.Controls.Add(Me.lblScaleX)
        Me.gbxBlockScale.Controls.Add(Me.chkUniScale)
        Me.gbxBlockScale.Location = New System.Drawing.Point(525, 20)
        Me.gbxBlockScale.Name = "gbxBlockScale"
        Me.gbxBlockScale.Size = New System.Drawing.Size(183, 199)
        Me.gbxBlockScale.TabIndex = 0
        Me.gbxBlockScale.TabStop = False
        Me.gbxBlockScale.Text = "Scale"
        '
        'chkInsertUseDimScale
        '
        Me.chkInsertUseDimScale.AutoSize = True
        Me.chkInsertUseDimScale.Location = New System.Drawing.Point(14, 120)
        Me.chkInsertUseDimScale.Name = "chkInsertUseDimScale"
        Me.chkInsertUseDimScale.Size = New System.Drawing.Size(118, 21)
        Me.chkInsertUseDimScale.TabIndex = 7
        Me.chkInsertUseDimScale.Text = "Use DimScale"
        Me.chkInsertUseDimScale.UseVisualStyleBackColor = True
        '
        'txtScaleZ
        '
        Me.txtScaleZ.Location = New System.Drawing.Point(62, 71)
        Me.txtScaleZ.Name = "txtScaleZ"
        Me.txtScaleZ.Size = New System.Drawing.Size(115, 24)
        Me.txtScaleZ.TabIndex = 6
        Me.txtScaleZ.Text = "1"
        '
        'txtScaleY
        '
        Me.txtScaleY.Location = New System.Drawing.Point(62, 45)
        Me.txtScaleY.Name = "txtScaleY"
        Me.txtScaleY.Size = New System.Drawing.Size(115, 24)
        Me.txtScaleY.TabIndex = 5
        Me.txtScaleY.Text = "1"
        '
        'txtScaleX
        '
        Me.txtScaleX.Location = New System.Drawing.Point(62, 18)
        Me.txtScaleX.Name = "txtScaleX"
        Me.txtScaleX.Size = New System.Drawing.Size(115, 24)
        Me.txtScaleX.TabIndex = 4
        Me.txtScaleX.Text = "1"
        '
        'lblScaleZ
        '
        Me.lblScaleZ.AutoSize = True
        Me.lblScaleZ.Location = New System.Drawing.Point(11, 74)
        Me.lblScaleZ.Name = "lblScaleZ"
        Me.lblScaleZ.Size = New System.Drawing.Size(56, 17)
        Me.lblScaleZ.TabIndex = 3
        Me.lblScaleZ.Text = "Scale Z:"
        '
        'lblScaleY
        '
        Me.lblScaleY.AutoSize = True
        Me.lblScaleY.Location = New System.Drawing.Point(11, 48)
        Me.lblScaleY.Name = "lblScaleY"
        Me.lblScaleY.Size = New System.Drawing.Size(56, 17)
        Me.lblScaleY.TabIndex = 2
        Me.lblScaleY.Text = "Scale Y:"
        '
        'lblScaleX
        '
        Me.lblScaleX.AutoSize = True
        Me.lblScaleX.Location = New System.Drawing.Point(11, 21)
        Me.lblScaleX.Name = "lblScaleX"
        Me.lblScaleX.Size = New System.Drawing.Size(56, 17)
        Me.lblScaleX.TabIndex = 1
        Me.lblScaleX.Text = "Scale X:"
        '
        'chkUniScale
        '
        Me.chkUniScale.AutoSize = True
        Me.chkUniScale.Location = New System.Drawing.Point(14, 98)
        Me.chkUniScale.Name = "chkUniScale"
        Me.chkUniScale.Size = New System.Drawing.Size(118, 21)
        Me.chkUniScale.TabIndex = 0
        Me.chkUniScale.Text = "Uniform Scale"
        Me.chkUniScale.UseVisualStyleBackColor = True
        '
        'pnlBanner
        '
        Me.pnlBanner.BackgroundImage = CType(resources.GetObject("pnlBanner.BackgroundImage"), System.Drawing.Image)
        Me.pnlBanner.Controls.Add(Me.lblTitle)
        Me.pnlBanner.Controls.Add(Me.LogoPictureBox)
        Me.pnlBanner.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBanner.Location = New System.Drawing.Point(0, 0)
        Me.pnlBanner.Name = "pnlBanner"
        Me.pnlBanner.Size = New System.Drawing.Size(921, 52)
        Me.pnlBanner.TabIndex = 36
        '
        'lblTitle
        '
        Me.lblTitle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(181, 35)
        Me.lblTitle.TabIndex = 29
        Me.lblTitle.Text = "Block Finder"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 28
        Me.LogoPictureBox.TabStop = False
        '
        'chkEditAttributesOnEdit
        '
        Me.chkEditAttributesOnEdit.AutoSize = True
        Me.chkEditAttributesOnEdit.Location = New System.Drawing.Point(14, 79)
        Me.chkEditAttributesOnEdit.Name = "chkEditAttributesOnEdit"
        Me.chkEditAttributesOnEdit.Size = New System.Drawing.Size(142, 17)
        Me.chkEditAttributesOnEdit.TabIndex = 8
        Me.chkEditAttributesOnEdit.Text = "Edit Attributes on Insert"
        Me.chkEditAttributesOnEdit.UseVisualStyleBackColor = True
        '
        'BlockFinderForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(921, 769)
        Me.Controls.Add(Me.spcPageLayout)
        Me.Controls.Add(Me.pnlButtonBtm)
        Me.Controls.Add(Me.pnlBanner)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(937, 807)
        Me.Name = "BlockFinderForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.pnlButtonBtm.ResumeLayout(False)
        Me.spcPageLayout.Panel1.ResumeLayout(False)
        Me.spcPageLayout.Panel2.ResumeLayout(False)
        CType(Me.spcPageLayout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.spcPageLayout.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.spcBasic.Panel1.ResumeLayout(False)
        Me.spcBasic.Panel2.ResumeLayout(False)
        CType(Me.spcBasic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.spcBasic.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.spcAdvanced.Panel1.ResumeLayout(False)
        Me.spcAdvanced.Panel2.ResumeLayout(False)
        CType(Me.spcAdvanced, System.ComponentModel.ISupportInitialize).EndInit()
        Me.spcAdvanced.ResumeLayout(False)
        Me.spcAdvancedTop.Panel1.ResumeLayout(False)
        Me.spcAdvancedTop.Panel2.ResumeLayout(False)
        CType(Me.spcAdvancedTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.spcAdvancedTop.ResumeLayout(False)
        Me.DirectSearchFrame.ResumeLayout(False)
        Me.DirectSearchFrame.PerformLayout()
        Me.FiltersFrame.ResumeLayout(False)
        Me.FiltersFrame.PerformLayout()
        Me.FilteredLocationsFrame.ResumeLayout(False)
        Me.pnlButtons.ResumeLayout(False)
        Me.gbxInsertOnClose.ResumeLayout(False)
        Me.gbxBlockDets.ResumeLayout(False)
        Me.gbxBlockMisc.ResumeLayout(False)
        Me.gbxBlockMisc.PerformLayout()
        Me.gbxBlockScale.ResumeLayout(False)
        Me.gbxBlockScale.PerformLayout()
        Me.pnlBanner.ResumeLayout(False)
        Me.pnlBanner.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlButtonBtm As System.Windows.Forms.Panel
    Public WithEvents cmdOpenDC As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Friend WithEvents spcPageLayout As System.Windows.Forms.SplitContainer
    Friend WithEvents gbxInsertOnClose As System.Windows.Forms.GroupBox
    Friend WithEvents gbxBlockDets As System.Windows.Forms.GroupBox
    Friend WithEvents dpcBlockViewBlk As DwgPreviewControl
    Friend WithEvents lstBlockNames As System.Windows.Forms.ListBox
    Friend WithEvents gbxBlockMisc As System.Windows.Forms.GroupBox
    Friend WithEvents chkRotOnInsert As System.Windows.Forms.CheckBox
    Friend WithEvents txtRotate As System.Windows.Forms.TextBox
    Friend WithEvents lblRotate As System.Windows.Forms.Label
    Friend WithEvents gbxBlockScale As System.Windows.Forms.GroupBox
    Friend WithEvents txtScaleZ As System.Windows.Forms.TextBox
    Friend WithEvents txtScaleY As System.Windows.Forms.TextBox
    Friend WithEvents txtScaleX As System.Windows.Forms.TextBox
    Friend WithEvents lblScaleZ As System.Windows.Forms.Label
    Friend WithEvents lblScaleY As System.Windows.Forms.Label
    Friend WithEvents lblScaleX As System.Windows.Forms.Label
    Friend WithEvents chkUniScale As System.Windows.Forms.CheckBox
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents spcBasic As System.Windows.Forms.SplitContainer
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents CorporateFavouriteListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnName As System.Windows.Forms.ColumnHeader
    Friend WithEvents Path As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents ConfigFavListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents UserFavListView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Public WithEvents BrowseButton As System.Windows.Forms.Button
    Friend WithEvents dpcBlockViewBasic As DwgPreviewControl
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents spcAdvanced As System.Windows.Forms.SplitContainer
    Friend WithEvents spcAdvancedTop As System.Windows.Forms.SplitContainer
    Public WithEvents DirectSearchFrame As System.Windows.Forms.GroupBox
    Public WithEvents SearchTextBox As System.Windows.Forms.TextBox
    Public WithEvents cmdClear As System.Windows.Forms.Button
    Public WithEvents FiltersFrame As System.Windows.Forms.GroupBox
    Public WithEvents BusinessUnitComboBox As System.Windows.Forms.ComboBox
    Public WithEvents BusinessUnitLabel As System.Windows.Forms.Label
    Public WithEvents DisciplineComboBox As System.Windows.Forms.ComboBox
    Public WithEvents DisciplineLabel As System.Windows.Forms.Label
    Public WithEvents RegionComboBox As System.Windows.Forms.ComboBox
    Public WithEvents RegionLabel As System.Windows.Forms.Label
    Public WithEvents TypeComboBox As System.Windows.Forms.ComboBox
    Public WithEvents TypeLabel As System.Windows.Forms.Label
    Friend WithEvents dpcBlockViewAdv As DwgPreviewControl
    Public WithEvents FilteredLocationsFrame As System.Windows.Forms.GroupBox
    Public WithEvents FilteredLocationsListView As System.Windows.Forms.ListView
    Friend WithEvents pnlButtons As System.Windows.Forms.Panel
    Public WithEvents cmdAddToFavourites As System.Windows.Forms.Button
    Public WithEvents cmdRemoveFromFavourites As System.Windows.Forms.Button
    Public WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pnlBanner As System.Windows.Forms.Panel
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents cmdInsertBlock As System.Windows.Forms.Button
    Friend WithEvents chkInsertUseDimScale As System.Windows.Forms.CheckBox
    Friend WithEvents chkEditAttributesOnEdit As System.Windows.Forms.CheckBox
#End Region
End Class