Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.ApplicationServices
Imports System.IO
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.BlockFinder.BlockFinder))> 

Public Class BlockFinder

    Private Structure BlockDetails
        Dim Name As String
        Dim ObjScale As String
        Dim AuxScale As String
        Dim Rotation As String
        Dim PromptForRotation As String
        Dim Explode As String
        Dim Color As String
        Dim Layer As String
        Dim Linetype As String
        Dim PlotStyle As String
        Dim Lineweight As String
        Dim Visibility As String
    End Structure

    ' This needs to change to read an XML file that states
    ' The name of the block, layer details and the scale desired

    Public iPrevAttReq As Integer
    Dim SelectConfig As New SelectTemplate.TemplateSelector
    ' Dim RuleAccessors As New RuleAccessors

#Region "Events"



#End Region

    ''' <summary>
    ''' Block finder command used to fire off the block finder tool
    ''' , Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_BLOCKFINDER")> _
    Public Sub BlockFinder()

        ' , Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _

        Try
            '' If the tool needs to be configured and it is not give the user the option to configure it
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                Dim SelectConfig As New SelectTemplate.TemplateSelector
                SelectConfig.DisplayWarning()
                '' If the user cancelled the select configuration process on either the warning or the selection dialogs then the drawing was not configured
                '' Check here to see if it was configured - hence the user did not cancel prematurely
                If ThisDrawingIsConfigured() = True Then
                    DisplayDialog()
                End If
            Else
                '' If the drawing is configured already or the tool does not require a configuration then fire it off
                DisplayDialog()
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub DisplayDialog()

        Try
            Dim BlockFinderForm As New BlockFinderForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(BlockFinderForm)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

End Class

