Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports System.Drawing
Imports System.IO
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings

Imports System.Collections.Generic
Imports System.ComponentModel
'Imports System.Data
Imports System.Linq
Imports System.Text

'All in the acdmgd.dll from C:\Program Files\Autocad etc
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Windows
Imports System.Drawing.Imaging
Imports Jacobs.AutoCAD.Utilities
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
'Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension

Friend Class BlockFinderForm
    Inherits System.Windows.Forms.Form

    'Dim StartDir As String = Settings.Manager.AE.BlockLibraryFolder
    Public dList As New Collection
    ' Dim RuleAccessors As New RuleAccessors
    Dim sDocumentsAndSettingsFolder As String
    Public IsInitialising As Boolean = True

    Private mSelectedFileName As String = ""
    Private mSelectedBlockName As String = ""

    Dim newImage As System.Drawing.Bitmap

#Region "Events"

    <DllImport("user32.dll")>
    Public Shared Function ShowScrollBar(ByVal hWnd As System.IntPtr, ByVal wBar As Integer, ByVal bShow As Boolean) As Boolean
    End Function
    Private Const SB_HORZ As UInteger = 0
    Private Const SB_VERT As UInteger = 1
    Private Const ESB_DISABLE_BOTH As UInteger = &H3
    Private Const ESB_ENABLE_BOTH As UInteger = &H0

    Private Sub BlockFindForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            IsInitialising = True
            initialise()

            ShowScrollBar(Me.CorporateFavouriteListView.Handle, CInt(SB_VERT), True)
            ShowScrollBar(Me.ConfigFavListView.Handle, CInt(SB_VERT), True)
            ShowScrollBar(Me.UserFavListView.Handle, CInt(SB_VERT), True)
            ShowScrollBar(Me.CorporateFavouriteListView.Handle, CInt(SB_VERT), True)
            ShowScrollBar(Me.CorporateFavouriteListView.Handle, CInt(SB_VERT), True)

            IsInitialising = False

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Public Property UpdateDialogProp(ByVal FileOrBlock As Integer) As String
        Get
            Dim Ret As String = ""
            Select Case FileOrBlock
                Case 0
                    Ret = mSelectedFileName
                Case 1
                    Ret = mSelectedBlockName
            End Select
            Return Ret
        End Get
        Set(ByVal value As String)

            Select Case FileOrBlock
                Case 0
                    mSelectedFileName = value
                    mSelectedBlockName = ""
                Case 1
                    mSelectedBlockName = value
            End Select

            ''if file has been picked
            'If mSelectedFileName <> "" Then
            '    'if a block has been selecte
            '    If mSelectedBlockName <> "" Then
            '        cmdOpenDC.Enabled = True
            '        cmdInsertBlock.Enabled = True
            '    Else
            '        cmdOpenDC.Enabled = True
            '        cmdInsertBlock.Enabled = False
            '    End If
            'Else
            '    cmdOpenDC.Enabled = False
            '    cmdInsertBlock.Enabled = False
            'End If

            cmdOpenDC.Enabled = True
            cmdInsertBlock.Enabled = True

        End Set
    End Property

    Private Sub BrowseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseButton.Click


        Try

            Dim sSelectedFile As String
            Dim strPath As String
            Dim ProdName As String = ""

            ProdName = Settings.Manager.AutoCAD.Name

            Me.Close()

            strPath = Settings.Manager.AE.NetworkConfiguration.CombinePath(ProdName, Environment.GetADSite, "BlockFinder")

            sSelectedFile = DocumentOpenSingleSelect(strPath, "Select Blockfinder Alternative Shortcuts File", "All Data Files(*.dat)|*.dat", "Select File")  ' "*.dat")

            ' Copy file
            CopyFile(sSelectedFile, ThisDrawingUtilities.GetVariable("roamablerootprefix").ToString.CombinePath("Support", Settings.Manager.AE.UserBlockFinderSettingsFileName), True)

            'Me.Show()

            ' Reload File in user area
            initialise()
            Me.Show()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub


    Private Sub cmdAddToFavourites_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddToFavourites.Click

        Try
            Dim sSelected As String = ""
            Dim MyValue As String
            Dim Title As String
            Dim Message As String
            Dim Default_Renamed As String
            Dim ColumnArray(1, 0) As Object

            ' If there is something in the list
            If FilteredLocationsListView.Items.Count >= 1 Then

                ' scroll thru all the selected items
                For Each item As ListViewItem In FilteredLocationsListView.SelectedItems

                    Message = "Enter a short descriptive name for this shortcut."
                    Title = "Favourite Short Name"

                    sSelected = item.SubItems(0).Text

                    Default_Renamed = Split(Split(sSelected, "\")(UBound(Split(sSelected, "\"))), ".")(0)
                    MyValue = InputBox(Message, Title, Default_Renamed)

                    If MyValue <> "" Then

                        ColumnArray(0, 0) = MyValue
                        ColumnArray(1, 0) = sSelected

                        Dim lvi As ListViewItem = UserFavListView.Items.Add(MyValue)
                        lvi.SubItems.Add(sSelected)

                    End If
                Next

            End If

            If sSelected = "" Then

                Acad_MessageBox("You must select a Filtered Location item before you can add it to the favourites.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

            Else
                SaveSettingsForNextTime()
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub cmdClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClear.Click

        Try
            BusinessUnitComboBox.Enabled = True
            DisciplineComboBox.Enabled = True
            RegionComboBox.Enabled = True

            BusinessUnitComboBox.Text = String.Empty
            DisciplineComboBox.Text = String.Empty
            RegionComboBox.Text = String.Empty

            SearchTextBox.Text = ""

            BuildFilter()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub cmdRemoveFromFavourites_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRemoveFromFavourites.Click

        Try
            If UserFavListView.Items.Count >= 1 Then
                UserFavListView.Items.Remove(UserFavListView.SelectedItems(0))
            End If
            SaveSettingsForNextTime()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub FilteredLocationsListView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilteredLocationsListView.SelectedIndexChanged


        Try

            If IsInitialising Then Exit Sub
            Dim SelectedItem As System.Windows.Forms.ListViewItem
            Dim sSelected As String = String.Empty

            CorporateFavouriteListView.SelectedItems.Clear()

            ' If there is something in the list
            If FilteredLocationsListView.Items.Count >= 1 Then

                For Each SelectedItem In FilteredLocationsListView.SelectedItems
                    ' get the dwgname and path
                    sSelected = SelectedItem.Text
                    'sSelected = SelectedItem.SubItems.Item(0).Text
                Next

            End If

            If System.IO.File.Exists(sSelected) Then

                UpdateDialogProp(0) = sSelected

                InitaliseDwgViewControl(dpcBlockViewAdv, UpdateDialogProp(0), False, False)

                GetBlockNamesFromFile(sSelected, lstBlockNames)

                If Not dpcBlockViewBlk.mpView Is Nothing Then
                    ' clear the preview control
                    dpcBlockViewBlk.mpView.EraseAll()
                    refreshViewInsert()
                    cmdInsertBlock.Enabled = True
                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    'Private Sub pictureBoxall_Click(ByVal sender As Object, ByVal e As EventArgs)
    '    Me.OnClick(e)
    'End Sub

    Private Sub BusinessUnitComboBox_SelectedValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BusinessUnitComboBox.SelectedValueChanged

        Try
            If IsInitialising Then Exit Sub

            DisciplineComboBox.Items.Clear()
            DisciplineComboBox.Text = String.Empty

            RegionComboBox.Items.Clear()
            RegionComboBox.Text = String.Empty

            If BusinessUnitComboBox.Text <> "*" Then
                ListFilesInFolder(Settings.Manager.AE.BlockLibraryFolder.CombinePath(BusinessUnitComboBox.Text), True, DisciplineComboBox)
            End If
            BuildFilter()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub DisciplineComboBox_SelectedValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisciplineComboBox.SelectedValueChanged

        Try
            If IsInitialising Then Exit Sub

            RegionComboBox.Items.Clear()
            RegionComboBox.Text = String.Empty

            If DisciplineComboBox.Text <> "*" Then
                ListFilesInFolder(Settings.Manager.AE.BlockLibraryFolder.CombinePath(BusinessUnitComboBox.Text, DisciplineComboBox.Text), True, RegionComboBox)
            End If
            BuildFilter()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub RegionComboBox_SelectedValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegionComboBox.SelectedValueChanged

        Try
            If IsInitialising Then Exit Sub
            BuildFilter()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    'Private Sub FavouriteListBox_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) 'Handles FavouriteListBox.DoubleClick

    '    Try
    '        OK_Button_Click(OK_Button, New System.EventArgs())
    '    Catch ex As Exception
    '        ExceptionMessageDisplay(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try
    'End Sub

    Private Sub ConfigFavListvIEW_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConfigFavListView.DoubleClick

        Try
            cmdOpenDC_Click(cmdOpenDC, New System.EventArgs())
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub UserFavListView_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserFavListView.DoubleClick

        Try
            cmdOpenDC_Click(cmdOpenDC, New System.EventArgs())
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub FilteredLocationsListView_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilteredLocationsListView.DoubleClick

        Try
            cmdOpenDC_Click(cmdOpenDC, New System.EventArgs())
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub BlockFindForm_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Cursor = Cursors.Default
        e.Cancel = True
        Me.Visible = False
        dpcBlockViewBasic.Dispose()
        dpcBlockViewAdv.Dispose()
        dpcBlockViewBlk.Dispose()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        Try
            Me.Hide()
            dpcBlockViewBasic.Dispose()
            dpcBlockViewAdv.Dispose()
            dpcBlockViewBlk.Dispose()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub cmdOpenDC_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOpenDC.Click

        Try

            Dim sSelected As String = ""
            Dim i As Integer
            Dim SelectedItem As System.Windows.Forms.ListViewItem

            ' If there is something in the list
            If FilteredLocationsListView.Items.Count >= 1 Then
                ' If there is something selected in the list
                For Each SelectedItem In FilteredLocationsListView.SelectedItems
                    ' get the dwgname and path
                    sSelected = SelectedItem.Text
                Next
            End If

            If CorporateFavouriteListView.Items.Count >= 1 Then ' If there is something in the list
                For Each SelectedItem In CorporateFavouriteListView.SelectedItems
                    sSelected = SelectedItem.SubItems.Item(1).Text
                Next
            End If

            ' If there is something in the list
            If ConfigFavListView.Items.Count >= 1 Then
                ' If there is something selected in the list
                For i = 0 To ConfigFavListView.Items.Count - 1
                    For Each SelectedItem In ConfigFavListView.SelectedItems
                        sSelected = SelectedItem.SubItems.Item(1).Text
                    Next

                Next
            End If

            If UserFavListView.Items.Count >= 1 Then ' If there is something in the list
                For i = 0 To UserFavListView.Items.Count - 1 ' If there is something selected in the list
                    For Each SelectedItem In UserFavListView.SelectedItems
                        sSelected = SelectedItem.SubItems.Item(1).Text
                    Next
                Next
            End If

            If sSelected = "" Then

                Acad_MessageBox("You must select an item either from either ot the [Favourites] list boxes or the [Filtered Locations] list box.",
                                 System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)

                Exit Sub
            End If

            SaveSettingsForNextTime()

            If UCase(sSelected) Like "*.DWG" Then
                sSelected = sSelected & "/BLOCKS"
            End If

            dpcBlockViewBasic.Dispose()
            dpcBlockViewAdv.Dispose()
            dpcBlockViewBlk.Dispose()

            Me.Cursor = Cursors.Default

            Me.Hide()
            Me.Close()

            If Len(sSelected & "/BLOCKS") > 132 Then

                Acad_MessageBox("The selected item has a path that is too long to naviage via ADCNAVIGATE command. Maximum lenght including file name is 125 characters" & vbCrLf &
                                "The Block Finder will get as close as possible to the file but you will need to navigate the rest of the way manually" & vbCrLf &
                                "Contact CAD Support to shorten the path to this block in future releases" & vbCrLf & FilteredLocationsListView.Text,
                                 System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)

            End If

            If CInt(ThisDrawingUtilities.GetVariable("ADCSTATE")) <> 1 Then
                ThisDrawingUtilities.SendCommand("'_ADCENTER" & vbCr)
                ThisDrawingUtilities.SendCommand("_.adcnavigate " & sSelected & vbCr)
            Else
                ThisDrawingUtilities.SendCommand("_.adcnavigate " & sSelected & vbCr)
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try


    End Sub

    Private Sub cmdInsertBlock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInsertBlock.Click

        Try

            Dim sSelected As String = ""
            Dim i As Integer
            Dim SelectedItem As System.Windows.Forms.ListViewItem

            ' If there is something in the list
            If FilteredLocationsListView.Items.Count >= 1 Then
                ' If there is something selected in the list
                For Each SelectedItem In FilteredLocationsListView.SelectedItems
                    ' get the dwgname and path
                    sSelected = SelectedItem.Text
                Next
            End If

            If CorporateFavouriteListView.Items.Count >= 1 Then ' If there is something in the list
                For Each SelectedItem In CorporateFavouriteListView.SelectedItems
                    sSelected = SelectedItem.SubItems.Item(1).Text
                Next
            End If

            ' If there is something in the list
            If ConfigFavListView.Items.Count >= 1 Then
                ' If there is something selected in the list
                For i = 0 To ConfigFavListView.Items.Count - 1
                    For Each SelectedItem In ConfigFavListView.SelectedItems
                        sSelected = SelectedItem.SubItems.Item(1).Text
                    Next
                Next
            End If

            If UserFavListView.Items.Count >= 1 Then ' If there is something in the list
                For i = 0 To UserFavListView.Items.Count - 1 ' If there is something selected in the list
                    For Each SelectedItem In UserFavListView.SelectedItems
                        sSelected = SelectedItem.SubItems.Item(1).Text
                    Next
                Next
            End If

            If sSelected = "" Then

                Acad_MessageBox("You must select an item either from either ot the [Favourites] list boxes or the [Filtered Locations] list box.",
                                 System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name,
                                MessageBoxButtons.OK, MessageBoxIcon.Information)

                Exit Sub
            End If

            SaveSettingsForNextTime()

            If UCase(sSelected) Like "*.DWG" Then
                sSelected = sSelected & "/BLOCKS"
            End If

            dpcBlockViewBasic.Dispose()
            dpcBlockViewAdv.Dispose()
            dpcBlockViewBlk.Dispose()

            Me.Cursor = Cursors.Default

            Me.Hide()
            'Me.Close()

            InsertBlockFromDialog()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub InsertBlockFromDialog()

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim Ed As Editor = Doc.Editor
        Dim InsertPoint As Point3d, SecondPoint As Point3d
        Dim Length As Double = 0
        Dim ExtraRotation As Double = 0
        Dim RotBool As Boolean = Double.TryParse(txtRotate.Text, ExtraRotation)

        Dim PickPointRes As PromptPointResult = Ed.GetPoint("Pick Insert Point:")
        If PickPointRes.Status = PromptStatus.OK Then

            'Returned Point
            InsertPoint = PickPointRes.Value

            Dim BlockNameX As String = ""

            If mSelectedBlockName = "" Or lstBlockNames.Items.Count = 0 Then
                BlockNameX = mSelectedFileName
            Else
                BlockNameX = mSelectedBlockName 'lstBlockNames.SelectedItem.ToString
            End If

            Dim Space As Boolean = False

            Select Case WhichSpace()
                Case "ModelSpace", "FloatingModelSpace"
                    Space = True
                Case "PaperSpace"
                    Space = False
            End Select

            Dim XS As Double = Double.Parse(txtScaleX.Text)
            Dim YS As Double = Double.Parse(txtScaleY.Text)
            Dim ZS As Double = Double.Parse(txtScaleZ.Text)

            Dim BlockInserter As New clsDynamicBlockMod(InsertPoint,
                                            mSelectedFileName,
                                            BlockNameX,
                                            ExtraRotation,
                                            XS,
                                            YS,
                                            ZS,
                                            Space, "0")

            If chkRotOnInsert.CheckState = CheckState.Checked Then

                'Reset Rotation as the Second Point will determine the rotation
                BlockInserter.Rotation = 0

                Dim SecondPointOptions As PromptPointOptions
                SecondPointOptions = New PromptPointOptions("Pick Rotation:")
                SecondPointOptions.UseBasePoint = True
                SecondPointOptions.BasePoint = InsertPoint
                PickPointRes = Ed.GetPoint(SecondPointOptions)
                If PickPointRes.Status = PromptStatus.OK Then
                    SecondPoint = PickPointRes.Value
                    BlockInserter.InsPt2 = SecondPoint
                End If

            End If

            Dim BlockID As ObjectId = BlockInserter.InsertBlock()

            If chkEditAttributesOnEdit.Checked Then

                Dim BlkHandSC As String = "(handent """ & BlockID.Handle.ToString & """)"

                Dim AcadDoc As AcadDocument = CType(Doc.GetAcadDocument, AcadDocument)
                'AcadDoc.SendCommand("_ATTEDIT" & vbCr & BlkHandSC & vbCr)
                ThisDrawingUtilities.SendCommand("_ATTEDIT" & vbCr & BlkHandSC & vbCr)
            End If

            BlockInserter = Nothing

            mSelectedBlockName = ""
            mSelectedFileName = ""
        End If

    End Sub



    Private Sub GetBlockNamesFromFile(ByVal FileName As String, ByVal BlkLstBox As ListBox)

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim Ed As Editor = Doc.Editor

        ' create a new database
        Dim dwgs As Database = New Database(False, True)

        ' now read it in
        dwgs.ReadDwgFile(FileName, FileOpenMode.OpenForReadAndReadShare, True, "")

        BlkLstBox.Items.Clear()

        Using Doc.LockDocument

            Using trans As Transaction = dwgs.TransactionManager.StartTransaction

                Dim bt As BlockTable = CType(trans.GetObject(dwgs.BlockTableId, OpenMode.ForRead, False), BlockTable)

                For Each OID As ObjectId In bt

                    Dim btr As BlockTableRecord = CType(trans.GetObject(OID, OpenMode.ForRead, False), BlockTableRecord)

                    If btr.IsErased = False AndAlso btr.IsAnonymous = False Then

                        If Not btr.Name.ToString.StartsWith("*") Then
                            BlkLstBox.Items.Add(btr.Name.ToString)
                        End If

                    End If

                Next

                trans.Commit()

            End Using

        End Using

    End Sub

#Region "Preview Methods"

    Public Shared ReadOnly Property IsDesignMode() As Boolean
        Get
            Return DwgPreviewControl.IsDesignMode
        End Get
    End Property

    '' pass a view style you want, the gs view will update to it
    'Public Sub ChangeViewStyleTo(vs As VisualStyleType)
    '    Dim oldVs As VisualStyle = dpcBlockView.mpView.VisualStyle
    '    dpcBlockView.mpView.VisualStyle = New VisualStyle(vs)
    '    If oldVs IsNot Nothing Then
    '        oldVs.Dispose()
    '    End If
    '    refreshView()
    'End Sub

    'Private Sub ViewStyleMenuItemClick(sender As Object, e As EventArgs)
    '    Dim item As EnumToolStripMenuItem = TryCast(sender, EnumToolStripMenuItem)
    '    If item IsNot Nothing AndAlso TypeOf item.Value Is VisualStyleType Then
    '        ChangeViewStyleTo(DirectCast(item.Value, VisualStyleType))
    '    End If
    'End Sub

    '' initializes the GsPreViewCtrl
    'Public Sub InitDrawingControl(doc As Document, db As Database, ByVal BlockName As String)

    '    ' initialize the control
    '    dpcBlockViewBasic.Init(doc, db)

    '    ' now find out what the current view is and set the GsPreviewCtrl to the same
    '    SetViewToBlock(dpcBlockViewBasic.mpView, BlockName, db)

    '    Using doc.LockDocument

    '        Using trans As Transaction = db.TransactionManager.StartTransaction

    '            Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead, False), BlockTable)
    '            'Dim Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)

    '            ' now add the current space to the GsView
    '            Using Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)
    '                dpcBlockViewBasic.mpView.Add(Spacebtr, dpcBlockViewBasic.mpModel)
    '            End Using

    '        End Using

    '    End Using

    '    refreshView()

    '    '' set the view style to basic
    '    'ChangeViewStyleTo(VisualStyleType.Basic)

    '    '' set the render mode to basic
    '    'ChangeRenderModeTo(Autodesk.AutoCAD.GraphicsSystem.RenderMode.Wireframe)

    'End Sub

    'Public Sub InitDrawingControlInsert(doc As Document, db As Database, ByVal BlockName As String)

    '    ' initialize the control
    '    dpcBlockViewBlk.Init(doc, db)

    '    ' now find out what the current view is and set the GsPreviewCtrl to the same
    '    SetViewToBlock(dpcBlockViewBlk.mpView, BlockName, db)

    '    Using doc.LockDocument

    '        Using trans As Transaction = db.TransactionManager.StartTransaction

    '            Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead, False), BlockTable)
    '            'Dim Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)

    '            ' now add the current space to the GsView
    '            Using Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)
    '                dpcBlockViewBlk.mpView.Add(Spacebtr, dpcBlockViewBlk.mpModel)
    '            End Using

    '        End Using

    '    End Using

    '    refreshView()

    '    '' set the view style to basic
    '    'ChangeViewStyleTo(VisualStyleType.Basic)

    '    '' set the render mode to basic
    '    'ChangeRenderModeTo(Autodesk.AutoCAD.GraphicsSystem.RenderMode.Wireframe)

    'End Sub

    'Public Sub InitDrawingControl(doc As Document, db As Database)

    '    ' initialize the control
    '    dpcBlockViewBasic.Init(doc, db)

    '    dpcBlockViewBasic.mbOrbiting = False

    '    ' now find out what the current view is and set the GsPreviewCtrl to the same
    '    SetViewTo(dpcBlockViewBasic.mpView, db)

    '    Using doc.LockDocument

    '        Using trans As Transaction = db.TransactionManager.StartTransaction

    '            Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead, False), BlockTable)
    '            'Dim Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)

    '            ' now add the current space to the GsView
    '            Using Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)
    '                dpcBlockViewBasic.mpView.Add(Spacebtr, dpcBlockViewBasic.mpModel)
    '                dpcBlockViewBasic.mpView.Zoom(0.9)
    '            End Using

    '        End Using

    '    End Using

    '    refreshView()

    '    '' set the view style to basic
    '    'ChangeViewStyleTo(VisualStyleType.Basic)

    '    '' set the render mode to basic
    '    'ChangeRenderModeTo(Autodesk.AutoCAD.GraphicsSystem.RenderMode.Wireframe)

    'End Sub

    'Public Sub InitDrawingControlAdv(doc As Document, db As Database)

    '    ' initialize the control
    '    dpcBlockViewAdv.Init(doc, db)

    '    dpcBlockViewAdv.mbOrbiting = False

    '    ' now find out what the current view is and set the GsPreviewCtrl to the same
    '    SetViewToAdv(dpcBlockViewAdv.mpView, db)

    '    '' now add the current space to the GsView
    '    'Using curSpace As Autodesk.AutoCAD.DatabaseServices.BlockTableRecord = TryCast(db.CurrentSpaceId.Open(OpenMode.ForRead, True, True), BlockTableRecord)
    '    '    dpcBlockFinderView.mpView.Add(curSpace, dpcBlockFinderView.mpModel)
    '    'End Using

    '    Using doc.LockDocument

    '        Using trans As Transaction = db.TransactionManager.StartTransaction

    '            Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead, False), BlockTable)
    '            'Dim Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)

    '            ' now add the current space to the GsView
    '            Using Spacebtr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForRead), BlockTableRecord)
    '                dpcBlockViewAdv.mpView.Add(Spacebtr, dpcBlockViewAdv.mpModel)
    '                dpcBlockViewAdv.mpView.Zoom(0.9)
    '            End Using

    '        End Using

    '    End Using

    '    refreshViewAdv()

    '    '' set the view style to basic
    '    'ChangeViewStyleTo(VisualStyleType.Basic)

    '    '' set the render mode to basic
    '    'ChangeRenderModeTo(Autodesk.AutoCAD.GraphicsSystem.RenderMode.Wireframe)

    'End Sub

    Protected Overrides Sub OnMouseWheel(ByVal e As MouseEventArgs)
        MyBase.OnMouseWheel(e)
        If Not IsDesignMode Then

            Dim AlreadyDone As Boolean = False
            If Not dpcBlockViewBasic Is Nothing Then
                ' if we are wheeling down
                If e.Delta < 0 Then
                    dpcBlockViewBasic.mpView.Zoom(0.5)
                Else
                    ' wheel up!
                    dpcBlockViewBasic.mpView.Zoom(1.5)
                End If

                refreshViewBasic()
                AlreadyDone = True
            End If

            If Not dpcBlockViewAdv Is Nothing AndAlso AlreadyDone = False Then
                ' if we are wheeling down
                If e.Delta < 0 Then
                    dpcBlockViewAdv.mpView.Zoom(0.5)
                Else
                    ' wheel up!
                    dpcBlockViewAdv.mpView.Zoom(1.5)
                End If

                refreshViewAdv()
            End If

        End If
    End Sub

    ' sets a GsView to the active viewport data held by the database
    Public Sub SetViewTo(ByVal view As Autodesk.AutoCAD.GraphicsSystem.View, ByVal db As Database)

        ' just check we have valid extents
        If db.Extmax.X < db.Extmin.X OrElse db.Extmax.Y < db.Extmin.Y OrElse db.Extmax.Z < db.Extmax.Z Then
            db.Extmin = New Point3d(0, 0, 0)
            db.Extmax = New Point3d(400, 400, 400)
        End If

        ' get the dwg extents
        Dim extMax As Point3d = db.Extmax
        Dim extMin As Point3d = db.Extmin

        ' now the active viewport info
        Dim height As Double = 0.0, width As Double = 0.0, viewTwist As Double = 0.0
        Dim targetView As New Point3d()
        Dim viewDir As New Vector3d()

        GSUtil.GetActiveViewPortInfo(height, width, targetView, viewDir, viewTwist, True)

        ' from the data returned let's work out the viewmatrix
        viewDir = viewDir.GetNormal()
        Dim viewXDir As Vector3d = viewDir.GetPerpendicularVector().GetNormal()
        viewXDir = viewXDir.RotateBy(viewTwist, -viewDir)
        Dim viewYDir As Vector3d = viewDir.CrossProduct(viewXDir)
        Dim boxCenter As Point3d = extMin + 0.5 * (extMax - extMin)

        Dim viewMat As Matrix3d
        viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis, boxCenter, viewXDir,
         viewYDir, viewDir).Inverse()

        Dim wcsExtents As New Extents3d(extMin, extMax)
        Dim viewExtents As Extents3d = wcsExtents
        viewExtents.TransformBy(viewMat)

        Dim xMax As Double = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X)
        Dim yMax As Double = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y)
        Dim eye As Point3d = boxCenter + viewDir

        ' finally set the Gs view to the dwg view
        view.SetView(eye, boxCenter, viewYDir, xMax, yMax)

        ' now update
        refreshViewBasic()

    End Sub

    ' sets a GsView to the active viewport data held by the database
    Public Sub SetViewToAdv(ByVal view As Autodesk.AutoCAD.GraphicsSystem.View, ByVal db As Database)

        ' just check we have valid extents
        If db.Extmax.X < db.Extmin.X OrElse db.Extmax.Y < db.Extmin.Y OrElse db.Extmax.Z < db.Extmax.Z Then
            db.Extmin = New Point3d(0, 0, 0)
            db.Extmax = New Point3d(400, 400, 400)
        End If

        ' get the dwg extents
        Dim extMax As Point3d = db.Extmax
        Dim extMin As Point3d = db.Extmin

        ' now the active viewport info
        Dim height As Double = 0.0, width As Double = 0.0, viewTwist As Double = 0.0
        Dim targetView As New Point3d()
        Dim viewDir As New Vector3d()

        GSUtil.GetActiveViewPortInfo(height, width, targetView, viewDir, viewTwist, True)

        ' from the data returned let's work out the viewmatrix
        viewDir = viewDir.GetNormal()
        Dim viewXDir As Vector3d = viewDir.GetPerpendicularVector().GetNormal()
        viewXDir = viewXDir.RotateBy(viewTwist, -viewDir)
        Dim viewYDir As Vector3d = viewDir.CrossProduct(viewXDir)
        Dim boxCenter As Point3d = extMin + 0.5 * (extMax - extMin)

        Dim viewMat As Matrix3d
        viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis, boxCenter, viewXDir,
         viewYDir, viewDir).Inverse()

        Dim wcsExtents As New Extents3d(extMin, extMax)
        Dim viewExtents As Extents3d = wcsExtents
        viewExtents.TransformBy(viewMat)

        Dim xMax As Double = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X)
        Dim yMax As Double = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y)
        Dim eye As Point3d = boxCenter + viewDir

        ' finally set the Gs view to the dwg view
        view.SetView(eye, boxCenter, viewYDir, xMax, yMax)

        ' now update
        refreshViewAdv()

    End Sub

    ' sets a GsView to the active viewport data held by the database
    Public Sub SetViewToBlock(ByVal view As Autodesk.AutoCAD.GraphicsSystem.View, ByVal Blockname As String, ByVal db As Database)
        '' just check we have valid extents
        'If db.Extmax.X < db.Extmin.X OrElse db.Extmax.Y < db.Extmin.Y OrElse db.Extmax.Z < db.Extmax.Z Then
        '    db.Extmin = New Point3d(0, 0, 0)
        '    db.Extmax = New Point3d(400, 400, 400)
        'End If

        Dim Trx As Transaction = db.TransactionManager.StartTransaction

        Dim myBT As BlockTable
        Dim myBTR As BlockTableRecord = Nothing
        Dim wcsExtents As New Extents3d

        myBT = CType(Trx.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

        If myBT.Has(Blockname) Then

            myBTR = TryCast(Trx.GetObject(myBT(Blockname), OpenMode.ForRead, False), BlockTableRecord)

            Dim Col As ObjectIdCollection = myBTR.GetBlockReferenceIds(True, False)
            If Col.Count > 0 Then
                Dim Bref As BlockReference = TryCast(Trx.GetObject(Col.Item(0), OpenMode.ForRead), BlockReference)
                wcsExtents = Bref.GeometricExtents
            End If

        End If

        Trx.Commit()

        ' get the dwg extents
        Dim extMax As Point3d = wcsExtents.MaxPoint
        Dim extMin As Point3d = wcsExtents.MinPoint

        ' now the active viewport info
        Dim height As Double = 0.0, width As Double = 0.0, viewTwist As Double = 0.0
        Dim targetView As New Point3d()
        Dim viewDir As New Vector3d()
        GSUtil.GetActiveViewPortInfo(height, width, targetView, viewDir, viewTwist, True)

        ' from the data returned let's work out the viewmatrix
        viewDir = viewDir.GetNormal()
        Dim viewXDir As Vector3d = viewDir.GetPerpendicularVector().GetNormal()
        viewXDir = viewXDir.RotateBy(viewTwist, -viewDir)
        Dim viewYDir As Vector3d = viewDir.CrossProduct(viewXDir)
        Dim boxCenter As Point3d = extMin + 0.5 * (extMax - extMin)
        Dim viewMat As Matrix3d
        viewMat = Matrix3d.AlignCoordinateSystem(boxCenter, Vector3d.XAxis, Vector3d.YAxis, Vector3d.ZAxis, boxCenter, viewXDir,
         viewYDir, viewDir).Inverse()

        'Dim wcsExtents As New Extents3d(extMin, extMax)
        'Dim viewExtents As Extents3d = wcsExtents
        'viewExtents.TransformBy(viewMat)

        Dim viewExtents As Extents3d = wcsExtents
        viewExtents.TransformBy(viewMat)
        Dim xMax As Double = System.Math.Abs(viewExtents.MaxPoint.X - viewExtents.MinPoint.X)
        Dim yMax As Double = System.Math.Abs(viewExtents.MaxPoint.Y - viewExtents.MinPoint.Y)
        Dim eye As Point3d = boxCenter + viewDir
        ' finally set the Gs view to the dwg view
        view.SetView(eye, boxCenter, viewYDir, xMax, yMax)

        ' now update
        refreshViewInsert()
    End Sub

    Public Sub refreshViewBasic()
        If Not IsDesignMode Then
            'dpcBlockViewBasic.mbOrbiting = False
            dpcBlockViewBasic.mpView.Invalidate()
            dpcBlockViewBasic.mpView.Update()
            'dpcBlockViewBasic.mbOrbiting = False
        End If
    End Sub

    Public Sub refreshViewInsert()
        If Not IsDesignMode Then
            'dpcBlockViewBlk.mbOrbiting = False
            dpcBlockViewBlk.mpView.Invalidate()
            dpcBlockViewBlk.mpView.Update()
            'dpcBlockViewBlk.mbOrbiting = False
        End If
    End Sub

    Public Sub refreshViewAdv()
        If Not IsDesignMode Then
            'dpcBlockViewAdv.mbOrbiting = False
            dpcBlockViewAdv.mpView.Invalidate()
            dpcBlockViewAdv.mpView.Update()
            'dpcBlockViewAdv.mbOrbiting = False
        End If
    End Sub

#End Region

    Private Sub UserFavListView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UserFavListView.SelectedIndexChanged

        Try
            Dim sSelected As String = String.Empty
            Dim SelectedItem As System.Windows.Forms.ListViewItem

            FilteredLocationsListView.SelectedItems.Clear()
            ConfigFavListView.SelectedItems.Clear()
            'FavouriteListView.SelectedItems.Clear()

            ' If there is something in the list
            If UserFavListView.Items.Count >= 1 Then
                For Each SelectedItem In UserFavListView.SelectedItems
                    ' get the dwgname and path
                    sSelected = SelectedItem.SubItems.Item(1).Text
                Next
            End If

            ''Me.dwgPickBox.Visible = False
            If System.IO.File.Exists(sSelected) Then



                UpdateDialogProp(0) = sSelected

                Me.Cursor = Cursors.WaitCursor

                InitaliseDwgViewControl(dpcBlockViewBasic, sSelected, False, False)

                GetBlockNamesFromFile(sSelected, lstBlockNames)

                If Not dpcBlockViewBlk.mpView Is Nothing Then
                    ' clear the preview control
                    dpcBlockViewBlk.mpView.EraseAll()
                    refreshViewInsert()
                    cmdInsertBlock.Enabled = True
                End If

                Me.Cursor = Cursors.Default

            End If


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub ConfigFavListView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConfigFavListView.SelectedIndexChanged


        Try
            Dim sSelected As String = String.Empty
            Dim SelectedItem As System.Windows.Forms.ListViewItem

            FilteredLocationsListView.SelectedItems.Clear()
            UserFavListView.SelectedItems.Clear()
            CorporateFavouriteListView.SelectedItems.Clear()

            ' If there is something in the list
            If ConfigFavListView.Items.Count >= 1 Then

                For Each SelectedItem In ConfigFavListView.SelectedItems
                    ' Just get dwgname in this case as the pathto the config is already in the Support search path
                    ' sSelected = System.IO.Path.GetFileName(SelectedItem.SubItems.Item(1).Text)
                    sSelected = SelectedItem.SubItems.Item(1).Text
                Next
            End If

            If System.IO.File.Exists(sSelected) Then


                UpdateDialogProp(0) = sSelected

                Me.Cursor = Cursors.WaitCursor

                InitaliseDwgViewControl(dpcBlockViewBasic, sSelected, False, False)

                GetBlockNamesFromFile(sSelected, lstBlockNames)

                If Not dpcBlockViewBlk.mpView Is Nothing Then
                    ' clear the preview control
                    dpcBlockViewBlk.mpView.EraseAll()
                    refreshViewInsert()
                    cmdInsertBlock.Enabled = True
                End If

                Me.Cursor = Cursors.Default

            End If


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub SearchTextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchTextBox.TextChanged

        Try
            If IsInitialising Then Exit Sub
            If SearchTextBox.Text <> "" Then

                BusinessUnitComboBox.Enabled = False
                DisciplineComboBox.Enabled = False
                RegionComboBox.Enabled = False

                PopulatePossibleLocations(("*" & SearchTextBox.Text & "*"))

            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

#End Region

    Public Sub initialise()

        Try
            Dim sLastUsedSettingsFile As String

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            GetConfigSettings()

            'If System.IO.Directory.Exists(Settings.Manager.AE.BlockLibraryFolder.CombinePath("Enterprise")) Then
            '    StartDir = Settings.Manager.AE.BlockLibraryFolder.CombinePath("Enterprise")
            'Else
            '    If System.IO.Directory.Exists(Settings.Manager.AE.BlockLibraryFolder.CombinePath("Jacobs")) Then
            '        StartDir = Settings.Manager.AE.BlockLibraryFolder.CombinePath("Jacobs")
            '    Else
            '        StartDir = Settings.Manager.AE.BlockLibraryFolder.CombinePath("SKM")
            '    End If
            'End If

            ' Populates dlist which is a list of all files and folders in the start directory
            FirstTimeListFilesInFolder(Settings.Manager.AE.BlockLibraryFolder)

            'New code
            CorporateFavouriteListView.Items.Clear()
            ConfigFavListView.Items.Clear()
            UserFavListView.Items.Clear()


            ListFilesInFolder(Settings.Manager.AE.BlockLibraryFolder, True, BusinessUnitComboBox)

            BuildFilter()

            ' User
            'sLastUsedSettingsFile = ThisDrawing.GetVariable("roamablerootprefix").tostring & "Support\" & "BlockFinder.dat"
            sLastUsedSettingsFile = Settings.Manager.AE.UserBlockFinderSettingsFileName
            Dim ColumnArray As Object
            Dim ArrSize As Integer
            If System.IO.File.Exists(sLastUsedSettingsFile) Then
                ' Reads the USERS BlockFinder.dat file on the machine if present
                RestorePreviousSettings(sLastUsedSettingsFile)
            Else
                ReDim ColumnArray(1, ArrSize)
                BuildFilter()
            End If

            '' Corporate
            'If System.IO.Directory.Exists(Settings.Manager.AE.LibraryFolder.CombinePath("ENTERPRISE")) Then
            '    sLastUsedSettingsFile = Settings.Manager.AE.BlockLibraryFolder.CombinePath("Enterprise", Settings.Manager.AE.UserBlockFinderSettingsFileName)
            'Else
            '    If System.IO.Directory.Exists(Settings.Manager.AE.LibraryFolder.CombinePath("Jacobs")) Then
            '        sLastUsedSettingsFile = Settings.Manager.AE.BlockLibraryFolder.CombinePath("Jacobs", Settings.Manager.AE.UserBlockFinderSettingsFileName)
            '    Else
            '        sLastUsedSettingsFile = Settings.Manager.AE.BlockLibraryFolder.CombinePath("SKM", Settings.Manager.AE.UserBlockFinderSettingsFileName)
            '    End If
            'End If

            sLastUsedSettingsFile = Settings.Manager.AE.BlockLibraryFolder.CombinePath("General", "Symbols", Settings.Manager.AE.UserBlockFinderSettingsFileName)

            If System.IO.File.Exists(sLastUsedSettingsFile) Then
                ' Reads the file on the machine if present
                GetConfigFavourites(sLastUsedSettingsFile, CorporateFavouriteListView, False)
            End If

            ' Config
            If IsThisAnOldConfigName() = True Then
                If RuleAccessors.GetruleValue("TESTCONFIG", "False", True, False).IsTrue Then
                    sLastUsedSettingsFile = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath("T@" & RuleAccessors.GetruleValue("FULLCONFIGNAME"), "Support", Settings.Manager.AE.UserBlockFinderSettingsFileName)
                Else
                    sLastUsedSettingsFile = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(RuleAccessors.GetruleValue("FULLCONFIGNAME"), "Support", Settings.Manager.AE.UserBlockFinderSettingsFileName)
                End If
            Else
                sLastUsedSettingsFile = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(RuleAccessors.GetruleValue("FullConfigName"), "Support", Settings.Manager.AE.UserBlockFinderSettingsFileName)
            End If

            If System.IO.File.Exists(sLastUsedSettingsFile) Then
                ' Reads the file on the machine if present
                GetConfigFavourites(sLastUsedSettingsFile, ConfigFavListView, False)
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub CopyFile(ByRef sSource As String, ByRef sPathTarget As String, ByRef Overwrite As Boolean)

        Try
            If System.IO.File.Exists(sSource) Then
                My.Computer.FileSystem.CopyFile(sSource, sPathTarget, Overwrite)
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub BuildFilter()

        Try
            Dim sFilter As String
            Dim BusinessUnitValue As String
            Dim DisciplineValue As String
            Dim RegionValue As String

            'Me.PictureBoxAll.Visible = False
            'Me.dwgPickBox.Visible = False

            If BusinessUnitComboBox.Text = "" Then
                BusinessUnitValue = "*"
            Else
                BusinessUnitValue = BusinessUnitComboBox.Text
            End If

            If DisciplineComboBox.Text = "" Then
                DisciplineValue = "*"
            Else
                DisciplineValue = DisciplineComboBox.Text
            End If

            If RegionComboBox.Text = "" Then
                RegionValue = "*"
            Else
                RegionValue = RegionComboBox.Text
            End If

            'If System.IO.Directory.Exists(Settings.Manager.AE.BlockLibraryFolder.CombinePath("Enterprise")) Then
            '    sFilter = Settings.Manager.AE.BlockLibraryFolder.CombinePath("Enterprise", BusinessUnitValue, DisciplineValue, RegionValue) & "\*"
            'Else
            '    sFilter = Settings.Manager.AE.BlockLibraryFolder.CombinePath("Jacobs", BusinessUnitValue, DisciplineValue, RegionValue) & "\*"
            'End If

            sFilter = Settings.Manager.AE.BlockLibraryFolder.CombinePath(BusinessUnitValue, DisciplineValue, RegionValue) & "\*"

            PopulatePossibleLocations((sFilter))
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub PopulatePossibleLocations(ByRef sFilter As String)

        Try
            Dim Item As String

            FilteredLocationsListView.Items.Clear()

            Label1.Text = sFilter

            For Each Item In dList
                If UCase(Item) Like UCase(sFilter) Then
                    If UCase(Item) Like "*.DWG" Then
                        FilteredLocationsListView.Items.Add(Item)
                    End If
                End If
            Next Item

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub FirstTimeListFilesInFolder(ByRef SourceFolderName As String)

        Try
            For Each File As String In System.IO.Directory.GetFiles(SourceFolderName, "*.dwg", IO.SearchOption.AllDirectories)
                dList.Add(File)
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub ListFilesInFolder(ByRef SourceFolderName As String, ByRef IncludeSubfolders As Boolean, ByRef NextComboBox As System.Windows.Forms.ComboBox)

        Try
            Dim SourceFolder As System.IO.DirectoryInfo
            Dim SubFolder As System.IO.DirectoryInfo

            SourceFolder = My.Computer.FileSystem.GetDirectoryInfo(SourceFolderName)

            If IncludeSubfolders Then
                For Each SubFolder In SourceFolder.GetDirectories
                    If SubFolder.FullName.ToUpper.Contains(Settings.Manager.AE.BlockLibraryFolder.CombinePath("General").ToUpper) And
                        NextComboBox.Name.ToUpper = "BusinessUnitComboBox".ToUpper Then
                        '' Skip it we don't want to see General folder files in this dialog
                    Else
                        NextComboBox.Items.Add(SubFolder.Name)
                        ' CHECK
                        ListFilesInFolder(SubFolder.FullName, False, NextComboBox)
                    End If

                Next SubFolder
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Sub SaveSettingsForNextTime()

        Try
            Dim sLastUsedSettingsFileBlockFinderDat As String = ThisDrawingUtilities.GetVariable("roamablerootprefix").ToString.CombinePath("Support", Settings.Manager.AE.UserBlockFinderSettingsFileName)

            If System.IO.File.Exists(sLastUsedSettingsFileBlockFinderDat) Then
                System.IO.File.Delete(sLastUsedSettingsFileBlockFinderDat)
            End If

            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, BusinessUnitComboBox.SelectedIndex.ToString)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, DisciplineComboBox.SelectedIndex.ToString)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, RegionComboBox.SelectedIndex.ToString)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, TypeComboBox.SelectedIndex.ToString)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, SearchTextBox.Text.ToString)
            File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)

            ' Record the Favourites
            If UserFavListView.Items.Count >= 1 Then ' If there is something in the list
                For i As Integer = 0 To UserFavListView.Items.Count - 1
                    File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, UserFavListView.Items(i).Text)
                    File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)
                    File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, UserFavListView.Items(i).SubItems(1).Text)
                    File.AppendAllText(sLastUsedSettingsFileBlockFinderDat, vbCr)
                Next
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub RestorePreviousSettings(ByRef sLastUsedSettingsFile As String)

        Try
            Dim stemp As String
            Dim ctr As Integer
            Dim flength As Integer

            FileClose(1) ' Just in case it was left open
            FileOpen(1, sLastUsedSettingsFile, Microsoft.VisualBasic.OpenMode.Input)
            flength = 0
            'until the end of file
            While Not EOF(1)
                'read the line and store it in a variable
                stemp = LineInput(1)
                ' Count the lines in the file
                If Not stemp = "" Then
                    stemp = Common.Settings.Manager.EvaluateExpression(stemp)
                    flength = flength + 1
                End If
            End While

            Seek(1, 1)

            '    BuildFilter

            If flength <> 0 Then ' The dat file is not empty

                stemp = LineInput(1)
                stemp = LineInput(1)
                stemp = LineInput(1)
                stemp = LineInput(1)
                stemp = LineInput(1)

                ' Check to see if there are any user favorites
                If flength > 4 Then
                    ' These are the 7 fixed shortcuts to the corporate blocks
                    ' -3 to remove the first 3 entries / 2 because two lines make up one line in the list box and -1 because array starts counting at 0
                    Dim config_params(CInt(((flength - 4) / 2.0#) - 1), 1) As String
                    ctr = 0
                    'until the end of file
                    While Not EOF(1)
                        'read the first line and store it in a variable
                        stemp = LineInput(1)
                        If Not stemp = "" Then
                            config_params(ctr, 0) = stemp
                            If Not EOF(1) Then
                                'Got a valid fisrt line then read the second line
                                stemp = LineInput(1)
                                If stemp <> "" Then
                                    config_params(ctr, 1) = stemp
                                End If
                            End If
                            ctr = ctr + 1
                        End If
                    End While
                    ' Record the Favourites

                    '' clear and add new data
                    UserFavListView.Items.Clear()
                    For i As Integer = 0 To UBound(config_params)
                        Dim item As ListViewItem = UserFavListView.Items.Add(config_params(i, 0))
                        item.SubItems.Add(config_params(i, 1))
                    Next i

                End If
            Else
                Acad_MessageBox("Last used parameters file is present but empty", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            FileClose(1)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub GetConfigFavourites(ByRef sLastUsedSettingsFile As String, ByRef FListBox As System.Windows.Forms.ListView, Optional ByRef RemovePath As Boolean = True)

        Try
            Dim stemp As String
            Dim ctr As Integer
            Dim flength As Integer

            FileClose(1) ' Just in case it was left open

            FileOpen(1, sLastUsedSettingsFile, Microsoft.VisualBasic.OpenMode.Input)

            flength = 0
            'until the end of file
            While Not EOF(1)
                'read the line and store it in a variable
                stemp = LineInput(1)
                ' Count the lines in the file
                If Not stemp = "" Then
                    stemp = Replace(stemp, "[DocumentsAndSettings]", sDocumentsAndSettingsFolder)
                    flength = flength + 1
                End If
            End While

            Seek(1, 1)

            If flength <> 0 Then ' The dat file is not empty

                ' These are the 7 fixed shortcuts to the corporate blocks
                ' -3 to remove the first 3 entries / 2 because two lines make up one line in the list box and -1 because array starts counting at 0
                Dim config_params(CInt((flength / 2.0#) - 1), 1) As String

                ctr = 0

                'until the end of file
                While Not EOF(1)

                    'read the first line and store it in a variable
                    stemp = LineInput(1)

                    If Not stemp = "" Then
                        config_params(ctr, 0) = stemp
                        If Not EOF(1) Then
                            'Got a valid first line then read the second line
                            stemp = LineInput(1)
                            stemp = Replace(stemp, "[DocumentsAndSettings]", sDocumentsAndSettingsFolder)
                            config_params(ctr, 1) = stemp
                        End If
                        ctr = ctr + 1
                    End If
                End While

                'Steven Houghton modified
                For i As Integer = LBound(config_params) To UBound(config_params) '- 1

                    Dim FileToUse As String = config_params(i, 1).ToString

                    If Not FileToUse.Contains(":") Then

                        If IsThisAnOldConfigName() = True Then
                            If RuleAccessors.GetruleValue("TESTCONFIG", "False", True, False).IsTrue Then
                                FileToUse = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath("T@", RuleAccessors.GetruleValue("FULLCONFIGNAME"), "Support", FileToUse)
                            Else
                                FileToUse = Settings.Manager.AE.ConfigurationExtractionPathPrefix.CombinePath(RuleAccessors.GetruleValue("FULLCONFIGNAME"), "Support", FileToUse)
                            End If
                        Else
                            FileToUse = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(RuleAccessors.GetruleValue("FullConfigName"), "Support", FileToUse)
                        End If

                    End If

                    If System.IO.File.Exists(FileToUse) Then
                        '' add main item
                        Dim item As ListViewItem = FListBox.Items.Add(config_params(i, 0).ToString)

                        '' now add the rest of the columns
                        item.SubItems.Add(FileToUse)
                    Else
                        Acad_MessageBox("File not found " & FileToUse & " link was not added", , , , , , , True, )
                    End If

                Next
            Else
                Acad_MessageBox("Last used parameters file is present but empty", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            FileClose(1)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            FileClose(1)
        End Try

    End Sub

    Public Function get_image_of_file(ByVal filename As String) As System.Drawing.Bitmap

        'create a new database instance and load the dwg file into it.   
        Dim dbb As New Database(False, True)
        dbb.ReadDwgFile(filename, FileOpenMode.OpenForReadAndAllShare, False, "")

        'grab the thumbnail bitmap and get rid of the white background   
        Dim preview As System.Drawing.Bitmap = dbb.ThumbnailBitmap
        preview.MakeTransparent(System.Drawing.Color.White)

        Return preview

    End Function

    Public Sub assign_image(Optional ByVal resize As Boolean = False)

        'place the picture in the preview box and resize   
        'x Me.PictureBoxAll.BackColor = System.Drawing.Color.LightSlateGray
        'Me.PictureBoxAll.Image = newImage

        'resize the picture box (not the pallete) if it was asked for   
        If resize = True Then
            'Me.PictureBoxAll.Width = newImage.Width
            'Me.PictureBoxAll.Height = newImage.Height
        End If

        'Using g As Graphics = Graphics.FromImage(newImage)

        '    For x As Integer = 0 To newImage.Width - 1
        '        For y As Integer = 0 To newImage.Height - 1
        '            Dim intR As Integer = CInt(255 * (x / (newImage.Width - 1)))
        '            Dim intG As Integer = CInt(255 * (y / (newImage.Height - 1)))
        '            Dim intB As Integer = CInt(255 * ((x + y) / (newImage.Width + newImage.Height - 2)))

        '            Dim imageAttributes As New ImageAttributes()
        '            Dim colorMap As New Imaging.ColorMap()

        '            colorMap.OldColor = Color.FromArgb(0, 0, 0, 0)            ' Black ?
        '            colorMap.NewColor = Color.FromArgb(255, 255, 255, 255)    ' White ?

        '            Dim remapTable As ColorMap() = {colorMap}

        '            imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap)

        '            Using penNew As New Pen(Color.FromArgb(255, intR, intG, intB))

        '                'NOTE: when the form resizes, only the new section is painted, according to e.ClipRectangle.
        '                g.DrawRectangle(penNew, New Rectangle(New Point(x, y), New Size(1, 1)))

        '            End Using
        '        Next y
        '    Next x

        'End Using


    End Sub


    Private Sub ColorMap_Click(ByVal sender As Object, ByVal e As PaintEventArgs)

        Dim imageAttributes As New ImageAttributes()
        Dim colorMap As New Imaging.ColorMap()

        colorMap.NewColor = System.Drawing.Color.White  'Color.FromArgb(0, 0, 0, 0)            ' Black ?
        colorMap.OldColor = System.Drawing.Color.Black  'Color.FromArgb(255, 255, 255, 255)    ' White ?

        Dim remapTable As ColorMap() = {colorMap}

        imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap)

        'e.Graphics.DrawImage(newImage, 10, 10, Width, Height)

        '' Pass in the destination rectangle (2nd argument), the upper-left corner  
        '' (3rd and 4th arguments), width (5th argument),  and height (6th  
        '' argument) of the source rectangle.
        'e.Graphics.DrawImage( _
        '   newImage, _
        '   New Rectangle(0, 0, Width, Height), _
        '   0, 0, _
        '   PictureBoxAll.Width, _
        '   PictureBoxAll.Height, _
        '   GraphicsUnit.Pixel, _
        '   imageAttributes)
        e.Graphics.DrawImage(
                               newImage,
                               New Rectangle(150, 10, Width, Height),
                               0, 0,
                               Width * 2,
                               Height * 2,
                               GraphicsUnit.Pixel,
                               imageAttributes)
    End Sub

    'Private Sub chkInsertOnClose_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkInsertOnClose.CheckedChanged

    '    Select Case chkInsertOnClose.CheckState
    '        Case CheckState.Checked

    '            XVisible(gbxInsertOnClose, True)

    '        Case CheckState.Unchecked

    '            XVisible(gbxInsertOnClose, False)

    '    End Select

    'End Sub

    Private Sub chkUniScale_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkUniScale.CheckedChanged

        Select Case chkUniScale.CheckState
            Case CheckState.Checked

                txtScaleY.Text = txtScaleX.Text
                txtScaleZ.Text = txtScaleX.Text
                txtScaleY.Enabled = False
                txtScaleZ.Enabled = False

            Case CheckState.Unchecked

                txtScaleY.Enabled = True
                txtScaleZ.Enabled = True

        End Select

    End Sub

    Private Sub lstBlockNames_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstBlockNames.SelectedValueChanged

        If UpdateDialogProp(0) = "" Then Exit Sub

        UpdateDialogProp(1) = lstBlockNames.SelectedItem.ToString

        InitaliseDwgViewControl(dpcBlockViewBlk, UpdateDialogProp(0), False, False, UpdateDialogProp(1))

    End Sub

    Private Sub chkRotOnInsert_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkRotOnInsert.CheckStateChanged

        If chkRotOnInsert.CheckState = CheckState.Checked Then
            txtRotate.Text = "0"
            txtRotate.Enabled = False
        Else
            txtRotate.Enabled = True
        End If

    End Sub

    Private Sub chkInsertUseDimScale_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInsertUseDimScale.CheckedChanged

        Select Case chkInsertUseDimScale.CheckState
            Case CheckState.Checked
                chkUniScale.Enabled = False
                txtScaleX.Text = GetDimScale.ToString
                txtScaleY.Text = txtScaleX.Text
                txtScaleZ.Text = txtScaleX.Text
                txtScaleX.Enabled = False
                txtScaleY.Enabled = False
                txtScaleZ.Enabled = False

            Case CheckState.Unchecked

                chkUniScale.Enabled = True
                txtScaleX.Enabled = True
                txtScaleY.Enabled = True
                txtScaleZ.Enabled = True

        End Select

    End Sub

    Private Sub BlockFinderForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

    Private Sub CorporateFavouriteListView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CorporateFavouriteListView.SelectedIndexChanged

        Try
            Dim sSelected As String = String.Empty
            Dim SelectedItem As System.Windows.Forms.ListViewItem

            ' FilteredLocationsListView.SelectedItems.Clear()
            UserFavListView.SelectedItems.Clear()
            ConfigFavListView.SelectedItems().Clear()

            ' If there is something in the list
            If CorporateFavouriteListView.Items.Count >= 1 Then
                For Each SelectedItem In CorporateFavouriteListView.SelectedItems
                    ' get the dwgname and path
                    sSelected = SelectedItem.SubItems.Item(1).Text
                Next
            End If

            ''Me.dwgPickBox.Visible = False
            If System.IO.File.Exists(sSelected) Then

                UpdateDialogProp(0) = sSelected

                Me.Cursor = Cursors.WaitCursor

                InitaliseDwgViewControl(dpcBlockViewBasic, sSelected, False, False)

                GetBlockNamesFromFile(sSelected, lstBlockNames)

                If Not dpcBlockViewBlk.mpView Is Nothing Then
                    ' clear the preview control
                    dpcBlockViewBlk.mpView.EraseAll()
                    refreshViewInsert()
                    cmdInsertBlock.Enabled = True
                End If

                Me.Cursor = Cursors.Default

            End If


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub
End Class
