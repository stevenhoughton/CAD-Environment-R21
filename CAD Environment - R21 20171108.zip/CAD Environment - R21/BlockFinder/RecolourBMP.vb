﻿Imports System.Drawing.Imaging

Module RecolourBMP

    Sub remap()

        Dim image As New Bitmap("RemapInput.bmp")
        Dim imageAttributes As New ImageAttributes()
        Dim colorMap As New Imaging.ColorMap()

        colorMap.OldColor = Color.FromArgb(255, 255, 0, 0) ' opaque red
        colorMap.NewColor = Color.FromArgb(255, 0, 0, 255) ' opaque blue

        Dim remapTable As ColorMap() = {colorMap}

        imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap)


    End Sub
End Module
