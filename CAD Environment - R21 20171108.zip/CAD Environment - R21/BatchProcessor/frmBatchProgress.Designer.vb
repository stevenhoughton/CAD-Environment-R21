﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBatchProgress
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBatchProgress))
        Me.pgbProcesses = New System.Windows.Forms.ProgressBar()
        Me.lblProcessProgress = New System.Windows.Forms.Label()
        Me.pgbFiles = New System.Windows.Forms.ProgressBar()
        Me.lblFileProgress = New System.Windows.Forms.Label()
        Me.pnlBanner = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.pnlBanner.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pgbProcesses
        '
        Me.pgbProcesses.Location = New System.Drawing.Point(16, 90)
        Me.pgbProcesses.Margin = New System.Windows.Forms.Padding(4)
        Me.pgbProcesses.Name = "pgbProcesses"
        Me.pgbProcesses.Size = New System.Drawing.Size(540, 33)
        Me.pgbProcesses.TabIndex = 39
        '
        'lblProcessProgress
        '
        Me.lblProcessProgress.AutoSize = True
        Me.lblProcessProgress.Location = New System.Drawing.Point(225, 68)
        Me.lblProcessProgress.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblProcessProgress.Name = "lblProcessProgress"
        Me.lblProcessProgress.Size = New System.Drawing.Size(120, 17)
        Me.lblProcessProgress.TabIndex = 40
        Me.lblProcessProgress.Text = "Process Progress"
        '
        'pgbFiles
        '
        Me.pgbFiles.Location = New System.Drawing.Point(15, 151)
        Me.pgbFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.pgbFiles.Name = "pgbFiles"
        Me.pgbFiles.Size = New System.Drawing.Size(540, 33)
        Me.pgbFiles.TabIndex = 39
        '
        'lblFileProgress
        '
        Me.lblFileProgress.AutoSize = True
        Me.lblFileProgress.Location = New System.Drawing.Point(240, 129)
        Me.lblFileProgress.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFileProgress.Name = "lblFileProgress"
        Me.lblFileProgress.Size = New System.Drawing.Size(91, 17)
        Me.lblFileProgress.TabIndex = 40
        Me.lblFileProgress.Text = "File Progress"
        '
        'pnlBanner
        '
        Me.pnlBanner.BackgroundImage = CType(resources.GetObject("pnlBanner.BackgroundImage"), System.Drawing.Image)
        Me.pnlBanner.Controls.Add(Me.lblTitle)
        Me.pnlBanner.Controls.Add(Me.LogoPictureBox)
        Me.pnlBanner.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBanner.Location = New System.Drawing.Point(0, 0)
        Me.pnlBanner.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlBanner.Name = "pnlBanner"
        Me.pnlBanner.Size = New System.Drawing.Size(568, 52)
        Me.pnlBanner.TabIndex = 38
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(217, 35)
        Me.lblTitle.TabIndex = 29
        Me.lblTitle.Text = "Progress Meter"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 28
        Me.LogoPictureBox.TabStop = False
        '
        'frmBatchProgress
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(568, 193)
        Me.Controls.Add(Me.lblFileProgress)
        Me.Controls.Add(Me.lblProcessProgress)
        Me.Controls.Add(Me.pgbFiles)
        Me.Controls.Add(Me.pgbProcesses)
        Me.Controls.Add(Me.pnlBanner)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmBatchProgress"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.pnlBanner.ResumeLayout(False)
        Me.pnlBanner.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlBanner As System.Windows.Forms.Panel
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents pgbProcesses As System.Windows.Forms.ProgressBar
    Friend WithEvents lblProcessProgress As System.Windows.Forms.Label
    Friend WithEvents pgbFiles As System.Windows.Forms.ProgressBar
    Friend WithEvents lblFileProgress As System.Windows.Forms.Label
End Class
