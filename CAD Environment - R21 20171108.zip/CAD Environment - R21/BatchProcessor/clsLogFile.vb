﻿Imports System.Text
Imports System.IO

Public Class clsLogFile

    Private EachLineOfLogFile As New StringBuilder
    Private LogFileName As String = ""

    Public Sub New(ByVal LogFileName As String, ByVal CreateNewAndDeleteOld As Boolean)
        'do nothign
        LogFileName = LogFileName

        If CreateNewAndDeleteOld = True Then
            If File.Exists(LogFileName) Then
                My.Computer.FileSystem.DeleteFile(LogFileName)
            End If
        End If

    End Sub

    Public Sub AddLine(ByVal LineItem As String)
        EachLineOfLogFile.AppendLine(LineItem)
    End Sub

    Public Sub WriteLogFile()

        Dim LogFileName As String = IO.Path.GetTempPath + Format(Now, "yyyyMMdd_hhmmsstt") + ".txt"

        System.IO.File.WriteAllText(LogFileName, EachLineOfLogFile.ToString)

        System.Diagnostics.Process.Start(LogFileName)

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
