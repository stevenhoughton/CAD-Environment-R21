﻿Imports Jacobs.Common.Settings
Imports Jacobs.Common.Core

Public Class frmBatchProgress

    Private TheProcessor As clsProcessor

    Public Sub New(ByRef Proc As clsProcessor)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        TheProcessor = Proc

    End Sub

    Private Sub frmBatchProgress_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        lblTitle.Left = Me.Width \ 2 - Me.lblTitle.Width \ 2
        lblFileProgress.Left = Me.Width \ 2 - Me.lblFileProgress.Width \ 2
        lblProcessProgress.Left = Me.Width \ 2 - Me.lblProcessProgress.Width \ 2

        Me.TopMost = True

    End Sub

    Public Sub Go(ByVal SaveOnExit As Boolean)

        Me.Show()

        'Remove Flag to batch process
        Registry.RegistryDelete("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing")

        TheProcessor.FilesProgBar = pgbFiles
        TheProcessor.ProcessesProgBar = pgbProcesses

        TheProcessor.PassLabelForNotifications(lblFileProgress, lblProcessProgress)

        ' Flag that the batch processor is running
        Registry.RegistryWrite("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing", "True", "REG_SZ")

        'Process Files
        TheProcessor.ExeCuteProcessOnFiles(SaveOnExit)

        'Remove Flag to batch process
        Registry.RegistryDelete("HKCU", Settings.Manager.AutoCAD.AEAcadWorkingRegKey & "\BATCHPROCESSOR\", "Processing")

        Me.Hide()

    End Sub

    Private Sub lblFileProgress_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles lblFileProgress.Paint
        'Me.Refresh()
    End Sub
End Class