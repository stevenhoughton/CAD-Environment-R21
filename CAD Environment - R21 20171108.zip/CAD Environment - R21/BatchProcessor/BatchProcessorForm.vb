﻿'Imports VB = Microsoft.VisualBasic
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports System.IO
Imports System.Data
Imports System.Linq
Imports Autodesk.AutoCAD.ApplicationServices
Imports Jacobs.AutoCAD.Utilities
Imports System.Reflection
Imports Jacobs.Common.Settings
Imports Jacobs.AutoCAD.BatchProcessorPlugin

Friend Class BatchProcessorForm
    Inherits System.Windows.Forms.Form

    Private colDocs As DocumentCollection = Application.DocumentManager

    Private DisableUpdate As Boolean = False
    Private FailedToLoadAllFromFile As Boolean = False

    Private TabGenerationDS As New DataSet

    Private InstructionFile As String = ""
    Private CodeFile As String = ""
    Private HelpFile As String = ""

    Private SaveAsTypes(0) As String
    Private SaveAsTypesCount As Integer

    Private ProcessesDGV(0) As DataGridView
    Private ProcessesDGVCount As Integer = 0

    Private ColumnChooserDGV(0) As clsDGVColumnChooser
    Private ColumnChooserDGVCount As Integer = 0

    Private CurrentProcessesDGV As DataGridView

    Private Processes_DS As DataSet

    Private Network_DT As DataTable

    Private Application_DT As DataTable
    Private IsApplication_DT_New As Boolean = False
    Private HasApplication_File As Boolean = False

    Private Favs_DT As DataTable
    Private IsFavs_DT_New As Boolean = False
    Private HasFavs_File As Boolean = False

    Private Proj_DT As DataTable
    Private IsProj_DT_New As Boolean = False
    Private HasProj_File As Boolean = False

    Private blnRecurse As Boolean

    Private strPath As String ' Path returned by Browse dialog
    Private strPathDest As String ' Path returned by Browse dialog
    Private strLogPath As String ' Path returned by Browse dialog

    Private NDriveProcessesPath As String = ""
    Private MyDocuments As String = ""
    Private BatchProcessorRoutineFolder As String = ""
    Private BundleContentsPath As String = ""
    Private RoamableSupportPath As String = ""
    Private ApplicationFolder As String = ""
    'Private LocalFolder As String = ""
    'Private ProjectFolder As String = ""
    'Private FavouritesFolder As String = ""
    Private RoamableSupportPathBP As String = ""
    Private ProcessesFolder As String = ""

    Private IsInitialising As Boolean = True

    Private FileToProcess_DS As New DataSet

    Private SaveSettingsFile As String

    Private BackUpFiles As Boolean = False

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Private Sub frmBatchProcessor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)
            IsInitialising = True

            'Disabled Steven Houghton 6/11/17
            'cboFilterType.Items.Clear()
            'cboFilterType.Items.Add("Process Types")
            'cboFilterType.Items.Add("Process Exe File Type")

            'cboFilterType.Items.Add("DAT Process Exe File With DAT File As Parameters")
            'cboFilterType.Items.Add("INI Process Exe File With INI File As Paramaeters")
            'cboFilterType.Items.Add("XML Process Exe File With XML File As Paramaeters")
            'cboFilterType.Items.Add("CSV Process Exe File With CSV File As Paramaeters")

            'cboFilterType.Items.Add("Global Processes")
            'cboFilterType.Items.Add("Network Process (" & Settings.Manager.AE.NetworkConfiguration.CombinePath(Settings.Manager.AutoCAD.SharedAcadName, Settings.Manager.AE.ADSiteName, "BatchProcessorRoutines" & ")"))
            'cboFilterType.Items.Add("Project Process (" & My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Project)"))
            'cboFilterType.Items.Add("Local (" & My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Local)"))
            'cboFilterType.Items.Add("Favourites (" & My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Favourites)"))


            'cboSearchCondition.SelectedIndex = 0
            'cboSearchWhat.SelectedIndex = 0

            'Initialize File Datagrid View
            SetFilesDataTable()

            'Dim sDisplayValue As String
            Dim AcadPref As Autodesk.AutoCAD.Interop.AcadPreferencesOpenSave
            AcadPref = ThisDrawingUtilities.Application.Preferences.OpenSave

            ' Get the OpenSave preferences object
            AcadPref = ThisDrawingUtilities.Application.Preferences.OpenSave
            Dim sDisplayValue As String = ""
            ' Convert the value of this setting to a meaningful text string
            sDisplayValue = CStr(AcadPref.SaveAsType)

            Select Case sDisplayValue

                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_dwg) : sDisplayValue = "AutoCAD 2013 Drawing (*.dwg)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_dwg) : sDisplayValue = "AutoCAD 2010/LT2010 Drawing (*.dwg)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2007_dwg) : sDisplayValue = "AutoCAD 2007/LT2007 Drawing (*.dwg)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2004_dwg) : sDisplayValue = "AutoCAD 2004/LT2004 Drawing (*.dwg)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2000_dwg) : sDisplayValue = "AutoCAD 2000/LT2000 Drawing (*.dwg)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.acR14_dwg) : sDisplayValue = "AutoCAD R14/LT98/LT97 Drawing (*.dwg)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_Template) : sDisplayValue = "AutoCAD Drawing Template (*.dwt)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.acR13_dxf) : sDisplayValue = "AutoCAD R13 DXF (*.dxf)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_dxf) : sDisplayValue = "AutoCAD 2010/LT2010 DXF (*.dxf)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2007_dxf) : sDisplayValue = "AutoCAD 2007/LT2007 DXF (*.dxf)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2004_dxf) : sDisplayValue = "AutoCAD 2004/LT2004 DXF (*.dxf)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2000_dxf) : sDisplayValue = "AutoCAD 2000/LT2000 DXF (*.dxf)"
                Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.acR12_dxf) : sDisplayValue = "AutoCAD R12/LT2 DXF (*.dxf)"

                    'Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2004_Template) : sDisplayValue = "AutoCAD 2004 Drawing Template File (*.dwt)"
                    'Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_dxf) : sDisplayValue = "AutoCAD 2010 DXF (*.dxf)"
                    'Case CStr(Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_Template) : sDisplayValue = "AutoCAD 2010 Drawing Template File DWT (*.dwt)"

            End Select

            cboOutputFileFormat.Items.Add("AutoCAD 2013 Drawing (*.dwg)")
            cboOutputFileFormat.Items.Add("AutoCAD 2010/LT2010 Drawing (*.dwg)")
            cboOutputFileFormat.Items.Add("AutoCAD 2007/LT2007 Drawing (*.dwg)")
            cboOutputFileFormat.Items.Add("AutoCAD 2004/LT2004 Drawing (*.dwg)")
            cboOutputFileFormat.Items.Add("AutoCAD 2000/LT2000 Drawing (*.dwg)")
            cboOutputFileFormat.Items.Add("AutoCAD R14/LT98/LT97 Drawing (*.dwg)")
            cboOutputFileFormat.Items.Add("AutoCAD Drawing Template (*.dwt)")
            cboOutputFileFormat.Items.Add("AutoCAD 2013 DXF (*.dxf)")
            cboOutputFileFormat.Items.Add("AutoCAD 2010/LT2010 DXF (*.dxf)")
            cboOutputFileFormat.Items.Add("AutoCAD 2007/LT2007 DXF (*.dxf)")
            cboOutputFileFormat.Items.Add("AutoCAD 2004/LT2004 DXF (*.dxf)")
            cboOutputFileFormat.Items.Add("AutoCAD 2000/LT2000 DXF (*.dxf)")
            cboOutputFileFormat.Items.Add("AutoCAD R12/LT2 DXF (*.dxf)")

            'cboOutputFileFormat.Items.Add("AutoCAD 2010 Drawing Template File (*.dwt)")
            'cboOutputFileFormat.Items.Add("AutoCAD 2010 DXF (*.dxf)")
            'cboOutputFileFormat.Items.Add("AutoCAD 2010 Drawing Template File (*.dwt)")
            'cboOutputFileFormat.Items.Add("AutoCAD 2004 Drawing Template File (*.dwt)")

            cboOutputFileFormat.Sorted = True

            'Added Steven Houghton 6/11/17
            InitialiseFrontPageOfForm()

            SaveSettingsFile = BatchProcessorRoutineFolder.CombinePath("\Settings\BatchProcessorSetting.xml")

            If System.IO.File.Exists(SaveSettingsFile) Then

                ' Reads the file on the machine if present
                RestorePreviousSettings()

            Else

                ' First time it is used
                chkSpecifyDifferentFileLocation.CheckState = CheckState.Checked
                ClearLogFile_chk.CheckState = CheckState.Checked
                chkRecurse.CheckState = CheckState.Checked
                chkOverWriteExistingFiles.CheckState = CheckState.Unchecked
                chkMaintainDirectoryStructure.CheckState = CheckState.Unchecked
                lblDestinationLocation.Text = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal)
                'cboOutputFileFormat.Text = sDisplayValue
                ResultLogFile_FLD.Text = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal)

                If ThisDrawingUtilities.GetVariable("SAVEFIDELITY").ToString.IsTrue Then
                    chkMaintainSaveFidelity.CheckState = CheckState.Checked
                Else
                    chkMaintainSaveFidelity.CheckState = CheckState.Unchecked
                End If

                'Disabled Steven Houghton 6/11/17
                'cboFilterType.SelectedItem = "Process Types"
                optSaveOnExit.Checked = True
                chkSpecifyDifferentFileLocation.Checked = True
                chkOverWriteExistingFiles.Checked = False

                If ThisDrawingUtilities.GetVariable("SAVEFIDELITY").ToString.IsTrue Then
                    chkMaintainSaveFidelity.CheckState = CheckState.Checked
                Else
                    chkMaintainSaveFidelity.CheckState = CheckState.Unchecked
                End If

                cboOutputFileFormat.SelectedItem = sDisplayValue
                chkMaintainDirectoryStructure.Checked = False
                optNoSaveOnExit.Checked = False
                chkRecurse.Checked = True
                chkSaveFileHistory.Checked = True

            End If

            IsInitialising = False

            'InitialiseFrontPageOfForm()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub InitialiseFrontPageOfForm(Optional ByVal SetIsInitialising As Boolean = False,
                                         Optional ByVal ResetBundledProcesses As Boolean = False,
                                         Optional ByVal ResetApplicationProcesses As Boolean = False)

        If SetIsInitialising Then IsInitialising = True

        GetConfigSettings()
        'N:\JacobsCADcfg\Autodesk Shared R21\AU-BNE\BatchProcessorRoutines
        'NDriveProcessesPath = Settings.Manager.AE.NetworkConfiguration.CombinePath(Settings.Manager.AutoCAD.SharedAcadName, Settings.Manager.AE.ADSiteName, "BatchProcessorRoutines")
        'C:\Program Files\Autodesk\ApplicationPlugins\Jacobs AutoCAD Environment R21.bundle\Contents\BatchProcessorRoutines
        'BundleContentsPath = Settings.Manager.AE.AEBundleContents.CombinePath("BatchProcessorRoutines")
        'C:\Users\[USERNAME]\Documents
        MyDocuments = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        CheckAndSetSuppFolders(MyDocuments)
        'C:\Users\[USERNAME]\Documents\Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines
        BatchProcessorRoutineFolder = MyDocuments.CombinePath("Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines")
        CheckAndSetSuppFolders(BatchProcessorRoutineFolder)

        'C:\Users\[USERNAME]\Documents\Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Local
        'LocalFolder = BatchProcessorRoutineFolder.CombinePath("Local")
        'CheckAndSetSuppFolders(LocalFolder)

        'C:\Users\[USERNAME]\Documents\Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Favorites
        'FavouritesFolder = BatchProcessorRoutineFolder.CombinePath("Favourites")
        'CheckAndSetSuppFolders(FavouritesFolder)

        'C:\Users\[USERNAME]\Documents\Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Project
        'ProjectFolder = BatchProcessorRoutineFolder.CombinePath("Project")
        'CheckAndSetSuppFolders(ProjectFolder)

        'C:\Users\[USERNAME]\Documents\Jacobs\Jacobs AutoCAD Environment R21\BatchProcessorRoutines\Processes
        'ProcessesFolder = BatchProcessorRoutineFolder.CombinePath("Processes")
        'CheckAndSetSuppFolders(ProcessesFolder)

        'Copy BundleContents to RoamableSupport
        'Disabled Steven Houghton 25/09/17
        'CopyBundleContentFilesToSuppBP(ResetBundledProcesses)
        'CopyLocalContentFilesToSuppBP(ResetLocalProcesses)

        DefaultDataGridView(dgvAppliedProcess, "RUN_PROCESSES", False)

        Dim FStream As FileStream
        Dim TempDS As New DataSet

        Try

            FStream = New FileStream(BatchProcessorRoutineFolder.CombinePath("\Settings\BatchProcessor.xml"), FileMode.Open) ' ListEnt, FileMode.Open)

            TempDS.ReadXml(FStream)

            FStream.Close()

            If TempDS.Tables.Count > 0 Then
                Processes_DS = TempDS.Copy

                'Add Path Column to DataTable
                Dim NC As DataColumn = Processes_DS.Tables(0).Columns.Add("PPath", GetType(System.String))
                For Each DatRow As DataRow In Processes_DS.Tables(0).Rows
                    DatRow.Item("PPath") = BatchProcessorRoutineFolder
                Next

                'set Primary Key prio to use the first table a default for each of the following process
                'For Each MyTab As DataTable In Processes_DS.Tables
                'MyTab.PrimaryKey = New DataColumn() {MyTab.Columns("ProcessExeFile")}
                'Next

                'Add to make DGVAppliuedProcess same as all other grids
                Dim NewDT As DataTable = Processes_DS.Tables(0).Clone
                NewDT.TableName = "AppliedProcess"
                Processes_DS.Tables.Add(NewDT)

                GetExternalBatchPros(BatchProcessorRoutineFolder, "Applications", Application_DT)

                'Get Local, Favs and NDrive Scripts
                'GetExternalBatchPros(LocalFolder, "local", Local_DT)
                'GetExternalBatchPros(FavouritesFolder, "Favourites", Favs_DT)
                'GetExternalBatchPros(ProjectFolder, "Project", Proj_DT)
                'If IO.Directory.Exists(NDriveProcessesPath) Then
                'GetExternalBatchPros(GetUNCPath(NDriveProcessesPath), "Network", Network_DT)
                'End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        Finally
            TempDS = Nothing
            FStream = Nothing
        End Try

        'Add to make DGVAppliuedProcess same as all other grids
        dgvAppliedProcess.DataSource = Processes_DS
        dgvAppliedProcess.DataMember = Processes_DS.Tables("AppliedProcess").TableName

        InitialiseProcessesTabControl()

        If SetIsInitialising Then IsInitialising = False

    End Sub
    Public Property SetInstructionFile() As String
        Get
            Return InstructionFile
        End Get
        Set(ByVal value As String)
            InstructionFile = value
            If InstructionFile = "" Then
                EditDataFileButton.Enabled = False
            Else
                EditDataFileButton.Enabled = True
            End If
        End Set
    End Property

    Public Property SetCodeFile() As String
        Get
            Return CodeFile
        End Get
        Set(ByVal value As String)
            CodeFile = value
            If CodeFile = "" Then
                EditCodeButton.Enabled = False
            Else
                If CodeFile.ToUpper.Contains("DLL") Then
                    EditCodeButton.Enabled = False
                Else
                    EditCodeButton.Enabled = True
                End If
            End If
        End Set
    End Property

    Public Property SetHelpFile() As String
        Get
            Return HelpFile
        End Get
        Set(ByVal value As String)
            HelpFile = value
            If HelpFile = "" Then
                HelpButtonCode.Enabled = False
            Else
                HelpButtonCode.Enabled = True
            End If
        End Set
    End Property

    Private Sub frmBatchProcessor_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        lblTitle.Left = Me.Width \ 2 - Me.lblTitle.Width \ 2
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()
            'If IsLocal_DT_New Then
            'SaveXML(TabGenerationDS.Tables("LOCAL"), "Local", LocalFolder & "\Local.xml")
            'End If

            'If IsFavs_DT_New Then
            'MsgBox("Favs Is New need to save to XML File", MsgBoxStyle.Critical, "Should Never Appear")
            'End If

            SaveBacthProDialogSettings()

            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub
    Private Sub BrowseForApplicationsButton_Click(sender As Object, e As EventArgs) Handles BrowseForApplicationsButton.Click
        Try

            'Dim Result As String

            'Result = FolderBrowserDialog1.ShowDialog().ToString()

            'If Result = Windows.Forms.DialogResult.OK.ToString Then

            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.dat", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.ini", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.xml", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.csv", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.txt", LocalSupportPath, True)

            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.lsp", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.vlx", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.fas", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.scr", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.dvb", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.chm", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.rtf", LocalSupportPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.dll", LocalSupportPath, True)

            'End If

            Dim ReturnedFolder As String = BrowseForFolder()
            If ReturnedFolder <> String.Empty Then
                If System.IO.Directory.Exists(ReturnedFolder) Then

                    ApplicationsTextBox.Clear()
                    ApplicationsTextBox.Text = ReturnedFolder

                    CheckAndCopyFile(ReturnedFolder, "*.dat", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.ini", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.xml", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.csv", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.txt", ApplicationFolder, True)

                    CheckAndCopyFile(ReturnedFolder, "*.lsp", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.vlx", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.fas", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.scr", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.dvb", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.chm", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.rtf", ApplicationFolder, True)
                    CheckAndCopyFile(ReturnedFolder, "*.dll", ApplicationFolder, True)

                Else
                    Acad_MessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
                End If
            End If


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub CheckAndCopyFile(ByRef sPathSource As String, ByRef sFile As String, ByRef sPathTarget As String, ByRef Overwrite As Boolean)

        ' Since we are using wild cards to copy the copy file may return file not found of there are no files of that type present
        Try
            If System.IO.Directory.Exists(sPathSource) Then
                For Each foundFile As String In My.Computer.FileSystem.GetFiles(sPathSource, Microsoft.VisualBasic.FileIO.SearchOption.SearchTopLevelOnly, sFile)
                    If System.IO.File.Exists(sPathTarget.CombinePath(System.IO.Path.GetFileName(foundFile))) Then
                        If Overwrite = True Then
                            System.IO.File.Delete(sPathTarget.CombinePath(System.IO.Path.GetFileName(foundFile)))
                            My.Computer.FileSystem.CopyFile(foundFile, sPathTarget.CombinePath(System.IO.Path.GetFileName(foundFile)), False)
                        End If
                    Else
                        My.Computer.FileSystem.CopyFile(foundFile, sPathTarget.CombinePath(System.IO.Path.GetFileName(foundFile)), False)
                    End If
                Next
                'My.Computer.FileSystem.CopyFile(sPathSource & "\" & sFile, sPathTarget, Overwrite)
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub CheckAndSetSuppFolders(ByVal Path As String)

        If Directory.Exists(Path) = False Then
            Directory.CreateDirectory(Path)
        End If

    End Sub

    Private Sub SetFilesDataTable()

        If FileToProcess_DS.Tables.Contains("Files") Then
            FileToProcess_DS.Tables.Remove("Files")
        End If
        FileToProcess_DS.Tables.Add("Files")

        FileToProcess_DS.Tables("Files").Columns.Add("dFileName", GetType(System.String))
        Dim pk As DataColumn = FileToProcess_DS.Tables("Files").Columns.Add("dFilePath", GetType(System.String))

        'Need a primary key to search the data table for existing Files
        FileToProcess_DS.Tables("Files").PrimaryKey = New DataColumn() {pk}

        dgvFiles.AutoGenerateColumns = False
        dgvFiles.AllowDrop = True
        dgvFiles.DataSource = FileToProcess_DS
        dgvFiles.DataMember = FileToProcess_DS.Tables("Files").TableName

    End Sub

    Private Sub InitialiseProcessesTabControl(Optional ByVal AsSearch As Boolean = False)

        tbcProcesses.TabPages.Clear()

        ReDim ProcessesDGV(0)
        ProcessesDGVCount = 0

        TabGenerationDS = New DataSet
        If AsSearch = False Then
            'Disabled Steven Houghton 6/11/17
            'Select Case cboFilterType.SelectedIndex
            'Case 0 'Standard By ProcessCat
            Dim TableFilterVals As IEnumerable = (From U In Processes_DS.Tables(0).AsEnumerable()
                                                  Select U.Field(Of String)("ProcessCat")).Distinct

            For Each XVal As String In TableFilterVals

                Dim TableNam As String = XVal

                Dim FiltertedDT As DataTable = (From P In Processes_DS.Tables(0).AsEnumerable() _
                                                  .Where(Function(P) P.Field(Of String)("ProcessCat") = (TableNam))).CopyToDataTable

                FiltertedDT.TableName = TableNam

                TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            Next
            'Disabled Steven Houghton 6/11/17
            '    Case 1 'By EXE File Extension
            'Dim TableFilterVals As IEnumerable = (From U In Processes_DS.Tables(0).AsEnumerable()
            'Select Case U.Field(Of String)("ProcessExeFile").Substring(U.Field(Of String)("ProcessExeFile").Length - 4, 4).ToUpper).Distinct

            'For Each XVal As String In TableFilterVals

            'Dim TableNam As String = XVal

            'Dim FiltertedDT As DataTable = (From P In Processes_DS.Tables(0).AsEnumerable() _
            '.Where(Function(P) P.Field(Of String)("ProcessExeFile").ToUpper.Contains(TableNam))).CopyToDataTable

            'FiltertedDT.TableName = TableNam.Replace(".", "")

            'TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            'Next
            'Case 2 'With and Without Paramaeter
            '    Dim FiltertedDT As DataTable
            '    Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                                    Where U.Field(Of String)("DAT") <> "" _
            '                                    Select U)
            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "With DAT"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If


            '    FiltertedIE = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                    Where U.Field(Of String)("DAT") = "" _
            '                    Select U)

            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "No DAT"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If

            'Case 3
            '    Dim FiltertedDT As DataTable
            '    Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                                    Where U.Field(Of String)("INI") <> "" _
            '                                    Select U)
            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "With INI"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If


            '    FiltertedIE = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                    Where U.Field(Of String)("INI") = "" _
            '                    Select U)

            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "No INI"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If

            'Case 4 'With and Without Paramaeter
            '    Dim FiltertedDT As DataTable
            '    Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                                    Where U.Field(Of String)("XML") <> "" _
            '                                    Select U)
            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "With XML"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If


            '    FiltertedIE = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                    Where U.Field(Of String)("XML") = "" _
            '                    Select U)

            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "No XML"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If

            'Case 5 'With and Without Paramaeter
            '    Dim FiltertedDT As DataTable
            '    Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                                    Where U.Field(Of String)("CSV") <> "" _
            '                                    Select U)
            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "With CSV"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If


            '    FiltertedIE = (From U In Processes_DS.Tables(0).AsEnumerable() _
            '                    Where U.Field(Of String)("CSV") = "" _
            '                    Select U)

            '    If FiltertedIE.Count > 0 Then
            '        FiltertedDT = FiltertedIE.CopyToDataTable
            '        FiltertedDT.TableName = "No CSV"
            '        TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '    End If
            'Case 2 'CORPORATE
            '        Dim FiltertedDT As DataTable
            '        Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable()
            '                                                                  Where U.Field(Of String)("ProcessCat") <> "LOCAL"
            '                                                                  Select U)
            '        If FiltertedIE.Count > 0 Then
            '            FiltertedDT = FiltertedIE.CopyToDataTable
            '            FiltertedDT.TableName = "CORPORATE TOOLS"
            '            TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '        End If
            '    Case 3
            '        Dim FiltertedDT As DataTable
            '        Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable()
            '                                                                  Where U.Field(Of String)("ProcessCat") = "NETWORK"
            '                                                                  Select U)
            '        If FiltertedIE.Count > 0 Then
            '            FiltertedDT = FiltertedIE.CopyToDataTable
            '            FiltertedDT.TableName = "NETWORK TOOLS"
            '            TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '        End If
            '    Case 4 'LOCAL
            '        Dim FiltertedDT As DataTable
            '        Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From U In Processes_DS.Tables(0).AsEnumerable()
            '                                                                  Where U.Field(Of String)("ProcessCat") = "LOCAL"
            '                                                                  Select U)
            '        If FiltertedIE.Count > 0 Then
            '            FiltertedDT = FiltertedIE.CopyToDataTable
            '            FiltertedDT.TableName = "LOCAL TOOLS"
            '            TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '        End If
            'End Select
        Else

            'Dim SearchText As String = txtSearchVal.Text
            'Dim SerachOperator As String = cboSearchCondition.SelectedItem.ToString

            'If SearchText <> "*" AndAlso SearchText <> "" Then
            '    Select Case SerachOperator
            '        Case "Starts With"

            '            Dim FiltertedDT As DataTable
            '            Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From P In Processes_DS.Tables(0).AsEnumerable()
            '                                                                      Let CurrentR = P Where Processes_DS.Tables(0).Columns.Cast(Of DataColumn).Any(
            '                                                Function(Col As DataColumn) P.Item(Col.ColumnName).ToString.ToLower.StartsWith(SearchText.ToLower))
            '                                                                      Select CurrentR)

            '            If FiltertedIE.Count > 0 Then
            '                FiltertedDT = FiltertedIE.CopyToDataTable
            '                FiltertedDT.TableName = "SEARCH RESULTS"
            '                TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '            End If

            '        Case "Ends With"
            '            Dim FiltertedDT As DataTable
            '            Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From P In Processes_DS.Tables(0).AsEnumerable()
            '                                                                      Let CurrentR = P Where Processes_DS.Tables(0).Columns.Cast(Of DataColumn).Any(
            '                                                Function(Col As DataColumn) P.Item(Col.ColumnName).ToString.ToLower.EndsWith(SearchText.ToLower))
            '                                                                      Select CurrentR)

            '            If FiltertedIE.Count > 0 Then
            '                FiltertedDT = FiltertedIE.CopyToDataTable
            '                FiltertedDT.TableName = "SEARCH RESULTS"
            '                TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '            End If

            '        Case "Contains"

            '            Dim FiltertedDT As DataTable
            '            Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = (From P In Processes_DS.Tables(0).AsEnumerable()
            '                                                                      Let CurrentR = P Where Processes_DS.Tables(0).Columns.Cast(Of DataColumn).Any(
            '                                                Function(Col As DataColumn) P.Item(Col.ColumnName).ToString.ToLower.Contains(SearchText.ToLower))
            '                                                                      Select CurrentR)

            '            If FiltertedIE.Count > 0 Then
            '                FiltertedDT = FiltertedIE.CopyToDataTable
            '                FiltertedDT.TableName = "SEARCH RESULTS"
            '                TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            '            End If

            '    End Select

            'ElseIf SearchText = "*" Then

            Dim FiltertedDT As DataTable
            Dim FiltertedIE As EnumerableRowCollection(Of DataRow) = Processes_DS.Tables(0).AsEnumerable()

            If FiltertedIE.Count > 0 Then
                FiltertedDT = FiltertedIE.CopyToDataTable
                FiltertedDT.TableName = "SEARCH RESULTS"
                TabGenerationDS.Tables.Add(FiltertedDT.Copy)
            End If

        End If

        'End If

        For Each MyTab As DataTable In TabGenerationDS.Tables
            MyTab.PrimaryKey = New DataColumn() {MyTab.Columns("ProcessExeFile")}
        Next

        For Each DatTable As DataTable In TabGenerationDS.Tables ' Processes_DS.Tables

            ReDim Preserve ProcessesDGV(ProcessesDGVCount)
            ProcessesDGV(ProcessesDGVCount) = New DataGridView

            tbcProcesses.TabPages.Add(DatTable.TableName, DatTable.TableName)

            tbcProcesses.TabPages.Item(DatTable.TableName).Controls.Add(ProcessesDGV(ProcessesDGVCount))
            DefaultDataGridView(ProcessesDGV(ProcessesDGVCount), DatTable.TableName)

            ReDim Preserve ColumnChooserDGV(ColumnChooserDGVCount)
            ColumnChooserDGV(ColumnChooserDGVCount) = New clsDGVColumnChooser(ProcessesDGV(ProcessesDGVCount))

            ProcessesDGV(ProcessesDGVCount).DataSource = TabGenerationDS 'Processes_DS
            ProcessesDGV(ProcessesDGVCount).DataMember = DatTable.TableName

            ProcessesDGV(ProcessesDGVCount).ClearSelection()

            Dim MyBoundDataGridView As DataGridView = ProcessesDGV(ProcessesDGVCount)

            For Each DatRow As DataGridViewRow In MyBoundDataGridView.Rows

                Dim ThePath As String = DatRow.Cells("PPath").Value.ToString '""

                Dim TheFileName As FileInfo = New FileInfo(ThePath + "\" + DatRow.Cells("ProcessExeFile").Value.ToString.Replace("*", "").Replace("?", ""))

                If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

                    Dim iconForFile As Icon = SystemIcons.WinLogo

                    iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
                    imlScripts.Images.Add(TheFileName.Extension, iconForFile)

                End If
                Dim MyImageCell As DataGridViewImageCell = CType(DatRow.Cells("FileType"), DataGridViewImageCell)
                MyImageCell.Value = imlScripts.Images.Item(TheFileName.Extension)

                Dim MyImageCellS As DataGridViewImageCell = CType(DatRow.Cells("FileStatus"), DataGridViewImageCell)
                If TheFileName.Exists = True Then
                    MyImageCellS.Value = My.Resources.fileexist
                Else
                    MyImageCellS.Value = My.Resources.filenotfound
                End If

            Next

            'Binding complete event
            'Not 100% happy with this outcome
            AddHandler ProcessesDGV(ProcessesDGVCount).DataBindingComplete, AddressOf UpdateImageListInDGVX

            AddHandler ProcessesDGV(ProcessesDGVCount).SelectionChanged, AddressOf EnableDisableEditButton

            AddHandler ProcessesDGV(ProcessesDGVCount).MouseDown, AddressOf DataDGVMouseDown

            'AddHandler ProcessesDGV(ProcessesDGVCount).CellEndEdit, AddressOf CheckIfLocalHasChanged

            'Cell Formatting event
            'AddHandler ProcessesDGV(ProcessesDGVCount).CellFormatting, AddressOf UpdateImageListInDGV_CF

            'Need to add an event here for Cell Painting
            'UpdateImageListInGDV(ProcessesDGV(ProcessesDGVCount), DatTable.TableName)

            ProcessesDGVCount += 1
        Next

    End Sub

    'Private Sub CheckIfLocalHasChanged(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs)

    '    Dim DGV As DataGridView = CType(sender, DataGridView)

    '    Dim TP As TabPage = DirectCast(DGV.Parent, TabPage)

    '    If TP.Name = "LOCAL" Then
    '        IsLocal_DT_New = True
    '    End If

    'End Sub

    Private Sub DataDGVMouseDown(ByVal sender As Object, ByVal e As MouseEventArgs)
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Dim ht As DataGridView.HitTestInfo
            Dim DGV As DataGridView = CType(sender, DataGridView)
            ht = DGV.HitTest(e.X, e.Y)
            Select Case ht.Type
                Case DataGridViewHitTestType.RowHeader, DataGridViewHitTestType.Cell

                    'determine row and figure out if it is selected or not.
                    DGV.Rows(ht.RowIndex).Selected = True

                    tsmiResetTool.Enabled = False
                    tsmiAddProjectsScripts.Enabled = False

                    'If ProcessesDGV(tbcProcesses.SelectedIndex).DataMember <> "FAVOURITES" Then
                    '    tsmiAddToFavourites.Enabled = True
                    'Else
                    '    tsmiAddToFavourites.Enabled = False
                    'End If

                    cmsRightClickProcess.Show(DGV, e.Location)

            End Select
        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then
            Dim DGV As DataGridView = CType(sender, DataGridView)
            For Each SelRow As DataGridViewRow In DGV.SelectedRows
                DGV.DoDragDrop(SelRow, DragDropEffects.Copy)
            Next
        End If
    End Sub

    Private Sub dgvAppliedProcess_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvAppliedProcess.DragDrop
        Try
            Dim MyType As Type = GetType(DataGridViewRow)
            Dim MyDatARows As DataGridViewRow = CType(e.Data.GetData(MyType), DataGridViewRow)

            'If dgvAppliedProcess.Rows.Contains(MyDatARows) = False Then

            'If IsProcessAlreadyInGrid(MyDatARows) = False Then
            '    CloneRowWithValues(MyDatARows, dgvAppliedProcess)
            'End If

            Dim SelDatRowItem As DataRow = CType(MyDatARows.DataBoundItem, DataRowView).Row

            If Not SelDatRowItem Is Nothing Then

                If Processes_DS.Tables("AppliedProcess").Rows.Find(SelDatRowItem("ProcessEXEFile")) Is Nothing Then
                    Processes_DS.Tables("AppliedProcess").ImportRow(SelDatRowItem)
                Else
                    tsslMessage.Text = "Process already added! - Current Action to Add ignored"
                End If

            End If

            'Else
            'tsslMessage.Text = "Data Row already Exists"
            'End If

        Catch ex As Exception
            MsgBox("Error in Drag & Drop")
        End Try
    End Sub

    Private Sub dgvAppliedProcess_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvAppliedProcess.DragEnter
        e.Effect = DragDropEffects.Copy
    End Sub

    Private Sub EnableDisableEditButton(ByVal sender As Object, ByVal e As EventArgs)

        If DisableUpdate Then Exit Sub

        DisableUpdate = True

        If tbcProcesses.SelectedIndex > -1 AndAlso tbcProcesses.SelectedIndex <= ProcessesDGVCount Then

            Dim MyBoundDataGridView As DataGridView = ProcessesDGV(tbcProcesses.SelectedIndex)
            'Get Primary Key from Selecetd row
            'Get TabName from MyBoundDataGridView.Name
            'Then Test Process_DS_Tables etc for DAT, INI etc

            SetInstructionFile = ""
            SetCodeFile = ""
            SetHelpFile = ""
            Dim TabName As String = MyBoundDataGridView.DataMember

            If MyBoundDataGridView.SelectedRows.Count = 1 AndAlso TabName <> "NETWORK" Then

                Dim TestFileName As String = MyBoundDataGridView.SelectedRows.Item(0).Cells("ProcessExeFile").Value.ToString

                Dim Path As String = MyBoundDataGridView.SelectedRows.Item(0).Cells("PPath").Value.ToString '""

                Dim MyDatRow As DataRow = TabGenerationDS.Tables(TabName).Rows.Find(TestFileName) '  Processes_DS.Tables(TabName).Rows.Find(TestFileName)

                If Not MyDatRow Is Nothing Then
                    If MyDatRow.Item("INI").ToString <> "" Then
                        SetInstructionFile = Path.CombinePath(MyDatRow.Item("INI").ToString)
                    Else
                        If MyDatRow.Item("DAT").ToString <> "" Then
                            SetInstructionFile = Path.CombinePath(MyDatRow.Item("DAT").ToString)
                        Else
                            If MyDatRow.Item("CSV").ToString <> "" Then
                                SetInstructionFile = Path.CombinePath(MyDatRow.Item("CSV").ToString)
                            Else
                                If MyDatRow.Item("XML").ToString <> "" Then
                                    SetInstructionFile = Path.CombinePath(MyDatRow.Item("XML").ToString)
                                End If
                            End If
                        End If
                    End If

                End If

                Select Case TestFileName.Substring(TestFileName.Length - 4).ToUpper
                    Case ".SCR", ".LSP"
                        SetCodeFile = Path.CombinePath(TestFileName)
                    Case ".DLL"
                        SetCodeFile = Path.CombinePath(TestFileName)
                    Case Else
                        SetCodeFile = ""
                End Select

                If MyDatRow.Item("RTF").ToString <> "" Then
                    SetHelpFile = Path.CombinePath(MyDatRow.Item("RTF").ToString)
                Else
                    If MyDatRow.Item("CHM").ToString <> "" Then
                        SetHelpFile = Path.CombinePath(MyDatRow.Item("CHM").ToString)
                    Else
                        If MyDatRow.Item("TXT").ToString <> "" Then
                            SetHelpFile = Path.CombinePath(MyDatRow.Item("TXT").ToString)
                        End If
                    End If
                End If

            End If

        End If

        DisableUpdate = False

    End Sub

    Private Sub tbcProcesses_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tbcProcesses.MouseDown

        If e.Button = Windows.Forms.MouseButtons.Right Then
            'Transpose to Control location

            tsmiResetTool.Enabled = True

            'If HasTabPage(tbcProcesses, "FAVOURITES") Then
            '    tsmiResetFavourites.Enabled = True
            'Else
            '    tsmiResetFavourites.Enabled = False
            'End If

            'If HasTabPage(tbcProcesses, "LOCAL") Then
            '    tsmiResetLocalScripts.Enabled = True
            'Else
            '    tsmiResetLocalScripts.Enabled = False
            'End If

            'If HasTabPage(tbcProcesses, "PROJECT") Then
            '    tsmiResetProjectScripts.Enabled = True
            'Else
            '    tsmiResetProjectScripts.Enabled = False
            'End If

            tsmiAddProjectsScripts.Enabled = True

            tsmiAddToFavourites.Enabled = False
            cmsRightClickProcess.Show(tbcProcesses.PointToScreen(e.Location))
        End If


    End Sub

    Private Function HasTabPage(ByVal TabCon As TabControl, ByVal TabPageSearchName As String) As Boolean

        Dim Found As Boolean = False

        For Each TG As TabPage In TabCon.TabPages
            If TG.Name = TabPageSearchName Then
                Found = True
                Exit For
            End If
        Next

        Return Found

    End Function

    Private Sub tbcProcesses_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tbcProcesses.SelectedIndexChanged

        If tbcProcesses.SelectedIndex > -1 AndAlso tbcProcesses.SelectedIndex <= ProcessesDGVCount Then

            Dim MyBoundDataGridView As DataGridView = ProcessesDGV(tbcProcesses.SelectedIndex)

            MyBoundDataGridView.ClearSelection()

        End If

    End Sub

    Private Sub UpdateImageListInDGVX(ByVal sender As Object, ByVal e As DataGridViewBindingCompleteEventArgs)

        If tbcProcesses.SelectedIndex > -1 AndAlso tbcProcesses.SelectedIndex <= ProcessesDGVCount Then

            Dim MyBoundDataGridView As DataGridView = ProcessesDGV(tbcProcesses.SelectedIndex)

            For Each DatRow As DataGridViewRow In MyBoundDataGridView.Rows

                Dim ThePath As String = DatRow.Cells("PPath").Value.ToString '""

                Dim TheFileName As FileInfo = New FileInfo(ThePath + "\" + DatRow.Cells("ProcessExeFile").Value.ToString.Replace("*", "").Replace("?", ""))

                If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

                    Dim iconForFile As Icon = SystemIcons.WinLogo

                    iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
                    imlScripts.Images.Add(TheFileName.Extension, iconForFile)

                End If

                Dim MyImageCell As DataGridViewImageCell = CType(DatRow.Cells("FileType"), DataGridViewImageCell)
                MyImageCell.Value = imlScripts.Images.Item(TheFileName.Extension)

                Dim MyImageCellS As DataGridViewImageCell = CType(DatRow.Cells("FileStatus"), DataGridViewImageCell)
                If TheFileName.Exists = True Then
                    MyImageCellS.Value = My.Resources.fileexist
                Else
                    MyImageCellS.Value = My.Resources.filenotfound
                End If

            Next
        Else
            Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("Not Correct Index: " & tbcProcesses.SelectedIndex.ToString & vbCrLf)
        End If

    End Sub

    Private Sub DefaultDataGridView(ByRef MyDataGridView As DataGridView, ByVal GridviewName As String, Optional ByVal AllowMultiSelect As Boolean = True)

        Dim ColNum As Integer = 0

        MyDataGridView.Columns.Clear()

        Dim ImgCol As New DataGridViewImageColumn
        ImgCol.Name = "FileType"
        ColNum = MyDataGridView.Columns.Add(ImgCol)
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).Visible = False

        Dim ImgCol2 As New DataGridViewImageColumn
        ImgCol2.Name = "FileStatus"
        ColNum = MyDataGridView.Columns.Add(ImgCol2)
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("ProcessCat", "Category")
        MyDataGridView.Columns(ColNum).DataPropertyName = "ProcessCat"
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("ProcessName", "Name")
        MyDataGridView.Columns(ColNum).DataPropertyName = "ProcessName"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = True

        ColNum = MyDataGridView.Columns.Add("ProcessExeFile", "ProcessExeFile")
        MyDataGridView.Columns(ColNum).DataPropertyName = "ProcessExeFile"
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("ProcessLocation", "Location")
        MyDataGridView.Columns(ColNum).DataPropertyName = "ProcessLocation"
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = True
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
        'If GridviewName.ToUpper = "Applications" Then
        'MyDataGridView.Columns(ColNum).ReadOnly = False
        'Else
        'MyDataGridView.Columns(ColNum).ReadOnly = True
        'End If
        'MyDataGridView.Columns(ColNum).Visible = True

        ColNum = MyDataGridView.Columns.Add("DAT", "DAT File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "DAT"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("INI", "INI File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "INI"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("XML", "XML File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "XML"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("CSV", "CSV File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "CSV"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("TXT", "TXT File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "TXT"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("CHM", "CHM File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "CHM"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("RTF", "RTF Help File")
        MyDataGridView.Columns(ColNum).DataPropertyName = "RTF"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = False

        ColNum = MyDataGridView.Columns.Add("PPath", "PPath")
        MyDataGridView.Columns(ColNum).DataPropertyName = "PPath"
        MyDataGridView.Columns(ColNum).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
        MyDataGridView.Columns(ColNum).ReadOnly = True
        MyDataGridView.Columns(ColNum).Visible = True

        Dim AlternateCellStyle As DataGridViewCellStyle = MyDataGridView.AlternatingRowsDefaultCellStyle
        AlternateCellStyle.BackColor = Color.WhiteSmoke

        Dim DefaultCellStyle As DataGridViewCellStyle = MyDataGridView.DefaultCellStyle

        With MyDataGridView
            .BackgroundColor = dgvFiles.BackColor
            .AllowUserToAddRows = False
            .AllowUserToDeleteRows = False
            .AllowUserToOrderColumns = False
            .AllowUserToResizeColumns = True
            .AllowUserToResizeRows = False
            .AlternatingRowsDefaultCellStyle = AlternateCellStyle
            .DefaultCellStyle = DefaultCellStyle
            .ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
            .CellBorderStyle = DataGridViewCellBorderStyle.Single
            .AutoGenerateColumns = False
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = AllowMultiSelect
            .Dock = DockStyle.Fill
        End With
    End Sub

    Private Sub GetExternalBatchPros(ByVal SearchLocation As String, ByVal TableName As String,
                                     ByRef DT As DataTable,
                                     Optional ByVal ForceReReadLocation As Boolean = False)

        'Dim DT As DataTable

        'Search Local Area - in Folder AutoCAD BatchProcess under MyDocuments
        Dim SearchPath As String = SearchLocation ' RoamingProcessesPath
        Dim RetFiles As String() = Directory.GetFiles(SearchPath & "\", TableName & ".xml", SearchOption.TopDirectoryOnly)

        If RetFiles.Length = 1 AndAlso ForceReReadLocation = False Then

            Dim FStream As FileStream
            Dim TempDS As New DataSet

            Try
                FStream = New FileStream(RetFiles(0), FileMode.Open) ' ListEnt, FileMode.Open)

                TempDS.ReadXml(FStream)

                FStream.Close()

                If TempDS.Tables.Count = 1 Then
                    DT = TempDS.Tables(0).Copy
                    DT.TableName = TableName.ToUpper  '"LOCAL"

                    For Each DatRow As DataRow In DT.Rows
                        DatRow.Item("PPath") = SearchPath
                    Next

                    DT.PrimaryKey = New DataColumn() {DT.Columns("ProcessExeFile")}

                    Processes_DS.Tables(0).Merge(DT)
                    Processes_DS.AcceptChanges()
                Else
                    Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("No Data returned from " & TableName & ".xml" & vbCrLf)
                End If

            Catch ex As Exception
                MsgBox("General Exception has occurred in reading " & TableName & ".xml FIle" + vbCrLf +
                       "Forced ReRead Will occur now")
                ForceReReadLocation = True
            Finally
                TempDS = Nothing
                FStream = Nothing
            End Try

        ElseIf ForceReReadLocation = True Or (RetFiles.Length = 0 AndAlso ForceReReadLocation = False) Then

            Dim BackupUpOfOld As DataTable = Nothing
            If DT IsNot Nothing Then
                If DT.TableName.ToLower = "application" Then
                    BackupUpOfOld = DT.Copy
                End If
            End If

            Dim IsApplication As Boolean = False

            'Create Personla Table
            DT = Processes_DS.Tables(0).Clone
            DT.TableName = TableName.ToUpper  '"LOCAL"

            'If TableName.ToUpper <> "FAVORITES" Then

            'Read File in NON Fav's only as Favs is only XML FIle

            Dim AddPrefix As String = "", HelpText As String = ""
            Dim AddHelper As Boolean = False
            Select Case TableName.ToUpper
                    'Case "PROJECT"
                '   AddPrefix = "?"
                'HelpText = "Project Specific Scripts"
                 '       AddHelper = True
                Case "APPLICATIONS"
                    HelpText = "Application Scripts"
                    AddHelper = True
                    IsApplication = True
                    '  Case "NETWORK"
                    ' HelpText = "Network Specific Scripts"
                    'AddHelper = True
            End Select

            Dim SupportedExeFileTypes As String() = New String() {"*.lsp", "*.vlx", "*.fas", "*.scr", "*.dvb", "*.dll"}
            'Dim SupportedHelperFileTypes As String() = New String() {"*.dat", "*.txt", "*.chm", "*.rtf", "*.ini"}

            Dim FoundExeFiles As IEnumerable = GetFiles(SearchPath & "\", SupportedExeFileTypes, SearchOption.TopDirectoryOnly)

            For Each ExeFile As String In FoundExeFiles

                Dim FoundHelperFiles As IEnumerable = GetFiles(SearchPath, "", SearchOption.TopDirectoryOnly) 'GetFiles(SearchPath, SupportedHelperFileTypes, SearchOption.TopDirectoryOnly)

                Dim DatRow As DataRow = DT.NewRow

                DatRow.Item("ProcessCat") = TableName.ToUpper

                DatRow.Item("ProcessName") = Path.GetFileNameWithoutExtension(ExeFile)
                DatRow.Item("ProcessExeFile") = AddPrefix & Path.GetFileName(ExeFile) '  Path.GetFileName(ExeFile)
                'DatRow.Item("ProcessLocation") = SearchPath

                'For Each HelperFile As String In FoundHelperFiles
                'If HelperFile.Contains(Path.GetFileNameWithoutExtension(ExeFile)) Then
                'DatRow.Item(Path.GetExtension(HelperFile).ToUpper.Replace(".", "")) = Path.GetFileName(HelperFile)
                'End If
                'Next

                'If AddHelper Then
                '    If IsApplication And BackupUpOfOld IsNot Nothing Then

                '        If BackupUpOfOld.Rows.Count > 0 Then

                '            For Each DTR As DataRow In BackupUpOfOld.Rows

                '                If DTR.Item("ProcessExeFile").ToString.ToLower = DatRow.Item("ProcessExeFile").ToString.ToLower Then
                '                    DatRow.Item("ProcessDesc") = DTR.Item("ProcessDesc").ToString
                '                    Exit For
                '                End If

                '            Next

                '        Else
                '            DatRow.Item("ProcessDesc") = HelpText
                '            AddHelper = False
                '        End If
                '    Else
                '        'Do If Databackup exists keep descriptions
                '        DatRow.Item("ProcessDesc") = HelpText
                '        AddHelper = False
                '    End If

                'End If

                DT.Rows.Add(DatRow)

            Next

        End If

        If DT.Rows.Count > 0 Then

            For Each DatRow As DataRow In DT.Rows
                DatRow.Item("PPath") = SearchPath
            Next

            Processes_DS.Tables(0).Merge(DT)
            Processes_DS.AcceptChanges()

            'Select Case TableName.ToUpper
            '    Case "LOCAL"
            '        IsLocal_DT_New = True
            '    Case "FAVOURITES"
            '        IsFavs_DT_New = True
            'End Select

        Else
            'If TableName.ToUpper <> "FAVOURITES" Then
            '    Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("No Processor Files found for " & TableName.ToUpper & vbCrLf & SearchPath & vbCrLf)
            'End If

        End If

        'End If

    End Sub

    Private Sub CopyBundleContentFilesToSuppBP(Optional ByVal OverWrite As Boolean = False)
        Try
            ' If user has a copy of a data file updates on server will not be copied over
            ' Same from install folder
            If OverWrite = True Then
                For Each Fln As String In GetFiles(BatchProcessorRoutineFolder, , SearchOption.TopDirectoryOnly)
                    File.Delete(Fln)
                Next
            End If

            'C:\Users\XXXXXXX\Documents\Jacobs\Jacobs AutoCAD Environmnet R21\BatchProcessor
            'RoamableSupportPathBP = RoamableSupportPath.CombinePath("BatchProcessorRoutines")

            'BundleContentsPath = Settings.Manager.AutoCAD.CachedSettingsFolder.CombinePath("BatchProcessorRoutines")

            CheckAndCopyFile(BundleContentsPath, "*.dat", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.ini", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.xml", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.csv", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.txt", BatchProcessorRoutineFolder, OverWrite)

            CheckAndCopyFile(BundleContentsPath, "*.lsp", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.vlx", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.fas", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.scr", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.dvb", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.chm", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.rtf", BatchProcessorRoutineFolder, OverWrite)
            CheckAndCopyFile(BundleContentsPath, "*.dll", BatchProcessorRoutineFolder, OverWrite)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    'Private Sub CopyLocalContentFilesToSuppBP(Optional ByVal OverWrite As Boolean = False)
    '    Try
    '        ' If user has a copy of a data file updates on server will not be copied over
    '        ' Same from install folder
    '        If OverWrite = True Then
    '            For Each Fln As String In GetFiles(LocalFolder, , SearchOption.TopDirectoryOnly)
    '                File.Delete(Fln)
    '            Next
    '        End If

    '        CheckAndCopyFile(ProcessesFolder, "*.dat", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.ini", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.xml", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.csv", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.txt", LocalFolder, OverWrite)

    '        CheckAndCopyFile(ProcessesFolder, "*.lsp", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.vlx", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.fas", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.scr", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.dvb", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.chm", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.rtf", LocalFolder, OverWrite)
    '        CheckAndCopyFile(ProcessesFolder, "*.dll", LocalFolder, OverWrite)

    '    Catch ex As Exception
    '        Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
    '    End Try
    'End Sub

    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click

        For Each DatRow As DataGridViewRow In ProcessesDGV(tbcProcesses.SelectedIndex).SelectedRows

            'If IsProcessAlreadyInGrid(DatRow) = False Then
            '    CloneRowWithValues(DatRow, dgvAppliedProcess)
            'End If
            Dim SelDatRowItem As DataRow = CType(DatRow.DataBoundItem, DataRowView).Row

            If Not SelDatRowItem Is Nothing Then

                If Processes_DS.Tables("AppliedProcess").Rows.Find(SelDatRowItem("ProcessEXEFile")) Is Nothing Then
                    Processes_DS.Tables("AppliedProcess").ImportRow(SelDatRowItem)
                Else
                    tsslMessage.Text = "Process already added! - Current Action to Add ignored"
                End If

            End If

        Next

    End Sub

    'Private Function IsProcessAlreadyInGrid(ByVal MyDatRow As DataGridViewRow) As Boolean

    '    Dim Ret As Boolean = False

    '    For Each DatRow As DataGridViewRow In dgvAppliedProcess.Rows

    '        If DatRow.Cells("ProcessExeFile").Value Is MyDatRow.Cells("ProcessExeFile").Value Then
    '            Ret = True
    '            Exit For
    '        End If
    '    Next

    '    Return Ret

    'End Function

    Private Sub cmdRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRemove.Click

        If dgvAppliedProcess.SelectedRows.Count > 0 Then

            Dim row As DataGridViewRow = dgvAppliedProcess.SelectedRows(0)
            'dgvAppliedProcess.Rows.Remove(row)

            Dim SelDatRowItem As DataRow = CType(row.DataBoundItem, DataRowView).Row

            If Not SelDatRowItem Is Nothing Then

                If Not Processes_DS.Tables("AppliedProcess").Rows.Find(SelDatRowItem("ProcessEXEFile")) Is Nothing Then
                    Processes_DS.Tables("AppliedProcess").Rows.Remove(SelDatRowItem)
                End If

            End If

        End If

    End Sub

    Private Sub cmdMoveUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdMoveUp.Click
        If dgvAppliedProcess.SelectedRows.Count > 0 Then

            DisableUpdate = True
            Dim DGVRow As DataGridViewRow = dgvAppliedProcess.SelectedRows(0)
            Dim DGVRowIndex As Integer = DGVRow.Index

            Dim SelDatRowItem As DataRow = CType(DGVRow.DataBoundItem, DataRowView).Row
            Dim SelDatRowItemIndex As Integer = Processes_DS.Tables("AppliedProcess").Rows.IndexOf(SelDatRowItem)

            If SelDatRowItemIndex = 0 Then
                DisableUpdate = False
                Return
            End If

            Dim NewRow As DataRow = Processes_DS.Tables("AppliedProcess").NewRow
            NewRow.ItemArray = SelDatRowItem.ItemArray

            Processes_DS.Tables("AppliedProcess").Rows.Remove(SelDatRowItem)
            Processes_DS.Tables("AppliedProcess").AcceptChanges()
            Processes_DS.Tables("AppliedProcess").Rows.InsertAt(NewRow, SelDatRowItemIndex - 1)
            dgvAppliedProcess.Rows(DGVRowIndex - 1).Selected = True
            DisableUpdate = False
        End If
    End Sub

    Private Sub cmdMoveDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdMoveDown.Click
        If dgvAppliedProcess.SelectedRows.Count > 0 Then

            DisableUpdate = True
            Dim DGVRow As DataGridViewRow = dgvAppliedProcess.SelectedRows(0)
            Dim DGVRowIndex As Integer = DGVRow.Index

            Dim SelDatRowItem As DataRow = CType(DGVRow.DataBoundItem, DataRowView).Row
            Dim SelDatRowItemIndex As Integer = Processes_DS.Tables("AppliedProcess").Rows.IndexOf(SelDatRowItem)

            If SelDatRowItemIndex = Processes_DS.Tables("AppliedProcess").Rows.Count - 1 Then
                DisableUpdate = False
                Return
            End If

            Dim NewRow As DataRow = Processes_DS.Tables("AppliedProcess").NewRow
            NewRow.ItemArray = SelDatRowItem.ItemArray

            Processes_DS.Tables("AppliedProcess").Rows.Remove(SelDatRowItem)
            Processes_DS.Tables("AppliedProcess").AcceptChanges()
            Processes_DS.Tables("AppliedProcess").Rows.InsertAt(NewRow, SelDatRowItemIndex + 1)
            dgvAppliedProcess.Rows(DGVRowIndex + 1).Selected = True
            DisableUpdate = False
        End If
    End Sub

    Private Sub tsmAddFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAddFiles.Click


        Dim Ret() As String = AutoCADOpenMultiSelect(My.Computer.FileSystem.SpecialDirectories.MyDocuments,
                                                          "Select Drawing Files...",
                                                          "dwg; *",
                                                          "Drawing Files")
        If Ret.Length > 0 Then

            Dim TheFileNames() As String = Ret 'OpenFileDialog1.FileNames

            For Each Fln As String In TheFileNames

                If FileToProcess_DS.Tables("Files").Rows.Contains(Fln) = False Then

                    Dim TheFileName As FileInfo = New FileInfo(Fln)

                    If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

                        Dim iconForFile As Icon = SystemIcons.WinLogo

                        iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
                        imlScripts.Images.Add(TheFileName.Extension, iconForFile)

                    End If

                    Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

                    FileToAdd.Item("dFileName") = Path.GetFileName(Fln)
                    FileToAdd.Item("dFilePath") = Fln

                    FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)

                End If

            Next

            FileToProcess_DS.Tables("Files").AcceptChanges()
            FileToProcess_DS.AcceptChanges()

        End If

    End Sub

    Private Sub tsmAddFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAddFolder.Click

        'If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

        '    Dim SearchSubFolders As SearchOption

        '    If chkRecurse.CheckState = CheckState.Checked Then
        '        SearchSubFolders = SearchOption.AllDirectories
        '    Else
        '        SearchSubFolders = SearchOption.TopDirectoryOnly
        '    End If

        '    Dim FoundExeFiles As IEnumerable = GetFiles(FolderBrowserDialog1.SelectedPath, New String() {"*.dwg", "*.DWG"}, SearchSubFolders)

        '    For Each Fln As String In FoundExeFiles

        '        If FileToProcess_DS.Tables("Files").Rows.Contains(Fln) = False Then

        '            Dim TheFileName As FileInfo = New FileInfo(Fln)

        '            If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

        '                Dim iconForFile As Icon = SystemIcons.WinLogo

        '                iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
        '                imlScripts.Images.Add(TheFileName.Extension, iconForFile)

        '            End If

        '            Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

        '            FileToAdd.Item("dFileName") = Path.GetFileName(Fln)
        '            FileToAdd.Item("dFilePath") = Fln

        '            FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)

        '        End If

        '    Next

        '    FileToProcess_DS.Tables("Files").AcceptChanges()
        '    FileToProcess_DS.AcceptChanges()

        'End If

        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then

                Dim SearchSubFolders As SearchOption

                If chkRecurse.CheckState = CheckState.Checked Then
                    SearchSubFolders = SearchOption.AllDirectories
                Else
                    SearchSubFolders = SearchOption.TopDirectoryOnly
                End If

                Dim FoundExeFiles As IEnumerable = GetFiles(ReturnedFolder, New String() {"*.dwg", "*.DWG"}, SearchSubFolders)

                For Each Fln As String In FoundExeFiles

                    If FileToProcess_DS.Tables("Files").Rows.Contains(Fln) = False Then

                        Dim TheFileName As FileInfo = New FileInfo(Fln)

                        If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

                            Dim iconForFile As Icon = SystemIcons.WinLogo

                            iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
                            imlScripts.Images.Add(TheFileName.Extension, iconForFile)

                        End If

                        Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

                        FileToAdd.Item("dFileName") = Path.GetFileName(Fln)
                        FileToAdd.Item("dFilePath") = Fln

                        FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)

                    End If

                Next

                FileToProcess_DS.Tables("Files").AcceptChanges()
                FileToProcess_DS.AcceptChanges()

            Else
                Acad_MessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If



    End Sub

    Private Sub HelpButtonCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpButtonCode.Click

        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = HelpFile
        Process.Start(startInfo)
        startInfo = Nothing

    End Sub

    Private Sub EditDataFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditDataFileButton.Click

        Dim UseExternalDialog As Boolean = False

        If CodeFile.ToUpper.Contains("DLL") Then

            If System.IO.File.Exists(CodeFile) Then

                Dim XX As New Load_BatchPlugin_Assembly
                XX.LoadAssembly(CodeFile)
                XX.ExecuteSettingsDialog()
                UseExternalDialog = XX.UsingExternalDialog
                XX = Nothing

            Else

                UseExternalDialog = False
            End If

        End If

        If UseExternalDialog = False Then
            Dim startInfo As New ProcessStartInfo
            startInfo.FileName = "notepad.EXE"
            startInfo.Arguments = InstructionFile
            Process.Start(startInfo)
            startInfo = Nothing
        End If

    End Sub

    Private Sub EditCodeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditCodeButton.Click

        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = "notepad.EXE"
        startInfo.Arguments = CodeFile
        Process.Start(startInfo)
        startInfo = Nothing

    End Sub

    'Private Sub tbcProcesses_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles tbcProcesses.SelectedIndexChanged

    '    If IsInitialising Then Exit Sub

    '    'TODO - Adjust the EDIT CODE etc buttons to suit
    '    Select Case tbcProcesses.TabPages.Item(tbcProcesses.SelectedIndex).Name.ToString.ToUpper
    '        Case "NETWORK"

    '        Case "LOCAL"

    '        Case Else

    '    End Select

    'End Sub

    Private Sub dgvFiles_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgvFiles.CellFormatting

        If e.RowIndex > -1 AndAlso e.ColumnIndex = 0 Then

            If Not dgvFiles.Rows.Item(e.RowIndex).Cells("FilePath").Value Is Nothing Then

                Dim Ext As String = dgvFiles.Rows.Item(e.RowIndex).Cells("FilePath").Value.ToString
                Ext = Ext.Substring(Ext.Length - 4)

                'If imlScripts.Images.ContainsKey(Ext) Then

                e.Value = imlScripts.Images.Item(Ext)
                'Dim MyImageCell As DataGridViewImageCell = CType(dgvFiles.Rows.Item(e.RowIndex).Cells("FileType"), DataGridViewImageCell)
                'MyImageCell.Value = imlScripts.Images.Item(TheFileName.Extension)

                ' End If

            End If

        End If

    End Sub

    Private Sub dgvFiles_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgvFiles.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Dim ht As DataGridView.HitTestInfo
            ht = Me.dgvFiles.HitTest(e.X, e.Y)
            Select Case ht.Type
                Case DataGridViewHitTestType.Cell, DataGridViewHitTestType.ColumnHeader, DataGridViewHitTestType.RowHeader, DataGridViewHitTestType.None

                    If dgvFiles.SelectedRows.Count > 0 Then
                        tsmInvertSelction.Enabled = True
                        tsmDeSelectAll.Enabled = True
                        tsmRemoveSelected.Enabled = True
                    Else
                        tsmInvertSelction.Enabled = False
                        tsmDeSelectAll.Enabled = False
                        tsmRemoveSelected.Enabled = False
                    End If

                    If dgvFiles.Rows.Count > 0 Then
                        tsmSelectAll.Enabled = True
                    Else
                        tsmSelectAll.Enabled = False
                    End If

                    cmsRightClickMenu.Show(dgvFiles, New Point(e.X, e.Y))

            End Select
        End If
    End Sub


    Private Sub tsmSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmSelectAll.Click
        dgvFiles.SelectAll()
    End Sub

    Private Sub tsmDeSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmDeSelectAll.Click
        dgvFiles.ClearSelection()
    End Sub

    Private Sub tsmInvertSelction_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmInvertSelction.Click
        For Each row As DataGridViewRow In dgvFiles.Rows
            If row.Selected Then
                row.Selected = False
            Else
                row.Selected = True
            End If
        Next
    End Sub

    Private Sub tsmRemoveSelected_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmRemoveSelected.Click

        For Index As Integer = dgvFiles.SelectedRows.Count - 1 To 0 Step -1
            Dim row As DataGridViewRow = dgvFiles.SelectedRows(Index)
            FileToProcess_DS.Tables("Files").Rows.Remove(FileToProcess_DS.Tables("Files").Rows.Find(row.Cells(2).Value.ToString))
        Next

    End Sub

    Private Sub EnableRun()

        If DisableUpdate Then Exit Sub

        Dim Cont As Boolean = False

        'Tab 1 - Processes applied
        If dgvAppliedProcess.Rows.Count > 0 AndAlso FailedToLoadAllFromFile = False Then

            Cont = False

            'Tab 2 - Checking
            If optSaveOnExit.Checked = True Then

                'check for particular options that require secondary Settings
                If chkSpecifyDifferentFileLocation.CheckState = CheckState.Checked Then

                    If lblDestinationLocation.Text <> "" Then

                        If Directory.Exists(lblDestinationLocation.Text) = True Then

                            Cont = True

                        Else

                            Cont = False
                            tsslMessage.Text = "Override Path is invalid! - Refer TAB 2."

                        End If

                    End If

                Else

                    Cont = True

                End If

            ElseIf optNoSaveOnExit.Checked = True Then

                Cont = True

            End If

            'Tab 2 - Correct Options applied
            If Cont = True Then

                Cont = False

                If dgvFiles.Rows.Count > 0 Then

                    Cont = True

                Else

                    Cont = False
                    tsslMessage.Text = "No Files Selected to Run Processes on! - Refere TAB 3."

                End If

            End If

        Else

            If FailedToLoadAllFromFile = True Then

                tsslMessage.Text = "1 or more LOAD FROM FILE Loaded Processes Do Not Exist!"

            Else

                tsslMessage.Text = "No Applied Processes selected! - Refer TAB 1."

            End If

        End If

        cmdRunFiles.Enabled = Cont

    End Sub

    Private Sub dgvAppliedProcess_RowsAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsAddedEventArgs) Handles dgvAppliedProcess.RowsAdded
        EnableRun()
    End Sub

    Private Sub dgvAppliedProcess_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles dgvAppliedProcess.RowsRemoved
        EnableRun()
    End Sub

    Private Sub dgvFiles_RowsAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsAddedEventArgs) Handles dgvFiles.RowsAdded
        EnableRun()
    End Sub

    Private Sub dgvFiles_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles dgvFiles.RowsRemoved
        EnableRun()
    End Sub

    Private Sub chkSpecifyDifferentFileLocation_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSpecifyDifferentFileLocation.CheckStateChanged

        If DisableUpdate Then Exit Sub

        DisableUpdate = True
        If chkSpecifyDifferentFileLocation.CheckState = CheckState.Checked Then
            chkOverWriteExistingFiles.CheckState = CheckState.Unchecked
            chkMaintainDirectoryStructure.Enabled = True
        ElseIf chkSpecifyDifferentFileLocation.CheckState = CheckState.Unchecked Then
            chkOverWriteExistingFiles.CheckState = CheckState.Checked
            chkMaintainDirectoryStructure.Enabled = False
        End If
        DisableUpdate = False

        EnableRun()
    End Sub

    Private Sub OverWriteExistingFilesCheckBox_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkOverWriteExistingFiles.CheckStateChanged

        If DisableUpdate Then Exit Sub

        DisableUpdate = True
        If chkOverWriteExistingFiles.CheckState = CheckState.Checked Then
            chkSpecifyDifferentFileLocation.CheckState = CheckState.Unchecked
            chkMaintainDirectoryStructure.Enabled = False
        ElseIf chkOverWriteExistingFiles.CheckState = CheckState.Unchecked Then
            chkSpecifyDifferentFileLocation.CheckState = CheckState.Checked
            chkMaintainDirectoryStructure.Enabled = True
        End If
        DisableUpdate = False

        EnableRun()

    End Sub

    Private Sub BackUpFilesToProcess()

        Dim BackupLocation As String = ProcessesFolder.CombinePath("BackUpProcessFiles")

        If Directory.Exists(BackupLocation) Then
            Directory.CreateDirectory(BackupLocation)
        End If

        Dim BackupPath As String = Directory.CreateDirectory(BackupLocation.CombinePath(Now.ToString("yyyyMMdd_hhmmsstt"))).FullName.ToString

        For Each RowInTable As DataRow In FileToProcess_DS.Tables("Files").Rows
            Dim Xfile As String = RowInTable.Item("dFilePath").ToString
            File.Copy(Xfile, BackupPath & "\" & Path.GetFileName(Xfile))
        Next

    End Sub

    Private Function ConfirmMessage() As String

        Dim RunningMessage As String = ""

        RunningMessage += "Batch Processor is about to run:" & vbCrLf
        Dim LineCounter As Integer = 1
        For Each DX As DataRow In Processes_DS.Tables("AppliedProcess").Rows
            RunningMessage += vbTab & LineCounter.ToString & " - " & DX.Item("ProcessExeFile").ToString & " Process / Script" & vbCrLf
            LineCounter += 1
        Next
        RunningMessage += "  (Processes will be run in the order as Displayed above)" & vbCrLf

        RunningMessage += "" & vbCrLf
        RunningMessage += "On Selected Files:" & vbCrLf

        Dim Counter As Integer = 0

        For Each FX As DataRow In FileToProcess_DS.Tables("Files").Rows
            RunningMessage += vbTab & FX.Item("dFileName").ToString & vbCrLf
            Counter += 1
            If Counter > 5 Then
                RunningMessage += vbTab & "....(" & FileToProcess_DS.Tables("Files").Rows.Count.ToString & " in Total)" & vbCrLf
                Exit For
            End If
        Next

        RunningMessage += "" & vbCrLf
        If optSaveOnExit.Checked = True Then

            RunningMessage += "With Save Options as Follows:" & vbCrLf

            If chkSpecifyDifferentFileLocation.Checked Then
                RunningMessage += vbTab & "File Will be saved to a different Location:" & vbCrLf
                RunningMessage += vbTab & lblDestinationLocation.Text & vbCrLf
                If chkMaintainDirectoryStructure.Checked Then
                    RunningMessage += vbTab & "And Directory Structure of Current Files" & vbCrLf
                    RunningMessage += vbTab & "Will be maintained in New Location (As Shown above)" & vbCrLf
                End If
            End If

            If chkOverWriteExistingFiles.Checked Then RunningMessage += vbTab & "Existing Files will be overwritten and" & vbCrLf
            RunningMessage += vbTab & "File to be saved as " & cboOutputFileFormat.SelectedItem.ToString & " File Format" & vbCrLf
            If chkMaintainSaveFidelity.Checked Then RunningMessage += vbTab & "with FILESAVEFIDELITY will be Maintained" & vbCrLf

        Else
            RunningMessage += "Files listed above will NOT get SAVED" & vbCrLf
            RunningMessage += "After Process / Script is run" & vbCrLf
        End If
        RunningMessage += "" & vbCrLf

        RunningMessage += "Refer to Log File Displayed after Process is run for Results" & vbCrLf
        RunningMessage += "" & vbCrLf
        RunningMessage += "Press OK To Confirm and Begin Batch Process" & vbCrLf
        RunningMessage += "Press CANCEL To Return Back to Dialog" & vbCrLf

        Return RunningMessage

    End Function

    Private Sub cmdRunFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRunFiles.Click

        If MsgBox(ConfirmMessage, MsgBoxStyle.OkCancel, "Process Confirmation") = MsgBoxResult.Ok Then

            'Dim DS As New DataSet
            'DS.Tables.Add(Processes_DS.Tables("LOCAL").Copy)

            SaveBacthProDialogSettings()

            Me.Hide()

            If BackUpFiles Then
                BackUpFilesToProcess()
            End If

            'Set Log File
            If ResultLogFile_FLD.Text = "" Then
                'strLogPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal)
                strLogPath = Manager.EvaluateExpression(System.Environment.GetFolderPath(System.Environment.SpecialFolder.CommonDocuments).CombinePath("[MANUFACTURER]" & "\" & "[AEPRODUCTNAME]"))
            Else
                strLogPath = ResultLogFile_FLD.Text
            End If

            strLogPath = strLogPath.CombinePath(Format(Now, "yyyyMMdd_hhmmsstt") & "_Activities" & Common.Settings.Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension))

            Dim LogFile As New clsLogFile(strLogPath, ClearLogFile_chk.Checked)
            Dim Processor As New clsProcessor(LogFile)

            Try

                'Initials Log File
                LogFile.AddLine("------------[ Batch Start time: " & Now.ToString & " ]------------")

                Dim SaveVal As AcSaveAsType

                Select Case cboOutputFileFormat.SelectedItem.ToString

                    Case "AutoCAD 2013 Drawing (*.dwg)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_dwg
                    Case "AutoCAD 2010/LT2010 Drawing (*.dwg)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_dwg
                    Case "AutoCAD 2007/LT2007 Drawing (*.dwg)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2007_dwg
                    Case "AutoCAD 2004/LT2004 Drawing (*.dwg)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2004_dwg
                    Case "AutoCAD 2000/LT2000 Drawing (*.dwg)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2000_dwg
                    Case "AutoCAD R14/LT98/LT97 Drawing (*.dwg)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.acR14_dwg
                    Case "AutoCAD Drawing Template (*.dwt)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_Template
                    Case "AutoCAD R13 DXF (*.dxf)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.acR13_dxf
                    Case "AutoCAD 2010/LT2010 DXF (*.dxf)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2010_dxf
                    Case "AutoCAD 2007/LT2007 DXF (*.dxf)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2007_dxf
                    Case "AutoCAD 2004/LT2004 DXF (*.dxf)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2004_dxf
                    Case "AutoCAD 2000/LT2000 DXF (*.dxf)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2000_dxf
                    Case "AutoCAD R12/LT2 DXF (*.dxf)" : SaveVal = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.acR12_dxf


                End Select

                Processor.SaveAsType(cboOutputFileFormat.SelectedItem.ToString) = SaveVal
                Processor.MaintainStructure = chkMaintainDirectoryStructure.Checked
                Processor.SaveFidelity = chkMaintainSaveFidelity.Checked

                'Pass Processes
                LogFile.AddLine("------------[ Processes ]------------")
                For Each DatRow As DataGridViewRow In dgvAppliedProcess.Rows
                    Processor.AddProcess(DatRow.Cells("PPath").Value.ToString.CombinePath(DatRow.Cells("ProcessExeFile").Value.ToString.Replace("*", "").Replace("?", "")))
                Next

                LogFile.AddLine("------------[ File Modified ]------------")
                For Each RowInTable As DataRow In FileToProcess_DS.Tables("Files").Rows
                    Processor.AddFile(RowInTable.Item("dFilePath").ToString)
                Next

                If chkSpecifyDifferentFileLocation.CheckState = CheckState.Checked Then
                    Processor.OverRightDestinationPath = lblDestinationLocation.Text
                End If

                Dim Prog As New frmBatchProgress(Processor)
                Prog.Go(optSaveOnExit.Checked)
                Prog = Nothing

            Catch ex As Exception

                Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

            Finally

                LogFile.AddLine("------------[ Batch End time: " & Now.ToString & " ]------------")
                LogFile.WriteLogFile()

                LogFile = Nothing

                'Set to Nothing
                Processor = Nothing

            End Try

            'If IsLocal_DT_New Then
            '    SaveXML(TabGenerationDS.Tables("LOCAL"), "Local", LocalFolder & "\Local.xml")
            'End If

            If IsFavs_DT_New Then
                MsgBox("Favourites Is New need to save to XML File", MsgBoxStyle.Critical, "Should Never Appear")
            End If

            Me.Close()

        End If

    End Sub

    Private Sub tabControlX_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabControlX.SelectedIndexChanged

        If dgvAppliedProcess.Rows.Count = 0 Then
            tabControlX.SelectedIndex = 0
        End If

    End Sub

    Private Sub SaveBacthProDialogSettings()

        If System.IO.File.Exists(SaveSettingsFile) Then
            System.IO.File.Delete(SaveSettingsFile)
        End If

        Try

            Dim Settings_DT As New DataTable

            Settings_DT.TableName = "Settings"
            Settings_DT.Columns.Add("SettingName", GetType(System.String))
            Settings_DT.Columns.Add("SettingValue", GetType(System.String))
            'Disabled Steven Houghton 6/11/17
            'SaveDataRow(Settings_DT, "cboFilterType", cboFilterType.SelectedItem.ToString)
            SaveDataRow(Settings_DT, "optSaveOnExit", optSaveOnExit.Checked.ToString)
            SaveDataRow(Settings_DT, "chkSpecifyDifferentFileLocation", chkSpecifyDifferentFileLocation.Checked.ToString)
            SaveDataRow(Settings_DT, "chkOverWriteExistingFiles", chkOverWriteExistingFiles.Checked.ToString)
            SaveDataRow(Settings_DT, "chkMaintainSaveFidelity", chkMaintainSaveFidelity.Checked.ToString)
            SaveDataRow(Settings_DT, "cboOutputFileFormat", cboOutputFileFormat.SelectedItem.ToString)
            SaveDataRow(Settings_DT, "chkMaintainDirectoryStructure", chkMaintainDirectoryStructure.Checked.ToString)
            SaveDataRow(Settings_DT, "optNoSaveOnExit", optNoSaveOnExit.Checked.ToString)
            SaveDataRow(Settings_DT, "chkRecurse", chkRecurse.Checked.ToString)
            SaveDataRow(Settings_DT, "chkSaveFileHistory", chkSaveFileHistory.Checked.ToString)

            If chkSaveFileHistory.Checked = False Then
                SaveDataRow(Settings_DT, "FileCount", "0")
            Else
                SaveDataRow(Settings_DT, "FileCount", FileToProcess_DS.Tables("Files").Rows.Count.ToString)

                Dim Counter As Integer = 0
                For Each RowInTable As DataRow In FileToProcess_DS.Tables("Files").Rows
                    Dim Xfile As String = RowInTable.Item("dFilePath").ToString
                    SaveDataRow(Settings_DT, Counter.ToString & "File", Xfile)
                    Counter += 1
                Next
            End If

            Settings_DT.AcceptChanges()

            SaveXML(Settings_DT, "DialogSettings", SaveSettingsFile)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub RestorePreviousSettings()

        Dim FStream As FileStream
        Dim TempDS As New DataSet

        Try

            FStream = New FileStream(SaveSettingsFile, FileMode.Open) ' ListEnt, FileMode.Open)

            TempDS.ReadXml(FStream)

            FStream.Close()

            If TempDS.Tables.Count > 0 Then
                TempDS.Tables(0).PrimaryKey = New DataColumn() {TempDS.Tables(0).Columns("SettingName")}
                TempDS.Tables(0).AcceptChanges()

                Dim Settings_DT As DataTable = TempDS.Tables(0)
                'Disabled Steven Houghton 6/11/17
                'cboFilterType.SelectedItem = RestoreSettingValue(Settings_DT, "cboFilterType")
                optSaveOnExit.Checked = RestoreSettingValue(Settings_DT, "optSaveOnExit").IsTrue
                chkSpecifyDifferentFileLocation.Checked = RestoreSettingValue(Settings_DT, "chkSpecifyDifferentFileLocation").IsTrue
                chkOverWriteExistingFiles.Checked = RestoreSettingValue(Settings_DT, "chkOverWriteExistingFiles").IsTrue
                chkMaintainSaveFidelity.Checked = RestoreSettingValue(Settings_DT, "chkMaintainSaveFidelity").IsTrue
                cboOutputFileFormat.SelectedItem = RestoreSettingValue(Settings_DT, "cboOutputFileFormat")
                chkMaintainDirectoryStructure.Checked = RestoreSettingValue(Settings_DT, "chkMaintainDirectoryStructure").IsTrue
                optNoSaveOnExit.Checked = RestoreSettingValue(Settings_DT, "optNoSaveOnExit").IsTrue
                chkRecurse.Checked = RestoreSettingValue(Settings_DT, "chkRecurse").IsTrue
                chkSaveFileHistory.Checked = RestoreSettingValue(Settings_DT, "chkSaveFileHistory").IsTrue

                Dim FileCount As Integer = CType(RestoreSettingValue(Settings_DT, "FileCount"), Integer)

                If FileCount > 0 Then

                    If MsgBox("Do you want to load previous Files?", MsgBoxStyle.YesNo, "Restore Old FileSet") = MsgBoxResult.Yes Then

                        For Index As Integer = 0 To FileCount - 1

                            Dim Fln As String = RestoreSettingValue(Settings_DT, Index.ToString & "File")

                            If File.Exists(Fln) Then

                                If FileToProcess_DS.Tables("Files").Rows.Contains(Fln) = False Then

                                    Dim TheFileName As FileInfo = New FileInfo(Fln)

                                    If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

                                        Dim iconForFile As Icon = SystemIcons.WinLogo

                                        iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
                                        imlScripts.Images.Add(TheFileName.Extension, iconForFile)

                                    End If

                                    Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

                                    FileToAdd.Item("dFileName") = Path.GetFileName(Fln)
                                    FileToAdd.Item("dFilePath") = Fln

                                    FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)

                                End If

                            End If

                        Next

                    End If

                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        Finally
            TempDS = Nothing
            FStream = Nothing
        End Try

    End Sub

    Private Sub SaveDataRow(ByRef SettingDataTable As DataTable, ByVal ControlName As String, ByVal SaveValue As String)

        Dim NewAddRow As DataRow

        NewAddRow = SettingDataTable.NewRow()
        NewAddRow.Item("SettingName") = ControlName
        NewAddRow.Item("SettingValue") = SaveValue
        SettingDataTable.Rows.Add(NewAddRow)

        NewAddRow = Nothing

    End Sub

    Private Function RestoreSettingValue(ByVal Settings As DataTable, ByVal ControlFieldName As String) As String

        Dim DatRow As DataRow = Settings.Rows.Find(ControlFieldName)
        Dim Ret As String = ""

        If Not DatRow Is Nothing Then
            Ret = DatRow.Item("SettingValue").ToString
        End If

        Return Ret

    End Function

    Private Sub cboFilterType_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        If IsInitialising Then Exit Sub
        InitialiseProcessesTabControl()
    End Sub
    'Disabled Steven Houghton 6/11/17
    'Private Sub txtSearchVal_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If txtSearchVal.Text.Length = 0 Then
    '        lblSearchWhat.Visible = False
    '        cboSearchWhat.Visible = False
    '        cmdSearch.Visible = False
    '        lblSearchCondition.Visible = False
    '        cboSearchCondition.Visible = False
    '    Else
    '        lblSearchWhat.Visible = True
    '        cboSearchWhat.Visible = True
    '        cmdSearch.Visible = True
    '        lblSearchCondition.Visible = True
    '        cboSearchCondition.Visible = True
    '    End If
    'End Sub

    Private Sub tsmiAddToFavourites_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmiAddToFavourites.Click

        'Make a DataRowCopy to the Datatable with Favs
        If ProcessesDGV(tbcProcesses.SelectedIndex).SelectedRows.Count > 0 Then

            Dim TableName As String = ProcessesDGV(tbcProcesses.SelectedIndex).DataMember  ' ""

            'If TableName <> "FAVOURITES" AndAlso TableName <> "" Then

            '    For Each DatRow As DataGridViewRow In ProcessesDGV(tbcProcesses.SelectedIndex).SelectedRows

            '        Dim PKey As String = DatRow.Cells("ProcessExeFile").Value.ToString

            '        If Favs_DT.Rows.Find(PKey) Is Nothing Then

            '            Dim DTRow As DataRow = Nothing
            '            Select Case TableName.ToUpper
            '                Case "LOCAL"
            '                    DTRow = Local_DT.Rows.Find(PKey)
            '                Case "NETWORK"
            '                    DTRow = Network_DT.Rows.Find(PKey)
            '                Case "PROJECT"
            '                    DTRow = Proj_DT.Rows.Find(PKey)
            '                Case Else
            '                    DTRow = Processes_DS.Tables(0).Rows.Find(PKey)
            '            End Select

            '            If Not DTRow Is Nothing Then
            '                Favs_DT.ImportRow(DTRow)
            '                Favs_DT.AcceptChanges()
            '                Dim EditRow As DataRow = Favs_DT.Rows.Find(PKey)
            '                EditRow.Item("ProcessCat") = "FAVOURITES"
            '                EditRow.Item("ProcessExeFile") = "*" & EditRow.Item("ProcessExeFile").ToString
            '                Favs_DT.AcceptChanges()
            '            End If

            '        End If

            '    Next

            '    'SaveXML(Favs_DT, "Favourites", FavouritesFolder + "\Favourites.xml")
            '    InitialiseFrontPageOfForm(True, False, False)

            'End If

        End If

    End Sub

    Private Sub SaveXML(ByVal DT As DataTable, ByVal PDesc As String, ByVal FilePath As String)

        If DT.Rows.Count > 0 Then
            Dim TempDS As New DataSet
            TempDS.Tables.Add(DT.Copy)
            TempDS.AcceptChanges()

            If File.Exists(FilePath) Then
                File.Delete(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Processes have been deleted" & vbCrLf)
                TempDS.WriteXml(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Processes have been ReWritten!" & vbCrLf)
            Else
                TempDS.WriteXml(FilePath)
            End If
        End If

    End Sub

    Private Sub tsmiResetScripts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmiResetScripts.Click
        InitialiseFrontPageOfForm(True, True, False)
    End Sub

    Private Sub tsmiResetLocalScripts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmiResetLocalScripts.Click
        InitialiseFrontPageOfForm(True, False, True)
    End Sub

    'Private Sub tsmiResetFavourites_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmiResetFavourites.Click

    '    If File.Exists(FavouritesFolder + "\Favourites.xml") Then
    '        File.Delete(FavouritesFolder + "\Favourites.xml")
    '        Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("Favourites Processes have been deleted" & vbCrLf)
    '    End If

    '    InitialiseFrontPageOfForm(True, False, False)

    'End Sub

    'Private Sub tsmiResetProjectScripts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmiResetProjectScripts.Click

    '    If File.Exists(ProjectFolder + "\Project.xml") Then
    '        File.Delete(ProjectFolder + "\Project.xml")
    '        Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("Project Processes have been deleted" & vbCrLf)
    '        Dim FoundExeFiles As IEnumerable = GetFiles(ProjectFolder, , SearchOption.TopDirectoryOnly)
    '        For Each ExeFile As String In FoundExeFiles
    '            File.Delete(ExeFile)
    '            Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(Path.GetFileName(ExeFile) & " was deleted from Project Processes" & vbCrLf)
    '        Next
    '    End If

    '    InitialiseFrontPageOfForm(True, False, False)

    'End Sub

    Private Sub tsmiAddProjectsScripts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmiAddProjectsScripts.Click
        Try

            'Dim Result As String

            'Result = FolderBrowserDialog1.ShowDialog().ToString()

            'If Result = Windows.Forms.DialogResult.OK.ToString Then

            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.dat", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.ini", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.xml", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.csv", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.txt", RoamableSupportProjPath, True)

            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.lsp", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.vlx", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.fas", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.scr", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.dvb", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.chm", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.rtf", RoamableSupportProjPath, True)
            '    CheckAndCopyFile(FolderBrowserDialog1.SelectedPath, "*.dll", RoamableSupportProjPath, True)

            '    GetExternalBatchPros(RoamableSupportProjPath, "Project", Proj_DT)

            '    If Proj_DT.Rows.Count > 0 Then
            '        SaveXML(Proj_DT, "Project", RoamableSupportProjPath + "\Project.xml")
            '    End If

            '    InitialiseProcessesTabControl()
            'End If


            'Dim ReturnedFolder As String = BrowseForFolder()
            'If ReturnedFolder <> String.Empty Then
            '    If System.IO.Directory.Exists(ReturnedFolder) Then
            '        CheckAndCopyFile(ReturnedFolder, "*.dat", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.ini", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.xml", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.csv", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.txt", ProjectFolder, True)

            '        CheckAndCopyFile(ReturnedFolder, "*.lsp", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.vlx", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.fas", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.scr", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.dvb", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.chm", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.rtf", ProjectFolder, True)
            '        CheckAndCopyFile(ReturnedFolder, "*.dll", ProjectFolder, True)

            '        GetExternalBatchPros(ProjectFolder, "Project", Proj_DT)

            '        If Proj_DT.Rows.Count > 0 Then
            '            SaveXML(Proj_DT, "Project", ProjectFolder + "\Project.xml")
            '        End If

            '        InitialiseProcessesTabControl()
            '    Else
            '        Acad_MessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            '    End If
            'End If



        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        InitialiseProcessesTabControl(True)
    End Sub

    Private Sub optSaveOnExit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optSaveOnExit.CheckedChanged
        If DisableUpdate Then Exit Sub
        DisableUpdate = True
        Select Case optSaveOnExit.Checked
            Case True
                XEnabled(pnlFileSaveDetails, True)
                XEnabled(pnlFileNoSaveDetails, False)
            Case False
                XEnabled(pnlFileSaveDetails, False)
                XEnabled(pnlFileNoSaveDetails, True)
        End Select
        DisableUpdate = False
        EnableRun()
    End Sub

    Private Sub optNoSaveOnExit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles optNoSaveOnExit.CheckedChanged
        If DisableUpdate Then Exit Sub
        DisableUpdate = True
        Select Case optNoSaveOnExit.Checked
            Case True
                XEnabled(pnlFileSaveDetails, False)
                XEnabled(pnlFileNoSaveDetails, True)
            Case False
                XEnabled(pnlFileSaveDetails, True)
                XEnabled(pnlFileNoSaveDetails, False)
        End Select
        DisableUpdate = False
        EnableRun()
    End Sub

    Private Sub dgvFiles_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvFiles.DragDrop

        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim WEFiles() As String
            Dim i As Integer

            ' Assign the files to an array.
            WEFiles = CType(e.Data.GetData(DataFormats.FileDrop), String())
            ' Loop through the array and add the files to the list.
            For i = 0 To WEFiles.Length - 1

                Dim CurrentFile As System.IO.FileInfo = My.Computer.FileSystem.GetFileInfo(WEFiles(i).ToString)

                'Does the file exist
                If CurrentFile.Exists Then

                    'is it a dwg
                    If CurrentFile.FullName.ToString.ToLower.EndsWith("dwg") Then

                        If Not (imlScripts.Images.ContainsKey(CurrentFile.Extension)) Then

                            Dim iconForFile As Icon = SystemIcons.WinLogo

                            iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(CurrentFile.ToString)
                            imlScripts.Images.Add(CurrentFile.Extension, iconForFile)

                        End If

                        'Create New Row
                        Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

                        FileToAdd.Item("dFileName") = Path.GetFileName(CurrentFile.FullName)
                        FileToAdd.Item("dFilePath") = CurrentFile.FullName

                        'Check if the Datarow would exist
                        If FileToProcess_DS.Tables("Files").Rows.IndexOf(FileToAdd) = -1 Then

                            'add the row
                            FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)
                            FileToProcess_DS.Tables("Files").AcceptChanges()

                        Else

                            FileToProcess_DS.Tables("Files").RejectChanges()

                        End If

                    End If 'Is Dwg

                End If 'Is file exist

            Next 'Step thru selected Files

        End If
    End Sub

    Private Sub dgvFiles_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvFiles.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.All
        End If
    End Sub

    Private Sub dgvFiles_DragOver(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvFiles.DragOver
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.All
        End If
    End Sub

    Private Sub cmdSaveList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveList.Click

        Dim MyDT As DataTable = GetDGVContentAsDataTable(dgvAppliedProcess)

        If Not MyDT Is Nothing Then

            MyDT.TableName = "SAVELIST"

            For Each DatRow As DataRow In MyDT.Rows
                DatRow(0) = ""
                DatRow(1) = ""
            Next

            MyDT.Columns.RemoveAt(0)
            MyDT.AcceptChanges()

            MyDT.Columns(0).ColumnName = "Status"

            Dim saveFileDialog1 As New SaveFileDialog()
            saveFileDialog1.Filter = "Saved EXE List|*.xml"
            saveFileDialog1.Title = "Save Execution Process List"
            saveFileDialog1.ShowDialog()

            ' If the file name is not an empty string open it for saving.
            If saveFileDialog1.FileName <> "" Then

                SaveXML(MyDT, "EXELIST", saveFileDialog1.FileName)

            End If

        End If

    End Sub

    Private Sub cmdLoadList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLoadList.Click

        DisableUpdate = True

        Dim FStream As FileStream
        Dim TempDS As New DataSet

        Try

            Dim openFileDialog1 As OpenFileDialog = New OpenFileDialog

            ' Set filter options and filter index.
            openFileDialog1.Filter = "Saved EXE List|*.xml"
            openFileDialog1.Title = "Restore Execution Process List"
            openFileDialog1.FilterIndex = 1

            openFileDialog1.Multiselect = False

            FailedToLoadAllFromFile = False

            If openFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

                FStream = New FileStream(openFileDialog1.FileName, FileMode.Open) ' ListEnt, FileMode.Open)

                TempDS.ReadXml(FStream)

                FStream.Close()

                If TempDS.Tables.Count > 0 Then

                    For Each DatRow As DataRow In TempDS.Tables(0).Rows
                        Processes_DS.Tables("AppliedProcess").ImportRow(DatRow)
                    Next

                    For Each DatRowDGV As DataGridViewRow In dgvAppliedProcess.Rows

                        Dim DatRowItem As DataRow = CType(DatRowDGV.DataBoundItem, DataRowView).Row
                        Dim TestFile As String = DatRowItem("PPath").ToString.CombinePath(DatRowItem("ProcessEXEFile").ToString.Replace("?", ""))

                        If File.Exists(TestFile) = False Then

                            DatRowDGV.DefaultCellStyle.BackColor = Color.Red
                            FailedToLoadAllFromFile = True

                        End If

                    Next

                End If

            End If

        Catch ex As Exception
            MsgBox("General Exception has occurred in reading BatchProcessor.xml FIle" + vbCrLf + ex.Message)

        Finally
            TempDS = Nothing
            FStream = Nothing
        End Try

        DisableUpdate = False

    End Sub

    Private Sub cmdBrowseForDestination_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowseForDestination.Click

        Try

            Dim ReturnedFolder As String = BrowseForFolder()
            If ReturnedFolder <> String.Empty Then
                If System.IO.Directory.Exists(ReturnedFolder) Then
                    lblDestinationLocation.Text = ReturnedFolder
                    EnableRun()
                Else
                    Acad_MessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
                End If
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub frmBatchProcessor_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub
End Class

Class Load_BatchPlugin_Assembly
    Inherits MarshalByRefObject
    Private _assembly As Assembly
    Private MyType As System.Type = Nothing
    Private inst As Object = Nothing
    Private CodeFile As String
    Private UseExternalDialog As Boolean = False

    Public Overrides Function InitializeLifetimeService() As Object
        Return Nothing
    End Function

    Public Sub LoadAssembly(ByVal path As String)
        CodeFile = path
        _assembly = Assembly.Load(File.ReadAllBytes(CodeFile)) ' AssemblyName.GetAssemblyName(path))
    End Sub

    Public ReadOnly Property UsingExternalDialog() As Boolean
        Get
            Return UseExternalDialog
        End Get
    End Property

    Public Function ExecuteSettingsDialog() As Object

        MyType = _assembly.GetType(_assembly.GetName.Name.ToString)

        If MyType = Nothing Then

            Acad_MessageBox("Error loading: " & _assembly.GetName.Name.ToString & vbCrLf &
                   "Either the file or one of it's dependencies could not be found", , , , , , , True, logName)
            UseExternalDialog = False
            Return Nothing
            Exit Function

        End If
        inst = _assembly.CreateInstance(MyType.FullName)

        Dim ExeClass As BatchPlugin.iBatchPlugin = DirectCast(inst, BatchPlugin.iBatchPlugin)

        If ExeClass.HasSettingsDialog = True Then

            UseExternalDialog = True
            ExeClass.ShowSettingsDialog(CodeFile)

        Else
            UseExternalDialog = False
        End If

        Return Nothing
    End Function
End Class
