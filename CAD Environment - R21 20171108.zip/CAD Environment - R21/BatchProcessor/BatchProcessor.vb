Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports System.Collections.Specialized
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.Geometry
Imports System.Collections.Generic
Imports Autodesk.AutoCAD.PlottingServices
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.BatchProcessor.BatchProcessor))> 

Public Class BatchProcessor

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_BatchProcessor", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub BatchProcessX()
        Try
            Dim fbp As New BatchProcessorForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModelessDialog(fbp)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

End Class
