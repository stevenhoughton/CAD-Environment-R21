﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BatchProcessorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BatchProcessorForm))
        Me.cmsRightClickMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tsmAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAddFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAddFolder = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmRemoveSelected = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSelectAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmInvertSelction = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDeSelectAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.tsslMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsslProgBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.pnlButtonBtm = New System.Windows.Forms.Panel()
        Me.chkSaveFileHistory = New System.Windows.Forms.CheckBox()
        Me.cmdRunFiles = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.pnlMainArea = New System.Windows.Forms.Panel()
        Me.tabControlX = New System.Windows.Forms.TabControl()
        Me.tpcScripts = New System.Windows.Forms.TabPage()
        Me.spcProcsses = New System.Windows.Forms.SplitContainer()
        Me.tbcProcesses = New System.Windows.Forms.TabControl()
        Me.pnlAvaliableProcessTools = New System.Windows.Forms.Panel()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.EditCodeButton = New System.Windows.Forms.Button()
        Me.EditDataFileButton = New System.Windows.Forms.Button()
        Me.HelpButtonCode = New System.Windows.Forms.Button()
        Me.gbxFilter = New System.Windows.Forms.GroupBox()
        Me.BrowseForApplicationsButton = New System.Windows.Forms.Button()
        Me.ApplicationsTextBox = New System.Windows.Forms.TextBox()
        Me.dgvAppliedProcess = New System.Windows.Forms.DataGridView()
        Me.pnlSelectedScriptsTools = New System.Windows.Forms.Panel()
        Me.cmdSaveList = New System.Windows.Forms.Button()
        Me.cmdLoadList = New System.Windows.Forms.Button()
        Me.cmdMoveUp = New System.Windows.Forms.Button()
        Me.cmdMoveDown = New System.Windows.Forms.Button()
        Me.cmdRemove = New System.Windows.Forms.Button()
        Me.tpcOptions = New System.Windows.Forms.TabPage()
        Me.pnlFileNoSaveDetails = New System.Windows.Forms.GroupBox()
        Me.optNoSaveOnExit = New System.Windows.Forms.RadioButton()
        Me.pnlFileSaveDetails = New System.Windows.Forms.GroupBox()
        Me.chkMaintainDirectoryStructure = New System.Windows.Forms.CheckBox()
        Me.lblDestinationLocation = New System.Windows.Forms.Label()
        Me.cmdBrowseForDestination = New System.Windows.Forms.Button()
        Me.chkSpecifyDifferentFileLocation = New System.Windows.Forms.CheckBox()
        Me.cboOutputFileFormat = New System.Windows.Forms.ComboBox()
        Me.lblOutPut = New System.Windows.Forms.Label()
        Me.ResultLogFile_FLD = New System.Windows.Forms.TextBox()
        Me.ResultLogFile_LBL = New System.Windows.Forms.Label()
        Me.ClearLogFile_chk = New System.Windows.Forms.CheckBox()
        Me.chkOverWriteExistingFiles = New System.Windows.Forms.CheckBox()
        Me.chkMaintainSaveFidelity = New System.Windows.Forms.CheckBox()
        Me.optSaveOnExit = New System.Windows.Forms.RadioButton()
        Me.tpcFiles = New System.Windows.Forms.TabPage()
        Me.dgvFiles = New System.Windows.Forms.DataGridView()
        Me.FileType = New System.Windows.Forms.DataGridViewImageColumn()
        Me.ProcessedFile = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FilePath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblFiles = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkRecurse = New System.Windows.Forms.CheckBox()
        Me.imlScripts = New System.Windows.Forms.ImageList(Me.components)
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.cmsRightClickProcess = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tsmiResetTool = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiResetScripts = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiResetLocalScripts = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiResetFavourites = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiResetProjectScripts = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiAddToFavourites = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmiAddProjectsScripts = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pnlBanner = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.cmsRightClickMenu.SuspendLayout()
        Me.pnlButtonBtm.SuspendLayout()
        Me.pnlMainArea.SuspendLayout()
        Me.tabControlX.SuspendLayout()
        Me.tpcScripts.SuspendLayout()
        CType(Me.spcProcsses, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.spcProcsses.Panel1.SuspendLayout()
        Me.spcProcsses.Panel2.SuspendLayout()
        Me.spcProcsses.SuspendLayout()
        Me.pnlAvaliableProcessTools.SuspendLayout()
        Me.gbxFilter.SuspendLayout()
        CType(Me.dgvAppliedProcess, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSelectedScriptsTools.SuspendLayout()
        Me.tpcOptions.SuspendLayout()
        Me.pnlFileSaveDetails.SuspendLayout()
        Me.tpcFiles.SuspendLayout()
        CType(Me.dgvFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.cmsRightClickProcess.SuspendLayout()
        Me.pnlBanner.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmsRightClickMenu
        '
        Me.cmsRightClickMenu.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.cmsRightClickMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAdd, Me.tsmRemoveSelected, Me.tsmSelectAll, Me.tsmInvertSelction, Me.tsmDeSelectAll})
        Me.cmsRightClickMenu.Name = "cmsRightClickMenu"
        Me.cmsRightClickMenu.Size = New System.Drawing.Size(169, 134)
        '
        'tsmAdd
        '
        Me.tsmAdd.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAddFiles, Me.tsmAddFolder})
        Me.tsmAdd.Name = "tsmAdd"
        Me.tsmAdd.Size = New System.Drawing.Size(168, 26)
        Me.tsmAdd.Text = "Add"
        '
        'tsmAddFiles
        '
        Me.tsmAddFiles.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.file_icon
        Me.tsmAddFiles.Name = "tsmAddFiles"
        Me.tsmAddFiles.Size = New System.Drawing.Size(107, 22)
        Me.tsmAddFiles.Text = "Files"
        '
        'tsmAddFolder
        '
        Me.tsmAddFolder.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.Folder_icon
        Me.tsmAddFolder.Name = "tsmAddFolder"
        Me.tsmAddFolder.Size = New System.Drawing.Size(107, 22)
        Me.tsmAddFolder.Text = "Folder"
        '
        'tsmRemoveSelected
        '
        Me.tsmRemoveSelected.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.delete_file_icon
        Me.tsmRemoveSelected.Name = "tsmRemoveSelected"
        Me.tsmRemoveSelected.Size = New System.Drawing.Size(168, 26)
        Me.tsmRemoveSelected.Text = "Remove Selected"
        '
        'tsmSelectAll
        '
        Me.tsmSelectAll.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources._select
        Me.tsmSelectAll.Name = "tsmSelectAll"
        Me.tsmSelectAll.Size = New System.Drawing.Size(168, 26)
        Me.tsmSelectAll.Text = "Select All"
        '
        'tsmInvertSelction
        '
        Me.tsmInvertSelction.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.invertselect
        Me.tsmInvertSelction.Name = "tsmInvertSelction"
        Me.tsmInvertSelction.Size = New System.Drawing.Size(168, 26)
        Me.tsmInvertSelction.Text = "Invert Selction"
        '
        'tsmDeSelectAll
        '
        Me.tsmDeSelectAll.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.deselect
        Me.tsmDeSelectAll.Name = "tsmDeSelectAll"
        Me.tsmDeSelectAll.Size = New System.Drawing.Size(168, 26)
        Me.tsmDeSelectAll.Text = "DeSelect All"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 520)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(486, 22)
        Me.StatusStrip1.TabIndex = 41
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'tsslMessage
        '
        Me.tsslMessage.Name = "tsslMessage"
        Me.tsslMessage.Size = New System.Drawing.Size(12, 21)
        Me.tsslMessage.Text = "."
        '
        'tsslProgBar
        '
        Me.tsslProgBar.Name = "tsslProgBar"
        Me.tsslProgBar.Size = New System.Drawing.Size(133, 20)
        '
        'pnlButtonBtm
        '
        Me.pnlButtonBtm.Controls.Add(Me.chkSaveFileHistory)
        Me.pnlButtonBtm.Controls.Add(Me.cmdRunFiles)
        Me.pnlButtonBtm.Controls.Add(Me.Cancel_Button)
        Me.pnlButtonBtm.Controls.Add(Me.cmdHelp)
        Me.pnlButtonBtm.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtonBtm.Location = New System.Drawing.Point(0, 483)
        Me.pnlButtonBtm.MaximumSize = New System.Drawing.Size(0, 37)
        Me.pnlButtonBtm.MinimumSize = New System.Drawing.Size(0, 37)
        Me.pnlButtonBtm.Name = "pnlButtonBtm"
        Me.pnlButtonBtm.Padding = New System.Windows.Forms.Padding(12, 6, 12, 6)
        Me.pnlButtonBtm.Size = New System.Drawing.Size(486, 37)
        Me.pnlButtonBtm.TabIndex = 42
        '
        'chkSaveFileHistory
        '
        Me.chkSaveFileHistory.BackColor = System.Drawing.Color.Transparent
        Me.chkSaveFileHistory.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkSaveFileHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkSaveFileHistory.Location = New System.Drawing.Point(114, 6)
        Me.chkSaveFileHistory.Name = "chkSaveFileHistory"
        Me.chkSaveFileHistory.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkSaveFileHistory.Size = New System.Drawing.Size(155, 23)
        Me.chkSaveFileHistory.TabIndex = 37
        Me.chkSaveFileHistory.Text = "Save File History"
        Me.chkSaveFileHistory.UseVisualStyleBackColor = False
        '
        'cmdRunFiles
        '
        Me.cmdRunFiles.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRunFiles.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRunFiles.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmdRunFiles.Enabled = False
        Me.cmdRunFiles.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRunFiles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRunFiles.Location = New System.Drawing.Point(275, 6)
        Me.cmdRunFiles.Name = "cmdRunFiles"
        Me.cmdRunFiles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRunFiles.Size = New System.Drawing.Size(106, 25)
        Me.cmdRunFiles.TabIndex = 34
        Me.cmdRunFiles.Text = "4. Process Files"
        Me.ToolTip1.SetToolTip(Me.cmdRunFiles, "Process Files Selected")
        Me.cmdRunFiles.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.Dock = System.Windows.Forms.DockStyle.Right
        Me.Cancel_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(381, 6)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(93, 25)
        Me.Cancel_Button.TabIndex = 35
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'cmdHelp
        '
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.Dock = System.Windows.Forms.DockStyle.Left
        Me.cmdHelp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(12, 6)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(81, 25)
        Me.cmdHelp.TabIndex = 36
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'pnlMainArea
        '
        Me.pnlMainArea.Controls.Add(Me.tabControlX)
        Me.pnlMainArea.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMainArea.Location = New System.Drawing.Point(0, 42)
        Me.pnlMainArea.Name = "pnlMainArea"
        Me.pnlMainArea.Padding = New System.Windows.Forms.Padding(6)
        Me.pnlMainArea.Size = New System.Drawing.Size(486, 441)
        Me.pnlMainArea.TabIndex = 43
        '
        'tabControlX
        '
        Me.tabControlX.Controls.Add(Me.tpcScripts)
        Me.tabControlX.Controls.Add(Me.tpcOptions)
        Me.tabControlX.Controls.Add(Me.tpcFiles)
        Me.tabControlX.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabControlX.Location = New System.Drawing.Point(6, 6)
        Me.tabControlX.Name = "tabControlX"
        Me.tabControlX.SelectedIndex = 0
        Me.tabControlX.Size = New System.Drawing.Size(474, 429)
        Me.tabControlX.TabIndex = 0
        '
        'tpcScripts
        '
        Me.tpcScripts.Controls.Add(Me.spcProcsses)
        Me.tpcScripts.Location = New System.Drawing.Point(4, 22)
        Me.tpcScripts.Name = "tpcScripts"
        Me.tpcScripts.Padding = New System.Windows.Forms.Padding(6)
        Me.tpcScripts.Size = New System.Drawing.Size(466, 403)
        Me.tpcScripts.TabIndex = 1
        Me.tpcScripts.Text = "1. Processes / Scripts"
        Me.tpcScripts.UseVisualStyleBackColor = True
        '
        'spcProcsses
        '
        Me.spcProcsses.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spcProcsses.Location = New System.Drawing.Point(6, 6)
        Me.spcProcsses.Name = "spcProcsses"
        Me.spcProcsses.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'spcProcsses.Panel1
        '
        Me.spcProcsses.Panel1.Controls.Add(Me.tbcProcesses)
        Me.spcProcsses.Panel1.Controls.Add(Me.pnlAvaliableProcessTools)
        Me.spcProcsses.Panel1.Controls.Add(Me.gbxFilter)
        '
        'spcProcsses.Panel2
        '
        Me.spcProcsses.Panel2.Controls.Add(Me.dgvAppliedProcess)
        Me.spcProcsses.Panel2.Controls.Add(Me.pnlSelectedScriptsTools)
        Me.spcProcsses.Size = New System.Drawing.Size(454, 391)
        Me.spcProcsses.SplitterDistance = 225
        Me.spcProcsses.TabIndex = 0
        '
        'tbcProcesses
        '
        Me.tbcProcesses.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbcProcesses.Location = New System.Drawing.Point(0, 43)
        Me.tbcProcesses.Name = "tbcProcesses"
        Me.tbcProcesses.SelectedIndex = 0
        Me.tbcProcesses.Size = New System.Drawing.Size(454, 145)
        Me.tbcProcesses.TabIndex = 1
        '
        'pnlAvaliableProcessTools
        '
        Me.pnlAvaliableProcessTools.Controls.Add(Me.cmdAdd)
        Me.pnlAvaliableProcessTools.Controls.Add(Me.EditCodeButton)
        Me.pnlAvaliableProcessTools.Controls.Add(Me.EditDataFileButton)
        Me.pnlAvaliableProcessTools.Controls.Add(Me.HelpButtonCode)
        Me.pnlAvaliableProcessTools.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlAvaliableProcessTools.Location = New System.Drawing.Point(0, 188)
        Me.pnlAvaliableProcessTools.MaximumSize = New System.Drawing.Size(0, 37)
        Me.pnlAvaliableProcessTools.MinimumSize = New System.Drawing.Size(0, 37)
        Me.pnlAvaliableProcessTools.Name = "pnlAvaliableProcessTools"
        Me.pnlAvaliableProcessTools.Padding = New System.Windows.Forms.Padding(0, 4, 0, 4)
        Me.pnlAvaliableProcessTools.Size = New System.Drawing.Size(454, 37)
        Me.pnlAvaliableProcessTools.TabIndex = 0
        '
        'cmdAdd
        '
        Me.cmdAdd.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmdAdd.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdAdd.Location = New System.Drawing.Point(424, 4)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(30, 29)
        Me.cmdAdd.TabIndex = 17
        Me.cmdAdd.Text = "ê"
        Me.ToolTip1.SetToolTip(Me.cmdAdd, "Press Button to Add Seleceted Scripts to Applied Processes Area Below")
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'EditCodeButton
        '
        Me.EditCodeButton.BackColor = System.Drawing.SystemColors.Control
        Me.EditCodeButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.EditCodeButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.EditCodeButton.Enabled = False
        Me.EditCodeButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EditCodeButton.Location = New System.Drawing.Point(104, 4)
        Me.EditCodeButton.Name = "EditCodeButton"
        Me.EditCodeButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EditCodeButton.Size = New System.Drawing.Size(66, 29)
        Me.EditCodeButton.TabIndex = 15
        Me.EditCodeButton.Text = "Edit Code"
        Me.ToolTip1.SetToolTip(Me.EditCodeButton, "Press Button to edit Code of Currently Selected Script File (Not avaiable to all " &
        "Processes)")
        Me.EditCodeButton.UseVisualStyleBackColor = False
        '
        'EditDataFileButton
        '
        Me.EditDataFileButton.BackColor = System.Drawing.SystemColors.Control
        Me.EditDataFileButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.EditDataFileButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.EditDataFileButton.Enabled = False
        Me.EditDataFileButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EditDataFileButton.Location = New System.Drawing.Point(38, 4)
        Me.EditDataFileButton.Name = "EditDataFileButton"
        Me.EditDataFileButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EditDataFileButton.Size = New System.Drawing.Size(66, 29)
        Me.EditDataFileButton.TabIndex = 14
        Me.EditDataFileButton.Text = "Edit Data"
        Me.ToolTip1.SetToolTip(Me.EditDataFileButton, "Press Vutton to Edit Data File assciated with currently selected Script File")
        Me.EditDataFileButton.UseVisualStyleBackColor = False
        '
        'HelpButtonCode
        '
        Me.HelpButtonCode.BackColor = System.Drawing.SystemColors.Control
        Me.HelpButtonCode.Cursor = System.Windows.Forms.Cursors.Default
        Me.HelpButtonCode.Dock = System.Windows.Forms.DockStyle.Left
        Me.HelpButtonCode.Enabled = False
        Me.HelpButtonCode.ForeColor = System.Drawing.SystemColors.ControlText
        Me.HelpButtonCode.Location = New System.Drawing.Point(0, 4)
        Me.HelpButtonCode.Name = "HelpButtonCode"
        Me.HelpButtonCode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.HelpButtonCode.Size = New System.Drawing.Size(38, 29)
        Me.HelpButtonCode.TabIndex = 11
        Me.HelpButtonCode.Text = "Help"
        Me.ToolTip1.SetToolTip(Me.HelpButtonCode, "Press Button to see RTF / Help File")
        Me.HelpButtonCode.UseVisualStyleBackColor = False
        '
        'gbxFilter
        '
        Me.gbxFilter.Controls.Add(Me.BrowseForApplicationsButton)
        Me.gbxFilter.Controls.Add(Me.ApplicationsTextBox)
        Me.gbxFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbxFilter.Location = New System.Drawing.Point(0, 0)
        Me.gbxFilter.MaximumSize = New System.Drawing.Size(0, 90)
        Me.gbxFilter.Name = "gbxFilter"
        Me.gbxFilter.Padding = New System.Windows.Forms.Padding(6, 3, 6, 3)
        Me.gbxFilter.Size = New System.Drawing.Size(454, 43)
        Me.gbxFilter.TabIndex = 2
        Me.gbxFilter.TabStop = False
        Me.gbxFilter.Text = "Navigate to applications"
        '
        'BrowseForApplicationsButton
        '
        Me.BrowseForApplicationsButton.Location = New System.Drawing.Point(370, 16)
        Me.BrowseForApplicationsButton.Name = "BrowseForApplicationsButton"
        Me.BrowseForApplicationsButton.Size = New System.Drawing.Size(75, 23)
        Me.BrowseForApplicationsButton.TabIndex = 21
        Me.BrowseForApplicationsButton.Text = "Browse..."
        Me.BrowseForApplicationsButton.UseVisualStyleBackColor = True
        '
        'ApplicationsTextBox
        '
        Me.ApplicationsTextBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.ApplicationsTextBox.Location = New System.Drawing.Point(6, 16)
        Me.ApplicationsTextBox.Name = "ApplicationsTextBox"
        Me.ApplicationsTextBox.Size = New System.Drawing.Size(359, 20)
        Me.ApplicationsTextBox.TabIndex = 20
        '
        'dgvAppliedProcess
        '
        Me.dgvAppliedProcess.AllowDrop = True
        Me.dgvAppliedProcess.AllowUserToAddRows = False
        Me.dgvAppliedProcess.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvAppliedProcess.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvAppliedProcess.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.dgvAppliedProcess.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvAppliedProcess.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvAppliedProcess.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvAppliedProcess.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvAppliedProcess.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvAppliedProcess.Location = New System.Drawing.Point(37, 0)
        Me.dgvAppliedProcess.MinimumSize = New System.Drawing.Size(0, 110)
        Me.dgvAppliedProcess.Name = "dgvAppliedProcess"
        Me.dgvAppliedProcess.ReadOnly = True
        Me.dgvAppliedProcess.RowTemplate.Height = 24
        Me.dgvAppliedProcess.Size = New System.Drawing.Size(417, 162)
        Me.dgvAppliedProcess.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dgvAppliedProcess, "Processes in this list will be applied in the order of the list to each File")
        '
        'pnlSelectedScriptsTools
        '
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdSaveList)
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdLoadList)
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdMoveUp)
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdMoveDown)
        Me.pnlSelectedScriptsTools.Controls.Add(Me.cmdRemove)
        Me.pnlSelectedScriptsTools.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSelectedScriptsTools.Location = New System.Drawing.Point(0, 0)
        Me.pnlSelectedScriptsTools.MaximumSize = New System.Drawing.Size(37, 0)
        Me.pnlSelectedScriptsTools.MinimumSize = New System.Drawing.Size(37, 0)
        Me.pnlSelectedScriptsTools.Name = "pnlSelectedScriptsTools"
        Me.pnlSelectedScriptsTools.Padding = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.pnlSelectedScriptsTools.Size = New System.Drawing.Size(37, 162)
        Me.pnlSelectedScriptsTools.TabIndex = 1
        '
        'cmdSaveList
        '
        Me.cmdSaveList.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cmdSaveList.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdSaveList.Location = New System.Drawing.Point(4, 46)
        Me.cmdSaveList.Name = "cmdSaveList"
        Me.cmdSaveList.Size = New System.Drawing.Size(29, 29)
        Me.cmdSaveList.TabIndex = 21
        Me.cmdSaveList.Text = "<"
        Me.ToolTip1.SetToolTip(Me.cmdSaveList, "Press Button to Save a List of Applied Processes to XML File")
        Me.cmdSaveList.UseVisualStyleBackColor = True
        '
        'cmdLoadList
        '
        Me.cmdLoadList.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cmdLoadList.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdLoadList.Location = New System.Drawing.Point(4, 75)
        Me.cmdLoadList.Name = "cmdLoadList"
        Me.cmdLoadList.Size = New System.Drawing.Size(29, 29)
        Me.cmdLoadList.TabIndex = 20
        Me.cmdLoadList.Text = "1"
        Me.ToolTip1.SetToolTip(Me.cmdLoadList, "Press Button to Load Saved List of Processes (XML File)")
        Me.cmdLoadList.UseVisualStyleBackColor = True
        '
        'cmdMoveUp
        '
        Me.cmdMoveUp.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cmdMoveUp.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdMoveUp.Location = New System.Drawing.Point(4, 104)
        Me.cmdMoveUp.Name = "cmdMoveUp"
        Me.cmdMoveUp.Size = New System.Drawing.Size(29, 29)
        Me.cmdMoveUp.TabIndex = 19
        Me.cmdMoveUp.Text = "Æ"
        Me.ToolTip1.SetToolTip(Me.cmdMoveUp, "Press Button to Move Selected Process up one line in the list")
        Me.cmdMoveUp.UseVisualStyleBackColor = True
        '
        'cmdMoveDown
        '
        Me.cmdMoveDown.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.cmdMoveDown.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdMoveDown.Location = New System.Drawing.Point(4, 133)
        Me.cmdMoveDown.Name = "cmdMoveDown"
        Me.cmdMoveDown.Size = New System.Drawing.Size(29, 29)
        Me.cmdMoveDown.TabIndex = 18
        Me.cmdMoveDown.Text = "Ä"
        Me.ToolTip1.SetToolTip(Me.cmdMoveDown, "Press Button to Move Selected Process down one line in the list")
        Me.cmdMoveDown.UseVisualStyleBackColor = True
        '
        'cmdRemove
        '
        Me.cmdRemove.Dock = System.Windows.Forms.DockStyle.Top
        Me.cmdRemove.Font = New System.Drawing.Font("Wingdings", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdRemove.Location = New System.Drawing.Point(4, 0)
        Me.cmdRemove.Name = "cmdRemove"
        Me.cmdRemove.Size = New System.Drawing.Size(29, 29)
        Me.cmdRemove.TabIndex = 17
        Me.cmdRemove.Text = "û"
        Me.ToolTip1.SetToolTip(Me.cmdRemove, "Press Button to remove Selected Process")
        Me.cmdRemove.UseVisualStyleBackColor = True
        '
        'tpcOptions
        '
        Me.tpcOptions.Controls.Add(Me.pnlFileNoSaveDetails)
        Me.tpcOptions.Controls.Add(Me.optNoSaveOnExit)
        Me.tpcOptions.Controls.Add(Me.pnlFileSaveDetails)
        Me.tpcOptions.Controls.Add(Me.optSaveOnExit)
        Me.tpcOptions.Location = New System.Drawing.Point(4, 22)
        Me.tpcOptions.Name = "tpcOptions"
        Me.tpcOptions.Padding = New System.Windows.Forms.Padding(6)
        Me.tpcOptions.Size = New System.Drawing.Size(466, 403)
        Me.tpcOptions.TabIndex = 2
        Me.tpcOptions.Text = "2. Options"
        Me.tpcOptions.UseVisualStyleBackColor = True
        '
        'pnlFileNoSaveDetails
        '
        Me.pnlFileNoSaveDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFileNoSaveDetails.Location = New System.Drawing.Point(6, 222)
        Me.pnlFileNoSaveDetails.MinimumSize = New System.Drawing.Size(0, 70)
        Me.pnlFileNoSaveDetails.Name = "pnlFileNoSaveDetails"
        Me.pnlFileNoSaveDetails.Size = New System.Drawing.Size(454, 70)
        Me.pnlFileNoSaveDetails.TabIndex = 7
        Me.pnlFileNoSaveDetails.TabStop = False
        Me.pnlFileNoSaveDetails.Text = "OutPut Options"
        '
        'optNoSaveOnExit
        '
        Me.optNoSaveOnExit.AutoSize = True
        Me.optNoSaveOnExit.Dock = System.Windows.Forms.DockStyle.Top
        Me.optNoSaveOnExit.Location = New System.Drawing.Point(6, 196)
        Me.optNoSaveOnExit.Name = "optNoSaveOnExit"
        Me.optNoSaveOnExit.Padding = New System.Windows.Forms.Padding(0, 6, 0, 3)
        Me.optNoSaveOnExit.Size = New System.Drawing.Size(454, 26)
        Me.optNoSaveOnExit.TabIndex = 6
        Me.optNoSaveOnExit.Text = "DO NOT Saves Files on Exit (used for Data Extraction Processes && Printing)"
        Me.optNoSaveOnExit.UseVisualStyleBackColor = True
        '
        'pnlFileSaveDetails
        '
        Me.pnlFileSaveDetails.BackColor = System.Drawing.Color.Transparent
        Me.pnlFileSaveDetails.Controls.Add(Me.chkMaintainDirectoryStructure)
        Me.pnlFileSaveDetails.Controls.Add(Me.lblDestinationLocation)
        Me.pnlFileSaveDetails.Controls.Add(Me.cmdBrowseForDestination)
        Me.pnlFileSaveDetails.Controls.Add(Me.chkSpecifyDifferentFileLocation)
        Me.pnlFileSaveDetails.Controls.Add(Me.cboOutputFileFormat)
        Me.pnlFileSaveDetails.Controls.Add(Me.lblOutPut)
        Me.pnlFileSaveDetails.Controls.Add(Me.ResultLogFile_FLD)
        Me.pnlFileSaveDetails.Controls.Add(Me.ResultLogFile_LBL)
        Me.pnlFileSaveDetails.Controls.Add(Me.ClearLogFile_chk)
        Me.pnlFileSaveDetails.Controls.Add(Me.chkOverWriteExistingFiles)
        Me.pnlFileSaveDetails.Controls.Add(Me.chkMaintainSaveFidelity)
        Me.pnlFileSaveDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFileSaveDetails.ForeColor = System.Drawing.SystemColors.ControlText
        Me.pnlFileSaveDetails.Location = New System.Drawing.Point(6, 32)
        Me.pnlFileSaveDetails.Name = "pnlFileSaveDetails"
        Me.pnlFileSaveDetails.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.pnlFileSaveDetails.Size = New System.Drawing.Size(454, 164)
        Me.pnlFileSaveDetails.TabIndex = 5
        Me.pnlFileSaveDetails.TabStop = False
        Me.pnlFileSaveDetails.Text = "Output Options"
        '
        'chkMaintainDirectoryStructure
        '
        Me.chkMaintainDirectoryStructure.BackColor = System.Drawing.Color.Transparent
        Me.chkMaintainDirectoryStructure.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkMaintainDirectoryStructure.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkMaintainDirectoryStructure.Location = New System.Drawing.Point(10, 128)
        Me.chkMaintainDirectoryStructure.Name = "chkMaintainDirectoryStructure"
        Me.chkMaintainDirectoryStructure.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkMaintainDirectoryStructure.Size = New System.Drawing.Size(158, 23)
        Me.chkMaintainDirectoryStructure.TabIndex = 10
        Me.chkMaintainDirectoryStructure.Text = "Maintan directory structure"
        Me.chkMaintainDirectoryStructure.UseVisualStyleBackColor = False
        '
        'lblDestinationLocation
        '
        Me.lblDestinationLocation.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDestinationLocation.BackColor = System.Drawing.SystemColors.Window
        Me.lblDestinationLocation.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDestinationLocation.Enabled = False
        Me.lblDestinationLocation.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDestinationLocation.Location = New System.Drawing.Point(11, 44)
        Me.lblDestinationLocation.Name = "lblDestinationLocation"
        Me.lblDestinationLocation.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDestinationLocation.Size = New System.Drawing.Size(438, 24)
        Me.lblDestinationLocation.TabIndex = 6
        '
        'cmdBrowseForDestination
        '
        Me.cmdBrowseForDestination.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBrowseForDestination.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBrowseForDestination.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBrowseForDestination.Location = New System.Drawing.Point(274, 16)
        Me.cmdBrowseForDestination.Name = "cmdBrowseForDestination"
        Me.cmdBrowseForDestination.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBrowseForDestination.Size = New System.Drawing.Size(80, 24)
        Me.cmdBrowseForDestination.TabIndex = 0
        Me.cmdBrowseForDestination.Text = "Browse..."
        Me.cmdBrowseForDestination.UseVisualStyleBackColor = False
        '
        'chkSpecifyDifferentFileLocation
        '
        Me.chkSpecifyDifferentFileLocation.BackColor = System.Drawing.Color.Transparent
        Me.chkSpecifyDifferentFileLocation.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkSpecifyDifferentFileLocation.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkSpecifyDifferentFileLocation.Location = New System.Drawing.Point(10, 16)
        Me.chkSpecifyDifferentFileLocation.Name = "chkSpecifyDifferentFileLocation"
        Me.chkSpecifyDifferentFileLocation.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkSpecifyDifferentFileLocation.Size = New System.Drawing.Size(245, 23)
        Me.chkSpecifyDifferentFileLocation.TabIndex = 1
        Me.chkSpecifyDifferentFileLocation.Text = "Specify a different file save location"
        Me.chkSpecifyDifferentFileLocation.UseVisualStyleBackColor = False
        '
        'cboOutputFileFormat
        '
        Me.cboOutputFileFormat.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboOutputFileFormat.BackColor = System.Drawing.SystemColors.Window
        Me.cboOutputFileFormat.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboOutputFileFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOutputFileFormat.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboOutputFileFormat.Location = New System.Drawing.Point(120, 96)
        Me.cboOutputFileFormat.Name = "cboOutputFileFormat"
        Me.cboOutputFileFormat.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboOutputFileFormat.Size = New System.Drawing.Size(328, 21)
        Me.cboOutputFileFormat.TabIndex = 2
        '
        'lblOutPut
        '
        Me.lblOutPut.AutoSize = True
        Me.lblOutPut.BackColor = System.Drawing.Color.Transparent
        Me.lblOutPut.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPut.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPut.Location = New System.Drawing.Point(10, 102)
        Me.lblOutPut.Name = "lblOutPut"
        Me.lblOutPut.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPut.Size = New System.Drawing.Size(96, 13)
        Me.lblOutPut.TabIndex = 3
        Me.lblOutPut.Text = "Output File Format:"
        Me.lblOutPut.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ResultLogFile_FLD
        '
        Me.ResultLogFile_FLD.AcceptsReturn = True
        Me.ResultLogFile_FLD.BackColor = System.Drawing.SystemColors.Window
        Me.ResultLogFile_FLD.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ResultLogFile_FLD.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ResultLogFile_FLD.Location = New System.Drawing.Point(120, 216)
        Me.ResultLogFile_FLD.MaxLength = 0
        Me.ResultLogFile_FLD.Name = "ResultLogFile_FLD"
        Me.ResultLogFile_FLD.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ResultLogFile_FLD.Size = New System.Drawing.Size(291, 20)
        Me.ResultLogFile_FLD.TabIndex = 4
        Me.ResultLogFile_FLD.Visible = False
        '
        'ResultLogFile_LBL
        '
        Me.ResultLogFile_LBL.AutoSize = True
        Me.ResultLogFile_LBL.BackColor = System.Drawing.SystemColors.Control
        Me.ResultLogFile_LBL.Cursor = System.Windows.Forms.Cursors.Default
        Me.ResultLogFile_LBL.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ResultLogFile_LBL.Location = New System.Drawing.Point(31, 222)
        Me.ResultLogFile_LBL.Name = "ResultLogFile_LBL"
        Me.ResultLogFile_LBL.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ResultLogFile_LBL.Size = New System.Drawing.Size(80, 13)
        Me.ResultLogFile_LBL.TabIndex = 5
        Me.ResultLogFile_LBL.Text = "Result Log File:"
        Me.ResultLogFile_LBL.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ResultLogFile_LBL.Visible = False
        '
        'ClearLogFile_chk
        '
        Me.ClearLogFile_chk.BackColor = System.Drawing.SystemColors.Control
        Me.ClearLogFile_chk.Cursor = System.Windows.Forms.Cursors.Default
        Me.ClearLogFile_chk.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ClearLogFile_chk.Location = New System.Drawing.Point(10, 184)
        Me.ClearLogFile_chk.Name = "ClearLogFile_chk"
        Me.ClearLogFile_chk.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ClearLogFile_chk.Size = New System.Drawing.Size(152, 23)
        Me.ClearLogFile_chk.TabIndex = 8
        Me.ClearLogFile_chk.Text = "Clear result log file"
        Me.ClearLogFile_chk.UseVisualStyleBackColor = False
        Me.ClearLogFile_chk.Visible = False
        '
        'chkOverWriteExistingFiles
        '
        Me.chkOverWriteExistingFiles.BackColor = System.Drawing.Color.Transparent
        Me.chkOverWriteExistingFiles.Checked = True
        Me.chkOverWriteExistingFiles.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkOverWriteExistingFiles.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkOverWriteExistingFiles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkOverWriteExistingFiles.Location = New System.Drawing.Point(11, 71)
        Me.chkOverWriteExistingFiles.Name = "chkOverWriteExistingFiles"
        Me.chkOverWriteExistingFiles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkOverWriteExistingFiles.Size = New System.Drawing.Size(152, 23)
        Me.chkOverWriteExistingFiles.TabIndex = 7
        Me.chkOverWriteExistingFiles.Text = "Overwrite existing files"
        Me.chkOverWriteExistingFiles.UseVisualStyleBackColor = False
        '
        'chkMaintainSaveFidelity
        '
        Me.chkMaintainSaveFidelity.BackColor = System.Drawing.Color.Transparent
        Me.chkMaintainSaveFidelity.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkMaintainSaveFidelity.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkMaintainSaveFidelity.Location = New System.Drawing.Point(191, 71)
        Me.chkMaintainSaveFidelity.Name = "chkMaintainSaveFidelity"
        Me.chkMaintainSaveFidelity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkMaintainSaveFidelity.Size = New System.Drawing.Size(152, 23)
        Me.chkMaintainSaveFidelity.TabIndex = 9
        Me.chkMaintainSaveFidelity.Text = "Maintain Save Fidelity"
        Me.chkMaintainSaveFidelity.UseVisualStyleBackColor = False
        '
        'optSaveOnExit
        '
        Me.optSaveOnExit.AutoSize = True
        Me.optSaveOnExit.Checked = True
        Me.optSaveOnExit.Dock = System.Windows.Forms.DockStyle.Top
        Me.optSaveOnExit.Location = New System.Drawing.Point(6, 6)
        Me.optSaveOnExit.Name = "optSaveOnExit"
        Me.optSaveOnExit.Padding = New System.Windows.Forms.Padding(0, 6, 0, 3)
        Me.optSaveOnExit.Size = New System.Drawing.Size(454, 26)
        Me.optSaveOnExit.TabIndex = 4
        Me.optSaveOnExit.TabStop = True
        Me.optSaveOnExit.Text = "Save Files on Exit"
        Me.optSaveOnExit.UseVisualStyleBackColor = True
        '
        'tpcFiles
        '
        Me.tpcFiles.AllowDrop = True
        Me.tpcFiles.Controls.Add(Me.dgvFiles)
        Me.tpcFiles.Controls.Add(Me.lblFiles)
        Me.tpcFiles.Controls.Add(Me.GroupBox1)
        Me.tpcFiles.Location = New System.Drawing.Point(4, 22)
        Me.tpcFiles.Name = "tpcFiles"
        Me.tpcFiles.Padding = New System.Windows.Forms.Padding(6, 12, 6, 6)
        Me.tpcFiles.Size = New System.Drawing.Size(466, 403)
        Me.tpcFiles.TabIndex = 0
        Me.tpcFiles.Text = "3. Files"
        Me.tpcFiles.UseVisualStyleBackColor = True
        '
        'dgvFiles
        '
        Me.dgvFiles.AllowDrop = True
        Me.dgvFiles.AllowUserToAddRows = False
        Me.dgvFiles.AllowUserToDeleteRows = False
        Me.dgvFiles.AllowUserToResizeColumns = False
        Me.dgvFiles.AllowUserToResizeRows = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvFiles.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvFiles.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.dgvFiles.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFiles.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgvFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFiles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FileType, Me.ProcessedFile, Me.FilePath})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvFiles.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgvFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvFiles.Location = New System.Drawing.Point(6, 93)
        Me.dgvFiles.Name = "dgvFiles"
        Me.dgvFiles.ReadOnly = True
        Me.dgvFiles.RowTemplate.Height = 24
        Me.dgvFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFiles.Size = New System.Drawing.Size(454, 304)
        Me.dgvFiles.TabIndex = 4
        '
        'FileType
        '
        Me.FileType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.FileType.HeaderText = ""
        Me.FileType.Name = "FileType"
        Me.FileType.ReadOnly = True
        Me.FileType.Width = 5
        '
        'ProcessedFile
        '
        Me.ProcessedFile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ProcessedFile.DataPropertyName = "dFileName"
        Me.ProcessedFile.HeaderText = "FileName"
        Me.ProcessedFile.Name = "ProcessedFile"
        Me.ProcessedFile.ReadOnly = True
        Me.ProcessedFile.Width = 76
        '
        'FilePath
        '
        Me.FilePath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.FilePath.DataPropertyName = "dFilePath"
        Me.FilePath.HeaderText = "File Path"
        Me.FilePath.Name = "FilePath"
        Me.FilePath.ReadOnly = True
        '
        'lblFiles
        '
        Me.lblFiles.AutoSize = True
        Me.lblFiles.Dock = System.Windows.Forms.DockStyle.Top
        Me.lblFiles.Location = New System.Drawing.Point(6, 74)
        Me.lblFiles.Name = "lblFiles"
        Me.lblFiles.Padding = New System.Windows.Forms.Padding(0, 3, 0, 3)
        Me.lblFiles.Size = New System.Drawing.Size(225, 19)
        Me.lblFiles.TabIndex = 2
        Me.lblFiles.Text = "Files to Process (Right Click For More Options)"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkRecurse)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(6, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(454, 62)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Options"
        '
        'chkRecurse
        '
        Me.chkRecurse.BackColor = System.Drawing.Color.Transparent
        Me.chkRecurse.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkRecurse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkRecurse.Location = New System.Drawing.Point(6, 19)
        Me.chkRecurse.Name = "chkRecurse"
        Me.chkRecurse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkRecurse.Size = New System.Drawing.Size(147, 23)
        Me.chkRecurse.TabIndex = 5
        Me.chkRecurse.Text = "Include Subfolders"
        Me.chkRecurse.UseVisualStyleBackColor = False
        '
        'imlScripts
        '
        Me.imlScripts.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlScripts.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlScripts.TransparentColor = System.Drawing.Color.Transparent
        '
        'cmsRightClickProcess
        '
        Me.cmsRightClickProcess.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.cmsRightClickProcess.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiResetTool, Me.tsmiAddToFavourites, Me.tsmiAddProjectsScripts})
        Me.cmsRightClickProcess.Name = "cmsRightClickProcess"
        Me.cmsRightClickProcess.Size = New System.Drawing.Size(184, 82)
        '
        'tsmiResetTool
        '
        Me.tsmiResetTool.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmiResetScripts, Me.tsmiResetLocalScripts, Me.tsmiResetFavourites, Me.tsmiResetProjectScripts})
        Me.tsmiResetTool.Name = "tsmiResetTool"
        Me.tsmiResetTool.Size = New System.Drawing.Size(183, 26)
        Me.tsmiResetTool.Text = "Reset"
        '
        'tsmiResetScripts
        '
        Me.tsmiResetScripts.Name = "tsmiResetScripts"
        Me.tsmiResetScripts.Size = New System.Drawing.Size(166, 22)
        Me.tsmiResetScripts.Text = "Global Scripts"
        '
        'tsmiResetLocalScripts
        '
        Me.tsmiResetLocalScripts.Name = "tsmiResetLocalScripts"
        Me.tsmiResetLocalScripts.Size = New System.Drawing.Size(166, 22)
        Me.tsmiResetLocalScripts.Text = "Local Scripts"
        '
        'tsmiResetFavourites
        '
        Me.tsmiResetFavourites.Name = "tsmiResetFavourites"
        Me.tsmiResetFavourites.Size = New System.Drawing.Size(166, 22)
        Me.tsmiResetFavourites.Text = "Favourites Scripts"
        '
        'tsmiResetProjectScripts
        '
        Me.tsmiResetProjectScripts.Name = "tsmiResetProjectScripts"
        Me.tsmiResetProjectScripts.Size = New System.Drawing.Size(166, 22)
        Me.tsmiResetProjectScripts.Text = "Project Scripts"
        '
        'tsmiAddToFavourites
        '
        Me.tsmiAddToFavourites.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.Favorites_icon
        Me.tsmiAddToFavourites.Name = "tsmiAddToFavourites"
        Me.tsmiAddToFavourites.Size = New System.Drawing.Size(183, 26)
        Me.tsmiAddToFavourites.Text = "Add To Favourites"
        '
        'tsmiAddProjectsScripts
        '
        Me.tsmiAddProjectsScripts.Image = Global.Jacobs.AutoCAD.BatchProcessor.My.Resources.Resources.Documents_icon
        Me.tsmiAddProjectsScripts.Name = "tsmiAddProjectsScripts"
        Me.tsmiAddProjectsScripts.Size = New System.Drawing.Size(183, 26)
        Me.tsmiAddProjectsScripts.Text = "Add Projects Scripts"
        '
        'pnlBanner
        '
        Me.pnlBanner.BackgroundImage = CType(resources.GetObject("pnlBanner.BackgroundImage"), System.Drawing.Image)
        Me.pnlBanner.Controls.Add(Me.lblTitle)
        Me.pnlBanner.Controls.Add(Me.LogoPictureBox)
        Me.pnlBanner.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBanner.Location = New System.Drawing.Point(0, 0)
        Me.pnlBanner.Name = "pnlBanner"
        Me.pnlBanner.Size = New System.Drawing.Size(486, 42)
        Me.pnlBanner.TabIndex = 37
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(107, 10)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(188, 27)
        Me.lblTitle.TabIndex = 29
        Me.lblTitle.Text = "Batch Processor"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(100, 44)
        Me.LogoPictureBox.TabIndex = 28
        Me.LogoPictureBox.TabStop = False
        '
        'BatchProcessorForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(486, 542)
        Me.Controls.Add(Me.pnlMainArea)
        Me.Controls.Add(Me.pnlButtonBtm)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.pnlBanner)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(500, 517)
        Me.Name = "BatchProcessorForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.cmsRightClickMenu.ResumeLayout(False)
        Me.pnlButtonBtm.ResumeLayout(False)
        Me.pnlMainArea.ResumeLayout(False)
        Me.tabControlX.ResumeLayout(False)
        Me.tpcScripts.ResumeLayout(False)
        Me.spcProcsses.Panel1.ResumeLayout(False)
        Me.spcProcsses.Panel2.ResumeLayout(False)
        CType(Me.spcProcsses, System.ComponentModel.ISupportInitialize).EndInit()
        Me.spcProcsses.ResumeLayout(False)
        Me.pnlAvaliableProcessTools.ResumeLayout(False)
        Me.gbxFilter.ResumeLayout(False)
        Me.gbxFilter.PerformLayout()
        CType(Me.dgvAppliedProcess, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSelectedScriptsTools.ResumeLayout(False)
        Me.tpcOptions.ResumeLayout(False)
        Me.tpcOptions.PerformLayout()
        Me.pnlFileSaveDetails.ResumeLayout(False)
        Me.pnlFileSaveDetails.PerformLayout()
        Me.tpcFiles.ResumeLayout(False)
        Me.tpcFiles.PerformLayout()
        CType(Me.dgvFiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.cmsRightClickProcess.ResumeLayout(False)
        Me.pnlBanner.ResumeLayout(False)
        Me.pnlBanner.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlBanner As System.Windows.Forms.Panel
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents cmsRightClickMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents tsmAdd As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmRemoveSelected As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmSelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents pnlButtonBtm As System.Windows.Forms.Panel
    Public WithEvents cmdRunFiles As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Friend WithEvents pnlMainArea As System.Windows.Forms.Panel
    Friend WithEvents tabControlX As System.Windows.Forms.TabControl
    Friend WithEvents tpcScripts As System.Windows.Forms.TabPage
    Friend WithEvents tpcOptions As System.Windows.Forms.TabPage
    Friend WithEvents tpcFiles As System.Windows.Forms.TabPage
    Friend WithEvents spcProcsses As System.Windows.Forms.SplitContainer
    Friend WithEvents pnlAvaliableProcessTools As System.Windows.Forms.Panel
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Public WithEvents EditCodeButton As System.Windows.Forms.Button
    Public WithEvents EditDataFileButton As System.Windows.Forms.Button
    Public WithEvents HelpButtonCode As System.Windows.Forms.Button
    Friend WithEvents pnlSelectedScriptsTools As System.Windows.Forms.Panel
    Friend WithEvents cmdRemove As System.Windows.Forms.Button
    Friend WithEvents dgvAppliedProcess As System.Windows.Forms.DataGridView
    Friend WithEvents cmdMoveUp As System.Windows.Forms.Button
    Friend WithEvents cmdMoveDown As System.Windows.Forms.Button
    Friend WithEvents tsmInvertSelction As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDeSelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents imlScripts As System.Windows.Forms.ImageList
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents tsmAddFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAddFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblFiles As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Public WithEvents chkRecurse As System.Windows.Forms.CheckBox
    Friend WithEvents tbcProcesses As System.Windows.Forms.TabControl
    Friend WithEvents dgvFiles As System.Windows.Forms.DataGridView
    Friend WithEvents FileType As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents ProcessedFile As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FilePath As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tsslMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents gbxFilter As System.Windows.Forms.GroupBox
    Friend WithEvents cmsRightClickProcess As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents tsmiResetTool As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiResetScripts As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiResetLocalScripts As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiAddToFavourites As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiAddProjectsScripts As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiResetFavourites As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmiResetProjectScripts As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsslProgBar As System.Windows.Forms.ToolStripProgressBar
    Public WithEvents pnlFileSaveDetails As System.Windows.Forms.GroupBox
    Public WithEvents chkMaintainDirectoryStructure As System.Windows.Forms.CheckBox
    Public WithEvents lblDestinationLocation As System.Windows.Forms.Label
    Public WithEvents cmdBrowseForDestination As System.Windows.Forms.Button
    Public WithEvents chkSpecifyDifferentFileLocation As System.Windows.Forms.CheckBox
    Public WithEvents cboOutputFileFormat As System.Windows.Forms.ComboBox
    Public WithEvents lblOutPut As System.Windows.Forms.Label
    Public WithEvents ResultLogFile_FLD As System.Windows.Forms.TextBox
    Public WithEvents ResultLogFile_LBL As System.Windows.Forms.Label
    Public WithEvents ClearLogFile_chk As System.Windows.Forms.CheckBox
    Public WithEvents chkOverWriteExistingFiles As System.Windows.Forms.CheckBox
    Public WithEvents chkMaintainSaveFidelity As System.Windows.Forms.CheckBox
    Friend WithEvents optSaveOnExit As System.Windows.Forms.RadioButton
    Friend WithEvents optNoSaveOnExit As System.Windows.Forms.RadioButton
    Friend WithEvents pnlFileNoSaveDetails As System.Windows.Forms.GroupBox
    Friend WithEvents cmdSaveList As System.Windows.Forms.Button
    Friend WithEvents cmdLoadList As System.Windows.Forms.Button
    Public WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents chkSaveFileHistory As System.Windows.Forms.CheckBox
    Friend WithEvents ApplicationsTextBox As TextBox
    Friend WithEvents BrowseForApplicationsButton As Button
End Class
