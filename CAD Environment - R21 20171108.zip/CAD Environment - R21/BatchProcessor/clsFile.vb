﻿Imports VB = Microsoft.VisualBasic
Imports Autodesk.AutoCAD
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports System.IO
Imports System.Reflection
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.BatchProcessorPlugin
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension

Public Class clsFile

    Private mDocMan As DocumentCollection = Application.DocumentManager
    Private mCurrentDocument As Document
    Private mCurrentDocumentDB As Autodesk.AutoCAD.DatabaseServices.Database ' database

    Private mFileName As String = ""

    Private mHasProblem As Boolean = True
    Private mProblemsMessage As String = ""

    Public Sub New(ByVal FileName As String)
        'Do nothing
        mFileName = FileName
    End Sub

    Public ReadOnly Property FileName() As String
        Get
            Return mFileName
        End Get
    End Property

    Public Sub OpenFileForProcessing()
        mCurrentDocument = mDocMan.Open(mFileName, False)
        mCurrentDocumentDB = mCurrentDocument.Database
    End Sub

    Public Function ExecuteProcesses(ByVal ProcessNameIncPath As String) As String

        Dim LogString As String = ""

        Dim FileName As String = Path.GetFileName(ProcessNameIncPath)
        Dim FileNameNoExt As String = Path.GetFileNameWithoutExtension(ProcessNameIncPath)
        Dim FilePath As String = Path.GetFullPath(ProcessNameIncPath).Replace("\" & FileName, "")

        Try
            Dim strToExecute As String = ""

            'Set default return value for Process
            LogString = "Process: " & ProcessNameIncPath & " FAILED"

            ' Find the process first in the LocalDrive then in the N:
            If ProcessNameIncPath.ToUpper.EndsWith(".DVB") Then
                If System.IO.File.Exists(ProcessNameIncPath) Then
                    ThisDrawingUtilities.Application.LoadDVB(ProcessNameIncPath)
                    ThisDrawingUtilities.Application.RunMacro("ThisDrawing." & FileNameNoExt)
                    LogString = "Executed DVB: " & ProcessNameIncPath & " Macro: ThisDrawing." & FileNameNoExt
                End If
            End If

            If ProcessNameIncPath.ToUpper.EndsWith(".LSP") Or _
                ProcessNameIncPath.ToUpper.EndsWith(".VLX") Or _
                ProcessNameIncPath.ToUpper.EndsWith(".FAS") Then
                If System.IO.File.Exists(ProcessNameIncPath) Then
                    strToExecute = "(load " & """" & Replace(ProcessNameIncPath, "\", "\\") & """" & ")"
                    ThisDrawingUtilities.SendCommand(strToExecute & vbCr)
                    strToExecute = FileNameNoExt
                    ThisDrawingUtilities.SendCommand(strToExecute & vbCr)
                    LogString = "Loaded Lisp: " & "(load " & """" & Replace(ProcessNameIncPath, "\", "\\") & """" & ")" & " Ran: " & FileNameNoExt
                End If
            End If

            If ProcessNameIncPath.ToUpper.EndsWith(".SCR") Then
                If System.IO.File.Exists(ProcessNameIncPath) Then
                    strToExecute = "(command "".SCRIPT"" " & """" & Replace(ProcessNameIncPath, "\", "\\") & """" & ")"
                    ThisDrawingUtilities.SendCommand(strToExecute & vbCr)
                    LogString = "Ran SCR: " & Replace(ProcessNameIncPath, "\", "\\")
                End If
            End If

            'Command line key in method
            'if i wan to use I need to check to see if DLL is loaded in AutoCAD first.
            'If ProcessNameIncPath.ToUpper.EndsWith(".DLL") Then
            '    If System.IO.File.Exists(ProcessNameIncPath) Then
            '        strToExecute = "(command NETLOAD " & ProcessNameIncPath & ")"
            '        ThisDrawingUtilities.SendCommand(strToExecute & vbCr)
            '        ThisDrawingUtilities.SendCommand(FileNameNoExt)
            '        LogString = "Executed NET DLL: " & ProcessNameIncPath & " Command: " & FileNameNoExt
            '    End If
            'End If

            If ProcessNameIncPath.ToUpper.EndsWith(".DLL") Then

                If System.IO.File.Exists(ProcessNameIncPath) Then

                    Dim b As Byte() = File.ReadAllBytes(ProcessNameIncPath)

                    Dim MyDomain As AppDomain = AppDomain.CreateDomain("JacobsBatchPro")

                    'Dim ProcessAss As Assembly = Assembly.LoadFrom(ProcessNameIncPath)
                    Dim ProcessAss As Assembly = Assembly.LoadFrom(ProcessNameIncPath) 'Load(b)

                    If ProcessAss IsNot Nothing Then

                        Dim ProcType As Type = ProcessAss.GetType(ProcessAss.GetName.Name.ToString)

                        Dim ArgTypes() As Type = New Type() {}
                        Dim ConInfo As ConstructorInfo = ProcType.GetConstructor(ArgTypes)

                        If ConInfo IsNot Nothing Then

                            Dim ProcClass As Object = ConInfo.Invoke(Nothing)
                            If ProcClass IsNot Nothing Then

                                Dim ExeClass As BatchPlugin.iBatchPlugin = DirectCast(ProcClass, BatchPlugin.iBatchPlugin)

                                If ExeClass IsNot Nothing Then
                                    ExeClass.RunProcess(ProcessNameIncPath)
                                    Dim StrMesgX As String = ExeClass.ResultMessage
                                    LogString = "Executed NET DLL: " & ProcessNameIncPath & " Command: RunProcess" & vbCrLf & StrMesgX
                                Else
                                    LogString += LogString & vbCrLf & "Cast To Interface Failed"
                                End If
                                ExeClass = Nothing
                                ProcClass = Nothing
                                ConInfo = Nothing
                                ProcessAss = Nothing
                            Else
                                LogString += LogString & vbCrLf & "Class Creation Failed"
                            End If

                            ProcClass = Nothing
                            ConInfo = Nothing
                            ProcessAss = Nothing
                        Else
                            LogString += LogString & vbCrLf & "Invalid Constructor Info"
                        End If

                        ConInfo = Nothing
                        ProcessAss = Nothing

                    Else
                        LogString += LogString & vbCrLf & "Invalid Type: " & ProcessAss.GetName.Name.ToString
                    End If

                    ProcessAss = Nothing

                Else
                    LogString += LogString & vbCrLf & "DLL Could Not Loaded From: " & vbCrLf & ProcessNameIncPath
                End If

            End If

            'This snippet of code also works but has possibilities
            'If ProcessNameIncPath.ToUpper.EndsWith(".DLL") Then
            '    If System.IO.File.Exists(ProcessNameIncPath) Then
            '        Dim ProcessAss As Assembly = Assembly.LoadFrom(ProcessNameIncPath)
            '        If ProcessAss IsNot Nothing Then
            '            Dim ProcType As Type = ProcessAss.GetType(ProcessAss.GetName.Name.ToString)
            '            If ProcType IsNot Nothing Then
            '                Dim ProcClass As Object = Activator.CreateInstance(ProcType)
            '                If ProcClass IsNot Nothing Then
            '                    Dim ExeCutionMethod As System.Reflection.MethodInfo = ProcClass.GetType.GetMethod("RunProcess")
            '                    If ExeCutionMethod IsNot Nothing Then
            '                        ExeCutionMethod.Invoke(ProcClass, Nothing, Nothing, Nothing, Nothing)
            '                        Dim ResultProperty As System.Reflection.PropertyInfo = ProcClass.GetType.GetProperty("ResultMessage")
            '                        If ResultProperty IsNot Nothing Then
            '                            Dim StrMesgX As Object = ResultProperty.GetValue(ProcClass, Nothing)
            '                            LogString = "Executed NET DLL: " & ProcessNameIncPath & " Command: RunProcess" & vbCrLf & StrMesgX.ToString
            '                        Else
            '                            LogString += LogString & vbCrLf & "Results Property Missing: ResultMessage"
            '                        End If
            '                    Else
            '                        LogString += LogString & vbCrLf & "Execution Method Missing: RunProcess"
            '                    End If
            '                Else
            '                    LogString += LogString & vbCrLf & "Class Creation Failed"
            '                End If
            '            Else
            '                LogString += LogString & vbCrLf & "Invalid Type: " & ProcessAss.GetName.Name.ToString
            '            End If
            '        Else
            '            LogString += LogString & vbCrLf & "DLL Could Not Loaded From: " & vbCrLf & ProcessNameIncPath
            '        End If
            '    Else
            '        LogString += LogString & vbCrLf & "DLL Could Not Be Found" & vbCrLf & ProcessNameIncPath
            '    End If
            'End If



        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            LogString = "Process: " & ProcessNameIncPath & " FAILED"
        End Try

        Return LogString

    End Function

    Public Sub EndFileProcess(ByVal SaveFile As Boolean, ByVal SaveAsType As AcSaveAsType,
                              ByRef Logger As clsLogFile, Optional ByVal DestinationPath As String = "")

        If SaveFile Then

            psave(DestinationPath, Path.GetFileName(mFileName), SaveAsType, [Enum].GetName(GetType(AcSaveAsType), SaveAsType).ToString, False)
            mCurrentDocument.CloseAndDiscard()

        Else

            mCurrentDocument.CloseAndDiscard()
            Logger.AddLine(("---->----> File Closed without Saving "))

        End If

        mCurrentDocument = Nothing

        'mDocMan.CloseAll()

    End Sub

    Public Function psave(ByRef sSavePath As String, ByRef sSaveFile As String, ByRef sFileType As Autodesk.AutoCAD.Interop.Common.AcSaveAsType,
                          ByRef sFileDesc As String, ByRef bOverWriteExistingFilesCheckBox As Boolean) As String

        Dim ResultString As String = ""

        Try

            Dim sfolder As String
            Dim sComparePath As String
            Dim sNewPath As String

            If sSavePath = "" Then
                ThisDrawingUtilities.Save()
                ResultString = ""
            Else

                sNewPath = VB.Left(sSavePath, 2) ' "d:"  'sSavePath

                sComparePath = VB.Right(sSavePath, Len(sSavePath) - 3)
                For Each sfolder In Split(sComparePath, "\")
                    sNewPath = sNewPath & "\" & sfolder
                    If System.IO.Directory.Exists(sNewPath) = False Then
                        ' Path not present it needs to be created
                        My.Computer.FileSystem.CreateDirectory(sNewPath)
                    End If
                Next sfolder

                If Dir(sSavePath & "\" & sSaveFile) <> "" Then

                    If bOverWriteExistingFilesCheckBox = True Then
                        ThisDrawingUtilities.SaveAs(sSavePath & "\" & sSaveFile, sFileType)
                        ResultString = "   Save as " & sFileDesc & " process has overwritten existing file"
                    Else
                        ResultString = "!!!Save as " & sFileDesc & " process not done due to file being present"
                    End If

                Else
                    ThisDrawingUtilities.SaveAs(sSavePath & "\" & sSaveFile, sFileType)
                    ResultString = "   Save as " & sFileDesc & " process performed"
                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            ResultString = ""
        End Try

        Return ResultString
    End Function

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
