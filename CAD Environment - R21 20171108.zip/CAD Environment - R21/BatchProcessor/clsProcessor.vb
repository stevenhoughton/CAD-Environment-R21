﻿Imports Jacobs.Common.Core
Imports System.Collections.Generic
Imports Autodesk.AutoCAD.Interop.Common
Imports System.IO
Imports Jacobs.AutoCAD.Utilities

Public Class clsProcessor

    Private mFilesToProcess As New List(Of clsFile)

    Private LabelProcess As Label
    Private LabelFile As Label

    Private ProgBarFiles As ProgressBar
    Private ProgBarProcess As ProgressBar
    Private mTheLogFile As clsLogFile

    Private mSaveAsTypeAfterProcess As AcSaveAsType
    Private mSaveFidelity As Boolean = False
    Private mDestinationPath As String = ""
    Private mMaintainStructure As Boolean = False

    Private mProcesses As New ArrayList
    'Private mProcessesParaFile1 As New ArrayList
    'Private mProcessesParaFile2 As New ArrayList

    Public Sub New(ByRef MyLogger As clsLogFile)
        mTheLogFile = MyLogger
    End Sub

    Public Sub AddProcess(ByVal ProcessName As String) ', Optional ParameterFile1 As String = " ", Optional ParameterFile2 As String = " ")
        mProcesses.Add(ProcessName)
        mTheLogFile.AddLine("----> Adding Process: " & ProcessName)
        'mProcessesParaFile1.Add(ParameterFile1)
        'mProcessesParaFile2.Add(ParameterFile2)
    End Sub

    Public WriteOnly Property SaveAsType(ByVal DisplayName As String) As AcSaveAsType
        Set(ByVal value As AcSaveAsType)
            mSaveAsTypeAfterProcess = value
            'mTheLogFile.AddLine("----> Setting File Saveas Type : " & [Enum].GetName(GetType(AcSaveAsType), value))
            mTheLogFile.AddLine("----> Setting File Saveas Type : " & DisplayName)
        End Set
    End Property

    Public WriteOnly Property MaintainStructure() As Boolean
        Set(ByVal value As Boolean)
            mMaintainStructure = value
            mTheLogFile.AddLine("----> Setting Maintain Directory Structure : " & mMaintainStructure.ToString)
        End Set
    End Property

    Public WriteOnly Property SaveFidelity() As Boolean
        Set(ByVal value As Boolean)
            mSaveFidelity = value
            mTheLogFile.AddLine("----> Setting Save Fidelity : " & mSaveFidelity.ToString)
        End Set
    End Property

    Public WriteOnly Property OverRightDestinationPath() As String
        Set(ByVal value As String)
            mDestinationPath = value
            mTheLogFile.AddLine("----> Setting Destination To : " & value)
        End Set
    End Property

    Public Sub AddFile(ByVal Filename As String)
        mFilesToProcess.Add(New clsFile(Filename))
        mTheLogFile.AddLine("----> Adding File: " & Filename)
    End Sub

    Public WriteOnly Property ProcessesProgBar() As ProgressBar
        Set(ByVal value As ProgressBar)
            ProgBarProcess = value
        End Set
    End Property

    Public WriteOnly Property FilesProgBar() As ProgressBar
        Set(ByVal value As ProgressBar)
            ProgBarFiles = value
        End Set
    End Property

    Public Sub PassLabelForNotifications(ByRef FileLab As Label, ByRef ProcLab As Label)
        LabelFile = FileLab
        LabelProcess = ProcLab
    End Sub

    'Public Sub ExeCuteProcessOnFiles(ByRef ProgBar As ToolStripProgressBar, Optional SaveOnClose As Boolean = True)
    Public Sub ExeCuteProcessOnFiles(Optional SaveOnClose As Boolean = True)

        Dim Count As Integer = 0

        ProgBarFiles.Minimum = 0
        ProgBarFiles.Maximum = mFilesToProcess.Count

        Dim PrevSaveFidelity As Boolean

        PrevSaveFidelity = ThisDrawingUtilities.GetVariable("SAVEFIDELITY").ToString.IsTrue

        For Each FileToModify As clsFile In mFilesToProcess

            ProgBarFiles.Value = Count + 1
            ProgBarFiles.Refresh()

            LabelFile.Text = "Processing File: " & (Count + 1).ToString & " of " & mFilesToProcess.Count.ToString
            LabelFile.Refresh()

            FileToModify.OpenFileForProcessing()
            mTheLogFile.AddLine("----> Opening File")

            Dim ProcessCounter As Integer = 0

            ProgBarProcess.Minimum = 0
            ProgBarProcess.Maximum = mProcesses.Count

            For Each ProcessX As String In mProcesses

                ProgBarProcess.Value = ProcessCounter + 1
                ProgBarProcess.Refresh()

                LabelProcess.Text = "Running Process: " & (ProcessCounter + 1).ToString & " of " & mProcesses.Count.ToString
                LabelProcess.Refresh()

                mTheLogFile.AddLine("----> Process Started")
                mTheLogFile.AddLine("---->----> " & FileToModify.ExecuteProcesses(ProcessX))
                mTheLogFile.AddLine("<---- Process Started")

                ProcessCounter += 1

            Next

            ProgBarFiles.Value = 0
            ProgBarFiles.Refresh()

            Dim SavePath As String = ""

            If mDestinationPath <> "" Then

                If mMaintainStructure = False Then

                    SavePath = mDestinationPath

                Else
                    ' Need to string together the new path and the old maybe minus the drive letter
                    SavePath = mDestinationPath & Right(Path.GetDirectoryName(FileToModify.FileName), Len(Path.GetDirectoryName(FileToModify.FileName)) - 2)

                End If
            Else
                SavePath = "" ' Path.GetDirectoryName(FileToModify.FileName)
            End If

            FileToModify.EndFileProcess(SaveOnClose, mSaveAsTypeAfterProcess, mTheLogFile, SavePath)
            mTheLogFile.AddLine("<---- File Close")

            Count += 1

        Next

        If Not Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument Is Nothing Then
            ThisDrawingUtilities.SetVariable("SAVEFIDELITY", PrevSaveFidelity)
        End If

    End Sub

End Class
