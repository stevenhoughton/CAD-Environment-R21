﻿Option Strict On
Option Explicit On

Imports System.IO
Imports System.Data
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.GraphicsInterface
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD
Imports Jacobs.AutoCAD.BatchProcessorPlugin

Public Class LayerVisibility
    Implements BatchPlugin.iBatchPlugin, Autodesk.AutoCAD.Runtime.IExtensionApplication

    Public mSettingsTableName As String = "LAYERS VISIBILITY"
    Private mResultMessage As String = ""
    Private mHasSettingsDialog As Boolean = True

    Public Sub Initialize() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Initialize
        Dim Ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        Ed.WriteMessage("Batch Processor Routine Loading..." + vbCrLf +
            "Layer, Thaw, Freeze, On, Off Tool!!")

    End Sub

    Public Sub Terminate() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Terminate
        'Do nothing
    End Sub

    Public ReadOnly Property HasSettingsDialog() As Boolean Implements BatchPlugin.iBatchPlugin.HasSettingsDialog
        Get
            Return mHasSettingsDialog
        End Get
    End Property

    Public ReadOnly Property ResultMessage() As String Implements BatchPlugin.iBatchPlugin.ResultMessage
        Get
            Return mResultMessage
        End Get
    End Property

    'The Command Method is just for Testing.  RunProcess Will Be called from BacthProcessor
    Public Sub RunProcess(Optional ByVal SettingsFilePath As String = "") Implements BatchPlugin.iBatchPlugin.RunProcess

        'Read XML File into Datase
        Dim FStream As FileStream
        Dim TempDS As New DataSet
        Dim ContinueFlag As Boolean = True
        Dim ErrorInMainTry As Boolean = False
        Dim XMLFileToRead As String = ""

        'Dim AssmObj As System.Reflection.Assembly

        Try
            'AssmObj = System.Reflection.Assembly.GetExecutingAssembly
            XMLFileToRead = SettingsFilePath.Replace(".dll", ".xml") 'AssmObj.Location.ToString.Replace(".dll", ".xml")

        Catch ex As Exception
            mResultMessage = "XML Fialed TO Read from : " & XMLFileToRead
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            Try

                FStream = New FileStream(XMLFileToRead, FileMode.Open)

                TempDS.ReadXml(FStream)

                FStream.Close()

                If TempDS.Tables.Count > 0 Then

                    Dim WorkingTable As System.Data.DataTable = TempDS.Tables(0)

                    'Set Primary Key
                    WorkingTable.PrimaryKey = New System.Data.DataColumn() {WorkingTable.Columns("LAYERNAME")}

                    Dim ThisDrawing As Document = Application.DocumentManager.MdiActiveDocument
                    Dim db As Database = ThisDrawing.Database

                    Using ThisDrawing.LockDocument()

                        Using tr As Transaction = db.TransactionManager.StartTransaction()

                            Dim lt As LayerTable = DirectCast(tr.GetObject(db.LayerTableId, OpenMode.ForRead), LayerTable)

                            'Step Thru Each Layer
                            For Each ltrId As ObjectId In lt

                                'Make sure Current is no test Layer
                                If db.Clayer <> ltrId Then

                                    'Get Layer Object
                                    Dim ltr As LayerTableRecord = DirectCast(tr.GetObject(ltrId, OpenMode.ForWrite), LayerTableRecord)

                                    'See if the next layer is in the Datatable
                                    Dim FoundDatRow As DataRow = WorkingTable.Rows.Find(ltr.Name)

                                    'Does current layer Exist in the DataTable Of Layer Mods
                                    If Not FoundDatRow Is Nothing Then

                                        If FoundDatRow.Item("FROZEN").ToString.ToUpper.Trim <> "" Then
                                            If FoundDatRow.Item("FROZEN").ToString.ToUpper = "TRUE" Then
                                                ltr.IsFrozen = True
                                            Else
                                                ltr.IsFrozen = False
                                            End If
                                        End If

                                        If FoundDatRow.Item("OFF").ToString.ToUpper.Trim <> "" Then
                                            If FoundDatRow.Item("OFF").ToString.ToUpper = "TRUE" Then
                                                ltr.IsOff = True
                                            Else
                                                ltr.IsOff = False
                                            End If
                                        End If

                                        mResultMessage += "Layer: " & "" & " Adjusted (on/Off & Thaw/Freeze)" & vbCrLf

                                    End If

                                End If

                            Next

                            tr.Commit()

                        End Using

                    End Using

                End If

            Catch ex As Exception
                ErrorInMainTry = True
                mResultMessage = ex.ToString & vbCrLf
            Finally
                TempDS = Nothing
                FStream = Nothing
                If ErrorInMainTry = False Then
                    mResultMessage += "Layer Display Modifcation Completed!"
                Else
                    mResultMessage += "Layer Display Modifcation Failed!"
                End If
            End Try

        End If

    End Sub

    Public Sub Settings(Optional ByVal SettingsFilePath As String = "") Implements iBatchPlugin.ShowSettingsDialog


        Dim ContinueFlag As Boolean = False
        Dim XMLFileToRead As String = ""

        Dim MyForm As New LayerVisibilitySettingsForm

        Try
            If SettingsFilePath <> "" Then
                XMLFileToRead = SettingsFilePath.Replace(".dll", ".xml")
                If File.Exists(XMLFileToRead) = False Then
                    Dim NewDS As New DataSet
                    NewDS.Tables.Add(MyForm.CreateEmptyDataTable)
                    NewDS.AcceptChanges()
                    MyForm.DS = NewDS
                    MyForm.SaveXML(mSettingsTableName, XMLFileToRead)
                    ContinueFlag = True
                Else
                    ContinueFlag = True
                End If
            Else
                ContinueFlag = False
            End If
        Catch ex As Exception
            mResultMessage = "XML Failed TO Read from : " & XMLFileToRead
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            MyForm.FilePath = SettingsFilePath
            MyForm.ShowDialog()

        End If

        MyForm = Nothing

    End Sub
End Class
