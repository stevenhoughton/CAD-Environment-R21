﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LayerVisibilitySettingsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LayerVisibilitySettingsForm))
        Me.pnlButtons = New System.Windows.Forms.Panel()
        Me.cmdSaveSettings = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.pnlMiddle = New System.Windows.Forms.Panel()
        Me.dgvLayers = New System.Windows.Forms.DataGridView()
        Me.LayerName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LayerOff = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.LayerFrozen = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.pnlButtons.SuspendLayout()
        Me.pnlMiddle.SuspendLayout()
        CType(Me.dgvLayers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlButtons
        '
        Me.pnlButtons.Controls.Add(Me.cmdSaveSettings)
        Me.pnlButtons.Controls.Add(Me.cmdCancel)
        Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtons.Location = New System.Drawing.Point(0, 171)
        Me.pnlButtons.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlButtons.MaximumSize = New System.Drawing.Size(0, 57)
        Me.pnlButtons.MinimumSize = New System.Drawing.Size(0, 57)
        Me.pnlButtons.Name = "pnlButtons"
        Me.pnlButtons.Size = New System.Drawing.Size(579, 57)
        Me.pnlButtons.TabIndex = 1
        '
        'cmdSaveSettings
        '
        Me.cmdSaveSettings.Location = New System.Drawing.Point(355, 14)
        Me.cmdSaveSettings.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdSaveSettings.Name = "cmdSaveSettings"
        Me.cmdSaveSettings.Size = New System.Drawing.Size(100, 28)
        Me.cmdSaveSettings.TabIndex = 1
        Me.cmdSaveSettings.Text = "Save"
        Me.cmdSaveSettings.UseVisualStyleBackColor = True
        '
        'cmdCancel
        '
        Me.cmdCancel.Location = New System.Drawing.Point(463, 14)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(100, 28)
        Me.cmdCancel.TabIndex = 0
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'pnlMiddle
        '
        Me.pnlMiddle.Controls.Add(Me.dgvLayers)
        Me.pnlMiddle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMiddle.Location = New System.Drawing.Point(0, 0)
        Me.pnlMiddle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlMiddle.Name = "pnlMiddle"
        Me.pnlMiddle.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnlMiddle.Size = New System.Drawing.Size(579, 171)
        Me.pnlMiddle.TabIndex = 2
        '
        'dgvLayers
        '
        Me.dgvLayers.AllowUserToResizeColumns = False
        Me.dgvLayers.AllowUserToResizeRows = False
        Me.dgvLayers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLayers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LayerName, Me.LayerOff, Me.LayerFrozen})
        Me.dgvLayers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvLayers.Location = New System.Drawing.Point(4, 4)
        Me.dgvLayers.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgvLayers.Name = "dgvLayers"
        Me.dgvLayers.RowTemplate.Height = 24
        Me.dgvLayers.Size = New System.Drawing.Size(571, 163)
        Me.dgvLayers.TabIndex = 0
        '
        'LayerName
        '
        Me.LayerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.LayerName.DataPropertyName = "LAYERNAME"
        Me.LayerName.HeaderText = "Layer Name"
        Me.LayerName.Name = "LayerName"
        '
        'LayerOff
        '
        Me.LayerOff.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LayerOff.DataPropertyName = "OFF"
        Me.LayerOff.FalseValue = "False"
        Me.LayerOff.HeaderText = "OFF"
        Me.LayerOff.IndeterminateValue = "False"
        Me.LayerOff.Name = "LayerOff"
        Me.LayerOff.TrueValue = "True"
        Me.LayerOff.Width = 41
        '
        'LayerFrozen
        '
        Me.LayerFrozen.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LayerFrozen.DataPropertyName = "FROZEN"
        Me.LayerFrozen.FalseValue = "False"
        Me.LayerFrozen.HeaderText = "FREEZE"
        Me.LayerFrozen.IndeterminateValue = "False"
        Me.LayerFrozen.Name = "LayerFrozen"
        Me.LayerFrozen.TrueValue = "True"
        Me.LayerFrozen.Width = 68
        '
        'LayerVisibilitySettingsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(579, 228)
        Me.Controls.Add(Me.pnlMiddle)
        Me.Controls.Add(Me.pnlButtons)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MinimumSize = New System.Drawing.Size(594, 45)
        Me.Name = "LayerVisibilitySettingsForm"
        Me.Text = "Layer Visibility Settings"
        Me.pnlButtons.ResumeLayout(False)
        Me.pnlMiddle.ResumeLayout(False)
        CType(Me.dgvLayers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlButtons As System.Windows.Forms.Panel
    Friend WithEvents cmdSaveSettings As System.Windows.Forms.Button
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents pnlMiddle As System.Windows.Forms.Panel
    Friend WithEvents dgvLayers As System.Windows.Forms.DataGridView
    Friend WithEvents LayerName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LayerOff As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents LayerFrozen As System.Windows.Forms.DataGridViewCheckBoxColumn
End Class
