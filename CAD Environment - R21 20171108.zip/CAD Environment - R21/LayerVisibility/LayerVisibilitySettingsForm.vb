﻿Imports System.IO
Imports System.Windows.Forms

Public Class LayerVisibilitySettingsForm

    Dim FormData_DS As New DataSet
    Dim XMLFileToRead As String = ""
    Dim SearchFilePath As String = ""

    Dim Initializing As Boolean = False
    Dim NewCell As Boolean = False

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Dim objAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly
        Dim VNumber As String
        'Get each part of the version through the assembly object
        VNumber = objAssembly.GetName().Version.Major & "." & objAssembly.GetName().Version.Minor & "." &
            objAssembly.GetName().Version.Build & "." & objAssembly.GetName().Version.Revision

        Me.Text = objAssembly.GetName().Name & " - " & VNumber

    End Sub

    Public WriteOnly Property FilePath() As String
        Set(ByVal value As String)
            SearchFilePath = value
        End Set
    End Property

    Private Sub frmLayerSettings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Initializing = True

        Dim FStream As FileStream
        Dim ContinueFlag As Boolean = True
        Dim ErrorInMainTry As Boolean = False

        'Dim AssmObj As System.Reflection.Assembly

        Try
            If SearchFilePath <> "" Then
                'AssmObj = System.Reflection.Assembly.GetExecutingAssembly
                XMLFileToRead = SearchFilePath.Replace(".dll", ".xml") ' AssmObj.Location.ToString.Replace(".dll", ".xml")
            Else
                ContinueFlag = False
            End If

        Catch ex As Exception
            ContinueFlag = False
        End Try

        If ContinueFlag Then

            Try

                FStream = New FileStream(XMLFileToRead, FileMode.Open)

                FormData_DS.ReadXml(FStream)

                FStream.Close()

                If FormData_DS.Tables.Count > 0 Then

                    FormData_DS.Tables(0).TableName = "LAYER"

                    Dim dtCloned As DataTable = FormData_DS.Tables(0).Clone()
                    dtCloned.Columns(1).DataType = GetType(Boolean)
                    dtCloned.Columns(2).DataType = GetType(Boolean)
                    For Each row As DataRow In FormData_DS.Tables(0).Rows
                        dtCloned.ImportRow(row)
                    Next

                    FormData_DS.Tables.Remove("LAYER")
                    FormData_DS.AcceptChanges()

                    FormData_DS.Tables.Add(dtCloned.Copy)
                    FormData_DS.AcceptChanges()

                End If

            Catch ex As Exception
                FormData_DS.Tables.Add(CreateEmptyDataTable)
            Finally

                FStream = Nothing

            End Try

        Else
            FormData_DS.Tables.Add(CreateEmptyDataTable)

        End If

        FormData_DS.Tables("LAYER").PrimaryKey = New DataColumn() {FormData_DS.Tables("LAYER").Columns("LAYERNAME")}
        FormData_DS.Tables("LAYER").AcceptChanges()

        dgvLayers.DataSource = FormData_DS
        dgvLayers.DataMember = "LAYER"

        Initializing = False
    End Sub

    Public Function CreateEmptyDataTable() As DataTable

        Dim DatTable As New DataTable

        DatTable.TableName = "LAYER"
        DatTable.Columns.Add("LAYERNAME", GetType(String))
        DatTable.Columns.Add("FROZEN", GetType(Boolean))
        DatTable.Columns.Add("off", GetType(Boolean))

        Return DatTable
    End Function

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Close()
    End Sub

    Private Sub cmdSaveSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveSettings.Click

        If FormData_DS.HasChanges Then

            FormData_DS.AcceptChanges()
            For Each DatRow As DataRow In FormData_DS.Tables("LAYER").Rows
                If DatRow.Item("LAYERNAME").ToString <> "" Then
                    If DatRow.Item("OFF").GetType = GetType(System.DBNull) Then
                        DatRow.Item("OFF") = False
                    End If
                    If DatRow.Item("FROZEN").GetType = GetType(System.DBNull) Then
                        DatRow.Item("FROZEN") = False
                    End If
                End If
            Next
            FormData_DS.AcceptChanges()
            SaveXML("LAYERS VISIBILITY", XMLFileToRead)

        End If

        Close()

    End Sub

    'Only used if the XML is missing from PC to create new XML
    Public WriteOnly Property DS() As DataSet
        Set(ByVal value As DataSet)
            FormData_DS = value
        End Set
    End Property

    Public Sub SaveXML(ByVal PDesc As String, ByVal FilePath As String)

        If FormData_DS.Tables("LAYER").Rows.Count > 0 Then

            If File.Exists(FilePath) Then
                File.Delete(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Settings File has been deleted" & vbCrLf)
                FormData_DS.WriteXml(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Settings File has been ReWritten!" & vbCrLf)
            Else
                FormData_DS.WriteXml(FilePath)
            End If
        End If

    End Sub

    Private Sub dgvLayers_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvLayers.CellEnter
        If String.IsNullOrEmpty(dgvLayers.CurrentCell.FormattedValue.ToString) Then
            NewCell = True
        Else
            NewCell = False
        End If
    End Sub

    Private Sub dgvLayers_CellErrorTextChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvLayers.CellErrorTextChanged

    End Sub

    Private Sub dgvLayers_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles dgvLayers.KeyDown

        If e.KeyCode = Windows.Forms.Keys.Delete Then

            'For Each DatRow As DataGridViewRow In dgvLayers.SelectedRows

            '    Dim DatBdItem As DataRowView = DatRow.DataBoundItem

            '    If DatBdItem IsNot Nothing Then
            '        FormData_DS.Tables("LAYER").Rows.Remove(DatBdItem.Row)
            '    End If

            'Next

            For Index As Integer = dgvLayers.SelectedRows.Count - 1 To 0 Step -1
                Dim row As DataGridViewRow = dgvLayers.SelectedRows(Index)
                FormData_DS.Tables("LAYER").Rows.Remove(FormData_DS.Tables("LAYER").Rows.Find(row.Cells(0).Value.ToString))
            Next

            FormData_DS.AcceptChanges()

        End If

    End Sub

    Private Sub dgvLayers_CellValidating(ByVal sender As Object, ByVal e As DataGridViewCellValidatingEventArgs) Handles dgvLayers.CellValidating

        If Initializing Then Exit Sub

        If e.ColumnIndex = 0 Then

            If dgvLayers.IsCurrentCellDirty Then

                ' Confirm that the cell is not empty.
                If (String.IsNullOrEmpty(e.FormattedValue.ToString())) Then

                    dgvLayers.Rows(e.RowIndex).ErrorText = "Layer Name Goes Here"
                    e.Cancel = True

                Else

                    Dim DTRow As DataRowView = dgvLayers.Rows(e.RowIndex).DataBoundItem

                    If DTRow IsNot Nothing Then

                        Select Case NewCell
                            Case True

                                If HasCurrentData(e.FormattedValue.ToString(), e.RowIndex) Then
                                    dgvLayers.Rows(e.RowIndex).ErrorText = "Duplicate LayerName Found - ESC to Clear"
                                    e.Cancel = True
                                End If
                            Case False
                                If HasCurrentData(e.FormattedValue.ToString(), e.RowIndex) Then
                                    dgvLayers.Rows(e.RowIndex).ErrorText = "Duplicate LayerName Found - ESC to Clear"
                                    e.Cancel = True
                                End If
                        End Select

                    End If

                End If

            End If

        End If

    End Sub

    Private Function HasCurrentData(ByVal TestData As String, ByVal RowIndex As Integer) As Boolean

        Dim Ret As Boolean = False

        For Index As Integer = 0 To dgvLayers.Rows.Count - 1
            If Index <> RowIndex Then
                Dim DtRow As DataGridViewRow = dgvLayers.Rows(Index)
                If DtRow.Cells(0).FormattedValue.ToString.ToUpper = TestData.ToUpper Then

                    Ret = True
                    Exit For

                End If
            End If
        Next

        Return Ret
    End Function
    Private Sub dgvLayers_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvLayers.CellEndEdit

        ' Clear the row error in case the user presses ESC.   
        dgvLayers.Rows(e.RowIndex).ErrorText = String.Empty

    End Sub


End Class