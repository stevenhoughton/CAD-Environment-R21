﻿Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports System.IO
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports Autodesk.AutoCAD.ApplicationServices
Imports Jacobs.AutoCAD.Utilities
Imports System.Reflection
Imports System.Windows.Forms
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.Common.Settings
Imports UtilitiesMyResources = Jacobs.AutoCAD.Utilities.My.Resources

Public Class LayerStatesTransferForm

    Private mInitalising As Boolean = False

    Private mDisableUpdate As Boolean = False
    Private mSaveSettingsFile As String = ""

    Private TableIsFiltered As Boolean = False

    Private FileToProcess_DS As New System.Data.DataSet
    Private WhichFiles() As String = New String() {"All Files", "Odd Numbered Files", "Even Numbered Files"}
    Private mLayers As List(Of clsLayerDetails)

    Private mBlockDataSet As New DataSet

    Public Sub New()

        mInitalising = True

        ' This call is required by the designer.
        InitializeComponent()

        System.Windows.Forms.Application.EnableVisualStyles()

        ' Add any initialization after the InitializeComponent() call.
        dgvFiles.AutoGenerateColumns = False

        Dim DT As New System.Data.DataTable("BlockDetails")

        DT.Columns.Add("BlockName", GetType(System.String))
        DT.Columns.Add("AttributeName", GetType(System.String))
        DT.Columns.Add("AttributeValue", GetType(System.String))
        DT.Columns.Add("LayoutID", GetType(System.String))

        If mBlockDataSet.Tables.Contains("BlockDetails") Then
            mBlockDataSet.Tables.Remove("BlockDetails")
            mBlockDataSet.AcceptChanges()
        End If
        mBlockDataSet.Tables.Add(DT)

        Dim DTL As New System.Data.DataTable("LayoutDetails")

        DTL.Columns.Add("LayoutName", GetType(System.String))
        DTL.Columns.Add("LayoutID", GetType(System.String))

        If mBlockDataSet.Tables.Contains("LayoutDetails") Then
            mBlockDataSet.Tables.Remove("LayoutDetails")
            mBlockDataSet.AcceptChanges()
        End If
        mBlockDataSet.Tables.Add(DTL)

        mBlockDataSet.AcceptChanges()

        SetIgnoreData()

    End Sub

    Private Sub frmLayoutTools_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        mInitalising = True

        mLayers = GetAllLayersPropertiesFromCurrentFile()

        '' Workout out the Dialog Box Title 
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        ' Now that we have things like the AEVersion number and Title display it on the dialog name 
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

        RepositionTitle(Me.lblTitle, Me)

        lblInformation.Text = "Layer States will be imported from - " & Path.GetFileNameWithoutExtension(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Name) & ".dwg"

        '' Assign Global Generic dialog tool tips. Not to be hard coded. Use Global Reference file in Utilities
        ToolTip1.SetToolTip(cmdHelp, UtilitiesMyResources.ToolTipHelp)
        ToolTip1.SetToolTip(Cancel_Button, UtilitiesMyResources.ToolTipCancel)

        '' Assign local unique tool tips. Not to be hard coded. Use local reference file
        ToolTip1.SetToolTip(cmdRunFiles, My.Resources.ToolTipOK)
        ToolTip1.SetToolTip(lblTitle, My.Resources.ToolSummary)

        'Populate Filter Combo Box
        cboWhichFiles.Items.AddRange(WhichFiles)
        cboWhichFiles.SelectedIndex = 0

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        txtFilePrefix.Text = Path.GetFileNameWithoutExtension(Doc.Name)

        'Inistalize File Datagrid View
        SetFilesDataTable()

        mSaveSettingsFile = ThisDrawingUtilities.GetVariable("roamablerootprefix").ToString & "Support\LayoutToolsSettings.xml"

        mInitalising = False

    End Sub

    Private Sub frmLayoutTools_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        lblTitle.Left = Me.Width \ 2 - Me.lblTitle.Width \ 2
    End Sub

    Private Sub SetIgnoreData()
        'This will set Unresolved Settings etc
        'Hidden Message dialog Settings
    End Sub

    Private Sub tsmAddFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAddFiles.Click

        AddFiles()

    End Sub

    Private Sub tsmAddFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAddFolder.Click

        'If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then

        '    Dim SearchSubFolders As SearchOption

        '    If chkRecurse.CheckState = CheckState.Checked Then
        '        SearchSubFolders = SearchOption.AllDirectories
        '    Else
        '        SearchSubFolders = SearchOption.TopDirectoryOnly
        '    End If

        '    Dim FoundExeFiles As IEnumerable = GetFiles(FolderBrowserDialog1.SelectedPath, ".dwg", SearchSubFolders)

        '    AddRowElement(ConvertToArray(Of String)(CType(FoundExeFiles, Global.System.Collections.Generic.IEnumerable(Of String))))

        'End If

        AddFolders()

    End Sub

    Private Sub dgvFiles_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgvFiles.CellFormatting

        If e.RowIndex > -1 AndAlso e.ColumnIndex = 0 Then

            If Not dgvFiles.Rows.Item(e.RowIndex).Cells("FilePath").Value Is Nothing Then

                Dim Ext As String = dgvFiles.Rows.Item(e.RowIndex).Cells("FilePath").Value.ToString
                Ext = Ext.Substring(Ext.Length - 4)

                e.Value = imlScripts.Images.Item(Ext)

            End If

        End If

    End Sub

    Private Sub dgvFiles_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgvFiles.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Dim ht As DataGridView.HitTestInfo
            ht = Me.dgvFiles.HitTest(e.X, e.Y)
            Select Case ht.Type
                Case DataGridViewHitTestType.Cell, DataGridViewHitTestType.ColumnHeader, DataGridViewHitTestType.RowHeader, DataGridViewHitTestType.None

                    If dgvFiles.SelectedRows.Count > 0 Then
                        tsmInvertSelction.Enabled = True
                        tsmDeSelectAll.Enabled = True
                        tsmRemoveSelected.Enabled = True
                        tsmResetList.Enabled = True
                    Else
                        tsmInvertSelction.Enabled = False
                        tsmDeSelectAll.Enabled = False
                        tsmRemoveSelected.Enabled = False
                        tsmResetList.Enabled = False
                    End If

                    If dgvFiles.Rows.Count > 0 Then
                        tsmSelectAll.Enabled = True
                    Else
                        tsmSelectAll.Enabled = False
                    End If

                    cmsRightClickMenu.Show(dgvFiles, New Point(e.X, e.Y))

            End Select
        End If
    End Sub

    Private Sub dgvFiles_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvFiles.DragDrop

        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim WEFiles() As String

            ' Assign the files to an array.
            WEFiles = CType(e.Data.GetData(DataFormats.FileDrop), String())

            AddRowElement(WEFiles)

        End If
    End Sub

    Private Sub dgvFiles_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvFiles.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.All
        End If
    End Sub

    Private Sub dgvFiles_DragOver(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles dgvFiles.DragOver
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.All
        End If
    End Sub

    Private Sub tsmSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmSelectAll.Click
        dgvFiles.SelectAll()
    End Sub

    Private Sub tsmDeSelectAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmDeSelectAll.Click
        dgvFiles.ClearSelection()
    End Sub

    Private Sub tsmInvertSelction_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmInvertSelction.Click
        For Each row As DataGridViewRow In dgvFiles.Rows
            If row.Selected Then
                row.Selected = False
            Else
                row.Selected = True
            End If
        Next
    End Sub

    Private Sub tsmRemoveSelected_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tsmRemoveSelected.Click

        RemoveSelected()

    End Sub

    Private Sub RemoveSelected()

        For Index As Integer = dgvFiles.SelectedRows.Count - 1 To 0 Step -1

            Dim row As DataGridViewRow = dgvFiles.SelectedRows(Index)
            'FileToProcess_DS.Tables("Files").Rows.Remove(FileToProcess_DS.Tables("Files").Rows.Find(row.Cells(2).Value.ToString))
            RemoveRowElement(row)
        Next

    End Sub


    Private Sub AddRowElement(ByVal TheFiles() As String, Optional ByVal IgnoreDrawing As String = "")

        Dim I As Integer = 0

        ' Loop through the array and add the files to the list.
        For I = 0 To TheFiles.Length - 1

            Dim CurrentFile As System.IO.FileInfo = My.Computer.FileSystem.GetFileInfo(TheFiles(I).ToString)

            If IgnoreDrawing <> "" Then
                If IgnoreDrawing = CurrentFile.ToString Then
                    Continue For
                End If
            End If

            'Does the file exist
            If CurrentFile.Exists Then

                'is it a dwg
                If CurrentFile.FullName.ToString.ToLower.EndsWith("dwg") Then

                    If Not (imlScripts.Images.ContainsKey(CurrentFile.Extension)) Then

                        Dim iconForFile As Icon = SystemIcons.WinLogo

                        iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(CurrentFile.ToString)
                        imlScripts.Images.Add(CurrentFile.Extension, iconForFile)

                    End If

                    'Create New Row
                    Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

                    FileToAdd.Item("dFileName") = Path.GetFileName(CurrentFile.FullName)
                    FileToAdd.Item("dFilePath") = CurrentFile.FullName
                    FileToAdd.Item("fFileName") = Path.GetFileNameWithoutExtension(CurrentFile.FullName)

                    'Check if the Datarow would exist
                    If FileToProcess_DS.Tables("Files").Rows.IndexOf(FileToAdd) = -1 Then

                        'add the row
                        FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)
                        FileToProcess_DS.Tables("Files").AcceptChanges()

                    Else

                        FileToProcess_DS.Tables("Files").RejectChanges()

                    End If

                End If 'Is Dwg

            End If 'Is file exist

        Next 'Step thru selected Files

        If FileToProcess_DS.Tables("Files").Rows.Count > 0 Then

            DataBindColumnsToForm()

            chkFilterDisplay.Enabled = True
            cmdRunFiles.Enabled = True
        Else
            chkFilterDisplay.Enabled = False
            cmdRunFiles.Enabled = False
        End If
    End Sub

    Private Sub RemoveRowElement(ByVal row As DataGridViewRow)
        FileToProcess_DS.Tables("Files").Rows.Remove(FileToProcess_DS.Tables("Files").Rows.Find(row.Cells(2).Value.ToString))
        'FileToProcess_DS.Tables("Files").AcceptChanges()
        If FileToProcess_DS.Tables("Files").Rows.Count > 0 Then
            chkFilterDisplay.Enabled = True
        Else
            chkFilterDisplay.Enabled = False
        End If
        DataBindColumnsToForm()
    End Sub

    Private Sub SetFilesDataTable()

        If FileToProcess_DS.Tables.Contains("Files") Then
            FileToProcess_DS.Tables.Remove("Files")
            If FileToProcess_DS.Tables.Contains("DFiles") Then
                FileToProcess_DS.Tables.Remove("DFiles")
            End If
        End If
        FileToProcess_DS.Tables.Add("Files")

        FileToProcess_DS.Tables("Files").Columns.Add("dFileName", GetType(System.String))

        Dim pk As System.Data.DataColumn = FileToProcess_DS.Tables("Files").Columns.Add("dFilePath", GetType(System.String))

        FileToProcess_DS.Tables("Files").Columns.Add("fFileName", GetType(System.String))

        'Need a primary key to search the datatable for existing Files
        FileToProcess_DS.Tables("Files").PrimaryKey = New System.Data.DataColumn() {pk}
        FileToProcess_DS.AcceptChanges()

        DataBindColumnsToForm()

        dgvFiles.DataSource = Nothing

        dgvFiles.AllowDrop = True
        dgvFiles.DataSource = FileToProcess_DS
        dgvFiles.DataMember = FileToProcess_DS.Tables("DFiles").TableName


    End Sub

    Private Sub DataBindColumnsToForm()

        If FileToProcess_DS.Tables.Contains("DFiles") = False Then
            Dim FiltertedDT As Data.DataTable = FileToProcess_DS.Tables("Files").Copy
            FiltertedDT.TableName = "DFiles"
            'If FileToProcess_DS.Tables.Contains("DFiles") Then
            '    FileToProcess_DS.Tables.Remove("DFiles")
            'End If
            FileToProcess_DS.Tables.Add(FiltertedDT)
            FileToProcess_DS.AcceptChanges()
        End If

        FileToProcess_DS.Tables("DFiles").Rows.Clear()
        For Each DtRow As Data.DataRow In FileToProcess_DS.Tables("Files").Rows
            FileToProcess_DS.Tables("DFiles").ImportRow(DtRow)
        Next
        FileToProcess_DS.Tables("DFiles").AcceptChanges()
        FileToProcess_DS.AcceptChanges()

        If TableIsFiltered Then
            FilterFileList()
        End If

    End Sub

    Private Sub SaveXML(ByVal DT As System.Data.DataTable, ByVal PDesc As String, ByVal FilePath As String)

        If DT.Rows.Count > 0 Then
            Dim TempDS As New DataSet
            TempDS.Tables.Add(DT.Copy)
            TempDS.AcceptChanges()

            If File.Exists(FilePath) Then
                File.Delete(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Processes have been deleted" & vbCrLf)
                TempDS.WriteXml(FilePath)
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage(PDesc & " Processes have been ReWritten!" & vbCrLf)
            Else
                TempDS.WriteXml(FilePath)
            End If
        End If

    End Sub

    Private Sub chkFilterDisplay_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFilterDisplay.CheckedChanged
        Dim CheckValue As Boolean = False
        Select Case chkFilterDisplay.CheckState
            Case CheckState.Checked
                CheckValue = True
            Case CheckState.Unchecked
                CheckValue = False
        End Select

        cmdRefreshFileList.Enabled = CheckValue
        lblFilePrefix.Enabled = CheckValue
        txtFilePrefix.Enabled = CheckValue
        lblWhichFiles.Enabled = CheckValue
        cboWhichFiles.Enabled = CheckValue

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()

            SaveDialogSettings()

            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

#Region "Options On OFF - Check Boxes"
    'Private Sub chkLayerOnOff_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerOnOff.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.eOnOff = chkLayerOnOff.Checked
    '    Next

    'End Sub

    'Private Sub chkLayerFreeze_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerFreeze.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.eFreeze = chkLayerFreeze.Checked
    '    Next
    'End Sub

    'Private Sub chkLayerPlot_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerPlot.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.ePlot = chkLayerPlot.Checked
    '    Next
    'End Sub

    'Private Sub chkLayerLock_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerLock.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.eLock = chkLayerLock.Checked
    '    Next
    'End Sub

    'Private Sub chkLayerColor_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerColor.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.eLColor = chkLayerColor.Checked
    '    Next
    'End Sub

    'Private Sub chkLayerLineType_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerLineType.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.eLLineType = chkLayerLineType.Checked
    '    Next
    'End Sub

    'Private Sub chkDeleteLayers_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkDeleteLayers.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.DeleteIfNotInCurrent = chkDeleteLayers.Checked
    '    Next
    'End Sub

    'Private Sub chkAddMissing_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkAddMissing.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.CreateIfMissing = chkAddMissing.Checked
    '    Next
    'End Sub

    'Private Sub chkLayerLineWeight_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkLayerLineWeight.CheckedChanged
    '    If mInitalising Then Exit Sub

    '    For Each X As clsLayerDetails In mLayers
    '        X.eLLineWeight = chkLayerLineWeight.Checked
    '    Next
    'End Sub

    Private Sub ReReadCheckBoxes()

        For Each X As clsLayerDetails In mLayers
            X.eOnOff = chkLayerOnOff.Checked
            X.eFreeze = chkLayerFreeze.Checked
            X.ePlot = chkLayerPlot.Checked
            X.eLock = chkLayerLock.Checked
            X.eLColor = chkLayerColor.Checked
            X.eLLineType = chkLayerLineType.Checked
            X.DeleteIfNotInCurrent = chkDeleteLayers.Checked
            X.CreateIfMissing = chkAddMissing.Checked
            X.eLLineWeight = chkLayerLineWeight.Checked
        Next

    End Sub

#End Region

    Private Sub SaveDialogSettings()

        If System.IO.File.Exists(mSaveSettingsFile) Then
            System.IO.File.Delete(mSaveSettingsFile)
        End If

        Try

            Dim Settings_DT As New System.Data.DataTable

            Settings_DT.TableName = "Settings"
            Settings_DT.Columns.Add("SettingName", GetType(System.String))
            Settings_DT.Columns.Add("SettingValue", GetType(System.String))

            SaveDataRow(Settings_DT, "chkAddMissing", chkAddMissing.Checked.ToString)
            SaveDataRow(Settings_DT, "chkDeleteLayers", chkDeleteLayers.Checked.ToString)
            SaveDataRow(Settings_DT, "chkExcludePath", chkExcludePath.Checked.ToString)
            SaveDataRow(Settings_DT, "chkFilterDisplay", chkFilterDisplay.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerColor", chkLayerColor.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerFreeze", chkLayerFreeze.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerLineType", chkLayerLineType.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerLineWeight", chkLayerLineWeight.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerLock", chkLayerLock.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerOnOff", chkLayerOnOff.Checked.ToString)
            SaveDataRow(Settings_DT, "chkLayerPlot", chkLayerPlot.Checked.ToString)
            SaveDataRow(Settings_DT, "chkRecurse", chkRecurse.Checked.ToString)

            SaveDataRow(Settings_DT, "FileCount", FileToProcess_DS.Tables("Files").Rows.Count.ToString)

            Dim Counter As Integer = 0
            For Each RowInTable As DataRow In FileToProcess_DS.Tables("Files").Rows
                Dim Xfile As String = RowInTable.Item("dFilePath").ToString
                SaveDataRow(Settings_DT, Counter.ToString & "File", Xfile)
                Counter += 1
            Next

            Settings_DT.AcceptChanges()

            SaveXML(Settings_DT, "DialogSettings", mSaveSettingsFile)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub RestoreDialogSettings()

        Dim FStream As FileStream
        Dim TempDS As New DataSet

        Try

            FStream = New FileStream(mSaveSettingsFile, FileMode.Open) ' ListEnt, FileMode.Open)

            TempDS.ReadXml(FStream)

            FStream.Close()

            If TempDS.Tables.Count > 0 Then
                TempDS.Tables(0).PrimaryKey = New System.Data.DataColumn() {TempDS.Tables(0).Columns("SettingName")}
                TempDS.Tables(0).AcceptChanges()

                Dim Settings_DT As System.Data.DataTable = TempDS.Tables(0)

                chkAddMissing.Checked = RestoreSettingValue(Settings_DT, "chkAddMissing").IsTrue
                chkDeleteLayers.Checked = RestoreSettingValue(Settings_DT, "chkDeleteLayers").IsTrue
                chkExcludePath.Checked = RestoreSettingValue(Settings_DT, "chkExcludePath").IsTrue
                chkFilterDisplay.Checked = RestoreSettingValue(Settings_DT, "chkFilterDisplay").IsTrue
                chkLayerColor.Checked = RestoreSettingValue(Settings_DT, "chkLayerColor").IsTrue
                chkLayerFreeze.Checked = RestoreSettingValue(Settings_DT, "chkLayerFreeze").IsTrue
                chkLayerLineType.Checked = RestoreSettingValue(Settings_DT, "chkLayerLineType").IsTrue
                chkLayerLineWeight.Checked = RestoreSettingValue(Settings_DT, "chkLayerLineWeight").IsTrue
                chkLayerLock.Checked = RestoreSettingValue(Settings_DT, "chkLayerLock").IsTrue
                chkLayerOnOff.Checked = RestoreSettingValue(Settings_DT, "chkLayerOnOff").IsTrue
                chkLayerPlot.Checked = RestoreSettingValue(Settings_DT, "chkLayerPlot").IsTrue
                chkRecurse.Checked = RestoreSettingValue(Settings_DT, "chkRecurse").IsTrue

                Dim FileCount As Integer = CType(RestoreSettingValue(Settings_DT, "FileCount"), Integer)

                If FileCount > 0 Then

                    If MsgBox("Do you want to load previous Files?", MsgBoxStyle.YesNo, "Restore Old FileSet") = MsgBoxResult.Yes Then

                        For Index As Integer = 0 To FileCount - 1

                            Dim Fln As String = RestoreSettingValue(Settings_DT, Index.ToString & "File")

                            If File.Exists(Fln) Then

                                If FileToProcess_DS.Tables("Files").Rows.Contains(Fln) = False Then

                                    Dim TheFileName As FileInfo = New FileInfo(Fln)

                                    If Not (imlScripts.Images.ContainsKey(TheFileName.Extension)) Then

                                        Dim iconForFile As Icon = SystemIcons.WinLogo

                                        iconForFile = System.Drawing.Icon.ExtractAssociatedIcon(TheFileName.ToString)
                                        imlScripts.Images.Add(TheFileName.Extension, iconForFile)

                                    End If

                                    Dim FileToAdd As DataRow = FileToProcess_DS.Tables("Files").NewRow

                                    FileToAdd.Item("dFileName") = Path.GetFileName(Fln)
                                    FileToAdd.Item("dFilePath") = Fln
                                    FileToAdd.Item("fFileName") = Path.GetFileNameWithoutExtension(Fln)

                                    FileToProcess_DS.Tables("Files").Rows.Add(FileToAdd)

                                End If

                            End If

                        Next

                        If FileToProcess_DS.Tables("Files").Rows.Count > 0 Then

                            DataBindColumnsToForm()

                            chkFilterDisplay.Enabled = True
                            cmdRunFiles.Enabled = True
                        Else
                            chkFilterDisplay.Enabled = False
                            cmdRunFiles.Enabled = False
                        End If

                    End If

                End If

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        Finally
            TempDS = Nothing
            FStream = Nothing
        End Try

        ReReadCheckBoxes()

    End Sub

    Private Sub cmdSaveList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveList.Click
        Dim MyDT As System.Data.DataTable = FileToProcess_DS.Tables("Files").Copy

        If Not MyDT Is Nothing Then

            Dim saveFileDialog1 As New SaveFileDialog()
            saveFileDialog1.Filter = "Saved File List|*.xml"
            saveFileDialog1.Title = "Save File List"
            saveFileDialog1.ShowDialog()

            ' If the file name is not an empty string open it for saving.
            If saveFileDialog1.FileName <> "" Then

                SaveXML(MyDT, "FILELST", saveFileDialog1.FileName)

            End If

        End If

    End Sub

    Private Sub cmdLoadList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLoadList.Click

        mDisableUpdate = True

        Dim FStream As FileStream
        Dim TempDS As New System.Data.DataSet

        Try

            Dim openFileDialog1 As OpenFileDialog = New OpenFileDialog

            ' Set filter options and filter index.
            openFileDialog1.Filter = "Load File List|*.xml"
            openFileDialog1.Title = "Restore File List"
            openFileDialog1.FilterIndex = 1

            openFileDialog1.Multiselect = False

            If openFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

                FStream = New FileStream(openFileDialog1.FileName, FileMode.Open) ' ListEnt, FileMode.Open)

                TempDS.ReadXml(FStream)

                FStream.Close()

                If TempDS.Tables.Count > 0 Then

                    FileToProcess_DS.Tables("Files").Rows.Clear()
                    For Each DtRow As DataRow In TempDS.Tables("Files").Rows
                        FileToProcess_DS.Tables("Files").ImportRow(DtRow)
                    Next

                End If

            End If

        Catch ex As Exception
            MsgBox("General Expection has occured in reading BatchProcessor.xml FIle" + vbCrLf + ex.Message)
        Finally
            TempDS = Nothing
            FStream = Nothing
        End Try

        mDisableUpdate = False

    End Sub

    Private Sub SaveDataRow(ByRef SettingDataTable As System.Data.DataTable, ByVal ControlName As String, ByVal SaveValue As String)

        Dim NewAddRow As DataRow

        NewAddRow = SettingDataTable.NewRow()
        NewAddRow.Item("SettingName") = ControlName
        NewAddRow.Item("SettingValue") = SaveValue
        SettingDataTable.Rows.Add(NewAddRow)

        NewAddRow = Nothing

    End Sub

    Private Function RestoreSettingValue(ByVal Settings As System.Data.DataTable, ByVal ControlFieldName As String) As String

        Dim DatRow As DataRow = Settings.Rows.Find(ControlFieldName)
        Dim Ret As String = ""

        If Not DatRow Is Nothing Then
            Ret = DatRow.Item("SettingValue").ToString
        End If

        Return Ret

    End Function

    Private Sub cmdRunFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRunFiles.Click

        SaveDialogSettings()

        ReReadCheckBoxes()

        Dim BackUpPathLoaction As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments.CombinePath("LayoutToolsBackup").CombinePath("LayerMap")
        CheckAndSetFolders(BackUpPathLoaction)
        Dim FileDateTimeFolder As String = Format(Now, "yyyyMMdd_hhmmsstt")
        BackUpPathLoaction = BackUpPathLoaction.CombinePath(FileDateTimeFolder)
        CheckAndSetFolders(BackUpPathLoaction)

        Dim StepCounter As Integer = 1
        Dim Changed As Boolean = False
        Dim SaveAsFileName As String = "", OldFileName As String = "", BackUpFileName As String = ""

        'Set Progress Bar Settings
        tsslProgBar.Minimum = 0
        tsslProgBar.Maximum = FileToProcess_DS.Tables("DFiles").Rows.Count

        'Stepp thru each ro of File
        For Each DTRow As DataRow In FileToProcess_DS.Tables("DFiles").Rows

            'Set Progress Bar Index
            tsslProgBar.Value = StepCounter

            'Set File Naming Before and after Process
            Dim ExistingFileName As String = DTRow.Item("dFilePath").ToString
            OldFileName = ExistingFileName
            BackUpFileName = BackUpPathLoaction & "\" & Path.GetFileName(ExistingFileName)

            SaveAsFileName = ExistingFileName.Replace(".dwg", "Temp_.dwg")

            'Open External File
            Dim SideDB As Database
            SideDB = New Database(False, True)
            SideDB.ReadDwgFile(ExistingFileName, FileOpenMode.OpenForReadAndWriteNoShare, False, "")

            'Execute Mapping, Return Booleen is mapping was successfull
            Changed = ExecuteExistingLayerMapping(SideDB, mLayers, SaveAsFileName, True) '<-- Change to false once we go to production

            'Layer Map Successful
            If Changed Then
                'tsslMessage.Text = "Saving Drawing..."

                If File.Exists(ExistingFileName) Then
                    File.Move(ExistingFileName, BackUpFileName)
                    File.Move(SaveAsFileName, ExistingFileName)
                End If
            End If

            'Increase Progress COunter for Progress bar
            StepCounter += 1

        Next

        'tsslProgBar.Value = 0
        tsslMessage.Text = "Process Complete, Applied Changes to " & (StepCounter - 1).ToString & " Drawings!"
        'tsslMessage.Text = "Layer Mapping Complete!"
        Me.Hide()
        Me.Close()

    End Sub

    Private Sub CheckAndSetFolders(ByVal Path As String)

        If Directory.Exists(Path) = False Then
            Directory.CreateDirectory(Path)
        End If

    End Sub

    Private Sub tsmAutoLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmAutoLoad.Click

        Dim Doc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument
        Dim FilterS As String = Path.GetFileNameWithoutExtension(Doc.Name)
        Dim SerachPath As String = Path.GetDirectoryName(Doc.Name)
        Dim Test As String = InputBox("Enter File Filter:", "File Filter", FilterS)

        If Test <> "" Then
            Dim FoundFiles As IEnumerable = GetFiles(SerachPath, New String() {Test & "*.dwg"}, SearchOption.TopDirectoryOnly)
            AddRowElement(ConvertToArray(Of String)(CType(FoundFiles, Global.System.Collections.Generic.IEnumerable(Of String))), Doc.Name)
        End If

    End Sub

    Private Sub cmdRefreshFileList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefreshFileList.Click
        FilterFileList()
    End Sub

    Private Sub FilterFileList()

        TableIsFiltered = True
        Dim FiltertedDT As Data.DataTable
        Dim FiltertedIE As EnumerableRowCollection(Of Data.DataRow) = Nothing

        Select Case cboWhichFiles.SelectedIndex
            Case 0 'All Files

                FiltertedIE = (From P In FileToProcess_DS.Tables("Files").AsEnumerable()
                               Let CurrentR = P Where FileToProcess_DS.Tables("Files").Columns.Cast(Of Data.DataColumn).Any(
                                                    Function(Col As Data.DataColumn) P.Item(Col.ColumnName).ToString.Contains(txtFilePrefix.Text))
                               Select CurrentR)
            Case 1 'Odd Files
                FiltertedIE = (From P In FileToProcess_DS.Tables("Files").AsEnumerable()
                               Let CurrentR = P Where FileToProcess_DS.Tables("Files").Columns.Cast(Of Data.DataColumn).Any(
                                    Function(Col As Data.DataColumn)
                                        Dim x As String = P.Item("fFileName").ToString.Replace(txtFilePrefix.Text, "")
                                        Dim Ans As Boolean = False
                                        Dim IntValue As Integer = 0
                                        If Integer.TryParse(x, IntValue) Then
                                            If IntValue Mod 2 > 0 Then
                                                'Even
                                                Ans = True
                                            Else
                                                'Odd
                                                Ans = False
                                            End If
                                        End If
                                        Return Ans
                                    End Function)
                               Select CurrentR)
            Case 2 'Even Filews
                FiltertedIE = (From P In FileToProcess_DS.Tables("Files").AsEnumerable()
                               Let CurrentR = P Where FileToProcess_DS.Tables("Files").Columns.Cast(Of Data.DataColumn).Any(
                    Function(Col As Data.DataColumn)
                        Dim x As String = P.Item("fFileName").ToString.Replace(txtFilePrefix.Text, "")
                        Dim Ans As Boolean = False
                        Dim IntValue As Integer = 0
                        If Integer.TryParse(x, IntValue) Then
                            If IntValue Mod 2 = 0 Then
                                'Even
                                Ans = True
                            Else
                                'Odd
                                Ans = False
                            End If
                        End If
                        Return Ans
                    End Function)
                               Select CurrentR)
            Case 3 'Conatins

            Case Else
                TableIsFiltered = False
        End Select

        If FiltertedIE.Count > 0 Then
            FiltertedDT = FiltertedIE.CopyToDataTable
            FiltertedDT.TableName = "Files"

            If FileToProcess_DS.Tables.Contains("DFiles") Then
                'FileToProcess_DS.Tables.Remove("DFiles")
                FileToProcess_DS.Tables("DFiles").Rows.Clear()
                For Each DtRow As Data.DataRow In FiltertedDT.Rows
                    FileToProcess_DS.Tables("DFiles").ImportRow(DtRow)
                Next
                FileToProcess_DS.Tables("DFiles").AcceptChanges()
                FileToProcess_DS.AcceptChanges()
            End If
            'FileToProcess_DS.Tables.Add(FiltertedDT)
        End If

    End Sub

    Private Sub tsmResetList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmResetList.Click
        FileToProcess_DS.Tables("Files").Rows.Clear()
        FileToProcess_DS.Tables("DFiles").Rows.Clear()
    End Sub

    Private Sub frmLayoutTools_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If File.Exists(mSaveSettingsFile) Then
            RestoreDialogSettings()
        End If
    End Sub

    Private Shared Function EffectiveName(ByVal blkref As BlockReference) As String
        If blkref.IsDynamicBlock Then
            Using obj As BlockTableRecord = DirectCast(blkref.DynamicBlockTableRecord.GetObject(OpenMode.ForRead), BlockTableRecord)
                Return obj.Name
            End Using
        End If
        Return blkref.Name
    End Function

    Private Sub cmdHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelp.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub LayerStatesTransferForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

    Private Sub dgvFiles_RowsAdded(sender As Object, e As System.Windows.Forms.DataGridViewRowsAddedEventArgs) Handles dgvFiles.RowsAdded

        If dgvFiles.RowCount > 0 Then
            cmdSaveList.Enabled = True
        Else
            cmdSaveList.Enabled = False
        End If

    End Sub

    Private Sub dgvFiles_RowsRemoved(sender As Object, e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles dgvFiles.RowsRemoved

        If dgvFiles.RowCount > 0 Then
            cmdSaveList.Enabled = True
        Else
            cmdSaveList.Enabled = False
        End If

    End Sub


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles AddFileButton.Click
        AddFiles()
    End Sub

    Private Sub AddFiles()
        Dim OpenFileDialog1 As New System.Windows.Forms.OpenFileDialog

        OpenFileDialog1.Title = "Please Select Files..."
        OpenFileDialog1.Filter = "AutoCAD Drawings (*.dwg)|*.dwg"
        OpenFileDialog1.InitialDirectory = "C:\"
        OpenFileDialog1.Multiselect = True
        OpenFileDialog1.ShowDialog()

        If OpenFileDialog1.FileNames.Length > 0 Then

            Dim TheFileNames() As String = OpenFileDialog1.FileNames

            AddRowElement(TheFileNames, Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Name)

        End If

    End Sub

    Private Sub AddFolders()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Dim SearchSubFolders As SearchOption

                If chkRecurse.CheckState = CheckState.Checked Then
                    SearchSubFolders = SearchOption.AllDirectories
                Else
                    SearchSubFolders = SearchOption.TopDirectoryOnly
                End If

                Dim FoundExeFiles As IEnumerable = GetFiles(ReturnedFolder, ".dwg", SearchSubFolders)

                AddRowElement(ConvertToArray(Of String)(CType(FoundExeFiles, Global.System.Collections.Generic.IEnumerable(Of String))))
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles AddFolderButton.Click
        AddFolders()
    End Sub

    Private Sub RemoveSelectedButton_Click(sender As System.Object, e As System.EventArgs) Handles RemoveSelectedButton.Click
        RemoveSelected()
    End Sub


    Private Sub dgvFiles_SelectionChanged(sender As Object, e As System.EventArgs) Handles dgvFiles.SelectionChanged

        If dgvFiles.SelectedRows.Count > 0 Then
            RemoveSelectedButton.Enabled = True
        Else
            RemoveSelectedButton.Enabled = False
        End If

    End Sub
End Class
