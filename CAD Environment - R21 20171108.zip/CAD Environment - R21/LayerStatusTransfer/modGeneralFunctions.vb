﻿Imports System.Text
Imports System.Management
Imports System.IO
Imports System.Linq
Imports System.Collections.Generic
Imports System.Text.RegularExpressions
Imports System.Runtime.InteropServices
Imports Jacobs.Common.Core
Imports System.Data
Imports System.Windows.Forms

Public Module modGeneralFunctions

    Public Enum LayerStatusOption
        slso_LayerBoolean = 0
        slso_LayerColor = 1
        slso_LayerLineType = 2
        slso_LayerDelete = 3
        slso_LayerCreate = 4
    End Enum

    Public Enum LayerStatusOptionCD
        slsocd_CreateLayer = 0
        slsocd_DeleteLayer = 1
    End Enum

    Public Function ConvertToArray(Of T)(enumerable As IEnumerable(Of T)) As T()
        If enumerable Is Nothing Then
            Throw New ArgumentNullException("enumerable")
        End If

        Return If(TryCast(enumerable, T()), enumerable.ToArray())
    End Function

    Public Sub CloneRowWithValues(ByVal SingleRow As DataGridViewRow, ByVal Target As DataGridView)
        Dim Results As DataGridViewRow = CType(SingleRow.Clone(), DataGridViewRow)
        For Row As Int32 = 0 To SingleRow.Cells.Count - 1
            Results.Cells(Row).Value = SingleRow.Cells(Row).Value
        Next
        Target.Rows.Add(Results)
    End Sub

    ' Regex version
    Public Function GetFiles(searchpath As String, Optional searchPatternExpression As String = "", Optional searchOption__2 As SearchOption = SearchOption.TopDirectoryOnly) As IEnumerable '(Of String)
        Dim reSearchPattern As New Regex(searchPatternExpression)
        Return Directory.EnumerateFiles(searchpath, "*", searchOption__2).Where(Function(file) reSearchPattern.IsMatch(Path.GetExtension(file)))
    End Function

    ' Takes same patterns, and executes in parallel
    Public Function GetFiles(searchpath As String, searchPatterns As String(), Optional searchOption__1 As SearchOption = SearchOption.TopDirectoryOnly) As IEnumerable '(Of String)
        Return searchPatterns.AsParallel().SelectMany(Function(searchPattern) Directory.EnumerateFiles(searchpath, searchPattern, searchOption__1))
    End Function

    Public Function GetUNCPath(ByVal sFilePath As String) As String
        GetUNCPath = ""
        Dim searcher As New ManagementObjectSearcher("SELECT RemoteName FROM win32_NetworkConnection WHERE LocalName = '" + sFilePath.Substring(0, 2) + "'")
        For Each managementObject As ManagementObject In searcher.[Get]()
            Dim sRemoteName As String = TryCast(managementObject("RemoteName"), String)
            sRemoteName += sFilePath.Substring(2)
            'Return (New Uri(sRemoteName)).ToString()
            Return sRemoteName.ToString
        Next

    End Function

    Public Function GetDGVContentAsDataTable(ByVal dgv As DataGridView, Optional IgnoreHideColumns As Boolean = False) As DataTable
        Try
            If dgv.ColumnCount = 0 Then
                Return Nothing
            End If
            Dim dtSource As New DataTable()
            For Each col As DataGridViewColumn In dgv.Columns
                If IgnoreHideColumns And Not col.Visible Then
                    Continue For
                End If
                If col.Name = String.Empty Then
                    Continue For
                End If
                dtSource.Columns.Add(col.Name, GetType(System.String))
                dtSource.Columns(col.Name).Caption = col.HeaderText
            Next
            If dtSource.Columns.Count = 0 Then
                Return Nothing
            End If
            For Each row As DataGridViewRow In dgv.Rows
                Dim drNewRow As DataRow = dtSource.NewRow()
                For Each col As DataColumn In dtSource.Columns
                    drNewRow(col.ColumnName) = row.Cells(col.ColumnName).Value
                    If drNewRow(col.ColumnName).Equals(String.Empty) Then
                        drNewRow(col.ColumnName) = " "
                    End If
                Next
                dtSource.Rows.Add(drNewRow)
            Next
            Return dtSource
        Catch
            Return Nothing
        End Try
    End Function

End Module
