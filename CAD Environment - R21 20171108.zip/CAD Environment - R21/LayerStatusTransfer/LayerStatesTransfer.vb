﻿' (C) Copyright 2013 by Sinclair Knight Merz 
'
Imports System
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.Common.Settings

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(jacobs.AutoCAD.LayerStatesTransfer.LayerStatesTransferMain))> 

' This class is instantiated by AutoCAD for each document when
' a command is called by the user the first time in the context
' of a given document. In other words, non static data in this class
' is implicitly per-document!
Public Class LayerStatesTransferMain

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    ' This allows us to access the AE's Select Configuration dialog and configure the drawing if required.
    Dim SelectConfig As New SelectTemplate.TemplateSelector

    ''' <summary>
    ''' Primary command used to kick off the tool.
    ''' </summary>
    ''' <remarks></remarks>
    ''' , Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_LayerStatesTransfer", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub LayoutTools()

        Try

            ' Create an instance of the form that we can use
            Dim SampleDialogInst As New LayerStatesTransferForm

            ' Check to see if this tool needs to be configured. The flag for this is nominated by the developer and stored in 
            ' HKEY_LOCAL_MACHINE\SOFTWARE\[MANUFACTURER]\[PRODUCTNAME]\Applications\{DLL Name without extension}\MustBeconfigured = True or False
            ' The registry key is created with the installer (don't forget to add it in). Adding a new tool via the DFS will require the a call 
            ' to the Client Selector to add this key for that tool.

            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then

                ' If it needs to be configured as per the reg key and it's not configured then 
                ' Call the generic function to allow user to select a configuration as this DWG is not configured and it needs to be.

                SelectConfig.DisplayWarning()

                ' We gave the user the opportunity to configure the drawing - check that they have done that and not just canceled the 
                ' Select Configuration dialog

                If ThisDrawingIsConfigured() Then

                    ' Present them with the dialog box.
                    Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(SampleDialogInst)

                End If

            Else

                '' There either was no need to have a configured drawing (most likely for a tool that does not use rules)
                '' Or the drawing is already configured and ready to go.

                Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(SampleDialogInst)

            End If

        Catch ex As System.Exception

            ' Generic exception handling - using reflection to let us know where the error came from.

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)

        End Try

    End Sub

End Class

