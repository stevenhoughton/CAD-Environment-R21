﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LayerStatesTransferForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LayerStatesTransferForm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlBanner = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.pnlButtonBtm = New System.Windows.Forms.Panel()
        Me.cmdRunFiles = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.tsslMessage = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsslProgBar = New System.Windows.Forms.ToolStripProgressBar()
        Me.pnlMainArea = New System.Windows.Forms.Panel()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tpcLayerTransfer = New System.Windows.Forms.TabPage()
        Me.pnlFiles = New System.Windows.Forms.Panel()
        Me.gbxFiles = New System.Windows.Forms.GroupBox()
        Me.dgvFiles = New System.Windows.Forms.DataGridView()
        Me.FileType = New System.Windows.Forms.DataGridViewImageColumn()
        Me.ProcessedFile = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FilePath = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pnlFileTools = New System.Windows.Forms.Panel()
        Me.chkRecurse = New System.Windows.Forms.CheckBox()
        Me.chkExcludePath = New System.Windows.Forms.CheckBox()
        Me.cmdSaveList = New System.Windows.Forms.Button()
        Me.cmdLoadList = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblInformation = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkFilterDisplay = New System.Windows.Forms.CheckBox()
        Me.cmdRefreshFileList = New System.Windows.Forms.Button()
        Me.txtFilePrefix = New System.Windows.Forms.TextBox()
        Me.lblWhichFiles = New System.Windows.Forms.Label()
        Me.cboWhichFiles = New System.Windows.Forms.ComboBox()
        Me.lblFilePrefix = New System.Windows.Forms.Label()
        Me.gbxLayerStatusExport = New System.Windows.Forms.GroupBox()
        Me.chkLayerLineWeight = New System.Windows.Forms.CheckBox()
        Me.chkLayerLineType = New System.Windows.Forms.CheckBox()
        Me.chkLayerColor = New System.Windows.Forms.CheckBox()
        Me.chkLayerLock = New System.Windows.Forms.CheckBox()
        Me.chkDeleteLayers = New System.Windows.Forms.CheckBox()
        Me.chkAddMissing = New System.Windows.Forms.CheckBox()
        Me.chkLayerPlot = New System.Windows.Forms.CheckBox()
        Me.chkLayerFreeze = New System.Windows.Forms.CheckBox()
        Me.chkLayerOnOff = New System.Windows.Forms.CheckBox()
        Me.cmsRightClickMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.tsmAutoLoad = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAddFiles = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmAddFolder = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmRemoveSelected = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmSelectAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmInvertSelction = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmDeSelectAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmResetList = New System.Windows.Forms.ToolStripMenuItem()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.imlScripts = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.AddFileButton = New System.Windows.Forms.Button()
        Me.AddFolderButton = New System.Windows.Forms.Button()
        Me.RemoveSelectedButton = New System.Windows.Forms.Button()
        Me.pnlBanner.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlButtonBtm.SuspendLayout()
        Me.pnlMainArea.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tpcLayerTransfer.SuspendLayout()
        Me.pnlFiles.SuspendLayout()
        Me.gbxFiles.SuspendLayout()
        CType(Me.dgvFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFileTools.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbxLayerStatusExport.SuspendLayout()
        Me.cmsRightClickMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlBanner
        '
        Me.pnlBanner.BackgroundImage = CType(resources.GetObject("pnlBanner.BackgroundImage"), System.Drawing.Image)
        Me.pnlBanner.Controls.Add(Me.lblTitle)
        Me.pnlBanner.Controls.Add(Me.LogoPictureBox)
        Me.pnlBanner.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlBanner.Location = New System.Drawing.Point(0, 0)
        Me.pnlBanner.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlBanner.Name = "pnlBanner"
        Me.pnlBanner.Size = New System.Drawing.Size(1011, 64)
        Me.pnlBanner.TabIndex = 38
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(297, 35)
        Me.lblTitle.TabIndex = 29
        Me.lblTitle.Text = "Layer States Transfer"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 28
        Me.LogoPictureBox.TabStop = False
        '
        'pnlButtonBtm
        '
        Me.pnlButtonBtm.Controls.Add(Me.cmdRunFiles)
        Me.pnlButtonBtm.Controls.Add(Me.Cancel_Button)
        Me.pnlButtonBtm.Controls.Add(Me.cmdHelp)
        Me.pnlButtonBtm.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlButtonBtm.Location = New System.Drawing.Point(0, 570)
        Me.pnlButtonBtm.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlButtonBtm.MaximumSize = New System.Drawing.Size(0, 46)
        Me.pnlButtonBtm.MinimumSize = New System.Drawing.Size(0, 46)
        Me.pnlButtonBtm.Name = "pnlButtonBtm"
        Me.pnlButtonBtm.Padding = New System.Windows.Forms.Padding(16, 7, 16, 7)
        Me.pnlButtonBtm.Size = New System.Drawing.Size(1011, 46)
        Me.pnlButtonBtm.TabIndex = 44
        '
        'cmdRunFiles
        '
        Me.cmdRunFiles.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRunFiles.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRunFiles.Dock = System.Windows.Forms.DockStyle.Right
        Me.cmdRunFiles.Enabled = False
        Me.cmdRunFiles.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRunFiles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRunFiles.Location = New System.Drawing.Point(704, 7)
        Me.cmdRunFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdRunFiles.Name = "cmdRunFiles"
        Me.cmdRunFiles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRunFiles.Size = New System.Drawing.Size(159, 32)
        Me.cmdRunFiles.TabIndex = 34
        Me.cmdRunFiles.Text = "OK"
        Me.cmdRunFiles.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.Dock = System.Windows.Forms.DockStyle.Right
        Me.Cancel_Button.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(863, 7)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(132, 32)
        Me.Cancel_Button.TabIndex = 35
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'cmdHelp
        '
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.Dock = System.Windows.Forms.DockStyle.Left
        Me.cmdHelp.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(16, 7)
        Me.cmdHelp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(132, 32)
        Me.cmdHelp.TabIndex = 36
        Me.cmdHelp.Text = "Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 616)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(1011, 22)
        Me.StatusStrip1.TabIndex = 43
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'tsslMessage
        '
        Me.tsslMessage.Name = "tsslMessage"
        Me.tsslMessage.Size = New System.Drawing.Size(12, 21)
        Me.tsslMessage.Text = "."
        '
        'tsslProgBar
        '
        Me.tsslProgBar.Name = "tsslProgBar"
        Me.tsslProgBar.Size = New System.Drawing.Size(133, 20)
        '
        'pnlMainArea
        '
        Me.pnlMainArea.Controls.Add(Me.TabControl1)
        Me.pnlMainArea.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMainArea.Location = New System.Drawing.Point(0, 64)
        Me.pnlMainArea.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlMainArea.Name = "pnlMainArea"
        Me.pnlMainArea.Padding = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.pnlMainArea.Size = New System.Drawing.Size(1011, 506)
        Me.pnlMainArea.TabIndex = 45
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tpcLayerTransfer)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(8, 7)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(995, 492)
        Me.TabControl1.TabIndex = 0
        '
        'tpcLayerTransfer
        '
        Me.tpcLayerTransfer.Controls.Add(Me.pnlFiles)
        Me.tpcLayerTransfer.Controls.Add(Me.gbxLayerStatusExport)
        Me.tpcLayerTransfer.Location = New System.Drawing.Point(4, 25)
        Me.tpcLayerTransfer.Margin = New System.Windows.Forms.Padding(4)
        Me.tpcLayerTransfer.Name = "tpcLayerTransfer"
        Me.tpcLayerTransfer.Padding = New System.Windows.Forms.Padding(4)
        Me.tpcLayerTransfer.Size = New System.Drawing.Size(987, 463)
        Me.tpcLayerTransfer.TabIndex = 0
        Me.tpcLayerTransfer.Text = "Layers Status Transfer"
        Me.tpcLayerTransfer.UseVisualStyleBackColor = True
        '
        'pnlFiles
        '
        Me.pnlFiles.Controls.Add(Me.gbxFiles)
        Me.pnlFiles.Controls.Add(Me.GroupBox3)
        Me.pnlFiles.Controls.Add(Me.GroupBox1)
        Me.pnlFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlFiles.Location = New System.Drawing.Point(4, 4)
        Me.pnlFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlFiles.Name = "pnlFiles"
        Me.pnlFiles.Padding = New System.Windows.Forms.Padding(0, 0, 8, 0)
        Me.pnlFiles.Size = New System.Drawing.Size(712, 455)
        Me.pnlFiles.TabIndex = 1
        '
        'gbxFiles
        '
        Me.gbxFiles.Controls.Add(Me.dgvFiles)
        Me.gbxFiles.Controls.Add(Me.pnlFileTools)
        Me.gbxFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbxFiles.Location = New System.Drawing.Point(0, 64)
        Me.gbxFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.gbxFiles.Name = "gbxFiles"
        Me.gbxFiles.Padding = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.gbxFiles.Size = New System.Drawing.Size(704, 278)
        Me.gbxFiles.TabIndex = 4
        Me.gbxFiles.TabStop = False
        Me.gbxFiles.Text = "Files"
        '
        'dgvFiles
        '
        Me.dgvFiles.AllowDrop = True
        Me.dgvFiles.AllowUserToAddRows = False
        Me.dgvFiles.AllowUserToDeleteRows = False
        Me.dgvFiles.AllowUserToResizeColumns = False
        Me.dgvFiles.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvFiles.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvFiles.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvFiles.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFiles.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFiles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FileType, Me.ProcessedFile, Me.FilePath})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvFiles.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvFiles.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvFiles.Location = New System.Drawing.Point(8, 61)
        Me.dgvFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvFiles.Name = "dgvFiles"
        Me.dgvFiles.ReadOnly = True
        Me.dgvFiles.RowTemplate.Height = 24
        Me.dgvFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFiles.Size = New System.Drawing.Size(688, 210)
        Me.dgvFiles.TabIndex = 5
        '
        'FileType
        '
        Me.FileType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.FileType.HeaderText = ""
        Me.FileType.Name = "FileType"
        Me.FileType.ReadOnly = True
        Me.FileType.Width = 5
        '
        'ProcessedFile
        '
        Me.ProcessedFile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ProcessedFile.DataPropertyName = "dFileName"
        Me.ProcessedFile.HeaderText = "FileName"
        Me.ProcessedFile.Name = "ProcessedFile"
        Me.ProcessedFile.ReadOnly = True
        Me.ProcessedFile.Width = 92
        '
        'FilePath
        '
        Me.FilePath.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.FilePath.DataPropertyName = "dFilePath"
        Me.FilePath.HeaderText = "File Path"
        Me.FilePath.Name = "FilePath"
        Me.FilePath.ReadOnly = True
        '
        'pnlFileTools
        '
        Me.pnlFileTools.Controls.Add(Me.RemoveSelectedButton)
        Me.pnlFileTools.Controls.Add(Me.chkRecurse)
        Me.pnlFileTools.Controls.Add(Me.AddFolderButton)
        Me.pnlFileTools.Controls.Add(Me.chkExcludePath)
        Me.pnlFileTools.Controls.Add(Me.AddFileButton)
        Me.pnlFileTools.Controls.Add(Me.cmdSaveList)
        Me.pnlFileTools.Controls.Add(Me.cmdLoadList)
        Me.pnlFileTools.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlFileTools.Location = New System.Drawing.Point(8, 22)
        Me.pnlFileTools.Margin = New System.Windows.Forms.Padding(4)
        Me.pnlFileTools.MaximumSize = New System.Drawing.Size(0, 39)
        Me.pnlFileTools.MinimumSize = New System.Drawing.Size(0, 39)
        Me.pnlFileTools.Name = "pnlFileTools"
        Me.pnlFileTools.Padding = New System.Windows.Forms.Padding(4, 0, 0, 4)
        Me.pnlFileTools.Size = New System.Drawing.Size(688, 39)
        Me.pnlFileTools.TabIndex = 1
        '
        'chkRecurse
        '
        Me.chkRecurse.BackColor = System.Drawing.Color.Transparent
        Me.chkRecurse.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkRecurse.Dock = System.Windows.Forms.DockStyle.Right
        Me.chkRecurse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkRecurse.Location = New System.Drawing.Point(492, 0)
        Me.chkRecurse.Margin = New System.Windows.Forms.Padding(4)
        Me.chkRecurse.Name = "chkRecurse"
        Me.chkRecurse.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.chkRecurse.Size = New System.Drawing.Size(196, 35)
        Me.chkRecurse.TabIndex = 46
        Me.chkRecurse.Text = "Include Subfolders"
        Me.chkRecurse.UseVisualStyleBackColor = False
        '
        'chkExcludePath
        '
        Me.chkExcludePath.AutoSize = True
        Me.chkExcludePath.Location = New System.Drawing.Point(206, 7)
        Me.chkExcludePath.Margin = New System.Windows.Forms.Padding(4)
        Me.chkExcludePath.Name = "chkExcludePath"
        Me.chkExcludePath.Padding = New System.Windows.Forms.Padding(8, 0, 0, 0)
        Me.chkExcludePath.Size = New System.Drawing.Size(120, 21)
        Me.chkExcludePath.TabIndex = 45
        Me.chkExcludePath.Text = "Exclude Path"
        Me.chkExcludePath.UseVisualStyleBackColor = True
        Me.chkExcludePath.Visible = False
        '
        'cmdSaveList
        '
        Me.cmdSaveList.Dock = System.Windows.Forms.DockStyle.Left
        Me.cmdSaveList.Enabled = False
        Me.cmdSaveList.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdSaveList.Location = New System.Drawing.Point(43, 0)
        Me.cmdSaveList.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdSaveList.Name = "cmdSaveList"
        Me.cmdSaveList.Size = New System.Drawing.Size(39, 35)
        Me.cmdSaveList.TabIndex = 44
        Me.cmdSaveList.Text = "<"
        Me.ToolTip1.SetToolTip(Me.cmdSaveList, "Export List of Files")
        Me.cmdSaveList.UseVisualStyleBackColor = True
        '
        'cmdLoadList
        '
        Me.cmdLoadList.Dock = System.Windows.Forms.DockStyle.Left
        Me.cmdLoadList.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdLoadList.Location = New System.Drawing.Point(4, 0)
        Me.cmdLoadList.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdLoadList.Name = "cmdLoadList"
        Me.cmdLoadList.Size = New System.Drawing.Size(39, 35)
        Me.cmdLoadList.TabIndex = 43
        Me.cmdLoadList.Text = "1"
        Me.ToolTip1.SetToolTip(Me.cmdLoadList, "Import List of Files")
        Me.cmdLoadList.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblInformation)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox3.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(704, 64)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Information"
        '
        'lblInformation
        '
        Me.lblInformation.AutoSize = True
        Me.lblInformation.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblInformation.Location = New System.Drawing.Point(4, 19)
        Me.lblInformation.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblInformation.Name = "lblInformation"
        Me.lblInformation.Size = New System.Drawing.Size(225, 17)
        Me.lblInformation.TabIndex = 0
        Me.lblInformation.Text = "Layer States will be imported from "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkFilterDisplay)
        Me.GroupBox1.Controls.Add(Me.cmdRefreshFileList)
        Me.GroupBox1.Controls.Add(Me.txtFilePrefix)
        Me.GroupBox1.Controls.Add(Me.lblWhichFiles)
        Me.GroupBox1.Controls.Add(Me.cboWhichFiles)
        Me.GroupBox1.Controls.Add(Me.lblFilePrefix)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.GroupBox1.Location = New System.Drawing.Point(0, 342)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(704, 113)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filter File Selection"
        '
        'chkFilterDisplay
        '
        Me.chkFilterDisplay.AutoSize = True
        Me.chkFilterDisplay.Enabled = False
        Me.chkFilterDisplay.Location = New System.Drawing.Point(17, 23)
        Me.chkFilterDisplay.Margin = New System.Windows.Forms.Padding(4)
        Me.chkFilterDisplay.Name = "chkFilterDisplay"
        Me.chkFilterDisplay.Size = New System.Drawing.Size(196, 21)
        Me.chkFilterDisplay.TabIndex = 47
        Me.chkFilterDisplay.Text = "Filter Display By File Prefix"
        Me.chkFilterDisplay.UseVisualStyleBackColor = True
        '
        'cmdRefreshFileList
        '
        Me.cmdRefreshFileList.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdRefreshFileList.Enabled = False
        Me.cmdRefreshFileList.Font = New System.Drawing.Font("Wingdings 3", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.cmdRefreshFileList.Location = New System.Drawing.Point(655, 16)
        Me.cmdRefreshFileList.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdRefreshFileList.Name = "cmdRefreshFileList"
        Me.cmdRefreshFileList.Size = New System.Drawing.Size(39, 36)
        Me.cmdRefreshFileList.TabIndex = 46
        Me.cmdRefreshFileList.Text = "Q"
        Me.cmdRefreshFileList.UseVisualStyleBackColor = True
        '
        'txtFilePrefix
        '
        Me.txtFilePrefix.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFilePrefix.Enabled = False
        Me.txtFilePrefix.Location = New System.Drawing.Point(8, 73)
        Me.txtFilePrefix.Margin = New System.Windows.Forms.Padding(4)
        Me.txtFilePrefix.Name = "txtFilePrefix"
        Me.txtFilePrefix.Size = New System.Drawing.Size(502, 22)
        Me.txtFilePrefix.TabIndex = 4
        '
        'lblWhichFiles
        '
        Me.lblWhichFiles.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblWhichFiles.AutoSize = True
        Me.lblWhichFiles.Enabled = False
        Me.lblWhichFiles.Location = New System.Drawing.Point(522, 52)
        Me.lblWhichFiles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWhichFiles.Name = "lblWhichFiles"
        Me.lblWhichFiles.Size = New System.Drawing.Size(80, 17)
        Me.lblWhichFiles.TabIndex = 3
        Me.lblWhichFiles.Text = "Which Files"
        '
        'cboWhichFiles
        '
        Me.cboWhichFiles.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboWhichFiles.Enabled = False
        Me.cboWhichFiles.FormattingEnabled = True
        Me.cboWhichFiles.Location = New System.Drawing.Point(516, 73)
        Me.cboWhichFiles.Margin = New System.Windows.Forms.Padding(4)
        Me.cboWhichFiles.Name = "cboWhichFiles"
        Me.cboWhichFiles.Size = New System.Drawing.Size(172, 24)
        Me.cboWhichFiles.TabIndex = 2
        '
        'lblFilePrefix
        '
        Me.lblFilePrefix.AutoSize = True
        Me.lblFilePrefix.Enabled = False
        Me.lblFilePrefix.Location = New System.Drawing.Point(13, 52)
        Me.lblFilePrefix.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFilePrefix.Name = "lblFilePrefix"
        Me.lblFilePrefix.Size = New System.Drawing.Size(69, 17)
        Me.lblFilePrefix.TabIndex = 0
        Me.lblFilePrefix.Text = "File Prefix"
        '
        'gbxLayerStatusExport
        '
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerLineWeight)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerLineType)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerColor)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerLock)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkDeleteLayers)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkAddMissing)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerPlot)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerFreeze)
        Me.gbxLayerStatusExport.Controls.Add(Me.chkLayerOnOff)
        Me.gbxLayerStatusExport.Dock = System.Windows.Forms.DockStyle.Right
        Me.gbxLayerStatusExport.Location = New System.Drawing.Point(716, 4)
        Me.gbxLayerStatusExport.Margin = New System.Windows.Forms.Padding(4)
        Me.gbxLayerStatusExport.MinimumSize = New System.Drawing.Size(267, 0)
        Me.gbxLayerStatusExport.Name = "gbxLayerStatusExport"
        Me.gbxLayerStatusExport.Padding = New System.Windows.Forms.Padding(16, 7, 4, 4)
        Me.gbxLayerStatusExport.Size = New System.Drawing.Size(267, 455)
        Me.gbxLayerStatusExport.TabIndex = 0
        Me.gbxLayerStatusExport.TabStop = False
        Me.gbxLayerStatusExport.Text = "Layer Status to Export"
        '
        'chkLayerLineWeight
        '
        Me.chkLayerLineWeight.AutoSize = True
        Me.chkLayerLineWeight.Checked = True
        Me.chkLayerLineWeight.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerLineWeight.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerLineWeight.Location = New System.Drawing.Point(16, 183)
        Me.chkLayerLineWeight.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerLineWeight.Name = "chkLayerLineWeight"
        Me.chkLayerLineWeight.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkLayerLineWeight.Size = New System.Drawing.Size(247, 25)
        Me.chkLayerLineWeight.TabIndex = 10
        Me.chkLayerLineWeight.Text = "Include LineWeight Settings"
        Me.chkLayerLineWeight.UseVisualStyleBackColor = True
        Me.chkLayerLineWeight.Visible = False
        '
        'chkLayerLineType
        '
        Me.chkLayerLineType.AutoSize = True
        Me.chkLayerLineType.Checked = True
        Me.chkLayerLineType.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerLineType.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerLineType.Location = New System.Drawing.Point(16, 158)
        Me.chkLayerLineType.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerLineType.Name = "chkLayerLineType"
        Me.chkLayerLineType.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkLayerLineType.Size = New System.Drawing.Size(247, 25)
        Me.chkLayerLineType.TabIndex = 9
        Me.chkLayerLineType.Text = "Include LineType Settings"
        Me.chkLayerLineType.UseVisualStyleBackColor = True
        '
        'chkLayerColor
        '
        Me.chkLayerColor.AutoSize = True
        Me.chkLayerColor.Checked = True
        Me.chkLayerColor.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerColor.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerColor.Location = New System.Drawing.Point(16, 122)
        Me.chkLayerColor.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerColor.Name = "chkLayerColor"
        Me.chkLayerColor.Padding = New System.Windows.Forms.Padding(0, 15, 0, 0)
        Me.chkLayerColor.Size = New System.Drawing.Size(247, 36)
        Me.chkLayerColor.TabIndex = 8
        Me.chkLayerColor.Text = "Include Color Settings"
        Me.chkLayerColor.UseVisualStyleBackColor = True
        '
        'chkLayerLock
        '
        Me.chkLayerLock.AutoSize = True
        Me.chkLayerLock.Checked = True
        Me.chkLayerLock.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerLock.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerLock.Location = New System.Drawing.Point(16, 97)
        Me.chkLayerLock.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerLock.Name = "chkLayerLock"
        Me.chkLayerLock.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkLayerLock.Size = New System.Drawing.Size(247, 25)
        Me.chkLayerLock.TabIndex = 7
        Me.chkLayerLock.Text = "Include Is Layer Locked"
        Me.chkLayerLock.UseVisualStyleBackColor = True
        '
        'chkDeleteLayers
        '
        Me.chkDeleteLayers.AutoSize = True
        Me.chkDeleteLayers.Checked = True
        Me.chkDeleteLayers.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDeleteLayers.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.chkDeleteLayers.Location = New System.Drawing.Point(16, 401)
        Me.chkDeleteLayers.Margin = New System.Windows.Forms.Padding(4)
        Me.chkDeleteLayers.Name = "chkDeleteLayers"
        Me.chkDeleteLayers.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkDeleteLayers.Size = New System.Drawing.Size(247, 25)
        Me.chkDeleteLayers.TabIndex = 5
        Me.chkDeleteLayers.Text = "Delete Layers if Not in Current File"
        Me.chkDeleteLayers.UseVisualStyleBackColor = True
        Me.chkDeleteLayers.Visible = False
        '
        'chkAddMissing
        '
        Me.chkAddMissing.AutoSize = True
        Me.chkAddMissing.Checked = True
        Me.chkAddMissing.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAddMissing.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.chkAddMissing.Location = New System.Drawing.Point(16, 426)
        Me.chkAddMissing.Margin = New System.Windows.Forms.Padding(4)
        Me.chkAddMissing.Name = "chkAddMissing"
        Me.chkAddMissing.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkAddMissing.Size = New System.Drawing.Size(247, 25)
        Me.chkAddMissing.TabIndex = 4
        Me.chkAddMissing.Text = "Add Missing Layers from Current File"
        Me.chkAddMissing.UseVisualStyleBackColor = True
        Me.chkAddMissing.Visible = False
        '
        'chkLayerPlot
        '
        Me.chkLayerPlot.AutoSize = True
        Me.chkLayerPlot.Checked = True
        Me.chkLayerPlot.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerPlot.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerPlot.Location = New System.Drawing.Point(16, 72)
        Me.chkLayerPlot.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerPlot.Name = "chkLayerPlot"
        Me.chkLayerPlot.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkLayerPlot.Size = New System.Drawing.Size(247, 25)
        Me.chkLayerPlot.TabIndex = 3
        Me.chkLayerPlot.Text = "Include Is Layer is Plottable"
        Me.chkLayerPlot.UseVisualStyleBackColor = True
        '
        'chkLayerFreeze
        '
        Me.chkLayerFreeze.AutoSize = True
        Me.chkLayerFreeze.Checked = True
        Me.chkLayerFreeze.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerFreeze.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerFreeze.Location = New System.Drawing.Point(16, 47)
        Me.chkLayerFreeze.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerFreeze.Name = "chkLayerFreeze"
        Me.chkLayerFreeze.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkLayerFreeze.Size = New System.Drawing.Size(247, 25)
        Me.chkLayerFreeze.TabIndex = 1
        Me.chkLayerFreeze.Text = "Include Freeze / Thaw"
        Me.chkLayerFreeze.UseVisualStyleBackColor = True
        '
        'chkLayerOnOff
        '
        Me.chkLayerOnOff.AutoSize = True
        Me.chkLayerOnOff.Checked = True
        Me.chkLayerOnOff.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkLayerOnOff.Dock = System.Windows.Forms.DockStyle.Top
        Me.chkLayerOnOff.Location = New System.Drawing.Point(16, 22)
        Me.chkLayerOnOff.Margin = New System.Windows.Forms.Padding(4)
        Me.chkLayerOnOff.Name = "chkLayerOnOff"
        Me.chkLayerOnOff.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.chkLayerOnOff.Size = New System.Drawing.Size(247, 25)
        Me.chkLayerOnOff.TabIndex = 0
        Me.chkLayerOnOff.Text = "Include On / Off"
        Me.chkLayerOnOff.UseVisualStyleBackColor = True
        '
        'cmsRightClickMenu
        '
        Me.cmsRightClickMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAutoLoad, Me.tsmAdd, Me.tsmRemoveSelected, Me.tsmSelectAll, Me.tsmInvertSelction, Me.tsmDeSelectAll, Me.tsmResetList})
        Me.cmsRightClickMenu.Name = "cmsRightClickMenu"
        Me.cmsRightClickMenu.Size = New System.Drawing.Size(238, 172)
        '
        'tsmAutoLoad
        '
        Me.tsmAutoLoad.Name = "tsmAutoLoad"
        Me.tsmAutoLoad.Size = New System.Drawing.Size(237, 24)
        Me.tsmAutoLoad.Text = "Auto Load From Current"
        '
        'tsmAdd
        '
        Me.tsmAdd.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmAddFiles, Me.tsmAddFolder})
        Me.tsmAdd.Name = "tsmAdd"
        Me.tsmAdd.Size = New System.Drawing.Size(237, 24)
        Me.tsmAdd.Text = "Add Single"
        '
        'tsmAddFiles
        '
        Me.tsmAddFiles.Image = Global.Jacobs.AutoCAD.LayerStatesTransfer.My.Resources.Resources.file_icon
        Me.tsmAddFiles.Name = "tsmAddFiles"
        Me.tsmAddFiles.Size = New System.Drawing.Size(152, 24)
        Me.tsmAddFiles.Text = "Files"
        '
        'tsmAddFolder
        '
        Me.tsmAddFolder.Image = Global.Jacobs.AutoCAD.LayerStatesTransfer.My.Resources.Resources.Folder_icon
        Me.tsmAddFolder.Name = "tsmAddFolder"
        Me.tsmAddFolder.Size = New System.Drawing.Size(152, 24)
        Me.tsmAddFolder.Text = "Folder"
        '
        'tsmRemoveSelected
        '
        Me.tsmRemoveSelected.Image = Global.Jacobs.AutoCAD.LayerStatesTransfer.My.Resources.Resources.delete_file_icon
        Me.tsmRemoveSelected.Name = "tsmRemoveSelected"
        Me.tsmRemoveSelected.Size = New System.Drawing.Size(237, 24)
        Me.tsmRemoveSelected.Text = "Remove Selected"
        '
        'tsmSelectAll
        '
        Me.tsmSelectAll.Image = Global.Jacobs.AutoCAD.LayerStatesTransfer.My.Resources.Resources._select
        Me.tsmSelectAll.Name = "tsmSelectAll"
        Me.tsmSelectAll.Size = New System.Drawing.Size(237, 24)
        Me.tsmSelectAll.Text = "Select All"
        '
        'tsmInvertSelction
        '
        Me.tsmInvertSelction.Name = "tsmInvertSelction"
        Me.tsmInvertSelction.Size = New System.Drawing.Size(237, 24)
        Me.tsmInvertSelction.Text = "Invert Selction"
        '
        'tsmDeSelectAll
        '
        Me.tsmDeSelectAll.Name = "tsmDeSelectAll"
        Me.tsmDeSelectAll.Size = New System.Drawing.Size(237, 24)
        Me.tsmDeSelectAll.Text = "DeSelect All"
        '
        'tsmResetList
        '
        Me.tsmResetList.Name = "tsmResetList"
        Me.tsmResetList.Size = New System.Drawing.Size(237, 24)
        Me.tsmResetList.Text = "Reset List"
        '
        'imlScripts
        '
        Me.imlScripts.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imlScripts.ImageSize = New System.Drawing.Size(16, 16)
        Me.imlScripts.TransparentColor = System.Drawing.Color.Transparent
        '
        'AddFileButton
        '
        Me.AddFileButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.AddFileButton.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.AddFileButton.Location = New System.Drawing.Point(82, 0)
        Me.AddFileButton.Name = "AddFileButton"
        Me.AddFileButton.Size = New System.Drawing.Size(39, 35)
        Me.AddFileButton.TabIndex = 1
        Me.AddFileButton.Text = "4"
        Me.ToolTip1.SetToolTip(Me.AddFileButton, "Add one or more files to List")
        Me.AddFileButton.UseVisualStyleBackColor = True
        '
        'AddFolderButton
        '
        Me.AddFolderButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.AddFolderButton.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.AddFolderButton.Location = New System.Drawing.Point(121, 0)
        Me.AddFolderButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AddFolderButton.Name = "AddFolderButton"
        Me.AddFolderButton.Size = New System.Drawing.Size(39, 35)
        Me.AddFolderButton.TabIndex = 2
        Me.AddFolderButton.Text = "0"
        Me.ToolTip1.SetToolTip(Me.AddFolderButton, "Add a folder to the List")
        Me.AddFolderButton.UseVisualStyleBackColor = True
        '
        'RemoveSelectedButton
        '
        Me.RemoveSelectedButton.Dock = System.Windows.Forms.DockStyle.Left
        Me.RemoveSelectedButton.Font = New System.Drawing.Font("Wingdings", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.RemoveSelectedButton.Location = New System.Drawing.Point(160, 0)
        Me.RemoveSelectedButton.Name = "RemoveSelectedButton"
        Me.RemoveSelectedButton.Size = New System.Drawing.Size(39, 35)
        Me.RemoveSelectedButton.TabIndex = 3
        Me.RemoveSelectedButton.Text = "û"
        Me.ToolTip1.SetToolTip(Me.RemoveSelectedButton, "Remove selected List item")
        Me.RemoveSelectedButton.UseVisualStyleBackColor = True
        '
        'LayerStatesTransferForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1011, 638)
        Me.Controls.Add(Me.pnlMainArea)
        Me.Controls.Add(Me.pnlButtonBtm)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.pnlBanner)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "LayerStatesTransferForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.pnlBanner.ResumeLayout(False)
        Me.pnlBanner.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlButtonBtm.ResumeLayout(False)
        Me.pnlMainArea.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tpcLayerTransfer.ResumeLayout(False)
        Me.pnlFiles.ResumeLayout(False)
        Me.gbxFiles.ResumeLayout(False)
        CType(Me.dgvFiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFileTools.ResumeLayout(False)
        Me.pnlFileTools.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbxLayerStatusExport.ResumeLayout(False)
        Me.gbxLayerStatusExport.PerformLayout()
        Me.cmsRightClickMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pnlBanner As System.Windows.Forms.Panel
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents pnlButtonBtm As System.Windows.Forms.Panel
    Public WithEvents cmdRunFiles As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents tsslMessage As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsslProgBar As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents pnlMainArea As System.Windows.Forms.Panel
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tpcLayerTransfer As System.Windows.Forms.TabPage
    Friend WithEvents gbxLayerStatusExport As System.Windows.Forms.GroupBox
    Friend WithEvents chkLayerPlot As System.Windows.Forms.CheckBox
    Friend WithEvents chkLayerFreeze As System.Windows.Forms.CheckBox
    Friend WithEvents chkLayerOnOff As System.Windows.Forms.CheckBox
    Friend WithEvents pnlFiles As System.Windows.Forms.Panel
    Friend WithEvents gbxFiles As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtFilePrefix As System.Windows.Forms.TextBox
    Friend WithEvents cboWhichFiles As System.Windows.Forms.ComboBox
    Friend WithEvents cmsRightClickMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents tsmAdd As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAddFiles As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmAddFolder As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmRemoveSelected As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmSelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmInvertSelction As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmDeSelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlFileTools As System.Windows.Forms.Panel
    Friend WithEvents cmdLoadList As System.Windows.Forms.Button
    Friend WithEvents cmdSaveList As System.Windows.Forms.Button
    Friend WithEvents chkExcludePath As System.Windows.Forms.CheckBox
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents imlScripts As System.Windows.Forms.ImageList
    Public WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents chkRecurse As System.Windows.Forms.CheckBox
    Friend WithEvents lblWhichFiles As System.Windows.Forms.Label
    Friend WithEvents lblFilePrefix As System.Windows.Forms.Label
    Friend WithEvents cmdRefreshFileList As System.Windows.Forms.Button
    Friend WithEvents chkFilterDisplay As System.Windows.Forms.CheckBox
    Friend WithEvents chkAddMissing As System.Windows.Forms.CheckBox
    Friend WithEvents chkDeleteLayers As System.Windows.Forms.CheckBox
    Friend WithEvents chkLayerLineType As System.Windows.Forms.CheckBox
    Friend WithEvents chkLayerColor As System.Windows.Forms.CheckBox
    Friend WithEvents chkLayerLock As System.Windows.Forms.CheckBox
    Friend WithEvents chkLayerLineWeight As System.Windows.Forms.CheckBox
    Friend WithEvents tsmAutoLoad As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgvFiles As System.Windows.Forms.DataGridView
    Friend WithEvents FileType As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents ProcessedFile As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FilePath As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents tsmResetList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lblInformation As System.Windows.Forms.Label
    Friend WithEvents AddFileButton As System.Windows.Forms.Button
    Friend WithEvents AddFolderButton As System.Windows.Forms.Button
    Friend WithEvents RemoveSelectedButton As System.Windows.Forms.Button
End Class
