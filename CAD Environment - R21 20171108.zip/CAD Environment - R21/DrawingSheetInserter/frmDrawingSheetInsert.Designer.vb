<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmDrawingSheetInsert
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Help_Button As System.Windows.Forms.Button
    Public WithEvents OK_Button As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents lblTitle As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDrawingSheetInsert))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.FrameTypeCmbBox = New System.Windows.Forms.ComboBox()
        Me.OrganisationCmbBox = New System.Windows.Forms.ComboBox()
        Me.OrientationCmbBox = New System.Windows.Forms.ComboBox()
        Me.SizeCmbBox = New System.Windows.Forms.ComboBox()
        Me.BusinessUnitCmbBox = New System.Windows.Forms.ComboBox()
        Me.OfficeCmbBox = New System.Windows.Forms.ComboBox()
        Me.RegionCmbBox = New System.Windows.Forms.ComboBox()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.InsertClientSheet = New System.Windows.Forms.Button()
        Me.Sheetfrm = New System.Windows.Forms.GroupBox()
        Me.RegionLbl = New System.Windows.Forms.Label()
        Me.BusinessUnitLbl = New System.Windows.Forms.Label()
        Me.OfficeLbl = New System.Windows.Forms.Label()
        Me.Sizelbl = New System.Windows.Forms.Label()
        Me.OrientationLbl = New System.Windows.Forms.Label()
        Me.OrganisationLbl = New System.Windows.Forms.Label()
        Me.FrameTypeLbl = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Sheetfrm.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'FrameTypeCmbBox
        '
        Me.FrameTypeCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.FrameTypeCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.FrameTypeCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FrameTypeCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FrameTypeCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.FrameTypeCmbBox.Location = New System.Drawing.Point(106, 202)
        Me.FrameTypeCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.FrameTypeCmbBox.Name = "FrameTypeCmbBox"
        Me.FrameTypeCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameTypeCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.FrameTypeCmbBox.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.FrameTypeCmbBox, "Select frame type")
        '
        'OrganisationCmbBox
        '
        Me.OrganisationCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.OrganisationCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.OrganisationCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OrganisationCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrganisationCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OrganisationCmbBox.Location = New System.Drawing.Point(106, 25)
        Me.OrganisationCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.OrganisationCmbBox.Name = "OrganisationCmbBox"
        Me.OrganisationCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OrganisationCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.OrganisationCmbBox.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.OrganisationCmbBox, "Select logo type")
        '
        'OrientationCmbBox
        '
        Me.OrientationCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.OrientationCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.OrientationCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OrientationCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrientationCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OrientationCmbBox.Location = New System.Drawing.Point(106, 289)
        Me.OrientationCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.OrientationCmbBox.Name = "OrientationCmbBox"
        Me.OrientationCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OrientationCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.OrientationCmbBox.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.OrientationCmbBox, "Select paper oreintation")
        '
        'SizeCmbBox
        '
        Me.SizeCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.SizeCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.SizeCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SizeCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SizeCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SizeCmbBox.Location = New System.Drawing.Point(106, 243)
        Me.SizeCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SizeCmbBox.Name = "SizeCmbBox"
        Me.SizeCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SizeCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.SizeCmbBox.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.SizeCmbBox, "Select paper size")
        '
        'BusinessUnitCmbBox
        '
        Me.BusinessUnitCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.BusinessUnitCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.BusinessUnitCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.BusinessUnitCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BusinessUnitCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.BusinessUnitCmbBox.Location = New System.Drawing.Point(106, 154)
        Me.BusinessUnitCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.BusinessUnitCmbBox.Name = "BusinessUnitCmbBox"
        Me.BusinessUnitCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BusinessUnitCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.BusinessUnitCmbBox.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.BusinessUnitCmbBox, "Select style type")
        '
        'OfficeCmbBox
        '
        Me.OfficeCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.OfficeCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.OfficeCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OfficeCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OfficeCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OfficeCmbBox.Location = New System.Drawing.Point(106, 109)
        Me.OfficeCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.OfficeCmbBox.Name = "OfficeCmbBox"
        Me.OfficeCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OfficeCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.OfficeCmbBox.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.OfficeCmbBox, "Select logo type")
        '
        'RegionCmbBox
        '
        Me.RegionCmbBox.BackColor = System.Drawing.SystemColors.Window
        Me.RegionCmbBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionCmbBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RegionCmbBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionCmbBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RegionCmbBox.Location = New System.Drawing.Point(106, 68)
        Me.RegionCmbBox.Margin = New System.Windows.Forms.Padding(4)
        Me.RegionCmbBox.Name = "RegionCmbBox"
        Me.RegionCmbBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionCmbBox.Size = New System.Drawing.Size(297, 25)
        Me.RegionCmbBox.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.RegionCmbBox, "Select logo type")
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(11, 6)
        Me.Help_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(85, 32)
        Me.Help_Button.TabIndex = 11
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.BackColor = System.Drawing.SystemColors.Control
        Me.OK_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.OK_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OK_Button.Location = New System.Drawing.Point(118, 6)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OK_Button.Size = New System.Drawing.Size(85, 32)
        Me.OK_Button.TabIndex = 9
        Me.OK_Button.Text = "OK"
        Me.OK_Button.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(225, 6)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(85, 32)
        Me.Cancel_Button.TabIndex = 10
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 13
        Me.LogoPictureBox.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(317, 35)
        Me.lblTitle.TabIndex = 5
        Me.lblTitle.Text = "Drawing Sheet Inserter"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.OK_Button, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(264, 535)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(321, 44)
        Me.TableLayoutPanel2.TabIndex = 29
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.InsertClientSheet)
        Me.TabPage1.Controls.Add(Me.Sheetfrm)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Size = New System.Drawing.Size(556, 417)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tool Functions"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'InsertClientSheet
        '
        Me.InsertClientSheet.BackColor = System.Drawing.SystemColors.Control
        Me.InsertClientSheet.Cursor = System.Windows.Forms.Cursors.Default
        Me.InsertClientSheet.ForeColor = System.Drawing.SystemColors.ControlText
        Me.InsertClientSheet.Location = New System.Drawing.Point(45, 8)
        Me.InsertClientSheet.Margin = New System.Windows.Forms.Padding(4)
        Me.InsertClientSheet.Name = "InsertClientSheet"
        Me.InsertClientSheet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.InsertClientSheet.Size = New System.Drawing.Size(458, 30)
        Me.InsertClientSheet.TabIndex = 4
        Me.InsertClientSheet.Text = "Insert Client Sheet"
        Me.InsertClientSheet.UseVisualStyleBackColor = False
        '
        'Sheetfrm
        '
        Me.Sheetfrm.BackColor = System.Drawing.SystemColors.Control
        Me.Sheetfrm.Controls.Add(Me.BusinessUnitCmbBox)
        Me.Sheetfrm.Controls.Add(Me.RegionLbl)
        Me.Sheetfrm.Controls.Add(Me.BusinessUnitLbl)
        Me.Sheetfrm.Controls.Add(Me.OfficeLbl)
        Me.Sheetfrm.Controls.Add(Me.SizeCmbBox)
        Me.Sheetfrm.Controls.Add(Me.RegionCmbBox)
        Me.Sheetfrm.Controls.Add(Me.OfficeCmbBox)
        Me.Sheetfrm.Controls.Add(Me.Sizelbl)
        Me.Sheetfrm.Controls.Add(Me.OrientationCmbBox)
        Me.Sheetfrm.Controls.Add(Me.OrientationLbl)
        Me.Sheetfrm.Controls.Add(Me.OrganisationCmbBox)
        Me.Sheetfrm.Controls.Add(Me.OrganisationLbl)
        Me.Sheetfrm.Controls.Add(Me.FrameTypeCmbBox)
        Me.Sheetfrm.Controls.Add(Me.FrameTypeLbl)
        Me.Sheetfrm.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sheetfrm.Location = New System.Drawing.Point(47, 46)
        Me.Sheetfrm.Margin = New System.Windows.Forms.Padding(4)
        Me.Sheetfrm.Name = "Sheetfrm"
        Me.Sheetfrm.Padding = New System.Windows.Forms.Padding(4)
        Me.Sheetfrm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Sheetfrm.Size = New System.Drawing.Size(456, 346)
        Me.Sheetfrm.TabIndex = 0
        Me.Sheetfrm.TabStop = False
        Me.Sheetfrm.Text = "Sheet"
        '
        'RegionLbl
        '
        Me.RegionLbl.BackColor = System.Drawing.SystemColors.Control
        Me.RegionLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.RegionLbl.Location = New System.Drawing.Point(24, 71)
        Me.RegionLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.RegionLbl.Name = "RegionLbl"
        Me.RegionLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionLbl.Size = New System.Drawing.Size(71, 17)
        Me.RegionLbl.TabIndex = 0
        Me.RegionLbl.Text = "Region"
        Me.RegionLbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BusinessUnitLbl
        '
        Me.BusinessUnitLbl.AutoSize = True
        Me.BusinessUnitLbl.BackColor = System.Drawing.SystemColors.Control
        Me.BusinessUnitLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.BusinessUnitLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BusinessUnitLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BusinessUnitLbl.Location = New System.Drawing.Point(8, 157)
        Me.BusinessUnitLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.BusinessUnitLbl.Name = "BusinessUnitLbl"
        Me.BusinessUnitLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BusinessUnitLbl.Size = New System.Drawing.Size(87, 17)
        Me.BusinessUnitLbl.TabIndex = 5
        Me.BusinessUnitLbl.Text = "Business Unit"
        '
        'OfficeLbl
        '
        Me.OfficeLbl.BackColor = System.Drawing.SystemColors.Control
        Me.OfficeLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.OfficeLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OfficeLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OfficeLbl.Location = New System.Drawing.Point(38, 112)
        Me.OfficeLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.OfficeLbl.Name = "OfficeLbl"
        Me.OfficeLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OfficeLbl.Size = New System.Drawing.Size(57, 16)
        Me.OfficeLbl.TabIndex = 1
        Me.OfficeLbl.Text = "Office"
        Me.OfficeLbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Sizelbl
        '
        Me.Sizelbl.AutoSize = True
        Me.Sizelbl.BackColor = System.Drawing.SystemColors.Control
        Me.Sizelbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Sizelbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sizelbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sizelbl.Location = New System.Drawing.Point(64, 246)
        Me.Sizelbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Sizelbl.Name = "Sizelbl"
        Me.Sizelbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Sizelbl.Size = New System.Drawing.Size(31, 17)
        Me.Sizelbl.TabIndex = 4
        Me.Sizelbl.Text = "Size"
        '
        'OrientationLbl
        '
        Me.OrientationLbl.AutoSize = True
        Me.OrientationLbl.BackColor = System.Drawing.SystemColors.Control
        Me.OrientationLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.OrientationLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrientationLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OrientationLbl.Location = New System.Drawing.Point(20, 292)
        Me.OrientationLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.OrientationLbl.Name = "OrientationLbl"
        Me.OrientationLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OrientationLbl.Size = New System.Drawing.Size(75, 17)
        Me.OrientationLbl.TabIndex = 6
        Me.OrientationLbl.Text = "Orientation"
        '
        'OrganisationLbl
        '
        Me.OrganisationLbl.AutoSize = True
        Me.OrganisationLbl.BackColor = System.Drawing.SystemColors.Control
        Me.OrganisationLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.OrganisationLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrganisationLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OrganisationLbl.Location = New System.Drawing.Point(11, 28)
        Me.OrganisationLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.OrganisationLbl.Name = "OrganisationLbl"
        Me.OrganisationLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OrganisationLbl.Size = New System.Drawing.Size(84, 17)
        Me.OrganisationLbl.TabIndex = 7
        Me.OrganisationLbl.Text = "Organisation"
        '
        'FrameTypeLbl
        '
        Me.FrameTypeLbl.AutoSize = True
        Me.FrameTypeLbl.BackColor = System.Drawing.SystemColors.Control
        Me.FrameTypeLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.FrameTypeLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FrameTypeLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FrameTypeLbl.Location = New System.Drawing.Point(14, 205)
        Me.FrameTypeLbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.FrameTypeLbl.Name = "FrameTypeLbl"
        Me.FrameTypeLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameTypeLbl.Size = New System.Drawing.Size(81, 17)
        Me.FrameTypeLbl.TabIndex = 8
        Me.FrameTypeLbl.Text = "Frame Type"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(16, 75)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(564, 446)
        Me.TabControl1.TabIndex = 24
        '
        'frmDrawingSheetInsert
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(601, 594)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 15)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmDrawingSheetInsert"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Sheetfrm.ResumeLayout(False)
        Me.Sheetfrm.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents InsertClientSheet As System.Windows.Forms.Button
    Public WithEvents Sheetfrm As System.Windows.Forms.GroupBox
    Public WithEvents BusinessUnitCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents RegionLbl As System.Windows.Forms.Label
    Public WithEvents BusinessUnitLbl As System.Windows.Forms.Label
    Public WithEvents OfficeLbl As System.Windows.Forms.Label
    Public WithEvents SizeCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents RegionCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents OfficeCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents Sizelbl As System.Windows.Forms.Label
    Public WithEvents OrientationCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents OrientationLbl As System.Windows.Forms.Label
    Public WithEvents OrganisationCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents OrganisationLbl As System.Windows.Forms.Label
    Public WithEvents FrameTypeCmbBox As System.Windows.Forms.ComboBox
    Public WithEvents FrameTypeLbl As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
#End Region
End Class