﻿' (C) Copyright 2014 by Jacobs
'
Imports System.Runtime.InteropServices
Imports Autodesk.AutoCAD.ApplicationServices    'Access to the AutoCAD application
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.DrawingSheetInserter.DrawingSheetInserter))> 

' This class is instantiated by AutoCAD for each document when
' a command is called by the user the first time in the context
' of a given document. In other words, non static data in this class
' is implicitly per-document!
Public Class DrawingSheetInserter

    'Implements Autodesk.AutoCAD.Runtime.IExtensionApplication

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Dim frmDrawingSheetInsert As New frmDrawingSheetInsert
    '  ' Dim RuleAccessors As New RuleAccessors
    Dim SelectConfig As New SelectTemplate.TemplateSelector

    Dim IsInitializing As Boolean = True

    Public Structure DrawingSheet
        Dim Organisation As String
        Dim Region As String
        Dim Office As String
        Dim BusinessUnit As String
        Dim FrameType As String
        Dim Size As String
        Dim Orientation As String
        Dim ComponentType As String
        Dim Path As String
        Dim FileName As String
    End Structure

    ' Main subroutine used to start macro
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_DrawingSheetInserter", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub DrawingSheetInserter()

        Try
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() Then
                    DisplayDialog()
                End If
            Else
                DisplayDialog()
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub
    Sub DisplayDialog()
        Try
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(FrmDrawingSheetInsert)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

End Class

