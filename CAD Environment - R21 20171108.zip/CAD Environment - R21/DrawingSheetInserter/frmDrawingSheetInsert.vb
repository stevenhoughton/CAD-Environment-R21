Imports VB = Microsoft.VisualBasic
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports System.IO
Imports Jacobs.Common.Core
Imports System.Collections.Generic
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
Imports System.Windows.Forms

Friend Class frmDrawingSheetInsert
    Inherits System.Windows.Forms.Form

    Dim AllDrawingSheetsCollection As New Collection
    Dim IsInitializing As Boolean = True

    Private Sub frmDrawingSheetInsert_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

            Try

            IsInitializing = True

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            Dim Directory As System.IO.DirectoryInfo

            Directory = My.Computer.FileSystem.GetDirectoryInfo(Settings.Manager.AE.DrawingSheetsPath)

            Dim Files() As System.IO.FileInfo = Directory.GetFiles

            If String.IsNullOrEmpty(Settings.Manager.AE.DrawingSheetsPath) Then
                Acad_MessageBox("Directory " & Settings.Manager.AE.DrawingSheetsPath & " can not be found", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                Exit Sub
            End If

            '' Get all the DGW files in this folder who's name contains "_SHEET."
            For Each File As System.IO.FileInfo In Files

                If InStr(File.Name, "_SHEET.") > 0 Then

                    Dim ThisDrawingSheetFile As DrawingSheetInserter.DrawingSheet
                    Dim Splat() As String = Split(File.Name.ToUpper.Replace(".DWG", ""), "_")

                    '' Check we have the correct number of elements in the file name
                    If Splat.Length = 7 Then

                        ThisDrawingSheetFile.Organisation = Splat(0)
                        ThisDrawingSheetFile.Region = Splat(1)
                        ThisDrawingSheetFile.Office = ""
                        ThisDrawingSheetFile.BusinessUnit = Splat(2)
                        ThisDrawingSheetFile.FrameType = Splat(3)
                        ThisDrawingSheetFile.Size = Splat(4)
                        ThisDrawingSheetFile.Orientation = Splat(5)
                        ThisDrawingSheetFile.ComponentType = Splat(6)

                        ThisDrawingSheetFile.FileName = System.IO.Path.GetFileName(File.Name)
                        ThisDrawingSheetFile.Path = File.Name

                        AllDrawingSheetsCollection.Add(ThisDrawingSheetFile)

                    End If

                End If

            Next File

            Me.Text = "Drawing Sheet Inserter - " & Settings.Manager.AE.Version

            '' Starting point to cascade pick
            '  PopulateOrganisation()

            '' Ensure that Remote text is loaded in case any of the sheets implement this.
            Autodesk.AutoCAD.Runtime.SystemObjects.DynamicLinker.LoadModule(Settings.Manager.AutoCAD.Path & "\Express\RTEXT.ARX", True, True)

            OrganisationCmbBox.Items.Clear()
            RegionCmbBox.Items.Clear()
            OfficeCmbBox.Items.Clear()
            BusinessUnitCmbBox.Items.Clear()
            FrameTypeCmbBox.Items.Clear()
            SizeCmbBox.Items.Clear()
            OrientationCmbBox.Items.Clear()

            PopulateOrganisation()

        Catch ex As Exception
            ' Ignore any errors
            MsgBox(ex.Message)
        End Try

        IsInitializing = False

    End Sub

    '' This is the start of the cascading combo box population - it triggers selected index change events for the other combo boxes
    Public Sub PopulateOrganisation()

        Try
            '' Sort the list
            OrganisationCmbBox.Sorted = True
            For Each Item As Object In AllDrawingSheetsCollection
                If IsValueInComboBox(OrganisationCmbBox, Item.Organisation.ToUpper) = False Then
                    ' Add the organisation name to the combo box
                    OrganisationCmbBox.Items.Add(Item.Organisation)
                End If
                'If OrganisationCmbBox.Items.Count > 0 Then
                '    If String.IsNullOrEmpty(OrganisationCmbBox.Text) Then
                '        '' Make the top one current
                '        'OrganisationCmbBox.Text = OrganisationCmbBox.Items(0).ToString
                '        OrganisationCmbBox.SelectedIndex = 0
                '    End If
                'End If
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    '' When the Organisation value changes we need to populate the regions that belong to that organisation
    Private Sub OrganisationCmbBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles OrganisationCmbBox.SelectedIndexChanged

        '   If IsInitializing = True Then Exit Sub

        PopulateRegion()

    End Sub

    '' Populates the regions for that organisation 
    Public Sub PopulateRegion()

        Try

            '            If Not String.IsNullOrEmpty(OrganisationCmbBox.Text) Then

            RegionCmbBox.Items.Clear()
            OfficeCmbBox.Items.Clear()
            BusinessUnitCmbBox.Items.Clear()
            FrameTypeCmbBox.Items.Clear()
            SizeCmbBox.Items.Clear()
            OrientationCmbBox.Items.Clear()

            '' Sort the list
            RegionCmbBox.Sorted = True
            For Each item As Object In AllDrawingSheetsCollection
                '' Check to see if the selected organisation is the same as the one in the collection we are iterating
                If item.organisation.ToString.ToUpper = OrganisationCmbBox.Text.ToUpper Then
                    '   If IsValueInComboBox(OrganisationCmbBox, item.Organisation.ToUpper) = True Then
                    ' Check that the Region is not already in the list
                    If IsValueInComboBox(RegionCmbBox, item.Region.ToUpper) = False Then
                        RegionCmbBox.Items.Add(item.Region)
                    End If
                    '     End If

                    'If RegionCmbBox.Items.Count > 0 Then
                    '    If String.IsNullOrEmpty(RegionCmbBox.Text) Then
                    '        '' Make the top one current
                    '        RegionCmbBox.SelectedIndex = 0
                    '    End If
                    'End If

                End If
            Next
            'End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    '' When the selected region changes update the business units for that region and find the matching offices
    Private Sub RegionCmb_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles RegionCmbBox.SelectedIndexChanged

        If IsInitializing = True Then Exit Sub
        PopulateBusinessUnit()
        PopulateOffice()

    End Sub

    '' Populates the list of offices in that region
    Private Sub PopulateOffice()

        Me.OfficeCmbBox.Items.Clear()

        '' Test to see if file exists first then go read it.
        Dim svarsfile As String = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)
        Dim cities As Dictionary(Of String, List(Of String)) = Ini.ReadValues(svarsfile, "CITIES PER REGION", ";")

        For Each data As KeyValuePair(Of String, List(Of String)) In cities
   '         MsgBox(RegionCmbBox.Text.ToUpper & "  =   " & data.Key.ToUpper)

            If RegionCmbBox.Text.ToUpper = data.Key.ToUpper Then
                For Each Office As String In data.Value
                    Me.OfficeCmbBox.Items.Add(Office)
                Next
            End If
        Next

        'If OfficeCmbBox.Items.Count > 0 Then
        '    If String.IsNullOrEmpty(OfficeCmbBox.Text) Then
        '        '' Make the top one current
        '        OfficeCmbBox.SelectedIndex = 0
        '    End If
        'End If

    End Sub

    '' Populates the business units for that region in that organisation
    Private Sub PopulateBusinessUnit()

        Try
            'If Not String.IsNullOrEmpty(RegionCmbBox.Text) Then
            BusinessUnitCmbBox.Items.Clear()
            FrameTypeCmbBox.Items.Clear()
            SizeCmbBox.Items.Clear()
            OrientationCmbBox.Items.Clear()

            '' Sort the list
            BusinessUnitCmbBox.Sorted = True
            For Each item As Object In AllDrawingSheetsCollection

                If item.organisation.ToString.ToUpper = OrganisationCmbBox.Text.ToUpper Then

                    If item.region.ToString.ToUpper = RegionCmbBox.Text.ToUpper Then

                        '' Check to see if the selected region is the same as the one in the collection we are iterating
                        '  If IsValueInComboBox(RegionCmbBox, item.Region.ToUpper) = True Then
                        ' Check that the Business Unit is not already in the list
                        If IsValueInComboBox(BusinessUnitCmbBox, item.BusinessUnit.ToUpper) = False Then
                            BusinessUnitCmbBox.Items.Add(item.BusinessUnit)
                        End If
                        ' End If
                        'If BusinessUnitCmbBox.Items.Count > 0 Then
                        '    If String.IsNullOrEmpty(BusinessUnitCmbBox.Text) Then
                        '        '' Make the top one current
                        '        BusinessUnitCmbBox.SelectedIndex = 0
                        '    End If
                        'End If

                    End If

                End If

            Next
            'End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    '' When the selected business unit changes update the frame types for that business unit
    Private Sub BusinessUnitCmbBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles BusinessUnitCmbBox.SelectedIndexChanged

        If IsInitializing = True Then Exit Sub

        PopulateFrameTypes()

    End Sub

    '' Populates the frame types for that business units in that region in that organisation
    Private Sub PopulateFrameTypes()

        Try
            'If Not String.IsNullOrEmpty(BusinessUnitCmbBox.Text) Then
            FrameTypeCmbBox.Items.Clear()
            SizeCmbBox.Items.Clear()
            OrientationCmbBox.Items.Clear()

            '' Sort the list
            FrameTypeCmbBox.Sorted = True
            For Each item As Object In AllDrawingSheetsCollection
                If item.organisation.ToString.ToUpper = OrganisationCmbBox.Text.ToUpper Then
                    If item.region.ToString.ToUpper = RegionCmbBox.Text.ToUpper Then
                        If item.businessunit.ToString.ToUpper = BusinessUnitCmbBox.Text.ToUpper Then
                            '' Check to see if the selected Business Unit is the same as the one in the collection we are iterating
                            ' If IsValueInComboBox(BusinessUnitCmbBox, item.BusinessUnit.ToUpper) = True Then
                            ' Check that the Frame Type is not already in the list
                            If IsValueInComboBox(FrameTypeCmbBox, item.frametype.ToUpper) = False Then
                                FrameTypeCmbBox.Items.Add(item.FrameType)
                            End If
                            '  End If

                            'If FrameTypeCmbBox.Items.Count > 0 Then
                            '    If String.IsNullOrEmpty(FrameTypeCmbBox.Text) Then
                            '        '' Make the top one current
                            '        FrameTypeCmbBox.SelectedIndex = 0
                            '    End If
                            'End If

                        End If

                    End If
                End If

            Next
            'End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    '' When the selected frame type changes update the Sizes for that frame type in that business unit for that region in that organisation
    Private Sub FrameTypeCmbBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles FrameTypeCmbBox.SelectedIndexChanged

        If IsInitializing = True Then Exit Sub

        PopulateSizes()

    End Sub

    '' Populates the sizes in that frame type for that business units in that region in that organisation
    Private Sub PopulateSizes()
        Try
            'If Not String.IsNullOrEmpty(FrameTypeCmbBox.Text) Then
            SizeCmbBox.Items.Clear()
            OrientationCmbBox.Items.Clear()

            '' Sort the list
            SizeCmbBox.Sorted = True
            For Each item As Object In AllDrawingSheetsCollection

                If item.organisation.ToString.ToUpper = OrganisationCmbBox.Text.ToUpper Then
                    If item.region.ToString.ToUpper = RegionCmbBox.Text.ToUpper Then
                        If item.businessunit.ToString.ToUpper = BusinessUnitCmbBox.Text.ToUpper Then
                            If item.frametype.ToString.ToUpper = FrameTypeCmbBox.Text.ToUpper Then

                                '' Check to see if the selected Business Unit is the same as the one in the collection we are iterating
                                'If IsValueInComboBox(BusinessUnitCmbBox, item.BusinessUnit.ToUpper) = True Then
                                '    ' Check that the Frame Type is not already in the list
                                '    If IsValueInComboBox(FrameTypeCmbBox, item.frametype.ToUpper) = False Then
                                '        FrameTypeCmbBox.Items.Add(item.FrameType)
                                '    End If
                                'End If

                                'If FrameTypeCmbBox.Items.Count > 0 Then
                                '    If String.IsNullOrEmpty(FrameTypeCmbBox.Text) Then
                                '        '' Make the top one current
                                '        FrameTypeCmbBox.SelectedIndex = 0
                                '    End If
                                'End If

                                '' Check to see if the selected Frame Type is the same as the one in the collection we are iterating
                                '  If IsValueInComboBox(FrameTypeCmbBox, item.FrameType.ToUpper) = True Then
                                ' Check that the Frame Type is not already in the list
                                If IsValueInComboBox(SizeCmbBox, item.Size.ToUpper) = False Then
                                    SizeCmbBox.Items.Add(item.Size)
                                End If
                                ' End If
                                'If SizeCmbBox.Items.Count > 0 Then
                                '    If String.IsNullOrEmpty(SizeCmbBox.Text) Then
                                '        '' Make the top one current
                                '        SizeCmbBox.SelectedIndex = 0
                                '    End If
                                'End If

                            End If

                        End If


                    End If
                End If

            Next
            'End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    '' When the selected size changes update the orientations for those sizes in that frame type in that business unit for that region in that organisation
    Private Sub SizeCmbBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles SizeCmbBox.SelectedIndexChanged

        If IsInitializing = True Then Exit Sub

        PopulateOrientation()

    End Sub

    Private Sub PopulateOrientation()

        Try
            'If Not String.IsNullOrEmpty(SizeCmbBox.Text) Then
            OrientationCmbBox.Items.Clear()
            '' Sort the list
            OrientationCmbBox.Sorted = True
            For Each item As Object In AllDrawingSheetsCollection

                If item.organisation.ToString.ToUpper = OrganisationCmbBox.Text.ToUpper Then
                    If item.region.ToString.ToUpper = RegionCmbBox.Text.ToUpper Then
                        If item.businessunit.ToString.ToUpper = BusinessUnitCmbBox.Text.ToUpper Then
                            If item.frametype.ToString.ToUpper = FrameTypeCmbBox.Text.ToUpper Then
                                If item.size.ToString.ToUpper = SizeCmbBox.Text.ToUpper Then
                                    '' Check to see if the selected size is the same as the one in the collection we are iterating
                                    '  If IsValueInComboBox(SizeCmbBox, item.Size.ToUpper) = True Then
                                    ' Check that the Orientation is not already in the list
                                    If IsValueInComboBox(OrientationCmbBox, item.Orientation.ToUpper) = False Then
                                        OrientationCmbBox.Items.Add(item.Orientation)
                                    End If
                                    '  End If
                                    'If OrientationCmbBox.Items.Count > 0 Then
                                    '    If String.IsNullOrEmpty(OrientationCmbBox.Text) Then
                                    '        '' Make the top one current
                                    '        OrientationCmbBox.SelectedIndex = 0
                                    '    End If
                                    'End If
                                End If
                            End If
                        End If
                    End If
                End If
            Next
            ' End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Public Function IsValueInComboBox(cmbbox As ComboBox, StringToFind As String) As Boolean

        Dim resultIndex As Integer = -1
        Dim result As Boolean = False

        resultIndex = cmbbox.FindStringExact(StringToFind)

        If resultIndex > -1 Then
            ' Found text, do something here
            result = True
        Else
            ' Did not find text, do something here
            result = False
        End If

        Return result

    End Function

    Private Sub OK_Button_Click(sender As System.Object, e As System.EventArgs) Handles OK_Button.Click

        Try

            Dim TitleSheetToInsert As String = String.Empty
            Dim AttributeSheetToInsert As String = String.Empty

            TitleSheetToInsert = Settings.Manager.AE.DrawingSheetsPath.CombinePath(OrganisationCmbBox.Text & "_" & _
                             RegionCmbBox.Text & "_" & _
                             BusinessUnitCmbBox.Text & "_" & _
                             FrameTypeCmbBox.Text & "_" & _
                             SizeCmbBox.Text & "_" & _
                             OrientationCmbBox.Text & "_SHEET.DWG")


            AttributeSheetToInsert = Settings.Manager.AE.DrawingSheetsPath.CombinePath(OrganisationCmbBox.Text & "_" & _
                             RegionCmbBox.Text & "_" & _
                             BusinessUnitCmbBox.Text & "_" & _
                             FrameTypeCmbBox.Text & "_" & _
                             SizeCmbBox.Text & "_" & _
                             OrientationCmbBox.Text & "_ATT.DWG")

            Dim Insertpoint(2) As Double
            Insertpoint(0) = 0 : Insertpoint(1) = 0 : Insertpoint(2) = 0

            Dim ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor

            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)

                Dim DrawingSheetGeometryBlockReference As Autodesk.AutoCAD.Interop.Common.AcadBlockReference

                If System.IO.File.Exists(TitleSheetToInsert) Then
                    If WhichSpace() = "PaperSpace" Then
                        DrawingSheetGeometryBlockReference = ThisDrawingUtilities.PaperSpace.InsertBlock(Insertpoint, TitleSheetToInsert, 1.0#, 1.0#, 1.0#, 0)
                    Else
                        DrawingSheetGeometryBlockReference = ThisDrawingUtilities.ModelSpace.InsertBlock(Insertpoint, TitleSheetToInsert, 1.0#, 1.0#, 1.0#, 0)
                    End If
                    '' Explode the _SHEET DWG block that was just inserted so we get access to the Address block
                    DrawingSheetGeometryBlockReference.Explode()
                    DrawingSheetGeometryBlockReference.Delete()
                End If

                If System.IO.File.Exists(AttributeSheetToInsert) Then
                    If WhichSpace() = "PaperSpace" Then
                        ThisDrawingUtilities.PaperSpace.InsertBlock(Insertpoint, AttributeSheetToInsert, 1.0#, 1.0#, 1.0#, 0)
                    Else
                        ThisDrawingUtilities.ModelSpace.InsertBlock(Insertpoint, AttributeSheetToInsert, 1.0#, 1.0#, 1.0#, 0)
                    End If
                End If

            End Using

            ThisDrawingUtilities.Application.ZoomExtents()
            ThisDrawingUtilities.Regen(Autodesk.AutoCAD.Interop.Common.AcRegenType.acAllViewports)


            ChangeAllAddresses()

            Me.Hide()
            Me.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub ChangeAllAddresses()


        Dim Address As List(Of String) = Nothing
        Dim iAddress As Integer
        Dim svarsfile As String

        svarsfile = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)

        Dim Addresses As Dictionary(Of String, List(Of String)) = Ini.ReadValues(svarsfile, "ADDRESSES", ";")
        For Each data As KeyValuePair(Of String, List(Of String)) In Addresses
            If Me.OfficeCmbBox.SelectedItem.ToString.Trim = data.Key.Trim Then
                Address = data.Value
                iAddress = 0
                Exit For
            End If
        Next

        Using UI As EditorUserInteraction = Ed.StartUserInteraction(Me.Handle)

            Dim ss As Autodesk.AutoCAD.Interop.AcadSelectionSet = SSetAdd("ss")

            Dim GrpC(0) As Short
            Dim GrpV(0) As Object

            GrpC(0) = 0
            GrpV(0) = "INSERT"
            Dim oBkRef1 As Autodesk.AutoCAD.Interop.Common.AcadBlockReference = Nothing
            ss.Select(Autodesk.AutoCAD.Interop.Common.AcSelect.acSelectionSetAll, , , GrpC, GrpV)

            If ss.Count > 0 Then

                For Each ObjBlockRef In ss

                    If UCase(ObjBlockRef.EffectiveName) Like UCase("*_*_*_*_*_*_ADDRESS") Then
                        'Clears all address attributes
                        For Each att As AcadAttributeReference In DirectCast(ObjBlockRef.GetAttributes, IEnumerable)
                            If att.TagString.ToString.Contains("ADDRESSLINE") Then
                                att.TextString = ""
                            End If
                        Next

                        For iAddress = 0 To Address.Count - 1
                            For Each att As AcadAttributeReference In DirectCast(ObjBlockRef.GetAttributes, IEnumerable)
                                If att.TagString = "ADDRESSLINE" & iAddress + 1 Then
                                    att.TextString = Address(iAddress)
                                    Exit For
                                End If
                            Next
                        Next
                    End If
                Next ObjBlockRef

            End If

        End Using

        ThisDrawingUtilities.Application.Update()

    End Sub
    Private Sub Help_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Help_Button.Click

        Try
            CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub Cancel_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cancel_Button.Click

        Try
            Me.Hide()
            Me.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub InsertClientSheet_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles InsertClientSheet.Click

        Try

            Dim ConfigName As String
            Dim ModName As String
            Dim sClientLibraryPath As String

            If ThisDrawingIsConfigured() = True Then

                GetConfigSettings()

                ConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME")

                Me.Hide()
                Me.Close()

                sClientLibraryPath = String.Empty

                If RuleAccessors.GetruleValue("TESTCONFIG", "False", True, False).IsTrue Then
                    If UCase(RUNTIMEConfigPath) Like "*T@*" Then
                        ModName = UCase(RUNTIMEConfigPath)
                    Else
                        ModName = Replace(UCase(RUNTIMEConfigPath), UCase(ConfigName), "T@" & UCase(ConfigName))
                    End If

                Else
                    ModName = RUNTIMEConfigPath
                End If

                If System.IO.File.Exists(ModName.CombinePath("Support", Settings.Manager.AE.DrawingSheetsFileName)) Then
                    sClientLibraryPath = ModName.CombinePath("Support", Settings.Manager.AE.DrawingSheetsFileName) & "/BLOCKS"
                Else

                    Acad_MessageBox(Settings.Manager.AE.DrawingSheetsFileName & " is not present in this configuration. " & vbCrLf & "The Drawing Sheet tool will now open DesignCenter in the configuration support folder in case you wish to select an alternative.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                    sClientLibraryPath = ModName.CombinePath("Support")
                End If

                If CInt(ThisDrawingUtilities.GetVariable("ADCSTATE")) <> 1 Then
                    ThisDrawingUtilities.SendCommand("'_ADCENTER" & vbCr)
                    ThisDrawingUtilities.SendCommand("_.adcnavigate " & sClientLibraryPath & vbCr)
                Else
                    ThisDrawingUtilities.SendCommand("_.adcnavigate " & sClientLibraryPath & vbCr)
                End If

            Else

                Acad_MessageBox("This drawing has no configuration - you will need to navigate manually to your desired location", , , , , , , True, logName)
                ThisDrawingUtilities.SendCommand("(Command ""adcenter"")" & vbCr)

            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

End Class
