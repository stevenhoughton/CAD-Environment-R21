Friend Class LineType

    Private m_sLineTypeName As String ' name of linetype
    Private m_sDescription As String ' description of linetype
    Private m_sDefintion As String ' the actual definition of the linetype

    Public Property Name() As String
        Get
            Name = m_sLineTypeName
        End Get
        Set(ByVal Value As String)
            If m_sLineTypeName = "" Then
                m_sLineTypeName = Value
            End If
        End Set
    End Property

    Public Property Description() As String
        Get
            Description = m_sDescription
        End Get
        Set(ByVal Value As String)
            If m_sDescription = "" Then
                m_sDescription = Value
            End If
        End Set
    End Property

    Public Property Definition() As String
        Get
            Definition = m_sDefintion
        End Get
        Set(ByVal Value As String)
            If m_sDefintion = "" Then
                m_sDefintion = Value
            End If
        End Set

    End Property

    Public Sub New()
        MyBase.New()
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

End Class