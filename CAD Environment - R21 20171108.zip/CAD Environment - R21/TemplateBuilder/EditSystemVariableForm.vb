Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Friend Class EditSystemVariableForm
    Inherits System.Windows.Forms.Form

    ' class variable for the listitem that we're currently editing
    Private m_pListItem As System.Windows.Forms.ListViewItem
    ' boolean to indicate if we're editing sysvars or rules
    Private m_bRules As Boolean
    Dim ContentWizardDVB As New TemplateBuilder
    Dim IsInitializing As Boolean = True

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   Display
    '
    '   Arguments:      Listview Listitem and boolean indicating if we're
    '                   editing rules or system variables.
    '
    '   Description:    First method called to display this form.
    '                   It sets our class variables and the initial startup
    '                   values of the controls on the form.
    '
    '   Returns:        Nothing.
    '
    '------------------------------------------------------------------------------

    Public Sub Display(ByRef pItem As System.Windows.Forms.ListViewItem, ByRef bRules As Boolean)
        m_bRules = bRules

        ' set the class variavle to the var passed in
        m_pListItem = pItem

        ' set the caption on the form
        Me.Text = "Edit " & pItem.Text & " " & IIf(m_bRules, "Rule", "System Variable")

        ' set the description
        lblDesc.Text = pItem.SubItems.Item(1).Text
        Me.Text = "Edit: " & pItem.Text

        ' disable the OK button...
        cmdOK.Enabled = False

        ' set the default value in the edit box
        txtValue.Text = pItem.SubItems.Item(2).Text

        ' display the dialog
        Me.ShowDialog()
    End Sub

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   cmdCancel_Click
    '
    '   Arguments:      None
    '
    '   Description:    Cancel button event procedure.
    '
    '   Returns:        Nothing.
    '
    '------------------------------------------------------------------------------

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    '------------------------------------------------------------------------------
    '
    '   Function/Sub:   cmdOK_Click
    '
    '   Arguments:      None
    '
    '   Description:    OK button event procedure.
    '                   Checks our boolean to determine whether we're editing
    '                   rules or sysvars. If sysvars, then
    '                   it will determine the type of sysvar by getting value
    '                   from Acad, then try to set the variable with the value
    '                   enered intot the editbox. If it can't, then it warns the
    '                   user and asks to try again.
    '                   If we're doing rules, then it determines from the listitem
    '                   passed in (hidden dxf code column), what type to try to
    '                   convert the textbox value to. If it fails it warns the user.
    '
    '   Returns:        Nothing.
    '
    '------------------------------------------------------------------------------

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click

        Dim vSysVar As Object

        ' enable error trapping
        On Error Resume Next

        If Not m_bRules Then
            ' get the system variable that we've been editing

            vSysVar = ThisDrawingUtilities.GetVariable(m_pListItem.Text)

            ' check what type of variable we have so we can
            ' use the same type to set it
            Select Case VarType(vSysVar)
                Case VariantType.String ' string
                    ' do nothing - just take the textbox's value as is
                    ' try setting the variable to value in textbox
                    ThisDrawingUtilities.SetVariable(m_pListItem.Text, CStr(txtValue.Text))
                    If Err.Number = -2145320858 Then
                        Information.Err.Clear()
                        Acad_MessageBox("This System variable cannot be set to that value see AutoCAD help for valid values", "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                        txtValue.Focus()
                        txtValue.SelectionStart = 0
                        txtValue.SelectionLength = Len(txtValue.Text)
                        Exit Sub
                    ElseIf CBool(Err.Number) Then
                        Information.Err.Clear()
                        ' inform the user they made a mistake
                        Acad_MessageBox("System variable must be a valid string", "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                        ' set focus to the textbox
                        txtValue.Focus()
                        txtValue.SelectionStart = 0
                        txtValue.SelectionLength = Len(txtValue.Text)
                        Exit Sub
                    End If
                    m_pListItem.SubItems.Item(2).Text = txtValue.Text
                Case VariantType.Short ' integer
                    ' try setting the variable to an integer conversion
                    ' of the textbox's value
                    ThisDrawingUtilities.SetVariable(m_pListItem.Text, CShort(txtValue.Text))
                    If Err.Number = -2145320858 Then
                        Information.Err.Clear()
                        Acad_MessageBox("This System variable cannot be set to that value see AutoCAD help for valid values", "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                        txtValue.Focus()
                        txtValue.SelectionStart = 0
                        txtValue.SelectionLength = Len(txtValue.Text)
                        Exit Sub
                    ElseIf CBool(Err.Number) Then
                        Information.Err.Clear()
                        Acad_MessageBox("System variable must be an valid integer", "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                        ' set focus to the textbox
                        txtValue.Focus()
                        txtValue.SelectionStart = 0
                        txtValue.SelectionLength = Len(txtValue.Text)
                        Exit Sub
                    End If
                    m_pListItem.SubItems.Item(2).Text = txtValue.Text
                Case VariantType.Double ' real number
                    ' try setting the variable to a double conversion
                    ' of the textbox's value
                    ThisDrawingUtilities.SetVariable(m_pListItem.Selected.ToString, Val(txtValue.Text) * 1.0#)
                    If Err.Number = -2145320858 Then
                        Information.Err.Clear()
                        Acad_MessageBox("This System variable cannot be set to that value see AutoCAD help for valid values", "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                        txtValue.Focus()
                        txtValue.SelectionStart = 0
                        txtValue.SelectionLength = Len(txtValue.Text)
                        Exit Sub
                    ElseIf CBool(Err.Number) Then
                        Acad_MessageBox(Err.Description, "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                        Information.Err.Clear()
                        ' set focus to the textbox
                        txtValue.Focus()
                        txtValue.SelectionStart = 0
                        txtValue.SelectionLength = Len(txtValue.Text)
                        Exit Sub
                    End If
                    m_pListItem.SubItems.Item(2).Text = txtValue.Text
                Case Else
                    Acad_MessageBox("Value can't be set at this time!", "StylesLoader Generated Error Message in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                    Exit Sub
            End Select
            '
        Else '...we're doing rules...so do some data validation...

            m_pListItem.SubItems.Item(2).Text = txtValue.Text

        End If

        '    m_pListItem.ForeColor = vbGreen

        ' unload the form
        Me.Close()

    End Sub

    Private Sub txtValue_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtValue.TextChanged

        If IsInitializing = True Then Exit Sub

        If Len(txtValue.Text) > 0 Then
            cmdOK.Enabled = True
        Else
            cmdOK.Enabled = False
        End If
    End Sub


    Private Sub frmEdit_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ' Not sure if this would work... test

        IsInitializing = False

        '' Workout out the Dialog Box Title 
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

        RepositionTitle(Me.lblTitle, Me)
    End Sub

    Private Sub EditSystemVariableForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub
End Class