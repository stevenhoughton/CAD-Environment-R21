Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Friend Class LinetypeFile

    'local variable to hold collection
    Private mCol As Collection
    ' local variable to hold file name
    Private m_sName As String
    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Public Function Add(ByRef sName As String, ByRef sDesc As String, ByRef sDef As String, Optional ByRef sKey As String = "") As LineType
        'create a new object
        Dim objNewMember As LineType = Nothing

        Try
            objNewMember = New LineType

            'set the properties passed into the method
            objNewMember.Name = sName
            objNewMember.Description = sDesc
            objNewMember.Definition = sDef

            If Len(sKey) = 0 Then
                mCol.Add(objNewMember)
            Else
                mCol.Add(objNewMember, sKey)
            End If

            'return the object created
            Add = objNewMember
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            Return objNewMember
        End Try

    End Function

    Public ReadOnly Property item(ByVal vntIndexKey As Object) As LineType
        Get
            'used when referencing an element in the collection
            'vntIndexKey contains either the Index or Key to the collection,
            'this is why it is declared as a Variant
            'Syntax: Set foo = x.Item(xyz) or Set foo = x.Item(5)
            item = CType(mCol.Item(vntIndexKey), LineType)
        End Get
    End Property

    Public ReadOnly Property Count() As Integer
        Get
            'used when retrieving the number of elements in the
            'collection. Syntax: Debug.Print x.Count
            Count = mCol.Count()
        End Get
    End Property

    Public Sub Remove(ByRef vntIndexKey As Object)
        'used when removing an element from the collection
        'vntIndexKey contains either the Index or Key, which is why
        'it is declared as a Variant
        'Syntax: x.Remove(xyz)

        mCol.Remove(vntIndexKey)
    End Sub

    Public Function Enumerate() As System.Collections.IEnumerator
        Enumerate = mCol.GetEnumerator
    End Function

    Public Sub New()
        MyBase.New()
        mCol = New Collection
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Public Function Has(ByVal sLinetype As String) As Boolean
        Dim pLtype As LineType
        For Each pLtype In mCol
            If UCase(pLtype.Name) = UCase(sLinetype) Then
                Has = True
                Exit Function
            End If
        Next pLtype
        Has = False
    End Function

End Class