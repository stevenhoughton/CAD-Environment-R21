Imports Jacobs.AutoCAD.TemplateBuilder.frmTemplateBuilder
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings
Imports Jacobs.AutoCAD.Utilities


Public Class PromptForNewConfigurationName
    Inherits System.Windows.Forms.Form

    Dim cDirectoryEntries As Collection = New Collection
    Dim NewConfigName As String = String.Empty
    Dim ExistingConfigName As String = String.Empty

    Const cfgCountry As Integer = 0
    Const cfgRegion As Integer = 1
    Const cfgClient As Integer = 2
    Const cfgDisciplines As Integer = 3

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Friend WithEvents ActionGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ModifyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NewRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NewUsingRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents NextButton As System.Windows.Forms.Button
    Friend WithEvents StatusLabel As System.Windows.Forms.Label
    Friend WithEvents HideRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RemoveRadioButton As System.Windows.Forms.RadioButton

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lbTestConfigurations As System.Windows.Forms.ListBox
    Friend WithEvents txtClient As System.Windows.Forms.TextBox
    Friend WithEvents lblClient As System.Windows.Forms.Label
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents btnSelect As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents Help_Button As System.Windows.Forms.Button
    Friend WithEvents ClientTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RegionsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CountriesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents CountriesLabel As System.Windows.Forms.Label
    Friend WithEvents DisciplinesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ClientLabel As System.Windows.Forms.Label
    Friend WithEvents RegionsLabel As System.Windows.Forms.Label
    Friend WithEvents DisciplinesLabel As System.Windows.Forms.Label
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents Button_Help As System.Windows.Forms.Button
    Friend WithEvents Title_Label As System.Windows.Forms.Label
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents SelectExistingGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ExistingClientsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingCountriesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingCountriesLabel As System.Windows.Forms.Label
    Friend WithEvents ExistingRegionsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingRegionsLabel As System.Windows.Forms.Label
    Friend WithEvents ExistingClientsLabel As System.Windows.Forms.Label
    Friend WithEvents ExistingDisciplinesComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ExistingDisciplinesLabel As System.Windows.Forms.Label
    Friend WithEvents NewGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PromptForNewConfigurationName))
        Me.ClientTextBox = New System.Windows.Forms.TextBox()
        Me.RegionsComboBox = New System.Windows.Forms.ComboBox()
        Me.CountriesComboBox = New System.Windows.Forms.ComboBox()
        Me.CountriesLabel = New System.Windows.Forms.Label()
        Me.DisciplinesComboBox = New System.Windows.Forms.ComboBox()
        Me.ClientLabel = New System.Windows.Forms.Label()
        Me.RegionsLabel = New System.Windows.Forms.Label()
        Me.DisciplinesLabel = New System.Windows.Forms.Label()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Button_Help = New System.Windows.Forms.Button()
        Me.Title_Label = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.SelectExistingGroupBox = New System.Windows.Forms.GroupBox()
        Me.ExistingClientsComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingCountriesComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingCountriesLabel = New System.Windows.Forms.Label()
        Me.ExistingRegionsComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingRegionsLabel = New System.Windows.Forms.Label()
        Me.ExistingClientsLabel = New System.Windows.Forms.Label()
        Me.ExistingDisciplinesComboBox = New System.Windows.Forms.ComboBox()
        Me.ExistingDisciplinesLabel = New System.Windows.Forms.Label()
        Me.NewGroupBox = New System.Windows.Forms.GroupBox()
        Me.ActionGroupBox = New System.Windows.Forms.GroupBox()
        Me.HideRadioButton = New System.Windows.Forms.RadioButton()
        Me.RemoveRadioButton = New System.Windows.Forms.RadioButton()
        Me.NewUsingRadioButton = New System.Windows.Forms.RadioButton()
        Me.NewRadioButton = New System.Windows.Forms.RadioButton()
        Me.ModifyRadioButton = New System.Windows.Forms.RadioButton()
        Me.NextButton = New System.Windows.Forms.Button()
        Me.StatusLabel = New System.Windows.Forms.Label()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SelectExistingGroupBox.SuspendLayout()
        Me.NewGroupBox.SuspendLayout()
        Me.ActionGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'ClientTextBox
        '
        Me.ClientTextBox.Location = New System.Drawing.Point(436, 24)
        Me.ClientTextBox.Name = "ClientTextBox"
        Me.ClientTextBox.Size = New System.Drawing.Size(228, 22)
        Me.ClientTextBox.TabIndex = 38
        '
        'RegionsComboBox
        '
        Me.RegionsComboBox.FormattingEnabled = True
        Me.RegionsComboBox.Location = New System.Drawing.Point(267, 24)
        Me.RegionsComboBox.Name = "RegionsComboBox"
        Me.RegionsComboBox.Size = New System.Drawing.Size(109, 24)
        Me.RegionsComboBox.TabIndex = 37
        '
        'CountriesComboBox
        '
        Me.CountriesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Australia", "Brazil", "Chile", "China", "India", "Malaysia", "Singapore", "United Kingdom"})
        Me.CountriesComboBox.FormattingEnabled = True
        Me.CountriesComboBox.Location = New System.Drawing.Point(85, 24)
        Me.CountriesComboBox.Name = "CountriesComboBox"
        Me.CountriesComboBox.Size = New System.Drawing.Size(107, 24)
        Me.CountriesComboBox.Sorted = True
        Me.CountriesComboBox.TabIndex = 36
        '
        'CountriesLabel
        '
        Me.CountriesLabel.AutoSize = True
        Me.CountriesLabel.Location = New System.Drawing.Point(22, 28)
        Me.CountriesLabel.Name = "CountriesLabel"
        Me.CountriesLabel.Size = New System.Drawing.Size(57, 17)
        Me.CountriesLabel.TabIndex = 35
        Me.CountriesLabel.Text = "Country"
        '
        'DisciplinesComboBox
        '
        Me.DisciplinesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Architecture", "Electrical", "Mechanical", "Piping", "Mining", "Civil", "Spatial"})
        Me.DisciplinesComboBox.FormattingEnabled = True
        Me.DisciplinesComboBox.Location = New System.Drawing.Point(753, 24)
        Me.DisciplinesComboBox.Name = "DisciplinesComboBox"
        Me.DisciplinesComboBox.Size = New System.Drawing.Size(121, 24)
        Me.DisciplinesComboBox.Sorted = True
        Me.DisciplinesComboBox.TabIndex = 33
        '
        'ClientLabel
        '
        Me.ClientLabel.AutoSize = True
        Me.ClientLabel.Location = New System.Drawing.Point(397, 28)
        Me.ClientLabel.Name = "ClientLabel"
        Me.ClientLabel.Size = New System.Drawing.Size(43, 17)
        Me.ClientLabel.TabIndex = 34
        Me.ClientLabel.Text = "Client"
        '
        'RegionsLabel
        '
        Me.RegionsLabel.AutoSize = True
        Me.RegionsLabel.Location = New System.Drawing.Point(208, 28)
        Me.RegionsLabel.Name = "RegionsLabel"
        Me.RegionsLabel.Size = New System.Drawing.Size(53, 17)
        Me.RegionsLabel.TabIndex = 31
        Me.RegionsLabel.Text = "Region"
        '
        'DisciplinesLabel
        '
        Me.DisciplinesLabel.AutoSize = True
        Me.DisciplinesLabel.Location = New System.Drawing.Point(690, 28)
        Me.DisciplinesLabel.Name = "DisciplinesLabel"
        Me.DisciplinesLabel.Size = New System.Drawing.Size(75, 17)
        Me.DisciplinesLabel.TabIndex = 32
        Me.DisciplinesLabel.Text = "Disciplines"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(750, 267)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(149, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'Button_Help
        '
        Me.Button_Help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_Help.Location = New System.Drawing.Point(24, 267)
        Me.Button_Help.Name = "Button_Help"
        Me.Button_Help.Size = New System.Drawing.Size(149, 23)
        Me.Button_Help.TabIndex = 40
        Me.Button_Help.Text = "Help"
        Me.Button_Help.UseVisualStyleBackColor = True
        '
        'Title_Label
        '
        Me.Title_Label.AutoSize = True
        Me.Title_Label.BackColor = System.Drawing.Color.Transparent
        Me.Title_Label.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Title_Label.ForeColor = System.Drawing.Color.White
        Me.Title_Label.Location = New System.Drawing.Point(143, 12)
        Me.Title_Label.Name = "Title_Label"
        Me.Title_Label.Size = New System.Drawing.Size(280, 35)
        Me.Title_Label.TabIndex = 41
        Me.Title_Label.Text = "Configuration Name"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 42
        Me.LogoPictureBox.TabStop = False
        '
        'SelectExistingGroupBox
        '
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingClientsComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingCountriesComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingCountriesLabel)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingRegionsComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingRegionsLabel)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingClientsLabel)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingDisciplinesComboBox)
        Me.SelectExistingGroupBox.Controls.Add(Me.ExistingDisciplinesLabel)
        Me.SelectExistingGroupBox.Location = New System.Drawing.Point(12, 120)
        Me.SelectExistingGroupBox.Name = "SelectExistingGroupBox"
        Me.SelectExistingGroupBox.Size = New System.Drawing.Size(888, 62)
        Me.SelectExistingGroupBox.TabIndex = 43
        Me.SelectExistingGroupBox.TabStop = False
        Me.SelectExistingGroupBox.Text = "Select Existing Name"
        '
        'ExistingClientsComboBox
        '
        Me.ExistingClientsComboBox.FormattingEnabled = True
        Me.ExistingClientsComboBox.Location = New System.Drawing.Point(439, 24)
        Me.ExistingClientsComboBox.Name = "ExistingClientsComboBox"
        Me.ExistingClientsComboBox.Size = New System.Drawing.Size(228, 24)
        Me.ExistingClientsComboBox.TabIndex = 46
        '
        'ExistingCountriesComboBox
        '
        Me.ExistingCountriesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Australia", "Brazil", "Chile", "China", "India", "Malaysia", "Singapore", "United Kingdom"})
        Me.ExistingCountriesComboBox.FormattingEnabled = True
        Me.ExistingCountriesComboBox.Location = New System.Drawing.Point(85, 24)
        Me.ExistingCountriesComboBox.Name = "ExistingCountriesComboBox"
        Me.ExistingCountriesComboBox.Size = New System.Drawing.Size(109, 24)
        Me.ExistingCountriesComboBox.Sorted = True
        Me.ExistingCountriesComboBox.TabIndex = 44
        '
        'ExistingCountriesLabel
        '
        Me.ExistingCountriesLabel.AutoSize = True
        Me.ExistingCountriesLabel.Location = New System.Drawing.Point(24, 28)
        Me.ExistingCountriesLabel.Name = "ExistingCountriesLabel"
        Me.ExistingCountriesLabel.Size = New System.Drawing.Size(57, 17)
        Me.ExistingCountriesLabel.TabIndex = 43
        Me.ExistingCountriesLabel.Text = "Country"
        '
        'ExistingRegionsComboBox
        '
        Me.ExistingRegionsComboBox.FormattingEnabled = True
        Me.ExistingRegionsComboBox.Location = New System.Drawing.Point(267, 24)
        Me.ExistingRegionsComboBox.Name = "ExistingRegionsComboBox"
        Me.ExistingRegionsComboBox.Size = New System.Drawing.Size(111, 24)
        Me.ExistingRegionsComboBox.TabIndex = 45
        '
        'ExistingRegionsLabel
        '
        Me.ExistingRegionsLabel.AutoSize = True
        Me.ExistingRegionsLabel.Location = New System.Drawing.Point(210, 28)
        Me.ExistingRegionsLabel.Name = "ExistingRegionsLabel"
        Me.ExistingRegionsLabel.Size = New System.Drawing.Size(53, 17)
        Me.ExistingRegionsLabel.TabIndex = 39
        Me.ExistingRegionsLabel.Text = "Region"
        '
        'ExistingClientsLabel
        '
        Me.ExistingClientsLabel.AutoSize = True
        Me.ExistingClientsLabel.Location = New System.Drawing.Point(399, 28)
        Me.ExistingClientsLabel.Name = "ExistingClientsLabel"
        Me.ExistingClientsLabel.Size = New System.Drawing.Size(43, 17)
        Me.ExistingClientsLabel.TabIndex = 42
        Me.ExistingClientsLabel.Text = "Client"
        '
        'ExistingDisciplinesComboBox
        '
        Me.ExistingDisciplinesComboBox.AutoCompleteCustomSource.AddRange(New String() {"Architecture", "Electrical", "Mechanical", "Piping", "Mining", "Civil", "Spatial"})
        Me.ExistingDisciplinesComboBox.FormattingEnabled = True
        Me.ExistingDisciplinesComboBox.Location = New System.Drawing.Point(755, 24)
        Me.ExistingDisciplinesComboBox.Name = "ExistingDisciplinesComboBox"
        Me.ExistingDisciplinesComboBox.Size = New System.Drawing.Size(121, 24)
        Me.ExistingDisciplinesComboBox.Sorted = True
        Me.ExistingDisciplinesComboBox.TabIndex = 41
        '
        'ExistingDisciplinesLabel
        '
        Me.ExistingDisciplinesLabel.AutoSize = True
        Me.ExistingDisciplinesLabel.Location = New System.Drawing.Point(692, 28)
        Me.ExistingDisciplinesLabel.Name = "ExistingDisciplinesLabel"
        Me.ExistingDisciplinesLabel.Size = New System.Drawing.Size(75, 17)
        Me.ExistingDisciplinesLabel.TabIndex = 40
        Me.ExistingDisciplinesLabel.Text = "Disciplines"
        '
        'NewGroupBox
        '
        Me.NewGroupBox.Controls.Add(Me.CountriesComboBox)
        Me.NewGroupBox.Controls.Add(Me.CountriesLabel)
        Me.NewGroupBox.Controls.Add(Me.RegionsComboBox)
        Me.NewGroupBox.Controls.Add(Me.RegionsLabel)
        Me.NewGroupBox.Controls.Add(Me.ClientTextBox)
        Me.NewGroupBox.Controls.Add(Me.ClientLabel)
        Me.NewGroupBox.Controls.Add(Me.DisciplinesComboBox)
        Me.NewGroupBox.Controls.Add(Me.DisciplinesLabel)
        Me.NewGroupBox.Location = New System.Drawing.Point(12, 188)
        Me.NewGroupBox.Name = "NewGroupBox"
        Me.NewGroupBox.Size = New System.Drawing.Size(888, 62)
        Me.NewGroupBox.TabIndex = 44
        Me.NewGroupBox.TabStop = False
        Me.NewGroupBox.Text = "New Name"
        '
        'ActionGroupBox
        '
        Me.ActionGroupBox.Controls.Add(Me.HideRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.RemoveRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.NewUsingRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.NewRadioButton)
        Me.ActionGroupBox.Controls.Add(Me.ModifyRadioButton)
        Me.ActionGroupBox.Location = New System.Drawing.Point(11, 70)
        Me.ActionGroupBox.Name = "ActionGroupBox"
        Me.ActionGroupBox.Size = New System.Drawing.Size(888, 44)
        Me.ActionGroupBox.TabIndex = 47
        Me.ActionGroupBox.TabStop = False
        Me.ActionGroupBox.Text = "Action"
        '
        'HideRadioButton
        '
        Me.HideRadioButton.AutoSize = True
        Me.HideRadioButton.Location = New System.Drawing.Point(738, 19)
        Me.HideRadioButton.Name = "HideRadioButton"
        Me.HideRadioButton.Size = New System.Drawing.Size(58, 21)
        Me.HideRadioButton.TabIndex = 4
        Me.HideRadioButton.Text = "Hide"
        Me.HideRadioButton.UseVisualStyleBackColor = True
        '
        'RemoveRadioButton
        '
        Me.RemoveRadioButton.AutoSize = True
        Me.RemoveRadioButton.Location = New System.Drawing.Point(565, 19)
        Me.RemoveRadioButton.Name = "RemoveRadioButton"
        Me.RemoveRadioButton.Size = New System.Drawing.Size(81, 21)
        Me.RemoveRadioButton.TabIndex = 3
        Me.RemoveRadioButton.Text = "Remove"
        Me.RemoveRadioButton.UseVisualStyleBackColor = True
        '
        'NewUsingRadioButton
        '
        Me.NewUsingRadioButton.AutoSize = True
        Me.NewUsingRadioButton.Location = New System.Drawing.Point(341, 19)
        Me.NewUsingRadioButton.Name = "NewUsingRadioButton"
        Me.NewUsingRadioButton.Size = New System.Drawing.Size(148, 21)
        Me.NewUsingRadioButton.TabIndex = 2
        Me.NewUsingRadioButton.Text = "New Using Existing"
        Me.NewUsingRadioButton.UseVisualStyleBackColor = True
        '
        'NewRadioButton
        '
        Me.NewRadioButton.AutoSize = True
        Me.NewRadioButton.Checked = True
        Me.NewRadioButton.Location = New System.Drawing.Point(22, 19)
        Me.NewRadioButton.Name = "NewRadioButton"
        Me.NewRadioButton.Size = New System.Drawing.Size(56, 21)
        Me.NewRadioButton.TabIndex = 1
        Me.NewRadioButton.TabStop = True
        Me.NewRadioButton.Text = "New"
        Me.NewRadioButton.UseVisualStyleBackColor = True
        '
        'ModifyRadioButton
        '
        Me.ModifyRadioButton.AutoSize = True
        Me.ModifyRadioButton.Location = New System.Drawing.Point(177, 19)
        Me.ModifyRadioButton.Name = "ModifyRadioButton"
        Me.ModifyRadioButton.Size = New System.Drawing.Size(70, 21)
        Me.ModifyRadioButton.TabIndex = 0
        Me.ModifyRadioButton.Text = "Modify"
        Me.ModifyRadioButton.UseVisualStyleBackColor = True
        '
        'NextButton
        '
        Me.NextButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NextButton.Enabled = False
        Me.NextButton.Location = New System.Drawing.Point(595, 267)
        Me.NextButton.Name = "NextButton"
        Me.NextButton.Size = New System.Drawing.Size(149, 23)
        Me.NextButton.TabIndex = 43
        Me.NextButton.Text = "Next"
        Me.NextButton.UseVisualStyleBackColor = True
        '
        'StatusLabel
        '
        Me.StatusLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.StatusLabel.AutoSize = True
        Me.StatusLabel.Location = New System.Drawing.Point(204, 272)
        Me.StatusLabel.Name = "StatusLabel"
        Me.StatusLabel.Size = New System.Drawing.Size(0, 17)
        Me.StatusLabel.TabIndex = 48
        '
        'PromptForNewConfigurationName
        '
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(920, 305)
        Me.Controls.Add(Me.StatusLabel)
        Me.Controls.Add(Me.ActionGroupBox)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.NewGroupBox)
        Me.Controls.Add(Me.NextButton)
        Me.Controls.Add(Me.SelectExistingGroupBox)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.Title_Label)
        Me.Controls.Add(Me.Button_Help)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(917, 190)
        Me.Name = "PromptForNewConfigurationName"
        Me.Text = "Select an existing configuration to modify or create a new one"
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SelectExistingGroupBox.ResumeLayout(False)
        Me.SelectExistingGroupBox.PerformLayout()
        Me.NewGroupBox.ResumeLayout(False)
        Me.NewGroupBox.PerformLayout()
        Me.ActionGroupBox.ResumeLayout(False)
        Me.ActionGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

#Region "Start Here"

    Private Sub PromptForNewConfigurationName_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        '' Clear the collection
        cDirectoryEntries.Clear()

        '' Get all the countries based on the existing configs
        CEGetDirectories(Settings.Manager.AE.ClientsConfigurationPath, cDirectoryEntries, Settings.Manager.AE.TemplatesToHideFileNamePathed, Settings.IsUserValidSystemAdministrator)

        '' Read all the folders on the machine and populate the combo boxes based on that
        PopulateExistingListBoxes()

        '' If the drawing is configured then use the template name to set the values on the existing template name
        PopulateDefaultValues()

        '' Populate all the possible countries, regions and disciplines that can be used to create new configs
        PopulateListBoxes()

    End Sub

#End Region

#Region "Enabling and Disabling Of Controls"

    Sub EnableDisableSelectNewGroupBoxes()

        If NewRadioButton.Checked = True Then
            SelectExistingGroupBox.Enabled = False
            SelectExistingGroupBox.Visible = False
            NewGroupBox.Enabled = True
            NewGroupBox.Visible = True
        End If

        If ModifyRadioButton.Checked = True Then
            SelectExistingGroupBox.Enabled = True
            SelectExistingGroupBox.Visible = True
            NewGroupBox.Enabled = False
            NewGroupBox.Visible = False
        End If

        If NewUsingRadioButton.Checked = True Then
            SelectExistingGroupBox.Enabled = True
            SelectExistingGroupBox.Visible = True
            NewGroupBox.Enabled = True
            NewGroupBox.Visible = True
        End If

        If RemoveRadioButton.Checked = True Then
            SelectExistingGroupBox.Enabled = True
            SelectExistingGroupBox.Visible = True
            NewGroupBox.Enabled = False
            NewGroupBox.Visible = False
        End If

    End Sub

    Sub EnableDisableNextButtonCheck()

        StatusLabel.Text = String.Empty

        If NewRadioButton.Checked = True Then
            If CountriesComboBox.Text = String.Empty Or
                RegionsComboBox.Text = String.Empty Or
                ClientTextBox.Text = String.Empty Or
                DisciplinesComboBox.Text = String.Empty Then
                NextButton.Enabled = False
                Exit Sub
            Else

                NewConfigName = CountriesComboBox.Text & "-" & RegionsComboBox.Text & "-" & ClientTextBox.Text & "-" & DisciplinesComboBox.Text


                If System.IO.Directory.Exists(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewConfigName)) Then
                    StatusLabel.Text = "Configuration name exists"
                    NextButton.Enabled = False
                Else
                    NextButton.Enabled = True
                End If
            End If
        End If

        If ModifyRadioButton.Checked = True Then
            If ExistingCountriesComboBox.Text = String.Empty Or
                ExistingRegionsComboBox.Text = String.Empty Or
                ExistingClientsComboBox.Text = String.Empty Or
                ExistingDisciplinesComboBox.Text = String.Empty Then
                NextButton.Enabled = False
                Exit Sub
            Else
                ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text
                NextButton.Enabled = True
            End If
        End If

        If NewUsingRadioButton.Checked = True Then
            If CountriesComboBox.Text = String.Empty Or
                RegionsComboBox.Text = String.Empty Or
                ClientTextBox.Text = String.Empty Or
                DisciplinesComboBox.Text = String.Empty Or
                ExistingCountriesComboBox.Text = String.Empty Or
                ExistingRegionsComboBox.Text = String.Empty Or
                ExistingClientsComboBox.Text = String.Empty Or
                ExistingDisciplinesComboBox.Text = String.Empty Then
                NextButton.Enabled = False
                Exit Sub
            Else

                NewConfigName = CountriesComboBox.Text & "-" & RegionsComboBox.Text & "-" & ClientTextBox.Text & "-" & DisciplinesComboBox.Text
                ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text
                NextButton.Enabled = True

            End If
        End If

        If RemoveRadioButton.Checked = True Then
            If ExistingCountriesComboBox.Text = String.Empty Or
                ExistingRegionsComboBox.Text = String.Empty Or
                ExistingClientsComboBox.Text = String.Empty Or
                ExistingDisciplinesComboBox.Text = String.Empty Then
                NextButton.Enabled = False
                Exit Sub
            Else
                ExistingConfigName = ExistingCountriesComboBox.Text & "-" & ExistingRegionsComboBox.Text & "-" & ExistingClientsComboBox.Text & "-" & ExistingDisciplinesComboBox.Text
                NextButton.Enabled = True
            End If
        End If

    End Sub

#End Region

#Region "Actions"

    Sub ModifyExisting()

        '' Stamp file with template name
        StampFileWithConfigName(ExistingConfigName)

    End Sub

    Sub NewUsing()

        '' Copy files from old template
        CopyExistingConfigFiles(NewConfigName, ExistingConfigName)

        '' Stamp file with template name
        StampFileWithConfigName(NewConfigName)

    End Sub

    Sub NewConfig()

        '' New folder to be created....
        CreateFolderStructure(NewConfigName)

        '' Stamp file with template name
        StampFileWithConfigName(NewConfigName)

    End Sub

#End Region

#Region "Helpers"

    Sub StampFileWithConfigName(ByVal NewName As String)

        RuleAccessors.AddRule("FULLCONFIGNAME", NewName, "Configuration Name", "0", "0")
        RuleAccessors.AddRule("CONFIGLEVEL", "CLIENT", "Configuration Level", "0", "0")

        Me.DialogResult = System.Windows.Forms.DialogResult.Yes
        Me.Close()

    End Sub

    Sub CreateFolderStructure(ByVal NewName As String)

        Try

            System.IO.Directory.CreateDirectory(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewName))
            System.IO.Directory.CreateDirectory(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewName, "Support"))
            'System.IO.Directory.CreateDirectory(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewName, "Fonts"))
            System.IO.Directory.CreateDirectory(Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewName, "Plot Styles"))

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub CopyExistingConfigFiles(ByVal NewName As String, ByVal OldConfigname As String)

        Try
            Dim Source As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(OldConfigname)
            Dim Destination As String = Settings.Manager.AE.ClientsConfigurationPath.CombinePath(NewName)

            CopyDirectory(Source, Destination)

            '' Rename DWG and DWT files
            If System.IO.File.Exists(Destination.CombinePath("Settings", OldConfigname & ".dwg")) Then

                System.IO.File.Copy(Destination.CombinePath("Settings", OldConfigname & ".dwg"), Destination.CombinePath("Settings", NewConfigName & ".dwg"))


            End If

            If System.IO.File.Exists(Destination.CombinePath("Settings", OldConfigname & ".dwt")) Then
                System.IO.File.Copy(Destination.CombinePath("Settings", OldConfigname & ".dwt"), Destination.CombinePath("Settings", NewConfigName & ".dwt"))
            End If

            If System.IO.File.Exists(Destination.CombinePath("Settings", OldConfigname & ".dwg")) Then
                System.IO.File.Delete(Destination.CombinePath("Settings", OldConfigname & ".dwg"))
            End If

            If System.IO.File.Exists(Destination.CombinePath("Settings", OldConfigname & ".dwt")) Then

                System.IO.File.Delete(Destination.CombinePath("Settings", OldConfigname & ".dwt"))


            End If

            '' Stamp Them with new template Name

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub CopyDirectory(ByVal sourcePath As String, ByVal destPath As String)

        If Not System.IO.Directory.Exists(destPath) Then
            System.IO.Directory.CreateDirectory(destPath)
        End If

        For Each file As String In System.IO.Directory.GetFiles(sourcePath)
            Dim dest As String = destPath.CombinePath(System.IO.Path.GetFileName(file))
            System.IO.File.Copy(file, dest, FileIO.UIOption.AllDialogs)
        Next

        For Each Folder As String In System.IO.Directory.GetDirectories(sourcePath)
            Dim dest As String = destPath.CombinePath(System.IO.Path.GetFileName(Folder))
            CopyDirectory(Folder, dest)
        Next

    End Sub

#End Region

#Region "Radio Button Events"

    Private Sub NewRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewRadioButton.CheckedChanged
        EnableDisableSelectNewGroupBoxes()
    End Sub

    Private Sub ModifyRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ModifyRadioButton.CheckedChanged
        EnableDisableSelectNewGroupBoxes()
    End Sub

    Private Sub NewUsingRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewUsingRadioButton.CheckedChanged
        EnableDisableSelectNewGroupBoxes()
    End Sub

    Private Sub RemoveRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveRadioButton.CheckedChanged
        EnableDisableSelectNewGroupBoxes()
    End Sub

#End Region

#Region "New Template Name Combo Boxes"

    Private Sub CountryComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CountriesComboBox.SelectedIndexChanged

        PopulateRegions()
        EnableDisableNextButtonCheck()

    End Sub

    Private Sub RegionsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegionsComboBox.SelectedIndexChanged

        EnableDisableNextButtonCheck()

    End Sub

    Private Sub ClientNameTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClientTextBox.TextChanged

        EnableDisableNextButtonCheck()

    End Sub

    Private Sub DisciplineComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisciplinesComboBox.SelectedIndexChanged

        EnableDisableNextButtonCheck()

    End Sub

    Public Sub PopulateWithCountriesFromFile(ByVal CmbBox As ComboBox, Optional ByVal AddGlobal As Boolean = False)

        Try

            RegionsComboBox.Text = String.Empty
            For Each Region As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.RegionsFileName))
                If Not CmbBox.Items.Contains(Region.Split(","c)(0)) Then
                    CmbBox.Items.Add(Region.Split(","c)(0))
                End If
            Next

            If AddGlobal = True Then
                ' Discontinued when using Regions file to derive countries
                'If Not CmbBox.Items.Contains("Global") Then
                '    CmbBox.Items.Add("Global")
                'End If
            End If
            CmbBox.Sorted = True

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Sub PopulateListBoxes()

        '' Load the Combo Boxes if required
        Try
            If CountriesComboBox.Items.Count = 0 Then
                ' GetCountries.PopulateWithCountries(CountriesComboBox, True)
                PopulateWithCountriesFromFile(CountriesComboBox, True)
            End If

            If RegionsComboBox.Items.Count = 0 Then
                PopulateRegions()
            End If

            If DisciplinesComboBox.Items.Count = 0 Then
                PopulateDisciplines()
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub PopulateRegions()

        RegionsComboBox.Items.Clear()
        RegionsComboBox.Text = String.Empty

        For Each Region As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.RegionsFileName))
            If Region.Split(","c)(0).ToUpper = CountriesComboBox.Text.ToUpper Then
                RegionsComboBox.Items.Add(Region.Split(","c)(1))
            End If
        Next

        RegionsComboBox.Sorted = True

    End Sub

    Sub PopulateDisciplines()

        DisciplinesComboBox.Items.Clear()
        DisciplinesComboBox.Text = String.Empty

        For Each Disicipline As String In ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.DisciplinesFileName))
            DisciplinesComboBox.Items.Add(Disicipline)
        Next
        DisciplinesComboBox.Sorted = True

    End Sub

#End Region

#Region "Existing List Boxes"

    Private Sub ExistingCountryComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingCountriesComboBox.SelectedIndexChanged

        PopulateExistingRegions()
        EnableDisableNextButtonCheck()

    End Sub

    Private Sub ExistingRegionComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingRegionsComboBox.SelectedIndexChanged

        PopulateExistingClients()
        EnableDisableNextButtonCheck()

    End Sub

    Private Sub ExistingClientComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingClientsComboBox.SelectedIndexChanged

        PopulateExistingDisciplines()
        EnableDisableNextButtonCheck()

    End Sub

    Private Sub ExistingDisciplinesComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExistingDisciplinesComboBox.SelectedIndexChanged

        EnableDisableNextButtonCheck()

    End Sub

    Sub PopulateExistingListBoxes()

        Try
            If ExistingCountriesComboBox.Text = String.Empty Then
                PopulateExistingCountries()
            Else
                If ExistingRegionsComboBox.Text = String.Empty Then
                    PopulateExistingRegions()
                Else
                    If ExistingClientsComboBox.Text = String.Empty Then
                        PopulateExistingClients()
                    Else
                        If ExistingDisciplinesComboBox.Text = String.Empty Then
                            PopulateExistingDisciplines()
                        End If
                    End If
                End If
            End If

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub PopulateExistingCountries(Optional ByRef Value As Object = Nothing)

        Try
            Me.ExistingCountriesComboBox.Items.Clear()

            For Each Item As String In cDirectoryEntries

                Dim SplitDir() As String = Item.Split("-"c)

                If SplitDir.Length = 4 Then
                    If Not FindStringInComboBox(SplitDir(cfgCountry), ExistingCountriesComboBox) Then
                        Me.ExistingCountriesComboBox.Items.Add(SplitDir(cfgCountry))
                    End If
                Else
                    GeneralMessageBox("Invalid Config Folder Name: " & Item, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , LogName)
                End If

            Next

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub PopulateExistingClients()

        Try
            Me.ExistingClientsComboBox.Items.Clear()

            For Each DirectoryItem As String In cDirectoryEntries

                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = ExistingRegionsComboBox.Text.ToUpper Then
                        If Not FindStringInComboBox(SplitDir(cfgClient), ExistingClientsComboBox) Then
                            Me.ExistingClientsComboBox.Items.Add(SplitDir(cfgClient))
                        End If
                    End If
                End If

            Next

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub PopulateExistingRegions(Optional ByRef Value As Object = Nothing)

        Try
            Me.ExistingRegionsComboBox.Items.Clear()

            For Each DirectoryItem As String In cDirectoryEntries

                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If Not FindStringInComboBox(SplitDir(cfgRegion), ExistingRegionsComboBox) Then
                        Me.ExistingRegionsComboBox.Items.Add(SplitDir(cfgRegion))
                    End If
                End If

            Next

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub PopulateExistingDisciplines()

        Try
            Me.ExistingDisciplinesComboBox.Items.Clear()

            For Each DirectoryItem As String In cDirectoryEntries

                Dim SplitDir() As String = Nothing
                SplitDir = DirectoryItem.Split("-"c)

                If SplitDir(cfgCountry).ToUpper = ExistingCountriesComboBox.Text.ToUpper Then
                    If SplitDir(cfgRegion).ToUpper = ExistingRegionsComboBox.Text.ToUpper Then
                        If SplitDir(cfgClient).ToUpper = ExistingClientsComboBox.Text.ToUpper Then
                            If Not FindStringInComboBox(SplitDir(cfgDisciplines), ExistingDisciplinesComboBox) Then
                                Me.ExistingDisciplinesComboBox.Items.Add(SplitDir(cfgDisciplines))
                            End If
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Sub PopulateDefaultValues()

        If ThisDrawingIsConfigured = True And
            IsThisAnOldConfigName = False Then

            '' If this drawing is configured assume we are going to modify the configuration
            ModifyRadioButton.Checked = True

            Dim ConfigName As String = RuleAccessors.GetruleValue("FULLCONFIGNAME")

            ExistingCountriesComboBox.Text = ConfigName.Split("-"c)(cfgCountry)
            ExistingRegionsComboBox.Text = ConfigName.Split("-"c)(cfgRegion)
            ExistingClientsComboBox.Text = ConfigName.Split("-"c)(cfgClient)
            ExistingDisciplinesComboBox.Text = ConfigName.Split("-"c)(cfgDisciplines)

        Else

            '' If this drawing is not configured assume we are going to create a new one
            NewRadioButton.Checked = True

        End If

    End Sub

    Private Sub ClearAllExistingComboBoxes()

        ExistingCountriesComboBox.Items.Clear()
        ExistingRegionsComboBox.Items.Clear()
        ExistingClientsComboBox.Items.Clear()
        ExistingDisciplinesComboBox.Items.Clear()

        ExistingCountriesComboBox.Text = String.Empty
        ExistingRegionsComboBox.Text = String.Empty
        ExistingClientsComboBox.Text = String.Empty
        ExistingDisciplinesComboBox.Text = String.Empty

    End Sub

#End Region

#Region "Dialog Box Buttons"

    Private Sub Button_Help_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Help.Click

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Hide()
        Me.Close()

    End Sub

    Private Sub NextButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NextButton.Click

        If NewRadioButton.Checked = True Then
            NewConfig()
        End If

        If ModifyRadioButton.Checked = True Then
            ModifyExisting()
        End If

        If NewUsingRadioButton.Checked = True Then
            NewUsing()
        End If

    End Sub

#End Region

End Class
