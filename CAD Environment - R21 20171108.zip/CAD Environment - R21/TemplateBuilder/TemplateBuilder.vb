Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.ApplicationServices
Imports System.IO
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
'Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.TemplateBuilder.TemplateBuilder))>

Public Class TemplateBuilder
    Implements Autodesk.AutoCAD.Runtime.IExtensionApplication

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Public Sub Initialize() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Initialize

        AddHandler docs.DocumentActivated, AddressOf DocumentActivatedEvent

    End Sub

    Public Sub Terminate() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Terminate

    End Sub

    Public WithEvents ThisDrawing As AcadDocument = CType(Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)
    Public WithEvents docs As DocumentCollection = Application.DocumentManager

    Private Sub DocumentActivatedEvent(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.DocumentCollectionEventArgs)

        '' Get the current document
        Dim acDoc As Document = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument

        '' Add the events we wish to listen for
        AddHandler acDoc.BeginDocumentClose, AddressOf BeginDocumentCloseEvent

        ThisDrawing = CType(e.Document.GetAcadDocument, AcadDocument)
    End Sub

    Dim frmTemplateBuilder As New frmTemplateBuilder

    Public Sub BeginDocumentCloseEvent(ByVal senderObj As Object, ByVal e As DocumentBeginCloseEventArgs)
        Try
            If GetWorkVarValue("INTEMPLATE").IsTrue Then
                RemoveWorkVar("INTEMPLATE")
                If System.IO.File.Exists(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(ThisDrawing.Name.ToUpper.Replace(".DWT", ""), "Support", ThisDrawing.Name.ToUpper.Replace(".DWT", ".BAK")))) Then
                    System.IO.File.Delete(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(ThisDrawing.Name.ToUpper.Replace(".DWT", ""), "Support", ThisDrawing.Name.ToUpper.Replace(".DWT", ".BAK"))))
                End If
                SaveTemplate()
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_TemplateBuilder", Autodesk.AutoCAD.Runtime.CommandFlags.Session)>
    Public Sub TemplateBuilder()
        Try

            Dim sSupportPath As String
            sSupportPath = ThisDrawing.Application.Path & ";" & ThisDrawing.Application.Preferences.Files.SupportPath

            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(frmTemplateBuilder)

            CleanUpFiles()

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

End Class