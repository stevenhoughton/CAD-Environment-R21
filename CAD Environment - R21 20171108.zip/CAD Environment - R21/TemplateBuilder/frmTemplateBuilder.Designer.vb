<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTemplateBuilder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTemplateBuilder))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.NavigateSupportButton = New System.Windows.Forms.Button()
        Me.CreateBlockFinderDat = New System.Windows.Forms.Button()
        Me.NavigatePlotStyleButton = New System.Windows.Forms.Button()
        Me.SupportFolderFilesRefreshButton = New System.Windows.Forms.Button()
        Me.PlotStyleFilesRefreshButton = New System.Windows.Forms.Button()
        Me.fraFinish = New System.Windows.Forms.GroupBox()
        Me.lblPageSetups = New System.Windows.Forms.Label()
        Me.lblContentRules = New System.Windows.Forms.Label()
        Me.lblSystemVariables = New System.Windows.Forms.Label()
        Me.lblMenuItems = New System.Windows.Forms.Label()
        Me.lblLimits = New System.Windows.Forms.Label()
        Me.lblHatchPatterns = New System.Windows.Forms.Label()
        Me.lblFontsShapes = New System.Windows.Forms.Label()
        Me.lblAliases = New System.Windows.Forms.Label()
        Me.Curr = New System.Windows.Forms.Label()
        Me.Nkown = New System.Windows.Forms.Label()
        Me.cmdFinish = New System.Windows.Forms.Button()
        Me.fraSeparator = New System.Windows.Forms.GroupBox()
        Me.cmdNext = New System.Windows.Forms.Button()
        Me.cmdBack = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdHelp = New System.Windows.Forms.Button()
        Me.imJacobs = New System.Windows.Forms.PictureBox()
        Me.imPanel = New System.Windows.Forms.PictureBox()
        Me.lblSetup = New System.Windows.Forms.Label()
        Me.lblTextStyles = New System.Windows.Forms.Label()
        Me.lblDimStyles = New System.Windows.Forms.Label()
        Me.lblPageLayouts = New System.Windows.Forms.Label()
        Me.lblLayers = New System.Windows.Forms.Label()
        Me.lblLinetypes = New System.Windows.Forms.Label()
        Me.lblPlotStyles = New System.Windows.Forms.Label()
        Me.lblPointStyles = New System.Windows.Forms.Label()
        Me.lblTableStyles = New System.Windows.Forms.Label()
        Me.lblBlocks = New System.Windows.Forms.Label()
        Me.imArrow = New System.Windows.Forms.PictureBox()
        Me.lblPanelDescription = New System.Windows.Forms.Label()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.FinishButton = New System.Windows.Forms.Button()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.SystemVariablesTab = New System.Windows.Forms.TabPage()
        Me.SystemVariableEditButton = New System.Windows.Forms.Button()
        Me.SystemVariablesListView = New System.Windows.Forms.ListView()
        Me.VariableName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Description = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Value = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CHMFile = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Topic = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PlotStyleTablesTab = New System.Windows.Forms.TabPage()
        Me.PlotStyleFilterLabel = New System.Windows.Forms.Label()
        Me.PlotStyleFilterComboBox = New System.Windows.Forms.ComboBox()
        Me.AddPlotStyleButton = New System.Windows.Forms.Button()
        Me.DeletePlotStyleButton = New System.Windows.Forms.Button()
        Me.AdditionalPlotStyleFilesListBox = New System.Windows.Forms.ListBox()
        Me.SupportFolderFilesTab = New System.Windows.Forms.TabPage()
        Me.EditSupportFileButton = New System.Windows.Forms.Button()
        Me.CreateLineTypeFileButton = New System.Windows.Forms.Button()
        Me.CreateHatchFileButton = New System.Windows.Forms.Button()
        Me.CreatePGPButton = New System.Windows.Forms.Button()
        Me.SupportFilterLabel = New System.Windows.Forms.Label()
        Me.SupportFilterComboBox = New System.Windows.Forms.ComboBox()
        Me.AdditionalSupportFilesListBox = New System.Windows.Forms.ListBox()
        Me.AddSupportFilesButton = New System.Windows.Forms.Button()
        Me.DeleteSupportFilesButton = New System.Windows.Forms.Button()
        Me.ToolsTab = New System.Windows.Forms.TabPage()
        Me.RemoveRulesButton = New System.Windows.Forms.Button()
        Me.RemoveObsoleteRulesButton = New System.Windows.Forms.Button()
        Me.RemoveRulesByToolNameButton = New System.Windows.Forms.Button()
        Me.fraMenuItems = New System.Windows.Forms.GroupBox()
        Me.AvailableToolsList = New System.Windows.Forms.ListBox()
        Me.fraToolRules = New System.Windows.Forms.GroupBox()
        Me.DefaultsFrame = New System.Windows.Forms.Panel()
        Me.TemplateBuildeTabControl = New System.Windows.Forms.TabControl()
        Me.TemplateSettingsTab = New System.Windows.Forms.TabPage()
        Me.ContentsReportGroupBox = New System.Windows.Forms.GroupBox()
        Me.RefreshReportButton = New System.Windows.Forms.Button()
        Me.StampButton = New System.Windows.Forms.Button()
        Me.ContentReportTextBox = New System.Windows.Forms.TextBox()
        Me.SaveReportButton = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ConfigNameLabel = New System.Windows.Forms.Label()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imJacobs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imPanel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imArrow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SystemVariablesTab.SuspendLayout()
        Me.PlotStyleTablesTab.SuspendLayout()
        Me.SupportFolderFilesTab.SuspendLayout()
        Me.ToolsTab.SuspendLayout()
        Me.fraMenuItems.SuspendLayout()
        Me.fraToolRules.SuspendLayout()
        Me.TemplateBuildeTabControl.SuspendLayout()
        Me.TemplateSettingsTab.SuspendLayout()
        Me.ContentsReportGroupBox.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(238, 35)
        Me.lblTitle.TabIndex = 66
        Me.lblTitle.Text = "Template Builder"
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 67
        Me.LogoPictureBox.TabStop = False
        '
        'NavigateSupportButton
        '
        Me.NavigateSupportButton.BackColor = System.Drawing.SystemColors.Control
        Me.NavigateSupportButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.NavigateSupportButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NavigateSupportButton.Location = New System.Drawing.Point(968, 295)
        Me.NavigateSupportButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NavigateSupportButton.Name = "NavigateSupportButton"
        Me.NavigateSupportButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NavigateSupportButton.Size = New System.Drawing.Size(77, 33)
        Me.NavigateSupportButton.TabIndex = 4
        Me.NavigateSupportButton.Text = "Navigate"
        Me.ToolTip1.SetToolTip(Me.NavigateSupportButton, "Navigate to Working Folder")
        Me.NavigateSupportButton.UseVisualStyleBackColor = False
        '
        'CreateBlockFinderDat
        '
        Me.CreateBlockFinderDat.BackColor = System.Drawing.SystemColors.Control
        Me.CreateBlockFinderDat.Cursor = System.Windows.Forms.Cursors.Default
        Me.CreateBlockFinderDat.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CreateBlockFinderDat.Location = New System.Drawing.Point(868, 36)
        Me.CreateBlockFinderDat.Margin = New System.Windows.Forms.Padding(4)
        Me.CreateBlockFinderDat.Name = "CreateBlockFinderDat"
        Me.CreateBlockFinderDat.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CreateBlockFinderDat.Size = New System.Drawing.Size(216, 33)
        Me.CreateBlockFinderDat.TabIndex = 15
        Me.CreateBlockFinderDat.Text = "Create  File"
        Me.ToolTip1.SetToolTip(Me.CreateBlockFinderDat, "Generate  file for client block library shortcuts")
        Me.CreateBlockFinderDat.UseVisualStyleBackColor = False
        '
        'NavigatePlotStyleButton
        '
        Me.NavigatePlotStyleButton.BackColor = System.Drawing.SystemColors.Control
        Me.NavigatePlotStyleButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.NavigatePlotStyleButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NavigatePlotStyleButton.Location = New System.Drawing.Point(968, 295)
        Me.NavigatePlotStyleButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NavigatePlotStyleButton.Name = "NavigatePlotStyleButton"
        Me.NavigatePlotStyleButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NavigatePlotStyleButton.Size = New System.Drawing.Size(77, 33)
        Me.NavigatePlotStyleButton.TabIndex = 11
        Me.NavigatePlotStyleButton.Text = "Navigate"
        Me.ToolTip1.SetToolTip(Me.NavigatePlotStyleButton, "Navigate to Working Folder")
        Me.NavigatePlotStyleButton.UseVisualStyleBackColor = False
        '
        'SupportFolderFilesRefreshButton
        '
        Me.SupportFolderFilesRefreshButton.BackColor = System.Drawing.SystemColors.Control
        Me.SupportFolderFilesRefreshButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.SupportFolderFilesRefreshButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SupportFolderFilesRefreshButton.Location = New System.Drawing.Point(1053, 295)
        Me.SupportFolderFilesRefreshButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SupportFolderFilesRefreshButton.Name = "SupportFolderFilesRefreshButton"
        Me.SupportFolderFilesRefreshButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SupportFolderFilesRefreshButton.Size = New System.Drawing.Size(77, 33)
        Me.SupportFolderFilesRefreshButton.TabIndex = 117
        Me.SupportFolderFilesRefreshButton.Text = "Refresh"
        Me.ToolTip1.SetToolTip(Me.SupportFolderFilesRefreshButton, "Navigate to Working Folder")
        Me.SupportFolderFilesRefreshButton.UseVisualStyleBackColor = False
        '
        'PlotStyleFilesRefreshButton
        '
        Me.PlotStyleFilesRefreshButton.BackColor = System.Drawing.SystemColors.Control
        Me.PlotStyleFilesRefreshButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.PlotStyleFilesRefreshButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PlotStyleFilesRefreshButton.Location = New System.Drawing.Point(1053, 295)
        Me.PlotStyleFilesRefreshButton.Margin = New System.Windows.Forms.Padding(4)
        Me.PlotStyleFilesRefreshButton.Name = "PlotStyleFilesRefreshButton"
        Me.PlotStyleFilesRefreshButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.PlotStyleFilesRefreshButton.Size = New System.Drawing.Size(77, 33)
        Me.PlotStyleFilesRefreshButton.TabIndex = 120
        Me.PlotStyleFilesRefreshButton.Text = "Refresh"
        Me.ToolTip1.SetToolTip(Me.PlotStyleFilesRefreshButton, "Navigate to Working Folder")
        Me.PlotStyleFilesRefreshButton.UseVisualStyleBackColor = False
        '
        'fraFinish
        '
        Me.fraFinish.BackColor = System.Drawing.SystemColors.Control
        Me.fraFinish.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraFinish.Location = New System.Drawing.Point(920, -466)
        Me.fraFinish.Margin = New System.Windows.Forms.Padding(4)
        Me.fraFinish.Name = "fraFinish"
        Me.fraFinish.Padding = New System.Windows.Forms.Padding(4)
        Me.fraFinish.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraFinish.Size = New System.Drawing.Size(603, 286)
        Me.fraFinish.TabIndex = 94
        Me.fraFinish.TabStop = False
        Me.fraFinish.Text = "Finish"
        '
        'lblPageSetups
        '
        Me.lblPageSetups.BackColor = System.Drawing.SystemColors.Control
        Me.lblPageSetups.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPageSetups.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPageSetups.Location = New System.Drawing.Point(611, -279)
        Me.lblPageSetups.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPageSetups.Name = "lblPageSetups"
        Me.lblPageSetups.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPageSetups.Size = New System.Drawing.Size(123, 17)
        Me.lblPageSetups.TabIndex = 95
        Me.lblPageSetups.Text = "Page Setups"
        '
        'lblContentRules
        '
        Me.lblContentRules.BackColor = System.Drawing.SystemColors.Control
        Me.lblContentRules.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblContentRules.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblContentRules.Location = New System.Drawing.Point(611, -230)
        Me.lblContentRules.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblContentRules.Name = "lblContentRules"
        Me.lblContentRules.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblContentRules.Size = New System.Drawing.Size(123, 17)
        Me.lblContentRules.TabIndex = 96
        Me.lblContentRules.Text = "Additional Files 210"
        '
        'lblSystemVariables
        '
        Me.lblSystemVariables.BackColor = System.Drawing.SystemColors.Control
        Me.lblSystemVariables.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblSystemVariables.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSystemVariables.Location = New System.Drawing.Point(611, -262)
        Me.lblSystemVariables.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSystemVariables.Name = "lblSystemVariables"
        Me.lblSystemVariables.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblSystemVariables.Size = New System.Drawing.Size(123, 17)
        Me.lblSystemVariables.TabIndex = 97
        Me.lblSystemVariables.Text = "System Variables"
        '
        'lblMenuItems
        '
        Me.lblMenuItems.BackColor = System.Drawing.SystemColors.Control
        Me.lblMenuItems.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblMenuItems.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblMenuItems.Location = New System.Drawing.Point(611, -246)
        Me.lblMenuItems.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMenuItems.Name = "lblMenuItems"
        Me.lblMenuItems.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblMenuItems.Size = New System.Drawing.Size(123, 17)
        Me.lblMenuItems.TabIndex = 98
        Me.lblMenuItems.Text = "Menu Items"
        '
        'lblLimits
        '
        Me.lblLimits.BackColor = System.Drawing.SystemColors.Control
        Me.lblLimits.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLimits.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLimits.Location = New System.Drawing.Point(612, -476)
        Me.lblLimits.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLimits.Name = "lblLimits"
        Me.lblLimits.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblLimits.Size = New System.Drawing.Size(123, 17)
        Me.lblLimits.TabIndex = 104
        Me.lblLimits.Text = "Limits"
        '
        'lblHatchPatterns
        '
        Me.lblHatchPatterns.BackColor = System.Drawing.SystemColors.Control
        Me.lblHatchPatterns.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblHatchPatterns.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblHatchPatterns.Location = New System.Drawing.Point(611, -427)
        Me.lblHatchPatterns.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHatchPatterns.Name = "lblHatchPatterns"
        Me.lblHatchPatterns.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblHatchPatterns.Size = New System.Drawing.Size(123, 17)
        Me.lblHatchPatterns.TabIndex = 105
        Me.lblHatchPatterns.Text = "Hatch Patterns"
        '
        'lblFontsShapes
        '
        Me.lblFontsShapes.BackColor = System.Drawing.SystemColors.Control
        Me.lblFontsShapes.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFontsShapes.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFontsShapes.Location = New System.Drawing.Point(611, -394)
        Me.lblFontsShapes.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFontsShapes.Name = "lblFontsShapes"
        Me.lblFontsShapes.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFontsShapes.Size = New System.Drawing.Size(123, 17)
        Me.lblFontsShapes.TabIndex = 106
        Me.lblFontsShapes.Text = "Fonts && Shapes"
        '
        'lblAliases
        '
        Me.lblAliases.BackColor = System.Drawing.SystemColors.Control
        Me.lblAliases.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblAliases.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAliases.Location = New System.Drawing.Point(611, -213)
        Me.lblAliases.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblAliases.Name = "lblAliases"
        Me.lblAliases.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblAliases.Size = New System.Drawing.Size(123, 17)
        Me.lblAliases.TabIndex = 107
        Me.lblAliases.Text = "Aliases"
        '
        'Curr
        '
        Me.Curr.BackColor = System.Drawing.SystemColors.Control
        Me.Curr.Cursor = System.Windows.Forms.Cursors.Default
        Me.Curr.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Curr.Location = New System.Drawing.Point(824, -148)
        Me.Curr.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Curr.Name = "Curr"
        Me.Curr.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Curr.Size = New System.Drawing.Size(84, 28)
        Me.Curr.TabIndex = 109
        Me.Curr.Text = "Curr"
        Me.Curr.Visible = False
        '
        'Nkown
        '
        Me.Nkown.BackColor = System.Drawing.SystemColors.Control
        Me.Nkown.Cursor = System.Windows.Forms.Cursors.Default
        Me.Nkown.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Nkown.Location = New System.Drawing.Point(825, -126)
        Me.Nkown.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Nkown.Name = "Nkown"
        Me.Nkown.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Nkown.Size = New System.Drawing.Size(80, 31)
        Me.Nkown.TabIndex = 110
        Me.Nkown.Text = "Known"
        Me.Nkown.Visible = False
        '
        'cmdFinish
        '
        Me.cmdFinish.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFinish.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFinish.Enabled = False
        Me.cmdFinish.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFinish.Location = New System.Drawing.Point(1411, -151)
        Me.cmdFinish.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdFinish.Name = "cmdFinish"
        Me.cmdFinish.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFinish.Size = New System.Drawing.Size(112, 33)
        Me.cmdFinish.TabIndex = 70
        Me.cmdFinish.Text = "&Finish"
        Me.cmdFinish.UseVisualStyleBackColor = False
        '
        'fraSeparator
        '
        Me.fraSeparator.BackColor = System.Drawing.SystemColors.Control
        Me.fraSeparator.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraSeparator.Location = New System.Drawing.Point(568, -171)
        Me.fraSeparator.Margin = New System.Windows.Forms.Padding(4)
        Me.fraSeparator.Name = "fraSeparator"
        Me.fraSeparator.Padding = New System.Windows.Forms.Padding(4)
        Me.fraSeparator.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraSeparator.Size = New System.Drawing.Size(955, 4)
        Me.fraSeparator.TabIndex = 69
        Me.fraSeparator.TabStop = False
        '
        'cmdNext
        '
        Me.cmdNext.BackColor = System.Drawing.SystemColors.Control
        Me.cmdNext.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdNext.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdNext.Location = New System.Drawing.Point(1261, -151)
        Me.cmdNext.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdNext.Name = "cmdNext"
        Me.cmdNext.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdNext.Size = New System.Drawing.Size(112, 33)
        Me.cmdNext.TabIndex = 71
        Me.cmdNext.Text = "&Next >"
        Me.cmdNext.UseVisualStyleBackColor = False
        '
        'cmdBack
        '
        Me.cmdBack.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBack.Location = New System.Drawing.Point(1144, -151)
        Me.cmdBack.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBack.Size = New System.Drawing.Size(112, 33)
        Me.cmdBack.TabIndex = 72
        Me.cmdBack.Text = "< &Back"
        Me.cmdBack.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(995, -151)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(112, 33)
        Me.cmdCancel.TabIndex = 73
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        Me.cmdCancel.Visible = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.Enabled = False
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(697, -150)
        Me.cmdSave.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(112, 33)
        Me.cmdSave.TabIndex = 74
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        Me.cmdSave.Visible = False
        '
        'cmdHelp
        '
        Me.cmdHelp.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHelp.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHelp.Location = New System.Drawing.Point(577, -151)
        Me.cmdHelp.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdHelp.Name = "cmdHelp"
        Me.cmdHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHelp.Size = New System.Drawing.Size(112, 33)
        Me.cmdHelp.TabIndex = 75
        Me.cmdHelp.Text = "&Help"
        Me.cmdHelp.UseVisualStyleBackColor = False
        '
        'imJacobs
        '
        Me.imJacobs.Cursor = System.Windows.Forms.Cursors.Default
        Me.imJacobs.Location = New System.Drawing.Point(579, -555)
        Me.imJacobs.Margin = New System.Windows.Forms.Padding(4)
        Me.imJacobs.Name = "imJacobs"
        Me.imJacobs.Size = New System.Drawing.Size(148, 59)
        Me.imJacobs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imJacobs.TabIndex = 76
        Me.imJacobs.TabStop = False
        '
        'imPanel
        '
        Me.imPanel.Cursor = System.Windows.Forms.Cursors.Default
        Me.imPanel.Location = New System.Drawing.Point(749, -555)
        Me.imPanel.Margin = New System.Windows.Forms.Padding(4)
        Me.imPanel.Name = "imPanel"
        Me.imPanel.Size = New System.Drawing.Size(165, 364)
        Me.imPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imPanel.TabIndex = 78
        Me.imPanel.TabStop = False
        '
        'lblSetup
        '
        Me.lblSetup.BackColor = System.Drawing.SystemColors.Control
        Me.lblSetup.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblSetup.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSetup.Location = New System.Drawing.Point(611, -492)
        Me.lblSetup.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSetup.Name = "lblSetup"
        Me.lblSetup.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblSetup.Size = New System.Drawing.Size(123, 17)
        Me.lblSetup.TabIndex = 77
        Me.lblSetup.Text = "Setup"
        '
        'lblTextStyles
        '
        Me.lblTextStyles.BackColor = System.Drawing.SystemColors.Control
        Me.lblTextStyles.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTextStyles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTextStyles.Location = New System.Drawing.Point(611, -378)
        Me.lblTextStyles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTextStyles.Name = "lblTextStyles"
        Me.lblTextStyles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTextStyles.Size = New System.Drawing.Size(123, 17)
        Me.lblTextStyles.TabIndex = 79
        Me.lblTextStyles.Text = "Text Styles"
        '
        'lblDimStyles
        '
        Me.lblDimStyles.BackColor = System.Drawing.SystemColors.Control
        Me.lblDimStyles.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDimStyles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDimStyles.Location = New System.Drawing.Point(611, -329)
        Me.lblDimStyles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDimStyles.Name = "lblDimStyles"
        Me.lblDimStyles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDimStyles.Size = New System.Drawing.Size(123, 17)
        Me.lblDimStyles.TabIndex = 80
        Me.lblDimStyles.Text = "Dimension Styles 150"
        '
        'lblPageLayouts
        '
        Me.lblPageLayouts.BackColor = System.Drawing.SystemColors.Control
        Me.lblPageLayouts.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPageLayouts.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPageLayouts.Location = New System.Drawing.Point(611, -295)
        Me.lblPageLayouts.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPageLayouts.Name = "lblPageLayouts"
        Me.lblPageLayouts.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPageLayouts.Size = New System.Drawing.Size(123, 17)
        Me.lblPageLayouts.TabIndex = 81
        Me.lblPageLayouts.Text = "Layouts"
        '
        'lblLayers
        '
        Me.lblLayers.BackColor = System.Drawing.SystemColors.Control
        Me.lblLayers.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLayers.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLayers.Location = New System.Drawing.Point(611, -410)
        Me.lblLayers.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLayers.Name = "lblLayers"
        Me.lblLayers.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblLayers.Size = New System.Drawing.Size(123, 17)
        Me.lblLayers.TabIndex = 82
        Me.lblLayers.Text = "Layers"
        '
        'lblLinetypes
        '
        Me.lblLinetypes.BackColor = System.Drawing.SystemColors.Control
        Me.lblLinetypes.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLinetypes.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLinetypes.Location = New System.Drawing.Point(611, -443)
        Me.lblLinetypes.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblLinetypes.Name = "lblLinetypes"
        Me.lblLinetypes.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblLinetypes.Size = New System.Drawing.Size(123, 17)
        Me.lblLinetypes.TabIndex = 83
        Me.lblLinetypes.Text = "Linetypes"
        '
        'lblPlotStyles
        '
        Me.lblPlotStyles.BackColor = System.Drawing.SystemColors.Control
        Me.lblPlotStyles.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPlotStyles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPlotStyles.Location = New System.Drawing.Point(611, -311)
        Me.lblPlotStyles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPlotStyles.Name = "lblPlotStyles"
        Me.lblPlotStyles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPlotStyles.Size = New System.Drawing.Size(123, 17)
        Me.lblPlotStyles.TabIndex = 84
        Me.lblPlotStyles.Text = "Plot Styles"
        '
        'lblPointStyles
        '
        Me.lblPointStyles.BackColor = System.Drawing.SystemColors.Control
        Me.lblPointStyles.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPointStyles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPointStyles.Location = New System.Drawing.Point(611, -459)
        Me.lblPointStyles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPointStyles.Name = "lblPointStyles"
        Me.lblPointStyles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPointStyles.Size = New System.Drawing.Size(123, 17)
        Me.lblPointStyles.TabIndex = 85
        Me.lblPointStyles.Text = "Point Styles"
        '
        'lblTableStyles
        '
        Me.lblTableStyles.BackColor = System.Drawing.SystemColors.Control
        Me.lblTableStyles.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTableStyles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTableStyles.Location = New System.Drawing.Point(611, -345)
        Me.lblTableStyles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTableStyles.Name = "lblTableStyles"
        Me.lblTableStyles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTableStyles.Size = New System.Drawing.Size(123, 17)
        Me.lblTableStyles.TabIndex = 86
        Me.lblTableStyles.Text = "Table Styles"
        '
        'lblBlocks
        '
        Me.lblBlocks.BackColor = System.Drawing.SystemColors.Control
        Me.lblBlocks.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblBlocks.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblBlocks.Location = New System.Drawing.Point(611, -361)
        Me.lblBlocks.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblBlocks.Name = "lblBlocks"
        Me.lblBlocks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblBlocks.Size = New System.Drawing.Size(123, 17)
        Me.lblBlocks.TabIndex = 87
        Me.lblBlocks.Text = "Blocks"
        '
        'imArrow
        '
        Me.imArrow.Cursor = System.Windows.Forms.Cursors.Default
        Me.imArrow.Location = New System.Drawing.Point(584, -492)
        Me.imArrow.Margin = New System.Windows.Forms.Padding(4)
        Me.imArrow.Name = "imArrow"
        Me.imArrow.Size = New System.Drawing.Size(29, 17)
        Me.imArrow.TabIndex = 88
        Me.imArrow.TabStop = False
        '
        'lblPanelDescription
        '
        Me.lblPanelDescription.BackColor = System.Drawing.SystemColors.Control
        Me.lblPanelDescription.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPanelDescription.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPanelDescription.Location = New System.Drawing.Point(929, -562)
        Me.lblPanelDescription.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPanelDescription.Name = "lblPanelDescription"
        Me.lblPanelDescription.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPanelDescription.Size = New System.Drawing.Size(592, 122)
        Me.lblPanelDescription.TabIndex = 89
        Me.lblPanelDescription.Text = "Label1"
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'FinishButton
        '
        Me.FinishButton.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.FinishButton.BackColor = System.Drawing.SystemColors.Control
        Me.FinishButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.FinishButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FinishButton.Location = New System.Drawing.Point(118, 6)
        Me.FinishButton.Margin = New System.Windows.Forms.Padding(4)
        Me.FinishButton.Name = "FinishButton"
        Me.FinishButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FinishButton.Size = New System.Drawing.Size(85, 32)
        Me.FinishButton.TabIndex = 111
        Me.FinishButton.Text = "OK"
        Me.FinishButton.UseVisualStyleBackColor = False
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.Location = New System.Drawing.Point(11, 6)
        Me.Help_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.Size = New System.Drawing.Size(85, 32)
        Me.Help_Button.TabIndex = 112
        Me.Help_Button.Text = "&Help"
        Me.Help_Button.UseVisualStyleBackColor = True
        '
        'SystemVariablesTab
        '
        Me.SystemVariablesTab.Controls.Add(Me.SystemVariableEditButton)
        Me.SystemVariablesTab.Controls.Add(Me.SystemVariablesListView)
        Me.SystemVariablesTab.Location = New System.Drawing.Point(4, 25)
        Me.SystemVariablesTab.Margin = New System.Windows.Forms.Padding(4)
        Me.SystemVariablesTab.Name = "SystemVariablesTab"
        Me.SystemVariablesTab.Padding = New System.Windows.Forms.Padding(4)
        Me.SystemVariablesTab.Size = New System.Drawing.Size(1153, 428)
        Me.SystemVariablesTab.TabIndex = 15
        Me.SystemVariablesTab.Text = "System Variables"
        Me.SystemVariablesTab.UseVisualStyleBackColor = True
        '
        'SystemVariableEditButton
        '
        Me.SystemVariableEditButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SystemVariableEditButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.SystemVariableEditButton.BackColor = System.Drawing.SystemColors.Control
        Me.SystemVariableEditButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.SystemVariableEditButton.Enabled = False
        Me.SystemVariableEditButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SystemVariableEditButton.Location = New System.Drawing.Point(485, 385)
        Me.SystemVariableEditButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SystemVariableEditButton.Name = "SystemVariableEditButton"
        Me.SystemVariableEditButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SystemVariableEditButton.Size = New System.Drawing.Size(220, 33)
        Me.SystemVariableEditButton.TabIndex = 1
        Me.SystemVariableEditButton.Text = "&Edit..."
        Me.SystemVariableEditButton.UseVisualStyleBackColor = False
        '
        'SystemVariablesListView
        '
        Me.SystemVariablesListView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SystemVariablesListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.VariableName, Me.Description, Me.Value, Me.CHMFile, Me.Topic})
        Me.SystemVariablesListView.Location = New System.Drawing.Point(8, 18)
        Me.SystemVariablesListView.Margin = New System.Windows.Forms.Padding(4)
        Me.SystemVariablesListView.MultiSelect = False
        Me.SystemVariablesListView.Name = "SystemVariablesListView"
        Me.SystemVariablesListView.Size = New System.Drawing.Size(1127, 358)
        Me.SystemVariablesListView.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.SystemVariablesListView.TabIndex = 2
        Me.SystemVariablesListView.UseCompatibleStateImageBehavior = False
        '
        'VariableName
        '
        Me.VariableName.Text = "Name"
        Me.VariableName.Width = 130
        '
        'Description
        '
        Me.Description.Text = "Description"
        Me.Description.Width = 600
        '
        'Value
        '
        Me.Value.Text = "Value"
        Me.Value.Width = 100
        '
        'CHMFile
        '
        Me.CHMFile.Text = "CHM File Name"
        '
        'Topic
        '
        Me.Topic.Text = "Topic"
        '
        'PlotStyleTablesTab
        '
        Me.PlotStyleTablesTab.Controls.Add(Me.PlotStyleFilesRefreshButton)
        Me.PlotStyleTablesTab.Controls.Add(Me.PlotStyleFilterLabel)
        Me.PlotStyleTablesTab.Controls.Add(Me.PlotStyleFilterComboBox)
        Me.PlotStyleTablesTab.Controls.Add(Me.AddPlotStyleButton)
        Me.PlotStyleTablesTab.Controls.Add(Me.DeletePlotStyleButton)
        Me.PlotStyleTablesTab.Controls.Add(Me.NavigatePlotStyleButton)
        Me.PlotStyleTablesTab.Controls.Add(Me.AdditionalPlotStyleFilesListBox)
        Me.PlotStyleTablesTab.Location = New System.Drawing.Point(4, 25)
        Me.PlotStyleTablesTab.Margin = New System.Windows.Forms.Padding(4)
        Me.PlotStyleTablesTab.Name = "PlotStyleTablesTab"
        Me.PlotStyleTablesTab.Padding = New System.Windows.Forms.Padding(4)
        Me.PlotStyleTablesTab.Size = New System.Drawing.Size(1153, 428)
        Me.PlotStyleTablesTab.TabIndex = 23
        Me.PlotStyleTablesTab.Text = "Plot Style Tables"
        Me.PlotStyleTablesTab.UseVisualStyleBackColor = True
        '
        'PlotStyleFilterLabel
        '
        Me.PlotStyleFilterLabel.AutoSize = True
        Me.PlotStyleFilterLabel.Location = New System.Drawing.Point(829, 340)
        Me.PlotStyleFilterLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.PlotStyleFilterLabel.Name = "PlotStyleFilterLabel"
        Me.PlotStyleFilterLabel.Size = New System.Drawing.Size(39, 17)
        Me.PlotStyleFilterLabel.TabIndex = 13
        Me.PlotStyleFilterLabel.Text = "Filter"
        '
        'PlotStyleFilterComboBox
        '
        Me.PlotStyleFilterComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PlotStyleFilterComboBox.FormattingEnabled = True
        Me.PlotStyleFilterComboBox.Items.AddRange(New Object() {"ctb", "stb", "*"})
        Me.PlotStyleFilterComboBox.Location = New System.Drawing.Point(868, 336)
        Me.PlotStyleFilterComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.PlotStyleFilterComboBox.Name = "PlotStyleFilterComboBox"
        Me.PlotStyleFilterComboBox.Size = New System.Drawing.Size(97, 24)
        Me.PlotStyleFilterComboBox.TabIndex = 12
        '
        'AddPlotStyleButton
        '
        Me.AddPlotStyleButton.BackColor = System.Drawing.SystemColors.Control
        Me.AddPlotStyleButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.AddPlotStyleButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddPlotStyleButton.Location = New System.Drawing.Point(868, 295)
        Me.AddPlotStyleButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AddPlotStyleButton.Name = "AddPlotStyleButton"
        Me.AddPlotStyleButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AddPlotStyleButton.Size = New System.Drawing.Size(43, 33)
        Me.AddPlotStyleButton.TabIndex = 9
        Me.AddPlotStyleButton.Text = "+"
        Me.AddPlotStyleButton.UseVisualStyleBackColor = False
        '
        'DeletePlotStyleButton
        '
        Me.DeletePlotStyleButton.BackColor = System.Drawing.SystemColors.Control
        Me.DeletePlotStyleButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.DeletePlotStyleButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DeletePlotStyleButton.Location = New System.Drawing.Point(917, 295)
        Me.DeletePlotStyleButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DeletePlotStyleButton.Name = "DeletePlotStyleButton"
        Me.DeletePlotStyleButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DeletePlotStyleButton.Size = New System.Drawing.Size(43, 33)
        Me.DeletePlotStyleButton.TabIndex = 10
        Me.DeletePlotStyleButton.Text = "--"
        Me.DeletePlotStyleButton.UseVisualStyleBackColor = False
        '
        'AdditionalPlotStyleFilesListBox
        '
        Me.AdditionalPlotStyleFilesListBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.AdditionalPlotStyleFilesListBox.BackColor = System.Drawing.SystemColors.Window
        Me.AdditionalPlotStyleFilesListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.AdditionalPlotStyleFilesListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.AdditionalPlotStyleFilesListBox.ItemHeight = 16
        Me.AdditionalPlotStyleFilesListBox.Location = New System.Drawing.Point(41, 23)
        Me.AdditionalPlotStyleFilesListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.AdditionalPlotStyleFilesListBox.Name = "AdditionalPlotStyleFilesListBox"
        Me.AdditionalPlotStyleFilesListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AdditionalPlotStyleFilesListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.AdditionalPlotStyleFilesListBox.Size = New System.Drawing.Size(756, 372)
        Me.AdditionalPlotStyleFilesListBox.Sorted = True
        Me.AdditionalPlotStyleFilesListBox.TabIndex = 5
        '
        'SupportFolderFilesTab
        '
        Me.SupportFolderFilesTab.Controls.Add(Me.EditSupportFileButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.CreateLineTypeFileButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.SupportFolderFilesRefreshButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.CreateHatchFileButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.CreatePGPButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.SupportFilterLabel)
        Me.SupportFolderFilesTab.Controls.Add(Me.SupportFilterComboBox)
        Me.SupportFolderFilesTab.Controls.Add(Me.AdditionalSupportFilesListBox)
        Me.SupportFolderFilesTab.Controls.Add(Me.AddSupportFilesButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.DeleteSupportFilesButton)
        Me.SupportFolderFilesTab.Controls.Add(Me.CreateBlockFinderDat)
        Me.SupportFolderFilesTab.Controls.Add(Me.NavigateSupportButton)
        Me.SupportFolderFilesTab.Location = New System.Drawing.Point(4, 25)
        Me.SupportFolderFilesTab.Margin = New System.Windows.Forms.Padding(4)
        Me.SupportFolderFilesTab.Name = "SupportFolderFilesTab"
        Me.SupportFolderFilesTab.Padding = New System.Windows.Forms.Padding(4)
        Me.SupportFolderFilesTab.Size = New System.Drawing.Size(1153, 428)
        Me.SupportFolderFilesTab.TabIndex = 21
        Me.SupportFolderFilesTab.Text = "Support Folder Files"
        Me.SupportFolderFilesTab.UseVisualStyleBackColor = True
        '
        'EditSupportFileButton
        '
        Me.EditSupportFileButton.BackColor = System.Drawing.SystemColors.Control
        Me.EditSupportFileButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.EditSupportFileButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.EditSupportFileButton.Location = New System.Drawing.Point(868, 224)
        Me.EditSupportFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.EditSupportFileButton.Name = "EditSupportFileButton"
        Me.EditSupportFileButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EditSupportFileButton.Size = New System.Drawing.Size(216, 33)
        Me.EditSupportFileButton.TabIndex = 118
        Me.EditSupportFileButton.Text = "Edit With Notepad"
        Me.EditSupportFileButton.UseVisualStyleBackColor = False
        '
        'CreateLineTypeFileButton
        '
        Me.CreateLineTypeFileButton.BackColor = System.Drawing.SystemColors.Control
        Me.CreateLineTypeFileButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.CreateLineTypeFileButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CreateLineTypeFileButton.Location = New System.Drawing.Point(868, 158)
        Me.CreateLineTypeFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CreateLineTypeFileButton.Name = "CreateLineTypeFileButton"
        Me.CreateLineTypeFileButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CreateLineTypeFileButton.Size = New System.Drawing.Size(216, 33)
        Me.CreateLineTypeFileButton.TabIndex = 112
        Me.CreateLineTypeFileButton.Text = "Create Client Linetype File"
        Me.CreateLineTypeFileButton.UseVisualStyleBackColor = False
        '
        'CreateHatchFileButton
        '
        Me.CreateHatchFileButton.BackColor = System.Drawing.SystemColors.Control
        Me.CreateHatchFileButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.CreateHatchFileButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CreateHatchFileButton.Location = New System.Drawing.Point(868, 76)
        Me.CreateHatchFileButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CreateHatchFileButton.Name = "CreateHatchFileButton"
        Me.CreateHatchFileButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CreateHatchFileButton.Size = New System.Drawing.Size(216, 33)
        Me.CreateHatchFileButton.TabIndex = 116
        Me.CreateHatchFileButton.Text = "Create Client.PAT Hatch File"
        Me.CreateHatchFileButton.UseVisualStyleBackColor = False
        '
        'CreatePGPButton
        '
        Me.CreatePGPButton.BackColor = System.Drawing.SystemColors.Control
        Me.CreatePGPButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.CreatePGPButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CreatePGPButton.Location = New System.Drawing.Point(868, 117)
        Me.CreatePGPButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CreatePGPButton.Name = "CreatePGPButton"
        Me.CreatePGPButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CreatePGPButton.Size = New System.Drawing.Size(216, 33)
        Me.CreatePGPButton.TabIndex = 115
        Me.CreatePGPButton.Text = "Create Client.PGP Alias File"
        Me.CreatePGPButton.UseVisualStyleBackColor = False
        '
        'SupportFilterLabel
        '
        Me.SupportFilterLabel.AutoSize = True
        Me.SupportFilterLabel.Location = New System.Drawing.Point(829, 340)
        Me.SupportFilterLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.SupportFilterLabel.Name = "SupportFilterLabel"
        Me.SupportFilterLabel.Size = New System.Drawing.Size(39, 17)
        Me.SupportFilterLabel.TabIndex = 6
        Me.SupportFilterLabel.Text = "Filter"
        '
        'SupportFilterComboBox
        '
        Me.SupportFilterComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SupportFilterComboBox.FormattingEnabled = True
        Me.SupportFilterComboBox.Items.AddRange(New Object() {"*", "dwg", "dwt", "lin", "pat", "dct", "lsp", "mnl", "xml", "cui", "cuix", "shp", "shx"})
        Me.SupportFilterComboBox.Location = New System.Drawing.Point(868, 336)
        Me.SupportFilterComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.SupportFilterComboBox.Name = "SupportFilterComboBox"
        Me.SupportFilterComboBox.Size = New System.Drawing.Size(97, 24)
        Me.SupportFilterComboBox.TabIndex = 5
        '
        'AdditionalSupportFilesListBox
        '
        Me.AdditionalSupportFilesListBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.AdditionalSupportFilesListBox.BackColor = System.Drawing.SystemColors.Window
        Me.AdditionalSupportFilesListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.AdditionalSupportFilesListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.AdditionalSupportFilesListBox.ItemHeight = 16
        Me.AdditionalSupportFilesListBox.Location = New System.Drawing.Point(41, 23)
        Me.AdditionalSupportFilesListBox.Margin = New System.Windows.Forms.Padding(4)
        Me.AdditionalSupportFilesListBox.Name = "AdditionalSupportFilesListBox"
        Me.AdditionalSupportFilesListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AdditionalSupportFilesListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.AdditionalSupportFilesListBox.Size = New System.Drawing.Size(756, 372)
        Me.AdditionalSupportFilesListBox.Sorted = True
        Me.AdditionalSupportFilesListBox.TabIndex = 3
        '
        'AddSupportFilesButton
        '
        Me.AddSupportFilesButton.BackColor = System.Drawing.SystemColors.Control
        Me.AddSupportFilesButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.AddSupportFilesButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddSupportFilesButton.Location = New System.Drawing.Point(868, 295)
        Me.AddSupportFilesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AddSupportFilesButton.Name = "AddSupportFilesButton"
        Me.AddSupportFilesButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AddSupportFilesButton.Size = New System.Drawing.Size(43, 33)
        Me.AddSupportFilesButton.TabIndex = 0
        Me.AddSupportFilesButton.Text = "+"
        Me.AddSupportFilesButton.UseVisualStyleBackColor = False
        '
        'DeleteSupportFilesButton
        '
        Me.DeleteSupportFilesButton.BackColor = System.Drawing.SystemColors.Control
        Me.DeleteSupportFilesButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.DeleteSupportFilesButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DeleteSupportFilesButton.Location = New System.Drawing.Point(917, 295)
        Me.DeleteSupportFilesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DeleteSupportFilesButton.Name = "DeleteSupportFilesButton"
        Me.DeleteSupportFilesButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DeleteSupportFilesButton.Size = New System.Drawing.Size(43, 33)
        Me.DeleteSupportFilesButton.TabIndex = 1
        Me.DeleteSupportFilesButton.Text = "--"
        Me.DeleteSupportFilesButton.UseVisualStyleBackColor = False
        '
        'ToolsTab
        '
        Me.ToolsTab.Controls.Add(Me.RemoveRulesButton)
        Me.ToolsTab.Controls.Add(Me.RemoveObsoleteRulesButton)
        Me.ToolsTab.Controls.Add(Me.RemoveRulesByToolNameButton)
        Me.ToolsTab.Controls.Add(Me.fraMenuItems)
        Me.ToolsTab.Controls.Add(Me.fraToolRules)
        Me.ToolsTab.Location = New System.Drawing.Point(4, 25)
        Me.ToolsTab.Margin = New System.Windows.Forms.Padding(4)
        Me.ToolsTab.Name = "ToolsTab"
        Me.ToolsTab.Padding = New System.Windows.Forms.Padding(4)
        Me.ToolsTab.Size = New System.Drawing.Size(1153, 428)
        Me.ToolsTab.TabIndex = 16
        Me.ToolsTab.Text = "Tools"
        Me.ToolsTab.UseVisualStyleBackColor = True
        '
        'RemoveRulesButton
        '
        Me.RemoveRulesButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RemoveRulesButton.Location = New System.Drawing.Point(484, 420)
        Me.RemoveRulesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RemoveRulesButton.Name = "RemoveRulesButton"
        Me.RemoveRulesButton.Size = New System.Drawing.Size(224, 30)
        Me.RemoveRulesButton.TabIndex = 104
        Me.RemoveRulesButton.Text = "Reset All Rules"
        Me.RemoveRulesButton.UseVisualStyleBackColor = True
        Me.RemoveRulesButton.Visible = False
        '
        'RemoveObsoleteRulesButton
        '
        Me.RemoveObsoleteRulesButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RemoveObsoleteRulesButton.Location = New System.Drawing.Point(252, 420)
        Me.RemoveObsoleteRulesButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RemoveObsoleteRulesButton.Name = "RemoveObsoleteRulesButton"
        Me.RemoveObsoleteRulesButton.Size = New System.Drawing.Size(224, 30)
        Me.RemoveObsoleteRulesButton.TabIndex = 103
        Me.RemoveObsoleteRulesButton.Text = "Remove Obsolete Rules"
        Me.RemoveObsoleteRulesButton.UseVisualStyleBackColor = True
        Me.RemoveObsoleteRulesButton.Visible = False
        '
        'RemoveRulesByToolNameButton
        '
        Me.RemoveRulesByToolNameButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RemoveRulesByToolNameButton.Location = New System.Drawing.Point(20, 420)
        Me.RemoveRulesByToolNameButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RemoveRulesByToolNameButton.Name = "RemoveRulesByToolNameButton"
        Me.RemoveRulesByToolNameButton.Size = New System.Drawing.Size(224, 30)
        Me.RemoveRulesByToolNameButton.TabIndex = 102
        Me.RemoveRulesByToolNameButton.Text = "Remove Rules By Tool Name"
        Me.RemoveRulesByToolNameButton.UseVisualStyleBackColor = True
        Me.RemoveRulesByToolNameButton.Visible = False
        '
        'fraMenuItems
        '
        Me.fraMenuItems.BackColor = System.Drawing.SystemColors.Control
        Me.fraMenuItems.Controls.Add(Me.AvailableToolsList)
        Me.fraMenuItems.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraMenuItems.Location = New System.Drawing.Point(8, 7)
        Me.fraMenuItems.Margin = New System.Windows.Forms.Padding(4)
        Me.fraMenuItems.Name = "fraMenuItems"
        Me.fraMenuItems.Padding = New System.Windows.Forms.Padding(4)
        Me.fraMenuItems.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraMenuItems.Size = New System.Drawing.Size(1124, 151)
        Me.fraMenuItems.TabIndex = 100
        Me.fraMenuItems.TabStop = False
        Me.fraMenuItems.Text = "Tools"
        '
        'AvailableToolsList
        '
        Me.AvailableToolsList.BackColor = System.Drawing.SystemColors.Window
        Me.AvailableToolsList.Cursor = System.Windows.Forms.Cursors.Default
        Me.AvailableToolsList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.AvailableToolsList.ItemHeight = 16
        Me.AvailableToolsList.Location = New System.Drawing.Point(8, 23)
        Me.AvailableToolsList.Margin = New System.Windows.Forms.Padding(4)
        Me.AvailableToolsList.Name = "AvailableToolsList"
        Me.AvailableToolsList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AvailableToolsList.Size = New System.Drawing.Size(1107, 116)
        Me.AvailableToolsList.Sorted = True
        Me.AvailableToolsList.TabIndex = 8
        '
        'fraToolRules
        '
        Me.fraToolRules.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.fraToolRules.BackColor = System.Drawing.SystemColors.Control
        Me.fraToolRules.Controls.Add(Me.DefaultsFrame)
        Me.fraToolRules.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraToolRules.Location = New System.Drawing.Point(8, 166)
        Me.fraToolRules.Margin = New System.Windows.Forms.Padding(4)
        Me.fraToolRules.Name = "fraToolRules"
        Me.fraToolRules.Padding = New System.Windows.Forms.Padding(4)
        Me.fraToolRules.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraToolRules.Size = New System.Drawing.Size(1124, 242)
        Me.fraToolRules.TabIndex = 101
        Me.fraToolRules.TabStop = False
        Me.fraToolRules.Text = "Rules"
        '
        'DefaultsFrame
        '
        Me.DefaultsFrame.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.DefaultsFrame.AutoScroll = True
        Me.DefaultsFrame.Location = New System.Drawing.Point(8, 23)
        Me.DefaultsFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.DefaultsFrame.Name = "DefaultsFrame"
        Me.DefaultsFrame.Size = New System.Drawing.Size(1108, 212)
        Me.DefaultsFrame.TabIndex = 117
        '
        'TemplateBuildeTabControl
        '
        Me.TemplateBuildeTabControl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TemplateBuildeTabControl.Controls.Add(Me.TemplateSettingsTab)
        Me.TemplateBuildeTabControl.Controls.Add(Me.SupportFolderFilesTab)
        Me.TemplateBuildeTabControl.Controls.Add(Me.PlotStyleTablesTab)
        Me.TemplateBuildeTabControl.Controls.Add(Me.ToolsTab)
        Me.TemplateBuildeTabControl.Controls.Add(Me.SystemVariablesTab)
        Me.TemplateBuildeTabControl.Location = New System.Drawing.Point(16, 84)
        Me.TemplateBuildeTabControl.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplateBuildeTabControl.Name = "TemplateBuildeTabControl"
        Me.TemplateBuildeTabControl.SelectedIndex = 0
        Me.TemplateBuildeTabControl.Size = New System.Drawing.Size(1161, 457)
        Me.TemplateBuildeTabControl.TabIndex = 68
        '
        'TemplateSettingsTab
        '
        Me.TemplateSettingsTab.Controls.Add(Me.ContentsReportGroupBox)
        Me.TemplateSettingsTab.Controls.Add(Me.GroupBox2)
        Me.TemplateSettingsTab.Location = New System.Drawing.Point(4, 25)
        Me.TemplateSettingsTab.Margin = New System.Windows.Forms.Padding(4)
        Me.TemplateSettingsTab.Name = "TemplateSettingsTab"
        Me.TemplateSettingsTab.Padding = New System.Windows.Forms.Padding(4)
        Me.TemplateSettingsTab.Size = New System.Drawing.Size(1153, 428)
        Me.TemplateSettingsTab.TabIndex = 24
        Me.TemplateSettingsTab.Text = "Template Settings"
        Me.TemplateSettingsTab.UseVisualStyleBackColor = True
        '
        'ContentsReportGroupBox
        '
        Me.ContentsReportGroupBox.Controls.Add(Me.RefreshReportButton)
        Me.ContentsReportGroupBox.Controls.Add(Me.StampButton)
        Me.ContentsReportGroupBox.Controls.Add(Me.ContentReportTextBox)
        Me.ContentsReportGroupBox.Controls.Add(Me.SaveReportButton)
        Me.ContentsReportGroupBox.Location = New System.Drawing.Point(41, 132)
        Me.ContentsReportGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContentsReportGroupBox.Name = "ContentsReportGroupBox"
        Me.ContentsReportGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.ContentsReportGroupBox.Size = New System.Drawing.Size(1071, 286)
        Me.ContentsReportGroupBox.TabIndex = 13
        Me.ContentsReportGroupBox.TabStop = False
        Me.ContentsReportGroupBox.Text = "Report"
        '
        'RefreshReportButton
        '
        Me.RefreshReportButton.Location = New System.Drawing.Point(131, 245)
        Me.RefreshReportButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RefreshReportButton.Name = "RefreshReportButton"
        Me.RefreshReportButton.Size = New System.Drawing.Size(107, 33)
        Me.RefreshReportButton.TabIndex = 4
        Me.RefreshReportButton.Text = "Reread"
        Me.RefreshReportButton.UseVisualStyleBackColor = True
        '
        'StampButton
        '
        Me.StampButton.Location = New System.Drawing.Point(16, 245)
        Me.StampButton.Margin = New System.Windows.Forms.Padding(4)
        Me.StampButton.Name = "StampButton"
        Me.StampButton.Size = New System.Drawing.Size(107, 33)
        Me.StampButton.TabIndex = 3
        Me.StampButton.Text = "Stamp"
        Me.StampButton.UseVisualStyleBackColor = True
        '
        'ContentReportTextBox
        '
        Me.ContentReportTextBox.Location = New System.Drawing.Point(16, 25)
        Me.ContentReportTextBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ContentReportTextBox.Multiline = True
        Me.ContentReportTextBox.Name = "ContentReportTextBox"
        Me.ContentReportTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.ContentReportTextBox.Size = New System.Drawing.Size(1040, 211)
        Me.ContentReportTextBox.TabIndex = 2
        '
        'SaveReportButton
        '
        Me.SaveReportButton.Enabled = False
        Me.SaveReportButton.Location = New System.Drawing.Point(951, 245)
        Me.SaveReportButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SaveReportButton.Name = "SaveReportButton"
        Me.SaveReportButton.Size = New System.Drawing.Size(107, 33)
        Me.SaveReportButton.TabIndex = 1
        Me.SaveReportButton.Text = "Save Report"
        Me.SaveReportButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ConfigNameLabel)
        Me.GroupBox2.Location = New System.Drawing.Point(40, 7)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(1072, 117)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Template Name"
        '
        'ConfigNameLabel
        '
        Me.ConfigNameLabel.AutoSize = True
        Me.ConfigNameLabel.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ConfigNameLabel.Location = New System.Drawing.Point(65, 47)
        Me.ConfigNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ConfigNameLabel.Name = "ConfigNameLabel"
        Me.ConfigNameLabel.Size = New System.Drawing.Size(254, 35)
        Me.ConfigNameLabel.TabIndex = 16
        Me.ConfigNameLabel.Text = "ConfigNameLabel"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(225, 6)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(85, 32)
        Me.Cancel_Button.TabIndex = 113
        Me.Cancel_Button.Text = "&Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(73, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(60, 17)
        Me.RadioButton1.TabIndex = 1
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Testing"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.FinishButton, 1, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(856, 543)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(321, 44)
        Me.TableLayoutPanel2.TabIndex = 114
        '
        'frmTemplateBuilder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1201, 591)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.fraFinish)
        Me.Controls.Add(Me.lblPageSetups)
        Me.Controls.Add(Me.lblContentRules)
        Me.Controls.Add(Me.lblSystemVariables)
        Me.Controls.Add(Me.lblMenuItems)
        Me.Controls.Add(Me.lblLimits)
        Me.Controls.Add(Me.lblHatchPatterns)
        Me.Controls.Add(Me.lblFontsShapes)
        Me.Controls.Add(Me.lblAliases)
        Me.Controls.Add(Me.Curr)
        Me.Controls.Add(Me.Nkown)
        Me.Controls.Add(Me.cmdFinish)
        Me.Controls.Add(Me.fraSeparator)
        Me.Controls.Add(Me.cmdNext)
        Me.Controls.Add(Me.cmdBack)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdHelp)
        Me.Controls.Add(Me.imJacobs)
        Me.Controls.Add(Me.imPanel)
        Me.Controls.Add(Me.lblSetup)
        Me.Controls.Add(Me.lblTextStyles)
        Me.Controls.Add(Me.lblDimStyles)
        Me.Controls.Add(Me.lblPageLayouts)
        Me.Controls.Add(Me.lblLayers)
        Me.Controls.Add(Me.lblLinetypes)
        Me.Controls.Add(Me.lblPlotStyles)
        Me.Controls.Add(Me.lblPointStyles)
        Me.Controls.Add(Me.lblTableStyles)
        Me.Controls.Add(Me.lblBlocks)
        Me.Controls.Add(Me.imArrow)
        Me.Controls.Add(Me.lblPanelDescription)
        Me.Controls.Add(Me.TemplateBuildeTabControl)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(1210, 627)
        Me.Name = "frmTemplateBuilder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imJacobs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imPanel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imArrow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SystemVariablesTab.ResumeLayout(False)
        Me.PlotStyleTablesTab.ResumeLayout(False)
        Me.PlotStyleTablesTab.PerformLayout()
        Me.SupportFolderFilesTab.ResumeLayout(False)
        Me.SupportFolderFilesTab.PerformLayout()
        Me.ToolsTab.ResumeLayout(False)
        Me.fraMenuItems.ResumeLayout(False)
        Me.fraToolRules.ResumeLayout(False)
        Me.TemplateBuildeTabControl.ResumeLayout(False)
        Me.TemplateSettingsTab.ResumeLayout(False)
        Me.ContentsReportGroupBox.ResumeLayout(False)
        Me.ContentsReportGroupBox.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents fraFinish As System.Windows.Forms.GroupBox
    Public WithEvents lblPageSetups As System.Windows.Forms.Label
    Public WithEvents lblContentRules As System.Windows.Forms.Label
    Public WithEvents lblSystemVariables As System.Windows.Forms.Label
    Public WithEvents lblMenuItems As System.Windows.Forms.Label
    Public WithEvents lblLimits As System.Windows.Forms.Label
    Public WithEvents lblHatchPatterns As System.Windows.Forms.Label
    Public WithEvents lblFontsShapes As System.Windows.Forms.Label
    Public WithEvents lblAliases As System.Windows.Forms.Label
    Public WithEvents Curr As System.Windows.Forms.Label
    Public WithEvents Nkown As System.Windows.Forms.Label
    Public WithEvents cmdFinish As System.Windows.Forms.Button
    Public WithEvents fraSeparator As System.Windows.Forms.GroupBox
    Public WithEvents cmdNext As System.Windows.Forms.Button
    Public WithEvents cmdBack As System.Windows.Forms.Button
    Public WithEvents cmdCancel As System.Windows.Forms.Button
    Public WithEvents cmdSave As System.Windows.Forms.Button
    Public WithEvents cmdHelp As System.Windows.Forms.Button
    Public WithEvents imJacobs As System.Windows.Forms.PictureBox
    Public WithEvents imPanel As System.Windows.Forms.PictureBox
    Public WithEvents lblSetup As System.Windows.Forms.Label
    Public WithEvents lblTextStyles As System.Windows.Forms.Label
    Public WithEvents lblDimStyles As System.Windows.Forms.Label
    Public WithEvents lblPageLayouts As System.Windows.Forms.Label
    Public WithEvents lblLayers As System.Windows.Forms.Label
    Public WithEvents lblLinetypes As System.Windows.Forms.Label
    Public WithEvents lblPlotStyles As System.Windows.Forms.Label
    Public WithEvents lblPointStyles As System.Windows.Forms.Label
    Public WithEvents lblTableStyles As System.Windows.Forms.Label
    Public WithEvents lblBlocks As System.Windows.Forms.Label
    Public WithEvents imArrow As System.Windows.Forms.PictureBox
    Public WithEvents lblPanelDescription As System.Windows.Forms.Label
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Public WithEvents FinishButton As System.Windows.Forms.Button
    Public WithEvents Button54 As System.Windows.Forms.Button
    Friend WithEvents Help_Button As System.Windows.Forms.Button
    Friend WithEvents SystemVariablesTab As System.Windows.Forms.TabPage
    Friend WithEvents SystemVariablesListView As System.Windows.Forms.ListView
    Public WithEvents SystemVariableEditButton As System.Windows.Forms.Button
    Friend WithEvents PlotStyleTablesTab As System.Windows.Forms.TabPage
    Public WithEvents AdditionalPlotStyleFilesListBox As System.Windows.Forms.ListBox
    Friend WithEvents SupportFolderFilesTab As System.Windows.Forms.TabPage
    Friend WithEvents SupportFilterLabel As System.Windows.Forms.Label
    Friend WithEvents SupportFilterComboBox As System.Windows.Forms.ComboBox
    Public WithEvents AdditionalSupportFilesListBox As System.Windows.Forms.ListBox
    Public WithEvents AddSupportFilesButton As System.Windows.Forms.Button
    Public WithEvents DeleteSupportFilesButton As System.Windows.Forms.Button
    Public WithEvents NavigateSupportButton As System.Windows.Forms.Button
    Public WithEvents CreateBlockFinderDat As System.Windows.Forms.Button
    Friend WithEvents ToolsTab As System.Windows.Forms.TabPage
    Public WithEvents fraMenuItems As System.Windows.Forms.GroupBox
    Public WithEvents AvailableToolsList As System.Windows.Forms.ListBox
    Public WithEvents fraToolRules As System.Windows.Forms.GroupBox
    Friend WithEvents TemplateBuildeTabControl As System.Windows.Forms.TabControl
    Friend WithEvents PlotStyleFilterLabel As System.Windows.Forms.Label
    Friend WithEvents PlotStyleFilterComboBox As System.Windows.Forms.ComboBox
    Public WithEvents AddPlotStyleButton As System.Windows.Forms.Button
    Public WithEvents DeletePlotStyleButton As System.Windows.Forms.Button
    Public WithEvents NavigatePlotStyleButton As System.Windows.Forms.Button
    Public WithEvents CreateHatchFileButton As System.Windows.Forms.Button
    Public WithEvents CreatePGPButton As System.Windows.Forms.Button
    Public WithEvents CreateLineTypeFileButton As System.Windows.Forms.Button
    Friend WithEvents VariableName As System.Windows.Forms.ColumnHeader
    Friend WithEvents Description As System.Windows.Forms.ColumnHeader
    Friend WithEvents CHMFile As System.Windows.Forms.ColumnHeader
    Friend WithEvents Topic As System.Windows.Forms.ColumnHeader
    Friend WithEvents Value As System.Windows.Forms.ColumnHeader
    Public WithEvents SupportFolderFilesRefreshButton As System.Windows.Forms.Button
    Public WithEvents PlotStyleFilesRefreshButton As System.Windows.Forms.Button
    Public WithEvents EditSupportFileButton As System.Windows.Forms.Button
    Friend WithEvents DefaultsFrame As System.Windows.Forms.Panel
    Friend WithEvents TemplateSettingsTab As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents ContentsReportGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents ConfigNameLabel As System.Windows.Forms.Label
    Friend WithEvents SaveReportButton As System.Windows.Forms.Button
    Friend WithEvents ContentReportTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StampButton As System.Windows.Forms.Button
    Friend WithEvents RefreshReportButton As System.Windows.Forms.Button
    Friend WithEvents RemoveRulesByToolNameButton As System.Windows.Forms.Button
    Friend WithEvents RemoveObsoleteRulesButton As System.Windows.Forms.Button
    Friend WithEvents RemoveRulesButton As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel

End Class
