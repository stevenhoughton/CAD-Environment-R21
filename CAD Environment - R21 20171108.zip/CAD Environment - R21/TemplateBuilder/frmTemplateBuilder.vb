Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.EditorInput
Imports System.IO
Imports Microsoft.VisualBasic
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings
Imports System.Data
Imports System.Linq
Imports Autodesk.AutoCAD.ApplicationServices.DocumentExtension
'Imports Autodesk.AutoCAD.ApplicationServices.DocumentCollectionExtension

Public Class frmTemplateBuilder

    Dim cDirectoryEntries As Collection = New Collection
    Const cfgCountry As Integer = 0
    Const cfgRegion As Integer = 1
    Const cfgClient As Integer = 2
    Const cfgDisciplines As Integer = 3

    ' '' Setup a grid control
    Private WithEvents MyDataGridView As DataGridView

    Dim DataGridViewControlsCollection As Collection
    Dim DataTablesCollection As Collection

    Public ReadOnly Property ThisDrawing() As AcadDocument

        Get
            Return CType(Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.GetAcadDocument, AcadDocument)
        End Get

    End Property

    Dim ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
    Private Const SYSVARS_VARIABLES As String = "System Variables"
    ' Dim RuleAccessors As New RuleAccessors
    Dim DefaultsHeld As Boolean
    ' Hold and restore defaults array
    'Dim SelectedCntrlValues() As Object
    Dim RulesDirty As Boolean = False
    Dim PreviousToolSelected As Integer = -1

    'Public Function ShowLineTypeDialog() As ObjectId
    '    Dim xLIneTypeDialog As New Autodesk.AutoCAD.Windows.LinetypeDialog()
    '    Dim dr As System.Windows.Forms.DialogResult
    '    dr = xLIneTypeDialog.ShowDialog()
    '    If dr = System.Windows.Forms.DialogResult.OK Then
    '        Dim SelLineType As ObjectId = xLIneTypeDialog.Linetype
    '        Return SelLineType
    '    ElseIf dr = System.Windows.Forms.DialogResult.Cancel Then
    '        Return ObjectId.Null
    '    End If
    'End Function

    Private Sub frmTemplateBuilder_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        SaveRules()
    End Sub

    Private Sub frmTemplateBuilder_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            '' Are we in the middle of a template Create or Modify ?
            CheckForTriggerfile()

            'If res = Windows.Forms.DialogResult.Yes Then
            ConfigNameLabel.Text = RuleAccessors.GetruleValue("FULLCONFIGNAME")

            'MyDataGridView = New DataGridView
            'AddHandler MyDataGridView.DataError, AddressOf GridView_DataError

            DataGridViewControlsCollection = New Collection
            DataTablesCollection = New Collection

            SetSearchPath(Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", ConfigNameLabel.Text, "Support"), True)

            InitializeAdditionalSupportFilesTab()
            InitializeAdditionalPlotSTyleFilesTab()
            InitializeSystemVariablesTab()
            InitializeToolsTab()
            initializeConfigurationSettingsTab()

            PopulateConfigurationDescription()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub


    Sub CheckForTriggerfile()

        Dim TriggerFile As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea", "TriggerFile.txt")

        If System.IO.File.Exists(TriggerFile) Then
            Dim NewConfigName As String = ReadTextFile(TriggerFile)(0)
            ThisDrawingUtilities.Utility.Prompt("Checking..: " & NewConfigName.ToUpper & "  ===  " & ThisDrawingUtilities.Name.ToUpper)
            If ThisDrawingUtilities.Name.ToUpper.Contains(NewConfigName.ToUpper) Then

                RuleAccessors.AddRule("FULLCONFIGNAME", NewConfigName, "Configuration Name", "0", "0")
                RuleAccessors.AddRule("CONFIGLEVEL", "CLIENT", "Configuration Level", "0", "0")

                ThisDrawingUtilities.Utility.Prompt("New Template Name Stamped")

            End If

            System.IO.File.Delete(TriggerFile)

        End If

    End Sub

    Private Sub InitializeSystemVariablesTab()
        Try
            Dim sVariablesFile As String


            Dim sSearchPath As String = Settings.Manager.AE.Path ' getpath("General", "ContentWizard")

            Dim temp As New DirectoryInfo(sSearchPath)

            sVariablesFile = Environment.SearchFile(temp, "Variables.dat")

            ' check to see whether we found the variables files
            If sVariablesFile = vbNullString Then
                '...we didn't, so alert the user...

                Acad_MessageBox("Unable to find variables.dat file in " & sSearchPath, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

                '...and bail
                Exit Sub
            Else
                Display(sVariablesFile)
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Public Sub Display(ByRef sVarsFile As String)

        Try
            Dim strItems As String
            Dim lngSize As Integer
            Dim i As Integer
            Dim astrAllItems As Object

            With SystemVariablesListView
                .FullRowSelect = True
                .LabelEdit = False
                .MultiSelect = False
                .View = System.Windows.Forms.View.Details
                .Items.Clear()
            End With

            ' Pick some arbitrary size, as a guess.
            lngSize = 1024
            Do
                strItems = Space(lngSize)
                lngSize = GetPrivateProfileSection(SYSVARS_VARIABLES, strItems, lngSize, sVarsFile)

                If lngSize = 0 Then

                    Acad_MessageBox(SYSVARS_VARIABLES & " system variables section does not exist!", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

                    Exit Sub
                ElseIf lngSize = Len(strItems) - 2 Then
                    ' Not enough space!
                    ' If you double the amount of
                    ' available space, perhaps that
                    ' will solve the problem.
                    lngSize = lngSize * 2
                Else
                    ' Trim off the extra stuff. Use lngSize - 1
                    ' because there's an extra vbNullChar
                    ' at the end of this string.
                    If lngSize > 1 Then
                        strItems = strItems.Remove(lngSize - 1, 1)
                    End If
                    Exit Do
                End If
            Loop
            ' If you get here, you've got a null-separated
            ' list of items. Use the Split function
            ' to pull them into an array of strings.
            astrAllItems = Split(strItems, vbNullChar)

            Dim vSysVarItems As Object
            Dim str(4) As String
            Dim itm As ListViewItem

            For i = LBound(astrAllItems) To UBound(astrAllItems) - 1
                If Len(astrAllItems(i)) > 0 Then
                    vSysVarItems = Split(astrAllItems(i), ",")
                    str(0) = vSysVarItems(0)   ' Var Name
                    str(1) = vSysVarItems(1)   ' Description
                    str(2) = ThisDrawing.GetVariable(vSysVarItems(0)).ToString ' Value
                    str(3) = vSysVarItems(2)   ' Chm File
                    str(4) = vSysVarItems(3)   ' Topic ID
                    itm = New ListViewItem(str)
                    SystemVariablesListView.Items.Add(itm)
                End If
            Next

            SystemVariableEditButton.Enabled = False
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub FinishButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FinishButton.Click

        SaveRules()

        Try

            SaveDWG()

            'If PurgeLayersInTemplateCheckBox.Checked = True Then
            'End If

            AddWorkVar("INTEMPLATE", "True")

            SaveTemplate()

            Acad_MessageBox("The DWG & DWT files for " & ConfigNameLabel.Text & " have been saved." & vbCrLf &
                "You may purge any content you do not wish to see in the DWT file now." & vbCrLf &
                "You may save the template file at any time using the Jacobs_SaveTemplate command." _
                , System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Me.Hide()
        Me.Close()

    End Sub

    Public Sub SaveTemplate()

        Dim FileName As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support", ConfigNameLabel.Text & ".DWT"))

        Acad_MessageBox("Saving Template: " & FileName)

        Dim AcadPref As Autodesk.AutoCAD.Interop.AcadPreferencesOpenSave = ThisDrawingUtilities.Application.Preferences.OpenSave

        ' Store current setting
        Dim originalValue As AcSaveAsType = AcadPref.SaveAsType

        AcadPref.SaveAsType = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_Template
        ThisDrawingUtilities.SaveAs(FileName)
        AcadPref.SaveAsType = originalValue

    End Sub

    Sub SaveDWG()

        Dim FileName As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support", ConfigNameLabel.Text & ".DWG"))

        Acad_MessageBox("Saving Drawing: " & FileName)

        Dim AcadPref As Autodesk.AutoCAD.Interop.AcadPreferencesOpenSave = ThisDrawing.Application.Preferences.OpenSave

        ' Store current setting
        Dim originalValue As AcSaveAsType = AcadPref.SaveAsType

        AcadPref.SaveAsType = Autodesk.AutoCAD.Interop.Common.AcSaveAsType.ac2013_dwg
        ThisDrawingUtilities.SaveAs(FileName)
        AcadPref.SaveAsType = originalValue

        ThisDrawingUtilities.SaveAs(FileName)

    End Sub


#Region "Buttons"

    Private Sub HelpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub UnitsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".UNITS" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub PointStylesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".DDPTYPE" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub DraftingSettingsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".DSettings" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LayersButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".LAYER" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub DimensionStylesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".DIMSTYLE" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub TextStylesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".STYLE" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LineTypesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".LTYPE" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub TableStylesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".TABLESTYLE" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub LayoutsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Acad_MessageBox("NO UI Available type in layout name LAYOUT", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

    End Sub

    Private Sub CreateBlocksButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".BLOCK" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

    Private Sub PageSetupsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                ThisDrawingUtilities.SendCommand("^C" & vbCr)
                ThisDrawingUtilities.SendCommand(".PAGESETUP" & vbCr)
            End Using
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try
    End Sub

#End Region

    Private Sub SystemVariableEditButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SystemVariableEditButton.Click
        Dim frmEdit As New EditSystemVariableForm

        frmEdit.Display(SystemVariablesListView.SelectedItems(0), True)
        SystemVariablesListView.SelectedItems(0).Checked = True

        SystemVariableEditButton.Enabled = False

    End Sub

    Private Sub SystemVariablesListView_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SystemVariablesListView.SelectedIndexChanged
        If SystemVariablesListView.SelectedItems.Count <> 0 Then
            SystemVariableEditButton.Enabled = True
        Else
            SystemVariableEditButton.Enabled = False
        End If
    End Sub


#Region "Buttons"

    Private Sub DeleteSupportFilesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteSupportFilesButton.Click

        If IsThisAnOldConfigName() = True Then
            DeleteSelectedFiles(AdditionalSupportFilesListBox, Settings.Manager.AutoCAD.WorkingSupportFolder)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            DeleteSelectedFiles(AdditionalSupportFilesListBox, NewPath)
        End If
        AdditionalSupportFilesListBox.Sorted = True
        InitializeAdditionalSupportFilesTab()

    End Sub

    Private Sub SupportFolderFilesRefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SupportFolderFilesRefreshButton.Click

        InitializeAdditionalSupportFilesTab()

    End Sub

    Private Sub NavigateSupportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NavigateSupportButton.Click

        If IsThisAnOldConfigName() = True Then
            Call Shell("explorer " & Settings.Manager.AutoCAD.WorkingSupportFolder, AppWinStyle.NormalFocus)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            Call Shell("explorer " & NewPath, AppWinStyle.NormalFocus)
        End If

    End Sub

    Sub InitializeAdditionalSupportFilesTab()

        SupportFolderFilesTab.Enabled = True

        If ThisDrawingIsConfigured() = True Then
            If IsThisAnOldConfigName() = True Then
                PopulateListBoxWithFilesInFolder(AdditionalSupportFilesListBox, Settings.Manager.AutoCAD.WorkingSupportFolder, "*.*")
            Else
                'SupportFolderFilesTab.Enabled = False
                'Else

                Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))


                PopulateListBoxWithFilesInFolder(AdditionalSupportFilesListBox, NewPath, "*.*")
                ' End If
            End If
        Else
            SupportFolderFilesTab.Enabled = False
        End If
        SupportFilterComboBox.Text = "*"

    End Sub

    Private Sub AddSupportFilesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddSupportFilesButton.Click

        If IsThisAnOldConfigName() = True Then
            AddAndCopySelectedFiles(AdditionalSupportFilesListBox, SupportFilterComboBox.Text, "Select Files to include in the Support Folder: ", Settings.Manager.AutoCAD.WorkingSupportFolder, "Select Files")
        Else

            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))

            AddAndCopySelectedFiles(AdditionalSupportFilesListBox, SupportFilterComboBox.Text, "Select Files to include in the Support Folder: ", NewPath, "Select Files")

        End If
        AdditionalSupportFilesListBox.Sorted = True
        SupportFilterComboBox.Text = "*"
        InitializeAdditionalSupportFilesTab()

    End Sub

    Private Sub NavigateFontsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If IsThisAnOldConfigName() = True Then
            Call Shell("explorer " & Settings.Manager.AutoCAD.WorkingSupportFolder, AppWinStyle.NormalFocus)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            Call Shell("explorer " & NewPath, AppWinStyle.NormalFocus)
        End If

    End Sub

    Sub InitializeAdditionalPlotSTyleFilesTab()

        If IsThisAnOldConfigName() = True Then
            PopulateListBoxWithFilesInFolder(AdditionalPlotStyleFilesListBox, Settings.Manager.AutoCAD.WorkingPlotStylesFolder, "*.*")
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Plotters\Plot Styles"))
            PopulateListBoxWithFilesInFolder(AdditionalPlotStyleFilesListBox, NewPath, "*.*")
        End If
        AdditionalPlotStyleFilesListBox.Text = "*"

    End Sub

    Private Sub AddPlotStyleButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddPlotStyleButton.Click

        If IsThisAnOldConfigName() = True Then
            AddAndCopySelectedFiles(AdditionalPlotStyleFilesListBox, PlotStyleFilterComboBox.Text, "Select Files to include in the Plot Styles Folder: ", Settings.Manager.AutoCAD.WorkingPlotStylesFolder, "Select PlotStyle Tables")
        Else

            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Plotters\Plot Styles"))

            AddAndCopySelectedFiles(AdditionalPlotStyleFilesListBox, PlotStyleFilterComboBox.Text, "Select Files to include in the Plot Styles Folder: ", NewPath, "Select PlotStyle Tables")
        End If
        AdditionalPlotStyleFilesListBox.Sorted = True
        InitializeAdditionalPlotSTyleFilesTab()

    End Sub

    Private Sub DeletePlotStyleButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeletePlotStyleButton.Click

        If IsThisAnOldConfigName() = True Then
            DeleteSelectedFiles(AdditionalPlotStyleFilesListBox, Settings.Manager.AutoCAD.WorkingPlotStylesFolder)
        Else

            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Plotters\Plot Styles"))
            DeleteSelectedFiles(AdditionalPlotStyleFilesListBox, NewPath)

        End If
        AdditionalPlotStyleFilesListBox.Sorted = True
        InitializeAdditionalPlotSTyleFilesTab()

    End Sub

    Private Sub NavigatePlotStyleButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NavigatePlotStyleButton.Click
        If IsThisAnOldConfigName() = True Then
            Call Shell("explorer " & Settings.Manager.AutoCAD.WorkingPlotStylesFolder, AppWinStyle.NormalFocus)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Plotters\Plot Styles"))
            Call Shell("explorer " & NewPath, AppWinStyle.NormalFocus)
        End If
    End Sub

    Private Sub PlotStyleFilesRefreshButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlotStyleFilesRefreshButton.Click
        InitializeAdditionalPlotSTyleFilesTab()
    End Sub

#End Region

    Sub InitializeToolsTab()

        ' Read the rules to see if there are any menus already selected in this template
        ' If there is then add them to the selected menus list
        '      MenuCheck()

        ' Read the tools.ini file and populate the available menus for this level / selection
        ' If some menus have already been selected then omit them from the available menus list
        Dim j As Integer
        Dim sVarsFile As String

        ' Get rid of any rule overrides which may be present from creating a template from a production file
        SwitchRemoveRuleOverrides()

        AvailableToolsList.Items.Clear()
        ' This section of code reads the relevant section in the tools.ini file and extracts the information requied to build this user form
        sVarsFile = Settings.Manager.AE.Path.CombinePath("\Tools.ini")
        INIFileReadTopics(sVarsFile)
        ' Iterate though all the tools available in the TOOLS.INI file
        For j = 0 To CShort(UBound(ToolDetails))
            If InAvailableList(ToolDetails(j).ToolName) = False Then
                If ToolDetails(j).Rules(0).ToString <> "" Then
                    AvailableToolsList.Items.Add(ToolDetails(j).ToolName)

                    Dim SearchForContent As Boolean = True
                    If IsMasterFile() = True Then
                        SearchForContent = False
                    End If

                    ' Add rules to DWG database
                    'If IsThisAnOldConfigName() = True Then
                    '    InitializeRules(ToolDetails(j).ToolName, True, SearchForContent, False)
                    'Else
                    InitializeRulesNew(ToolDetails(j).ToolName, True, SearchForContent, False)
                    'End If

                End If
            End If
        Next
        '' Get rid of any old rule names we already know about
        '  RemoveObsoleteRules()

    End Sub

    Function InAvailableList(ByRef sToolName As String) As Boolean

        Dim IsInTheAvailableTools As Boolean
        Dim i As Integer

        IsInTheAvailableTools = False

        If AvailableToolsList.Items.Count <> 0 Then
            For i = 0 To CShort(AvailableToolsList.Items.Count - 1)
                If UCase(UserInterface.GetListBoxText(AvailableToolsList, i)) = UCase(sToolName) Then
                    IsInTheAvailableTools = True
                End If
            Next
        End If

        InAvailableList = IsInTheAvailableTools

    End Function

    Private Sub CreateBlockFinderDat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateBlockFinderDat.Click

        Dim sFilesInString() As String
        Dim fname As String
        Dim bName As String

        If IsThisAnOldConfigName() = True Then
            sFilesInString = AutoCADOpenMultiSelect(Settings.Manager.AutoCAD.WorkingSupportFolder)
            fname = Settings.Manager.AutoCAD.WorkingSupportFolder.ToString.CombinePath(Settings.Manager.AE.UserBlockFinderSettingsFileName)
        Else

            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))

            sFilesInString = AutoCADOpenMultiSelect(NewPath)

            fname = NewPath.ToString.CombinePath(Settings.Manager.AE.UserBlockFinderSettingsFileName)

        End If

        If Not sFilesInString Is Nothing Then

            FileOpen(1, fname, Microsoft.VisualBasic.OpenMode.Output)
            For Each bName In sFilesInString
                PrintLine(1, Path.GetFileNameWithoutExtension(bName))
                PrintLine(1, Path.GetFileName(bName))
            Next
            FileClose(1)
            ' open notepad with file

            If Acad_MessageBox("A basic " & Settings.Manager.AE.UserBlockFinderSettingsFileName & " file has been created with default link names." & vbCr &
                               "Do you wish to edit the file now so that you can modify the link display names?",
                                System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name,
                               MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                Shell("NOTEPAD.EXE " & fname, AppWinStyle.MaximizedFocus)

            End If

        End If

    End Sub

    Private Sub CreateHatchFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateHatchFileButton.Click

        If IsThisAnOldConfigName() = True Then

            AddAndCopySelectedFile(AdditionalSupportFilesListBox, "PAT", "Select a client hatch pattern file", Settings.Manager.AutoCAD.WorkingSupportFolder, , , True)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            AddAndCopySelectedFile(AdditionalSupportFilesListBox, "PAT", "Select a client hatch pattern file", NewPath, , , True)
        End If

    End Sub

    Private Sub CreatePGPButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreatePGPButton.Click

        If IsThisAnOldConfigName() = True Then
            AddAndCopySelectedFile(AdditionalSupportFilesListBox, "PGP", "Select a client PGP file", Settings.Manager.AutoCAD.WorkingSupportFolder, , , True)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            AddAndCopySelectedFile(AdditionalSupportFilesListBox, "PGP", "Select a client PGP file", NewPath, , , True)
        End If

    End Sub

    Private Sub CreateLineTypeFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateLineTypeFileButton.Click

        If IsThisAnOldConfigName() = True Then
            AddAndCopySelectedFile(AdditionalSupportFilesListBox, "LIN", "Select a client Line Type file", Settings.Manager.AutoCAD.WorkingSupportFolder, , , True)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            AddAndCopySelectedFile(AdditionalSupportFilesListBox, "LIN", "Select a client Line Type file", NewPath, , , True)
        End If

    End Sub

    Private Sub EditSupportFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditSupportFileButton.Click

        If IsThisAnOldConfigName() = True Then
            EditSelectedFiles(AdditionalSupportFilesListBox, Settings.Manager.AutoCAD.WorkingSupportFolder)
        Else
            Dim NewPath As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support"))
            EditSelectedFiles(AdditionalSupportFilesListBox, NewPath)
        End If

    End Sub

    Private Sub AvailableToolsList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AvailableToolsList.SelectedIndexChanged

        Dim i As Object
        Dim toolindex As Integer
        Dim strCleanTitle As String = String.Empty

        SaveRules()

        For i = 0 To Me.AvailableToolsList.Items.Count - 1
            If Me.AvailableToolsList.GetSelected(CInt(i)) = True Then
                strCleanTitle = UserInterface.GetListBoxText(Me.AvailableToolsList, CInt(i)).Replace("[", "")
                strCleanTitle = strCleanTitle.Replace("]", "")
                Exit For
            End If
        Next

        ' Find out which tool the user has chosen to configure and set the ToolIndex variable to point to it.
        For i = 0 To UBound(ToolDetails)
            If ToolDetails(CInt(i)).ToolName = "[" & strCleanTitle & "]" Then
                toolindex = CShort(i)
                Exit For
            End If
        Next

        ' If UCase(ConfigurationLevel) <> UCase(ToolDetails(tool index).ToolGroup) Then
        PreviousToolSelected = toolindex

        Dim SearchForContent As Boolean = True
        If IsMasterFile() = True Then
            SearchForContent = False
        End If

        'If IsThisAnOldConfigName() = True Then
        '    InitializeRules(ToolDetails(toolindex).ToolName, True, SearchForContent, False)
        'Else
        InitializeRulesNew(ToolDetails(toolindex).ToolName, True, SearchForContent, False)
        'End If

        ConfigReplacement()
        RulesDirty = True


    End Sub

    Sub ConfigReplacement()

        Dim strCleanTitle As String
        Dim toolindex As Integer

        strCleanTitle = UpdateTitleOnConfigDialogBox()

        toolindex = GetSelectedToolIndex((AvailableToolsList))

        '  DataTablesCollection.Clear()

        BuildConfigDialogBox(strCleanTitle, toolindex)

    End Sub


    Function UpdateTitleOnConfigDialogBox() As String

        Dim i As Integer
        Dim strCleanTitle As String = ""

        ' Go through the selected tools list and get the name of the tool - remove the []
        For i = 0 To CShort(AvailableToolsList.Items.Count - 1)
            If AvailableToolsList.GetSelected(i) = True Then
                strCleanTitle = UserInterface.GetListBoxText(Me.AvailableToolsList, i).Replace("[", "")
                strCleanTitle = strCleanTitle.Replace("]", "")
            End If
        Next

        ' Adjust the title in the dialog box and the help sting to show the tool we are working on
        Me.Text = "Define Tool Defaults for: " & strCleanTitle

        UpdateTitleOnConfigDialogBox = strCleanTitle


    End Function

    Function GetSelectedToolIndex(ByRef lListToSearch As System.Windows.Forms.ListBox) As Integer

        Dim toolindex As Integer
        Dim i As Integer
        Dim strCleanTitle As String = ""

        ' Go through the selected tools list and get the name of the tool - remove the []
        For i = 0 To CShort(lListToSearch.Items.Count - 1)
            If lListToSearch.GetSelected(i) = True Then
                ' strCleanTitle = VB.Right(VB.Left(Core.UserInterface.GetListBoxText(lListToSearch, i), Len(Core.UserInterface.GetListBoxText(lListToSearch, i)) - 1), Len(Core.UserInterface.GetListBoxText(lListToSearch, i)) - 2)
                strCleanTitle = UserInterface.GetListBoxText(Me.AvailableToolsList, i).Replace("[", "")
                strCleanTitle = strCleanTitle.Replace("]", "")
            End If
        Next

        ' Go through the tool details list and get a pointer to the selected tool
        For i = 0 To CShort(UBound(ToolDetails))
            If UCase(ToolDetails(i).ToolName) = UCase("[" & strCleanTitle & "]") Then
                toolindex = i
            End If
        Next

        GetSelectedToolIndex = toolindex

    End Function

    Private Sub WarningHelpButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())

    End Sub


    Private Sub TemplateBuildeTabControl_Selected(ByVal sender As Object, ByVal e As System.Windows.Forms.TabControlEventArgs) Handles TemplateBuildeTabControl.Selected

        SaveRules()

        Select Case e.TabPage.Name

            'Case "SetupTab"

            'Case "SymbolTablesTab"

            Case "SupportFolderFilesTab"
                InitializeAdditionalSupportFilesTab()

                'Case "FontsFolderFilesTab"
                '    InitializeAdditionalFontFilesTab()

            Case "PlotStyleTablesTab"
                InitializeAdditionalPlotSTyleFilesTab()

            Case "SystemVariablesTab"

            Case "ToolsTab"

            Case "ConfigurationSettingsTab"

                '                CurrentConfigNameTextBox.Text = RuleAccessors.GetruleValue("FULLCONFIGNAME", "Client", True)
                '                CurrentClientLevelTextBox.Text = RuleAccessors.GetruleValue("CONFIGLEVEL", "Client", True)
                '               If RuleAccessors.GetruleValue("TESTCONFIG", "FALSE", True).IsTrue Then
                'CurrentModeTextBox.Text = "TEST"
                'Else
                'CurrentModeTextBox.Text = "PRODUCTION"
                'End If

        End Select

    End Sub

    Sub SaveRules()

        If RulesDirty = True Then
            If Not PreviousToolSelected = -1 Then

                ' This function needs to iterate through all the controls and hold the values so that we can save them
                Dim cntrl As Control
                Dim i As Integer
                Dim toolindex As Integer = PreviousToolSelected
                Dim strCleanTitle As String = ""
                Dim Value As String
                Dim myCheckBox As CheckBox

                strCleanTitle = ToolDetails(PreviousToolSelected).ToolName.Replace("[", "")
                strCleanTitle = strCleanTitle.Replace("]", "")

                ' This loops through all the controls on the form and shows us which is the current selected item for each control.
                For Each cntrl In DefaultsFrame.Controls ' Check each of the controls found in the frame
                    ' Identify if this is one of the controls we are interested in

                    If cntrl.GetType.FullName.ToUpper.Contains("ComboBox".ToUpper) Or
                        cntrl.GetType.FullName.ToUpper.Contains("TextBox".ToUpper) Or
                        cntrl.GetType.FullName.ToUpper.Contains("ListBox".ToUpper) Or
                        cntrl.GetType.FullName.ToUpper.Contains("CheckBox".ToUpper) Or
                        cntrl.GetType.FullName.ToUpper.Contains("DataGridView".ToUpper) Then

                        ' Need to find the matching ToolDetail and record it

                        For i = 0 To UBound(ToolDetails(toolindex).Rules)

                            If cntrl.Name = Split(ToolDetails(toolindex).Rules(i), ",")(0) Then

                                If cntrl.GetType.FullName.ToUpper.Contains("CheckBox".ToUpper) Then
                                    myCheckBox = CType(cntrl, CheckBox)
                                    If myCheckBox.CheckState = CheckState.Checked Then
                                        Value = "1"
                                    Else
                                        Value = "0"
                                    End If
                                Else
                                    If cntrl.GetType.FullName.ToUpper.Contains("DataGridView".ToUpper) Then
                                        Value = GetFormattedRuleValueFromGridView(cntrl.Name)
                                    Else
                                        Value = cntrl.Text
                                    End If

                                End If

                                Acad_MessageBox("Saving Rule for Tool: " & strCleanTitle, , , , , , , True)
                                Acad_MessageBox("Saving Rule " & cntrl.Name & " = " & Value & " Desc: " & Split(ToolDetails(toolindex).Rules(i), ",")(1), , , , , , , True)

                                If Split(ToolDetails(toolindex).Rules(i), ",")(3) = "3" Then
                                    ' MsgBox(Value)
                                    RuleAccessors.AddRule(cntrl.Name, Value, Split(ToolDetails(toolindex).Rules(i), ",")(1), Split(ToolDetails(toolindex).Rules(i), ",")(3), Split(ToolDetails(toolindex).Rules(i), ",")(4))
                                Else
                                    RuleAccessors.AddRule(cntrl.Name, Value, Split(ToolDetails(toolindex).Rules(i), ",")(1), Split(ToolDetails(toolindex).Rules(i), ",")(3), Split(ToolDetails(toolindex).Rules(i), ",")(4))
                                End If

                            End If
                        Next
                    End If
                Next ' Next control

                '' Clear out the collections
                DataGridViewControlsCollection.Clear()
                DataTablesCollection.Clear()

                RulesDirty = False

            End If

        End If

    End Sub

    Private Sub CreateLayerXMLFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Acad_MessageBox("Work in progress", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

    End Sub

    Private Sub ImportLayersFromXMLButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Acad_MessageBox("Work in progress", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Acad_MessageBox("Work in progress", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

    End Sub

    Private Sub ImportPageSetupsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Acad_MessageBox("Work in progress", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        RemoveWorkVar("INTEMPLATE")

        Me.Hide()
        Me.Close()
    End Sub

    Private Sub initializeConfigurationSettingsTab()

        ' Get all client configurations in library
        CEGetDirectories(Settings.Manager.AE.ClientsConfigurationPath, cDirectoryEntries, Settings.Manager.AE.TemplatesToHideFileNamePathed, Settings.IsUserValidSystemAdministrator)

    End Sub

    Function CheckConfigBuilders() As Boolean

        Dim result As Boolean = False

        If File.Exists(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationTestersFileName)) Then
            Dim aFileRead() As String = ReadTextFile(Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationTestersFileName))
            For Each Str As String In aFileRead
                If Str.ToUpper = Common.Settings.Manager.EvaluateExpression(Settings.Manager.UserName).ToUpper Then
                    result = True
                End If
            Next
        Else
            GeneralMessageBox("Error Missing File:" & Settings.Manager.AE.AEBundleContents.CombinePath(Settings.Manager.AE.ConfigurationTestersFileName), System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , , logName)
        End If

        Return result

    End Function

    Sub PopulateConfigurationDescription()

        ContentReportTextBox.Clear()

        Dim FileName As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Support", ConfigNameLabel.Text & ".TXT"))


        If System.IO.File.Exists(FileName) Then

            Dim aFileRead() As String = ReadTextFile(FileName)
            If aFileRead IsNot Nothing Then
                For iCtr As Integer = 0 To UBound(aFileRead)
                    If iCtr = 0 Then
                        ContentReportTextBox.Text = ContentReportTextBox.Text & aFileRead(iCtr)
                    Else
                        ContentReportTextBox.Text = ContentReportTextBox.Text & vbCrLf & aFileRead(iCtr)
                    End If
                Next
            End If

        Else

            ContentReportTextBox.Text = "Created by: " & Common.Settings.Manager.EvaluateExpression(Settings.Manager.UserName) & vbCrLf &
                                        "On: " & Date.Today.Day & "/" & Date.Today.Month & "/" & Date.Today.Year & vbCrLf &
                                        "Description: " & vbCrLf
            SaveContentsReport()

        End If

    End Sub

    Sub SaveContentsReport()

        Try

            Dim sConfigurationName As String = RuleAccessors.GetruleValue("FULLCONFIGNAME")

            Dim FileName As String = Settings.Manager.AutoCAD.WorkingFolder.CombinePath("TemplateBuildArea".CombinePath(GetruleValue("FULLCONFIGNAME"), "Settings", sConfigurationName & ".TXT"))

            If System.IO.File.Exists(FileName) Then
                System.IO.File.Delete(FileName)
            End If

            WriteLineToTextFile(FileName, ContentReportTextBox.Text, True)

            SaveReportButton.Enabled = False

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub RemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If MessageBox.Show("Excluding a Template will mean it's no longer visible for users to select." & vbCrLf &
                           "Are you sure you wish to do this ?" _
                           , "PTS Generated  Question in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

            MsgBox("Code to add to exclusion list - required here")

            If MessageBox.Show("Would you like to set this Template to be mapped to a new one?", "PTS Generated  Question in " & System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                MsgBox("Code to add a line to the mapping file - required here")
            End If
        Else
            MessageBox.Show("Operation aborted no action taken.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

    Private Sub SaveReportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveReportButton.Click

        SaveContentsReport()
        StampButton.Enabled = True

    End Sub

    Private Sub ContentReportTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContentReportTextBox.TextChanged

        SaveReportButton.Enabled = True
        StampButton.Enabled = False

    End Sub

    Private Sub StampButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StampButton.Click

        PopulateConfigurationDescription()
        ContentReportTextBox.Text = ContentReportTextBox.Text & vbCrLf & "Modified by: " & Common.Settings.Manager.EvaluateExpression(Settings.Manager.UserName) & vbCrLf &
                                        "On: " & Date.Today.Day & "/" & Date.Today.Month & "/" & Date.Today.Year & vbCrLf &
                                        "Description: " & vbCrLf
        SaveContentsReport()

    End Sub

    Private Sub RefreshReportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RefreshReportButton.Click
        PopulateConfigurationDescription()
    End Sub

    Private Sub frmTemplateBuilder_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub


    ''' <summary>
    ''' Creates the controls on the fly based on the rules so that Template builders can enter in the details
    ''' </summary>
    ''' <param name="strCleanTitle"></param>
    ''' <param name="toolindex"></param>
    ''' <remarks></remarks>
    Sub BuildConfigDialogBox(ByRef strCleanTitle As String, ByRef toolindex As Integer)

        Dim ToolRule As Jacobs.AutoCAD.Utilities.Rule
        Dim i As Integer
        Dim intTop As Integer
        Dim intLeft As Integer
        Dim intDescWidth As Integer
        Dim intDescHt As Integer
        Dim intDataWidth As Integer
        Dim intDataHt As Integer
        Dim intLineSpacer As Integer
        Dim intNextRule As Integer = 0
        Dim DataGridHeight As Integer = 1

        ' By this point we have the information that we need to build the dialog box.
        ' We have all the rules for the selected tool in the ToolDetails array -
        ' each rule will become a new control in the Config dialog box
        ' *2 Because one is for the field and the other for the label control
        Dim ConfigControls((UBound(ToolDetails(toolindex).Rules) * 2) + 2) As System.Windows.Forms.Control

        ' Setup some variable to control sizes of fields and positioning
        intTop = 13
        intLeft = 13

        intDescWidth = 500
        intDescHt = 20

        intDataWidth = 250
        intDataHt = 20

        intLineSpacer = 5

        '' Need to unlink 
        For Each ctrl As Control In Me.DefaultsFrame.Controls
            If ctrl.GetType.FullName.ToUpper.Contains("DataGridView".ToUpper) Then
                Dim x As DataGridView = ctrl
                x.DataSource = Nothing
            End If
        Next

        Me.DefaultsFrame.Controls.Clear()


        ' Based on the number of controls we have and the height of each control and the line spacing between them
        ' we can set the frame scroll height
        '     DefaultsFrame.AutoScrollMinSize.Height = (intDescHt + intLineSpacer) * UBound(ToolDetails(toolindex).Rules)

        ' WORK OUT WHAT IS NEEDED FOR THIS TOOL
        ' Find out how many rules the current tool has and iterate through them to populate the dialog box
        For i = 0 To CShort(UBound(ToolDetails(toolindex).Rules))

            ' DRAW AND POPULATE THE DIALOG BOX
            ' The CurrentRuleValues is what we need to work out what controls we need.
            ' Assume all rules are loaded since the add tool button would have initialized all the rules for that tool

            ToolRule = RuleAccessors.GetRule(Split(ToolDetails(toolindex).Rules(i), ",")(0))

            If ToolRule Is Nothing Then

                Acad_MessageBox("Rule not set properly", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

            End If

            Select Case ToolRule.DlgCode ' Check out what the DGL Code is for this Rule

                Case CShort("1") ' Drop down single select List Box

                    ' Build a drop down list box type control
                    Dim MyComboBox As New ComboBox

                    MyComboBox.Name = ToolRule.RuleID '& "ComboBox"
                    MyComboBox.Left = intLeft + intDescWidth + intLineSpacer
                    MyComboBox.Top = intTop
                    MyComboBox.Width = intDataWidth
                    MyComboBox.Height = intDataHt

                    ' Check out if we need to populate the list boxes with anything that we already have in the drawing
                    ' Such as line types, text styles, layers....
                    ' Populate them accordingly and set the value in the ini file or the one in the current rule if present to be the default one.
                    Select Case ToolRule.TableCode

                        Case WZ_LAYER_TABLE ' this is a layer table request so go get all the layers in the drawing and add the value we have to the list
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "CLAYER", , True)

                        Case WZ_TEXTSTYLE_TABLE ' This is a text style table request
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "TEXTSTYLE", , True)

                        Case WZ_JUSTIFICATIONS ' This is a text justification request
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "TEXTJUSTIFICATION", , True)

                        Case WZ_BLOCK_TABLE
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "BLOCK", , True)

                        Case WZ_DIMSTYLE_TABLE
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "DIMSTYLE", , True)

                        Case WZ_LINETYPE_TABLE
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "CELTYPE", , True)

                        Case WZ_COLOUR
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "CECOLOR", , True)

                        Case WZ_INSUNITS
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "INSUNITS", , True)

                        Case WZ_CUSTOM
                            PopulateComboBox(MyComboBox, ToolRule.RuleID, "AllAvailable", "UseFirstRule", "CUSTOM", ToolRule.value, True)

                    End Select

                    DefaultsFrame.Controls.Add(MyComboBox)
                    ConfigControls(intNextRule) = MyComboBox

                    ' Increment counter to add label
                    intNextRule = CShort(intNextRule + 1)

                    ' Create a label for the control
                    Dim MyLabel As New Label

                    MyLabel.Left = intLeft
                    MyLabel.Top = intTop
                    MyLabel.Width = intDescWidth
                    MyLabel.Height = intDescHt
                    MyLabel.Name = ToolRule.RuleID & "Label"
                    MyLabel.Text = ToolRule.Description & "(" & ToolRule.RuleID & ")"
                    MyLabel.TextAlign = CType(HorizontalAlignment.Right, ContentAlignment)

                    DefaultsFrame.Controls.Add(MyLabel)
                    ConfigControls(intNextRule) = MyLabel

                Case CShort("2") ' Single entry Text box to collect text strings or numbers (int/dbl)

                    ' Setup a text box
                    Dim MytextBox As New TextBox

                    MytextBox.Name = ToolRule.RuleID '& "TextBox"
                    MytextBox.Left = intLeft + intDescWidth + intLineSpacer
                    MytextBox.Top = intTop
                    MytextBox.Width = intDataWidth
                    MytextBox.Height = intDataHt
                    ' Set the value to the TOOLS.INI or current saved rule value
                    MytextBox.Text = ToolRule.value

                    DefaultsFrame.Controls.Add(MytextBox)
                    ConfigControls(intNextRule) = MytextBox

                    ' Increment counter to add label
                    intNextRule = CShort(intNextRule + 1)

                    ' Create a label for the control
                    Dim MyLabel As New Label

                    MyLabel.Left = intLeft
                    MyLabel.Top = intTop
                    MyLabel.Width = intDescWidth
                    MyLabel.Height = intDescHt
                    MyLabel.Name = ToolRule.RuleID & "Label"
                    MyLabel.Text = ToolRule.Description & "(" & ToolRule.RuleID & ")"
                    MyLabel.TextAlign = CType(HorizontalAlignment.Right, ContentAlignment)

                    DefaultsFrame.Controls.Add(MyLabel)
                    ConfigControls(intNextRule) = MyLabel

                Case CShort("3") ' Boolean tick box

                    ' setup a check box to be ticked or unticked - ticked = true, unticked = false
                    Dim MyCheckBox As New CheckBox
                    MyCheckBox.Name = ToolRule.RuleID ' & "CheckBox"

                    MyCheckBox.Checked = ToolRule.value.ToString.IsTrue

                    'If ToolRule.value = "1" Then
                    '    MyCheckBox.CheckState = CheckState.Checked
                    'Else
                    '    MyCheckBox.CheckState = CheckState.Unchecked
                    'End If

                    MyCheckBox.Left = intLeft + intDescWidth + intLineSpacer
                    MyCheckBox.Top = intTop
                    MyCheckBox.Width = 81               ' standard check box height
                    MyCheckBox.Height = 17              ' standard check box width

                    DefaultsFrame.Controls.Add(MyCheckBox)
                    ConfigControls(intNextRule) = MyCheckBox

                    ' Increment counter to add label
                    intNextRule = CShort(intNextRule + 1)

                    ' Create a label for the control
                    Dim MyLabel As New Label

                    MyLabel.Left = intLeft
                    MyLabel.Top = intTop
                    MyLabel.Width = intDescWidth
                    MyLabel.Height = intDescHt
                    MyLabel.Name = ToolRule.RuleID & "Label"
                    MyLabel.Text = ToolRule.Description & "(" & ToolRule.RuleID & ")"
                    MyLabel.TextAlign = CType(HorizontalAlignment.Right, ContentAlignment)

                    DefaultsFrame.Controls.Add(MyLabel)
                    ConfigControls(intNextRule) = MyLabel

                Case "4" ' Multiple Values text box - separated by a semicolon ; then <> then | 

                    ' These characters were selected as separators because they can't be used in the name of a style or layer.
                    ' ToolRule.RuleID      = ANNOTATION18
                    ' ToolRule.Description = Nominate Text Styles default layer and height|Style/8-Layer/6-Height/40
                    ' ToolRule.value       = Standard|TEXT_18|1.8;Standard|TEXT_25|2.5;Standard|TEXT_35|3.5;Standard|TEXT_50|5.0;Standard|TEXT_50|5.0
                    ' ToolRule.DlgCode     = 4
                    ' ToolRule.TableCode   = 41

                    MyDataGridView = New DataGridView
                    AddHandler MyDataGridView.DataError, AddressOf GridView_DataError

                    '' Data Grid View Control
                    MyDataGridView.Name = ToolRule.RuleID

                    Dim RuleDataSet As New DataSet
                    Dim DT As New System.Data.DataTable(ToolRule.RuleID)

                    '' Work out the column names and types from the Rule 
                    Dim DescriptionColumnSection As String = ToolRule.Description.Split("|"c)(1)

                    Dim k As Integer = 0
                    '' Work out the column headings and types 
                    For Each ColumnHeading As String In DescriptionColumnSection.Split("-")

                        Dim ColumnHeadingName = ColumnHeading.Split("/")(0)
                        Dim Type As String = ColumnHeading.Split("/")(1)
                        Dim ColumnValue As String = String.Empty

                        If ToolRule.value.Contains("|") And ToolRule.value.Contains(";") Then
                            ColumnValue = ToolRule.value.Split(";")(k).Split("|")(1)
                        Else
                            If ToolRule.value.Contains(";") Then
                                ColumnValue = ToolRule.value.Split(";")(k)
                            Else
                                ColumnValue = ToolRule.value
                            End If
                        End If

                        '' Check if this is not a combo box type
                        If Type = "40" Or Type = "41" Or Type = "42" Or Type = "62" Or Type = "18" Then
                            '' It's not add a Text Box to the data grid view
                            Dim x As New DataGridViewTextBoxColumn
                            x.DataPropertyName = ColumnHeadingName
                            x.Name = ColumnHeadingName
                            MyDataGridView.Columns.Add(x)

                        Else
                            '' Add the populated Combo Box to the data grid view
                            Dim x As New DataGridViewComboBoxColumn
                            x.DataPropertyName = ColumnHeadingName
                            x.DataSource = Jacobs.AutoCAD.Utilities.PopulateColumnTableCode(Type, ColumnValue)
                            x.ValueMember = "X"
                            x.DisplayMember = "X"
                            x.Name = ColumnHeadingName
                            x.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                            MyDataGridView.Columns.Add(x)

                        End If

                        '' Add the column to the data table
                        DT.Columns.Add(ColumnHeadingName, GetType(String))
                        k = k + 1
                    Next
                    DT.AcceptChanges()

                    '' Populate the data table with the rule values
                    For Each RuleValues As String In ToolRule.value.Split(";")

                        Dim j As Integer = 0
                        Dim DatRow As DataRow = DT.NewRow
                        Dim ColumnValue As String

                        '' Populate the row
                        For Each ColumnValue In RuleValues.Split("|")

                            Dim ColumnName As String = DescriptionColumnSection.Split("-")(j).Split("/")(0)
                            Dim Type As String = DescriptionColumnSection.Split("-")(j).Split("/")(1)

                            If Type = "40" Or Type = "41" Or Type = "42" Or Type = "62" Or Type = "18" Then
                                '' These are simple text or numerical entries
                                DatRow.Item(ColumnName) = ColumnValue

                            Else

                                '' This is a combo box
                                '' Need to check to see that ColumnValue exists in the list of pre-populated items...
                                '                               If DT.Rows.Count > 0 Then

                                Dim DgvCbc As DataGridViewComboBoxColumn = MyDataGridView.Columns.Item(ColumnName)
                                If Not DgvCbc.DataSource Is Nothing Then
                                    Dim hh As System.Data.DataTable = DgvCbc.DataSource

                                    Dim x = hh.AsEnumerable().Any(Function(row) ColumnValue = row.Field(Of [String])(0))

                                    If x = True Then
                                        '' The default value we are sending exists the set it to default value
                                        DatRow.Item(ColumnName) = ColumnValue
                                    Else
                                        '' The default value is not present hence set the first item in combo box to be default
                                        DatRow.Item(ColumnName) = hh.Rows.Item(0).Item(0).ToString
                                    End If

                                End If

                            End If
                            j = j + 1
                        Next

                        '' Add the row to the Table
                        DT.Rows.Add(DatRow)
                        DT.AcceptChanges()

                    Next

                    '' Now Add the data table to the data set
                    If RuleDataSet.Tables.Contains(ToolRule.RuleID) Then
                        RuleDataSet.Tables.Remove(ToolRule.RuleID)
                        RuleDataSet.AcceptChanges()
                    End If
                    RuleDataSet.Tables.Add(DT)
                    RuleDataSet.AcceptChanges()

                    '' Now link and add the data set to the data view control
                    MyDataGridView.DataSource = RuleDataSet
                    MyDataGridView.DataMember = RuleDataSet.Tables(ToolRule.RuleID).TableName

                    MyDataGridView.Left = intLeft + intDescWidth + intLineSpacer
                    MyDataGridView.Top = intTop
                    MyDataGridView.Width = intDataWidth * 2
                    intDataHt = 200
                    MyDataGridView.Height = intDataHt
                    MyDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
                    MyDataGridView.AutoGenerateColumns = False

                    DefaultsFrame.Controls.Add(MyDataGridView)
                    ConfigControls(intNextRule) = MyDataGridView

                    ' Increment counter to add label
                    intNextRule = CShort(intNextRule + 1)

                    ' Create a label for the control
                    Dim MyLabel As New Label

                    MyLabel.Left = intLeft
                    MyLabel.Top = intTop
                    MyLabel.Width = intDescWidth
                    MyLabel.Height = intDescHt
                    MyLabel.Name = ToolRule.RuleID & "Label"
                    MyLabel.Text = ToolRule.Description.Split("|")(0) & "(" & ToolRule.RuleID & ")"
                    MyLabel.TextAlign = CType(HorizontalAlignment.Right, ContentAlignment)

                    DefaultsFrame.Controls.Add(MyLabel)
                    ConfigControls(intNextRule) = MyLabel

                    '' Adds the Data Table to the collection in case there are more than one
                    DataTablesCollection.Add(DT)
                    DataGridViewControlsCollection.Add(MyDataGridView)

            End Select

            ' Increment the line spacing so they don't end up on to of each other
            intTop = intTop + intDataHt + intLineSpacer
            intDataHt = 20
            intNextRule = CShort(intNextRule + 1)

        Next

        ' Need to reset saved values?

    End Sub

    Private Sub GridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs)

        Dim view As DataGridView = CType(sender, DataGridView)

        If view.Columns(e.ColumnIndex).GetType = GetType(DataGridViewComboBoxColumn) Then
            MsgBox(e.Exception.Message & " With this value: " & view.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString)
        End If

        e.ThrowException = False

    End Sub

    ''' <summary>
    ''' For DataGridView Controls
    ''' This matches up the control in the form with the Table in the collection to work out the selected values for the rule
    ''' it formats the values and returns the formatted string
    ''' </summary>
    ''' <param name="cntrlname"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFormattedRuleValueFromGridView(cntrlname As String) As String

        Dim FormattedValue As String = String.Empty

        Try
            For Each Table As System.Data.DataTable In DataTablesCollection
                If Table.TableName = cntrlname Then

                    Table.AcceptChanges()

                    For Each Row As System.Data.DataRow In Table.Rows
                        For Each col As String In Row.ItemArray
                            FormattedValue = FormattedValue & col & "|"
                        Next
                        FormattedValue = FormattedValue.Remove(FormattedValue.Length - 1, 1)
                        FormattedValue = FormattedValue & ";"
                    Next
                End If
            Next

            If FormattedValue.Length > 2 Then
                FormattedValue = FormattedValue.Remove(FormattedValue.Length - 1, 1)
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return FormattedValue

    End Function


End Class

