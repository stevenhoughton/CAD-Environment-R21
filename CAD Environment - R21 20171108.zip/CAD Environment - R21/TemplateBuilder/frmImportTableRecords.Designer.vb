'<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmImportTableRecords
'#Region "Windows Form Designer generated code "
'	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
'		MyBase.New()
'		'This call is required by the Windows Form Designer.
'		InitializeComponent()
'	End Sub
'	'Form overrides dispose to clean up the component list.
'	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
'		If Disposing Then
'			If Not components Is Nothing Then
'				components.Dispose()
'			End If
'		End If
'		MyBase.Dispose(Disposing)
'	End Sub
'	'Required by the Windows Form Designer
'	Private components As System.ComponentModel.IContainer
'	Public ToolTip1 As System.Windows.Forms.ToolTip
'	Public WithEvents cmdOk As System.Windows.Forms.Button
'	Public WithEvents cmdCancel As System.Windows.Forms.Button
'	Public WithEvents lbRecords As System.Windows.Forms.ListBox
'	Public WithEvents fraImport As System.Windows.Forms.GroupBox
'	'NOTE: The following procedure is required by the Windows Form Designer
'	'It can be modified using the Windows Form Designer.
'	'Do not modify it using the code editor.
'	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
'		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmImportTableRecords))
'		Me.components = New System.ComponentModel.Container()
'		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
'		Me.cmdOk = New System.Windows.Forms.Button
'		Me.cmdCancel = New System.Windows.Forms.Button
'		Me.fraImport = New System.Windows.Forms.GroupBox
'		Me.lbRecords = New System.Windows.Forms.ListBox
'		Me.fraImport.SuspendLayout()
'		Me.SuspendLayout()
'		Me.ToolTip1.Active = True
'		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
'		Me.ClientSize = New System.Drawing.Size(201, 210)
'		Me.Location = New System.Drawing.Point(3, 15)
'		Me.MaximizeBox = False
'		Me.MinimizeBox = False
'		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
'		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
'		Me.BackColor = System.Drawing.SystemColors.Control
'		Me.ControlBox = True
'		Me.Enabled = True
'		Me.KeyPreview = False
'		Me.Cursor = System.Windows.Forms.Cursors.Default
'		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
'		Me.ShowInTaskbar = True
'		Me.HelpButton = False
'		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
'		Me.Name = "frmImportTableRecords"
'		Me.cmdOk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'		Me.cmdOk.Text = "OK"
'		Me.cmdOk.Enabled = False
'		Me.cmdOk.Size = New System.Drawing.Size(80, 27)
'		Me.cmdOk.Location = New System.Drawing.Point(16, 176)
'		Me.cmdOk.TabIndex = 0
'		Me.cmdOk.BackColor = System.Drawing.SystemColors.Control
'		Me.cmdOk.CausesValidation = True
'		Me.cmdOk.ForeColor = System.Drawing.SystemColors.ControlText
'		Me.cmdOk.Cursor = System.Windows.Forms.Cursors.Default
'		Me.cmdOk.RightToLeft = System.Windows.Forms.RightToLeft.No
'		Me.cmdOk.TabStop = True
'		Me.cmdOk.Name = "cmdOk"
'		Me.cmdCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'		Me.CancelButton = Me.cmdCancel
'		Me.cmdCancel.Text = "&Cancel"
'		Me.cmdCancel.Size = New System.Drawing.Size(80, 27)
'		Me.cmdCancel.Location = New System.Drawing.Point(104, 176)
'		Me.cmdCancel.TabIndex = 1
'		Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
'		Me.cmdCancel.CausesValidation = True
'		Me.cmdCancel.Enabled = True
'		Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
'		Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
'		Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
'		Me.cmdCancel.TabStop = True
'		Me.cmdCancel.Name = "cmdCancel"
'		Me.fraImport.Text = "Import Records"
'		Me.fraImport.Size = New System.Drawing.Size(184, 160)
'		Me.fraImport.Location = New System.Drawing.Point(8, 8)
'		Me.fraImport.TabIndex = 2
'		Me.fraImport.BackColor = System.Drawing.SystemColors.Control
'		Me.fraImport.Enabled = True
'		Me.fraImport.ForeColor = System.Drawing.SystemColors.ControlText
'		Me.fraImport.RightToLeft = System.Windows.Forms.RightToLeft.No
'		Me.fraImport.Visible = True
'		Me.fraImport.Name = "fraImport"
'		Me.lbRecords.Size = New System.Drawing.Size(164, 137)
'		Me.lbRecords.Location = New System.Drawing.Point(10, 16)
'		Me.lbRecords.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
'		Me.lbRecords.TabIndex = 0
'		Me.lbRecords.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
'		Me.lbRecords.BackColor = System.Drawing.SystemColors.Window
'		Me.lbRecords.CausesValidation = True
'		Me.lbRecords.Enabled = True
'		Me.lbRecords.ForeColor = System.Drawing.SystemColors.WindowText
'		Me.lbRecords.IntegralHeight = True
'		Me.lbRecords.Cursor = System.Windows.Forms.Cursors.Default
'		Me.lbRecords.RightToLeft = System.Windows.Forms.RightToLeft.No
'		Me.lbRecords.Sorted = False
'		Me.lbRecords.TabStop = True
'		Me.lbRecords.Visible = True
'		Me.lbRecords.MultiColumn = False
'		Me.lbRecords.Name = "lbRecords"
'		Me.Controls.Add(cmdOk)
'		Me.Controls.Add(cmdCancel)
'		Me.Controls.Add(fraImport)
'		Me.fraImport.Controls.Add(lbRecords)
'		Me.fraImport.ResumeLayout(False)
'		Me.ResumeLayout(False)
'		Me.PerformLayout()
'	End Sub
'#End Region 
'End Class