<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmTitleBlockInsert
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Help_Button As System.Windows.Forms.Button
	Public WithEvents OK_Button As System.Windows.Forms.Button
	Public WithEvents Cancel_Button As System.Windows.Forms.Button
	Public WithEvents SamplePlotStamp As System.Windows.Forms.TextBox
    Public WithEvents LayoutFrame As System.Windows.Forms.GroupBox
	Public WithEvents Stylecmb As System.Windows.Forms.ComboBox
	Public WithEvents Stylelbl As System.Windows.Forms.Label
	Public WithEvents Sizecmb As System.Windows.Forms.ComboBox
	Public WithEvents Sizelbl As System.Windows.Forms.Label
	Public WithEvents LayoutCmb As System.Windows.Forms.ComboBox
	Public WithEvents Layoutlbl As System.Windows.Forms.Label
	Public WithEvents Logocmb As System.Windows.Forms.ComboBox
	Public WithEvents Logolbl As System.Windows.Forms.Label
	Public WithEvents FrameTypeCmb As System.Windows.Forms.ComboBox
	Public WithEvents FrameTypeLbl As System.Windows.Forms.Label
	Public WithEvents Sheetfrm As System.Windows.Forms.GroupBox
    Public WithEvents InsertClientSheet As System.Windows.Forms.Button
    Public WithEvents SaveDefaultsMach As System.Windows.Forms.CheckBox
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents lblTitle As System.Windows.Forms.Label
    Public WithEvents RegionCmbx As System.Windows.Forms.ComboBox
    Public WithEvents Regionlbl As System.Windows.Forms.Label
    Public WithEvents Officelbl As System.Windows.Forms.Label
    Public WithEvents RegionCmb As System.Windows.Forms.ComboBox
    Public WithEvents OfficeCmb As System.Windows.Forms.ComboBox
    Public WithEvents Addressfrm As System.Windows.Forms.GroupBox
    Public WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents TBI1Lst As System.Windows.Forms.ComboBox
    Public WithEvents TBI2Lst As System.Windows.Forms.ComboBox
    Public WithEvents Label13 As System.Windows.Forms.Label
    Public WithEvents DefaultInsertOnPSLabel As System.Windows.Forms.Label
    Public WithEvents TBI3Tick As System.Windows.Forms.CheckBox
    Public WithEvents SelectInsertionPointCheckBox As System.Windows.Forms.CheckBox
    Public WithEvents SpaceFrame As System.Windows.Forms.GroupBox
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTitleBlockInsert))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SamplePlotStamp = New System.Windows.Forms.TextBox()
        Me.Stylecmb = New System.Windows.Forms.ComboBox()
        Me.Sizecmb = New System.Windows.Forms.ComboBox()
        Me.LayoutCmb = New System.Windows.Forms.ComboBox()
        Me.Logocmb = New System.Windows.Forms.ComboBox()
        Me.FrameTypeCmb = New System.Windows.Forms.ComboBox()
        Me.RegionCmbx = New System.Windows.Forms.ComboBox()
        Me.RegionCmb = New System.Windows.Forms.ComboBox()
        Me.OfficeCmb = New System.Windows.Forms.ComboBox()
        Me.SelectInsertionPointCheckBox = New System.Windows.Forms.CheckBox()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.LayoutFrame = New System.Windows.Forms.GroupBox()
        Me.MultipleLayoutOptionButton = New System.Windows.Forms.RadioButton()
        Me.SingleLayoutOptionButton = New System.Windows.Forms.RadioButton()
        Me.Sheetfrm = New System.Windows.Forms.GroupBox()
        Me.Stylelbl = New System.Windows.Forms.Label()
        Me.Sizelbl = New System.Windows.Forms.Label()
        Me.Layoutlbl = New System.Windows.Forms.Label()
        Me.Logolbl = New System.Windows.Forms.Label()
        Me.FrameTypeLbl = New System.Windows.Forms.Label()
        Me.InsertClientSheet = New System.Windows.Forms.Button()
        Me.SaveDefaultsMach = New System.Windows.Forms.CheckBox()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Addressfrm = New System.Windows.Forms.GroupBox()
        Me.Regionlbl = New System.Windows.Forms.Label()
        Me.Officelbl = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TBI1Lst = New System.Windows.Forms.ComboBox()
        Me.TBI2Lst = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.DefaultInsertOnPSLabel = New System.Windows.Forms.Label()
        Me.TBI3Tick = New System.Windows.Forms.CheckBox()
        Me.SpaceFrame = New System.Windows.Forms.GroupBox()
        Me.Paperspace = New System.Windows.Forms.RadioButton()
        Me.Modelspace = New System.Windows.Forms.RadioButton()
        Me.ToolSettingsGroupBox = New System.Windows.Forms.GroupBox()
        Me.OverrideTemplateSettingsRadioButton = New System.Windows.Forms.RadioButton()
        Me.UseTemplateSettingsRadioButton = New System.Windows.Forms.RadioButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.LayoutFrame.SuspendLayout()
        Me.Sheetfrm.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Addressfrm.SuspendLayout()
        Me.SpaceFrame.SuspendLayout()
        Me.ToolSettingsGroupBox.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SamplePlotStamp
        '
        Me.SamplePlotStamp.AcceptsReturn = True
        Me.SamplePlotStamp.BackColor = System.Drawing.SystemColors.Control
        Me.SamplePlotStamp.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SamplePlotStamp.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SamplePlotStamp.Location = New System.Drawing.Point(125, 328)
        Me.SamplePlotStamp.MaxLength = 0
        Me.SamplePlotStamp.Name = "SamplePlotStamp"
        Me.SamplePlotStamp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SamplePlotStamp.Size = New System.Drawing.Size(341, 20)
        Me.SamplePlotStamp.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.SamplePlotStamp, "Sample plot stamp.")
        '
        'Stylecmb
        '
        Me.Stylecmb.BackColor = System.Drawing.SystemColors.Window
        Me.Stylecmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.Stylecmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Stylecmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Stylecmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Stylecmb.Location = New System.Drawing.Point(114, 54)
        Me.Stylecmb.Name = "Stylecmb"
        Me.Stylecmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Stylecmb.Size = New System.Drawing.Size(224, 21)
        Me.Stylecmb.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.Stylecmb, "Select style type")
        '
        'Sizecmb
        '
        Me.Sizecmb.BackColor = System.Drawing.SystemColors.Window
        Me.Sizecmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.Sizecmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Sizecmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sizecmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Sizecmb.Location = New System.Drawing.Point(114, 91)
        Me.Sizecmb.Name = "Sizecmb"
        Me.Sizecmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Sizecmb.Size = New System.Drawing.Size(224, 21)
        Me.Sizecmb.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.Sizecmb, "Select paper size")
        '
        'LayoutCmb
        '
        Me.LayoutCmb.BackColor = System.Drawing.SystemColors.Window
        Me.LayoutCmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.LayoutCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LayoutCmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LayoutCmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LayoutCmb.Location = New System.Drawing.Point(114, 128)
        Me.LayoutCmb.Name = "LayoutCmb"
        Me.LayoutCmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LayoutCmb.Size = New System.Drawing.Size(224, 21)
        Me.LayoutCmb.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.LayoutCmb, "Select paper oreintation")
        '
        'Logocmb
        '
        Me.Logocmb.BackColor = System.Drawing.SystemColors.Window
        Me.Logocmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.Logocmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Logocmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Logocmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Logocmb.Location = New System.Drawing.Point(114, 166)
        Me.Logocmb.Name = "Logocmb"
        Me.Logocmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Logocmb.Size = New System.Drawing.Size(224, 21)
        Me.Logocmb.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.Logocmb, "Select logo type")
        '
        'FrameTypeCmb
        '
        Me.FrameTypeCmb.BackColor = System.Drawing.SystemColors.Window
        Me.FrameTypeCmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.FrameTypeCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FrameTypeCmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FrameTypeCmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.FrameTypeCmb.Location = New System.Drawing.Point(114, 16)
        Me.FrameTypeCmb.Name = "FrameTypeCmb"
        Me.FrameTypeCmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameTypeCmb.Size = New System.Drawing.Size(224, 21)
        Me.FrameTypeCmb.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.FrameTypeCmb, "Select frame type")
        '
        'RegionCmbx
        '
        Me.RegionCmbx.BackColor = System.Drawing.SystemColors.Window
        Me.RegionCmbx.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionCmbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RegionCmbx.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionCmbx.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RegionCmbx.Location = New System.Drawing.Point(133, 152)
        Me.RegionCmbx.Name = "RegionCmbx"
        Me.RegionCmbx.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionCmbx.Size = New System.Drawing.Size(144, 21)
        Me.RegionCmbx.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.RegionCmbx, "Select regional office")
        '
        'RegionCmb
        '
        Me.RegionCmb.BackColor = System.Drawing.SystemColors.Window
        Me.RegionCmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RegionCmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionCmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RegionCmb.Location = New System.Drawing.Point(85, 19)
        Me.RegionCmb.Name = "RegionCmb"
        Me.RegionCmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionCmb.Size = New System.Drawing.Size(144, 21)
        Me.RegionCmb.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.RegionCmb, "Select logo type")
        '
        'OfficeCmb
        '
        Me.OfficeCmb.BackColor = System.Drawing.SystemColors.Window
        Me.OfficeCmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.OfficeCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OfficeCmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OfficeCmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OfficeCmb.Location = New System.Drawing.Point(283, 19)
        Me.OfficeCmb.Name = "OfficeCmb"
        Me.OfficeCmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OfficeCmb.Size = New System.Drawing.Size(160, 21)
        Me.OfficeCmb.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.OfficeCmb, "Select logo type")
        '
        'SelectInsertionPointCheckBox
        '
        Me.SelectInsertionPointCheckBox.BackColor = System.Drawing.SystemColors.Control
        Me.SelectInsertionPointCheckBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectInsertionPointCheckBox.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SelectInsertionPointCheckBox.Location = New System.Drawing.Point(102, 17)
        Me.SelectInsertionPointCheckBox.Name = "SelectInsertionPointCheckBox"
        Me.SelectInsertionPointCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectInsertionPointCheckBox.Size = New System.Drawing.Size(123, 22)
        Me.SelectInsertionPointCheckBox.TabIndex = 2
        Me.SelectInsertionPointCheckBox.Text = "Pick Insertion Point"
        Me.ToolTip1.SetToolTip(Me.SelectInsertionPointCheckBox, "When checked user can select block insertion point in model space")
        Me.SelectInsertionPointCheckBox.UseVisualStyleBackColor = False
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(8, 5)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(64, 26)
        Me.Help_Button.TabIndex = 11
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.BackColor = System.Drawing.SystemColors.Control
        Me.OK_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.OK_Button.Enabled = False
        Me.OK_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OK_Button.Location = New System.Drawing.Point(88, 5)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OK_Button.Size = New System.Drawing.Size(64, 26)
        Me.OK_Button.TabIndex = 9
        Me.OK_Button.Text = "OK"
        Me.OK_Button.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(168, 5)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(64, 26)
        Me.Cancel_Button.TabIndex = 10
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'LayoutFrame
        '
        Me.LayoutFrame.BackColor = System.Drawing.SystemColors.Control
        Me.LayoutFrame.Controls.Add(Me.MultipleLayoutOptionButton)
        Me.LayoutFrame.Controls.Add(Me.SingleLayoutOptionButton)
        Me.LayoutFrame.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LayoutFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LayoutFrame.Location = New System.Drawing.Point(34, 299)
        Me.LayoutFrame.Name = "LayoutFrame"
        Me.LayoutFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LayoutFrame.Size = New System.Drawing.Size(224, 64)
        Me.LayoutFrame.TabIndex = 3
        Me.LayoutFrame.TabStop = False
        Me.LayoutFrame.Text = "Layout Style"
        '
        'MultipleLayoutOptionButton
        '
        Me.MultipleLayoutOptionButton.AutoSize = True
        Me.MultipleLayoutOptionButton.Location = New System.Drawing.Point(10, 40)
        Me.MultipleLayoutOptionButton.Name = "MultipleLayoutOptionButton"
        Me.MultipleLayoutOptionButton.Size = New System.Drawing.Size(113, 17)
        Me.MultipleLayoutOptionButton.TabIndex = 4
        Me.MultipleLayoutOptionButton.TabStop = True
        Me.MultipleLayoutOptionButton.Text = "Multiple Titleblocks"
        Me.MultipleLayoutOptionButton.UseVisualStyleBackColor = True
        '
        'SingleLayoutOptionButton
        '
        Me.SingleLayoutOptionButton.AutoSize = True
        Me.SingleLayoutOptionButton.Location = New System.Drawing.Point(10, 16)
        Me.SingleLayoutOptionButton.Name = "SingleLayoutOptionButton"
        Me.SingleLayoutOptionButton.Size = New System.Drawing.Size(206, 17)
        Me.SingleLayoutOptionButton.TabIndex = 3
        Me.SingleLayoutOptionButton.TabStop = True
        Me.SingleLayoutOptionButton.Text = "Single Titleblock for Project Wise Sync"
        Me.SingleLayoutOptionButton.UseVisualStyleBackColor = True
        '
        'Sheetfrm
        '
        Me.Sheetfrm.BackColor = System.Drawing.SystemColors.Control
        Me.Sheetfrm.Controls.Add(Me.Stylecmb)
        Me.Sheetfrm.Controls.Add(Me.Stylelbl)
        Me.Sheetfrm.Controls.Add(Me.Sizecmb)
        Me.Sheetfrm.Controls.Add(Me.Sizelbl)
        Me.Sheetfrm.Controls.Add(Me.LayoutCmb)
        Me.Sheetfrm.Controls.Add(Me.Layoutlbl)
        Me.Sheetfrm.Controls.Add(Me.Logocmb)
        Me.Sheetfrm.Controls.Add(Me.Logolbl)
        Me.Sheetfrm.Controls.Add(Me.FrameTypeCmb)
        Me.Sheetfrm.Controls.Add(Me.FrameTypeLbl)
        Me.Sheetfrm.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sheetfrm.Location = New System.Drawing.Point(35, 37)
        Me.Sheetfrm.Name = "Sheetfrm"
        Me.Sheetfrm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Sheetfrm.Size = New System.Drawing.Size(462, 197)
        Me.Sheetfrm.TabIndex = 0
        Me.Sheetfrm.TabStop = False
        Me.Sheetfrm.Text = "Sheet"
        '
        'Stylelbl
        '
        Me.Stylelbl.AutoSize = True
        Me.Stylelbl.BackColor = System.Drawing.SystemColors.Control
        Me.Stylelbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Stylelbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Stylelbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Stylelbl.Location = New System.Drawing.Point(10, 58)
        Me.Stylelbl.Name = "Stylelbl"
        Me.Stylelbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Stylelbl.Size = New System.Drawing.Size(31, 13)
        Me.Stylelbl.TabIndex = 5
        Me.Stylelbl.Text = "Style"
        '
        'Sizelbl
        '
        Me.Sizelbl.AutoSize = True
        Me.Sizelbl.BackColor = System.Drawing.SystemColors.Control
        Me.Sizelbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Sizelbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sizelbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sizelbl.Location = New System.Drawing.Point(10, 95)
        Me.Sizelbl.Name = "Sizelbl"
        Me.Sizelbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Sizelbl.Size = New System.Drawing.Size(26, 13)
        Me.Sizelbl.TabIndex = 4
        Me.Sizelbl.Text = "Size"
        '
        'Layoutlbl
        '
        Me.Layoutlbl.AutoSize = True
        Me.Layoutlbl.BackColor = System.Drawing.SystemColors.Control
        Me.Layoutlbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Layoutlbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Layoutlbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Layoutlbl.Location = New System.Drawing.Point(10, 132)
        Me.Layoutlbl.Name = "Layoutlbl"
        Me.Layoutlbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Layoutlbl.Size = New System.Drawing.Size(40, 13)
        Me.Layoutlbl.TabIndex = 6
        Me.Layoutlbl.Text = "Layout"
        '
        'Logolbl
        '
        Me.Logolbl.AutoSize = True
        Me.Logolbl.BackColor = System.Drawing.SystemColors.Control
        Me.Logolbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Logolbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Logolbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Logolbl.Location = New System.Drawing.Point(10, 168)
        Me.Logolbl.Name = "Logolbl"
        Me.Logolbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Logolbl.Size = New System.Drawing.Size(30, 13)
        Me.Logolbl.TabIndex = 7
        Me.Logolbl.Text = "Logo"
        '
        'FrameTypeLbl
        '
        Me.FrameTypeLbl.AutoSize = True
        Me.FrameTypeLbl.BackColor = System.Drawing.SystemColors.Control
        Me.FrameTypeLbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.FrameTypeLbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FrameTypeLbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FrameTypeLbl.Location = New System.Drawing.Point(10, 22)
        Me.FrameTypeLbl.Name = "FrameTypeLbl"
        Me.FrameTypeLbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.FrameTypeLbl.Size = New System.Drawing.Size(62, 13)
        Me.FrameTypeLbl.TabIndex = 8
        Me.FrameTypeLbl.Text = "Frame type"
        '
        'InsertClientSheet
        '
        Me.InsertClientSheet.BackColor = System.Drawing.SystemColors.Control
        Me.InsertClientSheet.Cursor = System.Windows.Forms.Cursors.Default
        Me.InsertClientSheet.ForeColor = System.Drawing.SystemColors.ControlText
        Me.InsertClientSheet.Location = New System.Drawing.Point(34, 6)
        Me.InsertClientSheet.Name = "InsertClientSheet"
        Me.InsertClientSheet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.InsertClientSheet.Size = New System.Drawing.Size(462, 24)
        Me.InsertClientSheet.TabIndex = 4
        Me.InsertClientSheet.Text = "Insert Client Sheet"
        Me.InsertClientSheet.UseVisualStyleBackColor = False
        '
        'SaveDefaultsMach
        '
        Me.SaveDefaultsMach.BackColor = System.Drawing.SystemColors.Control
        Me.SaveDefaultsMach.Cursor = System.Windows.Forms.Cursors.Default
        Me.SaveDefaultsMach.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SaveDefaultsMach.Location = New System.Drawing.Point(133, 276)
        Me.SaveDefaultsMach.Name = "SaveDefaultsMach"
        Me.SaveDefaultsMach.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SaveDefaultsMach.Size = New System.Drawing.Size(259, 27)
        Me.SaveDefaultsMach.TabIndex = 6
        Me.SaveDefaultsMach.Text = "Save Settings in DWG for Next Session"
        Me.SaveDefaultsMach.UseVisualStyleBackColor = False
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(100, 44)
        Me.LogoPictureBox.TabIndex = 13
        Me.LogoPictureBox.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.Window
        Me.lblTitle.Location = New System.Drawing.Point(107, 10)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(210, 27)
        Me.lblTitle.TabIndex = 5
        Me.lblTitle.Text = "Title Block Inserter"
        '
        'Addressfrm
        '
        Me.Addressfrm.BackColor = System.Drawing.SystemColors.Control
        Me.Addressfrm.Controls.Add(Me.RegionCmbx)
        Me.Addressfrm.Controls.Add(Me.Regionlbl)
        Me.Addressfrm.Controls.Add(Me.Officelbl)
        Me.Addressfrm.Controls.Add(Me.RegionCmb)
        Me.Addressfrm.Controls.Add(Me.OfficeCmb)
        Me.Addressfrm.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Addressfrm.Location = New System.Drawing.Point(34, 235)
        Me.Addressfrm.Name = "Addressfrm"
        Me.Addressfrm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Addressfrm.Size = New System.Drawing.Size(462, 56)
        Me.Addressfrm.TabIndex = 1
        Me.Addressfrm.TabStop = False
        Me.Addressfrm.Text = "Address"
        '
        'Regionlbl
        '
        Me.Regionlbl.BackColor = System.Drawing.SystemColors.Control
        Me.Regionlbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Regionlbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Regionlbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Regionlbl.Location = New System.Drawing.Point(26, 25)
        Me.Regionlbl.Name = "Regionlbl"
        Me.Regionlbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Regionlbl.Size = New System.Drawing.Size(53, 13)
        Me.Regionlbl.TabIndex = 0
        Me.Regionlbl.Text = "Region"
        Me.Regionlbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Officelbl
        '
        Me.Officelbl.BackColor = System.Drawing.SystemColors.Control
        Me.Officelbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Officelbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Officelbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Officelbl.Location = New System.Drawing.Point(234, 25)
        Me.Officelbl.Name = "Officelbl"
        Me.Officelbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Officelbl.Size = New System.Drawing.Size(43, 13)
        Me.Officelbl.TabIndex = 1
        Me.Officelbl.Text = "Office"
        Me.Officelbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label11.Location = New System.Drawing.Point(68, 30)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(114, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Titleblock && Logo layer"
        '
        'TBI1Lst
        '
        Me.TBI1Lst.BackColor = System.Drawing.SystemColors.Window
        Me.TBI1Lst.Cursor = System.Windows.Forms.Cursors.Default
        Me.TBI1Lst.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TBI1Lst.Location = New System.Drawing.Point(185, 25)
        Me.TBI1Lst.Name = "TBI1Lst"
        Me.TBI1Lst.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TBI1Lst.Size = New System.Drawing.Size(207, 21)
        Me.TBI1Lst.TabIndex = 1
        '
        'TBI2Lst
        '
        Me.TBI2Lst.BackColor = System.Drawing.SystemColors.Window
        Me.TBI2Lst.Cursor = System.Windows.Forms.Cursors.Default
        Me.TBI2Lst.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TBI2Lst.Location = New System.Drawing.Point(185, 53)
        Me.TBI2Lst.Name = "TBI2Lst"
        Me.TBI2Lst.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TBI2Lst.Size = New System.Drawing.Size(207, 21)
        Me.TBI2Lst.TabIndex = 2
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.MenuText
        Me.Label13.Location = New System.Drawing.Point(100, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(82, 13)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "Attributes layer"
        '
        'DefaultInsertOnPSLabel
        '
        Me.DefaultInsertOnPSLabel.BackColor = System.Drawing.SystemColors.Control
        Me.DefaultInsertOnPSLabel.Cursor = System.Windows.Forms.Cursors.Default
        Me.DefaultInsertOnPSLabel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DefaultInsertOnPSLabel.ForeColor = System.Drawing.SystemColors.MenuText
        Me.DefaultInsertOnPSLabel.Location = New System.Drawing.Point(67, 83)
        Me.DefaultInsertOnPSLabel.Name = "DefaultInsertOnPSLabel"
        Me.DefaultInsertOnPSLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DefaultInsertOnPSLabel.Size = New System.Drawing.Size(109, 13)
        Me.DefaultInsertOnPSLabel.TabIndex = 4
        Me.DefaultInsertOnPSLabel.Text = "Default to insert on PS"
        '
        'TBI3Tick
        '
        Me.TBI3Tick.BackColor = System.Drawing.SystemColors.Control
        Me.TBI3Tick.Cursor = System.Windows.Forms.Cursors.Default
        Me.TBI3Tick.ForeColor = System.Drawing.SystemColors.MenuText
        Me.TBI3Tick.Location = New System.Drawing.Point(186, 82)
        Me.TBI3Tick.Name = "TBI3Tick"
        Me.TBI3Tick.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TBI3Tick.Size = New System.Drawing.Size(21, 21)
        Me.TBI3Tick.TabIndex = 5
        Me.TBI3Tick.Text = "CheckBox1"
        Me.TBI3Tick.UseVisualStyleBackColor = False
        '
        'SpaceFrame
        '
        Me.SpaceFrame.BackColor = System.Drawing.SystemColors.Control
        Me.SpaceFrame.Controls.Add(Me.Paperspace)
        Me.SpaceFrame.Controls.Add(Me.Modelspace)
        Me.SpaceFrame.Controls.Add(Me.SelectInsertionPointCheckBox)
        Me.SpaceFrame.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SpaceFrame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SpaceFrame.Location = New System.Drawing.Point(272, 299)
        Me.SpaceFrame.Name = "SpaceFrame"
        Me.SpaceFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SpaceFrame.Size = New System.Drawing.Size(224, 64)
        Me.SpaceFrame.TabIndex = 22
        Me.SpaceFrame.TabStop = False
        Me.SpaceFrame.Text = "Select Space"
        '
        'Paperspace
        '
        Me.Paperspace.AutoSize = True
        Me.Paperspace.Location = New System.Drawing.Point(10, 39)
        Me.Paperspace.Name = "Paperspace"
        Me.Paperspace.Size = New System.Drawing.Size(85, 17)
        Me.Paperspace.TabIndex = 4
        Me.Paperspace.TabStop = True
        Me.Paperspace.Text = "Paper Space"
        Me.Paperspace.UseVisualStyleBackColor = True
        '
        'Modelspace
        '
        Me.Modelspace.AutoSize = True
        Me.Modelspace.Location = New System.Drawing.Point(10, 16)
        Me.Modelspace.Name = "Modelspace"
        Me.Modelspace.Size = New System.Drawing.Size(85, 17)
        Me.Modelspace.TabIndex = 3
        Me.Modelspace.TabStop = True
        Me.Modelspace.Text = "Model Space"
        Me.Modelspace.UseVisualStyleBackColor = True
        '
        'ToolSettingsGroupBox
        '
        Me.ToolSettingsGroupBox.Controls.Add(Me.OverrideTemplateSettingsRadioButton)
        Me.ToolSettingsGroupBox.Controls.Add(Me.UseTemplateSettingsRadioButton)
        Me.ToolSettingsGroupBox.Location = New System.Drawing.Point(12, 493)
        Me.ToolSettingsGroupBox.Name = "ToolSettingsGroupBox"
        Me.ToolSettingsGroupBox.Size = New System.Drawing.Size(348, 43)
        Me.ToolSettingsGroupBox.TabIndex = 23
        Me.ToolSettingsGroupBox.TabStop = False
        Me.ToolSettingsGroupBox.Text = "Tool Settings"
        '
        'OverrideTemplateSettingsRadioButton
        '
        Me.OverrideTemplateSettingsRadioButton.AutoSize = True
        Me.OverrideTemplateSettingsRadioButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OverrideTemplateSettingsRadioButton.Location = New System.Drawing.Point(186, 19)
        Me.OverrideTemplateSettingsRadioButton.Name = "OverrideTemplateSettingsRadioButton"
        Me.OverrideTemplateSettingsRadioButton.Size = New System.Drawing.Size(153, 17)
        Me.OverrideTemplateSettingsRadioButton.TabIndex = 1
        Me.OverrideTemplateSettingsRadioButton.Text = "Override Template Settings"
        Me.OverrideTemplateSettingsRadioButton.UseVisualStyleBackColor = True
        '
        'UseTemplateSettingsRadioButton
        '
        Me.UseTemplateSettingsRadioButton.AutoSize = True
        Me.UseTemplateSettingsRadioButton.Checked = True
        Me.UseTemplateSettingsRadioButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.UseTemplateSettingsRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.UseTemplateSettingsRadioButton.Name = "UseTemplateSettingsRadioButton"
        Me.UseTemplateSettingsRadioButton.Size = New System.Drawing.Size(178, 17)
        Me.UseTemplateSettingsRadioButton.TabIndex = 0
        Me.UseTemplateSettingsRadioButton.TabStop = True
        Me.UseTemplateSettingsRadioButton.Text = "Use Settings Define In Template"
        Me.UseTemplateSettingsRadioButton.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 61)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(601, 424)
        Me.TabControl1.TabIndex = 24
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.InsertClientSheet)
        Me.TabPage1.Controls.Add(Me.SpaceFrame)
        Me.TabPage1.Controls.Add(Me.Addressfrm)
        Me.TabPage1.Controls.Add(Me.Sheetfrm)
        Me.TabPage1.Controls.Add(Me.LayoutFrame)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage1.Size = New System.Drawing.Size(593, 398)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tool Functions"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.TBI1Lst)
        Me.TabPage2.Controls.Add(Me.SamplePlotStamp)
        Me.TabPage2.Controls.Add(Me.TBI3Tick)
        Me.TabPage2.Controls.Add(Me.TBI2Lst)
        Me.TabPage2.Controls.Add(Me.DefaultInsertOnPSLabel)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.SaveDefaultsMach)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage2.Size = New System.Drawing.Size(593, 398)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Settings"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.OK_Button, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(372, 500)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(241, 36)
        Me.TableLayoutPanel2.TabIndex = 29
        '
        'frmTitleBlockInsert
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(625, 548)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ToolSettingsGroupBox)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 15)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmTitleBlockInsert"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.LayoutFrame.ResumeLayout(False)
        Me.LayoutFrame.PerformLayout()
        Me.Sheetfrm.ResumeLayout(False)
        Me.Sheetfrm.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Addressfrm.ResumeLayout(False)
        Me.SpaceFrame.ResumeLayout(False)
        Me.SpaceFrame.PerformLayout()
        Me.ToolSettingsGroupBox.ResumeLayout(False)
        Me.ToolSettingsGroupBox.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SingleLayoutOptionButton As System.Windows.Forms.RadioButton
    Friend WithEvents MultipleLayoutOptionButton As System.Windows.Forms.RadioButton
    Friend WithEvents Paperspace As System.Windows.Forms.RadioButton
    Friend WithEvents Modelspace As System.Windows.Forms.RadioButton
    Friend WithEvents ToolSettingsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents UseTemplateSettingsRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents OverrideTemplateSettingsRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
#End Region
End Class