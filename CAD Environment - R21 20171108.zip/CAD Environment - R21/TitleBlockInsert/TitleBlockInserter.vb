Imports System.Runtime.InteropServices
Imports Autodesk.AutoCAD.ApplicationServices    'Access to the AutoCAD application
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.TitleBlockInserter.TitleBlockInserter))> 

Public Class TitleBlockInserter
    'Implements Autodesk.AutoCAD.Runtime.IExtensionApplication

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Dim frmTitleblockInsert As New frmTitleBlockInsert
    '  ' Dim RuleAccessors As New RuleAccessors
    Dim SelectConfig As New SelectTemplate.TemplateSelector

    Dim IsInitializing As Boolean = True

    Public Structure TitleBlock
        Dim Frame As String
        Dim style As String
        Dim Size As String
        Dim Layout As String
        Dim Logo As String
        Dim Region As String
        Dim Office As String
        Dim ReviewStamp As Boolean
        Dim ScaleBar As Boolean
        Dim Path As String
        Dim FileName As String
    End Structure

    ' Main subroutine used to start macro
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_TitleBlockInserter", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub TitleBlockInserter()

        Try
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                SelectConfig.DisplayWarning()
                If ThisDrawingIsConfigured() Then
                    DisplayDialog()
                End If
            Else
                DisplayDialog()
            End If

        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub
    Sub DisplayDialog()
        Try
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(frmTitleblockInsert)
        Catch ex As System.Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

End Class
