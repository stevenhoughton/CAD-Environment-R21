Imports VB = Microsoft.VisualBasic
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports System.IO
Imports Jacobs.Common.Core
Imports System.Collections.Generic
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Friend Class frmTitleBlockInsert
    Inherits System.Windows.Forms.Form

    Dim AllTitleBlocks() As TitleBlockInserter.TitleBlock
    Dim bInitialize As Boolean
    Dim IsInitializing As Boolean = True
    Dim Path As String
    Dim BlockName As String
    Dim sAttBlockName As String
    Dim sStatusBlockName As String
    ' Dim RuleAccessors As New RuleAccessors
    Dim ourcompanyname As String

#Region "Events"

    Private Sub OfficeCmb_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OfficeCmb.SelectedValueChanged

        Try
            CheckForm()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub RegionCmb_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RegionCmb.SelectedValueChanged

        Try

            Dim svarsfile As String
            Dim cities As Dictionary(Of String, List(Of String))
            Dim Addresses As Object

            ' Test to see if file exists first then go read it.
            svarsfile = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)

            Addresses = Ini.ReadValues(svarsfile, "ADDRESSES", ";")
            cities = Ini.ReadValues(svarsfile, "CITIES PER REGION", ";")

            OfficeCmb.Items.Clear()

            '' find city
            If cities.ContainsKey(RegionCmb.SelectedItem.ToString()) Then
                For Each city As String In cities(RegionCmb.SelectedItem.ToString())
                    OfficeCmb.Items.Add(Trim(city))
                Next
            End If

            CheckForm()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

#End Region

    Sub PopulateListBoxes()

        Try

            If String.IsNullOrEmpty(FrameTypeCmb.Text) Then
                FrameTypes()
            Else
                If String.IsNullOrEmpty(Stylecmb.Text) Then
                    StyleTypes()
                Else
                    If String.IsNullOrEmpty(Sizecmb.Text) Then
                        Sizes()
                    Else
                        If String.IsNullOrEmpty(LayoutCmb.Text) Then
                            Layouts()
                        Else
                            If String.IsNullOrEmpty(Logocmb.Text) Then
                                Logos()
                            End If
                        End If
                    End If
                End If
            End If

            CheckForm()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub FrameTypes(Optional ByRef Value As Object = Nothing)

        Try

            Dim iList, iData, jList As Integer
            Dim Found As Boolean
            Dim List(0) As String
            Dim Item As String = String.Empty

            For iData = LBound(AllTitleBlocks) To UBound(AllTitleBlocks)
                Found = False
                For iList = LBound(List) To UBound(List)
                    If List(iList) = AllTitleBlocks(iData).Frame Then
                        Found = True
                        Exit For
                    End If
                Next
                If Found = False Then
                    ReDim Preserve List(jList)
                    List(jList) = AllTitleBlocks(iData).Frame
                    jList = jList + 1
                End If
            Next

            For Each Item In List
                Me.FrameTypeCmb.Items.Add(Item)
            Next

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub StyleTypes(Optional ByRef Value As Object = Nothing)

        Try
            Dim iList, iData, jList As Integer
            Dim Found As Boolean
            Dim Item As String = String.Empty

            Dim List(0) As String

            For iData = LBound(AllTitleBlocks) To UBound(AllTitleBlocks)
                If AllTitleBlocks(iData).Frame = FrameTypeCmb.Text Then
                    Found = False
                    For iList = LBound(List) To UBound(List)
                        If List(iList) = AllTitleBlocks(iData).style Then
                            Found = True
                            Exit For
                        End If
                    Next
                    If Found = False Then
                        ReDim Preserve List(jList)
                        List(jList) = AllTitleBlocks(iData).style
                        jList = jList + 1
                    End If
                End If
            Next

            For Each Item In List
                Me.Stylecmb.Items.Add(Item)
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub Sizes(Optional ByRef Value As Object = Nothing)

        Try

            Dim iList, iData, jList As Integer
            Dim Found As Boolean
            Dim Item As String = String.Empty
            Dim List(0) As String

            For iData = LBound(AllTitleBlocks) To UBound(AllTitleBlocks)
                If AllTitleBlocks(iData).Frame = FrameTypeCmb.Text Then
                    If AllTitleBlocks(iData).style = Stylecmb.Text Then
                        'Size
                        Found = False
                        For iList = LBound(List) To UBound(List)
                            If List(iList) = AllTitleBlocks(iData).Size Then
                                Found = True
                                Exit For
                            End If
                        Next
                        If Found = False Then
                            ReDim Preserve List(jList)
                            List(jList) = AllTitleBlocks(iData).Size
                            jList = jList + 1
                        End If
                    End If
                End If

            Next

            For Each Item In List
                Me.Sizecmb.Items.Add(Item)
            Next

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub Layouts(Optional ByRef Value As Object = Nothing)

        Try

            Dim iList, iData, jList As Integer
            Dim Found As Boolean
            Dim Item As String = String.Empty
            Dim List(0) As String

            For iData = LBound(AllTitleBlocks) To UBound(AllTitleBlocks)
                If AllTitleBlocks(iData).Frame = FrameTypeCmb.Text Then
                    If AllTitleBlocks(iData).style = Stylecmb.Text Then
                        If AllTitleBlocks(iData).Size = Sizecmb.Text Then

                            Found = False
                            For iList = LBound(List) To UBound(List)
                                If List(iList) = AllTitleBlocks(iData).Layout Then
                                    Found = True
                                    Exit For
                                End If
                            Next
                            If Found = False Then
                                ReDim Preserve List(jList)
                                List(jList) = AllTitleBlocks(iData).Layout
                                jList = jList + 1
                            End If
                        End If
                    End If
                End If
            Next

            For Each Item In List
                Me.LayoutCmb.Items.Add(Item)
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Function CheckForm() As Boolean

        Dim Result As Boolean = True

        Try

            If String.IsNullOrEmpty(Stylecmb.Text) Or
               String.IsNullOrEmpty(Sizecmb.Text) Or
               LayoutCmb.Enabled = True And String.IsNullOrEmpty(LayoutCmb.Text) Or
               String.IsNullOrEmpty(Logocmb.Text) Or
               String.IsNullOrEmpty(RegionCmb.Text) Or
               String.IsNullOrEmpty(OfficeCmb.Text) Then

                Result = False

            End If

            Me.OK_Button.Enabled = Result

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return Result

    End Function

    Sub Logos(Optional ByRef Value As Object = Nothing)

        Try
            Dim iList As Integer
            Dim List(0) As String
            Dim Item As String = String.Empty
            Dim directory As System.IO.DirectoryInfo

            directory = My.Computer.FileSystem.GetDirectoryInfo(Settings.Manager.AE.DrawingSheetsPath) ' & "\Components")

            Path = directory.Name
            Dim Files() As System.IO.FileInfo = directory.GetFiles
            For Each File As System.IO.FileInfo In Files
                If InStr(File.Name, "LOGO") <> 0 Then
                    If InStr(UCase(File.Name), UCase(Me.FrameTypeCmb.Text)) <> 0 And String.IsNullOrEmpty(FrameTypeCmb.Text) = False Then
                        If InStr(UCase(File.Name), UCase(Me.Sizecmb.Text)) <> 0 And String.IsNullOrEmpty(Sizecmb.Text) = False Then
                            ReDim Preserve List(iList)
                            List(iList) = VB.Left(File.Name, InStr(File.Name, "LOGO") - 2)
                            iList = iList + 1
                        End If
                    End If
                End If
            Next File

            For Each Item In List
                Me.Logocmb.Items.Add(Item)
            Next

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Function CleanBlocks() As Boolean

        Dim Result As Boolean = False

        Try

            Dim i As Integer

            DeleteBlock("*_LOGO_??_*")                                ' Deleting:         
            DeleteBlock("*_ADDRESS_??")                               ' Deleting:         
            DeleteBlock("*_STATUS_??_*")                              ' Deleting:         
            DeleteBlock("*" & BlockName & "*")
            DeleteBlock("*" & sAttBlockName & "*")                    ' Deleting:         
            DeleteBlock("*" & sStatusBlockName & "*")                 ' Deleting:         

            For i = 0 To Stylecmb.Items.Count - 1
                DeleteBlock("*_" & UserInterface.GetComboBoxText(Stylecmb, i) & "_??_*") ' Delete
            Next

            DeleteBlock("*INSERT_BARSCALE*")                         ' Deleting:         INSERT_BARSCALE
            DeleteBlock("*INSERT_DRAWING_STATUS*")
            DeleteBlock("*INSERT_NORTHPOINT*")                       ' Deleting:         INSERT_NORTHPOINT
            DeleteBlock("*INSERT_NOTES*")                            ' Deleting:         INSERT_NOTES
            DeleteBlock("*INSERT_LEGEND*")
            DeleteBlock("*INSERT_ADDRESS*")
            DeleteBlock("*PE CHOP TH CHONG*")
            DeleteBlock("*INSERT_REVIEW_STAMP*")

            PurgeBlockUsingFilter("*_LOGO_??_*")
            PurgeBlockUsingFilter("*_ADDRESS_??")
            PurgeBlockUsingFilter("*_STATUS_??_*")
            PurgeBlockUsingFilter("*" & BlockName & "*")
            PurgeBlockUsingFilter("*" & sAttBlockName & "*")
            PurgeBlockUsingFilter("*" & sStatusBlockName & "*")

            For i = 0 To Stylecmb.Items.Count - 1
                PurgeBlockUsingFilter("*_" & UserInterface.GetComboBoxText(Stylecmb, i) & "_??_*")
            Next

            PurgeBlockUsingFilter("*INSERT_BARSCALE*")
            PurgeBlockUsingFilter("*INSERT_DRAWING_STATUS*")
            PurgeBlockUsingFilter("*INSERT_NORTHPOINT*")
            PurgeBlockUsingFilter("*INSERT_NOTES*")
            PurgeBlockUsingFilter("*INSERT_LEGEND*")
            PurgeBlockUsingFilter("*INSERT_ADDRESS*")
            PurgeBlockUsingFilter("*PE CHOP TH CHONG*")
            PurgeBlockUsingFilter("*INSERT_REVIEW_STAMP*")

            Result = True


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return Result

    End Function

    Sub CheckRules(Optional ByRef bIgnoreOverrides As Boolean = False)

        '' This is the display mode of the control (which one to use as the default value)  - options are UseFirstRule or UsePrevious
        ''   UseFirstRule would get the first value in the list or array and just sets that as the visible item
        ''   UsePrevious would look for a pre saved workvar or a system variable to work out the default value

        Dim sWhatToUse As String

        '' This is the population mode of the control - options are all Available or JustRuleValues ("JustRuleValues" is for when called by Content Wizard or Template Builder)
        ''   In other words fill the list with only the rule values or all the values - example all layers in this drawing or just the one which is the default one.

        Dim sWhatToShow As String


        Try

            '' RULE 0
            '' Every Tool that uses rules needs to have a rule named {ToolName}0 
            '' This rule is used to work out if the template builder will allow users to change the Settings for this tool at runtime.
            ''
            '' Rules are made up of
            ''
            '' Name:            SAMPLECETOOL0
            '' Description:     Allow users to change default Settings nominated here:
            '' Value:           1
            '' DGL Code:        3      Three types available   1 = List Box
            ''                                                 2 = Single entry Text box
            ''                                                 3 = Boolean tickbox
            '' TBL Code:        42     Nine types Available  
            ''                                                 6 = Layer name (fixed)
            ''                                                 4 = Linetype name (fixed)
            ''                                                 8 = Text style name (fixed)
            ''                                                11 = DimStyle
            ''                                                15 = Text Justifications
            ''                                                40 = Double-precision floating-point values (text height, scale factors, and so on) 
            ''                                                41 = String
            ''                                                42 = Integers
            ''                                                62 = Color number (fixed)
            ''                                                18 = Insunits (fixed)
            ''                                                19 = User Defined List - (send array with items - fixed to that array)
            ''
            '' Rule Definition would look like this in the Tools.ini file.
            '' Rule = SAMPLECETOOL0,Allow users to change default Settings nominated here:,1,3,42

            ''Case "CLAYER"
            ''Case "TEXTSTYLE"
            ''Case "DIMSTYLE"
            ''Case "CTABLESTYLE"
            ''Case "CELWEIGHT"
            ''Case "PEN"
            ''Case "BLOCK"
            ''Case "CELTYPE"
            ''Case "CECOLOR"
            ''Case "TEXTJUSTIFICATION"
            ''Case "TEXTTYPES"
            ''Case "AUPREC0" ' Decimal Degrees
            ''Case "AUPREC1" ' Degrees minutes and seconds
            ''Case "AUPREC2" ' Grads
            ''Case "AUPREC3" ' Radians
            ''Case "AUPREC4" ' Surveyor's Units
            ''Case "AUPREC"
            ''Case "AUNITS"
            ''Case "INSUNITS"
            ''Case "LUNITS"
            ''Case "LUPREC0" ' Scientific
            ''Case "LUPREC1" ' Decimal
            ''Case "LUPREC2" ' Engineering
            ''Case "LUPREC3" ' Architectural
            ''Case "LUPREC4" ' Fractional
            ''Case "CUSTOM"

            '' Rule = SAMPLECETOOL0,Allow users to change default Settings nominated here:,1,3,42
            '' This tool by default allows users to change config defaults.

            If RuleAccessors.GetruleValue("TBI0", "True").ToString.IsTrue Then

                '' Allow uses to select if they want to use rules or not
                ToolSettingsGroupBox.Enabled = True

            Else

                '' Template Builder has restricted users from being able to change the template rules
                ToolSettingsGroupBox.Enabled = True

            End If

            '' Now that we have worked out if users could change the Settings or not.
            '' See which one it's set to
            If UseTemplateSettingsRadioButton.Checked = True Then

                '' User has opted to use the template Settings.
                '' Initialize the rules - this includes loading rules that may have been purged or ones that were never created in the origianal template
                '' For example new rules that now exist due to new tool features..
                '' This function is huge and it included functionality such as importing rules from the hierarchy and importing content from the hierarchy.

                Dim SearchForContent As Boolean = True
                If IsMasterFile() = True Then
                    SearchForContent = False
                End If

                'If IsThisAnOldConfigName = True Then
                '    InitializeRules("[TITLE BLOCK INSERTER]", True, SearchForContent, False)
                'Else
                InitializeRulesNew("[TITLE BLOCK INSERTER]", True, SearchForContent, False)
                'End If

                ' Enable/Disable relevant fields on your form - these would only be fields that have rules tied to them.
                ' If you are using the template Settings then normally all of the fields in this section should be disabled..

                TBI1Lst.Enabled = False
                TBI2Lst.Enabled = False
                TBI3Tick.Enabled = False

                '' Since we are using the rules in the Template the first one will be the only one 
                sWhatToUse = "UseFirstRule"

                '' Next line of code is probably redundant - as users can't select anything from the disabled fields.
                sWhatToShow = "AllAvailable"

            Else


                ' User has elected not to use the client rules
                ' Enable/Disable relevant fields
                ' If the user wishes to override the rules in the template then all the fields in this area should be enabled

                TBI1Lst.Enabled = True
                TBI2Lst.Enabled = True
                TBI3Tick.Enabled = True

                '' This time we are using the user overrides so if the user had picked something before we want to recall it from the workvars
                sWhatToUse = "UsePrevious"

                '' Show all items available so that the user can select
                sWhatToShow = "AllAvailable"


            End If

            ' TBI1 Rule ' Select the layer for the main titleblock & logo
            PopulateComboBox(TBI1Lst, "TBI1", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)

            ' TBI2 Rule ' Select the layer for the attributes block
            PopulateComboBox(TBI2Lst, "TBI2", sWhatToShow, sWhatToUse, "CLAYER", ThisDrawingUtilities.GetVariable("CLAYER").ToString, bIgnoreOverrides)

            ' TBI3 Rule ' Default to insert on paperspace
            PopulateCheckBox(TBI3Tick, "TBI3", "True", , False, bIgnoreOverrides)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub UseTemplateSettingsRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UseTemplateSettingsRadioButton.CheckedChanged

        '' Some events in .NET when implemented this way can tend to fire off prematurely 
        '' To Avoid this a flag has been setup to only fire off after the form is called
        '' Else this event fires off when DLL is loaded

        If IsInitializing = True Then Exit Sub

        Try

            CheckRules(UseTemplateSettingsRadioButton.Checked)

        Catch ex As Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try


    End Sub

    Private Sub Cancel_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cancel_Button.Click

        Try
            Me.Hide()
            Me.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub TBI3Tick_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TBI3Tick.CheckStateChanged

        If IsInitializing = True Then Exit Sub

        Try
            If UseTemplateSettingsRadioButton.Checked = True Then
                Paperspace.Checked = TBI3Tick.CheckState.ToString.IsTrue
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub Help_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Help_Button.Click

        Try
            CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub OK_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OK_Button.Click

        Try
            ourcompanyname = "Jacobs"

            Dim Insertpoint(2) As Double
            Dim LogoInsertPoint(2) As Double
            Dim AddressInsertPoint(2) As Double
            Dim ScaleBarInsertPoint(2) As Double
            Dim CheckStampInsertPoint(2) As Double
            Dim Address As List(Of String) = Nothing
            Dim iAddress As Integer
            Dim svarsfile As String
            Dim AddressName As String
            Dim LogoName As String
            Dim TitleBlockGeometryBlockReference As Autodesk.AutoCAD.Interop.Common.AcadBlockReference
            Dim TitleBlockAttributesBlockReference As Autodesk.AutoCAD.Interop.Common.AcadBlockReference
            Dim sCommand As String
            Dim OriginalBlockName As String
            Dim ATTDrawingName As String
            Dim DrawingStatusStampName As String
            Dim NewDrawingFullName, DrawingName, NewDrawingName As String
            Dim NewATTDrawingFullName As String
            Dim CleanBlocksResult As Boolean
            Dim ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor

            ' Work out if this drawing has been tied to a rules file and setup the rules if it has SetRules
            RuleAccessors.RecordDglRule("TBI1", TBI1Lst.Text)
            RuleAccessors.RecordDglRule("TBI2", TBI2Lst.Text)
            RuleAccessors.RecordDglRule("TBI3", TBI3Tick.CheckState.ToString.IsTrue)

            SaveDialogSettingsInUserArea()  ' save Settings on a machine basis
            WriteWorkVar() ' Save Settings on a drawing basis in case it's needed

            svarsfile = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)

            Dim Addresses As Dictionary(Of String, List(Of String)) = Ini.ReadValues(svarsfile, "ADDRESSES", ";")
            For Each data As KeyValuePair(Of String, List(Of String)) In Addresses
                If Me.OfficeCmb.SelectedItem.ToString.Trim = data.Key.Trim Then
                    Address = data.Value
                    iAddress = 0
                    Exit For
                End If
            Next

            CleanBlocksResult = True

            ' Remove previuos titleblocks
            If SingleLayoutOptionButton.Checked = True Then
                CleanBlocksResult = CleanBlocks()
            Else
                ' If multiblock mode selected make sure there are no single blocks in place
                If Block_Check(BlockName) >= 0 Or Block_Check(sAttBlockName) >= 0 Then
                    CleanBlocksResult = CleanBlocks()
                End If
            End If

            'Dim VarRet As Object
            If CleanBlocksResult = True Then

                DrawingName = ourcompanyname & "_"
                DrawingName = DrawingName & Me.FrameTypeCmb.Text & "_"
                DrawingName = DrawingName & Me.Stylecmb.Text & "_"
                DrawingName = DrawingName & Me.Sizecmb.Text & "_"
                DrawingName = DrawingName & Me.LayoutCmb.Text & "_"

                NewDrawingName = DrawingName & "SHEET.DWG"
                LogoName = Logocmb.Text & "_LOGO_" & Sizecmb.Text & "_" & FrameTypeCmb.Text & ".DWG"
                AddressName = ourcompanyname & "_ADDRESS_" & Sizecmb.Text & ".DWG"
                ATTDrawingName = DrawingName & "ATT.DWG"

                NewDrawingFullName = Settings.Manager.AE.DrawingSheetsPath.CombinePath(NewDrawingName)
                NewATTDrawingFullName = Settings.Manager.AE.DrawingSheetsPath.CombinePath(ATTDrawingName)
                DrawingName = Replace(NewDrawingName, "_SHEET.DWG", "")
                Dim Hold1() As String = Split(DrawingName, "_")
                DrawingStatusStampName = Hold1(0) & "_STATUS_" & Hold1(3) & "_" & Hold1(4) & ".DWG"

                '                Me.Hide()
                Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)
                    ' shawn how to ensure autocad main window is visible here
                    If SelectInsertionPointCheckBox.CheckState = CheckState.Checked Then
                        Dim VarRet() As Double = CType(ThisDrawingUtilities.Utility.GetPoint(, vbCrLf & "Select block origin point: "), Double())
                        Insertpoint(0) = VarRet(0)
                        Insertpoint(1) = VarRet(1)
                        Insertpoint(2) = VarRet(2)
                    Else
                        Insertpoint(0) = 0 : Insertpoint(1) = 0 : Insertpoint(2) = 0
                    End If

                    If System.IO.File.Exists(NewDrawingFullName) Then
                        If Modelspace.Checked = True Then

                            ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acModelSpace
                            TitleBlockGeometryBlockReference = ThisDrawingUtilities.ModelSpace.InsertBlock(Insertpoint, NewDrawingFullName, 1.0#, 1.0#, 1.0#, 0)
                            TitleBlockAttributesBlockReference = ThisDrawingUtilities.ModelSpace.InsertBlock(Insertpoint, NewATTDrawingFullName, 1.0#, 1.0#, 1.0#, 0)
                            If LayerExist(TBI2Lst.Text) Then
                                TitleBlockAttributesBlockReference.Layer = TBI2Lst.Text
                            Else
                                TitleBlockAttributesBlockReference.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                TBI1Lst.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                            End If

                            If String.IsNullOrEmpty(TitleBlockGeometryBlockReference.Name) = False Then

                                OriginalBlockName = TitleBlockGeometryBlockReference.EffectiveName

                                '' get all explodes entities
                                Dim entities() As Object = TryCast(TitleBlockGeometryBlockReference.Explode, Object())

                                For Each obj As Object In entities

                                    Dim MyAcadEntity As AcadEntity = TryCast(obj, AcadEntity)

                                    If MyAcadEntity IsNot Nothing Then
                                        If LayerExist(TBI1Lst.Text) Then
                                            MyAcadEntity.Layer = TBI1Lst.Text
                                        Else
                                            MyAcadEntity.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                            TBI1Lst.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                        End If
                                    End If
                                Next

                                TitleBlockGeometryBlockReference.Delete()
                                PurgeBlockUsingFilter(OriginalBlockName)

                                ReplaceBlock("INSERT_LOGO", Settings.Manager.AE.DrawingSheetsPath.CombinePath(LogoName), "MODEL", Address, False)
                                ReplaceBlock("INSERT_ADDRESS", Settings.Manager.AE.DrawingSheetsPath.CombinePath(AddressName), "MODEL", Address, False)
                                ReplaceBlock("INSERT_DRAWING_STATUS", Settings.Manager.AE.DrawingSheetsPath.CombinePath(DrawingStatusStampName), "MODEL", Address, False)

                            End If

                        Else

                            ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acPaperSpace
                            TitleBlockGeometryBlockReference = ThisDrawingUtilities.ActiveLayout.Block.InsertBlock(Insertpoint, NewDrawingFullName, 1.0#, 1.0#, 1.0#, 0)
                            TitleBlockAttributesBlockReference = ThisDrawingUtilities.ActiveLayout.Block.InsertBlock(Insertpoint, NewATTDrawingFullName, 1.0#, 1.0#, 1.0#, 0)
                            If LayerExist(TBI2Lst.Text) Then
                                TitleBlockAttributesBlockReference.Layer = TBI2Lst.Text
                            Else
                                TitleBlockAttributesBlockReference.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                TBI1Lst.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                            End If

                            If String.IsNullOrEmpty(TitleBlockGeometryBlockReference.Name) = False Then

                                OriginalBlockName = TitleBlockGeometryBlockReference.EffectiveName
                                '' get all explodes entities
                                Dim entities() As Object = TryCast(TitleBlockGeometryBlockReference.Explode, Object())

                                For Each obj As Object In entities

                                    Dim MyAcadEntity As AcadEntity = TryCast(obj, AcadEntity)

                                    If MyAcadEntity IsNot Nothing Then
                                        If LayerExist(TBI1Lst.Text) Then
                                            MyAcadEntity.Layer = TBI1Lst.Text
                                        Else
                                            MyAcadEntity.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                            TBI1Lst.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                        End If
                                    End If
                                Next

                                TitleBlockGeometryBlockReference.Delete()
                                PurgeBlockUsingFilter(OriginalBlockName)

                                ReplaceBlock("INSERT_LOGO", Settings.Manager.AE.DrawingSheetsPath.CombinePath(LogoName), "PAPER", Address, False)
                                ReplaceBlock("INSERT_ADDRESS", Settings.Manager.AE.DrawingSheetsPath.CombinePath(AddressName), "PAPER", Address, False)
                                ReplaceBlock("INSERT_DRAWING_STATUS", Settings.Manager.AE.DrawingSheetsPath.CombinePath(DrawingStatusStampName), "PAPER", Address, False)

                            End If

                        End If

                        If SingleLayoutOptionButton.Checked = True Then
                            ' RenameBlocks
                            sCommand = "-RENAME BLOCK " & Replace(UCase(NewDrawingName), "_SHEET.DWG", "") & vbCr & BlockName & vbCr
                            ThisDrawingUtilities.SendCommand(sCommand)

                            sCommand = "-RENAME BLOCK " & Replace(UCase(ATTDrawingName), ".DWG", "") & vbCr & sAttBlockName & vbCr
                            ThisDrawingUtilities.SendCommand(sCommand)

                            sCommand = "-RENAME BLOCK " & Replace(UCase(DrawingStatusStampName), ".DWG", "") & vbCr & sStatusBlockName & vbCr
                            ThisDrawingUtilities.SendCommand(sCommand)

                        End If

                    End If

                    ThisDrawingUtilities.Application.ZoomExtents()
                    ThisDrawingUtilities.Regen(Autodesk.AutoCAD.Interop.Common.AcRegenType.acAllViewports)

                    sCommand = "-PURGE" & vbCr & "BLOCKS" & vbCr & "*-TO-PURGE-" & vbCr & "NO" & vbCr
                    ThisDrawingUtilities.SendCommand(sCommand)

                End Using

            End If

            Me.Hide()
            Me.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub WriteWorkVar()

        Try

            WorkingVariableAccessors.AddWorkVar("TBIClientConfig", UseTemplateSettingsRadioButton.Checked = True)

            WorkingVariableAccessors.AddWorkVar("TBICFG", Me.FrameTypeCmb.Text & ";" &
                                            Me.Stylecmb.Text & ";" & Me.Sizecmb.Text &
                                            ";" & Me.LayoutCmb.Text & ";" & Me.Logocmb.Text &
                                            ";" & Me.RegionCmb.Text & ";" & Me.OfficeCmb.Text &
                                            ";" &
                                            Me.SingleLayoutOptionButton.Checked & ";" &
                                            Me.Paperspace.Checked & ";" &
                                            Me.SaveDefaultsMach.CheckState.ToString.IsTrue & ";" &
                                            Me.SelectInsertionPointCheckBox.CheckState.ToString.IsTrue)

        Catch ex As Exception

        End Try

    End Sub

    Function ReadWorkVars() As String()

        Try

            Dim config_params(10) As String
            Dim wkvar As WorkVars

            wkvar = WorkingVariableAccessors.GetWorkVar("TBICFG")

            If wkvar Is Nothing Then

                config_params(0) = "DRAWING"              ' Frame Types
                config_params(1) = "DEFAULT"              ' Style
                config_params(2) = "A1"                   ' Size
                config_params(3) = "HORIZONTAL"           ' Layout
                config_params(4) = "Jacobs"                  ' Logo"
                config_params(5) = String.Empty           ' Region
                config_params(6) = String.Empty           ' Office
                config_params(7) = CStr(True)             ' Single or Multple Title Block Per Drawing
                config_params(8) = CStr(True)             ' Paper or Model Space Insert
                config_params(9) = CStr(False)            ' SaveSettings in DWG
                config_params(10) = CStr(False)           ' Pick Insertion Point

            Else

                config_params = Split(wkvar.value.ToString, ";")

            End If

            ReadWorkVars = Array.Copy(config_params)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            Return Nothing
        End Try

    End Function

    Private Sub InsertClientSheet_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles InsertClientSheet.Click

        Try

            Dim ConfigName As String
            Dim ModName As String
            Dim sClientLibraryPath As String

            If ThisDrawingIsConfigured() = True Then

                GetConfigSettings()

                ConfigName = RuleAccessors.GetruleValue("FULLCONFIGNAME")

                Me.Hide()
                Me.Close()

                sClientLibraryPath = String.Empty

                If RuleAccessors.GetruleValue("TESTCONFIG", "False", True, False).IsTrue Then
                    If UCase(RUNTIMEConfigPath) Like "*T@*" Then
                        ModName = UCase(RUNTIMEConfigPath)
                    Else
                        ModName = Replace(UCase(RUNTIMEConfigPath), UCase(ConfigName), "T@" & UCase(ConfigName))
                    End If

                Else
                    ModName = RUNTIMEConfigPath
                End If

                If System.IO.File.Exists(ModName.CombinePath("Settings", Settings.Manager.AE.DrawingSheetsFileName)) Then
                    sClientLibraryPath = ModName.CombinePath("Settings", Settings.Manager.AE.DrawingSheetsFileName) & "/BLOCKS"
                Else

                    Acad_MessageBox(Settings.Manager.AE.DrawingSheetsFileName & " is not present in this configuration. " & vbCrLf & "The Drawing Sheet tool will now open DesignCenter in the configuration Support folder in case you wish to select an alternative.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                    sClientLibraryPath = ModName.CombinePath("Settings")
                End If

                If CInt(ThisDrawingUtilities.GetVariable("ADCSTATE")) <> 1 Then
                    ThisDrawingUtilities.SendCommand("'_ADCENTER" & vbCr)
                    ThisDrawingUtilities.SendCommand("_.adcnavigate " & sClientLibraryPath & vbCr)
                Else
                    ThisDrawingUtilities.SendCommand("_.adcnavigate " & sClientLibraryPath & vbCr)
                End If

            Else

                Acad_MessageBox("This drawing has no configuration - you will need to navigate manually to your desired location", , , , , , , True, logName)
                ThisDrawingUtilities.SendCommand("(Command ""adcenter"")" & vbCr)

            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    ''' <summary>
    ''' Save dialog box setting everytime we hit ok
    ''' </summary>
    ''' <remarks></remarks>
    ''' 
    Sub SaveDialogSettingsInUserArea()

        Try
            Dim MyStreamWriter As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.TitleBlockInserterDATFileName), False)

            MyStreamWriter.WriteLine(Me.FrameTypeCmb.Text)
            MyStreamWriter.WriteLine(Me.Stylecmb.Text)
            MyStreamWriter.WriteLine(Me.Sizecmb.Text)
            MyStreamWriter.WriteLine(Me.LayoutCmb.Text)
            MyStreamWriter.WriteLine(Me.Logocmb.Text)
            MyStreamWriter.WriteLine(Me.RegionCmb.Text)
            MyStreamWriter.WriteLine(Me.OfficeCmb.Text)
            MyStreamWriter.WriteLine(Me.SingleLayoutOptionButton.Checked)
            MyStreamWriter.WriteLine(Me.Paperspace.Checked)
            MyStreamWriter.WriteLine(Me.SaveDefaultsMach.CheckState)
            MyStreamWriter.WriteLine(Me.SelectInsertionPointCheckBox.CheckState)

            MyStreamWriter.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Function RestoreDialogSettingsInUserArea() As String()

        Dim result() As String = Nothing

        Try

            If System.IO.File.Exists(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.TitleBlockInserterDATFileName)) Then

                Dim MyStreamReader As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.TitleBlockInserterDATFileName), System.Text.Encoding.ASCII)
                Dim line As String = String.Empty
                Dim ctr As Integer = 0
                Dim Config_Params(10) As String

                Do
                    line = MyStreamReader.ReadLine()

                    If line IsNot Nothing Then
                        Config_Params(ctr) = line
                    End If

                    ctr = ctr + 1

                Loop Until line Is Nothing

                MyStreamReader.Close()

                result = Array.Copy(Config_Params)

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
            result = Nothing
        End Try

        Return result

    End Function

    Sub ReplaceBlock(ByRef InsertionBlockName As String, ByRef BlockName As String, ByRef Dwg_Space As String, ByRef Address As List(Of String), Optional ByRef ExplodeBlock As Boolean = False)



        Try

            Dim Insertpt As Object
            Dim rotateangle As Double
            Dim oBkRef As Autodesk.AutoCAD.Interop.Common.AcadBlockReference
            Dim oBkRef1 As Autodesk.AutoCAD.Interop.Common.AcadBlockReference = Nothing
            Dim rotation As Double
            Dim ent As Autodesk.AutoCAD.Interop.Common.AcadEntity
            Dim BlockNameToPurge As String
            Dim iAddress As Integer
            Dim ObjectsToDelete As Object = Nothing
            'Dim ObjectsToLayer() As AcadEntity
            'Dim i As Integer
            Dim ssetObj As Autodesk.AutoCAD.Interop.AcadSelectionSet

            rotation = 0.0#

            If UCase(Dwg_Space) = "MODEL" Then
                For Each ent In ThisDrawingUtilities.ModelSpace
                    If ent.ObjectName = "AcDbBlockReference" Then
                        oBkRef = CType(ent, AcadBlockReference)
                        If UCase(oBkRef.Name) = InsertionBlockName Then
                            Insertpt = oBkRef.InsertionPoint
                            BlockNameToPurge = oBkRef.EffectiveName
                            If ExplodeBlock = True Then
                                ObjectsToDelete = oBkRef.Explode
                            End If
                            oBkRef.Delete()

                            PurgeBlockUsingFilter(BlockNameToPurge)

                            If Not IsNothing(ObjectsToDelete) Then
                                ssetObj = SSetAdd("ObjectTodelete")
                                ssetObj.AddItems(ObjectsToDelete)
                                ssetObj.Erase()
                                ssetObj.Delete()
                            End If

                            ' Insert the new block in it's place - rotation assumed to be 0.0
                            ' Check UCS
                            ' set rotation Angle
                            rotateangle = rotation
                            rotateangle = rotation * 3.141592 / 180.0#

                            ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acModelSpace
                            oBkRef1 = ThisDrawingUtilities.ModelSpace.InsertBlock(Insertpt, BlockName, 1.0#, 1.0#, 1.0#, rotateangle)

                            If LayerExist(TBI1Lst.Text) Then
                                oBkRef1.Layer = TBI1Lst.Text
                            Else
                                oBkRef1.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                            End If

                            If ExplodeBlock = True Then
                                BlockName = oBkRef1.EffectiveName

                                '' get all explodes entities
                                Dim entities() As Object = TryCast(oBkRef1.Explode, Object())

                                oBkRef1.Delete()
                                PurgeBlockUsingFilter(BlockNameToPurge)

                                For Each obj As Object In entities

                                    Dim MyAcadEntity As AcadEntity = TryCast(obj, AcadEntity)

                                    If MyAcadEntity IsNot Nothing Then
                                        If LayerExist(TBI1Lst.Text) Then
                                            MyAcadEntity.Layer = TBI1Lst.Text
                                        Else
                                            MyAcadEntity.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                            TBI1Lst.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                        End If
                                    End If
                                Next

                                'ObjectsToLayer = CType(oBkRef1.Explode, AcadEntity())
                                'oBkRef1.Delete()
                                'PurgeBlockUsingFilter(BlockNameToPurge)
                                'For i = 0 To UBound(ObjectsToLayer)
                                '    If LayerExist(TBI1Lst.Text) Then
                                '        ObjectsToLayer(i).Layer = TBI1Lst.Text
                                '    Else
                                '        ObjectsToLayer(i).Layer = ThisDrawing.GetVariable("CLAYER").ToString
                                '        TBI1Lst.Text = ThisDrawing.GetVariable("CLAYER").ToString
                                '    End If
                                'Next

                            End If
                        End If
                    End If
                Next ent
            Else

                For Each ent In ThisDrawingUtilities.ActiveLayout.Block
                    If ent.ObjectName = "AcDbBlockReference" Then
                        oBkRef = CType(ent, AcadBlockReference)
                        If UCase(oBkRef.Name) = InsertionBlockName Then
                            Insertpt = oBkRef.InsertionPoint
                            BlockNameToPurge = oBkRef.EffectiveName
                            If ExplodeBlock = True Then
                                ObjectsToDelete = oBkRef.Explode
                            End If
                            oBkRef.Delete()
                            PurgeBlockUsingFilter(BlockNameToPurge)

                            If Not IsNothing(ObjectsToDelete) Then
                                ssetObj = SSetAdd("ObjectsToDelete")
                                ssetObj.AddItems(ObjectsToDelete)
                                ssetObj.Erase()
                                ssetObj.Delete()
                            End If

                            ' Insert the new block in it's place - rotation assumed to be 0.0
                            ' Check UCS
                            ' set rotation Angle
                            rotateangle = rotation
                            rotateangle = rotation * 3.141592 / 180.0#
                            ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acPaperSpace
                            oBkRef1 = ThisDrawingUtilities.ActiveLayout.Block.InsertBlock(Insertpt, BlockName, 1.0#, 1.0#, 1.0#, rotateangle)

                            If LayerExist(TBI1Lst.Text) Then
                                oBkRef1.Layer = TBI1Lst.Text
                            Else
                                oBkRef1.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                            End If

                            If ExplodeBlock = True Then



                                '' get all explodes entities
                                Dim entities() As Object = TryCast(oBkRef1.Explode, Object())

                                oBkRef1.Delete()
                                PurgeBlockUsingFilter(BlockNameToPurge)

                                For Each obj As Object In entities

                                    Dim MyAcadEntity As AcadEntity = TryCast(obj, AcadEntity)

                                    If MyAcadEntity IsNot Nothing Then
                                        If LayerExist(TBI1Lst.Text) Then
                                            MyAcadEntity.Layer = TBI1Lst.Text
                                        Else
                                            MyAcadEntity.Layer = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                            TBI1Lst.Text = ThisDrawingUtilities.GetVariable("CLAYER").ToString
                                        End If
                                    End If
                                Next

                                'ObjectsToLayer = CType(oBkRef1.Explode, AcadEntity())
                                'oBkRef1.Delete()
                                'PurgeBlockUsingFilter(BlockNameToPurge)
                                'For i = 0 To UBound(ObjectsToLayer)
                                '    If LayerExist(TBI1Lst.Text) Then
                                '        ObjectsToLayer(i).Layer = TBI1Lst.Text
                                '    Else
                                '        ObjectsToLayer(i).Layer = ThisDrawing.GetVariable("CLAYER").ToString
                                '        TBI1Lst.Text = ThisDrawing.GetVariable("CLAYER").ToString
                                '    End If
                                'Next

                            End If
                        End If
                    End If
                Next ent
            End If

            If InStr(UCase(InsertionBlockName), "INSERT_ADDRESS") > 0 Then
                If Not (oBkRef1 Is Nothing) Then ' Figure blocks don't seem to have addresses??

                    For Each Att As AcadAttributeReference In DirectCast(oBkRef1.GetAttributes, IEnumerable)
                        If VB.Left(Att.TagString, 11) = "ADDRESSLINE" Then
                            Att.TextString = String.Empty
                        End If
                    Next

                    iAddress = 0
                    For Each item As String In Address
                        For Each att As AcadAttributeReference In DirectCast(oBkRef1.GetAttributes, IEnumerable)
                            If att.TagString = "ADDRESSLINE" & iAddress + 1 Then
                                att.TextString = item
                                iAddress = iAddress + 1
                                Exit For
                            End If
                        Next
                    Next

                End If
            End If

            PurgeBlockUsingFilter(InsertionBlockName)

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub DeleteBlock(ByVal BlockName As String)


        Try

            With ThisDrawingUtilities

                For Each oLayout As Autodesk.AutoCAD.Interop.Common.AcadLayout In .Layouts

                    For Each oBlock As AcadObject In oLayout.Block
                        'Dim MyEntity As AcadEntity = TryCast(oBlock, AcadEntity)

                        Dim MyBlock As AcadBlockReference = TryCast(oBlock, AcadBlockReference)

                        If MyBlock IsNot Nothing Then
                            If UCase(MyBlock.Name) Like UCase(BlockName) = True Then

                                Acad_MessageBox("Deleting: " & MyBlock.Name, , , , , , , True, logName)
                                MyBlock.Delete()

                            End If
                        End If

                    Next
                Next

            End With

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub PurgeBlockUsingFilter(ByVal BlockName As String)



        Try

            Dim oBlock As Autodesk.AutoCAD.Interop.Common.AcadBlock
            With ThisDrawingUtilities
                For Each oBlock In .Blocks
                    If UCase(oBlock.Name) Like UCase(BlockName) = True Then
                        NewPurgeBlock(UCase(oBlock.Name), False)
                    End If
                Next oBlock
            End With

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Sub NewPurgeBlock(ByRef sBlockName As String, Optional ByRef Verbose As Boolean = True)



        Try

            Dim oTestblk As Autodesk.AutoCAD.Interop.Common.AcadBlock

            Try

                For Each oTestblk In ThisDrawingUtilities.Blocks
                    If UCase(oTestblk.Name) = UCase(sBlockName) Then
                        oTestblk.Delete()
                        If Err.Number <> 0 Then
                            If Verbose = True Then
                                Acad_MessageBox("Block " & sBlockName & " can't be purged. " & Err.Description, System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)
                            Else
                                Acad_MessageBox("Block " & sBlockName & " can't be purged. " & Err.Description, , , , , , , True, logName)
                                oTestblk.Name = oTestblk.Name & "-TO-PURGE-"
                                Acad_MessageBox("Renaming " & sBlockName & " To " & oTestblk.Name & "1", , , , , , , True, logName)
                            End If
                            Information.Err.Clear()
                        Else
                            If Verbose = True Then
                                Acad_MessageBox("Block " & sBlockName & " has been purged", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                            Else
                                Acad_MessageBox("Block " & sBlockName & " has been purged", , , , , , , True, logName)
                            End If
                        End If
                    End If
                Next oTestblk

            Catch ex As Exception
                ' Don't care if there is an error just keep going
            End Try

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub frmTitleBlockInsert_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Try
            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            IsInitializing = True

            ourcompanyname = "Jacobs"

            BlockName = ourcompanyname & "_TITLEBLOCK"
            sAttBlockName = ourcompanyname & "_TITLEBLOCK_ATTRIBUTES"
            sStatusBlockName = ourcompanyname & "_STATUS"


            '            BlockName = "JACOBS_TITLEBLOCK"
            '            sAttBlockName = "JACOBS_TITLEBLOCK_ATTRIBUTES"
            '            sStatusBlockName = "JACOBS_STATUS"

            InsertClientSheet.Enabled = ThisDrawingIsConfigured()

            Dim iData As Integer
            Dim Directory As System.IO.DirectoryInfo

            Directory = My.Computer.FileSystem.GetDirectoryInfo(Settings.Manager.AE.DrawingSheetsPath)

            Dim Files() As System.IO.FileInfo = Directory.GetFiles

            If String.IsNullOrEmpty(Settings.Manager.AE.DrawingSheetsPath) Then

                Acad_MessageBox("Directory " & Settings.Manager.AE.DrawingSheetsPath & " can not be found", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Error, , , , , logName)

                Exit Sub
            End If

            For Each File As System.IO.FileInfo In Files

                If InStr(File.Name, "_SHEET.") > 0 Then

                    ReDim Preserve AllTitleBlocks(iData)
                    AllTitleBlocks(iData).FileName = File.Name
                    AllTitleBlocks(iData).Frame = Mid(AllTitleBlocks(iData).FileName, InStr(AllTitleBlocks(iData).FileName, "_") + 1)
                    AllTitleBlocks(iData).style = Mid(AllTitleBlocks(iData).Frame, InStr(AllTitleBlocks(iData).Frame, "_") + 1)
                    AllTitleBlocks(iData).Size = Mid(AllTitleBlocks(iData).style, InStr(AllTitleBlocks(iData).style, "_") + 1)
                    AllTitleBlocks(iData).Layout = Mid(AllTitleBlocks(iData).Size, InStr(AllTitleBlocks(iData).Size, "_") + 1)
                    AllTitleBlocks(iData).Path = Path
                    'Truncate values
                    AllTitleBlocks(iData).Frame = VB.Left(AllTitleBlocks(iData).Frame, InStr(AllTitleBlocks(iData).Frame, "_") - 1)
                    AllTitleBlocks(iData).style = VB.Left(AllTitleBlocks(iData).style, InStr(AllTitleBlocks(iData).style, "_") - 1)
                    AllTitleBlocks(iData).Size = VB.Left(AllTitleBlocks(iData).Size, InStr(AllTitleBlocks(iData).Size, "_") - 1)
                    AllTitleBlocks(iData).Layout = VB.Left(AllTitleBlocks(iData).Layout, InStr(AllTitleBlocks(iData).Layout, "_") - 1)
                    iData = iData + 1

                End If

            Next File

            FrameTypes()

            Dim svarsfile As String
            Dim config_params As String()

            Me.Text = "Title Block Inserter - " & Settings.Manager.AE.Version

            bInitialize = True

            CheckRules(WorkingVariableAccessors.GetWorkVarValue("TBIClientConfig", "True").ToString.IsTrue) ' Ignore any overrides

            WorkingVariableAccessors.AddWorkVar("TBIClientConfig", UseTemplateSettingsRadioButton.Checked = True)

            Dim objAcApp As Autodesk.AutoCAD.Interop.AcadApplication = Nothing

            Autodesk.AutoCAD.Runtime.SystemObjects.DynamicLinker.LoadModule(Settings.Manager.AutoCAD.Path & "\Express\RTEXT.ARX", True, True)

            ' Test to see if file exists first then go read it.
            svarsfile = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)
            Dim cities As Dictionary(Of String, List(Of String)) = Ini.ReadValues(svarsfile, "CITIES PER REGION", ";")

            For Each data As KeyValuePair(Of String, List(Of String)) In cities
                Me.RegionCmb.Items.Add(data.Key)
            Next

            config_params = CType(ReadWorkVars(), String()) ' Read workvars if they are not set then or we wish to use the file 9 will be false anyway
            If CBool(config_params(9)) = False Then ' Do we want to read the DWG file Settings?
                If System.IO.File.Exists(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.TitleBlockInserterDATFileName)) Then ' Has the tool ever been run? Does the DAT file exist?
                    config_params = RestoreDialogSettingsInUserArea()
                End If
            End If

            Try

                FrameTypeCmb.Text = config_params(0)                                 ' Frame Option
                Stylecmb.Text = config_params(1)                                     ' Styles
                Sizecmb.Text = config_params(2)                                      ' Sizes
                LayoutCmb.Text = config_params(3)                                    ' Layouts
                Logocmb.Text = config_params(4)                                      ' Logos
                RegionCmb.Text = config_params(5)                                    ' Region
                OfficeCmb.Text = config_params(6)                                    ' Office
                SingleLayoutOptionButton.Checked = config_params(7).ToString.IsTrue   ' Single Block Mode
                'MultipleLayoutOptionButton.Checked = config_params(7).ToString.IsTrue

                If TBI3Tick.CheckState = CheckState.Unchecked Then
                    Paperspace.Checked = config_params(8).ToString.IsTrue             ' Insert in paperspace
                    If WhichSpace() <> "PaperSpace" And Paperspace.Checked Then
                        ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acModelSpace
                    End If
                Else
                    ' Client rule to insert on paperspace overrides previous Settings
                    Paperspace.Checked = True
                    If WhichSpace() <> "PaperSpace" Then
                        ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acPaperSpace
                    End If
                End If

                If Paperspace.Checked = False Then
                    Modelspace.Checked = True
                Else
                    Modelspace.Checked = False
                End If

                SaveDefaultsMach.CheckState = config_params(9).ToString.GetCheckState ' Save Settings in Drawing

                SelectInsertionPointCheckBox.CheckState = config_params(9).ToString.GetCheckState
            Catch ex As Exception
                ' Ignore any errors
            End Try

            IsInitializing = False


        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub LayoutCmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LayoutCmb.SelectedIndexChanged

        Try

            Logocmb.Items.Clear()
            PopulateListBoxes()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub Sizecmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Sizecmb.SelectedIndexChanged

        Try

            LayoutCmb.Items.Clear()
            Logocmb.Items.Clear()
            PopulateListBoxes()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub FrameTypeCmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrameTypeCmb.SelectedIndexChanged

        Try

            Stylecmb.Items.Clear()
            Sizecmb.Items.Clear()
            LayoutCmb.Items.Clear()
            Logocmb.Items.Clear()
            PopulateListBoxes()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub

    Private Sub Stylecmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Stylecmb.SelectedIndexChanged

        Try
            Sizecmb.Items.Clear()
            LayoutCmb.Items.Clear()
            Logocmb.Items.Clear()
            PopulateListBoxes()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Logocmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Logocmb.SelectedIndexChanged

        Try

            CheckForm()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

    End Sub


    Private Sub frmTitleBlockInsert_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub


End Class