<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BatchApplyTemplateAssociationSelectFilesOrFolders
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BatchApplyTemplateAssociationSelectFilesOrFolders))
        Me.FilesListBox = New System.Windows.Forms.ListBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfigNameComboBox = New System.Windows.Forms.ComboBox()
        Me.ConfigNameLabel = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.FilesToSwitchGroupBox = New System.Windows.Forms.GroupBox()
        Me.BrowseButton = New System.Windows.Forms.Button()
        Me.IncludeSubFoldersCheckBox = New System.Windows.Forms.CheckBox()
        Me.IncludeXrefsCheckBox = New System.Windows.Forms.CheckBox()
        Me.Folders = New System.Windows.Forms.RadioButton()
        Me.FilesRadioButton = New System.Windows.Forms.RadioButton()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.FilesToSwitchGroupBox.SuspendLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'FilesListBox
        '
        Me.FilesListBox.AllowDrop = True
        Me.FilesListBox.ContextMenuStrip = Me.ContextMenuStrip1
        Me.FilesListBox.FormattingEnabled = True
        Me.FilesListBox.ItemHeight = 16
        Me.FilesListBox.Location = New System.Drawing.Point(43, 79)
        Me.FilesListBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FilesListBox.Name = "FilesListBox"
        Me.FilesListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.FilesListBox.Size = New System.Drawing.Size(747, 260)
        Me.FilesListBox.Sorted = True
        Me.FilesListBox.TabIndex = 1
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelectAllToolStripMenuItem, Me.DeleteToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(133, 48)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select All"
        '
        'DeleteToolStripMenuItem
        '
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(132, 22)
        Me.DeleteToolStripMenuItem.Text = "Delete"
        '
        'ConfigNameComboBox
        '
        Me.ConfigNameComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ConfigNameComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ConfigNameComboBox.FormattingEnabled = True
        Me.ConfigNameComboBox.Location = New System.Drawing.Point(211, 69)
        Me.ConfigNameComboBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ConfigNameComboBox.Name = "ConfigNameComboBox"
        Me.ConfigNameComboBox.Size = New System.Drawing.Size(636, 24)
        Me.ConfigNameComboBox.Sorted = True
        Me.ConfigNameComboBox.TabIndex = 5
        '
        'ConfigNameLabel
        '
        Me.ConfigNameLabel.AutoSize = True
        Me.ConfigNameLabel.Location = New System.Drawing.Point(27, 73)
        Me.ConfigNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ConfigNameLabel.Name = "ConfigNameLabel"
        Me.ConfigNameLabel.Size = New System.Drawing.Size(172, 17)
        Me.ConfigNameLabel.TabIndex = 6
        Me.ConfigNameLabel.Text = "New Configuration Name: "
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FilesToSwitchGroupBox
        '
        Me.FilesToSwitchGroupBox.Controls.Add(Me.BrowseButton)
        Me.FilesToSwitchGroupBox.Controls.Add(Me.IncludeSubFoldersCheckBox)
        Me.FilesToSwitchGroupBox.Controls.Add(Me.IncludeXrefsCheckBox)
        Me.FilesToSwitchGroupBox.Controls.Add(Me.Folders)
        Me.FilesToSwitchGroupBox.Controls.Add(Me.FilesRadioButton)
        Me.FilesToSwitchGroupBox.Controls.Add(Me.FilesListBox)
        Me.FilesToSwitchGroupBox.Location = New System.Drawing.Point(31, 107)
        Me.FilesToSwitchGroupBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FilesToSwitchGroupBox.Name = "FilesToSwitchGroupBox"
        Me.FilesToSwitchGroupBox.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FilesToSwitchGroupBox.Size = New System.Drawing.Size(816, 400)
        Me.FilesToSwitchGroupBox.TabIndex = 7
        Me.FilesToSwitchGroupBox.TabStop = False
        Me.FilesToSwitchGroupBox.Text = "Files To Switch Configuration"
        '
        'BrowseButton
        '
        Me.BrowseButton.Location = New System.Drawing.Point(657, 348)
        Me.BrowseButton.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BrowseButton.Name = "BrowseButton"
        Me.BrowseButton.Size = New System.Drawing.Size(133, 31)
        Me.BrowseButton.TabIndex = 6
        Me.BrowseButton.Text = "&Browse"
        Me.BrowseButton.UseVisualStyleBackColor = True
        '
        'IncludeSubFoldersCheckBox
        '
        Me.IncludeSubFoldersCheckBox.AutoSize = True
        Me.IncludeSubFoldersCheckBox.Checked = True
        Me.IncludeSubFoldersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IncludeSubFoldersCheckBox.Location = New System.Drawing.Point(43, 354)
        Me.IncludeSubFoldersCheckBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.IncludeSubFoldersCheckBox.Name = "IncludeSubFoldersCheckBox"
        Me.IncludeSubFoldersCheckBox.Size = New System.Drawing.Size(200, 26)
        Me.IncludeSubFoldersCheckBox.TabIndex = 5
        Me.IncludeSubFoldersCheckBox.Text = "Include sub-folders"
        Me.IncludeSubFoldersCheckBox.UseVisualStyleBackColor = True
        '
        'IncludeXrefsCheckBox
        '
        Me.IncludeXrefsCheckBox.AutoSize = True
        Me.IncludeXrefsCheckBox.Checked = True
        Me.IncludeXrefsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IncludeXrefsCheckBox.Location = New System.Drawing.Point(236, 354)
        Me.IncludeXrefsCheckBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.IncludeXrefsCheckBox.Name = "IncludeXrefsCheckBox"
        Me.IncludeXrefsCheckBox.Size = New System.Drawing.Size(179, 26)
        Me.IncludeXrefsCheckBox.TabIndex = 4
        Me.IncludeXrefsCheckBox.Text = "Include Xref files"
        Me.IncludeXrefsCheckBox.UseVisualStyleBackColor = True
        Me.IncludeXrefsCheckBox.Visible = False
        '
        'Folders
        '
        Me.Folders.AutoSize = True
        Me.Folders.Checked = True
        Me.Folders.Location = New System.Drawing.Point(43, 23)
        Me.Folders.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Folders.Name = "Folders"
        Me.Folders.Size = New System.Drawing.Size(153, 26)
        Me.Folders.TabIndex = 3
        Me.Folders.TabStop = True
        Me.Folders.Text = "Select folders"
        Me.Folders.UseVisualStyleBackColor = True
        '
        'FilesRadioButton
        '
        Me.FilesRadioButton.AutoSize = True
        Me.FilesRadioButton.Location = New System.Drawing.Point(43, 52)
        Me.FilesRadioButton.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.FilesRadioButton.Name = "FilesRadioButton"
        Me.FilesRadioButton.Size = New System.Drawing.Size(129, 26)
        Me.FilesRadioButton.TabIndex = 2
        Me.FilesRadioButton.TabStop = True
        Me.FilesRadioButton.Text = "Select files"
        Me.FilesRadioButton.UseVisualStyleBackColor = True
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 18
        Me.LogoPictureBox.TabStop = False
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.Location = New System.Drawing.Point(11, 6)
        Me.Help_Button.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.Size = New System.Drawing.Size(85, 32)
        Me.Help_Button.TabIndex = 21
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = True
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(225, 6)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(85, 32)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Enabled = False
        Me.OK_Button.Location = New System.Drawing.Point(118, 6)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(85, 32)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(472, 35)
        Me.lblTitle.TabIndex = 19
        Me.lblTitle.Text = "Batch Apply Template Associations"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.OK_Button, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(533, 517)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(321, 44)
        Me.TableLayoutPanel2.TabIndex = 29
        '
        'BatchApplyTemplateAssociationSelectFilesOrFolders
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(871, 570)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.ConfigNameLabel)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.FilesToSwitchGroupBox)
        Me.Controls.Add(Me.ConfigNameComboBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(877, 603)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(877, 603)
        Me.Name = "BatchApplyTemplateAssociationSelectFilesOrFolders"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.FilesToSwitchGroupBox.ResumeLayout(False)
        Me.FilesToSwitchGroupBox.PerformLayout()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FilesListBox As System.Windows.Forms.ListBox
    Friend WithEvents ConfigNameComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ConfigNameLabel As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents FilesToSwitchGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents IncludeSubFoldersCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents IncludeXrefsCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Folders As System.Windows.Forms.RadioButton
    Friend WithEvents FilesRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents BrowseButton As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents Help_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel

End Class
