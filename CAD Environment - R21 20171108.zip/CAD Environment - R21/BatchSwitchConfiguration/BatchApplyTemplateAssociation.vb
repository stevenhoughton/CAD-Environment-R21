Imports Autodesk.AutoCAD.Runtime
Imports System.Windows.Forms
Imports Jacobs.AutoCAD.Utilities

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.BatchApplyTemplateAssociations.BatchApplyTemplateAssociation))> 

Public Class BatchApplyTemplateAssociation

    <CommandMethod("Jacobs_BatchApplyTemplateAssociations", CommandFlags.Session)> _
    Public Sub BATCHSWITCH()

        If Acad_MessageBox("Switching configurations will not change any existing geometry or content styles." & vbCrLf &
                  "To update existing styles you will need to use the Add Configuration command. (Note: This is not available in batch mode)" & vbCrLf & vbCrLf &
                  "Would you like to continue using the Batch Switch Configuration utility?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then

            Dim mydialog As New BatchProcessorLoginForm
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(mydialog)

        End If

    End Sub

End Class
