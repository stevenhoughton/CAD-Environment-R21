Imports System.IO
Imports System.Windows.Forms
Imports AutoCADApp = Autodesk.AutoCAD.ApplicationServices.Application
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings
'Imports Jacobs.AutoCAD

Public Class BatchApplyTemplateAssociationSelectFilesOrFolders

    Private Shared m_UserTempPath As String
    Private Shared m_file_name As String
    Public Shared sProductName As String

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        Dim sFile As String
        Dim w As StreamWriter
        Dim RulesAndWorkvars As New RulesAndWorkvars.RulesAndWorkVars

        Try
            w = New IO.StreamWriter(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "BatchSwitchConfigurationsResult" & Common.Settings.Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension))
            For Each sFile In FilesListBox.Items
                w.WriteLine(RulesAndWorkvars.AddRule("FULLCONFIGNAME", ConfigNameComboBox.SelectedItem.ToString, "Full Configuration Name", 0, 0, sFile))
                RulesAndWorkvars.AddRule("CONFIGLEVEL", "CLIENT", "Configuration Level", 0, 0, sFile)

                ' May not work - requires testing
                'AcadApp.DocumentManager.MdiActiveDocument.SendStringToExecute("SwitchRemoveRules" & vbCr, True, False, False)
                AutoCADApp.DocumentManager.MdiActiveDocument.SendStringToExecute("Jacobs_KILLOVERRIDES" & vbCr, True, False, False)
            Next
            w.Close()
            Shell("Notepad.exe " & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "BatchSwitchConfigurationsResult" & Common.Settings.Manager.EvaluateExpression(Settings.Manager.AE.LogFileExtension), AppWinStyle.MaximizedFocus, False)
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub BrowseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseButton.Click

        Dim sFileNames() As String

        Try

            If FilesRadioButton.Checked = True Then
                Dim GetFilesDialog As New Autodesk.AutoCAD.Windows.OpenFileDialog("AE Batch Switch Configurations Utility", "", "DWG", "Select Files", Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.AllowMultiple)

                If GetFilesDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    sFileNames = GetFilesDialog.GetFilenames()
                    Dim sFile As String
                    For Each sFile In sFileNames
                        If sFile <> "" Then
                            If File.Exists(sFile) Then
                                FilesListBox.Items.Add(sFile)
                            End If
                        End If
                    Next
                End If
            Else

                Dim sFolderName As String
                Dim GetFilesDialog As New Autodesk.AutoCAD.Windows.OpenFileDialog("AE Batch Switch Configurations Utility", "Drawings", "DWG", "Select Folders", Autodesk.AutoCAD.Windows.OpenFileDialog.OpenFileDialogFlags.AllowFoldersOnly)

tryagain:

                If GetFilesDialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    sFolderName = GetFilesDialog.Filename()

                    If sFolderName <> "" Then

                        Dim strFileSize As String = ""
                        Dim di As New IO.DirectoryInfo(sFolderName)
                        Dim aryFi As IO.FileInfo()

                        If IncludeSubFoldersCheckBox.Checked = True Then
                            aryFi = di.GetFiles("*.dwg", IO.SearchOption.AllDirectories)
                        Else
                            aryFi = di.GetFiles("*.dwg", IO.SearchOption.TopDirectoryOnly)
                        End If

                        Dim fi As IO.FileInfo

                        If aryFi.Length > 0 Then
                            For Each fi In aryFi
                                FilesListBox.Items.Add(fi.FullName)
                            Next
                        Else
                            Acad_MessageBox("No drawings found. Please select another directory.", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information, , , , , LogName)
                            GoTo tryagain
                        End If

                    End If
                End If
            End If

            FilesListBox.Focus()

            CheckEnableOK()

        Catch ex As Exception

            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Sub CheckEnableOK()
        Try
            If Not String.IsNullOrEmpty(ConfigNameComboBox.SelectedItem.ToString) And
                FilesListBox.Items.Count > 0 Then
                OK_Button.Enabled = True
            Else
                OK_Button.Enabled = False
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        End Try
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        'GetConfigSettings()

        ' Add any initialization after the InitializeComponent() call.
        Dim cDirectoryEntries As Collection = New Collection
        Dim strClient As String = ""

        Try

            sProductName = Settings.Manager.AutoCAD.Name

            GetDirectoryFiles(Settings.Manager.AE.LibraryFolder.CombinePath("client"), cDirectoryEntries)

            ConfigNameComboBox.Items.Clear()

            For Each strFile As String In cDirectoryEntries
                If UBound(strFile.Split(CChar("-"))) = 4 Then   ' It's one of our own with 4 -'s
                    strFile = strFile.Substring(strFile.LastIndexOf("\") + 1)
                    strFile = strFile.Replace(".zip", "")
                    strClient = strFile.Substring(strFile.LastIndexOf("-") + 1)
                    strClient = strClient.Substring(0, strClient.IndexOf("_")).ToLower()
                    If Not strFile.IndexOf("T@") > -1 Then
                        ConfigNameComboBox.Items.Add(strFile)
                    End If
                End If
            Next
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub FilesRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilesRadioButton.CheckedChanged
        Try
            If FilesRadioButton.Checked = True Then
                IncludeSubFoldersCheckBox.Enabled = False
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try

    End Sub

    Private Sub Folders_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Folders.CheckedChanged
        Try
            If Folders.Checked = True Then
                IncludeSubFoldersCheckBox.Enabled = True
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try
    End Sub

    Private Sub ContextMenuStrip1_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip1.ItemClicked
        Try
            If e.ClickedItem.Text = "Select All" Then
                For i As Integer = 0 To FilesListBox.Items.Count - 1
                    FilesListBox.SetSelected(i, True)
                Next
            Else
                Dim i As Integer
                For i = FilesListBox.SelectedItems.Count - 1 To 0 Step -1
                    FilesListBox.Items.Remove(FilesListBox.SelectedItems(i))
                Next
            End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, False, "", LogName)
        End Try
    End Sub

    Private Sub ConfigNameComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConfigNameComboBox.SelectedIndexChanged
        CheckEnableOK()
    End Sub

    Private Sub FilesListBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilesListBox.SelectedIndexChanged
        CheckEnableOK()
    End Sub

    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Private Sub frmBatchApplyTemplateAssociationSelectFilesOrFolders_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        '' Workout out the Dialog Box Title 
        Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
        ' Now that we have things like the AEVersion number and Title display it on the dialog name 
        Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

        RepositionTitle(Me.lblTitle, Me)

    End Sub

    Private Sub BatchApplyTemplateAssociationSelectFilesOrFolders_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub

End Class

