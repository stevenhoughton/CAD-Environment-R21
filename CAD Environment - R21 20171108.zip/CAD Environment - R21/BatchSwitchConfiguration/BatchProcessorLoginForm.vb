Imports AcadApp2 = Autodesk.AutoCAD.ApplicationServices.Application
Imports System.Windows.Forms
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings

Public Class BatchProcessorLoginForm

    Private Shared m_UserTempPath As String
    Private Shared m_file_name As String
    Public Shared sProductName As String
    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Dim mydialog As New BatchApplyTemplateAssociationSelectFilesOrFolders

        Try
            'Remove the log in password by Steven Houghton 14/02/17
            'If PasswordTextBox.Text <> "AELOCKDOWN1" Then
            'Acad_MessageBox("Incorrect password access denied", System.Reflection.MethodBase.GetCurrentMethod.Name() & " in " & System.Reflection.MethodBase.GetCurrentMethod.Module.Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            'Else
            'Me.Close()
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(mydialog)
            'End If
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        Try
            PasswordTextBox.Focus()
            sProductName = Settings.Manager.AutoCAD.Name             ' AcadApp2.GetSystemVariable("ROAMABLEROOTPREFIX").ToString.Split("\")(5)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub Help_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

End Class
