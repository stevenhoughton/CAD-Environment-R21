Imports Microsoft.VisualBasic
Imports System.IO
Imports System.Text
Imports System.Collections.Generic
Imports Microsoft.Win32
Imports acadApp4 = Autodesk.AutoCAD.ApplicationServices.Application
Imports System.Windows.Forms
Imports Jacobs
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.StartUpTab.StartUpSettings))>

Public Class StartUpSettings

    Public ADSiteName As String
    Public AutoCADHasBeenCustomised As Boolean
    Public UseOfficeNetworkFonts As Boolean
    Public NetworkFontsLocation As String
    Public LocalFontsLocation As String
    Public CachedFontsLocation As String
    Public CreateSupportShortCut As Boolean
    Public NetworkSupportLocation As String
    Public NetworkMenuLocation As String
    Public CreateTemplateShortCut As Boolean
    Public NetworkTemplateLocation As String
    Public CreatePlotStyleShortCut As Boolean
    Public NetworkPlotStyleLocation As String
    Public CreatePC3ShortCut As Boolean
    Public NetworkPC3Location As String
    Public CreatePMPShortCut As Boolean
    Public NetworkPMPLocation As String
    Public CreateBlockFinderShortCut As Boolean
    Public NetworkBlockFinderLocation As String
    'Public ResetScaleList As Boolean
    'Public ResetScaleListCivil As Boolean
    ' Public CheckInsUnits As Boolean
    'Public WhenAutoCADStarts As Boolean
    ' Public WhenDrawingIsActivated As Boolean
    '  Public JacobsConfigFile As String
    'Public StartUpLogFile As String
    Public CustomisationLocation As String
    Public Hklm_Keys_ToRemove As New List(Of String)
    Public SystemVariablesToSet As New List(Of String)
    Public EnvironmentVariablesToSet As New List(Of String)
    Public CustomDictionary As String
    Public UseOfficeCustomDictionary As Boolean
    Public SetSaveFidelity As Boolean
    Public RestoreacadCUI As Boolean
    Public ManageCUIs As Boolean
    Public RasterFix As Boolean
    'Public LoadTabs As Boolean
    Public ImpressionsFix As Boolean
    Public NetworkDictionaryLocation As String
    Public ResetScaleListOnDrawingActivate As Boolean
    Public MillimetersOnly As Boolean
    Public MillimetersAndMeters As Boolean
    ' Public ObjectEnablerFolder As String
    Public ProfileName As String
    Public SearchFolder As String
    ' Public WSCURRENT As String
    'Public DCTMAIN As String
    ' Public DYNMODE As Integer
    ' Public INPUTHISTORYMODE As Integer
    'Public CMDECHO As Integer
    'Public NOMUTT As Integer
    'Public OLESTARTUP As Integer
    'Public FILEDIA As Integer
    'Public CMDDIA As Integer
    'Public MAXSORT As Integer
    'Public FONTALT As String
    'Public ATTREQ As Integer
    'Public MAXACTVP As Integer
    'Public VIEWRES As Integer
    'Public MAXHATCH As String
    Public OnCompletionPrompt As String
    'Public FirstTimeUsePage As String
    ' Public RememberFolders As Integer
    '  Public DefaultOutputDevice As String                                   ' <DefaultOutputDevice>Default Windows System Printer.pc3</DefaultOutputDevice>  s
    ' Public CursorSize As Integer                                           ' <CursorSize>5</CursorSize>  i
    '   Public DisplayScrollBars As Boolean                                    ' <DisplayScrollBars>False</DisplayScrollBars> b
    ' Public LayoutDisplayPaper As Boolean '<LayoutDisplayPaper>False</LayoutDisplayPaper> b
    ' Public LayoutDisplayMargins As Boolean '<LayoutDisplayMargins>False</LayoutDisplayMargins> b
    '  Public LayoutDisplayPaperShadow As Boolean '<LayoutDisplayPaperShadow>False</LayoutDisplayPaperShadow> b
    ' Public GraphicsWinModelBackgrndColor As String '<GraphicsWinModelBackgrndColor>Black</GraphicsWinModelBackgrndColor> s
    ' Public ModelCrosshairColor As String '<ModelCrosshairColor>White</ModelCrosshairColor> s
    'Public GraphicsWinLayoutBackgrndColor As String '<GraphicsWinLayoutBackgrndColor>Black</GraphicsWinLayoutBackgrndColor> s
    ' Public LayoutCrosshairColor As String '<LayoutCrosshairColor>White</LayoutCrosshairColor> s
    ' Public DisplayLayoutTabs As Boolean '<DisplayLayoutTabs>True</DisplayLayoutTabs> b
    'Public BEditBackground As String '<BEditBackground>8421504</BEditBackground> b
    '  Public PREVIEWFILTER As Integer '<PREVIEWFILTER>23</PREVIEWFILTER>

End Class
