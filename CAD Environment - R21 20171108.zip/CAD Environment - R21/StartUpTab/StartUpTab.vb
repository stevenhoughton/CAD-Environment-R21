Imports System.Type
Imports System.CLSCompliantAttribute
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Windows.Forms
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD
Imports Autodesk.AutoCAD.ApplicationServices
Imports Microsoft.Win32
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Geometry
Imports Jacobs.AutoCAD.StartUpTab.StartUpSettings
Imports Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension
Imports Jacobs.Common.Core
Imports Jacobs.Common.Settings

Public Class Jacobs_StartUpTab
    Inherits System.Windows.Forms.UserControl

    'Dim Dirty As Boolean = False
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents UseOfficeNetworkFonts_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ScaleListSettings_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents FontSettings_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents DefaultNetworkLocationForFontFiles_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents BrowseForFonts_Button As System.Windows.Forms.Button
    Friend WithEvents ShortCutCreation_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents DefaultNetworkLocationForPC3Files_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworkLocationForPC3Files_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreatePC3ShortCut_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DefaultNetworklocationForPMPFiles_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworklocationForPMPFiles_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreatePMPShortCut_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DefaultNetworkLocationForTemplateFiles_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworkLocationForTemplateFiles_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreateTemplateShortCut_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DefaultNetworklocationForSupportFiles_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworkLocationForSupportFiles_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreateSupportShortCut_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents DefaultNetworkLocationForPlotStyleFiles_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworkLocationForPlotStyleFiles_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreatePlotStyleShortCut_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents DictionarySettings_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents DefaultNetworklocationForOfficeDictionaryFile_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworkLocationForDictionary_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents UseOfficeCustomDictionary_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents EnterpriseCUI_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents EnforceacadCUI_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents MillimetersOnly_RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ResetScaleListOnDrawingActivate_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ManageCuis_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents MenuSettings_GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents BrowseForMenu_Button As System.Windows.Forms.Button
    Friend WithEvents DefaultNetworkLocationForMenuFiles_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents UseOfficeNetworkMenu_CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MillimetersAndMeters_RadioButton As System.Windows.Forms.RadioButton

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.UseOfficeNetworkFonts_CheckBox = New System.Windows.Forms.CheckBox()
        Me.ScaleListSettings_GroupBox = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ResetScaleListOnDrawingActivate_CheckBox = New System.Windows.Forms.CheckBox()
        Me.MillimetersOnly_RadioButton = New System.Windows.Forms.RadioButton()
        Me.FontSettings_GroupBox = New System.Windows.Forms.GroupBox()
        Me.BrowseForFonts_Button = New System.Windows.Forms.Button()
        Me.DefaultNetworkLocationForFontFiles_TextBox = New System.Windows.Forms.TextBox()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.ShortCutCreation_GroupBox = New System.Windows.Forms.GroupBox()
        Me.DefaultNetworkLocationForPlotStyleFiles_Button = New System.Windows.Forms.Button()
        Me.DefaultNetworkLocationForPlotStyleFiles_TextBox = New System.Windows.Forms.TextBox()
        Me.CreatePlotStyleShortCut_CheckBox = New System.Windows.Forms.CheckBox()
        Me.DefaultNetworkLocationForTemplateFiles_Button = New System.Windows.Forms.Button()
        Me.CreatePC3ShortCut_CheckBox = New System.Windows.Forms.CheckBox()
        Me.DefaultNetworkLocationForPC3Files_TextBox = New System.Windows.Forms.TextBox()
        Me.DefaultNetworkLocationForTemplateFiles_TextBox = New System.Windows.Forms.TextBox()
        Me.DefaultNetworkLocationForPC3Files_Button = New System.Windows.Forms.Button()
        Me.CreateTemplateShortCut_CheckBox = New System.Windows.Forms.CheckBox()
        Me.CreatePMPShortCut_CheckBox = New System.Windows.Forms.CheckBox()
        Me.DefaultNetworklocationForSupportFiles_Button = New System.Windows.Forms.Button()
        Me.DefaultNetworklocationForPMPFiles_TextBox = New System.Windows.Forms.TextBox()
        Me.DefaultNetworkLocationForSupportFiles_TextBox = New System.Windows.Forms.TextBox()
        Me.DefaultNetworklocationForPMPFiles_Button = New System.Windows.Forms.Button()
        Me.CreateSupportShortCut_CheckBox = New System.Windows.Forms.CheckBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.DictionarySettings_GroupBox = New System.Windows.Forms.GroupBox()
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button = New System.Windows.Forms.Button()
        Me.DefaultNetworkLocationForDictionary_TextBox = New System.Windows.Forms.TextBox()
        Me.UseOfficeCustomDictionary_CheckBox = New System.Windows.Forms.CheckBox()
        Me.EnterpriseCUI_GroupBox = New System.Windows.Forms.GroupBox()
        Me.ManageCuis_CheckBox = New System.Windows.Forms.CheckBox()
        Me.EnforceacadCUI_CheckBox = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuSettings_GroupBox = New System.Windows.Forms.GroupBox()
        Me.BrowseForMenu_Button = New System.Windows.Forms.Button()
        Me.DefaultNetworkLocationForMenuFiles_TextBox = New System.Windows.Forms.TextBox()
        Me.UseOfficeNetworkMenu_CheckBox = New System.Windows.Forms.CheckBox()
        Me.MillimetersAndMeters_RadioButton = New System.Windows.Forms.RadioButton()
        Me.ScaleListSettings_GroupBox.SuspendLayout()
        Me.FontSettings_GroupBox.SuspendLayout()
        Me.ShortCutCreation_GroupBox.SuspendLayout()
        Me.DictionarySettings_GroupBox.SuspendLayout()
        Me.EnterpriseCUI_GroupBox.SuspendLayout()
        Me.MenuSettings_GroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'UseOfficeNetworkFonts_CheckBox
        '
        Me.UseOfficeNetworkFonts_CheckBox.AutoSize = True
        Me.UseOfficeNetworkFonts_CheckBox.Location = New System.Drawing.Point(14, 22)
        Me.UseOfficeNetworkFonts_CheckBox.Name = "UseOfficeNetworkFonts_CheckBox"
        Me.UseOfficeNetworkFonts_CheckBox.Size = New System.Drawing.Size(253, 21)
        Me.UseOfficeNetworkFonts_CheckBox.TabIndex = 0
        Me.UseOfficeNetworkFonts_CheckBox.Text = "Use Office Network Fonts if present"
        Me.UseOfficeNetworkFonts_CheckBox.UseVisualStyleBackColor = True
        '
        'ScaleListSettings_GroupBox
        '
        Me.ScaleListSettings_GroupBox.Controls.Add(Me.Label2)
        Me.ScaleListSettings_GroupBox.Controls.Add(Me.ResetScaleListOnDrawingActivate_CheckBox)
        Me.ScaleListSettings_GroupBox.Location = New System.Drawing.Point(304, 171)
        Me.ScaleListSettings_GroupBox.Name = "ScaleListSettings_GroupBox"
        Me.ScaleListSettings_GroupBox.Size = New System.Drawing.Size(290, 90)
        Me.ScaleListSettings_GroupBox.TabIndex = 2
        Me.ScaleListSettings_GroupBox.TabStop = False
        Me.ScaleListSettings_GroupBox.Text = "Scale List"
        Me.ScaleListSettings_GroupBox.Visible = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(15, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(269, 46)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "If INSUNITS = 6 a Metre Scale List is imported  else a Millimetre Scales List is " &
    "imported. Unused scales are purged."
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ResetScaleListOnDrawingActivate_CheckBox
        '
        Me.ResetScaleListOnDrawingActivate_CheckBox.AutoSize = True
        Me.ResetScaleListOnDrawingActivate_CheckBox.Location = New System.Drawing.Point(18, 18)
        Me.ResetScaleListOnDrawingActivate_CheckBox.Name = "ResetScaleListOnDrawingActivate_CheckBox"
        Me.ResetScaleListOnDrawingActivate_CheckBox.Size = New System.Drawing.Size(275, 21)
        Me.ResetScaleListOnDrawingActivate_CheckBox.TabIndex = 0
        Me.ResetScaleListOnDrawingActivate_CheckBox.Text = "Reset scale list when drawing activates"
        Me.ResetScaleListOnDrawingActivate_CheckBox.UseVisualStyleBackColor = True
        '
        'MillimetersOnly_RadioButton
        '
        Me.MillimetersOnly_RadioButton.AutoSize = True
        Me.MillimetersOnly_RadioButton.Location = New System.Drawing.Point(553, 378)
        Me.MillimetersOnly_RadioButton.Name = "MillimetersOnly_RadioButton"
        Me.MillimetersOnly_RadioButton.Size = New System.Drawing.Size(128, 21)
        Me.MillimetersOnly_RadioButton.TabIndex = 1
        Me.MillimetersOnly_RadioButton.TabStop = True
        Me.MillimetersOnly_RadioButton.Text = "Millimeters Only"
        Me.MillimetersOnly_RadioButton.UseVisualStyleBackColor = True
        Me.MillimetersOnly_RadioButton.Visible = False
        '
        'FontSettings_GroupBox
        '
        Me.FontSettings_GroupBox.Controls.Add(Me.BrowseForFonts_Button)
        Me.FontSettings_GroupBox.Controls.Add(Me.DefaultNetworkLocationForFontFiles_TextBox)
        Me.FontSettings_GroupBox.Controls.Add(Me.UseOfficeNetworkFonts_CheckBox)
        Me.FontSettings_GroupBox.Location = New System.Drawing.Point(304, 8)
        Me.FontSettings_GroupBox.Name = "FontSettings_GroupBox"
        Me.FontSettings_GroupBox.Size = New System.Drawing.Size(290, 72)
        Me.FontSettings_GroupBox.TabIndex = 0
        Me.FontSettings_GroupBox.TabStop = False
        Me.FontSettings_GroupBox.Text = "Fonts"
        '
        'BrowseForFonts_Button
        '
        Me.BrowseForFonts_Button.Location = New System.Drawing.Point(262, 42)
        Me.BrowseForFonts_Button.Name = "BrowseForFonts_Button"
        Me.BrowseForFonts_Button.Size = New System.Drawing.Size(24, 19)
        Me.BrowseForFonts_Button.TabIndex = 3
        Me.BrowseForFonts_Button.Text = "..."
        Me.BrowseForFonts_Button.UseVisualStyleBackColor = True
        '
        'DefaultNetworkLocationForFontFiles_TextBox
        '
        Me.DefaultNetworkLocationForFontFiles_TextBox.Location = New System.Drawing.Point(14, 41)
        Me.DefaultNetworkLocationForFontFiles_TextBox.Name = "DefaultNetworkLocationForFontFiles_TextBox"
        Me.DefaultNetworkLocationForFontFiles_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForFontFiles_TextBox.TabIndex = 2
        Me.DefaultNetworkLocationForFontFiles_TextBox.Tag = "DefaultNetworkLocationForFontFiles_TextBox"
        '
        'FolderBrowserDialog1
        '
        Me.FolderBrowserDialog1.Tag = "Browser"
        '
        'ShortCutCreation_GroupBox
        '
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForPlotStyleFiles_Button)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForPlotStyleFiles_TextBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.CreatePlotStyleShortCut_CheckBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForTemplateFiles_Button)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.CreatePC3ShortCut_CheckBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForPC3Files_TextBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForTemplateFiles_TextBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForPC3Files_Button)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.CreateTemplateShortCut_CheckBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.CreatePMPShortCut_CheckBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworklocationForSupportFiles_Button)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworklocationForPMPFiles_TextBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworkLocationForSupportFiles_TextBox)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.DefaultNetworklocationForPMPFiles_Button)
        Me.ShortCutCreation_GroupBox.Controls.Add(Me.CreateSupportShortCut_CheckBox)
        Me.ShortCutCreation_GroupBox.Location = New System.Drawing.Point(4, 8)
        Me.ShortCutCreation_GroupBox.Name = "ShortCutCreation_GroupBox"
        Me.ShortCutCreation_GroupBox.Size = New System.Drawing.Size(290, 274)
        Me.ShortCutCreation_GroupBox.TabIndex = 1
        Me.ShortCutCreation_GroupBox.TabStop = False
        Me.ShortCutCreation_GroupBox.Text = "Short Cuts"
        '
        'DefaultNetworkLocationForPlotStyleFiles_Button
        '
        Me.DefaultNetworkLocationForPlotStyleFiles_Button.Location = New System.Drawing.Point(260, 138)
        Me.DefaultNetworkLocationForPlotStyleFiles_Button.Name = "DefaultNetworkLocationForPlotStyleFiles_Button"
        Me.DefaultNetworkLocationForPlotStyleFiles_Button.Size = New System.Drawing.Size(24, 19)
        Me.DefaultNetworkLocationForPlotStyleFiles_Button.TabIndex = 19
        Me.DefaultNetworkLocationForPlotStyleFiles_Button.Text = "..."
        Me.DefaultNetworkLocationForPlotStyleFiles_Button.UseVisualStyleBackColor = True
        '
        'DefaultNetworkLocationForPlotStyleFiles_TextBox
        '
        Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.Location = New System.Drawing.Point(12, 137)
        Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.Name = "DefaultNetworkLocationForPlotStyleFiles_TextBox"
        Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.TabIndex = 18
        Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.Tag = "DefaultNetworkLocationForPlotStyleFiles_TextBox"
        '
        'CreatePlotStyleShortCut_CheckBox
        '
        Me.CreatePlotStyleShortCut_CheckBox.AutoSize = True
        Me.CreatePlotStyleShortCut_CheckBox.Location = New System.Drawing.Point(12, 118)
        Me.CreatePlotStyleShortCut_CheckBox.Name = "CreatePlotStyleShortCut_CheckBox"
        Me.CreatePlotStyleShortCut_CheckBox.Size = New System.Drawing.Size(261, 21)
        Me.CreatePlotStyleShortCut_CheckBox.TabIndex = 16
        Me.CreatePlotStyleShortCut_CheckBox.Text = "Create Plot Style Short Cut if present"
        Me.CreatePlotStyleShortCut_CheckBox.UseVisualStyleBackColor = True
        '
        'DefaultNetworkLocationForTemplateFiles_Button
        '
        Me.DefaultNetworkLocationForTemplateFiles_Button.Location = New System.Drawing.Point(260, 90)
        Me.DefaultNetworkLocationForTemplateFiles_Button.Name = "DefaultNetworkLocationForTemplateFiles_Button"
        Me.DefaultNetworkLocationForTemplateFiles_Button.Size = New System.Drawing.Size(24, 19)
        Me.DefaultNetworkLocationForTemplateFiles_Button.TabIndex = 15
        Me.DefaultNetworkLocationForTemplateFiles_Button.Text = "..."
        Me.DefaultNetworkLocationForTemplateFiles_Button.UseVisualStyleBackColor = True
        '
        'CreatePC3ShortCut_CheckBox
        '
        Me.CreatePC3ShortCut_CheckBox.AutoSize = True
        Me.CreatePC3ShortCut_CheckBox.Location = New System.Drawing.Point(12, 166)
        Me.CreatePC3ShortCut_CheckBox.Name = "CreatePC3ShortCut_CheckBox"
        Me.CreatePC3ShortCut_CheckBox.Size = New System.Drawing.Size(165, 21)
        Me.CreatePC3ShortCut_CheckBox.TabIndex = 0
        Me.CreatePC3ShortCut_CheckBox.Text = "Create PC3 Short Cut"
        Me.CreatePC3ShortCut_CheckBox.UseVisualStyleBackColor = True
        '
        'DefaultNetworkLocationForPC3Files_TextBox
        '
        Me.DefaultNetworkLocationForPC3Files_TextBox.Location = New System.Drawing.Point(12, 185)
        Me.DefaultNetworkLocationForPC3Files_TextBox.Name = "DefaultNetworkLocationForPC3Files_TextBox"
        Me.DefaultNetworkLocationForPC3Files_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForPC3Files_TextBox.TabIndex = 2
        Me.DefaultNetworkLocationForPC3Files_TextBox.Tag = "DefaultNetworkLocationForFonts_TextBox"
        '
        'DefaultNetworkLocationForTemplateFiles_TextBox
        '
        Me.DefaultNetworkLocationForTemplateFiles_TextBox.Location = New System.Drawing.Point(12, 89)
        Me.DefaultNetworkLocationForTemplateFiles_TextBox.Name = "DefaultNetworkLocationForTemplateFiles_TextBox"
        Me.DefaultNetworkLocationForTemplateFiles_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForTemplateFiles_TextBox.TabIndex = 14
        Me.DefaultNetworkLocationForTemplateFiles_TextBox.Tag = "DefaultNetworkLocationForTemplateFiles_TextBox"
        '
        'DefaultNetworkLocationForPC3Files_Button
        '
        Me.DefaultNetworkLocationForPC3Files_Button.Location = New System.Drawing.Point(260, 186)
        Me.DefaultNetworkLocationForPC3Files_Button.Name = "DefaultNetworkLocationForPC3Files_Button"
        Me.DefaultNetworkLocationForPC3Files_Button.Size = New System.Drawing.Size(24, 19)
        Me.DefaultNetworkLocationForPC3Files_Button.TabIndex = 3
        Me.DefaultNetworkLocationForPC3Files_Button.Text = "..."
        Me.DefaultNetworkLocationForPC3Files_Button.UseVisualStyleBackColor = True
        '
        'CreateTemplateShortCut_CheckBox
        '
        Me.CreateTemplateShortCut_CheckBox.AutoSize = True
        Me.CreateTemplateShortCut_CheckBox.Location = New System.Drawing.Point(12, 70)
        Me.CreateTemplateShortCut_CheckBox.Name = "CreateTemplateShortCut_CheckBox"
        Me.CreateTemplateShortCut_CheckBox.Size = New System.Drawing.Size(261, 21)
        Me.CreateTemplateShortCut_CheckBox.TabIndex = 12
        Me.CreateTemplateShortCut_CheckBox.Text = "Create Template Short Cut if present"
        Me.CreateTemplateShortCut_CheckBox.UseVisualStyleBackColor = True
        '
        'CreatePMPShortCut_CheckBox
        '
        Me.CreatePMPShortCut_CheckBox.AutoSize = True
        Me.CreatePMPShortCut_CheckBox.Location = New System.Drawing.Point(13, 214)
        Me.CreatePMPShortCut_CheckBox.Name = "CreatePMPShortCut_CheckBox"
        Me.CreatePMPShortCut_CheckBox.Size = New System.Drawing.Size(231, 21)
        Me.CreatePMPShortCut_CheckBox.TabIndex = 4
        Me.CreatePMPShortCut_CheckBox.Text = "Create PMP Short Cut if present"
        Me.CreatePMPShortCut_CheckBox.UseVisualStyleBackColor = True
        '
        'DefaultNetworklocationForSupportFiles_Button
        '
        Me.DefaultNetworklocationForSupportFiles_Button.Location = New System.Drawing.Point(260, 42)
        Me.DefaultNetworklocationForSupportFiles_Button.Name = "DefaultNetworklocationForSupportFiles_Button"
        Me.DefaultNetworklocationForSupportFiles_Button.Size = New System.Drawing.Size(24, 19)
        Me.DefaultNetworklocationForSupportFiles_Button.TabIndex = 11
        Me.DefaultNetworklocationForSupportFiles_Button.Text = "..."
        Me.DefaultNetworklocationForSupportFiles_Button.UseVisualStyleBackColor = True
        '
        'DefaultNetworklocationForPMPFiles_TextBox
        '
        Me.DefaultNetworklocationForPMPFiles_TextBox.Location = New System.Drawing.Point(13, 233)
        Me.DefaultNetworklocationForPMPFiles_TextBox.Name = "DefaultNetworklocationForPMPFiles_TextBox"
        Me.DefaultNetworklocationForPMPFiles_TextBox.Size = New System.Drawing.Size(245, 22)
        Me.DefaultNetworklocationForPMPFiles_TextBox.TabIndex = 6
        Me.DefaultNetworklocationForPMPFiles_TextBox.Tag = "DefaultNetworklocationForPMPFiles_TextBox"
        '
        'DefaultNetworkLocationForSupportFiles_TextBox
        '
        Me.DefaultNetworkLocationForSupportFiles_TextBox.Location = New System.Drawing.Point(12, 41)
        Me.DefaultNetworkLocationForSupportFiles_TextBox.Name = "DefaultNetworkLocationForSupportFiles_TextBox"
        Me.DefaultNetworkLocationForSupportFiles_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForSupportFiles_TextBox.TabIndex = 10
        Me.DefaultNetworkLocationForSupportFiles_TextBox.Tag = "DefaultNetworkLocationForSupportFiles_TextBox"
        '
        'DefaultNetworklocationForPMPFiles_Button
        '
        Me.DefaultNetworklocationForPMPFiles_Button.Location = New System.Drawing.Point(260, 234)
        Me.DefaultNetworklocationForPMPFiles_Button.Name = "DefaultNetworklocationForPMPFiles_Button"
        Me.DefaultNetworklocationForPMPFiles_Button.Size = New System.Drawing.Size(24, 19)
        Me.DefaultNetworklocationForPMPFiles_Button.TabIndex = 7
        Me.DefaultNetworklocationForPMPFiles_Button.Text = "..."
        Me.DefaultNetworklocationForPMPFiles_Button.UseVisualStyleBackColor = True
        '
        'CreateSupportShortCut_CheckBox
        '
        Me.CreateSupportShortCut_CheckBox.AutoSize = True
        Me.CreateSupportShortCut_CheckBox.Location = New System.Drawing.Point(13, 22)
        Me.CreateSupportShortCut_CheckBox.Name = "CreateSupportShortCut_CheckBox"
        Me.CreateSupportShortCut_CheckBox.Size = New System.Drawing.Size(252, 21)
        Me.CreateSupportShortCut_CheckBox.TabIndex = 8
        Me.CreateSupportShortCut_CheckBox.Text = "Create Support Short Cut if present"
        Me.CreateSupportShortCut_CheckBox.UseVisualStyleBackColor = True
        '
        'DictionarySettings_GroupBox
        '
        Me.DictionarySettings_GroupBox.Controls.Add(Me.DefaultNetworklocationForOfficeDictionaryFile_Button)
        Me.DictionarySettings_GroupBox.Controls.Add(Me.DefaultNetworkLocationForDictionary_TextBox)
        Me.DictionarySettings_GroupBox.Controls.Add(Me.UseOfficeCustomDictionary_CheckBox)
        Me.DictionarySettings_GroupBox.Location = New System.Drawing.Point(4, 290)
        Me.DictionarySettings_GroupBox.Name = "DictionarySettings_GroupBox"
        Me.DictionarySettings_GroupBox.Size = New System.Drawing.Size(290, 69)
        Me.DictionarySettings_GroupBox.TabIndex = 5
        Me.DictionarySettings_GroupBox.TabStop = False
        Me.DictionarySettings_GroupBox.Text = "Dictionary"
        '
        'DefaultNetworklocationForOfficeDictionaryFile_Button
        '
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button.Location = New System.Drawing.Point(260, 42)
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button.Name = "DefaultNetworklocationForOfficeDictionaryFile_Button"
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button.Size = New System.Drawing.Size(24, 19)
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button.TabIndex = 3
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button.Text = "..."
        Me.DefaultNetworklocationForOfficeDictionaryFile_Button.UseVisualStyleBackColor = True
        '
        'DefaultNetworkLocationForDictionary_TextBox
        '
        Me.DefaultNetworkLocationForDictionary_TextBox.Location = New System.Drawing.Point(14, 41)
        Me.DefaultNetworkLocationForDictionary_TextBox.Name = "DefaultNetworkLocationForDictionary_TextBox"
        Me.DefaultNetworkLocationForDictionary_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForDictionary_TextBox.TabIndex = 2
        Me.DefaultNetworkLocationForDictionary_TextBox.Tag = "DefaultNetworkLocationForDictionary_TextBox"
        '
        'UseOfficeCustomDictionary_CheckBox
        '
        Me.UseOfficeCustomDictionary_CheckBox.AutoSize = True
        Me.UseOfficeCustomDictionary_CheckBox.Location = New System.Drawing.Point(14, 19)
        Me.UseOfficeCustomDictionary_CheckBox.Name = "UseOfficeCustomDictionary_CheckBox"
        Me.UseOfficeCustomDictionary_CheckBox.Size = New System.Drawing.Size(277, 21)
        Me.UseOfficeCustomDictionary_CheckBox.TabIndex = 0
        Me.UseOfficeCustomDictionary_CheckBox.Text = "Use Office Custom Dictionary if present"
        Me.UseOfficeCustomDictionary_CheckBox.UseVisualStyleBackColor = True
        '
        'EnterpriseCUI_GroupBox
        '
        Me.EnterpriseCUI_GroupBox.Controls.Add(Me.ManageCuis_CheckBox)
        Me.EnterpriseCUI_GroupBox.Controls.Add(Me.EnforceacadCUI_CheckBox)
        Me.EnterpriseCUI_GroupBox.Location = New System.Drawing.Point(304, 287)
        Me.EnterpriseCUI_GroupBox.Name = "EnterpriseCUI_GroupBox"
        Me.EnterpriseCUI_GroupBox.Size = New System.Drawing.Size(290, 72)
        Me.EnterpriseCUI_GroupBox.TabIndex = 19
        Me.EnterpriseCUI_GroupBox.TabStop = False
        Me.EnterpriseCUI_GroupBox.Text = "Enterprise CUI"
        Me.EnterpriseCUI_GroupBox.Visible = False
        '
        'ManageCuis_CheckBox
        '
        Me.ManageCuis_CheckBox.AutoSize = True
        Me.ManageCuis_CheckBox.Location = New System.Drawing.Point(14, 41)
        Me.ManageCuis_CheckBox.Name = "ManageCuis_CheckBox"
        Me.ManageCuis_CheckBox.Size = New System.Drawing.Size(114, 21)
        Me.ManageCuis_CheckBox.TabIndex = 1
        Me.ManageCuis_CheckBox.Text = "Manage CUIs"
        Me.ManageCuis_CheckBox.UseVisualStyleBackColor = True
        '
        'EnforceacadCUI_CheckBox
        '
        Me.EnforceacadCUI_CheckBox.AutoSize = True
        Me.EnforceacadCUI_CheckBox.Location = New System.Drawing.Point(14, 18)
        Me.EnforceacadCUI_CheckBox.Name = "EnforceacadCUI_CheckBox"
        Me.EnforceacadCUI_CheckBox.Size = New System.Drawing.Size(141, 21)
        Me.EnforceacadCUI_CheckBox.TabIndex = 0
        Me.EnforceacadCUI_CheckBox.Text = "Enforce acad CUI"
        Me.EnforceacadCUI_CheckBox.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(144, 365)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(385, 42)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Changes made in this tab will not be implemented until AutoCAD is restarted."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MenuSettings_GroupBox
        '
        Me.MenuSettings_GroupBox.Controls.Add(Me.BrowseForMenu_Button)
        Me.MenuSettings_GroupBox.Controls.Add(Me.DefaultNetworkLocationForMenuFiles_TextBox)
        Me.MenuSettings_GroupBox.Controls.Add(Me.UseOfficeNetworkMenu_CheckBox)
        Me.MenuSettings_GroupBox.Location = New System.Drawing.Point(304, 86)
        Me.MenuSettings_GroupBox.Name = "MenuSettings_GroupBox"
        Me.MenuSettings_GroupBox.Size = New System.Drawing.Size(290, 72)
        Me.MenuSettings_GroupBox.TabIndex = 22
        Me.MenuSettings_GroupBox.TabStop = False
        Me.MenuSettings_GroupBox.Text = "Office Menu"
        '
        'BrowseForMenu_Button
        '
        Me.BrowseForMenu_Button.Location = New System.Drawing.Point(262, 42)
        Me.BrowseForMenu_Button.Name = "BrowseForMenu_Button"
        Me.BrowseForMenu_Button.Size = New System.Drawing.Size(24, 19)
        Me.BrowseForMenu_Button.TabIndex = 3
        Me.BrowseForMenu_Button.Text = "..."
        Me.BrowseForMenu_Button.UseVisualStyleBackColor = True
        '
        'DefaultNetworkLocationForMenuFiles_TextBox
        '
        Me.DefaultNetworkLocationForMenuFiles_TextBox.Location = New System.Drawing.Point(14, 41)
        Me.DefaultNetworkLocationForMenuFiles_TextBox.Name = "DefaultNetworkLocationForMenuFiles_TextBox"
        Me.DefaultNetworkLocationForMenuFiles_TextBox.Size = New System.Drawing.Size(246, 22)
        Me.DefaultNetworkLocationForMenuFiles_TextBox.TabIndex = 2
        Me.DefaultNetworkLocationForMenuFiles_TextBox.Tag = "DefaultNetworkLocationForMenuFiles_TextBox"
        '
        'UseOfficeNetworkMenu_CheckBox
        '
        Me.UseOfficeNetworkMenu_CheckBox.AutoSize = True
        Me.UseOfficeNetworkMenu_CheckBox.Location = New System.Drawing.Point(14, 22)
        Me.UseOfficeNetworkMenu_CheckBox.Name = "UseOfficeNetworkMenu_CheckBox"
        Me.UseOfficeNetworkMenu_CheckBox.Size = New System.Drawing.Size(198, 21)
        Me.UseOfficeNetworkMenu_CheckBox.TabIndex = 0
        Me.UseOfficeNetworkMenu_CheckBox.Text = "Use Office Menu if present"
        Me.UseOfficeNetworkMenu_CheckBox.UseVisualStyleBackColor = True
        '
        'MillimetersAndMeters_RadioButton
        '
        Me.MillimetersAndMeters_RadioButton.AutoSize = True
        Me.MillimetersAndMeters_RadioButton.Location = New System.Drawing.Point(678, 378)
        Me.MillimetersAndMeters_RadioButton.Name = "MillimetersAndMeters_RadioButton"
        Me.MillimetersAndMeters_RadioButton.Size = New System.Drawing.Size(105, 21)
        Me.MillimetersAndMeters_RadioButton.TabIndex = 2
        Me.MillimetersAndMeters_RadioButton.TabStop = True
        Me.MillimetersAndMeters_RadioButton.Text = "Meters Only"
        Me.MillimetersAndMeters_RadioButton.UseVisualStyleBackColor = True
        Me.MillimetersAndMeters_RadioButton.Visible = False
        '
        'Jacobs_StartUpTab
        '
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Menu
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Controls.Add(Me.MillimetersAndMeters_RadioButton)
        Me.Controls.Add(Me.MenuSettings_GroupBox)
        Me.Controls.Add(Me.MillimetersOnly_RadioButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DictionarySettings_GroupBox)
        Me.Controls.Add(Me.EnterpriseCUI_GroupBox)
        Me.Controls.Add(Me.ShortCutCreation_GroupBox)
        Me.Controls.Add(Me.FontSettings_GroupBox)
        Me.Controls.Add(Me.ScaleListSettings_GroupBox)
        Me.Name = "Jacobs_StartUpTab"
        Me.Size = New System.Drawing.Size(928, 413)
        Me.ScaleListSettings_GroupBox.ResumeLayout(False)
        Me.ScaleListSettings_GroupBox.PerformLayout()
        Me.FontSettings_GroupBox.ResumeLayout(False)
        Me.FontSettings_GroupBox.PerformLayout()
        Me.ShortCutCreation_GroupBox.ResumeLayout(False)
        Me.ShortCutCreation_GroupBox.PerformLayout()
        Me.DictionarySettings_GroupBox.ResumeLayout(False)
        Me.DictionarySettings_GroupBox.PerformLayout()
        Me.EnterpriseCUI_GroupBox.ResumeLayout(False)
        Me.EnterpriseCUI_GroupBox.PerformLayout()
        Me.MenuSettings_GroupBox.ResumeLayout(False)
        Me.MenuSettings_GroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Public Sub OnOk()

        RecordUserSettings()

    End Sub

    Sub RecordUserSettings()

        Try

            '' get some AutoCAD config
            Dim acad As New Manager.AutoCADProduct()

            '' Clear acad object
            Properties.SetProperties(acad, Nothing)

            acad.Name = Settings.Manager.AutoCAD.Name
            acad.UseOfficeNetworkFonts = UseOfficeNetworkFonts_CheckBox.Checked.ToString.IsTrue
            acad.UseOfficeNetworkMenu = UseOfficeNetworkMenu_CheckBox.Checked.ToString.IsTrue
            acad.CreateSupportShortCut = CreateSupportShortCut_CheckBox.Checked.ToString.IsTrue
            acad.CreateTemplateShortCut = CreateTemplateShortCut_CheckBox.Checked.ToString.IsTrue
            acad.CreatePC3ShortCut = CreatePC3ShortCut_CheckBox.Checked.ToString.IsTrue
            acad.CreatePMPShortCut = CreatePMPShortCut_CheckBox.Checked.ToString.IsTrue
            acad.CreatePlotStyleShortCut = CreatePlotStyleShortCut_CheckBox.Checked.ToString.IsTrue
            acad.NetworkSupportLocation = DefaultNetworkLocationForSupportFiles_TextBox.Text
            acad.NetworkMenuLocation = DefaultNetworkLocationForMenuFiles_TextBox.Text
            acad.NetworkTemplateLocation = DefaultNetworkLocationForTemplateFiles_TextBox.Text
            acad.NetworkPMPLocation = DefaultNetworklocationForPMPFiles_TextBox.Text
            acad.NetworkPC3Location = DefaultNetworkLocationForPC3Files_TextBox.Text
            acad.NetworkPlotStyleLocation = DefaultNetworkLocationForPlotStyleFiles_TextBox.Text
            acad.NetworkFontsLocation = DefaultNetworkLocationForFontFiles_TextBox.Text
            acad.ResetScaleListOnDrawingActivate = ResetScaleListOnDrawingActivate_CheckBox.Checked.ToString.IsTrue
            acad.MillimetresOnly = MillimetersOnly_RadioButton.Checked.ToString.IsTrue
            acad.MillimetresAndMetres = MillimetersAndMeters_RadioButton.Checked.ToString.IsTrue
            acad.RestoreacadCUI = EnforceacadCUI_CheckBox.Checked.ToString.IsTrue
            acad.ManageCUIs = ManageCuis_CheckBox.Checked.ToString.IsTrue

            acad.CustomDictionary = Path.GetFileName(DefaultNetworkLocationForDictionary_TextBox.Text)
            acad.NetworkDictionaryLocation = Path.GetDirectoryName(DefaultNetworkLocationForDictionary_TextBox.Text)

            acad.UseOfficeCustomDictionary = UseOfficeCustomDictionary_CheckBox.Checked.ToString.IsTrue

            Settings.PartialSettingsSaveacad(acad)

        Catch ex As Exception

        End Try

    End Sub

    Public Sub OnCancel()

    End Sub

    Public Sub OnApply()

        RecordUserSettings()

    End Sub
    Public Sub OnHelp()

        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub

    Public Shared Sub DoIt()



        AddHandler Autodesk.AutoCAD.ApplicationServices.Application.DisplayingOptionDialog, AddressOf Application_TabbedDialog
        '        sProductName = RTrim(Split(acadApp.MainWindow.Text, "-")(0))

        'sProductName = acadApp6.GetSystemVariable("ROAMABLEROOTPREFIX").ToString.Split("\")(5)
        '    If UCase(sProductName) = "C3D 2008" Then
        '        sProductName = "AutoCAD Civil 3D 2008"
        '    End If

        '    sProgramFilesFolder = My.Computer.FileSystem.SpecialDirectories.ProgramFiles

        '    Dim sProductShortname As String = "acad2008"
        '    Select Case UCase(sProductName)
        '        Case Is = UCase("AutoCAD 2008")
        '            sProductShortname = "acad2008"
        '        Case Is = UCase("AutoCAD Civil 3D 2008")
        '            sProductShortname = "acadCIVIL3D2008"
        '        Case Is = UCase("AutoCAD Map 3D 2008")
        '            sProductShortname = "acadMAP3D2008"
        '    End Select

    End Sub

    Private Shared Sub Application_TabbedDialog(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.TabbedDialogEventArgs)



        Dim ctrl As Jacobs_StartUpTab = New Jacobs_StartUpTab()

        e.AddTab("Jacobs Customisation",
                     New Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension _
                     (ctrl,
                         New Autodesk.AutoCAD.ApplicationServices.TabbedDialogAction(AddressOf ctrl.OnOk),
                         New Autodesk.AutoCAD.ApplicationServices.TabbedDialogAction(AddressOf ctrl.OnCancel),
                         New Autodesk.AutoCAD.ApplicationServices.TabbedDialogAction(AddressOf ctrl.OnHelp),
                         New Autodesk.AutoCAD.ApplicationServices.TabbedDialogAction(AddressOf ctrl.OnApply)
                     )
                )

        'Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(ctrl, True)

    End Sub

    Private Sub TabExtension_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load



        'GetConfigSettings()

        ToolTip1.SetToolTip(UseOfficeNetworkFonts_CheckBox, "Every time AutoCAD is opened all font files in the location below " & vbCr &
                                                            "will be copied to the AutoCAD fonts folder (if path is present)")

        ToolTip1.SetToolTip(UseOfficeNetworkMenu_CheckBox, "Every time AutoCAD is opened all Office.* files in the location below " & vbCr &
                                                    "will be copied to the AutoCAD support folder (if path is present)")

        ToolTip1.SetToolTip(CreatePC3ShortCut_CheckBox, "Every time AutoCAD is opened a shortcut to the Plotter " & vbCr &
                                                        "location below will be created (or deleted if path not present)")

        ToolTip1.SetToolTip(CreatePMPShortCut_CheckBox, "Every time AutoCAD is opened a shortcut to the Plotter Paper Sizes" & vbCr &
                                                        "location below will be created (or deleted if path not present)")

        ToolTip1.SetToolTip(CreateSupportShortCut_CheckBox, "Every time AutoCAD is opened a shortcut to the Support " & vbCr &
                                                            "location below will be created (or deleted if path not present)")

        ToolTip1.SetToolTip(CreateTemplateShortCut_CheckBox, "Every time AutoCAD is opened a shortcut to the Template " & vbCr &
                                                             "location below will be created (or deleted if path not present)")

        ToolTip1.SetToolTip(CreatePlotStyleShortCut_CheckBox, "Every time AutoCAD is opened shortcut to the Plot Styles " & vbCr &
                                                              "location below will be created (or deleted if path not present)")

        ToolTip1.SetToolTip(UseOfficeCustomDictionary_CheckBox, "Every time AutoCAD is opened the DCTCUST system variable will" & vbCr &
                                                                "be set to the value below if a Sample.cus file exists there")

        ToolTip1.SetToolTip(ResetScaleListOnDrawingActivate_CheckBox, "Every time a drawing is activated  all unused scales will be " & vbCr &
                                                                      "deleted and a new set of Jacobs standard scales will be created.")

        ToolTip1.SetToolTip(MillimetersOnly_RadioButton, "If the Reset Scale List when drawing activates check box it ticked" & vbCr &
                                                         "a new set of Jacobs standard Millimeter scales will be created.")

        ToolTip1.SetToolTip(MillimetersAndMeters_RadioButton, "If the Reset Scale List when drawing activates check box it ticked" & vbCr &
                                                         "a new set of Jacobs standard Millimeter and Meter scales will be created.")

        'ToolTip1.SetToolTip(TurnOffSaveFidelity_CheckBox, ("Every time AutoCAD is opened the SaveFidelity system" & vbCr & _
        '                                                   "variable will be set to 0. Refer to help file for more information."))

        ToolTip1.SetToolTip(EnforceacadCUI_CheckBox, ("Every time AutoCAD is opened the Jacobs cached version of the acad.CUI" & vbCr &
                                                          "file will be checked against the running version. If they are different" & vbCrLf &
                                                          "then the running version will be backed up and the cached version will be used."))

        ToolTip1.SetToolTip(ManageCuis_CheckBox, ("Every time AutoCAD is opened the acad.CUI will be set to Enterprise" & vbCr &
                                                  "And the Jacobs Custom.CUI will be set to MAIN"))

        'ToolTip1.SetToolTip(CheckINSUNITS_CheckBox, "Every time a drawing is activated INSUNITS will be checked to see if it's Meters" & vbCr & _
        '                                            "or Millimeters. If the drawing is not set to one of those measurement units" & vbCr & _
        '                                            "a dialog will appear giving users the option to set it or ignore it.")

        'ToolTip1.SetToolTip(LoadDrawingTabs_RadioButton, ("Every time AutoCAD is opened the Drawing Tabs will be displayed"))

        'ToolTip1.SetToolTip(UnLoadDrawingTabs_RadioButton, ("Every time AutoCAD is opened the Drawing Tabs will NOT be displayed"))


        'ToolTip1.SetToolTip(WhenAutoCADStarts_RadioButton, "Every time AutoCAD is opened all LSP,FAS and VLX" & vbCr & _
        '                                                   "files in the Jacobs Customisation area will be loaded")

        'ToolTip1.SetToolTip(WhenDrawingIsActivated_RadioButton, "Every time a drawing is activated all LSP,FAS and VLX" & vbCr & _
        '                                                        "files in the Jacobs Customisation area will be loaded")

        'If File.Exists(AE.Config.AppSettings.UserSettingsFile) Then
        '    Settings = LoadXML(Of ApplicationSettings)(AE.Config.AppSettings.UserSettingsFile)
        'Else
        '    Settings = CreateXMLFile()
        'End If

        UseOfficeNetworkFonts_CheckBox.Checked = Settings.Manager.AutoCAD.UseOfficeNetworkFonts
        UseOfficeNetworkMenu_CheckBox.Checked = Settings.Manager.AutoCAD.UseOfficeNetworkMenu

        CreateSupportShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreateSupportShortCut
        CreateTemplateShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreateTemplateShortCut
        CreatePC3ShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreatePC3ShortCut
        CreatePMPShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreatePMPShortCut
        CreatePlotStyleShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreatePlotStyleShortCut

        DefaultNetworkLocationForSupportFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkSupportLocation
        DefaultNetworkLocationForMenuFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkMenuLocation
        DefaultNetworkLocationForTemplateFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkTemplateLocation
        DefaultNetworklocationForPMPFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkPMPLocation
        DefaultNetworkLocationForPC3Files_TextBox.Text = Settings.Manager.AutoCAD.NetworkPC3Location
        DefaultNetworkLocationForPlotStyleFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkPlotStyleLocation
        DefaultNetworkLocationForFontFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkFontsLocation
        DefaultNetworkLocationForDictionary_TextBox.Text = Settings.Manager.AutoCAD.NetworkDictionaryLocation.CombinePath(Settings.Manager.AutoCAD.CustomDictionary)

        ResetScaleListOnDrawingActivate_CheckBox.Checked = Settings.Manager.AutoCAD.ResetScaleListOnDrawingActivate
        MillimetersOnly_RadioButton.Checked = Settings.Manager.AutoCAD.MillimetresOnly
        MillimetersAndMeters_RadioButton.Checked = Settings.Manager.AutoCAD.MillimetresAndMetres

        'ResetScaleList_CheckBox.Checked = AE.Config.AutoCAD.ResetScaleList
        'ResetScaleListCivil_CheckBox.Checked = AE.Config.AutoCAD.ResetScaleListCivil
        'CheckINSUNITS_CheckBox.Checked = AE.Config.AutoCAD.CheckInsUnits
        'WhenAutoCADStarts_RadioButton.Checked = AE.Config.AutoCAD.WhenAutoCADStarts
        'WhenDrawingIsActivated_RadioButton.Checked = AE.Config.AutoCAD.WhenDrawingIsActivated
        ' TurnOffSaveFidelity_CheckBox.Checked = AE.Config.AutoCAD.SetSaveFidelity
        EnforceacadCUI_CheckBox.Checked = Settings.Manager.AutoCAD.RestoreacadCUI
        ManageCuis_CheckBox.Checked = Settings.Manager.AutoCAD.ManageCUIs

        UseOfficeCustomDictionary_CheckBox.Checked = Settings.Manager.AutoCAD.UseOfficeCustomDictionary

        'If AE.Config.AutoCAD.LoadTabs = True Then
        '    LoadDrawingTabs_RadioButton.Checked = True
        '    UnLoadDrawingTabs_RadioButton.Checked = False
        'Else
        '    LoadDrawingTabs_RadioButton.Checked = False
        '    UnLoadDrawingTabs_RadioButton.Checked = True
        'End If

        If ResetScaleListOnDrawingActivate_CheckBox.Checked = True Then
            MillimetersOnly_RadioButton.Enabled = True
            MillimetersAndMeters_RadioButton.Enabled = True
        Else
            MillimetersOnly_RadioButton.Enabled = False
            MillimetersAndMeters_RadioButton.Enabled = False
        End If
    End Sub
    Private Sub DefaultNetworkLocationForPC3Files_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForPC3Files_Button.Click

        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForPC3Files_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForPC3Files_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If

    End Sub
    Private Sub DefaultNetworklocationForPMPFiles_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworklocationForPMPFiles_Button.Click

        '     FolderBrowserDialog1.ShowDialog()
        '  Me.DefaultNetworklocationForPMPFiles_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworklocationForPMPFiles_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If

    End Sub
    Private Sub DefaultNetworklocationForSupportFiles_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworklocationForSupportFiles_Button.Click
        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForSupportFiles_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForSupportFiles_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub
    Private Sub DefaultNetworkLocationForTemplateFiles_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForTemplateFiles_Button.Click
        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForTemplateFiles_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForTemplateFiles_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub
    Private Sub DefaultNetworkLocationForPlotStyleFiles_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForPlotStyleFiles_Button.Click
        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForPlotStyleFiles_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub
    Private Sub DefaultNetworkLocationForFonts_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForFontFiles_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForFontFiles_TextBox, DefaultNetworkLocationForFontFiles_TextBox.Text)
    End Sub

    Private Sub DefaultNetworkLocationForMenu_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForMenuFiles_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForMenuFiles_TextBox, DefaultNetworkLocationForMenuFiles_TextBox.Text)
    End Sub

    Private Sub DefaultNetworkLocationForPC3Files_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForPC3Files_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForPC3Files_TextBox, DefaultNetworkLocationForPC3Files_TextBox.Text)
    End Sub
    Private Sub DefaultNetworklocationForPMPFiles_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworklocationForPMPFiles_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworklocationForPMPFiles_TextBox, DefaultNetworklocationForPMPFiles_TextBox.Text)
    End Sub

    Private Sub DefaultNetworkLocationForSupportFiles_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForSupportFiles_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForSupportFiles_TextBox, DefaultNetworkLocationForSupportFiles_TextBox.Text)
    End Sub

    Private Sub DefaultNetworkLocationForTemplateFiles_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForTemplateFiles_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForTemplateFiles_TextBox, DefaultNetworkLocationForTemplateFiles_TextBox.Text)
    End Sub

    Private Sub DefaultNetworkLocationForPlotStyleFiles_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForPlotStyleFiles_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForPlotStyleFiles_TextBox, DefaultNetworkLocationForPlotStyleFiles_TextBox.Text)
    End Sub

    Private Sub DefaultNetworkLocationForDictionary_TextBox_MouseHover(ByVal sender As Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForDictionary_TextBox.MouseHover
        ToolTip1.SetToolTip(DefaultNetworkLocationForDictionary_TextBox, DefaultNetworkLocationForDictionary_TextBox.Text)
    End Sub

    Private Sub DefaultNetworklocationForOfficeDictionaryFile_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworklocationForOfficeDictionaryFile_Button.Click
        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForDictionary_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForDictionary_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub

    Private Sub BrowseForFonts_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseForFonts_Button.Click
        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForFontFiles_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForFontFiles_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub

    Private Sub ResetScaleListOnDrawingActivate_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetScaleListOnDrawingActivate_CheckBox.CheckedChanged
        If ResetScaleListOnDrawingActivate_CheckBox.Checked = True Then
            MillimetersOnly_RadioButton.Enabled = True
            MillimetersAndMeters_RadioButton.Enabled = True
            Settings.Manager.AutoCAD.MillimetresAndMetres = True
        Else
            MillimetersOnly_RadioButton.Enabled = False
            MillimetersAndMeters_RadioButton.Enabled = False
            Settings.Manager.AutoCAD.MillimetresOnly = True
        End If
        If Not ResetScaleListOnDrawingActivate_CheckBox.Checked = Settings.Manager.AutoCAD.ResetScaleListOnDrawingActivate Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub CreateTemplateShortCut_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateTemplateShortCut_CheckBox.CheckedChanged


        If Not CreateTemplateShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreateTemplateShortCut Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub CreatePlotStyleShortCut_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreatePlotStyleShortCut_CheckBox.CheckedChanged


        If Not CreatePlotStyleShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreatePlotStyleShortCut Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub CreatePC3ShortCut_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreatePC3ShortCut_CheckBox.CheckedChanged


        If Not CreatePC3ShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreatePC3ShortCut Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub CreatePMPShortCut_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreatePMPShortCut_CheckBox.CheckedChanged

        If Not CreatePMPShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreatePMPShortCut Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub UseOfficeCustomDictionary_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UseOfficeCustomDictionary_CheckBox.CheckedChanged

        If Not UseOfficeCustomDictionary_CheckBox.Checked = Settings.Manager.AutoCAD.UseOfficeCustomDictionary Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub UseOfficeNetworkFonts_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UseOfficeNetworkFonts_CheckBox.CheckedChanged

        If Not UseOfficeNetworkFonts_CheckBox.Checked = Settings.Manager.AutoCAD.UseOfficeNetworkFonts Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub CreateSupportShortCut_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateSupportShortCut_CheckBox.CheckedChanged


        If Not CreateSupportShortCut_CheckBox.Checked = Settings.Manager.AutoCAD.CreateSupportShortCut Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub EnforceacadCUI_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnforceacadCUI_CheckBox.CheckedChanged

        If Not EnforceacadCUI_CheckBox.Checked = Settings.Manager.AutoCAD.RestoreacadCUI Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub ManageCuis_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ManageCuis_CheckBox.CheckedChanged


        If Not ManageCuis_CheckBox.Checked = Settings.Manager.AutoCAD.ManageCUIs Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If

    End Sub


    Private Sub DefaultNetworkLocationForSupportFiles_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForSupportFiles_TextBox.TextChanged


        If Not DefaultNetworkLocationForSupportFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkSupportLocation Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworkLocationForMenuFiles_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForMenuFiles_TextBox.TextChanged


        If Not DefaultNetworkLocationForMenuFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkMenuLocation Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworkLocationForTemplateFiles_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForTemplateFiles_TextBox.TextChanged


        If Not DefaultNetworkLocationForTemplateFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkTemplateLocation Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworklocationForPMPFiles_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworklocationForPMPFiles_TextBox.TextChanged


        If Not DefaultNetworklocationForPMPFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkPMPLocation Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworkLocationForPC3Files_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForPC3Files_TextBox.TextChanged


        If Not DefaultNetworkLocationForPC3Files_TextBox.Text = Settings.Manager.AutoCAD.NetworkPC3Location Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworkLocationForPlotStyleFiles_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForPlotStyleFiles_TextBox.TextChanged


        If Not DefaultNetworkLocationForPlotStyleFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkPlotStyleLocation Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworkLocationForFontFiles_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForFontFiles_TextBox.TextChanged


        If Not DefaultNetworkLocationForFontFiles_TextBox.Text = Settings.Manager.AutoCAD.NetworkFontsLocation Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub DefaultNetworkLocationForDictionary_TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefaultNetworkLocationForDictionary_TextBox.TextChanged


        If Not DefaultNetworkLocationForDictionary_TextBox.Text = Settings.Manager.AutoCAD.NetworkDictionaryLocation.CombinePath(Settings.Manager.AutoCAD.CustomDictionary) Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    Private Sub MillimetersOnly_RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MillimetersOnly_RadioButton.CheckedChanged


        If Not MillimetersOnly_RadioButton.Checked = Settings.Manager.AutoCAD.MillimetresOnly Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub

    'Private Sub WhenAutoCADStarts_RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If Not WhenAutoCADStarts_RadioButton.Checked = AE.Config.AutoCAD.WhenAutoCADStarts Then
    '        Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
    '    End If
    'End Sub

    'Private Sub LoadDrawingTabs_RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    If Not LoadDrawingTabs_RadioButton.Checked = AE.Config.AutoCAD.LoadTabs Then
    '        Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
    '    End If
    'End Sub

    '        MillimetersAndMeters_RadioButton.Checked = AE.Config.AutoCAD.MillimetersAndMeters And _
    '        WhenDrawingIsActivated_RadioButton.Checked = AE.Config.AutoCAD.WhenDrawingIsActivated And _
    '         And _
    '        MillimetersOnly_RadioButton.Enabled = ResetScaleListOnDrawingActivate_CheckBox.Checked Then
    'Private Sub MillimetersAndMeters_RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MillimetersAndMeters_RadioButton.CheckedChanged
    '    'Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
    '    'checkdirty()
    'End Sub
    'Private Sub WhenDrawingIsActivated_RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WhenDrawingIsActivated_RadioButton.CheckedChanged
    '    'Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
    '    'checkdirty()
    'End Sub
    'Private Sub UnLoadDrawingTabs_RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnLoadDrawingTabs_RadioButton.CheckedChanged
    '    'Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
    '    'checkdirty()
    'End Sub

    Private Sub BrowseForMenu_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseForMenu_Button.Click
        'FolderBrowserDialog1.ShowDialog()
        'Me.DefaultNetworkLocationForMenuFiles_TextBox.Text = FolderBrowserDialog1.SelectedPath()
        Dim ReturnedFolder As String = BrowseForFolder()
        If ReturnedFolder <> String.Empty Then
            If System.IO.Directory.Exists(ReturnedFolder) Then
                Me.DefaultNetworkLocationForMenuFiles_TextBox.Text = ReturnedFolder
            Else
                GeneralMessageBox("Selected folder does not exist please try again: " & ReturnedFolder)
            End If
        End If
    End Sub

    Private Sub UseOfficeNetworkMenu_CheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UseOfficeNetworkMenu_CheckBox.CheckedChanged
        If Not UseOfficeNetworkMenu_CheckBox.Checked = Settings.Manager.AutoCAD.UseOfficeNetworkMenu Then
            Autodesk.AutoCAD.ApplicationServices.TabbedDialogExtension.SetDirty(Me, True)
        End If
    End Sub
End Class



