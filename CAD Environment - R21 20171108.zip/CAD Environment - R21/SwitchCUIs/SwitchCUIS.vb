Imports Autodesk.AutoCAD.ApplicationServices
Imports System.IO
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Autodesk.AutoCAD.EditorInput
Imports Jacobs.AutoCAD.Utilities
'Imports Jacobs.Common.Settings
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Jacobs.AutoCAD.SwitchCUIs.SwitchCUIS))> 

Public Class SwitchCUIS

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    <Autodesk.AutoCAD.Runtime.CommandMethod("SwitchCUIs", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub SwitchCUIs()

        Try
            Dim preferences As Autodesk.AutoCAD.Interop.AcadPreferences
            Dim MainMenu As String
            Dim EnterpriseMenu As String

            preferences = ThisDrawingUtilities.Application.Preferences

            MainMenu = preferences.Files.MenuFile
            EnterpriseMenu = preferences.Files.EnterpriseMenuFile

            preferences.Files.EnterpriseMenuFile = "."
            preferences.Files.MenuFile = "."

            preferences.Files.EnterpriseMenuFile = MainMenu
            preferences.Files.MenuFile = EnterpriseMenu

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

End Class