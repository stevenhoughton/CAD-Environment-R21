<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class AddressForm
#Region "Windows Form Designer generated code "
    <System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
        MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents Help_Button As System.Windows.Forms.Button
    Public WithEvents OK_Button As System.Windows.Forms.Button
    Public WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Public WithEvents RegionCmb As System.Windows.Forms.ComboBox
    Public WithEvents Regionlbl As System.Windows.Forms.Label
    Public WithEvents OfficeCmb As System.Windows.Forms.ComboBox
    Public WithEvents Officelbl As System.Windows.Forms.Label
    Friend WithEvents AddressAutomaticOptionButton As System.Windows.Forms.RadioButton
    Friend WithEvents AddressManualOptionButton As System.Windows.Forms.RadioButton
    Public WithEvents IgnoreAddressOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents Addressfrm As System.Windows.Forms.GroupBox
    Public WithEvents LogoComboBox As System.Windows.Forms.ComboBox
    Public WithEvents LogoAutomaticOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents LogoManualOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents IgnoreLogoOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents LogoFrame As System.Windows.Forms.GroupBox
    Public WithEvents ScaleBarComboBox As System.Windows.Forms.ComboBox
    Public WithEvents ScaleBarAutomaticOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents ScaleBarManualOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents IgnoreScaleBarOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents BarScaleFrame As System.Windows.Forms.GroupBox
    Public WithEvents NorthPointComboBox As System.Windows.Forms.ComboBox
    Public WithEvents NorthPointAutomaticOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents NorthPointManualOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents IgnoreNorthPointOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents NorthPointFrame As System.Windows.Forms.GroupBox
    Public WithEvents DrawingStatusComboBox As System.Windows.Forms.ComboBox
    Public WithEvents DrawingStatusAutomaticOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents DrawingStatusManualOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents IgnoreDrawingStatusOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents DrawingStatusFrame As System.Windows.Forms.GroupBox
    Public WithEvents NotesAutomaticOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents NotesManualOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents NotesComboBox As System.Windows.Forms.ComboBox
    Public WithEvents IgnoreNotesOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents NotesFrame As System.Windows.Forms.GroupBox
    Public WithEvents ReviewStampAutomaticOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents ReviewStampManualOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents ReviewStampComboBox As System.Windows.Forms.ComboBox
    Public WithEvents IgnoreReviewStampOptionButton As System.Windows.Forms.CheckBox
    Public WithEvents ReviewStampFrame As System.Windows.Forms.GroupBox
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AddressForm))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.RegionCmb = New System.Windows.Forms.ComboBox()
        Me.OfficeCmb = New System.Windows.Forms.ComboBox()
        Me.AddressAutomaticOptionButton = New System.Windows.Forms.RadioButton()
        Me.AddressManualOptionButton = New System.Windows.Forms.RadioButton()
        Me.IgnoreAddressOptionButton = New System.Windows.Forms.CheckBox()
        Me.LogoComboBox = New System.Windows.Forms.ComboBox()
        Me.LogoAutomaticOptionButton = New System.Windows.Forms.CheckBox()
        Me.LogoManualOptionButton = New System.Windows.Forms.CheckBox()
        Me.IgnoreLogoOptionButton = New System.Windows.Forms.CheckBox()
        Me.ScaleBarComboBox = New System.Windows.Forms.ComboBox()
        Me.ScaleBarAutomaticOptionButton = New System.Windows.Forms.CheckBox()
        Me.ScaleBarManualOptionButton = New System.Windows.Forms.CheckBox()
        Me.IgnoreScaleBarOptionButton = New System.Windows.Forms.CheckBox()
        Me.NorthPointComboBox = New System.Windows.Forms.ComboBox()
        Me.NorthPointAutomaticOptionButton = New System.Windows.Forms.CheckBox()
        Me.NorthPointManualOptionButton = New System.Windows.Forms.CheckBox()
        Me.IgnoreNorthPointOptionButton = New System.Windows.Forms.CheckBox()
        Me.DrawingStatusComboBox = New System.Windows.Forms.ComboBox()
        Me.DrawingStatusAutomaticOptionButton = New System.Windows.Forms.CheckBox()
        Me.DrawingStatusManualOptionButton = New System.Windows.Forms.CheckBox()
        Me.IgnoreDrawingStatusOptionButton = New System.Windows.Forms.CheckBox()
        Me.NotesAutomaticOptionButton = New System.Windows.Forms.CheckBox()
        Me.NotesManualOptionButton = New System.Windows.Forms.CheckBox()
        Me.NotesComboBox = New System.Windows.Forms.ComboBox()
        Me.IgnoreNotesOptionButton = New System.Windows.Forms.CheckBox()
        Me.ReviewStampAutomaticOptionButton = New System.Windows.Forms.CheckBox()
        Me.ReviewStampManualOptionButton = New System.Windows.Forms.CheckBox()
        Me.ReviewStampComboBox = New System.Windows.Forms.ComboBox()
        Me.IgnoreReviewStampOptionButton = New System.Windows.Forms.CheckBox()
        Me.Help_Button = New System.Windows.Forms.Button()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.Addressfrm = New System.Windows.Forms.GroupBox()
        Me.Regionlbl = New System.Windows.Forms.Label()
        Me.Officelbl = New System.Windows.Forms.Label()
        Me.LogoFrame = New System.Windows.Forms.GroupBox()
        Me.BarScaleFrame = New System.Windows.Forms.GroupBox()
        Me.NorthPointFrame = New System.Windows.Forms.GroupBox()
        Me.DrawingStatusFrame = New System.Windows.Forms.GroupBox()
        Me.NotesFrame = New System.Windows.Forms.GroupBox()
        Me.ReviewStampFrame = New System.Windows.Forms.GroupBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Addressfrm.SuspendLayout()
        Me.LogoFrame.SuspendLayout()
        Me.BarScaleFrame.SuspendLayout()
        Me.NorthPointFrame.SuspendLayout()
        Me.DrawingStatusFrame.SuspendLayout()
        Me.NotesFrame.SuspendLayout()
        Me.ReviewStampFrame.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'RegionCmb
        '
        Me.RegionCmb.BackColor = System.Drawing.SystemColors.Window
        Me.RegionCmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.RegionCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RegionCmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegionCmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RegionCmb.Location = New System.Drawing.Point(88, 30)
        Me.RegionCmb.Margin = New System.Windows.Forms.Padding(4)
        Me.RegionCmb.Name = "RegionCmb"
        Me.RegionCmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RegionCmb.Size = New System.Drawing.Size(223, 25)
        Me.RegionCmb.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.RegionCmb, "Select region where the office is located")
        '
        'OfficeCmb
        '
        Me.OfficeCmb.BackColor = System.Drawing.SystemColors.Window
        Me.OfficeCmb.Cursor = System.Windows.Forms.Cursors.Default
        Me.OfficeCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.OfficeCmb.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OfficeCmb.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OfficeCmb.Location = New System.Drawing.Point(376, 30)
        Me.OfficeCmb.Margin = New System.Windows.Forms.Padding(4)
        Me.OfficeCmb.Name = "OfficeCmb"
        Me.OfficeCmb.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OfficeCmb.Size = New System.Drawing.Size(191, 25)
        Me.OfficeCmb.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.OfficeCmb, "Select desired office.")
        '
        'AddressAutomaticOptionButton
        '
        Me.AddressAutomaticOptionButton.AutoSize = True
        Me.AddressAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.AddressAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.AddressAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddressAutomaticOptionButton.Location = New System.Drawing.Point(586, 32)
        Me.AddressAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AddressAutomaticOptionButton.Name = "AddressAutomaticOptionButton"
        Me.AddressAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AddressAutomaticOptionButton.Size = New System.Drawing.Size(91, 21)
        Me.AddressAutomaticOptionButton.TabIndex = 7
        Me.AddressAutomaticOptionButton.TabStop = True
        Me.AddressAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.AddressAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_LOGO and ??_LOGO blocks o" & _
                "ccurences")
        Me.AddressAutomaticOptionButton.UseVisualStyleBackColor = True
        '
        'AddressManualOptionButton
        '
        Me.AddressManualOptionButton.AutoSize = True
        Me.AddressManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.AddressManualOptionButton.Checked = True
        Me.AddressManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.AddressManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.AddressManualOptionButton.Location = New System.Drawing.Point(680, 32)
        Me.AddressManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AddressManualOptionButton.Name = "AddressManualOptionButton"
        Me.AddressManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.AddressManualOptionButton.Size = New System.Drawing.Size(75, 21)
        Me.AddressManualOptionButton.TabIndex = 22
        Me.AddressManualOptionButton.TabStop = True
        Me.AddressManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.AddressManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.AddressManualOptionButton.UseVisualStyleBackColor = True
        '
        'IgnoreAddressOptionButton
        '
        Me.IgnoreAddressOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreAddressOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreAddressOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreAddressOptionButton.Location = New System.Drawing.Point(845, 30)
        Me.IgnoreAddressOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreAddressOptionButton.Name = "IgnoreAddressOptionButton"
        Me.IgnoreAddressOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreAddressOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreAddressOptionButton.TabIndex = 6
        Me.IgnoreAddressOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreAddressOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreAddressOptionButton.UseVisualStyleBackColor = False
        '
        'LogoComboBox
        '
        Me.LogoComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.LogoComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.LogoComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.LogoComboBox.Location = New System.Drawing.Point(13, 30)
        Me.LogoComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoComboBox.Name = "LogoComboBox"
        Me.LogoComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LogoComboBox.Size = New System.Drawing.Size(377, 25)
        Me.LogoComboBox.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.LogoComboBox, "Select logo to use as replacement")
        '
        'LogoAutomaticOptionButton
        '
        Me.LogoAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.LogoAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LogoAutomaticOptionButton.Location = New System.Drawing.Point(408, 31)
        Me.LogoAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoAutomaticOptionButton.Name = "LogoAutomaticOptionButton"
        Me.LogoAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LogoAutomaticOptionButton.Size = New System.Drawing.Size(99, 28)
        Me.LogoAutomaticOptionButton.TabIndex = 1
        Me.LogoAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.LogoAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_LOGO and ??_LOGO blocks o" & _
                "ccurences")
        Me.LogoAutomaticOptionButton.UseVisualStyleBackColor = False
        '
        'LogoManualOptionButton
        '
        Me.LogoManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.LogoManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.LogoManualOptionButton.Location = New System.Drawing.Point(515, 31)
        Me.LogoManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoManualOptionButton.Name = "LogoManualOptionButton"
        Me.LogoManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LogoManualOptionButton.Size = New System.Drawing.Size(83, 28)
        Me.LogoManualOptionButton.TabIndex = 2
        Me.LogoManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.LogoManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.LogoManualOptionButton.UseVisualStyleBackColor = False
        '
        'IgnoreLogoOptionButton
        '
        Me.IgnoreLogoOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreLogoOptionButton.Checked = True
        Me.IgnoreLogoOptionButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IgnoreLogoOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreLogoOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreLogoOptionButton.Location = New System.Drawing.Point(632, 30)
        Me.IgnoreLogoOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreLogoOptionButton.Name = "IgnoreLogoOptionButton"
        Me.IgnoreLogoOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreLogoOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreLogoOptionButton.TabIndex = 3
        Me.IgnoreLogoOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreLogoOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreLogoOptionButton.UseVisualStyleBackColor = False
        '
        'ScaleBarComboBox
        '
        Me.ScaleBarComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.ScaleBarComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.ScaleBarComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ScaleBarComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScaleBarComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ScaleBarComboBox.Location = New System.Drawing.Point(17, 30)
        Me.ScaleBarComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ScaleBarComboBox.Name = "ScaleBarComboBox"
        Me.ScaleBarComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ScaleBarComboBox.Size = New System.Drawing.Size(377, 25)
        Me.ScaleBarComboBox.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.ScaleBarComboBox, "Select bar scale block to use as replacement")
        '
        'ScaleBarAutomaticOptionButton
        '
        Me.ScaleBarAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.ScaleBarAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ScaleBarAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ScaleBarAutomaticOptionButton.Location = New System.Drawing.Point(408, 31)
        Me.ScaleBarAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ScaleBarAutomaticOptionButton.Name = "ScaleBarAutomaticOptionButton"
        Me.ScaleBarAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ScaleBarAutomaticOptionButton.Size = New System.Drawing.Size(99, 28)
        Me.ScaleBarAutomaticOptionButton.TabIndex = 0
        Me.ScaleBarAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.ScaleBarAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_BARSCALE block occurences" & _
                "")
        Me.ScaleBarAutomaticOptionButton.UseVisualStyleBackColor = False
        '
        'ScaleBarManualOptionButton
        '
        Me.ScaleBarManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.ScaleBarManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ScaleBarManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ScaleBarManualOptionButton.Location = New System.Drawing.Point(515, 30)
        Me.ScaleBarManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ScaleBarManualOptionButton.Name = "ScaleBarManualOptionButton"
        Me.ScaleBarManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ScaleBarManualOptionButton.Size = New System.Drawing.Size(83, 28)
        Me.ScaleBarManualOptionButton.TabIndex = 1
        Me.ScaleBarManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.ScaleBarManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.ScaleBarManualOptionButton.UseVisualStyleBackColor = False
        '
        'IgnoreScaleBarOptionButton
        '
        Me.IgnoreScaleBarOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreScaleBarOptionButton.Checked = True
        Me.IgnoreScaleBarOptionButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IgnoreScaleBarOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreScaleBarOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreScaleBarOptionButton.Location = New System.Drawing.Point(632, 30)
        Me.IgnoreScaleBarOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreScaleBarOptionButton.Name = "IgnoreScaleBarOptionButton"
        Me.IgnoreScaleBarOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreScaleBarOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreScaleBarOptionButton.TabIndex = 3
        Me.IgnoreScaleBarOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreScaleBarOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreScaleBarOptionButton.UseVisualStyleBackColor = False
        '
        'NorthPointComboBox
        '
        Me.NorthPointComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.NorthPointComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.NorthPointComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.NorthPointComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NorthPointComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.NorthPointComboBox.Location = New System.Drawing.Point(17, 30)
        Me.NorthPointComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.NorthPointComboBox.Name = "NorthPointComboBox"
        Me.NorthPointComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NorthPointComboBox.Size = New System.Drawing.Size(377, 25)
        Me.NorthPointComboBox.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.NorthPointComboBox, "Select north point to use as replacement")
        '
        'NorthPointAutomaticOptionButton
        '
        Me.NorthPointAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.NorthPointAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.NorthPointAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NorthPointAutomaticOptionButton.Location = New System.Drawing.Point(408, 30)
        Me.NorthPointAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NorthPointAutomaticOptionButton.Name = "NorthPointAutomaticOptionButton"
        Me.NorthPointAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NorthPointAutomaticOptionButton.Size = New System.Drawing.Size(99, 28)
        Me.NorthPointAutomaticOptionButton.TabIndex = 0
        Me.NorthPointAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.NorthPointAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_NORTHPOINT block occurenc" & _
                "es")
        Me.NorthPointAutomaticOptionButton.UseVisualStyleBackColor = False
        '
        'NorthPointManualOptionButton
        '
        Me.NorthPointManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.NorthPointManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.NorthPointManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NorthPointManualOptionButton.Location = New System.Drawing.Point(515, 30)
        Me.NorthPointManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NorthPointManualOptionButton.Name = "NorthPointManualOptionButton"
        Me.NorthPointManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NorthPointManualOptionButton.Size = New System.Drawing.Size(83, 28)
        Me.NorthPointManualOptionButton.TabIndex = 1
        Me.NorthPointManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.NorthPointManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.NorthPointManualOptionButton.UseVisualStyleBackColor = False
        '
        'IgnoreNorthPointOptionButton
        '
        Me.IgnoreNorthPointOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreNorthPointOptionButton.Checked = True
        Me.IgnoreNorthPointOptionButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IgnoreNorthPointOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreNorthPointOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreNorthPointOptionButton.Location = New System.Drawing.Point(632, 30)
        Me.IgnoreNorthPointOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreNorthPointOptionButton.Name = "IgnoreNorthPointOptionButton"
        Me.IgnoreNorthPointOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreNorthPointOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreNorthPointOptionButton.TabIndex = 3
        Me.IgnoreNorthPointOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreNorthPointOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreNorthPointOptionButton.UseVisualStyleBackColor = False
        '
        'DrawingStatusComboBox
        '
        Me.DrawingStatusComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.DrawingStatusComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.DrawingStatusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.DrawingStatusComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DrawingStatusComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DrawingStatusComboBox.Location = New System.Drawing.Point(17, 30)
        Me.DrawingStatusComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.DrawingStatusComboBox.Name = "DrawingStatusComboBox"
        Me.DrawingStatusComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DrawingStatusComboBox.Size = New System.Drawing.Size(377, 25)
        Me.DrawingStatusComboBox.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.DrawingStatusComboBox, "Select drawing status to use as replacement")
        '
        'DrawingStatusAutomaticOptionButton
        '
        Me.DrawingStatusAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.DrawingStatusAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.DrawingStatusAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DrawingStatusAutomaticOptionButton.Location = New System.Drawing.Point(408, 30)
        Me.DrawingStatusAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DrawingStatusAutomaticOptionButton.Name = "DrawingStatusAutomaticOptionButton"
        Me.DrawingStatusAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DrawingStatusAutomaticOptionButton.Size = New System.Drawing.Size(99, 28)
        Me.DrawingStatusAutomaticOptionButton.TabIndex = 0
        Me.DrawingStatusAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.DrawingStatusAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_DRAWING_STATUS block occu" & _
                "rences")
        Me.DrawingStatusAutomaticOptionButton.UseVisualStyleBackColor = False
        '
        'DrawingStatusManualOptionButton
        '
        Me.DrawingStatusManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.DrawingStatusManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.DrawingStatusManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.DrawingStatusManualOptionButton.Location = New System.Drawing.Point(515, 30)
        Me.DrawingStatusManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DrawingStatusManualOptionButton.Name = "DrawingStatusManualOptionButton"
        Me.DrawingStatusManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DrawingStatusManualOptionButton.Size = New System.Drawing.Size(83, 28)
        Me.DrawingStatusManualOptionButton.TabIndex = 1
        Me.DrawingStatusManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.DrawingStatusManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.DrawingStatusManualOptionButton.UseVisualStyleBackColor = False
        '
        'IgnoreDrawingStatusOptionButton
        '
        Me.IgnoreDrawingStatusOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreDrawingStatusOptionButton.Checked = True
        Me.IgnoreDrawingStatusOptionButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IgnoreDrawingStatusOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreDrawingStatusOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreDrawingStatusOptionButton.Location = New System.Drawing.Point(632, 30)
        Me.IgnoreDrawingStatusOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreDrawingStatusOptionButton.Name = "IgnoreDrawingStatusOptionButton"
        Me.IgnoreDrawingStatusOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreDrawingStatusOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreDrawingStatusOptionButton.TabIndex = 3
        Me.IgnoreDrawingStatusOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreDrawingStatusOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreDrawingStatusOptionButton.UseVisualStyleBackColor = False
        '
        'NotesAutomaticOptionButton
        '
        Me.NotesAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.NotesAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.NotesAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NotesAutomaticOptionButton.Location = New System.Drawing.Point(408, 30)
        Me.NotesAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NotesAutomaticOptionButton.Name = "NotesAutomaticOptionButton"
        Me.NotesAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NotesAutomaticOptionButton.Size = New System.Drawing.Size(99, 30)
        Me.NotesAutomaticOptionButton.TabIndex = 0
        Me.NotesAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.NotesAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_NOTES block occurences")
        Me.NotesAutomaticOptionButton.UseVisualStyleBackColor = False
        '
        'NotesManualOptionButton
        '
        Me.NotesManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.NotesManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.NotesManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.NotesManualOptionButton.Location = New System.Drawing.Point(515, 30)
        Me.NotesManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.NotesManualOptionButton.Name = "NotesManualOptionButton"
        Me.NotesManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NotesManualOptionButton.Size = New System.Drawing.Size(83, 30)
        Me.NotesManualOptionButton.TabIndex = 1
        Me.NotesManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.NotesManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.NotesManualOptionButton.UseVisualStyleBackColor = False
        '
        'NotesComboBox
        '
        Me.NotesComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.NotesComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.NotesComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.NotesComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NotesComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.NotesComboBox.Location = New System.Drawing.Point(17, 30)
        Me.NotesComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.NotesComboBox.Name = "NotesComboBox"
        Me.NotesComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NotesComboBox.Size = New System.Drawing.Size(377, 25)
        Me.NotesComboBox.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.NotesComboBox, "Select notes block to use as replacement")
        '
        'IgnoreNotesOptionButton
        '
        Me.IgnoreNotesOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreNotesOptionButton.Checked = True
        Me.IgnoreNotesOptionButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IgnoreNotesOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreNotesOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreNotesOptionButton.Location = New System.Drawing.Point(632, 30)
        Me.IgnoreNotesOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreNotesOptionButton.Name = "IgnoreNotesOptionButton"
        Me.IgnoreNotesOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreNotesOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreNotesOptionButton.TabIndex = 3
        Me.IgnoreNotesOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreNotesOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreNotesOptionButton.UseVisualStyleBackColor = False
        '
        'ReviewStampAutomaticOptionButton
        '
        Me.ReviewStampAutomaticOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.ReviewStampAutomaticOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ReviewStampAutomaticOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReviewStampAutomaticOptionButton.Location = New System.Drawing.Point(408, 30)
        Me.ReviewStampAutomaticOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ReviewStampAutomaticOptionButton.Name = "ReviewStampAutomaticOptionButton"
        Me.ReviewStampAutomaticOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReviewStampAutomaticOptionButton.Size = New System.Drawing.Size(99, 28)
        Me.ReviewStampAutomaticOptionButton.TabIndex = 0
        Me.ReviewStampAutomaticOptionButton.Text = "Automatic"
        Me.ToolTip1.SetToolTip(Me.ReviewStampAutomaticOptionButton, "Automatic insertion searches the drawing for all INSERT_DRAWING_STATUS block occu" & _
                "rences")
        Me.ReviewStampAutomaticOptionButton.UseVisualStyleBackColor = False
        '
        'ReviewStampManualOptionButton
        '
        Me.ReviewStampManualOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.ReviewStampManualOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ReviewStampManualOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ReviewStampManualOptionButton.Location = New System.Drawing.Point(515, 30)
        Me.ReviewStampManualOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ReviewStampManualOptionButton.Name = "ReviewStampManualOptionButton"
        Me.ReviewStampManualOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReviewStampManualOptionButton.Size = New System.Drawing.Size(83, 28)
        Me.ReviewStampManualOptionButton.TabIndex = 1
        Me.ReviewStampManualOptionButton.Text = "Manual"
        Me.ToolTip1.SetToolTip(Me.ReviewStampManualOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.ReviewStampManualOptionButton.UseVisualStyleBackColor = False
        '
        'ReviewStampComboBox
        '
        Me.ReviewStampComboBox.BackColor = System.Drawing.SystemColors.Window
        Me.ReviewStampComboBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.ReviewStampComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ReviewStampComboBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReviewStampComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ReviewStampComboBox.Location = New System.Drawing.Point(17, 30)
        Me.ReviewStampComboBox.Margin = New System.Windows.Forms.Padding(4)
        Me.ReviewStampComboBox.Name = "ReviewStampComboBox"
        Me.ReviewStampComboBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReviewStampComboBox.Size = New System.Drawing.Size(377, 25)
        Me.ReviewStampComboBox.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.ReviewStampComboBox, "Select drawing status to use as replacement")
        '
        'IgnoreReviewStampOptionButton
        '
        Me.IgnoreReviewStampOptionButton.BackColor = System.Drawing.SystemColors.Control
        Me.IgnoreReviewStampOptionButton.Checked = True
        Me.IgnoreReviewStampOptionButton.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IgnoreReviewStampOptionButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.IgnoreReviewStampOptionButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.IgnoreReviewStampOptionButton.Location = New System.Drawing.Point(632, 30)
        Me.IgnoreReviewStampOptionButton.Margin = New System.Windows.Forms.Padding(4)
        Me.IgnoreReviewStampOptionButton.Name = "IgnoreReviewStampOptionButton"
        Me.IgnoreReviewStampOptionButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.IgnoreReviewStampOptionButton.Size = New System.Drawing.Size(76, 28)
        Me.IgnoreReviewStampOptionButton.TabIndex = 3
        Me.IgnoreReviewStampOptionButton.Text = "Ignore"
        Me.ToolTip1.SetToolTip(Me.IgnoreReviewStampOptionButton, "Manual insert allows users to select any block to be replaced")
        Me.IgnoreReviewStampOptionButton.UseVisualStyleBackColor = False
        '
        'Help_Button
        '
        Me.Help_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Help_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Help_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Help_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Help_Button.Location = New System.Drawing.Point(11, 6)
        Me.Help_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Help_Button.Name = "Help_Button"
        Me.Help_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Help_Button.Size = New System.Drawing.Size(85, 32)
        Me.Help_Button.TabIndex = 5
        Me.Help_Button.Text = "Help"
        Me.Help_Button.UseVisualStyleBackColor = False
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.BackColor = System.Drawing.SystemColors.Control
        Me.OK_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.OK_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OK_Button.Location = New System.Drawing.Point(118, 6)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OK_Button.Size = New System.Drawing.Size(85, 32)
        Me.OK_Button.TabIndex = 3
        Me.OK_Button.Text = "OK"
        Me.OK_Button.UseVisualStyleBackColor = False
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.BackColor = System.Drawing.SystemColors.Control
        Me.Cancel_Button.Cursor = System.Windows.Forms.Cursors.Default
        Me.Cancel_Button.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Cancel_Button.Location = New System.Drawing.Point(225, 6)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Cancel_Button.Size = New System.Drawing.Size(85, 32)
        Me.Cancel_Button.TabIndex = 4
        Me.Cancel_Button.Text = "Cancel"
        Me.Cancel_Button.UseVisualStyleBackColor = False
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.BackColor = System.Drawing.Color.Transparent
        Me.LogoPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.LogoPictureBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.LogoPictureBox.ErrorImage = Nothing
        Me.LogoPictureBox.InitialImage = Nothing
        Me.LogoPictureBox.Location = New System.Drawing.Point(1, 2)
        Me.LogoPictureBox.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(134, 54)
        Me.LogoPictureBox.TabIndex = 6
        Me.LogoPictureBox.TabStop = False
        '
        'Addressfrm
        '
        Me.Addressfrm.BackColor = System.Drawing.SystemColors.Control
        Me.Addressfrm.Controls.Add(Me.RegionCmb)
        Me.Addressfrm.Controls.Add(Me.Regionlbl)
        Me.Addressfrm.Controls.Add(Me.OfficeCmb)
        Me.Addressfrm.Controls.Add(Me.Officelbl)
        Me.Addressfrm.Controls.Add(Me.AddressAutomaticOptionButton)
        Me.Addressfrm.Controls.Add(Me.AddressManualOptionButton)
        Me.Addressfrm.Controls.Add(Me.IgnoreAddressOptionButton)
        Me.Addressfrm.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Addressfrm.Location = New System.Drawing.Point(13, 74)
        Me.Addressfrm.Margin = New System.Windows.Forms.Padding(4)
        Me.Addressfrm.Name = "Addressfrm"
        Me.Addressfrm.Padding = New System.Windows.Forms.Padding(4)
        Me.Addressfrm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Addressfrm.Size = New System.Drawing.Size(789, 79)
        Me.Addressfrm.TabIndex = 0
        Me.Addressfrm.TabStop = False
        Me.Addressfrm.Text = "Address"
        '
        'Regionlbl
        '
        Me.Regionlbl.AutoSize = True
        Me.Regionlbl.BackColor = System.Drawing.SystemColors.Control
        Me.Regionlbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Regionlbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Regionlbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Regionlbl.Location = New System.Drawing.Point(24, 36)
        Me.Regionlbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Regionlbl.Name = "Regionlbl"
        Me.Regionlbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Regionlbl.Size = New System.Drawing.Size(50, 17)
        Me.Regionlbl.TabIndex = 2
        Me.Regionlbl.Text = "Region"
        Me.Regionlbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Officelbl
        '
        Me.Officelbl.AutoSize = True
        Me.Officelbl.BackColor = System.Drawing.SystemColors.Control
        Me.Officelbl.Cursor = System.Windows.Forms.Cursors.Default
        Me.Officelbl.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Officelbl.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Officelbl.Location = New System.Drawing.Point(320, 36)
        Me.Officelbl.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Officelbl.Name = "Officelbl"
        Me.Officelbl.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Officelbl.Size = New System.Drawing.Size(42, 17)
        Me.Officelbl.TabIndex = 3
        Me.Officelbl.Text = "Office"
        Me.Officelbl.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LogoFrame
        '
        Me.LogoFrame.BackColor = System.Drawing.SystemColors.Control
        Me.LogoFrame.Controls.Add(Me.LogoComboBox)
        Me.LogoFrame.Controls.Add(Me.LogoAutomaticOptionButton)
        Me.LogoFrame.Controls.Add(Me.LogoManualOptionButton)
        Me.LogoFrame.Controls.Add(Me.IgnoreLogoOptionButton)
        Me.LogoFrame.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.LogoFrame.Location = New System.Drawing.Point(1003, 502)
        Me.LogoFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.LogoFrame.Name = "LogoFrame"
        Me.LogoFrame.Padding = New System.Windows.Forms.Padding(4)
        Me.LogoFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LogoFrame.Size = New System.Drawing.Size(747, 79)
        Me.LogoFrame.TabIndex = 6
        Me.LogoFrame.TabStop = False
        Me.LogoFrame.Text = "Logo"
        '
        'BarScaleFrame
        '
        Me.BarScaleFrame.BackColor = System.Drawing.SystemColors.Control
        Me.BarScaleFrame.Controls.Add(Me.ScaleBarComboBox)
        Me.BarScaleFrame.Controls.Add(Me.ScaleBarAutomaticOptionButton)
        Me.BarScaleFrame.Controls.Add(Me.ScaleBarManualOptionButton)
        Me.BarScaleFrame.Controls.Add(Me.IgnoreScaleBarOptionButton)
        Me.BarScaleFrame.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.BarScaleFrame.Location = New System.Drawing.Point(1003, 177)
        Me.BarScaleFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.BarScaleFrame.Name = "BarScaleFrame"
        Me.BarScaleFrame.Padding = New System.Windows.Forms.Padding(4)
        Me.BarScaleFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BarScaleFrame.Size = New System.Drawing.Size(747, 79)
        Me.BarScaleFrame.TabIndex = 7
        Me.BarScaleFrame.TabStop = False
        Me.BarScaleFrame.Text = "Bar Scale"
        '
        'NorthPointFrame
        '
        Me.NorthPointFrame.BackColor = System.Drawing.SystemColors.Control
        Me.NorthPointFrame.Controls.Add(Me.NorthPointComboBox)
        Me.NorthPointFrame.Controls.Add(Me.NorthPointAutomaticOptionButton)
        Me.NorthPointFrame.Controls.Add(Me.NorthPointManualOptionButton)
        Me.NorthPointFrame.Controls.Add(Me.IgnoreNorthPointOptionButton)
        Me.NorthPointFrame.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.NorthPointFrame.Location = New System.Drawing.Point(1003, 256)
        Me.NorthPointFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.NorthPointFrame.Name = "NorthPointFrame"
        Me.NorthPointFrame.Padding = New System.Windows.Forms.Padding(4)
        Me.NorthPointFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NorthPointFrame.Size = New System.Drawing.Size(747, 79)
        Me.NorthPointFrame.TabIndex = 8
        Me.NorthPointFrame.TabStop = False
        Me.NorthPointFrame.Text = "North Point"
        '
        'DrawingStatusFrame
        '
        Me.DrawingStatusFrame.BackColor = System.Drawing.SystemColors.Control
        Me.DrawingStatusFrame.Controls.Add(Me.DrawingStatusComboBox)
        Me.DrawingStatusFrame.Controls.Add(Me.DrawingStatusAutomaticOptionButton)
        Me.DrawingStatusFrame.Controls.Add(Me.DrawingStatusManualOptionButton)
        Me.DrawingStatusFrame.Controls.Add(Me.IgnoreDrawingStatusOptionButton)
        Me.DrawingStatusFrame.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.DrawingStatusFrame.Location = New System.Drawing.Point(1003, 335)
        Me.DrawingStatusFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.DrawingStatusFrame.Name = "DrawingStatusFrame"
        Me.DrawingStatusFrame.Padding = New System.Windows.Forms.Padding(4)
        Me.DrawingStatusFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DrawingStatusFrame.Size = New System.Drawing.Size(747, 79)
        Me.DrawingStatusFrame.TabIndex = 9
        Me.DrawingStatusFrame.TabStop = False
        Me.DrawingStatusFrame.Text = "Drawing Status"
        '
        'NotesFrame
        '
        Me.NotesFrame.BackColor = System.Drawing.SystemColors.Control
        Me.NotesFrame.Controls.Add(Me.NotesAutomaticOptionButton)
        Me.NotesFrame.Controls.Add(Me.NotesManualOptionButton)
        Me.NotesFrame.Controls.Add(Me.NotesComboBox)
        Me.NotesFrame.Controls.Add(Me.IgnoreNotesOptionButton)
        Me.NotesFrame.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.NotesFrame.Location = New System.Drawing.Point(1003, 98)
        Me.NotesFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.NotesFrame.Name = "NotesFrame"
        Me.NotesFrame.Padding = New System.Windows.Forms.Padding(4)
        Me.NotesFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NotesFrame.Size = New System.Drawing.Size(747, 79)
        Me.NotesFrame.TabIndex = 10
        Me.NotesFrame.TabStop = False
        Me.NotesFrame.Text = "Notes"
        '
        'ReviewStampFrame
        '
        Me.ReviewStampFrame.BackColor = System.Drawing.SystemColors.Control
        Me.ReviewStampFrame.Controls.Add(Me.ReviewStampAutomaticOptionButton)
        Me.ReviewStampFrame.Controls.Add(Me.ReviewStampManualOptionButton)
        Me.ReviewStampFrame.Controls.Add(Me.ReviewStampComboBox)
        Me.ReviewStampFrame.Controls.Add(Me.IgnoreReviewStampOptionButton)
        Me.ReviewStampFrame.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.ReviewStampFrame.Location = New System.Drawing.Point(1003, 414)
        Me.ReviewStampFrame.Margin = New System.Windows.Forms.Padding(4)
        Me.ReviewStampFrame.Name = "ReviewStampFrame"
        Me.ReviewStampFrame.Padding = New System.Windows.Forms.Padding(4)
        Me.ReviewStampFrame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ReviewStampFrame.Size = New System.Drawing.Size(747, 79)
        Me.ReviewStampFrame.TabIndex = 11
        Me.ReviewStampFrame.TabStop = False
        Me.ReviewStampFrame.Text = "Review Stamp"
        '
        'lblTitle
        '
        Me.lblTitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTitle.AutoSize = True
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(143, 12)
        Me.lblTitle.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(319, 35)
        Me.lblTitle.TabIndex = 21
        Me.lblTitle.Text = "Change Office Address"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Cancel_Button, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Help_Button, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.OK_Button, 1, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(481, 160)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(321, 44)
        Me.TableLayoutPanel2.TabIndex = 28
        '
        'AddressForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(811, 214)
        Me.Controls.Add(Me.TableLayoutPanel2)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.Addressfrm)
        Me.Controls.Add(Me.LogoFrame)
        Me.Controls.Add(Me.BarScaleFrame)
        Me.Controls.Add(Me.NorthPointFrame)
        Me.Controls.Add(Me.DrawingStatusFrame)
        Me.Controls.Add(Me.NotesFrame)
        Me.Controls.Add(Me.ReviewStampFrame)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(3, 15)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(817, 247)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(817, 247)
        Me.Name = "AddressForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Addressfrm.ResumeLayout(False)
        Me.Addressfrm.PerformLayout()
        Me.LogoFrame.ResumeLayout(False)
        Me.BarScaleFrame.ResumeLayout(False)
        Me.NorthPointFrame.ResumeLayout(False)
        Me.DrawingStatusFrame.ResumeLayout(False)
        Me.NotesFrame.ResumeLayout(False)
        Me.ReviewStampFrame.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
#End Region
End Class