
Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Microsoft
Imports Autodesk.AutoCAD.EditorInput
Imports System.IO
Imports System.Collections.Generic
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.Common.Settings


Friend Class AddressForm
    Inherits System.Windows.Forms.Form

    Dim bInitialize As Boolean
    Dim iData As Integer
    Dim svarsfile As String
    Dim cities As Dictionary(Of String, List(Of String))
    Dim Addresses As Object
    Dim config_params() As String
    Dim TBIPath As String
    'Dim GenBlocksPath As String
    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    Private Sub Cancel_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cancel_Button.Click
        Try
            Me.Hide()
            Me.Close()
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub Help_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Help_Button.Click
        CommonHelpButtonClick(Nothing, System.Reflection.MethodBase.GetCurrentMethod.Module.Name, System.Reflection.MethodBase.GetCurrentMethod.Name())
    End Sub


    Private Sub OK_Button_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OK_Button.Click

        Dim GrpC(0) As Short
        Dim GrpV(0) As Object

        Dim ObjBlockRef As Autodesk.AutoCAD.Interop.Common.AcadBlockReference

        Dim Addresses As Dictionary(Of String, List(Of String))
        Dim Address As List(Of String) = Nothing
        Dim iAddress As Integer
        Dim svarsfile As String
        Dim ed As Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor

        Try
            If String.IsNullOrEmpty(RegionCmb.Text) Or String.IsNullOrEmpty(OfficeCmb.Text) Then
                Acad_MessageBox("Both region and office drop down list boxes must have a selected value")
                Exit Sub
            End If

            SaveDialogSettingsInUserArea() ' save Settings on a machine basis
            WriteWorkVar() ' Save Settings on a drawing basis

            svarsfile = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)
            Addresses = Ini.ReadValues(svarsfile, "ADDRESSES", ";")
            For Each data As KeyValuePair(Of String, List(Of String)) In Addresses
                If Me.OfficeCmb.SelectedItem.ToString = data.Key Then
                    Address = data.Value
                    iAddress = 0
                    Exit For
                End If
            Next

            ' Me.Hide()
            Using UI As EditorUserInteraction = ed.StartUserInteraction(Me.Handle)

                Dim ss As Autodesk.AutoCAD.Interop.AcadSelectionSet = SSetAdd("ss")

                ' Do Address Update
                If IgnoreAddressOptionButton.Checked = False Then

                    If AddressManualOptionButton.Checked = True Then

                        GrpC(0) = 0
                        GrpV(0) = "INSERT"

                        Acad_MessageBox("Pick one or more address block(s) to update.")
                        ss.SelectOnScreen(GrpC, GrpV)
                        For Each ObjBlockRef In ss

                            ' Clears all address attributes
                            For Each att As AcadAttributeReference In DirectCast(ObjBlockRef.GetAttributes, IEnumerable)
                                If att.TagString.ToString.Contains("ADDRESSLINE") Then
                                    att.TextString = ""
                                End If
                            Next

                            For iAddress = 0 To Address.Count - 1
                                For Each att As AcadAttributeReference In DirectCast(ObjBlockRef.GetAttributes, IEnumerable)
                                    If att.TagString = "ADDRESSLINE" & iAddress + 1 Then
                                        att.TextString = Address(iAddress)
                                        Exit For
                                    End If
                                Next
                            Next
                        Next ObjBlockRef
                    End If

                    If AddressAutomaticOptionButton.Checked = True Then
                        GrpC(0) = 0
                        GrpV(0) = "INSERT"
                        ss.Select(Autodesk.AutoCAD.Interop.Common.AcSelect.acSelectionSetAll, , , GrpC, GrpV)
                        If ss.Count > 0 Then

                            For Each ObjBlockRef In ss

                                If UCase(ObjBlockRef.EffectiveName) Like UCase("*_*_*_*_*_*_ADDRESS") Then
                                    'Clears all address attributes
                                    For Each att As AcadAttributeReference In DirectCast(ObjBlockRef.GetAttributes, IEnumerable)
                                        If att.TagString.ToString.Contains("ADDRESSLINE") Then
                                            att.TextString = ""
                                        End If
                                    Next

                                    For iAddress = 0 To Address.Count - 1
                                        For Each att As AcadAttributeReference In DirectCast(ObjBlockRef.GetAttributes, IEnumerable)
                                            If att.TagString = "ADDRESSLINE" & iAddress + 1 Then
                                                att.TextString = Address(iAddress)
                                                Exit For
                                            End If
                                        Next
                                    Next
                                End If
                            Next ObjBlockRef
                        End If
                    End If
                End If

                ' Steve added to refresh drawing
                ThisDrawingUtilities.Application.Update()

            End Using

            Me.Hide()
            Me.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Sub WriteWorkVar()

        Try
            WorkingVariableAccessors.AddWorkVar("ADDCFG", Me.RegionCmb.SelectedItem.ToString & ";" & Me.OfficeCmb.Text.ToString)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Function ReadWorkVars() As String()

        ReDim config_params(1)
        Dim wkvar As WorkVars

        Try
            wkvar = WorkingVariableAccessors.GetWorkVar("ADDCFG")

            If wkvar Is Nothing Then
                config_params(0) = "" ' Region
                config_params(1) = "" ' Office
            Else
                config_params = Split(CStr(wkvar.value), ";")
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return config_params

    End Function

    Sub SaveDialogSettingsInUserArea()

        Try
            Dim MyStreamWriter As System.IO.StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.TitleBlockInserterDATFileName), False)

            MyStreamWriter.WriteLine(Me.RegionCmb.Text)
            MyStreamWriter.WriteLine(Me.OfficeCmb.Text)

            MyStreamWriter.Close()

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Function RestoreDialogSettingsInUserArea() As String()



        Dim result() As String = Nothing

        Try

            If System.IO.File.Exists(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.AddressDATFileName)) Then

                Dim MyStreamReader As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.AddressDATFileName), System.Text.Encoding.ASCII)
                Dim line As String = String.Empty
                Dim ctr As Integer = 0
                Dim Config_Params(1) As String

                Do
                    line = MyStreamReader.ReadLine()

                    If line IsNot Nothing Then
                        Config_Params(ctr) = line
                    End If

                    ctr = ctr + 1

                Loop Until line Is Nothing

                MyStreamReader.Close()

                result = Array.Copy(Config_Params)

            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
            result = Nothing
        End Try

        Return result

    End Function

    Sub InsertBlockMS(ByVal blockname As String, ByVal InsertionPoint As Object, ByVal rotation As Double)
        'This function inserts a new block
        Dim rotateangle As Double
        Dim blockrefobj As Autodesk.AutoCAD.Interop.Common.AcadBlockReference
        Try
            'set rotation Angle
            rotateangle = rotation
            rotateangle = rotation * 3.141592 / 180.0#
            ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acModelSpace
            blockrefobj = ThisDrawingUtilities.ModelSpace.InsertBlock(InsertionPoint, TBIPath & "\" & blockname, 1.0#, 1.0#, 1.0#, rotateangle)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Sub InsertBlockPS(ByVal blockname As String, ByVal InsertionPoint As Object, ByVal rotation As Double)
        'This function inserts a new block
        Dim rotateangle As Double
        Dim blockrefobj As Autodesk.AutoCAD.Interop.Common.AcadBlockReference

        Try
            'set rotation Angle
            rotateangle = rotation
            rotateangle = rotation * 3.141592 / 180.0#
            ThisDrawingUtilities.ActiveSpace = Autodesk.AutoCAD.Interop.Common.AcActiveSpace.acPaperSpace
            blockrefobj = ThisDrawingUtilities.ActiveLayout.Block.InsertBlock(InsertionPoint, TBIPath & "\" & blockname, 1.0#, 1.0#, 1.0#, rotateangle)
        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub RegionCmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegionCmb.SelectedIndexChanged
        Try
            'config_params = FileRead() ' read data file to find the last used configuration defaults
            config_params = RestoreDialogSettingsInUserArea() ' Read data file to find the last used configuration defaults
            OfficeCmb.Items.Clear()

            '' find city
            If cities.ContainsKey(RegionCmb.SelectedItem.ToString()) Then
                For Each city As String In cities(RegionCmb.SelectedItem.ToString())
                    OfficeCmb.Items.Add(Trim(city))
                Next
            End If
            If config_params IsNot Nothing Then

                If RegionCmb.SelectedItem.ToString = config_params(0) Then ' If last used value was for this region get the default city
                    OfficeCmb.SelectedItem = config_params(1) ' set last used value as the default
                Else
                    'OfficeCmb.SelectedItem = "" ' set the one at the top of the list as the default
                    OfficeCmb.Text = OfficeCmb.Items(0).ToString
                End If
            Else
                'OfficeCmb.SelectedItem = "" ' set the one at the top of the list as the default
                OfficeCmb.Text = OfficeCmb.Items(0).ToString
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

    End Sub

    Private Sub AddressForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            '' Workout out the Dialog Box Title 
            Me.lblTitle.Text = DeriveTitleFromModuleName(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)
            ' Now that we have things like the AEVersion number and Title display it on the dialog name 
            Me.Text = Me.lblTitle.Text & " " & Settings.Manager.AE.Version

            RepositionTitle(Me.lblTitle, Me)

            TBIPath = Settings.Manager.AE.DrawingSheetsPath  ' LIBRARYPATH & "General\Drawing Sheets"

            'If System.IO.Directory.Exists(Settings.Manager.AE.LibraryFolder.CombinePath("ENTERPRISE")) Then
            '    GenBlocksPath = Settings.Manager.AE.LibraryFolder.CombinePath("ENTERPRISE")
            'Else
            '    If System.IO.Directory.Exists(Settings.Manager.AE.LibraryFolder.CombinePath("JACOBS")) Then
            '        GenBlocksPath = Settings.Manager.AE.LibraryFolder.CombinePath("JACOBS")
            '    Else
            '        GenBlocksPath = Settings.Manager.AE.LibraryFolder.CombinePath("SKM")
            '    End If
            'End If

            Me.Text = "Modify Title Block - " & Settings.Manager.AE.Version

            ' Test to see if file exists first then go read it.
            svarsfile = Settings.Manager.AE.DefaultSettingsPath.CombinePath(Settings.Manager.AE.DrawingSheetSetupINIFileName)

            cities = Ini.ReadValues(svarsfile, "CITIES PER REGION", ";")

            For Each data As KeyValuePair(Of String, List(Of String)) In cities
                Me.RegionCmb.Items.Add(data.Key)
            Next

            config_params = ReadWorkVars() ' Read workvars if they are not set then or we wish to use the file 9 will be false anyway
            If config_params(1) = "" Then ' Do we want to read the DWG file Settings?
                If System.IO.File.Exists(Settings.Manager.AutoCAD.UserSettingsFolder.CombinePath(Settings.Manager.AE.AddressDATFileName)) = True Then ' Has the tool ever been run? Does the DAT file exist?
                    ' config_params = FileRead() ' Read data file to find the last used configuration defaults
                    config_params = RestoreDialogSettingsInUserArea() ' Read data file to find the last used configuration defaults
                End If
            End If

            Try
                Me.RegionCmb.SelectedItem = config_params(0) ' Region
                Me.OfficeCmb.SelectedItem = config_params(1) ' Office
            Catch ex As Exception
                ' Ignore
            End Try

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Private Sub AddressForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        RepositionTitle(Me.lblTitle, Me)
    End Sub
End Class