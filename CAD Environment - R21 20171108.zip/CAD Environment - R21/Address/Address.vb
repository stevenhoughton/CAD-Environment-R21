Imports Autodesk.AutoCAD.Interop
Imports Autodesk.AutoCAD.Interop.Common
Imports Jacobs.Common.Core
Imports Jacobs.AutoCAD.Utilities
Imports Jacobs.AutoCAD.SelectTemplate
Imports Jacobs.Common.Settings

Imports Autodesk.AutoCAD.Runtime

'' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(JACOBS.AutoCAD.ChangeOfficeAddress.ChangeOfficeAddress))> 

Public Class ChangeOfficeAddress

    Private LogName As String = System.IO.Path.GetFileNameWithoutExtension(System.Reflection.MethodBase.GetCurrentMethod.Module.Name)

    ''' <summary>
    ''' Command used to fire off the Address tool
    ''' </summary>
    ''' <remarks></remarks>
    <Autodesk.AutoCAD.Runtime.CommandMethod("Jacobs_Address", Autodesk.AutoCAD.Runtime.CommandFlags.Session)> _
    Public Sub Address()
        Try
            '' If the tool needs to be configured and it is not give the user the option to configure it
            If IsTemplateAssociatedDrawingRequired(System.Reflection.MethodBase.GetCurrentMethod.Module.Name) = True Then
                Dim SelectConfig As New SelectTemplate.TemplateSelector
                SelectConfig.DisplayWarning()
                '' If the user cancelled the select configuration process on either the warning or the selection dialogs then the drawing was not configured
                '' Check here to see if it was configured - hence the user did not cancel prematurely
                If ThisDrawingIsConfigured() = True Then
                    DisplayDialog()
                End If
            Else
                DisplayDialog()
            End If

        Catch ex As Exception
            Acad_ExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try
    End Sub

    Sub DisplayDialog()
        Dim frmAddress As New AddressForm
        Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(frmAddress)
    End Sub

End Class
