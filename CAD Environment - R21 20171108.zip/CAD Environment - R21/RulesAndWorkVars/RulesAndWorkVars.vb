Imports System.io
Imports Microsoft.Win32
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.DatabaseServices
Imports Jacobs.Common.Core

Public Class RulesAndWorkVars

    Public Const RULES_Label As String = "SKM_RULES"

    Public Structure Rule
        Dim name As String
        Dim Desc As String
        Dim value As String
        Dim tblcode As Integer
        Dim dglcode As Integer
    End Structure

    ' Overview
    ' Rules are present in the current file and in the template files.
    ' They default values for tules are defined in the tools.ini file
    ' The values for the tool rules can be overriden using the content wizard at any level
    ' An override flag can be set for each tool that can prevent users from being able to override any rule.

    ' Logic
    ' if the drawing is configured....this function would get called
    '   if Override flag is set for the tool) 
    '       Look for a rule override first (& "-DlgBox")
    '   end if
    '   If override not present or override flag not set look for the rule 
    '   If rule not present check Client.Dwt for the rule
    '   If rule or dwt not present check Office.dwt for the rule
    '   If rule or dwt not present check Discipline.Dwt
    '   If rule or dwt not present check Corporate.dwt
    '   If not found then get defaukt value from tools.ini file
    '   If rule was found on another file write it in this file's database
    ' Else if the drawing is not configured the autocad default Settings will be used. this function would not get called.

    ' rPhase = ReadRule("PHASE")

    Public Function ReadRule(ByVal sRuleName As String, Optional ByVal sFileName As String = "CurrentFile") As Rule

        Dim db As Database = HostApplicationServices.WorkingDatabase() 'save some space
        Dim mReturnRule As Rule = Nothing

        Try
            Using trans As Transaction = db.TransactionManager.StartTransaction() ' begin the transaction

                'Now, drill into the database and obtain a reference to the BlockTable
                Dim BlockTable As BlockTable = CType(trans.GetObject(db.BlockTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), Autodesk.AutoCAD.DatabaseServices.BlockTable)
                Dim ExtensionDictionary As DBDictionary
                Dim RulesDict As DBDictionary
                Dim RuleXRec As Xrecord

                Try
                    ExtensionDictionary = CType(trans.GetObject(BlockTable.ExtensionDictionary(), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead, False), DBDictionary)

                    ' Get the RULES Dictionary from the Extensions Dictionary in the Blocks Table
                    RulesDict = CType(trans.GetObject(ExtensionDictionary.GetAt(RULES_Label), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), DBDictionary)

                    RuleXRec = CType(trans.GetObject(RulesDict.GetAt(sRuleName), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), Xrecord)

                    mReturnRule.name = sRuleName
                    mReturnRule.Desc = CStr(RuleXRec.Data.AsArray(0).Value)
                    mReturnRule.value = CStr(RuleXRec.Data.AsArray(1).Value)
                    mReturnRule.tblcode = CInt(RuleXRec.Data.AsArray(2).Value)
                    mReturnRule.dglcode = CInt(RuleXRec.Data.AsArray(3).Value)

                Catch

                    mReturnRule.name = ""
                    mReturnRule.value = ""
                    mReturnRule.Desc = ""
                    mReturnRule.dglcode = 0
                    mReturnRule.tblcode = 0

                End Try

            End Using
        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)

        End Try

        Return mReturnRule

    End Function

    Public Function AddRule(ByVal sRulename As String, ByVal sRulevalue As String, ByVal sRuleDesc As String, ByVal sRuleDglCode As Integer, ByVal sRuleTblCode As Integer, Optional ByVal sFilename As String = "") As String

        Dim db As Database
        Dim Result As String = ""

        Try
            If sFilename <> "" Then
                db = New Database(False, True)
                Try
                    ' Connect to file that was sent
                    db.ReadDwgFile(sFilename, System.IO.FileShare.ReadWrite, False, "")
                Catch
                    Result = "\nUnable to read drawing file: " & sFilename
                    Return Result
                    Exit Function
                End Try
            Else
                ' connect to existing drawing db
                db = HostApplicationServices.WorkingDatabase() 'save some space
            End If

            Using trans As Transaction = db.TransactionManager.StartTransaction() ' begin the transaction
                'Now, drill into the database and obtain a reference to the BlockTable

                Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), BlockTable)

                Dim Dict As DBDictionary = New DBDictionary()
                Dim btextdict As DBDictionary = New DBDictionary()
                Dim brExtDict As DBDictionary = New DBDictionary()
                Try
                    Try
                        ' Get the Extensions Dictionary from the Block Table
                        btextdict = CType(trans.GetObject(bt.ExtensionDictionary(), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite, False), DBDictionary)
                    Catch
                        ' If you could not get the Extensions Dictionary from the Blocks table it's not there so Create it
                        bt.CreateExtensionDictionary()
                        ' Now get the Extensions Dictionary from the Block Table
                        btextdict = CType(trans.GetObject(bt.ExtensionDictionary(), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite, False), DBDictionary)
                    End Try
                    ' try getting the LABEL Dictionary from the Extensions Dictionary in the Blocks Table
                    Dict = CType(trans.GetObject(btextdict.GetAt(RULES_Label), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), DBDictionary)
                Catch
                    ' If it was or wasn't there overwite it with this new one anyway
                    btextdict.SetAt(RULES_Label, Dict)
                    trans.AddNewlyCreatedDBObject(Dict, True) 'Let the transaction know about any object/entity you add to the database!        
                End Try

                ' Now add the Xrecord Data
                Dim mgrXRec As Xrecord
                Try
                    mgrXRec = CType(trans.GetObject(Dict.GetAt(sRulename), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), Xrecord)
                Catch

                End Try
                mgrXRec = New Xrecord()
                mgrXRec.Data = New ResultBuffer(New TypedValue(CInt("300"), sRuleDesc), _
                                                New TypedValue(CInt("301"), sRulevalue), _
                                                New TypedValue(CInt("281"), sRuleTblCode), _
                                                New TypedValue(CInt("282"), sRuleDglCode))

                Dict.SetAt(sRulename, mgrXRec)
                trans.AddNewlyCreatedDBObject(mgrXRec, True)

                trans.Commit() 'All done, no errors?  Go ahead and commit!

                Try
                    If sFilename <> "" Then
                        db.SaveAs(sFilename, db.OriginalFileVersion)
                        db.Dispose()
                        Result = "Success: File: " & sFilename & " Template has been switched to " & sRulevalue
                        Return Result
                        Exit Function
                    End If

                Catch ex As Exception
                    If ex.Message.Contains("eFileSharingViolation") Then
                        Result = "Fail: " & sFilename & " was open by another user and could not be written to, Template not switched. Try again later."
                        db.Dispose()
                        Return Result
                        Exit Function
                    ElseIf ex.Message.Contains("eFileAccessErr") Then
                        Result = "Fail: " & sFilename & " was/is open by you close the file and try again."
                        db.Dispose()
                        Return Result
                        Exit Function
                    Else
                        Result = "Fail: " & sFilename & " Failed. " & ex.Message
                        db.Dispose()
                        Return Result
                        Exit Function
                    End If
                End Try

            End Using
            Result = "Unexpected exit: " & sFilename & " Failed. "
        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , logName)
        End Try

        Return Result

    End Function

End Class

Public Class WorkVars

    Public Const WORKVARS_Label As String = "SKM_WORKING_VARIABLES"
    Public Structure WorkVar
        Dim name As String
        Dim value As String
    End Structure

    Public Function ReadWorkvar(ByVal sWorkVarName As String) As WorkVar

        Dim WORKVARS_Label As String = "SKM_WORKING_VARIABLES"
        Dim mReturnWorkVar As WorkVar = Nothing

        Try

            Dim db As Database = HostApplicationServices.WorkingDatabase() 'save some space


            Using trans As Transaction = db.TransactionManager.StartTransaction() ' begin the transaction

                'Now, drill into the database and obtain a reference to the BlockTable
                Dim BlockTable As BlockTable = CType(trans.GetObject(db.BlockTableId, Autodesk.AutoCAD.DatabaseServices.OpenMode.ForWrite), Autodesk.AutoCAD.DatabaseServices.BlockTable)

                Dim ExtensionDictionary As DBDictionary
                Dim WorkVarDict As DBDictionary
                Dim RuleXRec As Xrecord

                Try
                    ' Get the Extensions Dictionary from the Block Table
                    ExtensionDictionary = CType(trans.GetObject(BlockTable.ExtensionDictionary(), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead, False), DBDictionary)

                    ' Get the RULES Dictionary from the Extensions Dictionary in the Blocks Table
                    WorkVarDict = CType(trans.GetObject(ExtensionDictionary.GetAt(WORKVARS_Label), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), DBDictionary)

                    ' Get the xRecord from the RULES Dictionary in the Extensions Dictionary in the Blocks Table
                    RuleXRec = CType(trans.GetObject(WorkVarDict.GetAt(sWorkVarName), Autodesk.AutoCAD.DatabaseServices.OpenMode.ForRead), Xrecord)

                    mReturnWorkVar.name = sWorkVarName
                    mReturnWorkVar.value = RuleXRec.Data.AsArray(1).Value.ToString

                Catch
                    mReturnWorkVar.name = ""
                    mReturnWorkVar.value = ""
                End Try

                ReadWorkvar = mReturnWorkVar

            End Using
        Catch ex As Exception

            GeneralExceptionMessageBox(ex, System.Reflection.MethodBase.GetCurrentMethod.Name(), System.Reflection.MethodBase.GetCurrentMethod.Module.Name, , , LogName)
        End Try

        Return mReturnWorkVar


    End Function

End Class


